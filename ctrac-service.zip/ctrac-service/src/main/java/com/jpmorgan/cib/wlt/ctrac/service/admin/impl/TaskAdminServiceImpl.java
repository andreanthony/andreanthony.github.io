package com.jpmorgan.cib.wlt.ctrac.service.admin.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.admin.TaskAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.TaskAdminDTO;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.SleepingTaskState;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional(readOnly = true)
public class TaskAdminServiceImpl implements TaskAdminService {

    @Autowired
    private AuditInformationService auditInformationService;

    @Autowired
    protected TMService tmService;

    @Autowired
    protected PerfectionTaskService perfectionTaskService;

    @Autowired
    private PerfectionTaskRepository perfectionTaskRepository;

    private static final Logger logger = LoggerFactory.getLogger(TaskAdminServiceImpl.class);
    private static final String ACTION_CLOSE = "Close";
    private static final String ACTION_UPDATE = "Update";
    private static final List<String> ACTIONS;

    static {
        List<String> actions = new ArrayList<>();
        actions.add(ACTION_CLOSE);
        actions.add(ACTION_UPDATE);
        ACTIONS = Collections.unmodifiableList(actions);
    }

    private static final List<String> TASK_STATUSES;

    static {
        List<String> taskStatuses = new ArrayList<>();
        taskStatuses.add(TaskStatus.OPEN.getDisplayValue());
        taskStatuses.add(TaskStatus.SLEEPING.getDisplayValue());
        taskStatuses.add(TaskStatus.TRANSIENT.getDisplayValue());
        taskStatuses.add(TaskStatus.CLOSED.getDisplayValue());
        TASK_STATUSES = Collections.unmodifiableList(taskStatuses);
    }

    @Override
    @Secured({EntitlementRoles.ADMIN_ROLE})
    public TaskAdminDTO prepareTaskAdminData() {
        TaskAdminDTO taskAdminData = new TaskAdminDTO();
        taskAdminData.setActions(ACTIONS);
        taskAdminData.setTaskStatuses(TASK_STATUSES);
        return taskAdminData;
    }

    @Override
    @Secured({EntitlementRoles.ADMIN_ROLE})
    public boolean validateTaskAdminData(TaskAdminDTO taskAdminData) {
        if (taskAdminData == null) {
            logger.error("No input parameter passed to validateTaskAdminData");
            return false;
        }
        resetCurrentTaskData(taskAdminData);
        taskAdminData.setAdminMessage(null);
        if (StringUtils.isBlank(taskAdminData.getTaskId())) {
            taskAdminData.setAdminMessage("No Task ID provided.");
            return false;
        }
        String action = taskAdminData.getAction();
        if (StringUtils.isBlank(action) || !isValidAction(action)) {
            taskAdminData.setAdminMessage("Invalid Action provided.");
            return false;
        }
        PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(taskAdminData.getTaskId());
        if (ACTION_UPDATE.equals(action)) {
            if (perfectionTask == null) {
                taskAdminData.setAdminMessage("No task found.");
                return false;
            }
            if (!isValidWorkflowStep(taskAdminData.getWorkflowStep())) {
                taskAdminData.setAdminMessage("Invalid Workflow Step provided.");
                return false;
            } else if (!isValidTaskStatus(taskAdminData.getTaskStatus())) {
                taskAdminData.setAdminMessage("Invalid Task Status provided.");
                return false;
            } else if (TaskStatus.SLEEPING.getDisplayValue().equals(taskAdminData.getTaskStatus())
                    && !(WorkflowStateDefinition.findByWorkflowStep(taskAdminData.getWorkflowStep()).getFloodRemapTaskState() instanceof SleepingTaskState)) {
                taskAdminData.setAdminMessage(taskAdminData.getWorkflowStep()
                        + " is not a valid workflow step for Sleeping task.");
                return false;
            } else if (!isValidDate(taskAdminData.getWakeUpDate())) {
                taskAdminData.setAdminMessage("Invalid Wake Up Date provided.");
                return false;
            } else if (!isValidDate(taskAdminData.getExecutionDate())) {
                taskAdminData.setAdminMessage("Invalid execution Date provided.");
                return false;
            }
        } else if (ACTION_CLOSE.equals(action)) {
            if (perfectionTask == null) {
                taskAdminData.setAdminMessage("Task not found in CTRAC! Submit to close TM task only.");
            } else {
                fillCurrentTaskData(taskAdminData, perfectionTask);
            }
            return true;
        }
        if (perfectionTask == null) {
            resetCurrentTaskData(taskAdminData);
            return false;
        } else {
            fillCurrentTaskData(taskAdminData, perfectionTask);
            return true;
        }

    }

    private void resetCurrentTaskData(TaskAdminDTO taskAdminData) {
        taskAdminData.setCurrentWorkflowStep(null);
        taskAdminData.setCurrentTaskStatus(null);
        taskAdminData.setCurrentWakeUpDate(null);
        taskAdminData.setCurrentExecutionDate(null);
    }

    private void fillCurrentTaskData(TaskAdminDTO taskAdminData, PerfectionTask perfectionTask) {
        taskAdminData.setCurrentWorkflowStep(perfectionTask.getWorkflowStep());
        TaskStatus currentTaskStatus = TaskStatus.findByName(perfectionTask.getTaskStatus());
        if (currentTaskStatus != null) {
            taskAdminData.setCurrentTaskStatus(currentTaskStatus.getDisplayValue());
        }
        Date currentWakeUpDate = perfectionTask.getWakeUpDate();
        taskAdminData.setCurrentWakeUpDate(DateConverter.convert(currentWakeUpDate));
        Date currentExecutionDate = perfectionTask.getExecutionDate();
        taskAdminData.setCurrentExecutionDate(DateConverter.convert(currentExecutionDate));
    }

    private boolean isValidAction(String action) {
        for (String validAction : ACTIONS) {
            if (validAction.equals(action)) {
                return true;
            }
        }
        return false;
    }

    private boolean isValidWorkflowStep(String workflowStep) {
        try {
            return WorkflowStateDefinition.findByWorkflowStep(workflowStep) != null;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isValidTaskStatus(String taskStatus) {
        for (String validTaskStatus : TASK_STATUSES) {
            if (validTaskStatus.equals(taskStatus)) {
                return true;
            }
        }
        return false;
    }

    private boolean isValidDate(String wakeUpDate) {
        try {
            DateConverter.convert(wakeUpDate);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    @Override
    @Secured({EntitlementRoles.ADMIN_ROLE})
    @Transactional(readOnly = false)
    public void submitTaskAdminData(TaskAdminDTO taskAdminData) {
        if (validateTaskAdminData(taskAdminData)) {
            PerfectionTask sourcePerfectionTask = perfectionTaskRepository.findByTmTaskId(taskAdminData.getTaskId());
            if (sourcePerfectionTask == null) {
                // not found in CTRAC
                sourcePerfectionTask = new PerfectionTask();
                sourcePerfectionTask.setTaskStatus(TaskStatus.OPEN.name());
                sourcePerfectionTask.setTmTaskId(taskAdminData.getTaskId());
                sourcePerfectionTask.setTmTaskType(TMTaskType.FLOOD_REMAP.name());
            }
            sourcePerfectionTask.setUpdatedByAdmin(true);
            sourcePerfectionTask.setUpdatedBy(auditInformationService.getLoggedInUserSid());
            sourcePerfectionTask.setUpdatedDate(new Date());
            TaskStatus targetTaskStatus = null;
            if (ACTION_CLOSE.equals(taskAdminData.getAction())) {
                cancelTask(sourcePerfectionTask);
                taskAdminData.setAdminMessage("Task has been cancelled successfully");
            } else if (taskAdminData.isGenerateNewTaskId() && (ACTION_UPDATE.equals(taskAdminData.getAction()))) {
                targetTaskStatus = TaskStatus.findByDisplayValue(taskAdminData.getTaskStatus());
                cancelTask(sourcePerfectionTask);
                updateTaskWithDTOData(taskAdminData.isGenerateNewTaskId(), sourcePerfectionTask, taskAdminData);
                if (TaskStatus.OPEN == targetTaskStatus) {
                    createTask(sourcePerfectionTask);
                }
                perfectionTaskService.saveTask(sourcePerfectionTask);
                taskAdminData.setAdminMessage("Task has been cancelled and re-created successfully");
            } else if (ACTION_UPDATE.equals(taskAdminData.getAction())) {
                targetTaskStatus = TaskStatus.findByDisplayValue(taskAdminData.getTaskStatus());
                TaskStatus sourceTaskStatus = TaskStatus.findByName(sourcePerfectionTask.getTaskStatus());
                updateTaskWithDTOData(false, sourcePerfectionTask, taskAdminData);
                taskAdminData.setAdminMessage("Task attributes updated sucessfully");
                if (TaskStatus.OPEN == sourceTaskStatus && TaskStatus.OPEN == targetTaskStatus) {
                    amendTask(sourcePerfectionTask);
                    taskAdminData.setAdminMessage("Task has been created successfully");
                } else if (TaskStatus.OPEN == targetTaskStatus) {
                    createTask(sourcePerfectionTask);
                    taskAdminData.setAdminMessage("Task has been created successfully");
                } else if (TaskStatus.CLOSED == targetTaskStatus) {
                    cancelTask(sourcePerfectionTask);
                    taskAdminData.setAdminMessage("Task has been cancelled successfully");
                }
                perfectionTaskService.saveTask(sourcePerfectionTask);
            }
        }

    }

    private void amendTask(PerfectionTask sourcePerfectionTask) {
        try {
            tmService.amendTask(sourcePerfectionTask);
        } catch (TMServiceApplicationException ex) {
            throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
        } catch (Exception ex) {
            throw new CTracApplicationException("E0352", CtracErrorSeverity.APPLICATION, ex);
        }
    }

    private void createTask(PerfectionTask sourcePerfectionTask) {
        try {
            tmService.createTask(sourcePerfectionTask);
        } catch (TMServiceApplicationException ex) {
            throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
        } catch (Exception ex) {
            throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
        }
    }

    private void cancelTask(PerfectionTask sourcePerfectionTask) {
        try {
            tmService.cancelTask(sourcePerfectionTask);
        } catch (TMServiceApplicationException ex) {
            throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
        } catch (Exception ex) {
            throw new CTracApplicationException("E0355", CtracErrorSeverity.APPLICATION, ex);
        }
    }

    private void updateTaskWithDTOData(boolean generateNewOtemTaskId, PerfectionTask sourcePerfectionTask, TaskAdminDTO taskAdminData) {
        sourcePerfectionTask.setWorkflowStep(taskAdminData.getWorkflowStep());
        TaskStatus taskStatus = TaskStatus.findByDisplayValue(taskAdminData.getTaskStatus());
        if (taskStatus != null) {
            sourcePerfectionTask.setTaskStatus(taskStatus.name());
        }
        sourcePerfectionTask.setWakeUpDate(DateConverter.convert(taskAdminData.getWakeUpDate()));
        sourcePerfectionTask.setExecutionDate(DateConverter.convert(taskAdminData.getExecutionDate()));
        if (generateNewOtemTaskId) {
            sourcePerfectionTask.setTmTaskId(UUID.randomUUID().toString());
        }
    }
}
