package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import java.util.Date;

public interface ReferenceDateService {
    void updateReferenceDate(Date referenceDate);

    void advanceReferenceDate();

    void advanceReferenceDate(String dayOfWeek);
}
