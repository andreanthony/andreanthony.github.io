package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

public class GenericEmailData extends FloodRemapSendEmailData implements Serializable {

	private static final long serialVersionUID = 4745787017846213849L;
	private String pageTitle;
	private String sendEmailUrl;	
	private EmailAttributeHolder emailAttributeHolder;
	private String emailStaticContent;
	
	public String getPageTitle() {
		return pageTitle;
	}
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	public String getSendEmailUrl() {
		return sendEmailUrl;
	}
	public void setSendEmailUrl(String sendEmailUrl) {
		this.sendEmailUrl = sendEmailUrl;
	}
	public EmailAttributeHolder getEmailAttributeHolder() {
		return emailAttributeHolder;
	}
	public void setEmailAttributeHolder(EmailAttributeHolder emailAttributeHolder) {
		this.emailAttributeHolder = emailAttributeHolder;
	}
	public String getEmailStaticContent() {
		return emailStaticContent;
	}
	public void setEmailStaticContent(String emailStaticContent) {
		this.emailStaticContent = emailStaticContent;
	}
	
}
