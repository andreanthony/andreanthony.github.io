package com.jpmorgan.cib.wlt.ctrac.service.collateral.details;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CreateNewCollateralRecord;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.FloodDeterminationDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.FloodDeterminationSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.InsurancePoliciesSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.LoanBorrowerSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.WorkflowDetailsSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ReferenceValues;

public interface CollateralDetailsService {

	/**
	 * Populate all collateral information 
	 * @param collateralRid
	 * @return
	 */
	CollateralDetailsMainDto populateCollateralDetailsInformation(Long collateralRid);
	
	void refreshCollateralSection(CollateralDetailsMainDto collateralDetailsMainDto);
	
	ReferenceValues getCollateralScreenReferenceValues();
	
	void putCollateralDescription(CollateralDetailsMainDto collateralDetailsMainDto, Long collateralId);

	/**
	 * Save collateral section information
	 * @param collateralDetailsMainDto
     * @param screenAction
	 */
	void saveCollateralSectionInfo(CollateralDetailsMainDto collateralDetailsMainDto, CollateralScreenAction screenAction);
	
	void updateCollateralDetailsSection(CollateralDto collateralDto, CollateralScreenAction action, CollateralDetailsSection sectionName);
	
	/**
	 * Delete collateral owner in collateral dto
	 * @param collateralDto
	 * @param index
	 * @return
	 */
	CollateralDto removeCollateralOwner(CollateralDto collateralDto, int index);

	/**
	 * Delete collateral owner in collateral dto
	 * @param collateralDetailsMainDto
	 * @param customerData
	 * @return
	 */

    CollateralDto removeCollateralOwner(CollateralDetailsMainDto collateralDetailsMainDto, CustomerData customerData);

    /**
	 * Add collateral owner data in collateral dto
	 * @param collateralDto
	 * @return
	 */
	CollateralDto addCollateralOwner(CollateralDto collateralDto);	
	
	/**
	 * Add collateral owner data in collateral dto
	 * @param collateralDetailsMainDto
	 * @return
	 */
	CollateralDetailsMainDto addExistingCollateralOwner(CollateralDetailsMainDto collateralDetailsMainDto, Long ownerRid);	
	
	/**
	 * Remove mortgagor doc in collateral section dto
	 * @param collateralSectionDto
	 * @param index
	 * @return
	 */
	CollateralSectionDto removeMortgagorDoc(CollateralSectionDto collateralSectionDto, int index);

	/**
	 * @param floodDeterminationSectionDto
	 * @param action
	 * @return
	 */
	FloodDeterminationDto prepareFloodDeterminationOverlayData(CollateralDto collateralDto, FloodDeterminationSectionDto floodDeterminationSectionDto, String action, Long fiatId);
	
    LoanBorrowerSectionDto changePrimaryLoan(LoanBorrowerSectionDto loanBorrowerSectionDto,Long loanRid);
        	
    void deleteLoanBorrower(CollateralDetailsMainDto collateralDetailsMainDto, Long loanToDelete);

    void refreshLoanBorrowerSection(CollateralDetailsMainDto collateralDetailsMainDto);
    
    void saveLoanBorrower(CollateralDetailsMainDto collateralDetailsData, LoanData loansData, boolean isPrimary);

    void savePolicy(CollateralDetailsMainDto collateralDetailsMainDto, ProofOfCoverageDTO proofOfCoverageData, List<MultipartFile> policyAttachments);

    void saveOverridePolicyOnly(CollateralDetailsMainDto collateralDetailsMainDto, ProofOfCoverageDTO proofOfCoverageData);

	CreateNewCollateralRecord prepareCreateNewCollateralRecord();
	
	boolean checkIfValidExpirationDate(CollateralDetailsMainDto collateralDetailsData,ProofOfCoverageDTO proofOfCoverageData);

	void refreshInsurancePoliciesSection(Long collateralRid, InsurancePoliciesSectionDto insurancePoliciesData);
		
	CollateralDetailsMainDto submitForVerification(CollateralDetailsMainDto collateralDetailsData);

	void refreshWorkflowDetailsSection(Long collateralRid, WorkflowDetailsSectionDto workflowDetailsSectionDto);
	
	void refreshFloodDeterminationSection(CollateralDetailsMainDto collateralDetailsMainDto);

    String getAdminComments(Long collateralId);

	void updateAdminComments(Long collateralId, String adminComments);
	
}
 
