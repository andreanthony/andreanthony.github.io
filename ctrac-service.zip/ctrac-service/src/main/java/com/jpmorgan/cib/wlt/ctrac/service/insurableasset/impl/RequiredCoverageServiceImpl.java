package com.jpmorgan.cib.wlt.ctrac.service.insurableasset.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredCoverageViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.comparators.MostRecentDocumentDateComparator;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.HoldDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageSourceDto;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.CoverageDetailService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.RequiredCoverageService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

@Service
public class RequiredCoverageServiceImpl implements RequiredCoverageService {

	@Autowired
	private ActivePolicyService activePolicyService;
    @Autowired
    private BuildingRepository buildingRepository;
    @Autowired
    private CtracObjectMapper ctracObjectMapper;
    @Autowired
    private InsurableAssetRepository insurableAssetRepository;
    @Autowired
    private CoverageDetailsRepository coverageDetailsRepository;
    @Autowired
    private CoverageDetailService coverageDetailService;
    @Autowired
    private RequiredCoverageRepository requiredCoverageRepository;
    @Autowired
    private CollateralDocumentService collateralDocumentService;
    @Autowired
    private RequiredCoverageSourceRepository requiredCoverageSourceRepository;
    @Autowired
    private CollateralDocumentRepository collateralDocumentRepository;
    @Autowired
    private BusinessDayUtil businessDayUtil;
    @Autowired
    private RequiredCoverageViewRepository requiredCoverageViewRepository;


    private static final Logger logger = LoggerFactory.getLogger(RequiredCoverageServiceImpl.class);

    // =============== Required Coverages  DB OP =====================================
    @Override
    @Transactional(readOnly = true)
    public Collection<RequiredCoverageDTO> findRequiredCoverageByCollateral(Long collateralRid, InsuranceType insuranceType) {
        List<RequiredCoverageDTO> result = new ArrayList<>();
        List<InsurableAsset> insurableAssets = insurableAssetRepository.findByBuildingCollateralRid(collateralRid);
        for (InsurableAsset insurableAsset : insurableAssets) {
            result.addAll(findRequiredCoveragesByInsurableAsset(insurableAsset, insuranceType));
        }
        return result;
    }

    @Override
    @Transactional(readOnly = true)
    public Collection<RequiredCoverageDTO> findRequiredCoveragesByInsurableAsset(
    		Long insurableAssetRid, InsuranceType coverageType) {
    	InsurableAsset insurableAsset = insurableAssetRepository.findOne(insurableAssetRid);
        return findRequiredCoveragesByInsurableAsset(insurableAsset, coverageType);
    }

    public Collection<RequiredCoverageDTO> findRequiredCoveragesByInsurableAsset(InsurableAsset insurableAsset, InsuranceType coverageType) {
        return buildAndPopulateRequiredCoverageDto(
                coverageType, insurableAsset, ctracObjectMapper.map(insurableAsset, InsurableAssetDTO.class));
    }

    @Override
    public Set<RequiredCoverageViewData> getLatestInactiveRequiredCoverages(Long collateralRid) {
        Set<RequiredCoverageViewData> previousCoverages = new HashSet<>();
        List<RequiredCoverageViewData> inactiveFiats =
                requiredCoverageViewRepository.findByCollateralRidAndStatus(collateralRid, CoverageRequirementStatus.INACTIVE.name());
        if(!CollectionUtils.isEmpty(inactiveFiats)){
            //sort list on Most recent based on document Date of the fiat
            Collections.sort(inactiveFiats,new MostRecentDocumentDateComparator());
            Date lastDocumentDate = inactiveFiats.get(0).getDocumentDate();
            //get only the top coverages with the latest document date
            for (RequiredCoverageViewData requiredCoverageViewData : inactiveFiats) {
                if(lastDocumentDate.equals(requiredCoverageViewData.getDocumentDate())){
                    previousCoverages.add(requiredCoverageViewData);
                }
            }
        }
        return previousCoverages;
    }

    @Override
    @Transactional
    public void saveRequiredCoverage(RequiredCoverageDTO requiredCoverageDTO) {

        // -1 first save the properties of this object
        if (requiredCoverageDTO.getPrimaryCoverageDetailsDto() != null) {
        	requiredCoverageDTO.getPrimaryCoverageDetailsDto().setCoverageType("Primary");
        	coverageDetailService.saveCoverageDetails(requiredCoverageDTO.getPrimaryCoverageDetailsDto());
        }

        if(requiredCoverageDTO.getExcessCoverageDetailsDto() != null){
        	requiredCoverageDTO.getExcessCoverageDetailsDto().setCoverageType("Excess");
        	coverageDetailService.saveCoverageDetails(requiredCoverageDTO.getExcessCoverageDetailsDto());
        }

        InsurableAssetDTO insurableAssetDto = requiredCoverageDTO.getInsurableAssetDTO();
        if (insurableAssetDto.getBuildingRid() == null) {
            createOrUpdateBuilding(insurableAssetDto);
        }
        saveInsurableAsset(insurableAssetDto);

        //TODO only save if it has changed... also we normally must save the source before this is likely not needed
        if(requiredCoverageDTO.getRequiredCoverageSourceDto()!=null ){
            saveRequiredCoverageSource(requiredCoverageDTO.getRequiredCoverageSourceDto(), null);
        }

        // 3
        RequiredCoverage requiredCoverageToUpdate = new RequiredCoverage();
        if (requiredCoverageDTO.getRid() != null) {
            requiredCoverageToUpdate = requiredCoverageRepository.findOne(requiredCoverageDTO.getRid());
        }

        // if we need to refresh/update dependent objects
        if (requiredCoverageDTO.getPrimaryCoverageDetailsDto() != null) {
            CoverageDetails coverageDetails = coverageDetailsRepository.findOne(requiredCoverageDTO.getPrimaryCoverageDetailsDto().getRid());
            requiredCoverageToUpdate.setPrimaryCoverageDetails(coverageDetails);
        }

        if(requiredCoverageDTO.getExcessCoverageDetailsDto() != null){
        	 CoverageDetails coverageDetails = coverageDetailsRepository.findOne(requiredCoverageDTO.getExcessCoverageDetailsDto().getRid());
             requiredCoverageToUpdate.setExcessCoverageDetails(coverageDetails);
        }

        //
        if (requiredCoverageDTO.getInsurableAssetDTO() != null) {
            InsurableAsset insurableAsset = insurableAssetRepository.findOne(requiredCoverageDTO.getInsurableAssetDTO().getRid());
            requiredCoverageToUpdate.setInsurableAsset(insurableAsset);
        }

        if(requiredCoverageDTO.getRequiredCoverageSourceDto()!=null ){
            RequiredCoverageSource reqCovSource = requiredCoverageSourceRepository.findOne(requiredCoverageDTO.getRequiredCoverageSourceDto().getRid());
            requiredCoverageToUpdate.setRequiredCoverageSource(reqCovSource);
        }

        ctracObjectMapper.map(requiredCoverageDTO, requiredCoverageToUpdate);
        RequiredCoverage savedRequiredCoverage = requiredCoverageRepository.saveAndFlush(requiredCoverageToUpdate);

        requiredCoverageDTO.setRid(savedRequiredCoverage.getRid());
        if(requiredCoverageToUpdate.getPrimaryHold()==null) {
            HoldDTO holdDTO = new HoldDTO();
            holdDTO.setCoverageType(CoverageType.PRIMARY);
            requiredCoverageDTO.setPrimaryHold(holdDTO);
        }
        if(requiredCoverageToUpdate.getExcessHold()==null) {
            HoldDTO holdDTO = new HoldDTO();
            holdDTO.setCoverageType(CoverageType.EXCESS);
            requiredCoverageDTO.setExcessHold(holdDTO);
        }
        requiredCoverageDTO.refreshAuditUpdate(savedRequiredCoverage);
    }

    private void createOrUpdateBuilding(InsurableAssetDTO insurableAssetDto) {
        Building building = buildingRepository.findByCollateralIdAndSortOrder(insurableAssetDto.getCollateralRid(), insurableAssetDto.getSortOrder());
        if (building == null) {
            building = new Building();
            building.setBuildingName(insurableAssetDto.getBuildingName());
            building.setCollateralRid(insurableAssetDto.getCollateralRid());
            building.setActive(true);
            building.setSortOrder(insurableAssetDto.getSortOrder());
            building = buildingRepository.save(building);
        } else if (StringUtils.isNotBlank(insurableAssetDto.getBuildingName()) &&
                !insurableAssetDto.getBuildingName().equals(building.getBuildingName())) {
            building.setBuildingName(insurableAssetDto.getBuildingName());
            building = buildingRepository.save(building);
        }
        insurableAssetDto.setBuildingRid(building.getRid());
    }


    @Override
    @Transactional
    public void saveRequiredCoverageSource(RequiredCoverageSourceDto requiredCoverageSourceDto,  List<MultipartFile> sourceDocumentFiles) {

    	//1 Persist the required coverage source
        RequiredCoverageSource requiredCovSource = new RequiredCoverageSource();
        if(requiredCoverageSourceDto.getRid()!=null ){
            requiredCovSource = requiredCoverageSourceRepository.findOne(requiredCoverageSourceDto.getRid());
        }

        // if source is not FIAT, reset OPB related fields. These fields are not bound automatically because these are hidden fields in frontend
        // if source is not FIAT
        if ("FIAT".equals(requiredCoverageSourceDto.getSource())) {
        	if ("N".equals(requiredCoverageSourceDto.getReqdCovSameAsOPB())) {
        		requiredCoverageSourceDto.setExcessRequired(null);
            	requiredCoverageSourceDto.setOutstandingPrincipleBalance(null);
        	}

        	if ("Y".equals(requiredCoverageSourceDto.getExcessRequired())) {
        		requiredCoverageSourceDto.setOutstandingPrincipleBalance(null);
        	}
        } else {
        	requiredCoverageSourceDto.setReqdCovSameAsOPB(null);
        	requiredCoverageSourceDto.setExcessRequired(null);
        	requiredCoverageSourceDto.setOutstandingPrincipleBalance(null);
        }

        ctracObjectMapper.map(requiredCoverageSourceDto, requiredCovSource);
        requiredCoverageSourceRepository.saveAndFlush(requiredCovSource);

        //2 Update and persist the coverage documents
        Collection <CollateralDocument> coverageSourceDocuments = null;
        Date documentDate = null;
        String documentDateString = requiredCoverageSourceDto.getDocumentDate();
        if (!StringUtils.isBlank(documentDateString)) {
            try {
                documentDate = DateConverter.convert(documentDateString);
            }
            catch (Exception e) {
            }
        }

        if(sourceDocumentFiles!=null && !sourceDocumentFiles.isEmpty()){

            coverageSourceDocuments = collateralDocumentService.saveCollateralDocuments(sourceDocumentFiles,
            		 CtracAppConstants.FIAT_DOCUMENT_IDENTIFIER, documentDate, null);

            for(CollateralDocument coverageSourceDocument : coverageSourceDocuments){
            	coverageSourceDocument.setRequiredCoverageSource(requiredCovSource);
            }

            collateralDocumentRepository.save(coverageSourceDocuments);

            requiredCoverageSourceDto.setCoverageSourceDocuments(coverageSourceDocuments, false);
        }

        requiredCoverageSourceDto.setRid(requiredCovSource.getRid());
        requiredCoverageSourceDto.refreshAuditUpdate(requiredCovSource);

    }



    @Override
    @Transactional
    public void deleteRequiredCoverages(Collection<Long> coverageIds) {

        if (coverageIds == null || coverageIds.isEmpty()) {
            return;
        }

        for (Long Id : coverageIds) {
            try {
                requiredCoverageRepository.delete(Id);
            } catch (Exception e) {

            }
        }
    }

    @Transactional
    public void saveRequiredCoverage(Collection<RequiredCoverageDTO> requiredCoverageDTOList) {

        for (RequiredCoverageDTO requiredCovDto : requiredCoverageDTOList) {
            saveRequiredCoverage(requiredCovDto);
        }
    }

    // =============== Required Coverages: controller Helper operation  =====================================

    private List<RequiredCoverageDTO> buildAndPopulateRequiredCoverageDto(InsuranceType coverageType,
            InsurableAsset insurableAsset, InsurableAssetDTO insurableAssetDTO) {
        if (insurableAsset == null) {
            return insurableAssetDTO != null ? insurableAssetDTO.getRequiredCoverageDTOs() : null;
        }

        // for display && business logic purposes, we need to know if the insurable asset
        // and required coverage had some valid coverages
        Boolean hasSomeValidCoverage = activePolicyService.insurableAssetHasActiveCoverage(
        		insurableAsset.getRid(), businessDayUtil.getCurrentReferenceDate(), false);
        for (RequiredCoverage requiredCoverage : insurableAsset.getRequiredCoverages()) {
            if (coverageType == null /*|| coverageType.name().equals(requiredCoverage.getCoverageDetails().getCoverageType())*/) {
                requiredCoverage = CtracBaseEntity.deproxy(requiredCoverage, RequiredCoverage.class);
                RequiredCoverageDTO requiredCovDto = ctracObjectMapper.map(requiredCoverage, RequiredCoverageDTO.class);
                requiredCovDto.setInsurableAssetDTO(insurableAssetDTO);
                Collection <CollateralDocument>  colDocs = requiredCoverage.getRequiredCoverageSource().getCoverageSourceDocuments();
                requiredCovDto.getRequiredCoverageSourceDto().setCoverageSourceDocuments(colDocs, true);
                requiredCovDto.setHadSomeCoverage(hasSomeValidCoverage);
                insurableAssetDTO.addRequiredCoverage(requiredCovDto);
            }
        }
        // TODO enable this line and simplify the code in the loop above when we
        // know how to map nested fields with ORIKA
        // result = ctracObjectMapper.mapAsList(candidateList,
        // ProvidedCoverageDTO.class);
        return insurableAssetDTO.getRequiredCoverageDTOs();
    }

    void saveInsurableAsset(InsurableAssetDTO insurableAssetDTO) {

        if (!insurableAssetDTO.hasChanged()) {
            return;
        }

        Building building = null;
        if (insurableAssetDTO.getBuildingRid() != null) {
            building = buildingRepository.findOne(insurableAssetDTO.getBuildingRid());
        }
        if (building == null) {
            logger.error(" The Building RID invalid");
            throw new RuntimeException(" Invalid state exception: cannot save and insurable asset without a valid Building id");
        }

        if (insurableAssetDTO.getInsurableAssetType() == InsurableAssetType.STRUCTURE && !insurableAssetDTO.getBuildingName().equals(building.getBuildingName())) {
            building.setBuildingName(insurableAssetDTO.getBuildingName());
            building = buildingRepository.save(building);
        }

        InsurableAsset insurableAssetToUpdate = null;
        if (insurableAssetDTO.getRid() != null) {
            insurableAssetToUpdate = insurableAssetRepository.findOne(insurableAssetDTO.getRid());
        } else if (insurableAssetDTO.getInsurableAssetType() != null) {
            insurableAssetToUpdate = new InsurableAsset(insurableAssetDTO.getInsurableAssetType());
        }
        if(insurableAssetToUpdate == null){
            throw new IllegalStateException("Invalid state - No Insurable asset DTO has been initialized");
        }

        insurableAssetToUpdate.setBuilding(building);
        insurableAssetToUpdate = CtracBaseEntity.deproxy(insurableAssetToUpdate, InsurableAsset.class);
        ctracObjectMapper.map(insurableAssetDTO, insurableAssetToUpdate);

        insurableAssetRepository.saveAndFlush(insurableAssetToUpdate);
        insurableAssetDTO.setRid(insurableAssetToUpdate.getRid());
    }

}
