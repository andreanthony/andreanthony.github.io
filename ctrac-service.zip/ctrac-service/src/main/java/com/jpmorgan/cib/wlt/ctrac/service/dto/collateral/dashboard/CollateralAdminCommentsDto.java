package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import org.springmodules.validation.bean.conf.loader.annotation.handler.MaxLength;
import org.springmodules.validation.bean.conf.loader.annotation.handler.NotNull;

import java.io.Serializable;

/**
 * Created by E704298 on 7/18/2017.
 */
public class CollateralAdminCommentsDto implements Serializable {

    private static final long serialVersionUID = -4302017464834476938L;

    public CollateralAdminCommentsDto() {}

    public CollateralAdminCommentsDto(String adminComments) {
        this.adminComments = adminComments;
    }

    @MaxLength(2000)
    private String adminComments;

    public String getAdminComments() {
        return adminComments;
    }

    public void setAdminComments(String adminComments) {
        this.adminComments = adminComments;
    }
}
