package com.jpmorgan.cib.wlt.ctrac.service.api;

public enum RestPathVariable {
    COLLATERAL_ID
}
