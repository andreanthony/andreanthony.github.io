package com.jpmorgan.cib.wlt.ctrac.service.dto.admin;

import java.io.Serializable;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;

public class BatchJobMaintenanceData implements Serializable {
	private static final long serialVersionUID = 5252457557658647565L;

	public String getSuccessMsg() {
		return successMsg;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<BatchCtrl> getBatchCtrl() {
		return batchCtrl;
	}

	public void setBatchCtrl(List<BatchCtrl> batchCtrl) {
		this.batchCtrl = batchCtrl;
	}

	private String successMsg = null;
	
	private String errorMsg = null;
		
	private List<BatchCtrl> batchCtrl;
}
