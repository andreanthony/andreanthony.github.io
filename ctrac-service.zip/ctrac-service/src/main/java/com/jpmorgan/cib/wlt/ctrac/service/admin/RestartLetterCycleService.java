package com.jpmorgan.cib.wlt.ctrac.service.admin;

import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.RestartLetterCycleDTO;

public interface RestartLetterCycleService {

	RestartLetterCycleDTO prepareRestartLetterCycleData(Long collateralId);
		
	void submitRestartLetterCycleData(RestartLetterCycleDTO restartLetterCycleData);
	
}
