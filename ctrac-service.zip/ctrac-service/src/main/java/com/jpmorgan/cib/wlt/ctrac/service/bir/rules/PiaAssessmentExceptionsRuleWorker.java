package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class PiaAssessmentExceptionsRuleWorker extends AbstractBIRRuleWorker {
	
	public PiaAssessmentExceptionsRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRRuleConclusionDTO piaAssessmentExceptionsConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		String piaAssessmentExceptions =
				borrowerInsuranceReviewData.getProofOfCoverageData().getPiaAssessmentExceptions();
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if ("yes".equalsIgnoreCase(piaAssessmentExceptions)) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACTION_REQUIRED;
		} else if ("no".equalsIgnoreCase(piaAssessmentExceptions)) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		}
		if (birConclusion != null) {
			piaAssessmentExceptionsConclusion.setConclusion(birConclusion.name());
		}
	}
	
}
