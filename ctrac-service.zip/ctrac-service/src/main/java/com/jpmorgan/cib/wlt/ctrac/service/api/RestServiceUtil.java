package com.jpmorgan.cib.wlt.ctrac.service.api;

public class RestServiceUtil {
    private RestServiceUtil() {}

    public static final RuntimeException NOT_IMPLEMENTED_EXCEPTION = new RuntimeException("Method not implemented.");

    public static final RuntimeException INVALID_REQUEST_EXCEPTION = new RuntimeException("Invalid request.");
}
