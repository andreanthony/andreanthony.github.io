package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import java.math.BigDecimal;


public class VerifyPreRenewalLetterDto extends VerifyLetterData {

	private static final long serialVersionUID = 1L;

	private String coverageType;

	private String coverageAmount;

	private String dateOfLetter;

	private String letterVerified;

	private String letterRetrievedImaged;
	
	private String reminderDate;
	
	private String currentDate;
	
	public String getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}

	public String getDateOfLetter() {
		return dateOfLetter;
	}

	public void setDateOfLetter(String dateOfLetter) {
		this.dateOfLetter = dateOfLetter;
	}
	
	public String getReminderDate() {
		return reminderDate;
	}

	public void setReminderDate(String reminderDate) {
		this.reminderDate = reminderDate;
	}

	public String getLetterRetrievedImaged() {
		return letterRetrievedImaged;
	}

	public void setLetterRetrievedImaged(String letterRetrievedImaged) {
		this.letterRetrievedImaged = letterRetrievedImaged;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(String coverageAmount) {
		this.coverageAmount = coverageAmount;
	}
	
	public void setCoverageAmount(BigDecimal coverageAmount) {
		//this.coverageAmount = AmountFormatter.format(coverageAmount);
	}

	public String getLetterVerified() {
		return letterVerified;
	}

	public void setLetterVerified(String letterVerified) {
		this.letterVerified = letterVerified;
	}



}
