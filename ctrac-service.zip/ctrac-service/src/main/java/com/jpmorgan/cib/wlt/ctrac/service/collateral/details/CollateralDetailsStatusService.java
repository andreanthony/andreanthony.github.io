package com.jpmorgan.cib.wlt.ctrac.service.collateral.details;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralWorkflowParam;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.SectionStatusDto;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;

public interface CollateralDetailsStatusService {

	/**
	 * Initiate all the section status - each section will be initialized with "DRAFT" status
	 *
	 * @param collateralId
	 */
	void initAllCollateralSectionsStatus(Long collateralId);

	/**
	 * Load section status for each section
	 *
	 * @param collateralId
	 * @param mainDto
	 */
	void loadAllCollateralSectionsStatus(CollateralDto collateralDto, List<SectionStatusDto> sectionStatusDtos);

	/**
	 * Advance each section to the next status; And advance collateral to pending_verification
	 * For now, this method should be only called when a "Draft" collateral is sent to be verified
	 *
	 * @param collateralId
	 * @param mainDto
	 */
	void advanceAllSections(CollateralDto collateralDto, List<SectionStatusDto> sectionStatusDtos);

	void saveSectionsStatus(List<SectionStatusDto> sectionStatusDtos);

	/**
	 * 1. Advance one section's status
	 * 2. Build workflow param with verification status for all sections
	 *
	 * @param collateralId
	 * @param section
	 */
	CollateralWorkflowParam advanceSection(CollateralDto collateralDto, TMParams tmParams,
			SectionStatusDto sectionStatusDto, CollateralScreenAction screenAction);

	void updateLoanBorrowerSection(CollateralDetailsMainDto collateralDetailsData);

	void updateInsurancePoliciesSection(CollateralDto collateralDto, CollateralScreenAction action,TMParams tmParams);

	boolean isValidForLinking(Long collateralId, WorkflowStateDefinition workflowStep);

	boolean areAllSectionsVerified(Long collateralId);

	boolean areBasicSectionsVerified(Long collateralId);

	void saveSectionStatus(Long collateralId);

	List<SectionStatusDto> getSectionStatuses(Long collateralId);

	void allowAnyVerification(Long collateralId);
}
