package com.jpmorgan.cib.wlt.ctrac.service.collateral.details;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;

import java.util.Date;

public interface ReviewCollateralService {
	
	void initiateReadyForLP(Long proofOfCoverageRid);
	
	boolean hasActiveReviewCollateralTask(Long collateralRid);

	void completeCollateralReview(CollateralDetailsMainDto collateralDetailsData);
	
	void advancePendingVerifyCollateral(Long collateralRid);

	Date calcReviewCollateralTaskWakeupDate(WorkItem workItem, ProofOfCoverage policy);

	void createSleepingReviewCollateralWorkflow(WorkItem workItem);
}
