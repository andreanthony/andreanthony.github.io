package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

public class ReconcilationResult {
	String id;
	String fieldName;
	public ReconcilationResult(String id, String fieldName, String sourceValue,
			String targetValue) {
		super();
		this.id = id;
		this.fieldName = fieldName;
		this.sourceValue = sourceValue;
		this.targetValue = targetValue;
	}
	public ReconcilationResult(){}
	String sourceValue;
	String targetValue;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getSourceValue() {
		return sourceValue;
	}
	public void setSourceValue(String sourceValue) {
		this.sourceValue = sourceValue;
	}
	public String getTargetValue() {
		return targetValue;
	}
	public void setTargetValue(String targetValue) {
		this.targetValue = targetValue;
	}
	public String toString(){
		return getId()+"|"+getFieldName()+"|"+getSourceValue()+"|"+getTargetValue()+"|";
	}
}
