package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions;

import java.util.Date;

public class AlthansLPRequestRow implements Comparable<AlthansLPRequestRow>{

	private String servicingTeam;
	private String proofOfCoverageRid;
	private String loanNumber;
	private String requestType;
	private String policyType;
	private String propertyType;
	private String borrowerName;
	private String borrowerMailingAddressStreet;
	private String borrowerMailingAddressCity;
	private String borrowerMailingAddressState;
	private String borrowerMailingAddressZip;
	private String addlBorrowersAndOwners;
	private String propertyAddress;
	private String buildingName;
	private String propertyUnitBldg;
	private String propertyCity;
	private String propertyState;
	private String propertyZipCode;
	private String floodZone;
	private Date effectiveDate;
	private Date expirationDate;
	private Date cancellationEffectiveDate;
	private String valueBasedOn;
	private String buildingCoverageAmount;
	private String contentsCoverageAmount;
	private String businessCoverageAmount;
	private String comments;
	private String premiumAmount;
	private String refundAmount;
	
	public String getServicingTeam() {
		return servicingTeam;
	}
	public void setServicingTeam(String servicingTeam) {
		this.servicingTeam = servicingTeam;
	}
	public String getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}
	public void setProofOfCoverageRid(String proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}
	public String getLoanNumber() {
		return loanNumber;
	}
	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	public String getBorrowerName() {
		return borrowerName;
	}
	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}
	public String getBorrowerMailingAddressStreet() {
		return borrowerMailingAddressStreet;
	}
	public void setBorrowerMailingAddressStreet(String borrowerMailingAddressStreet) {
		this.borrowerMailingAddressStreet = borrowerMailingAddressStreet;
	}
	public String getBorrowerMailingAddressCity() {
		return borrowerMailingAddressCity;
	}
	public void setBorrowerMailingAddressCity(String borrowerMailingAddressCity) {
		this.borrowerMailingAddressCity = borrowerMailingAddressCity;
	}
	public String getBorrowerMailingAddressState() {
		return borrowerMailingAddressState;
	}
	public void setBorrowerMailingAddressState(String borrowerMailingAddressState) {
		this.borrowerMailingAddressState = borrowerMailingAddressState;
	}
	public String getBorrowerMailingAddressZip() {
		return borrowerMailingAddressZip;
	}
	public void setBorrowerMailingAddressZip(String borrowerMailingAddressZip) {
		this.borrowerMailingAddressZip = borrowerMailingAddressZip;
	}
	public String getAddlBorrowersAndOwners() {
		return addlBorrowersAndOwners;
	}
	public void setAddlBorrowersAndOwners(String addlBorrowersAndOwners) {
		this.addlBorrowersAndOwners = addlBorrowersAndOwners;
	}
	public String getPropertyAddress() {
		return propertyAddress;
	}
	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getPropertyUnitBldg() {
		return propertyUnitBldg;
	}
	public void setPropertyUnitBldg(String propertyUnitBldg) {
		this.propertyUnitBldg = propertyUnitBldg;
	}
	public String getPropertyCity() {
		return propertyCity;
	}
	public void setPropertyCity(String propertyCity) {
		this.propertyCity = propertyCity;
	}
	public String getPropertyState() {
		return propertyState;
	}
	public void setPropertyState(String propertyState) {
		this.propertyState = propertyState;
	}
	public String getPropertyZipCode() {
		return propertyZipCode;
	}
	public void setPropertyZipCode(String propertyZipCode) {
		this.propertyZipCode = propertyZipCode;
	}
	public String getFloodZone() {
		return floodZone;
	}
	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Date getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	public Date getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}
	public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}
	public String getValueBasedOn() {
		return valueBasedOn;
	}
	public void setValueBasedOn(String valueBasedOn) {
		this.valueBasedOn = valueBasedOn;
	}
	public String getBuildingCoverageAmount() {
		return buildingCoverageAmount;
	}
	public void setBuildingCoverageAmount(String buildingCoverageAmount) {
		this.buildingCoverageAmount = buildingCoverageAmount;
	}
	public String getContentsCoverageAmount() {
		return contentsCoverageAmount;
	}
	public void setContentsCoverageAmount(String contentsCoverageAmount) {
		this.contentsCoverageAmount = contentsCoverageAmount;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	@Override
	public int compareTo(AlthansLPRequestRow other) {
		int result = loanNumber.compareTo(other.loanNumber);
		if (result != 0)
			return result;

		result = propertyAddress.compareTo(other.propertyAddress);
		if (result != 0)
			return result;

		return Long.compare(Long.parseLong(proofOfCoverageRid), Long.parseLong(other.proofOfCoverageRid));
	}
	public String getBusinessCoverageAmount() {
		return businessCoverageAmount;
	}
	public void setBusinessCoverageAmount(String businessCoverageAmount) {
		this.businessCoverageAmount = businessCoverageAmount;
	}
	
}
