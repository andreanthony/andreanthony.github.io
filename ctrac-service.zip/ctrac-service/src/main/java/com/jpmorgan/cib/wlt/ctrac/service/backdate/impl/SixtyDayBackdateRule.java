package com.jpmorgan.cib.wlt.ctrac.service.backdate.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Duration;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.service.backdate.BankPortionRule;

@Component
public class SixtyDayBackdateRule implements BankPortionRule {

	private static final Logger logger = Logger.getLogger(SixtyDayBackdateRule.class); 

	private static final BigDecimal DEFAULT_BANK_PREMIUM_AMOUNT = BigDecimal.ZERO.setScale(2);
	private static final int BACKDATE_LIMIT = 60;
	
	@Override
	public BigDecimal calculateBankPremiumAmount(Date effectiveDate, Date expirationDate, BigDecimal totalPremiumAmount, Date disbursementDate) {
		BigDecimal bankPremiumAmount = DEFAULT_BANK_PREMIUM_AMOUNT;
		
		int policyLength = calculateTotalPremiumPeriod(effectiveDate, expirationDate);
		if (policyLength == 0) {
			return bankPremiumAmount;
		}
		
		int backdate = calculateBankPremiumDays(effectiveDate, expirationDate, disbursementDate);
		if (backdate > 0) {
			BigDecimal bankPercentage = BigDecimal.valueOf(backdate * 1.0 / policyLength);
			bankPremiumAmount = totalPremiumAmount.multiply(bankPercentage).setScale(2, RoundingMode.HALF_UP);
			logger.debug("backdated=" + backdate + " days, bank portion=" + bankPremiumAmount);
		}
		
		return bankPremiumAmount;
	}
	
	@Override
	public int calculateTotalPremiumPeriod(Date effectiveDate, Date expirationDate) {
		logger.debug("calculateTotalPremiumPeriod between " + effectiveDate + " and " + expirationDate);
		return getDifferenceBetweenTwoDates(effectiveDate, expirationDate);
	}
	
	@Override
	public int calculateBankPremiumDays(Date effectiveDate, Date expirationDate, Date disbursementDate) {
		logger.debug("calculatePremiumDays between " + effectiveDate + " and " + disbursementDate);
		if (disbursementDate == null) {
			return 0;
		}
		int policyLength = calculateTotalPremiumPeriod(effectiveDate, expirationDate);
		int backdays = Math.max(getDifferenceBetweenTwoDates(effectiveDate, disbursementDate) - BACKDATE_LIMIT, 0);
		return(Math.min(backdays, policyLength));
	}
	
	private int getDifferenceBetweenTwoDates(Date date1, Date date2) {
		DateTime dateTime1 = new DateTime(date1).withZoneRetainFields(DateTimeZone.UTC).withTimeAtStartOfDay();
		DateTime dateTime2 = new DateTime(date2).withZoneRetainFields(DateTimeZone.UTC).withTimeAtStartOfDay();
		long diff = new Duration(dateTime1, dateTime2).getStandardDays();
		if (diff < 0) {
			throw new RuntimeException("calculation appears negative");
		}
		if (diff > Integer.MAX_VALUE) {
			throw new RuntimeException("calculation exceed max integer value");
		}
		return (int) diff;
	}

	@Override
	public BigDecimal calculateBankRefundAmount(BigDecimal borrowerPremiumAmount, BigDecimal totalRefundAmount) {
		if(borrowerPremiumAmount == null) {
			borrowerPremiumAmount =  BigDecimal.ZERO;
		}
		if(totalRefundAmount == null) {
			totalRefundAmount =  BigDecimal.ZERO;
		}
		return totalRefundAmount.subtract(borrowerPremiumAmount).setScale(2, RoundingMode.HALF_UP).max(DEFAULT_BANK_PREMIUM_AMOUNT);
	}

}
