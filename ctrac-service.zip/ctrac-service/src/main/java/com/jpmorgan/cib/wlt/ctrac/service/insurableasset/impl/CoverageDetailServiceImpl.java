package com.jpmorgan.cib.wlt.ctrac.service.insurableasset.impl;

import java.util.Date;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Hold;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.HoldRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.HoldDTO;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CoverageDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CoverageDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.CoverageDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.CoverageDetailService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;

@Service
public class CoverageDetailServiceImpl implements CoverageDetailService {

    @Autowired private CtracObjectMapper ctracObjectMapper;
    @Autowired CoverageDetailsRepository  coverageDetailsRepository;
    @Autowired private AuditInformationService auditInformationService;
    @Autowired private HoldRepository holdRepository;


	private static final Logger logger = Logger.getLogger(CoverageDetailServiceImpl.class);

	@Override
	@Transactional
	public void saveCoverageDetails(CoverageDetailsDTO coverageDetailsDTO) {
		if(!coverageDetailsDTO.hasChanged()){
	 		return;
		}
        final HoldDTO holdDTO = coverageDetailsDTO.getHoldDTO();
        if(holdDTO != null && !holdDTO.isRequired() && holdDTO.getParentHold() == null) {
            coverageDetailsDTO.setHoldDTO(null);
        }
        CoverageDetails coverageDetails;
        if(coverageDetailsDTO.getRid() == null){
			coverageDetails = new CoverageDetails();
			//In case this is a new Coverage Details With existing hold, Load existing Hold from DB to set on Coverage Details Hibernate Object
			if(holdDTO != null && holdDTO.getRid() != null){
				Hold holdDbObject = holdRepository.findOne(holdDTO.getRid());
				if(holdDbObject != null){
					coverageDetails.setHold(holdDbObject);
				}
			}
		}else{
			coverageDetails = coverageDetailsRepository.findOne(coverageDetailsDTO.getRid());
		}
		ctracObjectMapper.map(coverageDetailsDTO, coverageDetails);
		if (holdDTO != null && holdDTO.hasChanged() && coverageDetails.getHold() != null) {
		    if(holdDTO.isNewVerifiedHold()) {
                coverageDetails.getHold().setVerifiedBy(auditInformationService.getLoggedInUserSid());
                coverageDetails.getHold().setVerifiedDate(new Date());
            }
            auditInformationService.updateAuditInfo(coverageDetails.getHold());
		}
		coverageDetailsRepository.saveAndFlush(coverageDetails);
		ctracObjectMapper.map(coverageDetails, coverageDetailsDTO);
		coverageDetailsDTO.refreshAuditUpdate(coverageDetails);
	}

    @Override
	@Transactional
	public void saveCoverageDetails(List<CoverageDetailsDTO> coverageDetailsDTOList) {
		for (CoverageDetailsDTO coverageDetail : coverageDetailsDTOList) {
			saveCoverageDetails(coverageDetail);
		}
	}

	@Override
	@Transactional
	public void deleteCoverageDetails(CoverageDetailsDTO coverageDetailsDTO) {
		if (coverageDetailsDTO.getRid() != null) {
			coverageDetailsRepository.delete(coverageDetailsDTO.getRid());
		}
	}
	
	@Override
	@Transactional
	public void deleteCoverageDetails(List<CoverageDetailsDTO> coverageDetailsDTOs) {
		for (CoverageDetailsDTO coverageDetail : coverageDetailsDTOs) {
			deleteCoverageDetails(coverageDetail);
		}
		coverageDetailsDTOs.clear();
	}




}
