package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import org.apache.commons.lang.StringUtils;

import javax.validation.Valid;

public class ContactDetailDto extends BaseDto implements Cloneable {

	private static final long serialVersionUID = 1L;

	private Long rid;

	@NoInvalidCharacters
	private String phoneNumber;

	@NoInvalidCharacters
	private String emailAddress;
	
	private String faxNumber;
	
	@Valid
	private AddressDto address;

	private ContactDetailDto loadTimeValue;
	
	public ContactDetailDto(){
		address = new AddressDto();
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Long getRid() {
		return rid;
	}

	public AddressDto getAddress() {
		return address;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public void ensureAddressFieldsExist() {
    	if (address == null) {
            address = new AddressDto();
        }
	}
	
	public boolean hasChanged(){
		
		if(this.loadTimeValue ==null || this.getRid()==null){
			return true;
		}
		return !deepEquals( this.loadTimeValue );
	}
	
	public void saveACopy () {
		if(this.getAddress()!=null){
			this.getAddress().saveACopy();
		}
		try {
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException swallow) {
		} 
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ContactDetailDto other = (ContactDetailDto) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}
	
	private boolean deepEquals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ContactDetailDto other = (ContactDetailDto) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		}  else if (address.hasChanged() || !address.equals(other.address))
			return false;
		if (StringUtils.isEmpty(emailAddress)) {
			if (StringUtils.isNotEmpty(other.emailAddress))
				return false;
		} else if (!emailAddress.equals(other.emailAddress))
			return false;
		if (StringUtils.isEmpty(phoneNumber)) {
			if (StringUtils.isNotEmpty(other.phoneNumber))
				return false;
		} else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		if (StringUtils.isEmpty(faxNumber)) {
			if (StringUtils.isNotEmpty(other.faxNumber))
				return false;
		} else if (!faxNumber.equals(other.faxNumber))
			return false;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}
	
	@Override
	protected ContactDetailDto clone() throws CloneNotSupportedException {
		return (ContactDetailDto) super.clone();
	}
	
}
