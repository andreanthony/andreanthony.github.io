package com.jpmorgan.cib.wlt.ctrac.service.datamover.impl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataProcessor;



/**
 * NotInFilterProcessor will return subset of records that are passing the NotIn check for the field represented by 
 * sourceFieldName by comparing it against each targetValue in Set<Object> targetValues.
 * @author n446693
 *
 */
public class NotInFilterProcessor implements DataProcessor {
	String sourceFieldName;
	Set<Object> targetValues;
	/**
	 * NotInFilterProcessor will return subset of records that are passing the NotIn check for the field represented by 
	 * sourceFieldName by comparing it against each targetValue in Set<Object> targetValues.
	 * @author n446693
	 *
	 */
	public NotInFilterProcessor(String sourceFieldName, Set<Object> targetValues) {
		super();
		this.sourceFieldName = sourceFieldName;
		this.targetValues = targetValues;
	}
	

	@Override
	public<Source> List<Source> apply(List<Source> sourceDataList)
	{
		List<Source> sourceDataToMove = new ArrayList<Source>();
		for(Source sourceData : sourceDataList){
			applyNotInFilter(sourceDataToMove,sourceData);
		}
		return sourceDataToMove;
	}

	private <Source> void applyNotInFilter(List<Source> sourceDataToMove, Source sourceData) {			
		try {
			Field sourceField = sourceData.getClass().getDeclaredField(sourceFieldName);
			sourceField.setAccessible(true);
			Object sourceFieldValue = sourceField.get(sourceData);
			boolean notInTargetValues = true;
			for(Object targetValue : targetValues){
				if(targetValue.equals(sourceFieldValue)){
					notInTargetValues = false;
				}
			}	
			if(notInTargetValues){
				sourceDataToMove.add(sourceData);
			}
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
