package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public enum BorrowerInsuranceReviewAttribute {
	
	EVIDENCE_OF_INSURANCE_TYPE("Evidence of Ins. Type", "select", true, false),
	PROOF_OF_PAYMENT("Proof of Payment", "select", true, false),
	COVERAGE_TYPE("Coverage Type", "select", false, true),
	CONDO_ASSN_POLICY("Condo Assn. Policy", "radio", true, false),
	FLOOD_COVERAGE_INCLUDED("Flood Coverage Included", "radio", true, false),
	POLICY_NUMBER("Policy Number", "text", true, false),
	EFFECTIVE_DATE("Effective Date", "date", true, false),
	EXPIRATION_DATE("Expiration Date", "date", true, false),
	INSURED_NAME("Insured Name", "text", true, true),
	PROPERTY_ADDRESS("Property Address", "text", false, true),
	CITY_STATE_ZIP("City/State/Zip", "cityStateZip", false, true),
	INDIVIDUAL_CONDO_COVERED("Individual Condo Unit #(s) Covered by Policy", "text", true, true),
	FLOOD_ZONE("Flood Zone", "floodZone", true, false),
	COVERS_RISK_OF_FLOOD("Private Policy - Covers All Risk of Flood", "radio", true, false),
	TOTAL_NUMBER_OF_CONDOS_COVERED("Total # of Condo Units Covered by Policy", "text", true, false),
	JPM_MORTGAGEE_PAYEE("JPM Listed as Mortgagee Payee", "radio", true, false),
	JPM_LENDER_LOSS_PAYEE("JPM Listed as Lender Loss Payee", "radio", true, false),
	JPM_LIEN_POSITION("JPM Lien Position", "select", true, true);
	
	private BorrowerInsuranceReviewAttribute(String displayName, String fieldType, boolean generalRequirement, boolean userDecision) {
		this.displayName = displayName;
		this.fieldType = fieldType;
		this.generalRequirement = generalRequirement;
		this.userDecision = userDecision;
	}
	
	private final String displayName;
	private final boolean generalRequirement;
	private final boolean userDecision;
	private final String fieldType;
	
	private static Map<BorrowerInsuranceReviewAttribute, String> lookUpCodeSets;
	static {
        Map<BorrowerInsuranceReviewAttribute, String> aMap = new HashMap<BorrowerInsuranceReviewAttribute, String>();
        aMap.put(EVIDENCE_OF_INSURANCE_TYPE, "BRW_INS_REVIEW_EVIDENCE_OF_INSURANCE");
        aMap.put(PROOF_OF_PAYMENT, "BRW_INS_REVIEW_PROOF_OF_PAYMENT");
        aMap.put(COVERAGE_TYPE, "BRW_INS_REVIEW_COVERAGE_TYPE");
        aMap.put(CITY_STATE_ZIP, "STATE_CODES");
        aMap.put(JPM_LIEN_POSITION, "BRW_INS_REVIEW_JPM_LIEN_POSITION");
        lookUpCodeSets = Collections.unmodifiableMap(aMap);
    }
	
	public String getDisplayName() {
		return displayName;
	}

	public String getFieldType() {
		return fieldType;
	}

	public boolean isGeneralRequirement() {
		return generalRequirement;
	}

	public boolean isUserDecision() {
		return userDecision;
	}
	
	public static String getLookUpCodeSet(BorrowerInsuranceReviewAttribute attribute) {
		return lookUpCodeSets.get(attribute);
	}

}
