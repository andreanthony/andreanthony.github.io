package com.jpmorgan.cib.wlt.ctrac.service.dto.datatable;


import java.util.List;

public class DataTablesResponse<T> {

	/*The draw counter that this object is a response to - from the draw parameter sent as part of the data request
	 * 
	 */
	Integer draw;
	
	
	/*
	 * Total records, before filtering (i.e. the total number of records in the database)
	 */	
	Long recordsTotal;

	/*
	 * Total records, after filtering (i.e. the total number of records after filtering has been applied - not just the number of records being returned for this page of data).
	 */
	Long recordsFiltered;
	
	/*The data to be displayed in the table. This is an array of data source objects, one for each row, which will be used by DataTables.
	 * 
	 */
	List<? super T> data;
	
	
	@Deprecated
	public DataTablesResponse() {
	}

	
	public DataTablesResponse(DataTablesRequest dataTablesRequest, List<? super T> data) {
		this.draw =dataTablesRequest.getDraw();
		this.setData(data);
		this.recordsTotal = dataTablesRequest.getLength(); //TODO must normally be equal to the number before filtering
		this.recordsFiltered = dataTablesRequest.getLength();
	}
	
	
	
	public Integer getDraw() {
		return draw;
	}
	public void setDraw(Integer draw) {
		this.draw = draw;
	}
	public Long getRecordsTotal() {
		return recordsTotal;
	}
	
	public void setRecordsTotal(Long recordsTotal) {
		this.recordsTotal = recordsTotal;
	}

	
	public Long getRecordsFiltered() {
		return recordsFiltered;
	}

	public void setRecordsFiltered(Long recordsFiltered) {
		this.recordsFiltered = recordsFiltered;
	}

	public List<? super T> getData() {
		return data;
	}

	public void setData(List<? super T> data) {
		this.data = data;
	}
	
    /*
     * enabling method chaining
     */
	public DataTablesResponse<T> draw(Integer draw) {
		this.draw = draw;
		return this;
	}
	public DataTablesResponse<T> recordsTotal(Long recordsTotal) {
		this.recordsTotal = recordsTotal;
		return this;
	}
	
	public DataTablesResponse<T> recordsFiltered(Long recordsFiltered) {
		this.recordsFiltered = recordsFiltered;
		return this;
	}
	public DataTablesResponse<T> data(List<T> data) {
		setData(data);
		return this;
	}
	
}
