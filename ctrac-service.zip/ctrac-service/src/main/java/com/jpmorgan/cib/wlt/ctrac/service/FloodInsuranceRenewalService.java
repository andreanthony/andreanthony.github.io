package com.jpmorgan.cib.wlt.ctrac.service;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.ReminderType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.InsuranceRenewalItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ContactAgentDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VerifyPreRenewalLetterDto;

public interface FloodInsuranceRenewalService {

	ContactAgentDto prepareContactAgentDto(TMParams tmParams);

	void processContactAgentDto(final ContactAgentDto contactAgentDto);

	ReminderType getReminderType(ProofOfCoverageDTO proofOfCoverageDto);

	VerifyPreRenewalLetterDto prepareVerifyPreRenewalLetterDto(TMParams tmParams);

	void processVerifyPreRenewalLetterDto(final VerifyPreRenewalLetterDto verifyPreRenewalLetterDto) throws Exception;

	void initBorrowerRenewalWorkFlow(ProofOfCoverage proofOfCoverage);

	InsuranceRenewalItem createInsuranceRenewalItem(final ProofOfCoverage proofOfCoverage, final Collateral collateral);

	PerfectionTask initSendPreRenewalLetter(final ProofOfCoverage proofOfCoverage, final Collateral collateral);

    boolean isRenewalPolicyAccepted(ProofOfCoverage proofOfCoverage);

    void prepareAndSendMarketRenewalEmail(final InsuranceRenewalItem insuranceRenewalItem);
}
