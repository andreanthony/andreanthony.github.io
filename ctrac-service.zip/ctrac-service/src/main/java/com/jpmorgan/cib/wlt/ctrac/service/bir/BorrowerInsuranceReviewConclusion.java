package com.jpmorgan.cib.wlt.ctrac.service.bir;

public enum BorrowerInsuranceReviewConclusion {
	
	NONE,
	ACTION_REQUIRED,
	ACCEPTABLE,
	REJECTED;
	
}
