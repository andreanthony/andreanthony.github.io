package com.jpmorgan.cib.wlt.ctrac.service.bir.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AgentResponseItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRExceptionEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewRule;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.CollateralMainDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.PrimaryLoanBorrowerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.AbstractExceptionEmailState;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class BIRExceptionEmailServiceImpl implements BIRExceptionEmailService {

	private static final Logger logger = Logger.getLogger(BIRExceptionEmailServiceImpl.class);
	
	@Autowired private CalendarDayUtil calendarDayUtil;
	
	@Autowired private ViewDataRetrievalService viewDataRetrievalService;
    @Autowired private CollateralManagementService collateralManagementService;

	@Override
	@Transactional(readOnly = true)
	public BIRExceptionEmailDTO populateExceptionEmailData(
			WorkItem agentResponseItem, TaskState currentTaskState, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		logger.debug("populateExceptionEmailData::BEGIN");
		int i = 2000;
		AbstractExceptionEmailState exceptionEmailState = getAbstractExceptionEmailState(currentTaskState);
		agentResponseItem = CtracBaseEntity.deproxy(agentResponseItem, WorkItem.class);
		if (!(agentResponseItem instanceof AgentResponseItem)) {
			throw new RuntimeException("workItem not AgentResponseItem for populateExceptionEmailData: " + agentResponseItem.getRid());
		}
		BIRExceptionEmailDTO exceptionEmailData = prepareEmailExceptionData(
				(AgentResponseItem) agentResponseItem, exceptionEmailState, borrowerInsuranceReviewData);
		logger.debug("populateExceptionEmailData::END");
		return exceptionEmailData;
	}

	@Override
	public BIRAcceptedPolicyEmailDTO populateAcceptedPolicyWithNoExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		logger.debug("populateAcceptedPolicyWithNoExceptionEmailData::BEGIN");
		BIRAcceptedPolicyEmailDTO birAcceptedPolicyEmailDTO = prepareEmailPolicyAcceptedWithNoExceptionData(borrowerInsuranceReviewData);
		logger.debug("populateAcceptedPolicyWithNoExceptionEmailData::END");
		return birAcceptedPolicyEmailDTO;
	}
	
	private AbstractExceptionEmailState getAbstractExceptionEmailState(TaskState currentTaskState) {
		if (currentTaskState == null) {
			throw new RuntimeException("null exceptionEmailTask for getAbstractExceptionEmailState");
		}
		if (currentTaskState == null || !(currentTaskState instanceof AbstractExceptionEmailState)) {
			throw new RuntimeException("invalid workflowStep for getAbstractExceptionEmailState: " + currentTaskState.getName());
		}
		return (AbstractExceptionEmailState) currentTaskState;
	}
	
	private BIRExceptionEmailDTO prepareEmailExceptionData(AgentResponseItem agentResponseItem,
			AbstractExceptionEmailState exceptionEmailState, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRExceptionEmailDTO exceptionEmailData = new BIRExceptionEmailDTO();
		Long collateralRid = agentResponseItem.getCollateralRid();
		if(collateralRid == null){
			collateralRid = borrowerInsuranceReviewData.getCollateralRid();
		}	
		
		if(collateralRid != null){
			CollateralDto collateralDto = collateralManagementService.getCollateralDto(collateralRid);
			exceptionEmailData.setLoanData(collateralDto.getLoansData());
		}
		
		if(collateralRid == null && borrowerInsuranceReviewData.getCollateralDetailsMap().keySet() != null){
			 List<LoanData> loansData = new  ArrayList<LoanData>();
			for (Long colRid : borrowerInsuranceReviewData.getCollateralDetailsMap().keySet()) {
				CollateralDto collateralDto = collateralManagementService.getCollateralDto(colRid);
				loansData.addAll(collateralDto.getLoansData());
				//Pick a collateral rid
				collateralRid = colRid;
			}				
			exceptionEmailData.setLoanData(loansData);
		}	
		
		exceptionEmailData.setEmailSequence(exceptionEmailState.getEmailSequence());
		exceptionEmailData.setCurrentReferenceDate(
				DateConverter.convert(calendarDayUtil.getCurrentReferenceDate()));
		exceptionEmailData.setCollateralRid(collateralRid);
		ProofOfCoverageDTO proofOfCoverageData = borrowerInsuranceReviewData.getProofOfCoverageData();
		exceptionEmailData.setInsuredName(proofOfCoverageData.getInsuredName());
		exceptionEmailData.setPolicyNumber(proofOfCoverageData.getPolicyNumber());
		exceptionEmailData.setProofOfPaymentDescription(borrowerInsuranceReviewData.getProofOfPaymentDescription());
		exceptionEmailData.setEffectiveDate(proofOfCoverageData.getEffectiveDate());
		exceptionEmailData.setExpirationDate(proofOfCoverageData.getExpirationDate());
		exceptionEmailData.setCollateralIDs(populateCollateralIDs(borrowerInsuranceReviewData.getCollateralDetailsMap()));		
		exceptionEmailData.setInitialZoneVarianceDate(DateConverter.convert(agentResponseItem.getItemCreatedDate()));
		exceptionEmailData.setPolicyAmount("TODO");
		if(collateralRid!=null){
			PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto =
					viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(collateralRid);
			if(primaryLoanBorrowerViewDto!=null){ 
				exceptionEmailData.setLoanNumber(primaryLoanBorrowerViewDto.getLoanNumber());
				exceptionEmailData.setBorrowerName(primaryLoanBorrowerViewDto.getBorrowerNameIncludingOwners());
			}
			
			CollateralMainDetailsViewDto collateralMainDetailsViewDto=viewDataRetrievalService.getCollateralMainDetails(collateralRid);
			if(collateralMainDetailsViewDto!=null){
				exceptionEmailData.setPolicyAddress(populatePropertyAddress(collateralMainDetailsViewDto));
			}
		}
		// Loop through conclusions and add data to the BIRExceptionEmailDTO
		// TODO: create a method to only return Action Required
		Set<BorrowerInsuranceReviewRule> exceptionEmailRules = exceptionEmailState.getExceptionEmailRules();
		Set<BorrowerInsuranceReviewRule> rejectionEmailRules = exceptionEmailState.getRejectionEmailRules();
		List<BIRRuleConclusionDTO> ruleConclusions = borrowerInsuranceReviewData.getAllBIRRuleConclusions();
		for (BIRRuleConclusionDTO ruleConclusion : ruleConclusions) {
			BorrowerInsuranceReviewRule birRule = BorrowerInsuranceReviewRule.findByKey(ruleConclusion.getFieldName());
			if (birRule == null) {
				continue;
			}
			if (ruleConclusion.hasException() && exceptionEmailRules.contains(birRule)) {
				if (!birRule.isCollateralLevel()) {
					exceptionEmailData.setNonRejectReasons(true);
				}
				birRule.populateExceptionEmailData(borrowerInsuranceReviewData, exceptionEmailData);
			}else if (ruleConclusion.isReasonForReject() && rejectionEmailRules.contains(birRule)) {
				birRule.populateExceptionEmailData(borrowerInsuranceReviewData, exceptionEmailData);
			}
		}
		if (exceptionEmailData.getCollateralExceptionDataMap().size() > 0) {
			populatePropertyAddressForCollateral(borrowerInsuranceReviewData,exceptionEmailData);
		}
		return exceptionEmailData;
	}
	
	private boolean loanDataExists(ArrayList<LoanData> loanBorrowerList, String checkLoanNumber) {
		boolean retValue = false;
		
		for (LoanData ld: loanBorrowerList) {
			if (ld.getLoanNumber().equals(checkLoanNumber)) {
				retValue = true;
				break;
			}
		}
		
		return retValue;
	}
	
	private BIRAcceptedPolicyEmailDTO prepareEmailPolicyAcceptedWithNoExceptionData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRAcceptedPolicyEmailDTO birAcceptedPolicyEmailDTO = new BIRAcceptedPolicyEmailDTO();
				
		ProofOfCoverageDTO proofOfCoverageData = borrowerInsuranceReviewData.getProofOfCoverageData();
		birAcceptedPolicyEmailDTO.setInsuredName(proofOfCoverageData.getInsuredName());
		birAcceptedPolicyEmailDTO.setPolicyNumber(proofOfCoverageData.getPolicyNumber());
		birAcceptedPolicyEmailDTO.setExpirationDate(proofOfCoverageData.getExpirationDate());
		
		Iterator<BIRCollateralDetailsDTO> collateralDetailsIter = 
		borrowerInsuranceReviewData.getCollateralDetailsMap().values().iterator();
		
		ArrayList<LoanData> loanBorrowerList = new ArrayList<LoanData>();
		ArrayList<CollateralDto> collateralList = new ArrayList<CollateralDto>();
		StringBuilder sb = new StringBuilder();
		while (collateralDetailsIter.hasNext()) {
			BIRCollateralDetailsDTO collateralDetails = collateralDetailsIter.next();
			Long collateralRid = collateralDetails.getCollateralRid();
			
			CollateralDto collateralDto = collateralManagementService.getCollateralDto(collateralRid);
			
			if (collateralDto.getAddress().getStreetAddress() == null) {
				collateralDto.getAddress().setStreetAddress("");
			}
			
			if (collateralDto.getAddress().getUnitOrBuilding() == null) {
				collateralDto.getAddress().setUnitOrBuilding("");
			}
			
			if (collateralDto.getAddress().getCity() == null) {
				collateralDto.getAddress().setCity("");
			}
			
			if (collateralDto.getAddress().getState() == null) {
				collateralDto.getAddress().setState("");
			}
			
			if (collateralDto.getAddress().getZipCode() == null) {
				collateralDto.getAddress().setZipCode("");
			}
			sb.append(collateralRid.toString());
			if (collateralDetailsIter.hasNext()) {
				sb.append(", ");
			}
			collateralList.add(collateralDto);
			
			Iterator<LoanData> iter = collateralDto.getLoansData().iterator();
	        
			while (iter.hasNext()) {
				LoanData loanData = iter.next();

				if (loanData.getStatus() != null && loanData.getStatus().isActive() && 
					loanData.getPrimaryFlag() != null && loanData.getPrimaryFlag().equalsIgnoreCase("yes")) {
					if (!loanDataExists(loanBorrowerList, loanData.getLoanNumber())) {
						if (loanData.getPrimaryBorrower() == null || loanData.getPrimaryBorrower().getBorrowerName() == null) {
							loanData.getPrimaryBorrower().setBorrowerName("");
						}
						loanBorrowerList.add(loanData);
					}
	            }
			}
		}
		birAcceptedPolicyEmailDTO.setCollateralIds(sb.toString());
		birAcceptedPolicyEmailDTO.setLoanBorrowerList(loanBorrowerList);
		birAcceptedPolicyEmailDTO.setCollateralList(collateralList);
		
		return birAcceptedPolicyEmailDTO;
	}

	private void populatePropertyAddressForCollateral(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData){
		Iterator<BIRCollateralDetailsDTO> collateralDetailsIter = 
				borrowerInsuranceReviewData.getCollateralDetailsMap().values().iterator();
		while (collateralDetailsIter.hasNext()) {
			BIRCollateralDetailsDTO collateralDetails = collateralDetailsIter.next();
			BIRExceptionEmailCollateralDTO exceptionEmailCollateralData =
					exceptionEmailData.getCollateralExceptionDataMap().get(collateralDetails.getCollateralRid());
			if (exceptionEmailCollateralData != null) {
				exceptionEmailCollateralData.setPropertyAddress(
						collateralDetails.getCollateralAddressData().getFormattedFullAddress());
			}		
		}
	}
	
	private AddressDto populatePropertyAddress(CollateralMainDetailsViewDto collateralMainDetailsViewDto){
		AddressDto policyAddress=new AddressDto();
		policyAddress.setStreetAddress(collateralMainDetailsViewDto.getCollateralAddress());
		policyAddress.setCity(collateralMainDetailsViewDto.getCollateralCity());
		policyAddress.setState(collateralMainDetailsViewDto.getCollateralState());
		policyAddress.setZipCode(collateralMainDetailsViewDto.getCollateralZipCode());
		return policyAddress;
	}
	
	private String populateCollateralIDs(Map<Long,BIRCollateralDetailsDTO> collateralDetailsMap){
		StringBuilder sb = new StringBuilder();
		Iterator<BIRCollateralDetailsDTO> collateralDetails = collateralDetailsMap.values().iterator();
		while (collateralDetails.hasNext()) {
			BIRCollateralDetailsDTO birCollateralDetailsData = collateralDetails.next();
			if (birCollateralDetailsData.getCollateralRid() != null) {
				sb.append(birCollateralDetailsData.getCollateralRid().toString());
			}
			if (collateralDetails.hasNext()) {
				sb.append(", ");
			}
		}
		return sb.toString();
	}

}
