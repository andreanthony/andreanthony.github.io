package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;

public class PIARequestData extends CtracBaseHelperData {

	private static final long serialVersionUID = 1L;	
	
	private String policyExpiryDate;


	private Long agentResponseId;
	
	@NoInvalidCharacters
	private String tmTaskRererenceId;
	
	private List<LoanData> loanDtoList;
	 
	private ProofOfCoverageDTO proofOfCoverageDto;
	
	private List<CollateralDto> collateralDtoList; 
		 


	public List<LoanData> getLoanDtoList() {
		return loanDtoList;
	}

	public void setLoanDtoList(List<LoanData> loanDtoList) {
		this.loanDtoList = loanDtoList;
	}

	public ProofOfCoverageDTO getProofOfCoverageDto() {
		return proofOfCoverageDto;
	}

	public void setProofOfCoverageDto(ProofOfCoverageDTO proofOfCoverageDto) {
		this.proofOfCoverageDto = proofOfCoverageDto;
	}

	public List<CollateralDto> getCollateralDtoList() {
		return collateralDtoList;
	}

	public void setCollateralDtoList(List<CollateralDto> collateralDtoList) {
		this.collateralDtoList = collateralDtoList;
	}
	
	public String getPolicyExpiryDate() {
		return policyExpiryDate;
	}

	public void setPolicyExpiryDate(String policyExpiryDate) {
		this.policyExpiryDate = policyExpiryDate;
	}

	public String getTmTaskRererenceId() {
		return tmTaskRererenceId;
	}

	public void setTmTaskRererenceId(String tmTaskRererenceId) {
		this.tmTaskRererenceId = tmTaskRererenceId;
	}
	public Long getAgentResponseId() {
		return agentResponseId;
	}

	public void setAgentResponseId(Long agentResponseId) {
		this.agentResponseId = agentResponseId;
	}

}
