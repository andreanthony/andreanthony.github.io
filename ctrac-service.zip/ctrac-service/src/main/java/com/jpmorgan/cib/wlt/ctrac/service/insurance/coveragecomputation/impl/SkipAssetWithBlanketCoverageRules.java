package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import java.util.Collection;
import java.util.Date;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;

/**
 * If the insurable asset is covered by some kind of blanket coverage, We won't
 * be able to automatically compute it's coverage requirement; a manual decision
 * will be needed
 */
public class SkipAssetWithBlanketCoverageRules extends InsurableAssetCoverageRule {

	private static final Logger logger = Logger.getLogger(SkipAssetWithBlanketCoverageRules.class);

	public SkipAssetWithBlanketCoverageRules(Collateral collateral, WorkItem triggerWorkItem,
			InsurableAsset insurableAsset, CoverageActionData coverageActionData) {
		super(collateral, triggerWorkItem, insurableAsset, coverageActionData);
	}

	@Override
	public void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult globalResults) {
		logger.info(" Begin : SkipAssetWithBlanketCoverageRules::execute()");
		Collection<ProvidedCoverage> allActiveCoverages = coverageActionData.getAllActiveProvidedCoverages();
		for (ProvidedCoverage activeCoverage : allActiveCoverages) {
			Date dayPriorNextBusDay = coverageActionData.getMaxDateForLetterProcessing();
			ProofOfCoverage proofOfCoverage = activeCoverage.getProofOfCoverage();
			if ("Y".equalsIgnoreCase(activeCoverage.getCoveredByBlanketPolicy()) && proofOfCoverage.isEffectiveOn(dayPriorNextBusDay)) {
				prepareCanceltheInsurableAssetLpPolicies(
						insurableAsset, globalResults, triggerWorkItem, CancellationReason.BORROWER_POLICY_RECEIVED);
				globalResults.setMoreActionsNeeded(false); // nothing more for this insurable asset
				logger.info(" End : SkipAssetWithBlanketCoverageRules::execute() => "
						+ "Asset has a blanket coverage. skipping the next set of rules");
				return;
			}
		}
		logger.info(" End : SkipAssetWithBlanketCoverageRules::execute() => no blanket coverage. proceeding with next rules");
	}

	@Override
	public Integer getPriority() {
		return 18;
	}

}
