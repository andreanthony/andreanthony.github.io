package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import org.apache.commons.lang.builder.EqualsBuilder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class InsurableAssetDTO implements Serializable {

    private static final long serialVersionUID = -2796203553609240783L;

    private Long rid;
    private Long buildingRid;
    private Long collateralRid;
    private String buildingName;
    private String assetType;
    private String floodZone;
    private Integer sortOrder;
    private List<RequiredCoverageDTO> requiredCoverageDTOs = new ArrayList<>();
    private List<ProvidedCoverageDTO> providedCoverageDTOs = new ArrayList<>();

    public InsurableAssetDTO() {
        super();
    }

    public InsurableAssetDTO(InsurableAssetType assetType) {
        super();
        this.assetType = assetType != null ? assetType.name() : null;
    }

	private InsurableAssetDTO loadTimeValue;

    public String getDescription() {
        return buildingName;
    }

    public InsurableAssetType getInsurableAssetType() {
        return InsurableAssetType.findByName(assetType);
    }

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public Long getBuildingRid() {
        return buildingRid;
    }

    public void setBuildingRid(Long buildingRid) {
        this.buildingRid = buildingRid;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    public String getFloodZone() {
        return floodZone;
    }

    public void setFloodZone(String floodZone) {
        this.floodZone = floodZone;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public List<RequiredCoverageDTO> getRequiredCoverageDTOs() {
        return requiredCoverageDTOs;
    }

    public void setRequiredCoverageDTOs(List<RequiredCoverageDTO> requiredCoverageDTOs) {
        this.requiredCoverageDTOs = requiredCoverageDTOs;
    }

    public void addRequiredCoverage(RequiredCoverageDTO requiredCoverageDTO){

    	if(requiredCoverageDTO.getRid()!=null && requiredCoverageDTOs.contains(requiredCoverageDTO)){
    		return;
    	}
    	requiredCoverageDTOs.add(requiredCoverageDTO);

    }

    public List<ProvidedCoverageDTO> getProvidedCoverageDTOs() {
        return providedCoverageDTOs;
    }

    public void setProvidedCoverageDTOs(List<ProvidedCoverageDTO> providedCoverageDTOs) {
        this.providedCoverageDTOs = providedCoverageDTOs;
    }

    public void addProvidedCoverage(ProvidedCoverageDTO providedCoverageDTO){
    	if(providedCoverageDTO.getRid()!=null && providedCoverageDTOs.contains(providedCoverageDTO) ){
    		return;
    	}
    	providedCoverageDTOs.add(providedCoverageDTO);
    }



    public String getPropertyType(){

        String result=null;
        if(this.requiredCoverageDTOs!=null && this.requiredCoverageDTOs.size()>0){

            result =requiredCoverageDTOs.get(0).getPropertyType();
            //Try to get the property type from the latest Fiat; for now, we assume the pending verification has the highest priority
            for( RequiredCoverageDTO requiredCoverage : requiredCoverageDTOs ){
                RequiredCoverageSourceDto covsource = requiredCoverage.getRequiredCoverageSourceDto();
                if(covsource!=null && CoverageRequirementStatus.PENDING_VERIFICATION.name().equals(covsource.getStatus())){
                    return requiredCoverage.getPropertyType();
                }else if(covsource!=null  && CoverageRequirementStatus.VERIFIED.name().equals(covsource.getStatus())){
                    result = requiredCoverage.getPropertyType();
                }
            }
        }
        return result;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InsurableAssetDTO other = (InsurableAssetDTO) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}


	private boolean deepEquals(Object obj) {
        if (obj == null) {
            return false;
        }
		if (obj == this) {
            return true;
        }
		if (obj.getClass() != getClass()) {
            return false;
        }
		InsurableAssetDTO rhs = (InsurableAssetDTO) obj;
		return new EqualsBuilder()
                .appendSuper(super.equals(obj))
                .append(rid, rhs.rid)
                .append(buildingRid, rhs.buildingRid)
                .append(assetType, rhs.assetType)
                .append(floodZone, rhs.floodZone)
                .append(requiredCoverageDTOs, rhs.requiredCoverageDTOs)
                .append(providedCoverageDTOs, rhs.providedCoverageDTOs)
                .isEquals();
	}

	public boolean hasChanged(){

		if(this.loadTimeValue ==null || this.getRid()==null){
			return true;
		}
		return !deepEquals(this.loadTimeValue);
	}

	public void saveACopy () {
		for(RequiredCoverageDTO requiredCoverageDTO:requiredCoverageDTOs){
			requiredCoverageDTO.saveACopy();
		}
		for(ProvidedCoverageDTO providedCoverageDTO :providedCoverageDTOs){
			providedCoverageDTO.saveACopy();
		}
		try {
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException swallow) {
		}
	}

	@Override
	protected InsurableAssetDTO clone() throws CloneNotSupportedException {
		return (InsurableAssetDTO) super.clone();
	}

}
