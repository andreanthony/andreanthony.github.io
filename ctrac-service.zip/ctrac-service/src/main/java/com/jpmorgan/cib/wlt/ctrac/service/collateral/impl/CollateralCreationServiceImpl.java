package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralCreationService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BusinessAssetCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.RealEstateCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CreateNewCollateralRecord;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.store.client.CollateralEventSection;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class CollateralCreationServiceImpl implements CollateralCreationService {

    private final CollateralDetailsStatusService collateralDetailsStatusService;
    private final CollateralManagementService collateralManagementService;
    private final CtracObjectMapper ctracObjectMapper;
    private final PublishEventService publishEventService;

    @Autowired
    public CollateralCreationServiceImpl(CollateralManagementService collateralManagementService,
                                         CtracObjectMapper ctracObjectMapper,
                                         CollateralDetailsStatusService collateralDetailsStatusService,
                                         PublishEventService publishEventService
                                         ) {
        this.collateralDetailsStatusService = collateralDetailsStatusService;
        this.collateralManagementService = collateralManagementService;
        this.ctracObjectMapper = ctracObjectMapper;
        this.publishEventService =publishEventService;
    }


    @Override
    @Transactional
    public CollateralDto createCollateral(CreateNewCollateralRecord createNewCollateralRecord) {
        CollateralDto collateralDto = createCollateralModel(createNewCollateralRecord);
        collateralDetailsStatusService.initAllCollateralSectionsStatus(collateralDto.getRid());
        publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.COLLATERAL_CREATED, CollateralEventSection.COLLATERAL);
        publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.ADDED, CollateralEventSection.LOAN);


        return collateralDto;
    }

    private CollateralDto createCollateralModel(CreateNewCollateralRecord createNewCollateralRecord) {
        // based on the collateral type instantiate the object
        CollateralDto collateralDto;
        String collateralType = createNewCollateralRecord.getCollateralType();
        if(CollateralType.REAL_ESTATE.getCode().equals(collateralType)) {
            collateralDto = ctracObjectMapper.map(createNewCollateralRecord, RealEstateCollateralDto.class);
        } else if (CollateralType.BUSINESS_ASSETS.getCode().equals(collateralType)){
            collateralDto = ctracObjectMapper.map(createNewCollateralRecord, BusinessAssetCollateralDto.class);
        } else {
            throw new CTracApplicationException("E0247", CtracErrorSeverity.APPLICATION);
        }
        collateralDto.setCollateralStatus(CollateralStatus.DRAFT);
        if (collateralDto.getLoansData() != null && !collateralDto.getLoansData().isEmpty()) {
            LoanData loanData = collateralDto.getLoansData().get(0);
            loanData.setPrimaryFlag("Yes");
            loanData.setStatus(LoanStatus.PENDING_VERIFICATION);
        }
        return collateralManagementService.saveCollateral(collateralDto, "");
    }
}
