package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import java.io.Serializable;

public class CompleteLPPolicyReviewData extends FloodInsurancePolicyDto
		implements Serializable {
	
	private static final long serialVersionUID = 8608131299924578007L;
	
	private String borrowerName;
	private String loanNumber;
	private String vendorPaymentReferenceNumber;
	private String policyIssuanceDate;
	private String screenId;
	private String propertyAddress;
	private String cityStateZipcode;
	private Long perfectionTaskId;
	private boolean policyInfoVerified;
	private boolean vendorDocsRetrieved;
	private boolean floodTicklerCreated;	
	private boolean policyVerifiedInImageSystem;
	
	private String policyNumber;
	private String policyEffectiveDate;
	private String policyExpiryDate;
	private String coverageType;
	private String coverageAmount;
	private String floodzone;
	private String wiredDate;
	private String currentDate;
		
	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getVendorPaymentReferenceNumber() {
		return vendorPaymentReferenceNumber;
	}

	public void setVendorPaymentReferenceNumber(
			String vendorPaymentReferenceNumber) {
		this.vendorPaymentReferenceNumber = vendorPaymentReferenceNumber;
	}

	public String getPolicyIssuanceDate() {
		return policyIssuanceDate;
	}

	public void setPolicyIssuanceDate(String policyIssuanceDate) {
		this.policyIssuanceDate = policyIssuanceDate;
	}

	public String getScreenId() {
		return screenId;
	}

	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public void setCityStateZipcode(String cityStateZipcode) {
		this.cityStateZipcode = cityStateZipcode;
	}
	
	public Long getPerfectionTaskId() {
		return perfectionTaskId;
	}

	public void setPerfectionTaskId(Long perfectionTaskId) {
		this.perfectionTaskId = perfectionTaskId;
	}	

	public void setPolicyInfoVerified(boolean policyInfoVerified) {
		this.policyInfoVerified = policyInfoVerified;
	}

	public boolean getVendorDocsRetrieved() {
		return vendorDocsRetrieved;
	}

	public void setVendorDocsRetrieved(boolean vendorDocsRetrieved) {
		this.vendorDocsRetrieved = vendorDocsRetrieved;
	}

	public boolean getFloodTicklerCreated() {
		return floodTicklerCreated;
	}

	public void setFloodTicklerCreated(boolean floodTicklerCreated) {
		this.floodTicklerCreated = floodTicklerCreated;
	}	

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPolicyEffectiveDate() {
		return policyEffectiveDate;
	}

	public void setPolicyEffectiveDate(String policyEffectiveDate) {
		this.policyEffectiveDate = policyEffectiveDate;
	}

	public String getPolicyExpiryDate() {
		return policyExpiryDate;
	}

	public void setPolicyExpiryDate(String policyExpiryDate) {
		this.policyExpiryDate = policyExpiryDate;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(String coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public String getFloodzone() {
		return floodzone;
	}

	public void setFloodzone(String floodzone) {
		this.floodzone = floodzone;
	}
	
	public String getWiredDate() {
		return wiredDate;
	}

	public void setWiredDate(String wiredDate) {
		this.wiredDate = wiredDate;
	}

	public String getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}

	public boolean getPolicyVerifiedInImageSystem() {
		return policyVerifiedInImageSystem;
	}

	public void setPolicyVerifiedInImageSystem(boolean policyVerifiedInImageSystem) {
		this.policyVerifiedInImageSystem = policyVerifiedInImageSystem;
	}	
}
