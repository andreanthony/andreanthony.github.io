package com.jpmorgan.cib.wlt.ctrac.service.dto.datatable;

import java.util.Map;

public class EntityDataTableDtoWrapper {
	private Long entityToKeep;
    private Map<Long, EntityDataTableDto> entitiesMap;
	
	public Map<Long, EntityDataTableDto> getEntitiesMap() {
		return entitiesMap;
	}

	public void setEntitiesMap(Map<Long, EntityDataTableDto> entitiesMap) {
		this.entitiesMap = entitiesMap;
	}

	public Long getEntityToKeep() {
		return entityToKeep;
	}

	public void setEntityToKeep(Long entityToKeep) {
		this.entityToKeep = entityToKeep;
	}

}
