package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.log4j.Logger;

import java.io.Serializable;

public class HoldDTO extends BaseDto implements Serializable, Cloneable {
    private static final long serialVersionUID = 1;
    private static final Logger logger = Logger.getLogger(HoldDTO.class);

    private Long rid;
    private HoldDTO parentHold;
    private String holdType;
    private String startDate;
    private String lpiDate;
    private String holdPeriod;
    private CoverageType coverageType;
    private String holdStatus;
    private boolean required = false;

    private HoldDTO loadTimeValue = null;

    public boolean isEntered() {
        return startDate != null && StringUtils.isNotBlank(holdType) && StringUtils.isNotBlank(holdPeriod);
    }

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public HoldDTO getParentHold() {
        return parentHold;
    }

    public void setParentHold(HoldDTO parentHold) {
        this.parentHold = parentHold;
    }

    public String getHoldType() {
        return holdType;
    }

    public void setHoldType(String type) {
        this.holdType = type;
    }

    public String getHoldPeriod() {
        return holdPeriod;
    }

    public void setHoldPeriod(String period) {
        this.holdPeriod = period;
    }

    public String getLpiDate() {
        return lpiDate;
    }

    public void setLpiDate(String lpiDate) {
        this.lpiDate = lpiDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public CoverageType getCoverageType() {
        return coverageType;
    }

    public HoldDTO setCoverageType(CoverageType coverageType) {
        this.coverageType = coverageType;
        return this;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public HoldDTO copyHoldInfo() {
        HoldDTO cloned = new HoldDTO();
        cloned.setRid(this.rid);
        cloned.setHoldType(this.holdType);
        cloned.setStartDate(this.startDate);
        cloned.setHoldPeriod(this.holdPeriod);
        cloned.setParentHold(this.parentHold);
        return cloned;
    }

    public void saveACopy() {
        try {
            this.loadTimeValue = (HoldDTO) this.clone();
        } catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
        }
    }

    private boolean deepEquals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        HoldDTO rhs = (HoldDTO) obj;
        return new EqualsBuilder()
                .append(parentHold, rhs.parentHold)
                .append(holdType, rhs.holdType)
                .append(startDate, rhs.startDate)
                .append(lpiDate, rhs.lpiDate)
                .append(holdPeriod, rhs.holdPeriod)
                .append(required, rhs.required)
                .isEquals();
    }

    public boolean hasChanged(){
        if (this.loadTimeValue == null && this.getHoldType() == null) {
            return false;
        }
        if (this.loadTimeValue == null && this.getHoldType() != null) {
            return true;
        }
        return !deepEquals(this.loadTimeValue);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        HoldDTO rhs = (HoldDTO) obj;
        return new EqualsBuilder()
                .appendSuper(super.equals(obj))
                .append(parentHold, rhs.parentHold)
                .append(holdType, rhs.holdType)
                .append(startDate, rhs.startDate)
                .append(lpiDate, rhs.lpiDate)
                .append(holdPeriod, rhs.holdPeriod)
                .isEquals();
    }

    public boolean isNewVerifiedHold() {
        return parentHold == null && !StringUtils.isEmpty(startDate) && StringUtils.isEmpty(lpiDate) &&
                 VerificationStatus.VERIFIED.name().equals(holdStatus);
    }

    public boolean hasVerifiedLpiDate() {
        return !StringUtils.isEmpty(lpiDate) && VerificationStatus.VERIFIED.name().equals(holdStatus);
    }

    public String getHoldStatus() {
        return this.holdStatus;
    }
    public void setHoldStatus(String holdStatus) {
        this.holdStatus = holdStatus;
    }

}
