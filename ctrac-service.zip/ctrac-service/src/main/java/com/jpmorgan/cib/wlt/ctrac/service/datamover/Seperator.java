package com.jpmorgan.cib.wlt.ctrac.service.datamover;

public enum Seperator {
	
	COMMA(","),
	SPACE(" ");
	
	private String code;
	
	Seperator(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return code;
	}
}
