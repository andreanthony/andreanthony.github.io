package com.jpmorgan.cib.wlt.ctrac.service.dto.letters;

import java.math.BigDecimal;
import java.util.*;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CombinableLetterParam;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.letters.PendingPaymentChangeBuilder;
import com.jpmorgan.cib.wlt.ctrac.service.letters.templates.AbstractLetterTemplate;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.SerializationUtils;
import org.joda.time.DateTime;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.letters.LetterFileXml.Letters.Letter;
import com.jpmorgan.cib.wlt.ctrac.service.dto.letters.LetterFileXml.Letters.Letter.FileAttachments.FileAttachment;
import com.jpmorgan.cib.wlt.ctrac.service.dto.letters.LetterFileXml.Letters.Letter.PropertySchedule.Properties.Property;
import com.jpmorgan.cib.wlt.ctrac.service.dto.letters.LetterFileXml.Letters.Letter.PolicyPurchasingOptions.PropertyOptions.Option;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterTemplate;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.CombinableLetterParam.*;

public class CombinableLetter {

	public Date getLetterDate() {
		return letterDate;
	}

	public void setLetterDate(Date letterDate) {
		this.letterDate = letterDate;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
		this.combinedProofOfCoverages.add(proofOfCoverageRid);
	}

	public Long getPerfectionTaskRid() {
		return perfectionTaskRid;
	}

	public void setPerfectionTaskRid(Long perfectionTaskRid) {
		this.perfectionTaskRid = perfectionTaskRid;
	}

	public LetterTemplate getLetterTemplate() {
		return letterTemplate;
	}

	public void setLetterTemplate(LetterTemplate letterTemplate) {
		this.letterTemplate = letterTemplate;
	}

	private Letter letter;
	private Long recipientRid;
	private DateTime loanLoadedDate;
	private String letterTemplateCode;
	
	private boolean skipSendLetter;
	private String reasonForSkipSendLetter;
	private Long proofOfCoverageRid;
	private Long perfectionTaskRid;
	private LetterTemplate letterTemplate;
	private Date letterDate;
	
	private Set<Long> borrowers = new HashSet<Long>();
	private InsurableAssetDTO insurableAssetDTO;
	private Property property;
	private Set<Long> combinedProofOfCoverages = new HashSet<>();
	private Map<InsurableAssetDTO, Property> propertyMap; // preparation for combining properties
	private Option option;
	private BigDecimal escrowAmount;
	Map<InsurableAssetDTO, Option> optionsMap;
	
	public CombinableLetter(Letter letter, LetterTemplate letterTemplate, Map<CombinableLetterParam,Object> parameters) {
		this.letter = letter;
		LoanData primaryLoanData = (LoanData) parameters.get(PRIMARY_LOAN_DATA);
		this.loanLoadedDate = AbstractLetterTemplate.SHORT_DATE_FORMATTER.parseDateTime(primaryLoanData.getLoadedDate());
		this.recipientRid = (Long) parameters.get(RECIPIENT_RID);
		this.letterTemplateCode = letterTemplate.getCode();
		this.skipSendLetter = parameters.get(SKIP_LETTER_GENERATION) != null ?
				(Boolean) parameters.get(SKIP_LETTER_GENERATION) :false;
		this.reasonForSkipSendLetter = "";
		this.perfectionTaskRid = (Long) parameters.get(PERFECTION_TASK_RID);
		this.letterTemplate = letterTemplate;
		this.letterDate = (Date)parameters.get(LETTER_DATE);
		this.escrowAmount = (BigDecimal) parameters.get(ESCROW_AMOUNT);
		setBorrowers((Set<Long>) parameters.get(BORROWERS));
		setProofOfCoverageRid((Long) parameters.get(PROOF_OF_COVERAGE_RID));
		setPropertyMap((Map<InsurableAssetDTO, Property>) parameters.get(ASSET_PROPERTY_MAP));
		for (InsurableAssetDTO insurableAssetDTO : this.propertyMap.keySet()) {
			this.insurableAssetDTO = insurableAssetDTO;
			this.property = this.propertyMap.get(insurableAssetDTO);
			break;
		}
		setOptionsMap((Map<InsurableAssetDTO, Option>) parameters.get(ASSET_OPTIONS_MAP));
		this.option = this.optionsMap.get(insurableAssetDTO);
	}

	public boolean isCombinableWith(CombinableLetter other) {
		return (isEqual(this.getRecipientRid(), other.getRecipientRid()) &&
				isEqual(this.getBorrowers(), other.getBorrowers()) &&
				isEqual(this.getLetter().getLetterDate(), other.getLetter().getLetterDate()) &&
				isEqual(this.getLetter().getLineOfBusiness(), other.getLetter().getLineOfBusiness()) &&
				isEqual(this.getLetter().getLpCancellationEffectiveDate(), other.getLetter().getLpCancellationEffectiveDate()) &&
				isEqual(this.getLetter().getLpPolicyEffectiveDate(), other.getLetter().getLpPolicyEffectiveDate()) &&
				isEqual(this.getLetter().getNumberOfDays(), other.getLetter().getNumberOfDays()) &&
				isEqual(this.getLetter().getOpbContentType(), other.getLetter().getOpbContentType()) &&
				isEqual(this.getLetter().getOpbAmount(), other.getLetter().getOpbAmount()) &&
				isEqual(this.getLetterTemplateCode(), other.getLetterTemplateCode())); 
	}

	public boolean isSkipSendLetter() {
		return skipSendLetter;
	}

	public void setSkipSendLetter(boolean skipSendLetter) {
		this.skipSendLetter = skipSendLetter;
	}

	public String getReasonForSkipSendLetter() {
		return reasonForSkipSendLetter;
	}

	public void setReasonForSkipSendLetter(String reasonForSkipSendLetter) {
		this.reasonForSkipSendLetter = reasonForSkipSendLetter;
	}

	private boolean isEqual(Object obj1, Object obj2) {
		if(obj1 == null) {
			return (obj2 == null);
		}
		if(obj2 == null) {
			return false;
		}
		if(obj1 instanceof String && obj2 instanceof String) {
			return((String)obj1).equalsIgnoreCase(((String)obj2)); 
		}
		return obj1.equals(obj2);
	}

	private boolean fileExists(List<FileAttachment> fileAttachments, String checkForFile) {

		if (letter.getFileAttachments().getFileAttachment() != null) {
			for (int i=0; i<letter.getFileAttachments().getFileAttachment().size(); i++) {
				String fileAttachment = letter.getFileAttachments().getFileAttachment().get(i).getFileName();
				if (checkForFile.equals(fileAttachment)) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	public void combineLetters(CombinableLetter source) {
		// combine collateral ids
		String collateralId = letter.getCtracCollateralID();
		String sourceCollateralId = source.getLetter().getCtracCollateralID();
		if(!collateralId.contains(sourceCollateralId)) {
			letter.setCtracCollateralID(collateralId + ", " + sourceCollateralId);
		}
		//Add the proof of coverage rid from source also to the combined Letter
		this.combinedProofOfCoverages.add(source.getProofOfCoverageRid());
		// LCP-4107 Missing Certificates
		if ( source.getLetter().getFileAttachments().getFileAttachment() != null) {
			for (int j=0; j<source.getLetter().getFileAttachments().getFileAttachment().size(); j++) {
				String sourceFileAttachment = source.getLetter().getFileAttachments().getFileAttachment().get(j).getFileName();
				if (!fileExists(letter.getFileAttachments().getFileAttachment(), sourceFileAttachment)) {
					FileAttachment fa = new FileAttachment();
					fa.setFileName(sourceFileAttachment);
					letter.getFileAttachments().getFileAttachment().add(fa);
				}
			}
		}
	
		// select earliest loan
		if(!letter.getLoanNumber().equalsIgnoreCase(source.getLetter().getLoanNumber()) &&
				loanLoadedDate.isAfter(source.getLoanLoadedDate())) {
			letter.setLoanNumber(source.getLetter().getLoanNumber());
			loanLoadedDate = source.getLoanLoadedDate();
			escrowAmount = source.getEscrowAmount();
		}
		//combine Properties
		combinePropertyMap(source);
		//append source purchasing options to the combined property purchasing options
		if(!optionsMap.containsKey(source.getInsurableAssetDTO())) {
			optionsMap.putAll(source.getOptionsMap());
		}		
	}

	protected void combinePropertyMap(CombinableLetter source) {
		Property propertyInMap = propertyMap.get(source.getInsurableAssetDTO());
		if(propertyInMap != null) {
			//combine the amount on all the letters except LP 1st, 2nd, or pre-renewal letters - LCP-4582
			//adding Primary+Excess amounts for the same insurableAsset 
			if(letterTemplate.isPropertyScheduleCombinable()) {
				BigDecimal amountInMap = AmountFormatter.parse(propertyInMap.getLenderPlacedAmount());
				BigDecimal sourceAmount = AmountFormatter.parse(source.getProperty().getLenderPlacedAmount());
				propertyInMap.setLenderPlacedAmount(AmountFormatter.format(amountInMap.add(sourceAmount)));
			}
		}
		else
		{// append source properties to the combined property schedule
			propertyMap.putAll(source.getPropertyMap());
		}
	}

	public void populateLetterProperties() { // from combined propertyMap to the letter's property schedule
		letter.getPropertySchedule().getProperties().getProperty().clear();		
		for (Property property : propertyMap.values()) {
			letter.getPropertySchedule().getProperties().getProperty().add(property);
		}
	}

	public void populateLetterPurchasingOptions() { // from combined purchasing options map to the letter's Purchasing Options page
		letter.getPolicyPurchasingOptions().getPropertyOptions().getOption().clear();
		letter.setIncludePolicyPurchasingOptions(MapUtils.isNotEmpty(optionsMap));
		if(letter.isIncludePolicyPurchasingOptions()) {
			for (Option option : optionsMap.values()) {
				letter.getPolicyPurchasingOptions().getPropertyOptions().getOption().add(option);
			}
		}
	}

	/**
	 *	Execute xml builders after letters has been combined that will add XML element sections
	 *	within the GDS Letter XML file and populate with data
	 */
	public void addLetterDataAfterLetterCombine(){
		//Calculate and include the pending payment change into the letter if applicable
		new PendingPaymentChangeBuilder(this).populateLetterData();

	}

	public Long getRecipientRid() {
		return recipientRid;
	}

	public DateTime getLoanLoadedDate() {
		return loanLoadedDate;
	}

	public void setLoanLoadedDate(DateTime loanLoadedDate) {
		this.loanLoadedDate = loanLoadedDate;
	}

	public Letter getLetter() {
		return letter;
	}

	public String getLetterTemplateCode() {
		return letterTemplateCode;
	}

	public Set<Long> getBorrowers() {
		return borrowers;
	}

	public void setBorrowers(Set<Long> borrowers) {
		this.borrowers = borrowers;
	}
	
	public void setRecipientRid(Long recipientRid) {
		this.recipientRid = recipientRid;
	}

	public void setLetterTemplateCode(String letterTemplateCode) {
		this.letterTemplateCode = letterTemplateCode;
	}

	public void setOptionsMap(Map<InsurableAssetDTO, Option> original) {
		this.optionsMap = new HashMap<InsurableAssetDTO, Option>(); 
		if(original != null) {
			this.optionsMap = original;
		}	
	}

	public void setPropertyMap(Map<InsurableAssetDTO, Property> original) {
		this.propertyMap = new HashMap<InsurableAssetDTO, Property>(); 
		if(original != null) { //need deep copy for amount calculations 
		    for (InsurableAssetDTO insurableAssetDTO: original.keySet())
		    {
		    	Property property = (Property) SerializationUtils.clone( original.get(insurableAssetDTO));
		    	this.propertyMap.put(insurableAssetDTO, property);
		    }
		}
	}

	public Map<InsurableAssetDTO, Option> getOptionsMap() {
		return this.optionsMap;
	}

	public void addBorrowerRid(Long borrowerRid) {
		if(this.borrowers == null){
			borrowers = new HashSet<Long>();
		}
		this.borrowers.add(borrowerRid);
	}

	public Map<InsurableAssetDTO, Property> getPropertyMap() {
		return propertyMap;
	}

	public Property getProperty() {
		return property;
	}

	public Option getOption() {
		return this.option;
	}

	protected InsurableAssetDTO getInsurableAssetDTO() {
		return insurableAssetDTO;
	}

	protected void setInsurableAssetDTO(InsurableAssetDTO insurableAssetDTO) {
		this.insurableAssetDTO = insurableAssetDTO;
	}

	public Set<Long> getCombinedProofOfCoverages() {
		return combinedProofOfCoverages;
	}

	public BigDecimal getEscrowAmount() {
		return escrowAmount;
	}

	public void setEscrowAmount(BigDecimal escrowAmount) {
		this.escrowAmount = escrowAmount;
	}
}
