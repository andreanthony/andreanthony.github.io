package com.jpmorgan.cib.wlt.ctrac.service.admin;

import com.jpmorgan.cib.wlt.ctrac.service.admin.impl.AddressValidateRequest;
import com.jpmorgan.cib.wlt.ctrac.service.admin.impl.AddressValidateResponse;
import com.jpmorgan.cib.wlt.ctrac.service.admin.impl.CityStateLookupResponse;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.LoanBorrowerAddressDTO;

public interface USPSClientService {
    AddressValidateResponse getAddressValidate(LoanBorrowerAddressDTO loanBorrowerAddressDTO) throws Exception;
    AddressValidateRequest.Address addressValidateRequestAddressFromDTO(LoanBorrowerAddressDTO loanBorrowerAddressDTO);
    CityStateLookupResponse getCityFromZip5(String zip5) throws Exception ;
}
