package com.jpmorgan.cib.wlt.ctrac.service.admin.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Address;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LoanBorrowerAddressData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LoanBorrowerAddressRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AddressRepository;
import com.jpmorgan.cib.wlt.ctrac.service.admin.LoanBorrowerAddressService;
import com.jpmorgan.cib.wlt.ctrac.service.admin.USPSClientService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.LoanBorrowerAddressDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional(readOnly=true)
public class LoanBorrowerAddressServiceImpl implements LoanBorrowerAddressService {
	private static final Logger logger = LoggerFactory.getLogger(LoanBorrowerAddressServiceImpl.class);

    @Autowired private LoanBorrowerAddressRepository loanBorrowerAddressRepository;
    @Autowired private AddressRepository addressRepository;
    @Autowired private CtracObjectMapper ctracObjectMapper;
    @Autowired private USPSClientService uspsClientService;
	
	@Override
	@Secured({EntitlementRoles.ADMIN_ROLE})
	public int getUnverifiedLoanBorrowerAddressDataCount() {
		return(loanBorrowerAddressRepository.getLoanBorrowerAddressCount());
	}
	
	private boolean saveAddress(LoanBorrowerAddressDTO loanBorrowerAddressDTO) {
		boolean retValue = false;
		
		if (loanBorrowerAddressDTO.getErrorMessage() == "" &&
				loanBorrowerAddressDTO.getUnitBuilding().equals(loanBorrowerAddressDTO.getVerifiedUnitBuilding()) &&
				loanBorrowerAddressDTO.getCity().equals(loanBorrowerAddressDTO.getVerifiedCity()) &&
				loanBorrowerAddressDTO.getState().equals(loanBorrowerAddressDTO.getVerifiedState()) &&
				loanBorrowerAddressDTO.getZipCode().equals(loanBorrowerAddressDTO.getVerifiedZipCode())) {
			
			String dbStreetAddress = loanBorrowerAddressDTO.getStreetAddress();
			String uspsStreetAddress = loanBorrowerAddressDTO.getVerifiedStreetAddress();
			
			if (dbStreetAddress.equals(uspsStreetAddress) || hasSimilarStreetAddress(dbStreetAddress, uspsStreetAddress)) {
				loanBorrowerAddressDTO.setVerifiedAddress(true); 
				saveLoanBorrowerVerifiedAddressRecord(loanBorrowerAddressDTO);
				retValue=true;
			} 
		}
		
		return(retValue);
	}
	
	private boolean hasSimilarStreetAddress(String dbStreetAddress, String uspsStreetAddress) {
		Map<String, String> hm = new HashMap<>();
		
		//Source: http://pe.usps.gov/text/pub28/28apc_002.htm
		hm.put("AVENUE", "AVE");
		hm.put("BOULEVARD", "BLVD");
		hm.put("CENTER", "CTR");
		hm.put("CIRCLE", "CIR");
		hm.put("COURT", "CT");
		hm.put("DRIVE", "DR");
		hm.put("EXPRESSWAY", "EXPY");
		hm.put("FREEWAY", "FWY");
		hm.put("HIGHWAY", "HWY");
		hm.put("LANE", "LN");
		hm.put("PARKWAY", "PKWY");
		hm.put("ROAD", "RD");
		hm.put("STREET", "ST");
		
		 Iterator<Map.Entry<String, String>> it = hm.entrySet().iterator();
		    while (it.hasNext()) {
		    	Map.Entry<String, String> pair = (Map.Entry<String, String>)it.next();
		    	
		    	if (dbStreetAddress.replace(" " + pair.getKey(), " " + pair.getValue()).equals(uspsStreetAddress)) {
		    		return(true);
		    	}
		    }
		
		return(false);
	}
	
	@Override
	@Secured({EntitlementRoles.ADMIN_ROLE})
	public List<LoanBorrowerAddressDTO> autoCorrectLoanBorrowerAddress() {

        List<LoanBorrowerAddressData> loanBorrowerAddressData = loanBorrowerAddressRepository.findAll();
        List<LoanBorrowerAddressDTO> loanBorrowerAddressDTOs
                = ctracObjectMapper.mapAsList(loanBorrowerAddressData, LoanBorrowerAddressDTO.class);

        List<LoanBorrowerAddressDTO> savedLoanBorrowerAddressDTOs = new ArrayList<>();

        loanBorrowerAddressDTOs.stream().forEach(loanBorrowerAddressDTO -> {
            setVerifiedPostalAddressFields(loanBorrowerAddressDTO);
            if (saveAddress(loanBorrowerAddressDTO)) {
                savedLoanBorrowerAddressDTOs.add(loanBorrowerAddressDTO);
            }
        });

        return savedLoanBorrowerAddressDTOs;
    }

	@Override
	@Secured({EntitlementRoles.ADMIN_ROLE})
	public List<LoanBorrowerAddressDTO> prepareLoanBorrowerAddressData() {

        List<LoanBorrowerAddressData> loanBorrowerAddressData = loanBorrowerAddressRepository.getLoanBorrowerAddressData();
        List<LoanBorrowerAddressDTO> loanBorrowerAddressDTOs = ctracObjectMapper.mapAsList(loanBorrowerAddressData, LoanBorrowerAddressDTO.class);

        if (loanBorrowerAddressDTOs.size() == 0) {
            logger.debug("No records found");
        } else {
            logger.debug("{} Records found", loanBorrowerAddressDTOs.size());
            for (LoanBorrowerAddressDTO loanBorrowerAddressDTO: loanBorrowerAddressDTOs) {
                setVerifiedPostalAddressFields(loanBorrowerAddressDTO);
            }
        }

		return loanBorrowerAddressDTOs;
	}

	@Transactional
	private void saveLoanBorrowerVerifiedAddressRecord(LoanBorrowerAddressDTO loanBorrowerAddressData) {
		Address address = new Address();
		address.setRid(loanBorrowerAddressData.getAddressRid());
		address.setAddress(loanBorrowerAddressData.getVerifiedStreetAddress());
		address.setCity(loanBorrowerAddressData.getVerifiedCity());
		address.setState(loanBorrowerAddressData.getVerifiedState());
		address.setZipCode(loanBorrowerAddressData.getVerifiedZipCode());
		address.setUnitOrBuilding(loanBorrowerAddressData.getVerifiedUnitBuilding());
		address.setVerifiedDate(new Date());
		
		addressRepository.saveAndFlush(address);
	}
	
	@Transactional
	private void saveLoanBorrowerAddressRecord(LoanBorrowerAddressDTO loanBorrowerAddressData) {
		Address address = new Address();
		address.setRid(loanBorrowerAddressData.getAddressRid());
		address.setAddress(loanBorrowerAddressData.getStreetAddress());
		address.setCity(loanBorrowerAddressData.getCity());
		address.setState(loanBorrowerAddressData.getState());
		address.setZipCode(loanBorrowerAddressData.getZipCode());
		address.setUnitOrBuilding(loanBorrowerAddressData.getUnitBuilding());
		address.setVerifiedDate(new Date());
		
		addressRepository.saveAndFlush(address);
	}
	
	@Override
	@Secured({EntitlementRoles.ADMIN_ROLE})
	public void saveLoanBorrowerAddressRecords(List<LoanBorrowerAddressDTO> loanBorrowerAddressDataList) {
		for (LoanBorrowerAddressDTO loanBorrowerAddressDTO : loanBorrowerAddressDataList) {
			if (loanBorrowerAddressDTO.getVerifiedAddress()) {
				saveLoanBorrowerAddressRecord(loanBorrowerAddressDTO);
			}
		}
	}

	public void setVerifiedPostalAddressFields(LoanBorrowerAddressDTO loanBorrowerAddressDTO) {
		try {
            AddressValidateResponse addressValidateResponse = uspsClientService.getAddressValidate(loanBorrowerAddressDTO);
			if (!addressValidateResponse.hasError()) {
				loanBorrowerAddressDTO.setVerifiedStreetAddress(addressValidateResponse.getAddress().getAddress2());
				loanBorrowerAddressDTO.setVerifiedUnitBuilding(addressValidateResponse.getAddress().getAddress1());
				loanBorrowerAddressDTO.setVerifiedCity(addressValidateResponse.getAddress().getCity());
				loanBorrowerAddressDTO.setVerifiedState(addressValidateResponse.getAddress().getState());
				loanBorrowerAddressDTO.setVerifiedZipCode(addressValidateResponse.getAddress().getZip5());
				
				// if city names don't match, make one more attempt to get it using a different USPS API
				if (!addressValidateResponse.getAddress().getCity().equalsIgnoreCase(loanBorrowerAddressDTO.getCity())) {
					CityStateLookupResponse cityStateLookupResponse = uspsClientService.getCityFromZip5(addressValidateResponse.getAddress().getZip5());
					if (!cityStateLookupResponse.hasError()) {
                        loanBorrowerAddressDTO.setVerifiedCity(cityStateLookupResponse.getZipCode().getCity());
                    } else {
                        loanBorrowerAddressDTO.setErrorMessage("Error: Error getting city name.");
                    }
				}
			} else {
				loanBorrowerAddressDTO.setErrorMessage("Error: " + addressValidateResponse.getAddress().getError().getDescription());
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
		}
	}	

}
