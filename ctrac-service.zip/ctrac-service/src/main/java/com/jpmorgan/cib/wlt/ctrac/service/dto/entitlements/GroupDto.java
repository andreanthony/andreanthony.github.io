package com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements;


/**
 * Created by I569445 on 2/25/2016.
 */
public class GroupDto {

    private String groupName;
    private String categoryName;

    public GroupDto() {

    }

    public GroupDto(String rsamValue) {
        //comes in from RSAM request as Category - GroupName
        if(rsamValue != null) {
            String[] rsamProfile = rsamValue.split("-");
            this.categoryName = rsamProfile[0].trim();
            this.groupName = rsamProfile[1].trim();
        }
    }

    public GroupDto(String categoryName, String groupName) {
        this.categoryName = categoryName;
        this.groupName = groupName;
    }

    public String getRSAMProfileName() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.getCategoryName()).append(" - ").append(this.getGroupName());
        return sb.toString();
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
