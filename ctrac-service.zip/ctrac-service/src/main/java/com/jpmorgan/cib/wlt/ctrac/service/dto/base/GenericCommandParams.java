package com.jpmorgan.cib.wlt.ctrac.service.dto.base;


public class GenericCommandParams {
	private TMParams tmParams;
	private String janusUserId;

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	public String getJanusUserId() {
		return janusUserId;
	}

	public void setJanusUserId(String janusUserId) {
		this.janusUserId = janusUserId;
	}	
}
