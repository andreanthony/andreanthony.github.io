package com.jpmorgan.cib.wlt.ctrac.service.batch.remap.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileException;

/**
 * Created by E704298 on 8/2/2017.
 */
public class MultipleFilesException implements RemapFileException {

    private RemapVendor remapVendor;

    public MultipleFilesException(RemapVendor remapVendor) {
        this.remapVendor = remapVendor;
    }

    @Override
    public String getMessage() {
        String remapVendorDisplayName = remapVendor != null ? remapVendor.getDisplayName() : "";
        return "Multiple weekly remap files from " + remapVendorDisplayName +
                " were received and the files were processed.";
    }

    public RemapVendor getRemapVendor() {
        return remapVendor;
    }
}
