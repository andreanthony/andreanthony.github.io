package com.jpmorgan.cib.wlt.ctrac.service.event.service.request;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import org.apache.commons.lang3.StringUtils;

public abstract class AbstractPublishEventRequest implements PublishEventRequest {

    protected Long collateralRid;
    protected String lineOfBusiness;
    protected CollateralEventType collateralEventType;
    protected boolean isSystemEvent;

    @Override
    public CollateralEventType getCollateralEventType() {
        return collateralEventType;
    }

    public abstract String getDescription();

    public abstract String getIdentifier();

    @Override
    public Long getCollateralRid() {
        return collateralRid;
    }

    @Override
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    @Override
    public String getUser() {
        return isSystemEvent ? SYSTEM : null;
    }

    @Override
    public String getTaskName() {
        return StringUtils.EMPTY;
    }

    public void setSystemEvent(boolean isSystemEvent) {
        this.isSystemEvent = isSystemEvent;
    }
}
