package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

public class LPPremiumPaidData extends LenderPlaceData {

    private static final long serialVersionUID = -5895818972452006404L;

}
