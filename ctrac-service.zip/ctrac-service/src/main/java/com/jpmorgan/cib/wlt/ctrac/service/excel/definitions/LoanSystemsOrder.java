package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;

public class LoanSystemsOrder {

	private LoanSystemsOrder() {}

	public static final LoanSystem[] LOAN_SYSTEM_ORDER = {LoanSystem.VLS, LoanSystem.ACBS, LoanSystem.LIQ, LoanSystem.ABLE,LoanSystem.STRATEGY};

}
