package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NotEmptyIfAnotherFieldHasValue;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@NotEmptyIfAnotherFieldHasValue.List({
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "BUS", dependFieldName = "legalDescription", message = "{invalid.collateralDto.legalDescription}"),
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "REL", dependFieldName = "address.streetAddress", message = "{invalid.addressDto.streetAddress}"),
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "REL", dependFieldName = "address.city", message = "{invalid.addressDto.city}"),
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "REL", dependFieldName = "address.zipCode", message = "{invalid.addressDto.zipCode}"),
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "REL", dependFieldName = "address.state", message = "{invalid.addressDto.state}")
})
public class CreateNewCollateralRecord implements Serializable {

	private static final long serialVersionUID = 1L;

	private Collection<LookUpCode> collateralTypes;

	private Collection<LookUpCode> stateCodes;

	private Collection<LineOfBusinessDTO> linesOfBusiness;

	private String collateralType;

	private final List<LoanData> loansData = new ArrayList<>();

	@NoInvalidCharacters
	@Size(max=255, message="{invalid.collateralDto.legalDescription}")
	private String legalDescription;

	@Valid
	private AddressDto address;

	public String getPropertyTypeDisplayValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<LookUpCode> getCollateralTypes() {
		return collateralTypes;
	}

	public void setCollateralTypes(Collection<LookUpCode> collateralTypes) {
		this.collateralTypes = collateralTypes;
	}

	public Collection<LookUpCode> getStateCodes() {
		return stateCodes;
	}

	public void setStateCodes(Collection<LookUpCode> stateCodes) {
		this.stateCodes = stateCodes;
	}

    public Collection<LineOfBusinessDTO> getLinesOfBusiness() {
        return linesOfBusiness;
    }

    public void setLinesOfBusiness(Collection<LineOfBusinessDTO> linesOfBusiness) {
        this.linesOfBusiness = linesOfBusiness;
    }

    public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public List<LoanData> getLoansData() {
		return loansData;
	}

	public String getLegalDescription() {
		return legalDescription;
	}

	public void setLegalDescription(String legalDescription) {
		this.legalDescription = legalDescription;
	}

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}

}
