package com.jpmorgan.cib.wlt.ctrac.service.email.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DefaultDateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CoverageGapReportViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.WorkflowDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.batch.impl.CoverageGapReportUtil;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRExceptionEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRAcceptedPolicyEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.builder.EmailDataDtoBuilder;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.email.EmailDataDto;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationType;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailTemplateRetrievalService;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.externallyAgented.ExternallyAgentedService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CollateralDocumentUtil;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldService;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.*;
import microsoft.exchange.webservices.data.Importance;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.management.RuntimeErrorException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.*;

/**
 * @author n595724
 *
 */
@Service(value = "emailNotificationService")
public class EmailNotificationServiceImpl implements EmailNotificationService {

	private static final Logger logger = LoggerFactory.getLogger(EmailNotificationServiceImpl.class);

	private static final String lpInitiated = "LP_INIT";
	private static final String EMAIL_CATEGORY_AGENT = "AGENT";
	private static final String EMAIL_CATEGORY_MARKET = "MARKET";
	private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

	@Autowired
	private BIRExceptionEmailService birExceptionEmailService;

	@Autowired
	private CollateralRepository collateralRepository;

	@Autowired
	private EmailAlertSender emailAlertSender;

	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Autowired
	private EmailTemplateRetrievalService emailTemplateRetrievalService;

	@Autowired
	private Environment env;

	@Autowired
	private WorkItemRepository workItemRepository;

	@Autowired
	private WorkflowDetailsViewRepository workflowDetailsViewRepository;

	@Autowired
	private CalendarDayUtil calendarDayUtil;

	@Autowired
	private FloodEmailService floodEmailService;

	@Autowired
	private HoldService holdService;

	@Autowired
	private HoldWorkItemRepository holdWorkItemRepository;
	@Autowired
	private LoanService loanService;
	@Autowired
	ExternallyAgentedService externallyAgentedService;
	@Autowired
	CollateralInsuranceRepository collateralInsuranceRepository;
	@Autowired
	CoverageGapReportViewRepository coverageGapReportViewRepository;
	@Autowired
	private CollateralManagementService collateralManagementService;
    @Autowired
    private CoverageGapReportUtil coverageGapReportUtil;
    @Autowired
	private CollateralWorkflowService collateralWorkflowService;
    @Autowired
	private PerfectionTaskService perfectionTaskService;

	/**
	 * This method will be used after Verify Flood Coverage Amounts for Flood
	 * Remap AND when notifying the market prior to LP for Application/Proof of
	 * Payment
	 */
	@Override
	@Transactional(readOnly = true)
	public void releasePreLpMarketEmail(Long triggerworkItemId) {

		/**
		 * TODO refactor to take as input the CoverageActionResult?
		 */
		try {

			logger.debug("Begin releasePreLpMarketEmail() : ");

			WorkItem triggerworkItem = workItemRepository.findOne(triggerworkItemId);
			triggerworkItem = CtracBaseEntity.deproxy(triggerworkItem, WorkItem.class);
			Collateral collateral = triggerworkItem.getPreferredCollateral();

			if (triggerworkItem instanceof FloodRemapItem) {
				//@Christian this is a temp hack while fixing the root issue; collateralWorkItem should be used to store the relation;
				//the collateral reference in flood remap Item need to be deleted
				if (collateral == null) {
					collateral = ((FloodRemapItem) triggerworkItem).getCollateral();
				}
				FloodRemapItem remap = (FloodRemapItem) triggerworkItem;
				String remaptype = remap.getRemapCategory();
				boolean exposureExist = remap.getPreLenderPlaceDetails().doesExposureExists();
				boolean clientFount = remap.getPreLenderPlaceDetails().isClientFound();
				boolean propertyPledged = remap.getPreLenderPlaceDetails().isPropertyPledge();
				boolean zoneOut = CtracAppConstants.FLOOD_ZONE_STATUS_OUT.equalsIgnoreCase(remaptype);

				EmailDataDtoBuilder emailDataDtoBuilder = new EmailDataDtoBuilder();
				EmailDataDto emailDataDto = null;
				String toAddress = null;

				String emailStatus = null;
				boolean zoneInAtRisk = !zoneOut && clientFount && propertyPledged && exposureExist;
				boolean zoneInNoRisk = !zoneOut && clientFount && ((propertyPledged && !exposureExist) || !propertyPledged);
				boolean zoneOutAtRisk = zoneOut && clientFount && propertyPledged;
				boolean zoneOutNoRisk = zoneOut && clientFount && !propertyPledged;

				if (zoneInNoRisk || zoneOutNoRisk) {
					// need to release the no action email
					emailStatus = "NO_RISK";
					emailDataDto = emailDataDtoBuilder.buildNoRiskPreLpMarketEmailDTO(remap);
					toAddress = collateral != null ? floodEmailService.getMarketEmailToAddress(collateral) : getDefaultMarketEmailToAddress(remap);
				} else if (zoneInAtRisk || zoneOutAtRisk) {
					// need to release the Zin or Zout email
					emailStatus = "AT_RISK";
					toAddress = floodEmailService.getMarketEmailToAddress(collateral);
					emailDataDto = emailDataDtoBuilder.buildAtRiskPreLpMarketEmailDTO(remap, collateral);
				}

				// 1 do we need to send an email?
				if (StringUtils.isBlank(emailStatus) || toAddress == null) {
					return;
				}

				EmailTemplateRulerequest emailTemplateRulerequest = new EmailTemplateRulerequest();
				emailTemplateRulerequest.setRemapType(remaptype);
				emailTemplateRulerequest.setEmailCategory(EmailNotificationType.PRE_LP_ZONE_CHANGE_EMAIL.getEmailCategory());

				emailTemplateRulerequest.setStatus(emailStatus);

				logger.info("\n Searching for email template : " + emailTemplateRulerequest.toString());
				// 2 retrieve the proper email template
				EmailTemplate emailTemplate = emailTemplateRetrievalService.findEmailTemplate(emailTemplateRulerequest);

				if (emailTemplate == null) {
					logger.error("\n Could not find template : " + emailTemplateRulerequest.toString());
					//logger.error("\n Could not find the email template: Pre - Lp email:  " +emailTemplateRulerequest.toString());
					throw new RuntimeErrorException(null, "Email template not found; searched for " + emailTemplateRulerequest.toString());
				}
				//TODO FIXME attach the document conditionally?
				List<MultipartFile> attachment = new ArrayList<MultipartFile>();
				//Add flood determination
				CollateralDocument floodDetermination = remap.getFloodDetermination();
				attachment.add(new BasicMultipartFile(floodDetermination.getFileContent().getFileContent(), floodDetermination.getFileName(), floodDetermination.getFileNameWithExt(), "application/pdf"));

				CollateralDocument inToOutNotice = remap.getInToOutNotice();
				if (inToOutNotice != null && inToOutNotice.getFileName() != null) {
					attachment.add(new BasicMultipartFile(inToOutNotice.getFileContent().getFileContent(), inToOutNotice.getFileName(), inToOutNotice.getFileNameWithExt(), "application/pdf"));
				}
				EmailAttributeHolder marketEmail = CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);
				marketEmail.addToAddress(toAddress);
				marketEmail.setWorkItemLob(remap.getFloodRemap().getLineOfBusiness());

				marketEmail.setFiles(attachment);
				if (collateral != null) {
					marketEmail.getCollateralRids().add(collateral.getRid());
				}
				floodEmailService.sendInternalEmailThroughEWS(marketEmail);
				logger.debug("Successful Confirm of : releasePreLpMarketEmail()");
			}
		} catch (Exception e) {
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0326", CtracErrorSeverity.CRITICAL));
			logger.error("\n  ==============Error releasing Pre - Lp email:  " + e.getCause().toString(), e);
			throw e;
		}
	}

	/**
	 * This method will be used after Verify Flood Coverage Amounts for Flood
	 * Remap AND when notifying the market prior to LP for Application/Proof of
	 */
	/* (non-Javadoc)
	 * @see com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService#releaseLpInitiatedMarketEmail(java.util.List, com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral)
	 */
	@Override
	@Transactional(readOnly = true)
	public void releaseLpInitiatedMarketEmail(List<? extends ProofOfCoverageDTO> lpCoveragesToIssues, Collateral collateral) {

		/**
		 */
		if (lpCoveragesToIssues != null && lpCoveragesToIssues.size() > 0) {
			try {
				logger.debug("Begin : releaseLpInitiatedMarketEmail()");

				String toAddress = floodEmailService.getMarketEmailToAddress(collateral);//market email may not be needed fo CTL-no spesial handling
				if (toAddress != null) { //market email may not be needed
					EmailDataDtoBuilder emailDataDtoBuilder = new EmailDataDtoBuilder();
					EmailDataDto emailDataDto = emailDataDtoBuilder.buildLpEmailDto(collateral, null, lpCoveragesToIssues);

					EmailTemplateRulerequest emailTemplateRulerequest = new EmailTemplateRulerequest();
					//Relese 7.0.5 no seperate emails by LOB
					//emailTemplateRulerequest.setLob(collateral.getPreferredLoan().getLineOfBusiness());
					emailTemplateRulerequest.setAdditionalInfo(CtracAppConstants.ADDITIONAL_INFO);
					emailTemplateRulerequest.setTypeId(lpInitiated);

					logger.info("\n Searching for email template : " + emailTemplateRulerequest.toString());
					// 2 retrieve the proper email template
					EmailTemplate emailTemplate = emailTemplateRetrievalService.findEmailTemplate(emailTemplateRulerequest);

					if (emailTemplate == null) {
						logger.error("\n Could not find template : " + emailTemplateRulerequest.toString());
						throw new CTracApplicationException("E0115", CtracErrorSeverity.APPLICATION);
					}
					// - 3 populate the email template and send the email

					EmailAttributeHolder marketEmail = CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);
					marketEmail.addToAddress(toAddress);
					logger.debug("releaseLpInitiatedMarketEmail will be sent to : " + marketEmail.getToAddresses());
					marketEmail.getCollateralRids().add(collateral.getRid());

					PerfectionTask marketCancellationEmailTask = openTask(collateral.getRid(),
							WorkflowStateDefinition.SEND_MARKET_LP_ISSUANCE_EMAIL.getFloodRemapTaskState());

					floodEmailService.sendInternalEmailThroughEWS(marketEmail);

					closeTask(marketCancellationEmailTask,
							"LP Market Issuance Email Sent for Flood");
				}
				logger.debug("Successfull Confirm of : releaseLpInitiatedMarketEmail()");

			} catch (Exception e) {
				logger.error(ErrorCodeToMessageConverter.convertToMessage("E0328", CtracErrorSeverity.CRITICAL));
				logger.error("\n  ==============  Error Releasing Lp email:  " + e.getCause().toString(), e);
				throw e;

				// TODO enable exception processing after testing

			}
		}
	}


	@Override
	@Transactional(readOnly = true)
	public void requestLPInitiationVendorEmail(File insuranceReqFile, LpInsuranceVendor lpVendor) {
		logger.debug("BEGIN::sendInsuranceReqToVendor()");
		logger.debug("Vendor: " + lpVendor.getDisplayName());
		if (insuranceReqFile != null) {
			EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
			emailAttributeHolder.setSingleFileAttachment(insuranceReqFile);
			emailAttributeHolder.setSubject(env.getRequiredProperty(POLICY_INSURANCE_REQ_EMAIL_SUBJECT));
			emailAttributeHolder.setEmailBody(env.getRequiredProperty(POLICY_INSURANCE_REQ_EMAILBODY) + " " + lpVendor.getDisplayName());
			emailAttributeHolder.addToAddress(env.getRequiredProperty(POLICY_INSURANCE_REQ_TOEMAIL));
			emailAttributeHolder.setFromAddress(env.getRequiredProperty(POLICY_INSURANCE_REQ_FROMEMAIL));

			if (lpVendor.equals(LpInsuranceVendor.ALTHANS)) {
				emailAttributeHolder.addCcAddress(env.getRequiredProperty("from.email.address.flood.service"));
				emailAttributeHolder.addCcAddress(env.getRequiredProperty("from.email.address.ctl.flood.service"));
			}

			floodEmailService.sendEmail(emailAttributeHolder);
			logger.debug("Successfull Confirm of : ");

		} else {
			logger.debug("Error while creating LP Insurance Request xlsx file.");
		}
		logger.debug("END::sendInsuranceReqToVendor()");
	}


	/**
	 * Amounts for Flood Remap AND when notifying the market prior to LP for
	 * Application/Proof of Payment
	 * <p>
	 * Must be called in a transactional context
	 */
	/* (non-Javadoc)
	 * @see com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService#releaseLpMarketCancellationEmail(java.util.List, com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral)
	 */
	@Override
	// @Transactional(readOnly = true, propagation=Propagation.MANDATORY)
	@Transactional(readOnly = true)
	public void releaseLpMarketCancellationEmail(List<? extends ProofOfCoverageDTO> lpCoveragesToCancels, Long collateralId, List<? extends ProofOfCoverageDTO> lpCoveragesToIssue) {
		if (lpCoveragesToCancels != null && lpCoveragesToCancels.size() > 0) {
			try {
				logger.debug("Begin : releaseLpMarketCancellationEmail()");
				/**
				 * Assuming one email per collateral;
				 *
				 */
				if (lpCoveragesToCancels == null || lpCoveragesToCancels.isEmpty()) {
					return;
				}

				// - 3 populate the email template and send the email
				Collateral collateral = collateralRepository.findOne(collateralId);
				String toAddress = floodEmailService.getMarketEmailToAddress(collateral);
				if (toAddress != null) {
					EmailDataDtoBuilder emailDataDtoBuilder = new EmailDataDtoBuilder();
					EmailDataDto emailDataDto = emailDataDtoBuilder.buildLpMarketCancellationEmailDto(collateral, lpCoveragesToCancels, lpCoveragesToIssue);
					EmailTemplate emailTemplate = emailTemplateRepository.findByEmailTemplateId("BLPGAP");
					EmailAttributeHolder marketEmail = CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);
					marketEmail.addToAddress(toAddress);
					marketEmail.getCollateralRids().add(collateralId);

					PerfectionTask marketCancellationEmailTask = openTask(collateralId,
							WorkflowStateDefinition.SEND_MARKET_LP_CANCELLATION_EMAIL.getFloodRemapTaskState());

					floodEmailService.sendInternalEmailThroughEWS(marketEmail);

					closeTask(marketCancellationEmailTask,
							"LP Market Cancellation Email Sent for Flood");
				}

				logger.debug("Successful Confirm of : releaseLpMarketCancellationEmail()");

			} catch (Exception e) {
				logger.error(ErrorCodeToMessageConverter.convertToMessage("E0329", CtracErrorSeverity.CRITICAL));
				logger.error("\n  ==============  Could not release Lp Market Cancellation email:  " + e.getCause().toString(), e);
				if (e.getCause() != null && e.getCause().toString().contains("java.net.UnknownHostException")) {
					throw new CTracApplicationException("E0117", CtracErrorSeverity.APPLICATION);
				} else {
					throw new CTracApplicationException("E0116", CtracErrorSeverity.APPLICATION);
				}
			}
		}
	}

	private String getDefaultMarketEmailToAddress(FloodRemapItem remapItem) {
		EmailDetails emailDetail = remapItem.getPreLenderPlaceDetails().getMarketEmailDetails();
		return emailDetail.getEmailTo();
	}

	@Override
	@Transactional(readOnly = true)
	public void sendBIRExceptionEmails(PerfectionTask perfectionTask, TaskState currentTaskState,
									   BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		if (!(currentTaskState instanceof AbstractExceptionEmailState)) {
			throw new RuntimeException("Invalid workflow step for sendBIRExceptionEmails:" + currentTaskState.getName());
		}

		PolicyStatus policyStatus = borrowerInsuranceReviewData.getProofOfCoverageData().getPolicyStatus();
		if (policyStatus != PolicyStatus.REJECTED && policyStatus.isInactive()) {
			return;
		}

		AbstractExceptionEmailState exceptionEmailState = (AbstractExceptionEmailState) currentTaskState;
		BIRExceptionEmailDTO birExceptionEmailDTO =
				birExceptionEmailService.populateExceptionEmailData(
						perfectionTask.getWorkItem(), currentTaskState, borrowerInsuranceReviewData);

		// don't send email if no exceptions
		if (birExceptionEmailDTO.getPolicyExceptions().isEmpty() &&
				birExceptionEmailDTO.getCollateralExceptionDataMap().isEmpty()) {
			return;
		}

		File agentEmailFile = null;
		if (exceptionEmailState.hasAgentEmailTemplate()) {
			agentEmailFile = sendEmail(exceptionEmailState, EMAIL_CATEGORY_AGENT, borrowerInsuranceReviewData, birExceptionEmailDTO);
		}
		if (exceptionEmailState.hasMarketEmailTemplate()) {
			if (exceptionEmailState.attachAgentToMarket()) {
				birExceptionEmailDTO.setSingleFileAttachment(agentEmailFile);
			}
			sendEmail(exceptionEmailState, EMAIL_CATEGORY_MARKET, borrowerInsuranceReviewData, birExceptionEmailDTO);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public void sendBIRPolicyAcceptedWithNoExceptionEmails(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {

		BIRAcceptedPolicyEmailDTO birAcceptedPolicyEmailDTO =
				birExceptionEmailService.populateAcceptedPolicyWithNoExceptionEmailData(borrowerInsuranceReviewData);

		Set<String> toAddressSet = getMarketEmailAddresses(borrowerInsuranceReviewData.getCollateralDetailsMap());
		if (!toAddressSet.isEmpty()) {
			EmailTemplate emailTemplate = emailTemplateRepository.findByEmailTemplateId("BIRPOLACPT");
			EmailAttributeHolder exceptionEmail = getEmailContentNoExceptionMails(birAcceptedPolicyEmailDTO, emailTemplate);
			exceptionEmail.setToAddresses(toAddressSet);
			exceptionEmail.getCollateralRids().addAll(birAcceptedPolicyEmailDTO.getCollateralIdSet());
			floodEmailService.sendInternalEmailThroughEWS(exceptionEmail);
		}
	}

	EmailAttributeHolder getEmailContentNoExceptionMails(BIRAcceptedPolicyEmailDTO birAcceptedPolicyEmailDTO, EmailTemplate emailTemplate){
		return CtracEmailSender.createEmailContentForNoExceptionEmails(birAcceptedPolicyEmailDTO, emailTemplate);
	}

	File sendEmail(AbstractExceptionEmailState exceptionEmailState, String emailCategory,
				   BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, BIRExceptionEmailDTO birExceptionEmailDTO) {
		EmailTemplate emailTemplate = getExceptionEmailTemplate(exceptionEmailState, emailCategory);
		EmailAttributeHolder exceptionEmail = CtracEmailSender.createEmailContentForExceptionEmails(birExceptionEmailDTO, emailTemplate);
		if (EMAIL_CATEGORY_AGENT.equals(emailCategory)) {
			Set<String> agentEmailSet = getExternalAgentEmail(borrowerInsuranceReviewData.getCollateralDetailsMap());
			if (agentEmailSet.isEmpty()) {
				ContactDetailDto agentDetails =
						borrowerInsuranceReviewData.getProofOfCoverageData().getAgentData().getContactDetailDto();
				String toAddress = null;
				if (StringUtils.isNotBlank(agentDetails.getEmailAddress())) {
					toAddress = agentDetails.getEmailAddress();
				} else if (StringUtils.isNotBlank(agentDetails.getFaxNumber())) {
					toAddress = eFaXEmailAddress(agentDetails);
				}

				if (StringUtils.isNotBlank(toAddress)) {
					agentEmailSet.add(toAddress);
				}
			}
			exceptionEmail.setToAddresses(agentEmailSet);
			if (agentEmailSet.isEmpty()) {
				String newSubject = "UNDELIVERABLE - " + exceptionEmail.getSubject();
				exceptionEmail.setSubject(newSubject);
			}

		} else if (EMAIL_CATEGORY_MARKET.equals(emailCategory)) {
			exceptionEmail.setToAddresses(getMarketEmailAddresses(borrowerInsuranceReviewData.getCollateralDetailsMap()));
			if (exceptionEmail.getToAddresses().isEmpty()) {
				logger.info("Not sending sendBIRExceptionEmails when all primary loans are CTL and none is special handling");
				return null;
			}
		}
		exceptionEmail.setSingleFileAttachment(birExceptionEmailDTO.getSingleFileAttachment());
		exceptionEmail.getCollateralRids().addAll(birExceptionEmailDTO.getCollateralIdSet());
		floodEmailService.sendEmail(exceptionEmail);

		File agentEmailFile = null;
		if (EMAIL_CATEGORY_AGENT.equals(emailCategory) && exceptionEmailState.attachAgentToMarket()) {
			FileOutputStream fos = null;
			try {
				CollateralDocument document = CollateralDocumentUtil.getCollateralDocument(exceptionEmail);
				agentEmailFile = new File(document.getFileNameWithExt());
				fos = new FileOutputStream(agentEmailFile);
				fos.write(document.getFileContent().getFileContent());
			} catch (IOException e) {
				logger.error("Something went wrong sending BIR exception email", e);
			} finally {
				if (fos != null) {
					try {
						fos.close();
					} catch (IOException e) {
						logger.error("Error closing FileOutputStream agent email", e);
					}
				}
			}
		}
		return agentEmailFile;
	}

	protected Set<String> getExternalAgentEmail(Map<Long, BIRCollateralDetailsDTO> collateralDetailsMap) {
		Set<String> externalAgentEmailSet = new HashSet<String>();
		Iterator<BIRCollateralDetailsDTO> collateralDetailsIter = collateralDetailsMap.values().iterator();
		while (collateralDetailsIter.hasNext()) {
			Long collateralRid = collateralDetailsIter.next().getCollateralRid();
			if (collateralRid != null) {
				Collection<LoanData> loans = loanService.findActiveByCollateralRid(collateralRid);
				for (LoanData loanData : loans) {
					if (LoanType.EXTERNALLY_AGENTED.getDisplayName().equalsIgnoreCase(loanData.getLoanType())
							&& loanData.isPrimary()) {
						externalAgentEmailSet.add(loanData.getAgentLeadBankEmail());

					}

				}
			}
		}
		return externalAgentEmailSet;

	}


	protected EmailTemplate getExceptionEmailTemplate(AbstractExceptionEmailState exceptionEmailState,
													  String emailCategory) {
		EmailTemplateRulerequest emailTemplateRuleRequest = new EmailTemplateRulerequest();
		emailTemplateRuleRequest.setWorflowStepId(exceptionEmailState.getName());
		emailTemplateRuleRequest.setEmailCategory(emailCategory);
		EmailTemplate emailTemplate = emailTemplateRetrievalService.findEmailTemplate(emailTemplateRuleRequest);
		if (emailTemplate == null) {
			throw new RuntimeException("No email template found for workflow step=" +
					exceptionEmailState.getName() + ", email category=" + emailCategory);
		}
		return emailTemplate;
	}

	protected Set<String> getMarketEmailAddresses(Map<Long, BIRCollateralDetailsDTO> collateralDetailsMap) {
		Set<String> marketEmailSet = new HashSet<String>();
		Iterator<BIRCollateralDetailsDTO> collateralDetailsIter = collateralDetailsMap.values().iterator();
		while (collateralDetailsIter.hasNext()) {
			Long collateralRid = collateralDetailsIter.next().getCollateralRid();
			Collateral collateral = collateralRepository.findOne(collateralRid);
			if (collateral != null) {
				String marketEmailAddress = floodEmailService.getMarketEmailToAddress(collateral);
				if (!StringUtils.isEmpty(marketEmailAddress)) {
					marketEmailSet.add(marketEmailAddress);
				}
			}
		}
		return marketEmailSet;
	}


	@Override
	public void releaseCombinedIssueAndCancelLPEmail(List<ProofOfCoverageDTO> lpPoliciesToIssuesWithCancel, Collateral collateral) {
		if (lpPoliciesToIssuesWithCancel != null && lpPoliciesToIssuesWithCancel.size() > 0) {
			try {
				logger.debug("Begin : releaseCombinedIssueAndCancelLPEmail()");

				String toAddress = floodEmailService.getMarketEmailToAddress(collateral);
				if (toAddress != null) {
					EmailDataDto emailDataDto = buildEmailDataDto(lpPoliciesToIssuesWithCancel, collateral);

					EmailTemplateRulerequest emailTemplateRulerequest = new EmailTemplateRulerequest();
					//LOB criteria commented for LCP-3561, release 7.0.5
					//Lender Placement Renewal FIAT Changes Notification
					//emailTemplateRulerequest.setLob(collateral.getPreferredLoan().getLineOfBusiness());
					emailTemplateRulerequest.setStatus("LP_FLOOD_INSURANCE_RENEWAL_FIAT");

					logger.info("\n Searching for email template : " + emailTemplateRulerequest.toString());
					// 2 retrieve the proper email template
					EmailTemplate emailTemplate = emailTemplateRetrievalService.findEmailTemplate(emailTemplateRulerequest);

					if (emailTemplate == null) {
						logger.error("\n Could not find template : " + emailTemplateRulerequest.toString());
						throw new CTracApplicationException("E0115", CtracErrorSeverity.APPLICATION);
					}

					// - 3 populate the email template and send the email
					EmailAttributeHolder marketEmail = getEmailContentByTemplate(emailDataDto, emailTemplate);
					marketEmail.addToAddress(toAddress);
					logger.debug(" releaseLpInitiatedMarketEmail will be sent to : " + marketEmail.getToAddresses());
					marketEmail.getCollateralRids().add(collateral.getRid());

					PerfectionTask marketCancellationEmailTask = openTask(collateral.getRid(),
							WorkflowStateDefinition.SEND_MARKET_LP_ISSUANCE_AND_CANCELLATION_EMAIL.getFloodRemapTaskState());

					floodEmailService.sendInternalEmailThroughEWS(marketEmail);

					closeTask(marketCancellationEmailTask,
							"LP Market Combined Issuance and Cancellation Email Sent for Flood");
				}
				logger.debug("Successfull Confirm of : releaseCombinedIssueAndCancelLPEmail()");
			} catch (Exception e) {
				logger.error(ErrorCodeToMessageConverter.convertToMessage("E0330", CtracErrorSeverity.CRITICAL));
				logger.error("\n  ==============  Error Releasing Lp email:  " + e.getCause().toString(), e);
				throw e;
				// TODO enable exception processing after testing
			}
		}

	}

	EmailDataDto buildEmailDataDto(List<ProofOfCoverageDTO> lpPoliciesToIssuesWithCancel, Collateral collateral){
		return new EmailDataDtoBuilder().buildLpMarketIssueWithCancellationEmailDto(collateral, lpPoliciesToIssuesWithCancel);
	}

	EmailAttributeHolder getEmailContentByTemplate(EmailDataDto emailDataDto, EmailTemplate emailTemplate){
		return CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);
	}

	/**
	 * This method is to construct EFaxMail by combining country code , efax number and JPMC FAX domain.
	 *
	 * @param agentDetails
	 * @return eFAXMail like- 15756757575@jpmchasefax.com
	 */
	private String eFaXEmailAddress(ContactDetailDto agentDetails) {
		String eFAXMail = null;
		if (agentDetails != null && StringUtils.isNotBlank(agentDetails.getFaxNumber())) {
			//Used Regular expression to remove parenthesis and space from EFAX like -  (575) 675-7575
			String eFaxNumber = agentDetails.getFaxNumber().replaceAll("\\D+", "");
			eFAXMail = CtracAppConstants.COUNTRY_CODE + eFaxNumber + env.getRequiredProperty("eFax.domain");
		}
		return eFAXMail;
	}

	@Override
	public void sendLettersReviewEmail() {
		try {
			boolean ctlHeaderPrinted = false;
			boolean nonCTLHeaderPrinted = false;
			StringBuffer message = new StringBuffer();
			String newLine = "<br/>";
			Date currRefDate = calendarDayUtil.getCurrentReferenceDate();
			List<WorkflowDetailsViewData> workflowDetailsViewDataList = workflowDetailsViewRepository.findAllByOrderByCollateralRidAsc();
			if (workflowDetailsViewDataList != null && !workflowDetailsViewDataList.isEmpty()) {
				List<WorkflowDetailsViewData> lettersTasksList = new ArrayList<WorkflowDetailsViewData>();
				for (WorkflowDetailsViewData workflowDetailsViewData : workflowDetailsViewDataList) {
					TaskState taskState = WorkflowStateDefinition.findByWorkflowStep(workflowDetailsViewData.getWorkflowStep()).getFloodRemapTaskState();
					if (taskState instanceof AbstractLetterFloodState &&
							calendarDayUtil.isDateBeforeOrOn(workflowDetailsViewData.getWakeUpDate(), currRefDate, true)) {
						lettersTasksList.add(workflowDetailsViewData);
					}
				}
				if (lettersTasksList != null && !lettersTasksList.isEmpty()) {
					message.append("Review ").append(lettersTasksList.size()).append(" Letter Tasks: ").append(newLine);
					for (WorkflowDetailsViewData workflowDetailsViewData : lettersTasksList) {
						if(workflowDetailsViewData.isCTLLineOfBusiness() && !ctlHeaderPrinted){
							message.append(newLine).append("CTL Letter Tasks:").append(newLine);
							ctlHeaderPrinted = true;
						}
						if(!workflowDetailsViewData.isCTLLineOfBusiness()){continue;}
						
						message.append("Collateral: ").append(workflowDetailsViewData.getCollateralRid().toString());
						if (workflowDetailsViewData.getLineOfBusiness() != null) {
							message.append(", Line of Business: ").append(workflowDetailsViewData.getLineOfBusiness());
						}
						if (workflowDetailsViewData.getProofOfCoverageRid() != null) {
							message.append(", Policy: ").append(workflowDetailsViewData.getProofOfCoverageRid());
						}
						message.append(", ").append(workflowDetailsViewData.getWorkflowStep()).append(newLine);
					}
					
					
					for (WorkflowDetailsViewData workflowDetailsViewData : lettersTasksList) {
						if(!workflowDetailsViewData.isCTLLineOfBusiness() && !nonCTLHeaderPrinted){
							message.append(newLine).append("Non CTL Letter Tasks:").append(newLine);
							nonCTLHeaderPrinted = true;
						}
						if(workflowDetailsViewData.isCTLLineOfBusiness()){continue;}
						
						message.append("Collateral: ").append(workflowDetailsViewData.getCollateralRid().toString());
						if (workflowDetailsViewData.getLineOfBusiness() != null) {
							message.append(", Line of Business: ").append(workflowDetailsViewData.getLineOfBusiness());
						}
						if (workflowDetailsViewData.getProofOfCoverageRid() != null) {
							message.append(", Policy: ").append(workflowDetailsViewData.getProofOfCoverageRid());
						}
						message.append(", ").append(workflowDetailsViewData.getWorkflowStep()).append(newLine);
					}
				} else {
					message.append(newLine).append("There are no letter tasks to review today.");
				}
			} else {
				message.append(newLine).append("There are no letter tasks to review today.");
			}
			String subject = "Review Letter Tasks";
			emailAlertSender.sendAlertEmailToFloodTeam(subject, message.toString(), Importance.Normal);
		} catch (Exception e) {
			logger.error("\n  ==============  Error sending Letters Review email");
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	public void sendMarketHoldEmail(PerfectionTask perfectionTask) {
		HoldWorkItem holdWorkItem = holdWorkItemRepository.findOne(perfectionTask.getWorkItem().getRid());
		List<HoldDetailsViewDto> holdDetailsViewDtos = holdService.getHoldDetailsViewDtos(holdWorkItem);
		long collateralId = holdDetailsViewDtos.get(0).getCollateralRid();
		Set<String> marketEmailSet = new HashSet<String>();
		String toAddress = floodEmailService.getMarketEmailToAddress(collateralRepository.findOne(collateralId));
		if (toAddress != null) {
			Collateral collateral = collateralRepository.findOne(collateralId);
			EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
			emailAttributeHolder.addToAddress(toAddress);
			EmailTemplate emailTemplate = emailTemplateRepository.findByEmailTemplateId("HOLDME");
			if (emailTemplate == null) {
				logger.error("\n Could not find template : HOLDME");
				throw new CTracApplicationException("E0115", CtracErrorSeverity.APPLICATION);
			}
			EmailDataDtoBuilder emailDataDtoBuilder = new EmailDataDtoBuilder();
			EmailDataDto emailDataDto = emailDataDtoBuilder.buildMarketHoldEmailDto(holdDetailsViewDtos, holdWorkItem, collateral);
			EmailAttributeHolder holdEmail = CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);
			holdEmail.getCollateralRids().add(collateralId);
			marketEmailSet.add(toAddress);
			holdEmail.setToAddresses(marketEmailSet);
			floodEmailService.sendInternalEmailThroughEWS(holdEmail);

		}
	}

	@Override
	public void sendLeadbankEmails(PerfectionTask perfectionTask, TaskState currentTaskState) {
		if (!(currentTaskState instanceof AbstractLeadBankEmailState)) {
			throw new RuntimeException("Invalid workflow step for sendBIRExceptionEmails:" + currentTaskState.getName());
		}
		AbstractLeadBankEmailState exceptionEmailState = (AbstractLeadBankEmailState) currentTaskState;
		EmailTemplate emailTemplate = emailTemplateRepository.findByEmailTemplateId("EXTAGT");
		//send one email for each collateral
		EmailDataDto emailDataDto = new EmailDataDto();
		InsuranceRenewalItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), InsuranceRenewalItem.class);
		ProofOfCoverage proofOfCoverage = workItem.getProofOfCoverage();
		emailDataDto.setInsuredName(proofOfCoverage.getInsuredName());
		emailDataDto.setPolicyNumber(proofOfCoverage.getPolicyNumber());
		emailDataDto.setPolicyExpirationDate(DateConverter.convert(proofOfCoverage.getExpirationDate()));
		List<CollateralInsuranceViewData> collateralInsuranceViewDataList = collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverage.getRid());
		Iterator<CollateralInsuranceViewData> collateralDetailsIter = collateralInsuranceViewDataList.iterator();
		while (collateralDetailsIter.hasNext()) {
			CollateralInsuranceViewData collateralDetails = collateralDetailsIter.next();
			setCollateralInfo(emailDataDto, collateralDetails);
			EmailAttributeHolder agentEmail = CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);
			agentEmail.getCollateralRids().add(collateralDetails.getCollateral().getRid());
			Set<String> marketEmailSet = new HashSet<String>();
			String marketEmail = floodEmailService.getMarketEmailToAddress(collateralRepository.findOne(collateralDetails.getCollateral().getRid()));
			if(marketEmail!= null) {
                marketEmailSet.add(marketEmail);
                agentEmail.setCcAddresses(marketEmailSet);
            }
			agentEmail.setToAddresses(emailDataDto.getToAddresses());
			agentEmail.setSubject(exceptionEmailState.getEmailSequence().getDisplayValue() + " " + agentEmail.getSubject());
			floodEmailService.sendEmail(agentEmail);
		}

	}

	@Override
	public void sendCoverageGapReportEmail() {
		String subject = "Required Flood Coverage Gap Report " + DATE_FORMATTER.print(calendarDayUtil.getCurrentReferenceDate());
		String emailBody = "Attached please find this week's Required Flood Coverage Gap Report.";
		List<CoverageGapReportViewData> coverageGapReportData = coverageGapReportViewRepository.findAll();
		File attachment = coverageGapReportUtil.createCoverageGapReportAttachment(coverageGapReportData);
		if(attachment != null) {
            List<File> attachments = new ArrayList<>();
            attachments.add(attachment);
            emailAlertSender.sendEmailToFloodTeam(subject, emailBody, attachments);
        }
	}

	private void setCollateralInfo(EmailDataDto emailDataDto, CollateralInsuranceViewData collateralDetails) {
		ArrayList<CollateralDto> collateralList = new ArrayList<CollateralDto>();
		Set<String> agentEmailSet = new HashSet<String>();
		CollateralDto collateralDto = collateralManagementService.getCollateralDto(collateralDetails.getCollateral().getRid());
		emailDataDto.setCollateralID(collateralDto.getRid().toString());
		emailDataDto.setTaskUniqueID(collateralDto.getRid().toString());
		agentEmailSet.add(collateralDto.getPrimaryLoan().getAgentLeadBankEmail());
		emailDataDto.setToAddresses(agentEmailSet);
		collateralList.add(collateralDto);
		emailDataDto.setLoanDataList(collateralDto.getLoansData());
		emailDataDto.setCollateralList(collateralList);
		emailDataDto.setBorrowerName(collateralDto.getPipeSeparatedPrimaryLoanBorrowerNames());
	}

	private PerfectionTask openTask(Long collateralRid, TaskState taskState) {
		CollateralItem collateralItem = collateralWorkflowService.createCollateralWorkItem(collateralRid, PerfectionItemSubType.POLICY);
		collateralItem.setPerfectionType(PerfectionItemType.FLOOD_POLICY.name());
		return perfectionTaskService.createTransientTask(collateralItem, taskState, TMTaskType.FLOOD_INSURANCE, null);
	}

	private void closeTask(PerfectionTask perfectionTask, String comments) {
		perfectionTaskService.closeTask(perfectionTask, null, null, comments);
	}
}




