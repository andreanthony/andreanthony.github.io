package com.jpmorgan.cib.wlt.ctrac.service.filebucket;



import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FileItem;



/**
 * This  class is a cache to temporarily hold all email attachments for all email
 * each attachment has a unique identifier called taskUUId which could be the task UID for instance 
 *
 */
public interface EmailAttachmentsBucket {

	/**
	 * 
	 * @param attachment a set of attachments for an email being processed
	 * add the attachments to the customer session effectively replacing entry 
	 * with the same key if any
	 */
	public abstract void pushEmailAttachments(EmailAttachments attachment);

	/**
	 * Remove and return the attachments mapped to given key
	 * @param taskUUId :
	 * @return the attachments :
	 */
	public abstract EmailAttachments popEmailAttachments(String taskUUId);

	/**
	 * reinitialize the email bucket for the task
	 */
	public abstract void clear(String taskUUId);
	
	
	/**
	 * Optionally remove and return a single file f from the bucket with key @taskUUId so that f.getName()=name; 
	 * null if is returned no such element exist
	 */
	public abstract FileItem removeFile(String taskUUId, String fileName);


}