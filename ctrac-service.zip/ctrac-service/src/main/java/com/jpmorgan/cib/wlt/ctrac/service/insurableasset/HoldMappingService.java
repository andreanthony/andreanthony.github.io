package com.jpmorgan.cib.wlt.ctrac.service.insurableasset;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;

import java.util.Collection;

public interface HoldMappingService {
    void mapHoldsToCoverageDetails(Collection<RequiredCoverageDTO> requiredCoverageDTOs);

    void mapCoverageDetailsToHold(Collection<RequiredCoverageDTO> requiredCoverageDTOs);
}
