package com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;

public class UserEntitlementsData implements Serializable {
	private String sid;
	private String firstName;
	private String lastName;	
	private boolean userExists;
	
	private List<LookUpCode> profiles;
	private List<String> existingProfiles;
	/**
	 * 
	 */
	private static final long serialVersionUID = 8388074807629316118L;
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public List<LookUpCode> getProfiles() {
		return profiles;
	}
	public void setProfiles(List<LookUpCode> profiles) {
		this.profiles = profiles;
	}
	public List<String> getExistingProfiles() {
		return existingProfiles;
	}
	public void setExistingProfiles(List<String> existingProfiles) {
		this.existingProfiles = existingProfiles;
	}
	
	
	public Set <String> getProfilesOptions(){
		return getAllOptionsAsSetFromList(profiles ,"code");
	}
	public Set <String> getProfilesDescriptions(){
		return getAllOptionsAsSetFromList(profiles ,"description");
	}
	private Set <String> getAllOptionsAsSetFromList( List<LookUpCode> input, String accessKeyType ){
		SortedSet <String> response = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		if(input!=null){
			for(LookUpCode entry :input ){
				if("description".equalsIgnoreCase(accessKeyType)){
					response.add(entry.getDescription());
				}
				if("code".equalsIgnoreCase(accessKeyType)){
					response.add(entry.getCode());
				}
				
			}
		}
		return response;
	}
	
	public boolean isUserExists() {
		return userExists;
	}
	public void setUserExists(boolean userExists) {
		this.userExists = userExists;
	}
	

}
