package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.SelectOption;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.*;

public class RequiredCoverageSourceDto extends BaseDto  implements Serializable,Cloneable{

    
    /**
     * 
     */
    private static final long serialVersionUID = 1385236014094281783L;

    private static final Logger logger = Logger.getLogger(RequiredCoverageDTO.class);

    private Long rid;
    
    private Collection<CollateralDocument> coverageSourceDocuments;

    private RequiredCoverageSourceDto loadTimeValue;
    
    //private Collection<Long> coverageSourceDocumentIds;
    
    private String source;
    
    private String status;
    
    private String insuranceType;
    
    private String propertyType;
    
    private String documentDate;
    
    private String cancellationEffectiveDate;
    
    private Collection<RequiredCoverageDTO> requiredCoverageDTOs;
    
    private String reqdCovSameAsOPB;
    
    private String excessRequired;
    
    private String outstandingPrincipleBalance;

    private List<SelectOption> propertyTypes;

    private List<LookUpCode> holdTypes ;

    private List<LookUpCode> holdPeriods;

    public List<SelectOption> getPropertyTypes() {
        return propertyTypes;
    }

    public void setPropertyTypes(List<SelectOption> propertyTypes) {
        this.propertyTypes = propertyTypes;
    }

    /**
     * @return the rid
     */
    public Long getRid() {
        return rid;
    }


    /**
     * @return the source
     */
    public String getSource() {
        return source;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @return the insuranceType
     */
    public String getInsuranceType() {
        return insuranceType;
    }

    /**
     * @return the propertyType
     */
    public String getPropertyType() {
        return propertyType;
    }

    /**
     * @param rid the rid to set
     */
    public void setRid(Long rid) {
        this.rid = rid;
    }



    /**
     * @param source the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @param insuranceType the insuranceType to set
     */
    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    /**
     * @param propertyType the propertyType to set
     */
    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }


    /**
     * @return the documentDate
     */
    public String getDocumentDate() {
        return documentDate;
    }

    /**
     * @param documentDate the documentDate to set
     */
    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

    /**
     * @return the requiredCoverageDTOs
     */
    public Collection<RequiredCoverageDTO> getRequiredCoverageDTOs() {
        return requiredCoverageDTOs;
    }

    /**
     * @param requiredCoverageDTOs the requiredCoverageDTOs to set
     */
    public void setRequiredCoverageDTOs(List<RequiredCoverageDTO> requiredCoverageDTOs) {
        this.requiredCoverageDTOs = requiredCoverageDTOs;
    }

	public Collection<CollateralDocument> getCoverageSourceDocuments() {
		return coverageSourceDocuments;
	}
	
	public CollateralDocument getCoverageSourceDocumentsByRid(Long covRid){
		
		for(CollateralDocument coverageSourceDocument: coverageSourceDocuments){
			if(covRid.equals(coverageSourceDocument.getRequiredCoverageSource().getRid())){
				return coverageSourceDocument;
			}
		}
		
		return null;
	}

    public boolean hasChanged() {
        if (this.loadTimeValue == null || this.getRid() == null) {
            return true;
        }
        return !deepEquals(this.loadTimeValue);
    }

    public boolean deepEquals(Object obj){
        if(this == obj)
            return true;
        if(obj == null)
            return false;
        if(getClass() != obj.getClass())
            return false;
        RequiredCoverageSourceDto other = (RequiredCoverageSourceDto) obj;

        if(!StringUtils.equals(getInsuranceType(), other.getInsuranceType())){
            return false;
        }
        if(!StringUtils.equals(getSource(), other.getSource())){
            return false;
        }
        if(!StringUtils.equals(getDocumentDate(), other.getDocumentDate())){
            return false;
        }
        if(!StringUtils.equals(StringUtils.stripToNull(getCancellationEffectiveDate()), StringUtils.stripToNull(other.getCancellationEffectiveDate()))){
            return false;
        }
        if(!StringUtils.equals(getReqdCovSameAsOPB(), other.getReqdCovSameAsOPB())){
            return false;
        }
        if(!StringUtils.equals(getExcessRequired(), other.getExcessRequired())){
            return false;
        }
        if(!StringUtils.equals(StringUtils.stripToNull(getOutstandingPrincipleBalance()), StringUtils.stripToNull(other.getOutstandingPrincipleBalance()))){
            return false;
        }
        if(getCoverageSourceDocumentIds()!=null) {
            if(other.getCoverageSourceDocumentIds()==null) {
                return false;
            }
            else {
                if (!(getCoverageSourceDocumentIds().containsAll(other.getCoverageSourceDocumentIds())
                        && other.getCoverageSourceDocumentIds().containsAll(getCoverageSourceDocumentIds()))
                        && !(getCoverageSourceDocumentIds().size() == 0 && other.getCoverageSourceDocumentIds().size() == 0)) {
                    return false;
                }
            }
        } else {
            if (other.getCoverageSourceDocumentIds() != null) {
                return false;
            }
        }

        return true;
    }

    public void saveACopy() {
        try {
            this.loadTimeValue = (RequiredCoverageSourceDto) this.clone();
        } catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
        }
    }


	public Collection<Long> getCoverageSourceDocumentIds() {
			Set<Long> coverageSourceDocumentIds = new HashSet<Long>();
			if( coverageSourceDocuments!= null && !coverageSourceDocuments.isEmpty()){
				for(CollateralDocument coverageSourceDocument: coverageSourceDocuments){
					coverageSourceDocumentIds.add(coverageSourceDocument.getRid());
				}
			}
		return coverageSourceDocumentIds;
	}


	public void setCoverageSourceDocuments(Collection<CollateralDocument> coverageSourceDocuments, Boolean override) {
		
		Collection<CollateralDocument> deproxList = new HashSet<CollateralDocument>();
		
		for(CollateralDocument coverageSourceDocument:coverageSourceDocuments){
			CollateralDocument oneDocument = CtracBaseEntity.deproxy(coverageSourceDocument, CollateralDocument.class);
			deproxList.add(oneDocument);
		}
		coverageSourceDocuments.clear();
		coverageSourceDocuments.addAll(deproxList);
		
		if(override){
			this.coverageSourceDocuments = deproxList;
			return;
		}
		
		if(this.coverageSourceDocuments==null){
			this.coverageSourceDocuments = new ArrayList<CollateralDocument>();
		}
		this.coverageSourceDocuments.addAll(deproxList);
	}
	
	public String getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}

	public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}


	public String getReqdCovSameAsOPB() {
		return reqdCovSameAsOPB;
	}


	public void setReqdCovSameAsOPB(String reqdCovSameAsOPB) {
		this.reqdCovSameAsOPB = reqdCovSameAsOPB;
	}


	public String getExcessRequired() {
		return excessRequired;
	}


	public void setExcessRequired(String excessRequired) {
		this.excessRequired = excessRequired;
	}


	public String getOutstandingPrincipleBalance() {
		return outstandingPrincipleBalance;
	}


	public void setOutstandingPrincipleBalance(String outstandingPrincipleBalance) {
		this.outstandingPrincipleBalance = outstandingPrincipleBalance;
	}

    public List<LookUpCode> getHoldTypes() {
        return holdTypes;
    }

    public void setHoldTypes(List<LookUpCode> holdTypes) {
        this.holdTypes = holdTypes;
    }

    public List<LookUpCode> getHoldPeriods() {
        return holdPeriods;
    }

    public void setHoldPeriods(List<LookUpCode> holdPeriods) {
        this.holdPeriods = holdPeriods;
    }

}
