package com.jpmorgan.cib.wlt.ctrac.service.aggregate.impl;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.COLLECT_WIRE_CONFIRMATION_SCREEN_ID;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.COLLECT_WIRE_CONFIRMATION;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CREATE_REFUND_REQUEST;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CREATE_WIRE_REQUEST;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.LOB_EMAIL_LP_PREMUIM_PAID;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.PENDING_SEND_LOB_EMAIL_LP_PREMUIM_PAID;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.jpmorgan.cib.wlt.ctrac.service.dto.view.CollateralMainDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProvidedCoverageDetailsViewDto;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LpInsuranceVendor;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PaymentType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyPayor;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProcessType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProofOfCoverageWorkItemRelationType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskRelationType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ProofOfCoverageDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.WorkflowMainDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AccountWireReference;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AggregateItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WiredPolicy;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItemRelation;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.WiredPolicyRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AccountWireReferenceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AggregateItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageDetailsViewRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.WorkItemRelationRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.WorkItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.WorkflowMainDetailsViewRepository;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.WorkItemAndRelationsService;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.AggregateKey;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.AggregatedWorkItemService;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.CollectWireConfirmationData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.LenderPlaceAndWireItemRelationDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.WireRequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AccountWireReferenceDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CtracBaseHelperData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.PrimaryLoanBorrowerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.insuranceagency.InsuranceAgencyFactory;
import com.jpmorgan.cib.wlt.ctrac.service.insuranceagency.InsuranceAgencyStrategy;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.StateToBeAggregated;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;

@Service(value = "wireProcessingService")
public class WireProcessingServiceImpl implements WireProcessingService {

	private static final Logger logger = Logger.getLogger(WireProcessingServiceImpl.class);

	@Autowired private AccountWireReferenceRepository accountWireReferenceRepository;
	@Autowired private AggregateItemRepository aggregateItemRepository;
	@Autowired private AggregatedWorkItemService aggregatedWorkItemService;
	@Autowired private BusinessDayUtil businessDayUtil;
	@Autowired private LoanManagementService loanManagementService;
	@Autowired private MessageSource messageSource;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	@Autowired private TaskService taskService;
	@Autowired private WiredPolicyRepository wiredPolicyRepository;
	@Autowired private WorkItemAndRelationsService workItemAndRelationsService;
	@Autowired private WorkItemRelationRepository workItemRelationRepository;
	@Autowired private WorkflowMainDetailsViewRepository workflowMainDetailsViewRepository;
	@Autowired private WorkItemRepository workItemRepository;
	@Autowired private ProofOfCoverageDetailsViewRepository proofOfCoverageDetailsViewRepository;
	@Autowired private ViewDataRetrievalService viewDataRetrievalService;
	@Autowired private InsuranceMngtService insuranceMngtService;
	@Autowired @Qualifier("TMService") private TMService tmService;
    @Autowired private PerfectionTaskService perfectionTaskService;


	@Override
	@Transactional( readOnly = true)
	public WireRequestData prepareCreateWireRequestPage(TMParams TMParams) {
		logger.debug("processResearchResponseSave:: start");
		WireRequestData wireRequestData = new WireRequestData();

		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(TMParams.getId_task());
		wireRequestData.setWorkFlowStep(perfectionTask.getWorkflowStep());
		wireRequestData.setPageTitle(CREATE_WIRE_REQUEST.getName().equals(perfectionTask.getWorkflowStep()) ?
				messageSource.getMessage("create.wire.request.header", null, null) :
				messageSource.getMessage("create.refund.request.header", null, null));

		AggregateItem wireRequestItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), AggregateItem.class);
		wireRequestData.setPerfectionTaskId(wireRequestItem.getRid());
		wireRequestData.setAccountWireReferences(getAccountWireReferenceDTOs(wireRequestItem));
		return wireRequestData;
	}

	@Override
	@Transactional(readOnly = false)
	public void processWireRequestInformation(WireRequestData wireRequestData) {
		if (wireRequestData == null) {
			logger.error("No form data received for submitting wire request.");
			throw new CTracApplicationException("E0166", CtracErrorSeverity.APPLICATION);
		}

		TaskRelationType parentToChildRelation = TaskRelationType.WIRETOPOLICY;
		List<AccountWireReferenceDto> accountWireReferencesDtos = wireRequestData.getAccountWireReferences();
		AccountWireReference acctRef = null;
		for (AccountWireReferenceDto accountWireReferencesDto : accountWireReferencesDtos) {
			acctRef = accountWireReferenceRepository.findOne(accountWireReferencesDto.getAccountWireReferenceId());
			acctRef.setRequestNumber(accountWireReferencesDto.getRequestNumber());
			acctRef = accountWireReferenceRepository.save(acctRef);
		}

		//set different task event based on different aggregated task
		TMParams TMParams = wireRequestData.getTmParams();
		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(TMParams.getId_task());
		if (CREATE_WIRE_REQUEST.getName().equals(perfectionTask.getWorkflowStep())) {
			parentToChildRelation = TaskRelationType.WIRETOPOLICY;
		} else if(CREATE_REFUND_REQUEST.getName().equals(perfectionTask.getWorkflowStep())) {
			parentToChildRelation = TaskRelationType.REFUNDTOPOLICY;
		}
		processAggregateItem(perfectionTask, parentToChildRelation, TMParams);
	}

	private void processAggregateItem(PerfectionTask perfectionTask,
									  TaskRelationType parentToChildRelation, TMParams TMParams) {
		logger.debug("processAggregateItem: BEGIN");
		processItem(perfectionTask, TMParams);

		WorkflowStateDefinition childWorkflowStep = null;
		if (TaskRelationType.WIRETOPOLICY == parentToChildRelation) {
			childWorkflowStep = WorkflowStateDefinition.PENDING_CREATE_WIRE_REQUEST;
		} else if (TaskRelationType.REFUNDTOPOLICY == parentToChildRelation) {
			childWorkflowStep = WorkflowStateDefinition.PENDING_CREATE_REFUND_REQUEST;
		} else {
			logger.debug("this aggregate item has no defined child workflow step");
			return;
		}

		List<WorkItemRelation> childRelations = workItemRelationRepository.findByParentWorkItemAndRelationType(
				perfectionTask.getWorkItem(), parentToChildRelation.name());
		for (WorkItemRelation childRelation : childRelations) {
			WorkItem child = childRelation.getChildWorkItem();
			List<PerfectionTask> childTasks = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(child,
					childWorkflowStep.getName(), TaskStatus.TRANSIENT.name());
			for (PerfectionTask childTask : childTasks) {
				processItem(childTask, TMParams);
			}
		}
		logger.debug("processAggregateItem: END");
	}

	private void processItem(PerfectionTask perfectionTask, TMParams TMParams) {
		CtracBaseHelperData ctracBaseHelperData = new CtracBaseHelperData();
		ctracBaseHelperData.setWorkflowTransitionProcess(ProcessType.MANUAL_PROCESS.getName());
		ctracBaseHelperData.setTmParams(TMParams);
		Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
		inputParameterMap.put(StateParameterType.HELPER_DATA, ctracBaseHelperData);
		inputParameterMap.put(StateParameterType.TM_PARAMS, TMParams);
		inputParameterMap.put(StateParameterType.PERFECTION_TASK, perfectionTask);
		inputParameterMap.put(StateParameterType.WORK_ITEM, perfectionTask.getWorkItem());
		taskService.completeWorkFlowStepOperations(inputParameterMap);
	}

	/**
	 * Prepare dto for collect wire confirmation helper page
	 * @param TMParams
	 * @return
	 */
	@Override
	public CollectWireConfirmationData prepareCollectWireConfirmationData(TMParams TMParams) {
		CollectWireConfirmationData collectWireConfirmationData = new CollectWireConfirmationData();
		collectWireConfirmationData.setTmParams(TMParams);
		collectWireConfirmationData.setNotificationMessage(
				messageSource.getMessage("collectWireConfirmation.notification", null, null));
		collectWireConfirmationData.setScreenId(COLLECT_WIRE_CONFIRMATION_SCREEN_ID);
		return collectWireConfirmationData;
	}

	private List<AccountWireReferenceDto> getAccountWireReferenceDTOs(AggregateItem wireRequestItem) {
		List<AccountWireReference> accountWireReferences =
				accountWireReferenceRepository.findAllAccountWireReferenceByWorkItem(wireRequestItem);
		List<AccountWireReferenceDto> accountWireReferenceDTOs = new ArrayList<AccountWireReferenceDto>();
		for (AccountWireReference acctRef : accountWireReferences) {
			accountWireReferenceDTOs.add(getAccountWireReferenceDTO(wireRequestItem, acctRef));
		}
		return accountWireReferenceDTOs;
	}

	private AccountWireReferenceDto getAccountWireReferenceDTO(
			AggregateItem wireRequestItem, AccountWireReference acctRef) {
		AccountWireReferenceDto accountWireReferenceDTO = new AccountWireReferenceDto();
		accountWireReferenceDTO.setAccountingSystem(acctRef.getAccountingSysRef());
		accountWireReferenceDTO.setCreatedDate(wireRequestItem.getCreatedDate());
		accountWireReferenceDTO.setAccountWireReferenceId(acctRef.getRid());
		accountWireReferenceDTO.setFilename("");
		return accountWireReferenceDTO;
	}

	@Override
	@Transactional
	public byte[] generateWireDocumentByAccountWireReference(
			AccountWireReferenceDto accountWireReferenceDto, String workflowStep) {
		AccountWireReference accountWireReference = accountWireReferenceRepository.findOne(
				accountWireReferenceDto.getAccountWireReferenceId());
		List<WiredPolicy> wiredPolicies = getWiredPolicyByAccountWireReference(accountWireReference);
		InsuranceAgencyStrategy strategy = InsuranceAgencyFactory.getInsuranceAgencyStragegyByWorkItem(wiredPolicies.get(0).getWorkItem());
		return strategy.generateXlsxWireConfirmationDocument(accountWireReferenceDto, wiredPolicies, workflowStep);
	}

	/**main method to create Wire request task and get policies that are in WFSID in Approved Pending wire request
	 *and add the data in  wiredPolciy table and wire ref table. Also creates necessary records in CTRAC and sends an IBML message
	 *to TM
	 *
	 */
	@Override
	@Transactional
	public void processWiredPolicy(PolicyAggregationRequestData aggregationType) {
		logger.info("Inside processWiredPolicy() method");
		List<WorkItem> policiesToBeAggregated =   workItemRepository.findAllByWorkflowStepAndStatus(aggregationType.getChildPolicyState().getName(),TaskStatus.TRANSIENT.name());
		policiesToBeAggregated = getPoliciesToWire(policiesToBeAggregated, aggregationType);

		if (policiesToBeAggregated == null || policiesToBeAggregated.isEmpty()) {
			return;
		}

		Map<AggregateKey, List<WorkItem>> policyMap =
				aggregatedWorkItemService.aggregateWorkItemsByKey(policiesToBeAggregated,
						(StateToBeAggregated) aggregationType.getChildPolicyState().getFloodRemapTaskState());

		AggregateKey keyForStrategy   = new AggregateKey(LoanSystem.STRATEGY.getDescription(),LpInsuranceVendor.ALTHANS);
		List<WorkItem> listStrategyPolicies = policyMap.get(keyForStrategy);
		if (!CollectionUtils.isEmpty(listStrategyPolicies)) {
			Map<AggregateKey, List<WorkItem>> strategyPolicyMap = new HashMap<AggregateKey, List<WorkItem>>();
			strategyPolicyMap.put(keyForStrategy, listStrategyPolicies);
			createWireWorkflowData(aggregationType, strategyPolicyMap);
			policyMap.remove(keyForStrategy);
		}
		if(!MapUtils.isEmpty(policyMap)){
			createWireWorkflowData(aggregationType, policyMap);
		}
	}

	public void createWireWorkflowData(PolicyAggregationRequestData aggregationType,
									   Map<AggregateKey, List<WorkItem>> policyMap) {
		AggregateItem wireRequestItem = createAggregateItem(
				aggregationType.getParentTaskState().getName(),
				aggregationType.getParentPerfetionSubType());

		//workItemAndRelationsService.createRelations(wireRequestItem, policiesToBeAggregated,
		//aggregationType.getParentChildRelationType(), CtracAppConstants.SYSTEM_USER);

		workItemAndRelationsService.createRelations(wireRequestItem, policyMap,
				aggregationType.getParentChildRelationType(), CtracAppConstants.SYSTEM_USER);



		try {
			for (AggregateKey key : policyMap.keySet()) {
				AccountWireReference accountWireReference = new AccountWireReference();
				accountWireReference.setWorkItem(wireRequestItem);
				accountWireReference.setAccountingSysRef(key.getKey());
				accountWireReference.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);
				accountWireReference = accountWireReferenceRepository.save(accountWireReference);
				logger.info("data is saved to accountWireReference with perfection item ID " + accountWireReference.getRid());
				createAndPersistWiredPolicy(policyMap.get(key), accountWireReference, aggregationType, key.getVendor());
			}
			tmService.createTask(TMTaskType.FLOOD_INSURANCE, wireRequestItem,
					aggregationType.getParentTaskState().getFloodRemapTaskState());
			logger.info(" data is saved to accountWireReference with perfection item ID " + wireRequestItem.getRid());
		} catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			// TODO log the exception as fatal are throw back the exception
			logger.error("createNewWireTask failed with error message: " + ex.getMessage(), ex);
			throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
		}
	}

	@Override
	@Transactional
	public void processConfirmedWiredRequest() {
		logger.info("process confirmed wired request.");
		LenderPlaceAndWireItemRelationDto lpAndWireItemRelationDto =
				getPoliciesByCollateralProperty(getLenderPlaceItemsInCWC());
		Map<Long, List<LenderPlaceItem>> lenderPlaceItemsByAddress =
				lpAndWireItemRelationDto.getMatchedPolicyMap();

		logger.debug("For matched policies create new parent wire item and save the relationship.");
		for (Long addressRid : lenderPlaceItemsByAddress.keySet()) {
			List<LenderPlaceItem> policiesToProcess = lenderPlaceItemsByAddress.get(addressRid);
			createPropertyItemAndProcessPolicies(addressRid, policiesToProcess);
		}
	}

	@Override
	@Transactional
	public void processPendingSendLOBEmailForAlthans() {
		logger.info("BEGIN::processPendingSendLOBEmailForAlthans");
		List<? extends WorkItem> lenderPlaceItems = getAlthansLPItemsInPendingEmail();
		Map<AggregateKey, List<WorkItem>> policyMap =

				aggregatedWorkItemService.aggregateWorkItemsByKey(lenderPlaceItems,
						(StateToBeAggregated) PENDING_SEND_LOB_EMAIL_LP_PREMUIM_PAID.getFloodRemapTaskState());

		logger.debug("For matched policies create new parent wire item and save the relationship.");
		for (Entry<AggregateKey, List<WorkItem>> propertyEntry : policyMap.entrySet()) {
			createPropertyItem(propertyEntry.getValue(), TMTaskType.FLOOD_INSURANCE);//TODO: pick correct TMTaskType?
		}
		logger.info("END::processPendingSendLOBEmailForAlthans");
	}

	private List<LenderPlaceItem> getLenderPlaceItemsInCWC() {
		List<String> taskStatus = new ArrayList<String>();
		taskStatus.add("OPEN");
		taskStatus.add("SLEEPING");
		List<PerfectionTask> allTasksInCWC = perfectionTaskRepository.findByWorkflowStepAndTaskStatusIn(COLLECT_WIRE_CONFIRMATION.getName(), taskStatus);

		List<LenderPlaceItem> lenderPlaceItemsInCWC = new ArrayList<LenderPlaceItem>();
		for (PerfectionTask task : allTasksInCWC) {
			WorkItem workItem = CtracBaseEntity.deproxy(task.getWorkItem(), WorkItem.class);
			if (workItem instanceof LenderPlaceItem) {
				lenderPlaceItemsInCWC.add((LenderPlaceItem) workItem);
			}
		}
		return lenderPlaceItemsInCWC;
	}

	List<LenderPlaceItem> getAlthansLPItemsInPendingEmail() {
		List<String> taskStatus = new ArrayList<String>();
		taskStatus.add(TaskStatus.TRANSIENT.name());
		List<PerfectionTask> allEmailTasks = perfectionTaskRepository.findByWorkflowStepAndTaskStatusIn(
				PENDING_SEND_LOB_EMAIL_LP_PREMUIM_PAID.getName(), taskStatus);
		List<LenderPlaceItem> lenderPlaceItemsInPendingEmail = new ArrayList<LenderPlaceItem>();
		for (PerfectionTask task : allEmailTasks) {
			WorkItem workItem = CtracBaseEntity.deproxy(task.getWorkItem(), WorkItem.class);
			if (workItem instanceof LenderPlaceItem && LpInsuranceVendor.ALTHANS.getDisplayName().equals(workItem.getProofOfCoverageForItemType(
					ProofOfCoverageWorkItemRelationType.LENDERPLACEMENT_TO_POLICY).getInsuranceAgency())) {
				lenderPlaceItemsInPendingEmail.add((LenderPlaceItem) workItem);
			}
		}
		return lenderPlaceItemsInPendingEmail;
	}

	@Override
	public AggregateItem createAggregateItem(String wflsId, PerfectionItemSubType perfectionItemSubType) {
		AggregateItem wireProcessItem = new AggregateItem();
		wireProcessItem.setPerfectionType(PerfectionItemType.AGGREGATE_ITEM.name());
		wireProcessItem.setPerfectionSubType(perfectionItemSubType.name());
		wireProcessItem.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);
		Date createDate = businessDayUtil.getCurrentReferenceDate();
		wireProcessItem.setInitiationDate(createDate);
		wireProcessItem.setCreatedDate(createDate);
		return aggregateItemRepository.save(wireProcessItem);
	}

	/**
	 * Filter out the policies from a list that will not met the condition to create a wire / refund request for
	 * and return the complete list of all policies where wired policy will be created for
	 * @param policies
	 * @param
	 *
	 * @return List of policies to wire
	 */
	List<WorkItem> getPoliciesToWire(List<WorkItem> policies, PolicyAggregationRequestData aggregationType){
		List<WorkItem> workItemsFiltered = new ArrayList<>();
		if(CollectionUtils.isEmpty(policies)){
			return policies;
		}

		//Loop over all the Policies
		for (WorkItem workItem : policies) {
			if (WorkflowStateDefinition.CREATE_WIRE_REQUEST.equals(aggregationType.getParentTaskState()) ||
					insuranceMngtService.isWireRefundNeeded(workItem)) {
				workItemsFiltered.add(workItem);
			}else{
				//Get the Approved Request task for the policy and abort the workflow for that policy as we will not be including it in the create refund request
				List<PerfectionTask> perfectionTasks =
						perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(
								workItem, aggregationType.getChildPolicyState().getName(), TaskStatus.TRANSIENT.name());
				if (CollectionUtils.isNotEmpty(perfectionTasks)) {
					for (PerfectionTask perfectionTask : perfectionTasks) {
						Map<StateParameterType, Object> inputParameterMap = new HashMap<>();
						inputParameterMap.put(StateParameterType.WORK_ITEM, perfectionTask.getWorkItem());
						taskService.abortWorkflow(inputParameterMap, "No refund wire Should be created - No previous Wire Request exist");
					}
				}
			}
		}
		return workItemsFiltered;
	}

	/**
	 * Create records in WiredPolciy table that are in WFSID Approved for Wire Request and
	 * transit the WFSID of the policies to Pending Create Wire Request in sleeping state
	 * @return void
	 */
	public void createAndPersistWiredPolicy(List<WorkItem> policyByLoanSystem,
											AccountWireReference accountWireReference, PolicyAggregationRequestData aggregationType, LpInsuranceVendor vendor) {

		for (WorkItem workItem : policyByLoanSystem) {
			WiredPolicy wiredPolicy = new WiredPolicy();
			PrimaryLoanBorrowerViewDto primaryLoanBorrowerData=null;
			String loanSystem = null;
			ProofOfCoverageDetailsViewData proofOfCoverageDetailsViewData =null;
			ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto = null;
			CollateralMainDetailsViewDto collateralMainDetailsViewDto=null;
			List<WorkflowMainDetailsViewData> workflowDataList = workflowMainDetailsViewRepository.findByWorkItemRid(workItem.getRid());
			Long proofOfCoverageRid = null;
			for(WorkflowMainDetailsViewData workflowData : workflowDataList){
				primaryLoanBorrowerData = viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(workflowData.getCollateralRid());
				proofOfCoverageRid = workflowData.getProofOfCoverageRid();
				proofOfCoverageDetailsViewData = proofOfCoverageDetailsViewRepository.findByProofOfCoverageRid(proofOfCoverageRid);
				collateralMainDetailsViewDto=viewDataRetrievalService.getCollateralMainDetails(workflowData.getCollateralRid());
				providedCoverageDetailsViewDto = viewDataRetrievalService.getLPProofOfCoverageDetails(workItem.getRid());
				break;
			}
			if (proofOfCoverageDetailsViewData == null) {
				logger.error("no proofOfCoverageDetailsViewData found for rid: " + proofOfCoverageRid);
				throw new CTracApplicationException("E0177", CtracErrorSeverity.CRITICAL);
			}
			workItem = CtracBaseEntity.deproxy(workItem, WorkItem.class);
			if(workItem instanceof LenderPlaceItem){
				LenderPlaceItem lpWorkItem = (LenderPlaceItem)workItem;
				wiredPolicy.setPremuimAmount(lpWorkItem.getPremiumAmount());
				wiredPolicy.setRefundAmount(lpWorkItem.getRefundAmount());
			}
			if(primaryLoanBorrowerData != null){
				//wiredPolicy.setLoanNumber(primaryLoanBorrowerData.getLoanNumber());
				String branchCode = loanManagementService.getBranchCode(primaryLoanBorrowerData.getLoanRid());
				wiredPolicy.setLenderBranch("2127/" + branchCode);
				loanSystem = primaryLoanBorrowerData.getLoanAccountingSystem();
				wiredPolicy.setLoanAcctSystem(primaryLoanBorrowerData.getLoanAccountingSystem());
			}


			if(collateralMainDetailsViewDto!=null){
				wiredPolicy.setCollateralAddress(collateralMainDetailsViewDto.getCollateralAddress());
				wiredPolicy.setCollateralUnit(collateralMainDetailsViewDto.getCollateralUnitBuilding());
				wiredPolicy.setCollateralCity(collateralMainDetailsViewDto.getCollateralCity());
				wiredPolicy.setCollateralState(collateralMainDetailsViewDto.getCollateralState());
				wiredPolicy.setCollateralZip(collateralMainDetailsViewDto.getCollateralZipCode());
			}

			if(providedCoverageDetailsViewDto!=null){
				wiredPolicy.setBuildingName(providedCoverageDetailsViewDto.getBuildingName());
				//wiredPolicy.setCoverageType(providedCoverageDetailsViewDto.getCoverageType());
			}

			wiredPolicy.setAccountWireReference(accountWireReference);
			wiredPolicy.setWorkItem(workItem);
			wiredPolicy.setClientName(proofOfCoverageDetailsViewData.getInsuredName());
			wiredPolicy.setCoverageType(proofOfCoverageDetailsViewData.getCoverageTypeDescription());

			InsuranceAgencyStrategy insuranceAgencyStrategy = InsuranceAgencyFactory.getInsuranceAgencyStragegyByVendorEnum(vendor);
			if(WorkflowStateDefinition.CREATE_WIRE_REQUEST.equals(aggregationType.getParentTaskState())){
				wiredPolicy.setMethodOfPayment(proofOfCoverageDetailsViewData.getInvoicePaymentMethodDescription());
				String paymentReferenceNumber = proofOfCoverageDetailsViewData.getInvoicePaymentAccount();
				//if the method of payment is cost center then hard code ledger
				if (PaymentType.MARKET_COST_CENTER.getName().equals(wiredPolicy.getMethodOfPayment())) {
					wiredPolicy.setGeneralLedger(insuranceAgencyStrategy.getMarketCostCenterGLNumber(loanSystem));
					wiredPolicy.setCostCenter(paymentReferenceNumber);
				} else if (PaymentType.DEPOSIT_ACCOUNT_NUMBER.getName().equals(wiredPolicy.getMethodOfPayment())){
					wiredPolicy.setDdaNumber(paymentReferenceNumber);
				} else if (PaymentType.CASHIERS_CHECK.getName().equals(wiredPolicy.getMethodOfPayment())) {
					wiredPolicy.setRefundMailingAddress(proofOfCoverageDetailsViewData.getInvoicePaymentAddress());
				}else if (PaymentType.APPLY_TO_LOAN.getName().equals(wiredPolicy.getMethodOfPayment())) {
					wiredPolicy.setLoanNumber(paymentReferenceNumber);
				}
			}else{
				wiredPolicy.setMethodOfPayment(proofOfCoverageDetailsViewData.getRefundPaymentMethodDescription());
				String paymentReferenceNumber = proofOfCoverageDetailsViewData.getRefundPaymentAccount();
				//if the method of payment is cost center then hard code ledger
				if (PaymentType.MARKET_COST_CENTER.getName().equals(wiredPolicy.getMethodOfPayment())) {
					wiredPolicy.setGeneralLedger(insuranceAgencyStrategy.getMarketCostCenterGLNumber(loanSystem));
					wiredPolicy.setCostCenter(paymentReferenceNumber);
				} else if (PaymentType.DEPOSIT_ACCOUNT_NUMBER.getName().equals(wiredPolicy.getMethodOfPayment())){
					wiredPolicy.setDdaNumber(paymentReferenceNumber);
				} else if (PaymentType.CASHIERS_CHECK.getName().equals(wiredPolicy.getMethodOfPayment())) {
					wiredPolicy.setRefundMailingAddress(proofOfCoverageDetailsViewData.getRefundPaymentAddress());
				}else if (PaymentType.APPLY_TO_LOAN.getName().equals(wiredPolicy.getMethodOfPayment())) {
					wiredPolicy.setLoanNumber(paymentReferenceNumber);
				}
			}
			wiredPolicy.setPolicyCancellationDate(proofOfCoverageDetailsViewData.getCancellationEffectiveDate());
			//wiredPolicy.setRefundAmount(proofOfCoverageDetailsViewData.getRefundPaymentAmount());
			wiredPolicy.setPolicyEffectiveDay(proofOfCoverageDetailsViewData.getEffectiveDate());
			wiredPolicy.setPolicyExpirationDay(proofOfCoverageDetailsViewData.getExpirationDate());
			wiredPolicy.setPolicyNumber(proofOfCoverageDetailsViewData.getPolicyNumber());
			wiredPolicy.setInitialAuditInfo("SYSTEM");
			wiredPolicy.setPayor(PolicyPayor.BORROWER.getDesc());

			wiredPolicyRepository.save(wiredPolicy);

			insuranceAgencyStrategy.generateBankPortionWiredPolicy(wiredPolicy,aggregationType.getParentTaskState().getName());
			List<PerfectionTask> perfectionTasks =
					perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(
							workItem, aggregationType.getChildPolicyState().getName(), TaskStatus.TRANSIENT.name());
			if (perfectionTasks != null && !perfectionTasks.isEmpty()) {
				for (PerfectionTask perfectionTask : perfectionTasks) {
					Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
					CtracBaseHelperData ctracBaseHelperData = new CtracBaseHelperData();
					ctracBaseHelperData.setWorkflowTransitionProcess(ProcessType.BATCH_PROCESS.getName());
					inputParameterMap.put(StateParameterType.HELPER_DATA, ctracBaseHelperData);
					inputParameterMap.put(StateParameterType.PERFECTION_TASK, perfectionTask);
					inputParameterMap.put(StateParameterType.WORK_ITEM, perfectionTask.getWorkItem());
					taskService.completeWorkFlowStepOperations(inputParameterMap);
				}
			}

		}
	}

	private LenderPlaceAndWireItemRelationDto getPoliciesByCollateralProperty(List<LenderPlaceItem> allLenderPlaceItemsInCWC) {
		LenderPlaceAndWireItemRelationDto policyAndWireItemRelation =
				new LenderPlaceAndWireItemRelationDto();
		if (allLenderPlaceItemsInCWC == null) {
			return policyAndWireItemRelation;
		}

		Map<AggregateKey, List<WorkItem>> policyMap =
				aggregatedWorkItemService.aggregateWorkItemsByKey(allLenderPlaceItemsInCWC,
						(StateToBeAggregated) COLLECT_WIRE_CONFIRMATION.getFloodRemapTaskState());

		Map<Long, List<LenderPlaceItem>> matchedLenderPlaceItems =
				new HashMap<Long, List<LenderPlaceItem>>();
		List<LenderPlaceItem> unmatchedLenderPlaceItems = new ArrayList<LenderPlaceItem>();

		for (AggregateKey aggregateKey : policyMap.keySet()) {
			List<WorkItem> childItems = policyMap.get(aggregateKey);
			Long longKey = Long.parseLong(aggregateKey.getKey());
			for (WorkItem childItem : childItems) {
				LenderPlaceItem lenderPlaceItem =
						CtracBaseEntity.deproxy(childItem, LenderPlaceItem.class);
				if (isPolicyWireInfoReceived(lenderPlaceItem)) {
					List<LenderPlaceItem> refArray = matchedLenderPlaceItems.get(longKey);
					if (refArray == null) {
						refArray = new ArrayList<LenderPlaceItem>();
						matchedLenderPlaceItems.put(longKey, refArray);
					}
					refArray.add(lenderPlaceItem);
				} else {
					unmatchedLenderPlaceItems.add(lenderPlaceItem);
				}
			}
		}

		policyAndWireItemRelation.setMatchedPolicyMap(matchedLenderPlaceItems);
		policyAndWireItemRelation.setUnmatchedPolicies(unmatchedLenderPlaceItems);
		return policyAndWireItemRelation;
	}

	private Map<AggregateItem, List<LenderPlaceItem>> createPropertyItemAndProcessPolicies(
			Long addressRid, List<LenderPlaceItem> matchedLenderPlaceItems) {
		Map<AggregateItem, List<LenderPlaceItem>> propertyItems = new HashMap<AggregateItem, List<LenderPlaceItem>>();
		if (matchedLenderPlaceItems == null || matchedLenderPlaceItems.isEmpty()) {
			return propertyItems;
		}
		TMTaskType TMTaskType = processCollectWireConfirmationChildren(matchedLenderPlaceItems);
		AggregateItem propertyItem = createPropertyItem(matchedLenderPlaceItems, TMTaskType);
		propertyItems.put(propertyItem, matchedLenderPlaceItems);
		return propertyItems;
	}

	private AggregateItem createPropertyItem(List<? extends WorkItem> workItems, TMTaskType TMTaskType) {
		AggregateItem propertyItem = createAggregateItem(
				LOB_EMAIL_LP_PREMUIM_PAID.getName(), PerfectionItemSubType.PROPERTY);
		propertyItem.addCollateral(workItems.get(0).getPreferredCollateral());
		propertyItem.setWorkFlowID(workItems.get(0).getWorkFlowID());
		propertyItem = aggregateItemRepository.save(propertyItem);

        perfectionTaskService.createTask(TaskStatus.TRANSIENT, propertyItem,
                WorkflowStateDefinition.LOB_EMAIL_LP_PREMUIM_PAID.getFloodRemapTaskState(), TMTaskType, null, null);
		workItemAndRelationsService.createRelations(propertyItem, workItems,
				TaskRelationType.PROPERTYTOPOLICY, CtracAppConstants.SYSTEM_USER);
		return propertyItem;
	}

	private TMTaskType processCollectWireConfirmationChildren(List<LenderPlaceItem> matchedLenderPlaceItems) {
		TMTaskType tmTaskType = null;
		for (LenderPlaceItem lenderPlaceItem : matchedLenderPlaceItems) {
			try {
				List<String> taskStatuses = new ArrayList<String>();
				taskStatuses.add(TaskStatus.OPEN.name());
				taskStatuses.add(TaskStatus.SLEEPING.name());
				List<PerfectionTask> perfectionTasks = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatusIn(
						lenderPlaceItem, COLLECT_WIRE_CONFIRMATION.getName(), taskStatuses);
				for (PerfectionTask perfectionTask : perfectionTasks) {
					if (tmTaskType == null || tmTaskType != TMTaskType.FLOOD_INSURANCE) {
						tmTaskType = TMTaskType.valueOf(perfectionTask.getTmTaskType());
					}

					Map<StateParameterType, Object> inputParameterMap =
							new HashMap<StateParameterType, Object>();
					CtracBaseHelperData ctracBaseHelperData = new CtracBaseHelperData();
					ctracBaseHelperData.setWorkflowTransitionProcess(ProcessType.BATCH_PROCESS.getName());
					inputParameterMap.put(StateParameterType.PERFECTION_TASK, perfectionTask);
					inputParameterMap.put(StateParameterType.HELPER_DATA, ctracBaseHelperData);
					taskService.completeWorkFlowStepOperations(inputParameterMap);
				}
			} catch (Exception e) {
				logger.debug(e.getMessage(), e);
			}
		}
		return tmTaskType;
	}

	private boolean isPolicyWireInfoReceived(LenderPlaceItem lenderPlaceItem) {
		return lenderPlaceItem.getWireSentDate() != null && !StringUtils.isBlank(lenderPlaceItem.getFedReferenceNumber());
	}

	@Override
	public boolean isPolicyIncludedInAggregateWirePremium(LenderPlaceItem lenderPlaceItem) {
		WorkItemRelation wireRelation  = workItemAndRelationsService.findParentByChildAndRelation(lenderPlaceItem, TaskRelationType.WIRETOPOLICY);
		if(wireRelation != null){
			return true;
		}
		return false;
	}

	@Override
	public List<WiredPolicy> getWiredPolicyByAccountWireReference(AccountWireReference accountWireReference) {
		return wiredPolicyRepository.findByAccountWireReference(accountWireReference);
	}
}
