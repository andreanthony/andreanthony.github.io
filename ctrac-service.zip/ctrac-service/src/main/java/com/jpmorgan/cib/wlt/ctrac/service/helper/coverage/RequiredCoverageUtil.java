package com.jpmorgan.cib.wlt.ctrac.service.helper.coverage;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.RequiredCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.InsurableAssetRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.InsurancePolicyRequirementDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;



public class RequiredCoverageUtil {

    private static final Logger logger = Logger.getLogger(RequiredCoverageUtil.class);
    

    public static boolean isCoverageVerified(RequiredCoverage requiredCoverage){
    	
    	if(requiredCoverage != null && requiredCoverage.getRequiredCoverageSource() != null){
    		return requiredCoverage.getRequiredCoverageSource().isVeried();
    	}
    	return false;
    }
    
    public static boolean isCorrectCoverageType(
            RequiredCoverage requiredCoverage, InsuranceType coverageType) {
        return coverageType.name().equals(requiredCoverage.getRequiredCoverageSource().getInsuranceType());
    }
    
	/**
	 * will decide whether to use the FIAT of the Prior Cov Info
	 * If there is no coverage requirement we assume that there is no coverage needed
	 * @param insurableAsset
	 * @return
	 */
	public static RequiredCoverage getValidCoverageRequirement(InsurableAsset insurableAsset, InsuranceType coverageType){
		
		logger.info(" \n Begin getValidCoverageRequirement()::coverageType : "+coverageType);
		
		List<RequiredCoverage> requiredCoverageList = insurableAsset.getRequiredCoverages();
		if(requiredCoverageList == null){
			return null;
		}
		RequiredCoverage mainCoverage = null;
		//if we have a coverage requirement document of the specified type use it
		Date date = null;
		for(RequiredCoverage requiredCoverage: requiredCoverageList){
			
			if(isCoverageVerified(requiredCoverage) && isCorrectCoverageType(requiredCoverage, coverageType)){
				if(mainCoverage == null){
					mainCoverage = requiredCoverage;
					date = requiredCoverage.getUpdatedDate();
				}else{
					if( date == null || ( requiredCoverage.getUpdatedDate()!=null && requiredCoverage.getUpdatedDate().after(date)) ){
						mainCoverage = requiredCoverage;
						date = requiredCoverage.getUpdatedDate();
					}
				}
			}
		}
		String msg = " \n End getValidCoverageRequirement():: coverage found  ";
		if(mainCoverage==null){
			msg =" \n  End getValidCoverageRequirement():: => Could not find a verified required coverage with source FIAT, assetId "+insurableAsset.getRid();
		}
		logger.info(msg);
		return mainCoverage;	
	}
	
	public static RequiredCoverage getValidCoverageRequirement(InsurableAsset insurableAsset){
		
		logger.info(" \n Begin getValidCoverageRequirement() for insurableAsset:");
		
		List<RequiredCoverage> requiredCoverageList = insurableAsset.getRequiredCoverages();
		if(requiredCoverageList == null){
			return null;
		}
		RequiredCoverage mainCoverage = null;
		//if we have a coverage requirement document of the specified type use it
		Date date = null;
		for(RequiredCoverage requiredCoverage: requiredCoverageList){
			
			if(isCoverageVerified(requiredCoverage)){
				if(mainCoverage == null){
					mainCoverage = requiredCoverage;
					date = requiredCoverage.getUpdatedDate();
				}else{
					if( date == null || ( requiredCoverage.getUpdatedDate()!=null && requiredCoverage.getUpdatedDate().after(date)) ){
						mainCoverage = requiredCoverage;
						date = requiredCoverage.getUpdatedDate();
					}
				}
			}
		}
		String msg = " \n End getValidCoverageRequirement():: coverage found  ";
		if(mainCoverage==null){
			msg =" \n  End getValidCoverageRequirement():: => Could not find a verified required coverage with source FIAT, assetId "+insurableAsset.getRid();
		}
		logger.info(msg);
		return mainCoverage;	
	}
	
	public static BigDecimal getValidCoverageRequirementAmount(Long insurableAssetRid, InsuranceType insuranceType){
		InsurableAssetRepository repo = ApplicationContextProvider.getContext().getBean(InsurableAssetRepository.class);
		InsurableAsset insurableAsset = repo.findOne(insurableAssetRid);
		return getValidCoverageRequirementAmount(insurableAsset, insuranceType);
	}
	
	public static BigDecimal getValidCoverageRequirementAmount(InsurableAsset insurableAsset, InsuranceType insuranceType){
		RequiredCoverage requiredCoverage = getValidCoverageRequirement(insurableAsset, insuranceType);
		if (requiredCoverage == null || requiredCoverage.getPrimaryCoverageDetails() == null) {
			logger.info(" \n Could not find a valid required coverage: returnning 0  for assetID: " + insurableAsset.getRid());
			return BigDecimal.ZERO;
		} else {
			return requiredCoverage.getPrimaryCoverageDetails().getCoverageAmount();
		}
	}
	
	public static boolean canDeletePendingVerificationRequiredCoverage(CollateralDetailsMainDto collateralDetailsMainDto){		
		InsurancePolicyRequirementDto verifiedCoverage = collateralDetailsMainDto.getRequiredCoverageSectionDto().getActiveCoverageRequirement();
		if(verifiedCoverage != null && verifiedCoverage.getRequiredCoverageSourceDto() != null && CoverageRequirementStatus.VERIFIED.name().equals(verifiedCoverage.getRequiredCoverageSourceDto().getStatus())){
			//allowed if there is a verified fiat//pending verification fiat can be deleted
			return true;
    	}
		if(CollectionUtils.isEmpty(collateralDetailsMainDto.getInsuranceSectionData().getActivePolicies()) && CollectionUtils.isEmpty(collateralDetailsMainDto.getInsuranceSectionData().getInactivePolicies())){
			//If there is no verified fiat
			//And no associated policy to fiat
			//pending verification fiat can be deleted
			return true;
    	}
		return false;	
	}

    public static boolean hasHold(RequiredCoverage requiredCoverage, Long holdRid) {
        return (requiredCoverage.getPrimaryHold() != null && holdRid == requiredCoverage.getPrimaryHold().getRid()) ||
                (requiredCoverage.getExcessHold() != null && holdRid == requiredCoverage.getExcessHold().getRid());
    }

}
