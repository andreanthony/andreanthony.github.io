package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.coverageGapReport;

import com.jpmorgan.cib.wlt.ctrac.service.excel.ColumnDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;

import java.util.HashSet;
import java.util.Set;

public class CoverageGapReportDefinition {
    public static final ColumnDefinition[] COLUMN_DEFINITIONS = {
            new ColumnDefinition("Collateral RID", "collateralRID", FieldType.STRING),
            new ColumnDefinition("Collateral Type", "collateralType", FieldType.STRING),
            new ColumnDefinition("Line Of Business", "lineOfBusiness", FieldType.STRING),
            new ColumnDefinition("Loan Type", "loanType", FieldType.STRING),
            new ColumnDefinition("Asset RID", "assetRid", FieldType.STRING),
            new ColumnDefinition("Building Name", "buildingName", FieldType.STRING),
            new ColumnDefinition("Source Document", "sourceDocument", FieldType.STRING),
            new ColumnDefinition("Document Date", "documentDate", FieldType.DATE),
            new ColumnDefinition("Coverage Type", "coverageType", FieldType.STRING),
            new ColumnDefinition("Primary VS Excess", "primaryVsExcess", FieldType.STRING),
            new ColumnDefinition("Required Coverage Amount", "requiredCoverageAmount", FieldType.AMOUNT),
            new ColumnDefinition("LP Provided Coverage", "lpProvidedCoverage", FieldType.AMOUNT),
            new ColumnDefinition("LP Expiration Date", "lpExpirationDate", FieldType.DATE),
            new ColumnDefinition("Borrower Provided Coverage", "borrowerProvidedCoverage", FieldType.AMOUNT),
            new ColumnDefinition("Borrower Policy Expiration Date", "borrowerPolicyExpirationDate", FieldType.DATE),
            new ColumnDefinition("GAP Amount", "gapAmount", FieldType.AMOUNT),
            new ColumnDefinition("Hold Case", "holdCase", FieldType.STRING),
            new ColumnDefinition("Status", "status", FieldType.STRING)
    };
    public static final Set<Integer> COLUMNS_NOT_AUTO_SIZE = new HashSet<>();

}
