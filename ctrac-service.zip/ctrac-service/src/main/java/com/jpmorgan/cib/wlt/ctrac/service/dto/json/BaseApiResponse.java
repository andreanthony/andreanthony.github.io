package com.jpmorgan.cib.wlt.ctrac.service.dto.json;

import org.apache.commons.lang.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by V704662 on 8/8/2017.
 */
public class BaseApiResponse implements Serializable {

    private static final long serialVersionUID = 5831015682939105289L;
    private boolean success = true;
    private List<ValidationError> validationErrors;
    private String message;
    private String action;

    public BaseApiResponse(BindingResult errorResult, String successMessage){
        if(errorResult.hasErrors()){
            this.validationErrors = new ArrayList<>();
            for(ObjectError error:errorResult.getAllErrors()){
                String fieldId = error instanceof FieldError ? ((FieldError) error).getField(): StringUtils.EMPTY;
                this.validationErrors.add(new ValidationError(fieldId, error.getDefaultMessage()));
            }
            success = false;
        }else{
            this.message = successMessage;
        }
    }

    public BaseApiResponse(Exception exception, String messageOverride){
        if(this.validationErrors == null){
            this.validationErrors = new ArrayList<>();
        }
        this.validationErrors.add(new ValidationError(StringUtils.isEmpty(messageOverride)
                ? exception.getMessage() : messageOverride));
        this.success = false;
    }

    public BaseApiResponse(String action){
        this.action = action;
    }

    public BaseApiResponse(){}


    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public List<ValidationError> getValidationErrors() {
        return validationErrors;
    }

    public void setValidationErrors(List<ValidationError> validationErrors) {
        this.validationErrors = validationErrors;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
