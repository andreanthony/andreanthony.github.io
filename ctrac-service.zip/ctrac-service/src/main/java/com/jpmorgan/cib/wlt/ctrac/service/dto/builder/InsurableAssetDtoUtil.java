package com.jpmorgan.cib.wlt.ctrac.service.dto.builder;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import org.apache.log4j.Logger;

public class InsurableAssetDtoUtil {

    private static final Logger logger = Logger.getLogger(InsurableAssetDtoUtil.class);

	public static InsurableAssetDTO instantiate(CollateralDto collateralDto, InsurableAssetType type,
                                                Long collateralRid, String floodZone, Integer sortOrder) {
		logger.debug("instantiate::BEGIN");
		InsurableAssetDTO insurableAsset = new InsurableAssetDTO(type);
		collateralDto.getInsurableAssets().add(insurableAsset);
		insurableAsset.setCollateralRid(collateralRid);
		insurableAsset.setFloodZone(floodZone);
		insurableAsset.setSortOrder(sortOrder);
		logger.debug("instantiate::END");
		return insurableAsset;
    }

	public static LPConstants getFloodLPCoverageType(InsurableAsset insurableAsset) {
		LPConstants lpCoverageType = LPConstants.FLOOD_ZONE_IN_CONTENT;
		if (InsurableAssetType.STRUCTURE.name().equals(insurableAsset.getAssetType())) {
			lpCoverageType = LPConstants.FLOOD_ZONE_IN_BUILDING;
		}
		return lpCoverageType;
	}

}
