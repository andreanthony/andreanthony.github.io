package com.jpmorgan.cib.wlt.ctrac.service.helper;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.jpmorgan.cib.wlt.ctrac.service.dto.letters.ack.CtracLetterConfirmationFile;
import com.jpmorgan.cib.wlt.ctrac.service.dto.servicelink.FloodRemaps;

public class XMLUtil {

	private static final Logger logger = Logger.getLogger(XMLUtil.class);

	public static boolean validateXML(String schemaLocation, Source xmlFile) {

		boolean isValid = true;

		URL schemaFile;
		try {
			schemaFile = XMLUtil.class.getResource(schemaLocation);

			SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = schemaFactory.newSchema(schemaFile);
			Validator validator = schema.newValidator();

			validator.validate(xmlFile);
			logger.debug(xmlFile.getSystemId() + " is valid");
		}
		catch (SAXException e) {
			isValid = false;
			logger.error(xmlFile.getSystemId() + " is NOT valid");
			logger.error(e.getMessage(),e);
		}
		catch (MalformedURLException e) {
			isValid = false;
			e.printStackTrace();
		}
		catch (IOException e) {
			isValid = false;
			e.printStackTrace();
		}
		return isValid;
	}
	

	
	/*
	 * This method will return the value of a named XML element. 
	 * In the event of multiple values with 
	 */
	public static String extractElementValue(String elementName, File xmlFile){
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		Document document = null;
		String retVal = "ERROR";
		
		NodeList nodeList;
		try {
			builder = factory.newDocumentBuilder();
			document = builder.parse(xmlFile);
		//	Element rootElement = document.getDocumentElement();
			nodeList = document.getElementsByTagName(elementName);
			Node n = nodeList.item(0);
			retVal = n.getTextContent();
					
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		return retVal;
	}
	
	public static FloodRemaps convertXmlFileToRemaps(File xmlFile) throws Exception{
		FloodRemaps floodRemaps = new FloodRemaps();
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(FloodRemaps.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			floodRemaps = (FloodRemaps) jaxbUnmarshaller.unmarshal(xmlFile);
		}
		catch (JAXBException e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
		return floodRemaps;
	}
	
	public static CtracLetterConfirmationFile convertXmlFileToLetterAck(File xmlFile) throws Exception{
		CtracLetterConfirmationFile letterAck = new CtracLetterConfirmationFile();
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(CtracLetterConfirmationFile.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			letterAck = (CtracLetterConfirmationFile) jaxbUnmarshaller.unmarshal(xmlFile);
		}
		catch (JAXBException e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
		return letterAck;
		
	}
	
	/**
	 * Method to convert xmldate  to Java date 
	 * @param XMLGregorianCalendar
	 * @return Date
	 */
	public static Date convertXMLDatetoJavaDate(XMLGregorianCalendar xmlGregorianCalendar) throws Exception {
		if (xmlGregorianCalendar == null)
			return null;
		XMLGregorianCalendar xMLGregorianCalendar = xmlGregorianCalendar;
		Date date = xMLGregorianCalendar.toGregorianCalendar().getTime();
		return date;
	}
	public static boolean isXmlFile(File file) {
		String extension = FilenameUtils.getExtension(file.getName());
		return "xml".equalsIgnoreCase(extension);
	}

}
