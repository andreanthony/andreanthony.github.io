package com.jpmorgan.cib.wlt.ctrac.service.dto.view;

import java.math.BigDecimal;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.BalanceType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;

public class RequiredCoverageViewDto {
	
	private Long requiredCoverageRid;
	private Long collateralRid;
	private Long insurableAssetRid;
	private String status;
	private String documentDate;
	private String insuranceType;
	private String sourceDocument;
	private String reqdCovSameAsOPB;
	private String excessRequired;
	private BigDecimal outstandingPrincipleBalance;
	private String propertyType;
	private String buildingName;
	//private String coverageAmount;
	private String primaryCoverageAmount;
	private String excessCoverageAmount;
	private String primaryCoverageValue;
	private String excessCoverageValue;	
	private String assetType;
	private String primaryBuildingContentBalanceType;
	private String excessBuildingContentBalanceType;
	
	public Long getCollateralRid() {
		return collateralRid;
	}
	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}
	public Long getRequiredCoverageRid() {
		return requiredCoverageRid;
	}
	public void setRequiredCoverageRid(Long requiredCoverageRid) {
		this.requiredCoverageRid = requiredCoverageRid;
	}
	public Long getInsurableAssetRid() {
		return insurableAssetRid;
	}
	public void setInsurableAssetRid(Long insurableAssetRid) {
		this.insurableAssetRid = insurableAssetRid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDocumentDate() {
		return documentDate;
	}
	public void setDocumentDate(String documentDate) {
		this.documentDate = documentDate;
	}
	public String getInsuranceType() {
		return insuranceType;
	}
	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}
	public String getSourceDocument() {
		return sourceDocument;
	}
	public void setSourceDocument(String sourceDocument) {
		this.sourceDocument = sourceDocument;
	}
	public String getReqdCovSameAsOPB() {
		return reqdCovSameAsOPB;
	}
	public void setReqdCovSameAsOPB(String reqdCovSameAsOPB) {
		this.reqdCovSameAsOPB = reqdCovSameAsOPB;
	}
	public String getExcessRequired() {
		return excessRequired;
	}
	public void setExcessRequired(String excessRequired) {
		this.excessRequired = excessRequired;
	}
	public BigDecimal getOutstandingPrincipleBalance() {
		return outstandingPrincipleBalance;
	}
	public void setOutstandingPrincipleBalance(BigDecimal outstandingPrincipleBalance) {
		this.outstandingPrincipleBalance = outstandingPrincipleBalance;
	}
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
//	public String getCoverageAmount() {
//		return coverageAmount;
//	}
//	public void setCoverageAmount(String coverageAmount) {
//		this.coverageAmount = coverageAmount;
//	}
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getPrimaryCoverageAmount() {
		return primaryCoverageAmount;
	}
	public BigDecimal getPrimaryCoverageAmount_() {
		return primaryCoverageAmount == null? BigDecimal.ZERO : AmountFormatter.parse(primaryCoverageAmount);
	}
	public void setPrimaryCoverageAmount(String primaryCoverageAmount) {
		this.primaryCoverageAmount = primaryCoverageAmount;
	}
	public String getExcessCoverageAmount() {
		return excessCoverageAmount;
	}
	public BigDecimal getExcessCoverageAmount_() {
		return excessCoverageAmount == null? BigDecimal.ZERO : AmountFormatter.parse(excessCoverageAmount);
	}
	public void setExcessCoverageAmount(String excessCoverageAmount) {
		this.excessCoverageAmount = excessCoverageAmount;
	}
	public String getPrimaryCoverageValue() {
		return primaryCoverageValue;
	}
	public BigDecimal getPrimaryCoverageValue_() {
		return primaryCoverageValue == null? BigDecimal.ZERO : AmountFormatter.parse(primaryCoverageValue);
	}
	public void setPrimaryCoverageValue(String primaryCoverageValue) {
		this.primaryCoverageValue = primaryCoverageValue;
	}
	public String getExcessCoverageValue() {
		return excessCoverageValue;
	}
	public BigDecimal getExcessCoverageValue_() {
		return excessCoverageValue == null? BigDecimal.ZERO : AmountFormatter.parse(excessCoverageValue);
	}
	public void setExcessCoverageValue(String excessCoverageValue) {
		this.excessCoverageValue = excessCoverageValue;
	}
	public BigDecimal getTotalCoverageAmount_() {
		return getPrimaryCoverageAmount_().add(getExcessCoverageAmount_());
	}
	public String getPrimaryBuildingContentBalanceType() {
		return this.primaryBuildingContentBalanceType;
	}
	public void setPrimaryBuildingContentBalanceType(String primaryBuildingContentBalanceType) {
		this.primaryBuildingContentBalanceType = primaryBuildingContentBalanceType;
	}
	public String getExcessBuildingContentBalanceType() {
		return this.excessBuildingContentBalanceType;
	}
	public void setExcessBuildingContentBalanceType(String excessBuildingContentBalanceType) {
		this.excessBuildingContentBalanceType = excessBuildingContentBalanceType;
	}
	public BigDecimal getValueByBalanceType(BalanceType balanceType) {
		BigDecimal value = null;
		if(balanceType != null) {
			if(balanceType.name().equals(this.getPrimaryBuildingContentBalanceType())) {
				value = this.getPrimaryCoverageValue_(); 
			}
			else if(balanceType.name().equals(this.getExcessBuildingContentBalanceType())) {
				value = this.getExcessCoverageValue_(); 
			}
		}
		return value;	//return null if value is not specified
	}	
	
}
