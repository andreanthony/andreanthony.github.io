package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.wiredrequests;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WiredPolicy;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ColumnDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ExpressionOperator;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldExpression;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CREATE_REFUND_REQUEST;

public class AlthansExcelWiredRefundRequestDefinition implements AlthansExcelWiredRequestsDefinitions, AlthansWiredRequestsConstants {

	public static final ColumnDefinition[] ALTHANS_EXCEL_DEFINITION = {
			new ColumnDefinition("Policy Number", "policyRid", FieldType.STRING),
			new ColumnDefinition("Payor", "payorDisplayValue", FieldType.STRING),
			new ColumnDefinition("Method of Payment", "methodOfPayment", FieldType.STRING),
			new ColumnDefinition("Loan #", "loanNumber", FieldType.STRING),
			new ColumnDefinition("Cost Center", "costCenterDisplayValue", FieldType.STRING,
				new FieldExpression("Look up #", ExpressionOperator.EQUALS)),
			new ColumnDefinition("General Ledger", "generalLedger", FieldType.STRING),
			new ColumnDefinition("DDA #", "ddaNumber", FieldType.STRING),
			new ColumnDefinition("Refund Mailing Address", "refundMailingAddress", FieldType.STRING),

			new ColumnDefinition("Collateral Address", "collateralAddress", FieldType.STRING),
			new ColumnDefinition("Collateral Unit/Building", "collateralUnit", FieldType.STRING),
			new ColumnDefinition("Collateral City", "collateralCity", FieldType.STRING),
			new ColumnDefinition("Collateral State", "collateralState", FieldType.STRING),
			new ColumnDefinition("Collateral Zip", "collateralZip", FieldType.STRING),
			new ColumnDefinition("Building Name", "buildingName", FieldType.STRING),

			new ColumnDefinition("Borrower Name", "clientName", FieldType.STRING),
			new ColumnDefinition("Policy Effective Date", "policyEffectiveDay", FieldType.DATE),
			new ColumnDefinition("Policy Expiration Date", "policyExpirationDay", FieldType.DATE),
			new ColumnDefinition("Policy Cancelation Date", "policyCancellationDate", FieldType.DATE),

			new ColumnDefinition("Coverage Type", "coverageType", FieldType.STRING),
			new ColumnDefinition("Premium Amount", "premiumAmountDouble", FieldType.AMOUNT),
			new ColumnDefinition("Amount Refunded", "refundAmountDouble", FieldType.AMOUNT)
	};

	public static final Map<String, String> wiredRefundAttributes = new HashMap<String, String>() {
		{
			//Create Wire Refund Request Definitions
			put(CONST_WORKSHEET_TITLE, "CTRAC Flood Refund Requests");
			put(CONST_TRANSFER_REQUEST_COUNT_LABEL_KEY, "Refund Request Count:");
			put(CONST_TRANSFER_FUNDS_LABEL_KEY, "TRANSFER FUNDS FROM:");
			put(CONST_LOAN_SYSTEM_LABEL_KEY, "Loan System");
			put(CONST_VENDOR_TO_LABEL_KEY, "Vendor");
			put(CONST_EFFECTIVE_DATE_LABEL_KEY, "Effective Date");
			//VLS
			put(CONST_FUND_TO_ACCOUNT_NUMBER_KEY + CONST_DELIMITER + LoanSystem.VLS, LABEL_WIRE_REQUEST_DDA_ACCOUNTNUMBER + "17908221954");
			put(CONST_FUND_TO_COMPANY_NUMBER_KEY + CONST_DELIMITER + LoanSystem.VLS, LABEL_WIRE_REQUEST_COMPANY + "0201");
			//ACBS
			put(CONST_FUND_TO_ACCOUNT_NUMBER_KEY + CONST_DELIMITER + LoanSystem.ACBS, LABEL_WIRE_REQUEST_GL_ACCOUNTNUMBER + "2071020077");
			put(CONST_FUND_TO_COMPANY_NUMBER_KEY + CONST_DELIMITER + LoanSystem.ACBS, LABEL_WIRE_REQUEST_COMPANY + "0802");
			put(CONST_FUND_TO_COST_CENTER_NUMBER_KEY + CONST_DELIMITER + LoanSystem.ACBS, LABEL_WIRE_REQUEST_COST_CENTER + "007315");
			//LIQ
			put(CONST_FUND_TO_ACCOUNT_NUMBER_KEY + CONST_DELIMITER + LoanSystem.LIQ, LABEL_WIRE_REQUEST_GL_ACCOUNTNUMBER + "2855000005");
			put(CONST_FUND_TO_COMPANY_NUMBER_KEY + CONST_DELIMITER + LoanSystem.LIQ, LABEL_WIRE_REQUEST_COMPANY + "0802");
			put(CONST_FUND_TO_COST_CENTER_NUMBER_KEY + CONST_DELIMITER + LoanSystem.LIQ, LABEL_WIRE_REQUEST_COST_CENTER + "007315");
			//ABLE
			put(CONST_FUND_TO_ACCOUNT_NUMBER_KEY + CONST_DELIMITER + LoanSystem.ABLE, LABEL_WIRE_REQUEST_DDA_ACCOUNTNUMBER + "400999773");
			put(CONST_FUND_TO_COMPANY_NUMBER_KEY + CONST_DELIMITER + LoanSystem.ABLE, LABEL_WIRE_REQUEST_COMPANY + "0802");
			//STRATEGY
			put(CONST_FUND_TO_ACCOUNT_NUMBER_KEY + CONST_DELIMITER + LoanSystem.STRATEGY, LABEL_WIRE_REQUEST_GL_ACCOUNTNUMBER + "1311036043");

			put(CONST_FUND_TO_COMPANY_NUMBER_KEY + CONST_DELIMITER + LoanSystem.STRATEGY, LABEL_WIRE_REQUEST_COMPANY + "0802");
			put(CONST_FUND_TO_COST_CENTER_NUMBER_KEY + CONST_DELIMITER + LoanSystem.STRATEGY, LABEL_WIRE_REQUEST_COST_CENTER + "476294");

		}
	};

	@Override
	public ColumnDefinition[] getExcelColumnDefinitions() {
		return ALTHANS_EXCEL_DEFINITION;
	}

	@Override
	public Map<String, String> getWiredRequestAttributes() {
		return wiredRefundAttributes;
	}

	@Override
	public List convertWiredPoliciesToExcelTableRowData(CtracObjectMapper ctracObjectMapper, List<WiredPolicy> wiredPolicies) {
		return ctracObjectMapper.mapAsList(wiredPolicies, AlthansExcelWiredRefundRequestRow.class);
	}

	@Override
	public ColumnDefinition findColumnDefinitionForFieldName(String fieldName) {
		for(ColumnDefinition columnDefinition:ALTHANS_EXCEL_DEFINITION){
			if(columnDefinition.getFieldName().equals(fieldName)){
				return columnDefinition;
			}
		}
		return null;
	}
}
