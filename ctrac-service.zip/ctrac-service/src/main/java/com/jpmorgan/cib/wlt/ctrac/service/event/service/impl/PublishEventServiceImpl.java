package com.jpmorgan.cib.wlt.ctrac.service.event.service.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.request.PublishEventRequest;
import com.jpmorgan.cib.wlt.ctrac.service.event.store.client.CollateralEventSection;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.UUID;


@Service
public class PublishEventServiceImpl extends AbstractPublishEventService implements PublishEventService {
    private static final Logger logger = Logger.getLogger(PublishEventServiceImpl.class);

    @Override
    @Transactional
    public void publishCollateralEvent(CollateralDto collateralDto, CollateralEventType eventType, CollateralEventSection collateralSection) {
        logger.debug("publishCollateralEvent:START");
        publishEvent(null, collateralDto.getRid(), collateralDto.getPrimaryLoan().getLineOfBusiness(), null, eventType, collateralSection, null);
        logger.debug("publishCollateralEvent:END");
    }

    @Override
    @Transactional
    public void publishLoanBorrowerEvent(LoanData loanData,Long collateralRid, CollateralEventType eventType, CollateralEventSection collateralSection) {
        logger.debug("publishLoanBorrowerEvent:START");
       String description ="";
        if(StringUtils.isNotEmpty(loanData.getReleasedDate())&& collateralSection.toString().equalsIgnoreCase(CollateralEventSection.LOAN.toString()))
        {
            description = "Paid Off -" + loanData.getReleasedDate();
        }

        publishEvent(loanData.getLoanNumber(), collateralRid, loanData.getLineOfBusiness(), description, eventType, collateralSection, null);
        logger.debug("publishLoanBorrowerEvent:END");
    }

    @Override
    @Transactional
    public void publishPerfectionTaskEvent(PublishEventRequest publishRequest) {
        logger.debug("publishPerfectionTaskEvent:START");
        publishCollateralSectionEvent(publishRequest, CollateralEventSection.WORKFLOW_TASK);
        logger.debug("publishPerfectionTaskEvent:END");
    }

    @Override
    @Transactional
    public void publishBIProofOfCoverageEvent(PublishEventRequest publishRequest) {
        logger.debug("publishBIProofOfCoverageEvent:SATRT");
        publishEvent(publishRequest.getIdentifier(), publishRequest.getCollateralRid(), publishRequest.getLineOfBusiness(),
                publishRequest.getDescription(), publishRequest.getCollateralEventType(),
                CollateralEventSection.FLOOD_INSURANCE_BORROWER_POLICY, null);
        logger.debug("publishBIProofOfCoverageEvent:END");
    }

    @Override
    @Transactional
    public void publishSFHDFEvent(String identifier, Long collateralRid, String lineOfBusiness, CollateralEventType eventType,
                                  String userName, String dateOfDetermination) {
        logger.debug(" publishSFHDFEvent:SATRT");
        publishEventWithUserName(identifier, collateralRid, lineOfBusiness, "Date of Determination - " + dateOfDetermination,
                eventType, CollateralEventSection.SFHDF, null,userName);
        logger.debug(" publishSFHDFEvent:END");
    }

    @Override
    @Transactional
    public void publishRequiredFloodCoverageAmountEvent(String identifier,Long collateralRid, String lineOfBusiness,String description,
                                                        CollateralEventType eventType) {
        logger.debug(" publishRequiredFloodCoverageAmountEvent:SATRT");
        publishEvent(identifier, collateralRid, lineOfBusiness,description, eventType, CollateralEventSection.FLOOD_REQUIRED_COVERAGE, null);
        logger.debug(" publishRequiredFloodCoverageAmountEvent:END");
    }

    @Override
    @Transactional
    public void publishLPProofOfCoverageEvent(PublishEventRequest publishRequest) {
        logger.debug("publishLPProofOfCoverageEventEvent:START");
        publishCollateralSectionEvent(publishRequest, CollateralEventSection.FLOOD_INSURANCE_LPI_POLICY);
        logger.debug("publishLPProofOfCoverageEventEvent:END");
    }

    @Override
    public void republishEvent(UUID eventUuid) {
        super.republishEvent(eventUuid);
    }

    @Override
    public void republishEvents(Date fromDate, Date toDate) {
        super.republishEvents(fromDate, toDate);
    }
}
