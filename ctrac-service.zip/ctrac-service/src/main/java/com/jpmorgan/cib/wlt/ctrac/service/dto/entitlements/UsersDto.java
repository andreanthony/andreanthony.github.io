package com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements;



import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.jpmorgan.cib.wlt.ctrac.service.entitlements.CtracAutoProvisionHandler;


/**
 * Created by I569445 on 2/25/2016.
 */
public class UsersDto implements UserDetails {

	private static final long serialVersionUID = -7820166404337254873L;
	private String username;
    private Boolean enabled;
    private String firstName;
    private String lastName;
    private String sid;
    private Date lastLoginDate;
    private List<GroupDto> groups;
    private CtracAutoProvisionHandler.RSAMActionEnum action;
    private String lob;
    private List<GrantedAuthority> authorities;

    public UsersDto(){
    	
    }
    
    public UsersDto(String username, boolean enabled, List<GrantedAuthority> authorities, Date lastLoginDate) {
        this.username = username;
        this.enabled = enabled;
        this.authorities = authorities;
        this.lastLoginDate = lastLoginDate;
    }

    public UsersDto(String username, Date lastLoginDate, boolean enabled) {
        this.username = username;
        this.lastLoginDate = lastLoginDate;
        this.enabled = enabled;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
       return null;
    }

    public String getUsername() {
        return username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return enabled;
    }

    @Override
    public boolean isAccountNonLocked() {
        return enabled;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return enabled;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public Date getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(Date lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public CtracAutoProvisionHandler.RSAMActionEnum getAction() {
        return action;
    }

    public void setAction(CtracAutoProvisionHandler.RSAMActionEnum action) {
        this.action = action;
    }

    public List<GroupDto> getGroups() {
        if(this.groups == null) {
            this.groups = new ArrayList<GroupDto>();
        }
        return groups;
    }

    public void setGroups(List<GroupDto> groups) {
        this.groups = groups;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public void setAuthorities(List<GrantedAuthority> authorities) {
        this.authorities = authorities;
    }
}
