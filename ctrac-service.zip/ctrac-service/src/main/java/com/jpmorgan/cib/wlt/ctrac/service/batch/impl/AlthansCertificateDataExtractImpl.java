package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;



import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.PROCESS_VENDOR_CERTIFICATES;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.AlthansDataException;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.FileType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProofOfCoverageWorkItemRelationType;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.file.FileValidator;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FileProcessingUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCovWorkItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.AlthansBatchItemService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapDataExtract;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;




@Service(value = "althansCertificateDataExtract")
public class AlthansCertificateDataExtractImpl extends AbstractFloodRemapDataExtractImpl implements FloodRemapDataExtract {

	public static final String NO_FILE_RECEIVED = "No file received for task id: ";
	public static final String NOT_A_VALID_ZIP_FILE = "Not a valid zip file for task id: ";
	public static final String NOT_PDF_CONTENTS = "Non-PDF contents found in entry: ";
	public static final String NOT_A_POLICY_RID = "File not named as a policy rid: ";
	public static final String NOT_MATCHING_EXPECTED = "Contents not matching expected policies.";

	private static final Logger logger = Logger.getLogger(AlthansCertificateDataExtractImpl.class);	

	private static final String ALTHANS_INBOUND_LANDING_ZIP_DIR = "althans.landing.inbound.zip.directory";
	private static final String ALTHANS_INBOUND_ARCHIVE_ZIP_DIR ="althans.archive.inbound.zip.directory";	
	private static final String ALTHANS_INBOUND_LANDING_PDF_DIR = "althans.landing.inbound.pdf.directory";
	private static final String ALTHANS_INBOUND_ARCHIVE_PDF_DIR ="althans.archive.inbound.pdf.directory";	
	
	@Autowired private AlthansBatchItemService althansBatchItemService;
	@Autowired private CtracEmailSender ctracEmailSender;
	@Autowired private FileValidator fileValidator;
	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;
	@Autowired private ProofOfCovWorkItemRepository proofOfCovWorkItemRepository;
	@Autowired private PerfectionTaskService perfectionTaskService;
	@Autowired private TMService tmService;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	@Autowired @Qualifier("wireProcessingService") WireProcessingService wireProcessingService;
	
	
	@Override
	protected File[] getAllFiles() {
		File[] files = getAllFiles(ALTHANS_INBOUND_LANDING_ZIP_DIR);
		return  files != null? files: new File[0]; 
	}

	@Override
	protected boolean isValidFileName(File file) {
		return true;
	}

	@Override
	protected boolean areValidContents() {
		return true;
	}
	
	@Override
	protected void archiveFile(File file) {
		if(file == null) return;
		FileProcessingUtil.archiveSingleFile(file, env.getRequiredProperty(ALTHANS_INBOUND_ARCHIVE_ZIP_DIR));
	}

	@Override
	protected void updateLastFileReceivedDate() {
		//updateLastFileReceivedDate(CtracAppConstants.LIQ_LAST_RENEWAL_FILE_RECEIVED_DATE);
	}
	
	@Override
	protected void extractContents(File file) {
		 extractContents(file, ALTHANS_INBOUND_LANDING_PDF_DIR);
	}
	
	@Override
	protected void processContents(File file) {	
		//savePDFFiles(ALTHANS_INBOUND_LANDING_ZIP_PDF_DIR);
	}
	
	@Override
	protected void processContents() {	
		//savePDFFiles(ALTHANS_INBOUND_LANDING_ZIP_PDF_DIR);
	}
	
	private  Map<String, CollateralDocument> savePDFFiles(String dataLandingDir, Long batchItemRid) {
		logger.debug("savePDFFiles::BEGIN");
		try {
			File dir = new File(env.getProperty(dataLandingDir) + CtracAppConstants.PATH_SEPERATOR);
			for (File file : dir.listFiles()) {
				ProofOfCoverage proof = getProofOfCoverageForFilename(FilenameUtils.removeExtension(file.getName()));
				if(proof != null){
					LenderPlaceItem lenderPlaceItem = null;
					List<ProofOfCovWorkItem> items = proofOfCovWorkItemRepository.findByProofOfCoverageRidAndItemType(proof.getRid(),  ProofOfCoverageWorkItemRelationType.LENDERPLACEMENT_TO_POLICY.getName());
					for (ProofOfCovWorkItem item : items){
						lenderPlaceItem  = (LenderPlaceItem)item.getWorkItem();					
					}
					
					if (lenderPlaceItem!=null){	
						if(althansBatchItemService.isNewIssuePolicy(batchItemRid, proof)){
							collateralDocumentService.saveCollateralDocument(file, CollateralDocumentType.PREMIUM_CERTIFICATE.getName(), proof.getRid());	
							if(wireProcessingService.isPolicyIncludedInAggregateWirePremium(lenderPlaceItem) || proof.getCancellationEffectiveDate() == null){								
								//Verify_Vendor_Certificate
								tmService.createTask(TMTaskType.FLOOD_INSURANCE, lenderPlaceItem, WorkflowStateDefinition.VERIFY_VENDOR_CERTIFICATE.getFloodRemapTaskState());
								perfectionTaskService.createTransientTask(lenderPlaceItem, WorkflowStateDefinition.SEND_FINAL_LP_LETTER.getFloodRemapTaskState(), TMTaskType.FLOOD_INSURANCE, null);
							}else{
								//Image_Certificate
								tmService.createTask(TMTaskType.FLOOD_INSURANCE, lenderPlaceItem, WorkflowStateDefinition.IMAGE_CERTIFICATE.getFloodRemapTaskState());
							}
						}else{
							collateralDocumentService.saveCollateralDocument(file, CollateralDocumentType.REFUND_CERTIFICATE.getName(), proof.getRid());
							//Image_Cancellation_Certificate
							tmService.createTask(TMTaskType.FLOOD_INSURANCE, lenderPlaceItem, WorkflowStateDefinition.IMAGE_CANCELLATION_CERTIFICATE.getFloodRemapTaskState());
						}
					}
					/*		
					if (lenderPlaceItem!=null){		
						if(proof.getCancellationEffectiveDate() != null){
							
							collateralDocumentService.saveCollateralDocument(file, CollateralDocumentType.REFUND_CERTIFICATE.getName(), proof.getRid());
							//Image_Cancellation_Certificate
							tmService.createTask(TMTaskType.FLOOD_INSURANCE, lenderPlaceItem, WorkflowStateDefinition.IMAGE_CANCELLATION_CERTIFICATE.getFloodRemapTaskState());
						}else{
							collateralDocumentService.saveCollateralDocument(file, CollateralDocumentType.PREMIUM_CERTIFICATE.getName(), proof.getRid());	
							if(wireProcessingService.isPolicyIncludedInAggregateWirePremium(lenderPlaceItem)){								
								//Verify_Vendor_Certificate
								tmService.createTask(TMTaskType.FLOOD_INSURANCE, lenderPlaceItem, WorkflowStateDefinition.VERIFY_VENDOR_CERTIFICATE.getFloodRemapTaskState());
								perfectionTaskService.createTransientTask(lenderPlaceItem, WorkflowStateDefinition.SEND_FINAL_LP_LETTER.getFloodRemapTaskState(), TMTaskType.FLOOD_INSURANCE, null);
							}else{
								//Verify_Vendor_Certificate
								tmService.createTask(TMTaskType.FLOOD_INSURANCE, lenderPlaceItem, WorkflowStateDefinition.VERIFY_VENDOR_CERTIFICATE.getFloodRemapTaskState());
							}
						}
					}*/
				}
			}			
		} catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			throw new CTracApplicationException("E0213", CtracErrorSeverity.CRITICAL, ex);
		}
		logger.debug("savePDFFiles::END");
		return null;
	}
	
	public ProofOfCoverage getProofOfCoverageForFilename(String filename){
		ProofOfCoverage proof = null;
		try {
		    if (filename == null) {
		        return null;
		    }
		    
		    // 2. Is excelRid numeric?
		    Long proofRid = Long.valueOf(filename);
		    if (proofRid == null || proofRid.compareTo(0L) <= 0) {
		        return null;
		    }
		    
		    // 3. Is lpItemRid a valid LenderPlaceItem RID?
		    proof = proofOfCoverageRepository.findOne(proofRid);
		} catch (Exception e) {
			return null;
		}
		return proof;
	}
	
	@Override
	protected boolean isValidZipFile(File file) {
		return true;
	}

	@Override
	protected void processContents(Long batchItemRid) {
		savePDFFiles(ALTHANS_INBOUND_LANDING_PDF_DIR,batchItemRid);
	}	
	
	
	/**
	 * This file must be a zip file that contains exactly the PDFs that we expect
	 * - 1 PDF per related policy with file name matching the rid of the policy
	 */
	@Override
	public boolean isValidFile(File file, Long taskRid) {
		ZipFile zipFile = null;
		try {
			if (file == null) {
				throw new AlthansDataException(NO_FILE_RECEIVED + taskRid);
			}
			if (!fileValidator.isFileType(file, FileType.ZIP)) {
				throw new AlthansDataException(NOT_A_VALID_ZIP_FILE + taskRid);
			}
			zipFile = new ZipFile(file);
			Set<Long> relatedPolicyRids = althansBatchItemService.getRelatedPolicyRids(taskRid);
			Set<Long> certificateRids = getCertificateRids(zipFile);
			if (!relatedPolicyRids.equals(certificateRids)) {
				throw new AlthansDataException(getMismatchMessage(relatedPolicyRids, certificateRids));
			}
			return true;
		} catch (Exception e) {
			List<File> attachments = new ArrayList<File>();
			if (file != null) {
				attachments.add(file);
			}
			ctracEmailSender.sendExceptionEmailToDevTeam("Error processing Althans certificates file", e.getMessage(), attachments);
			return false;
		} finally {
			if (zipFile != null) {
				try {
					zipFile.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
	}

	private Set<Long> getCertificateRids(ZipFile zipFile) {
		Set<Long> innerFiles = new HashSet<Long>();
		Enumeration<? extends ZipEntry> entries = zipFile.entries();
		while (entries.hasMoreElements()) {
			ZipEntry entry = entries.nextElement();
			String innerFileName = entry.getName();
			if (!fileValidator.isFileType(innerFileName, FileType.PDF)) {
				throw new AlthansDataException(NOT_PDF_CONTENTS + innerFileName);
			}
			try {
				innerFiles.add(Long.parseLong(FilenameUtils.removeExtension(innerFileName)));
			} catch (NumberFormatException e) {
				throw new AlthansDataException(NOT_A_POLICY_RID + innerFileName);
			}
		}
		return innerFiles;
	}

	String getMismatchMessage(Set<Long> relatedPolicyRids, Set<Long> certificateRids) {
		Set<Long> missingSet = new HashSet<>();
		Set<Long> extraSet = new HashSet<>();
		missingSet.addAll(relatedPolicyRids);
		missingSet.removeAll(certificateRids);
		extraSet.addAll(certificateRids);
		extraSet.removeAll(relatedPolicyRids);
		StringBuilder sb = new StringBuilder(NOT_MATCHING_EXPECTED);
		if (!missingSet.isEmpty()) {
			sb.append(" Missing: ").append(StringUtils.join(missingSet, ','));
		}
		if (!extraSet.isEmpty()) {
			sb.append(" Extra: ").append(StringUtils.join(extraSet, ','));
		}
		return sb.toString();
	}

	@Override
	protected void archiveContents() {
		FileProcessingUtil.archiveEntireDirectory(
				env.getRequiredProperty(ALTHANS_INBOUND_LANDING_PDF_DIR),
				env.getRequiredProperty(ALTHANS_INBOUND_ARCHIVE_PDF_DIR));
	}
	
	protected Long getFileId(File file) {
		Long fileId = null;
		try {
			String[] filename = FilenameUtils.removeExtension(file.getName()).split("-");
			if (filename == null || filename.length < 2) {
				throw new AlthansDataException("Not enough parts to filename: " + file.getName());
			}
			if (!filename[0].equalsIgnoreCase("certificates")) {
				throw new AlthansDataException("Unexpected file description: " + file.getName());
			}
			fileId = Long.parseLong(filename[1]);
		} catch (Exception e) {
			logger.error("Invalid file name - " + e.getMessage());
		}
		return fileId;
	}
	
	@Override 
	protected List<PerfectionTask> getTasks(){
		List<PerfectionTask> tasks = perfectionTaskRepository.findTransientTasksWakeUpDateBeforeToday(PROCESS_VENDOR_CERTIFICATES.getName());
		return tasks;
	}
	
}
