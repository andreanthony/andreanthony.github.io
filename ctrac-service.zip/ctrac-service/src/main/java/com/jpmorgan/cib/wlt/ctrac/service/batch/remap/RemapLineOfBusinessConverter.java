package com.jpmorgan.cib.wlt.ctrac.service.batch.remap;

import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessCategory;

/**
 * Created by E704298 on 8/21/2017.
 */
public interface RemapLineOfBusinessConverter {

    String convertToDescription(String code, LineOfBusinessCategory lobCategory);

    String getUnknownLOB();

}
