package com.jpmorgan.cib.wlt.ctrac.service.insurableasset;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.CoverageDetailsDTO;



public interface CoverageDetailService {

    void saveCoverageDetails(CoverageDetailsDTO coverageDetailsDTO);
    
    void saveCoverageDetails(List<CoverageDetailsDTO> coverageDetailsDTOList);
	
    void deleteCoverageDetails(CoverageDetailsDTO coverageDetailsDTO);

	void deleteCoverageDetails(List<CoverageDetailsDTO> coverageDetailsDTOs);	
}
