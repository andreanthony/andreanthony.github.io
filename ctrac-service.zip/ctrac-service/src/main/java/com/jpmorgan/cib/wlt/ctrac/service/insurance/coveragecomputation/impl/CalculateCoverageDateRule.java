package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import java.util.Date;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracCheckedException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;

public class CalculateCoverageDateRule extends InsurableAssetCoverageRule {

	private static final Logger logger = Logger.getLogger(CalculateCoverageDateRule.class);
	
	protected CalculateCoverageDateRule(Collateral collateral, WorkItem triggerWorkItem, InsurableAsset insurableAsset,
			CoverageActionData coverageActionData) {
		super(collateral, triggerWorkItem, insurableAsset, coverageActionData);
	}

	@Override
	public void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult partialResult) {
		logger.debug("execute::BEGIN, insurable asset rid = " + coverageActionData.getInsurableAssetRid());
		if (coverageActionRequest.getOverrideCalculatedDate() != null) {
            partialResult.setCoverageDate(coverageActionRequest.getOverrideCalculatedDate());
            logger.debug("getOverrideCalculatedDate = " + coverageActionRequest.getOverrideCalculatedDate());
        } else {
            try {
                Date date = calculateCoverageDate();
                logger.debug("calculateCoverageDate->" + (date != null ? date.toString() : "null"));
                partialResult.setCoverageDate(date);
            } catch (CtracCheckedException e) {
                logger.debug(e.getMessage() + ", skipping insurable asset");
                partialResult.setMoreActionsNeeded(false);
            }
        }
		logger.debug("execute::END");
	}

    protected Date calculateCoverageDate() throws CtracCheckedException {
        return CoverageDateCalculator.calculateCoverageDate(coverageActionData, collateral, triggerWorkItem);
    }

    @Override
	public Integer getPriority() {
		return 25;
	}

}
