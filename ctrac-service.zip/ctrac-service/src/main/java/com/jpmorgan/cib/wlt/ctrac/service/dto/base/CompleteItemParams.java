package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskRelationType;



public class CompleteItemParams extends GenericCommandParams{
	private String comments;
	private String closeReasonCode;
	private Date sleepFromDate;
	private int slaDaysRemaining;
	private TaskRelationType parentChildRelation;
	AppRuleInput AppRuleInput;
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getCloseReasonCode() {
		return closeReasonCode;
	}
	public void setCloseReasonCode(String closeReasonCode) {
		this.closeReasonCode = closeReasonCode;
	}
	public Date getSleepFromDate() {
		return sleepFromDate;
	}
	public void setSleepFromDate(Date sleepFromDate) {
		this.sleepFromDate = sleepFromDate;
	}
	public int getSlaDaysRemaining() {
		return slaDaysRemaining;
	}
	public void setSlaDaysRemaining(int slaDaysRemaining) {
		this.slaDaysRemaining = slaDaysRemaining;
	}
	public TaskRelationType getParentChildRelation() {
		return parentChildRelation;
	}
	public void setParentChildRelation(TaskRelationType parentChildRelation) {
		this.parentChildRelation = parentChildRelation;
	}
	public AppRuleInput getFloodRemapBusinessRuleRequest() {
		return AppRuleInput;
	}
	public void setFloodRemapBusinessRuleRequest(
			AppRuleInput AppRuleInput) {
		this.AppRuleInput = AppRuleInput;
	}
	
}
