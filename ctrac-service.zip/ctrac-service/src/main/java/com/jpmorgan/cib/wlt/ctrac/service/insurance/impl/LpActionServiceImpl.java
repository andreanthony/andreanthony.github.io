package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LpActionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class LpActionServiceImpl implements LpActionService {

    private ProofOfCoverageRepository proofOfCoverageRepository;

    @Autowired
    public LpActionServiceImpl(ProofOfCoverageRepository proofOfCoverageRepository) {
        assert(proofOfCoverageRepository != null);
        this.proofOfCoverageRepository = proofOfCoverageRepository;
    }

    @Override
    @Transactional
    public void updateLpAction(List<Long> proofOfCoverageRids, LPActions lpAction) {
        List<ProofOfCoverage> policies = proofOfCoverageRepository.findAll(proofOfCoverageRids);
        if (!policies.isEmpty()) {
            policies.forEach(policy -> policy.setLpAction(lpAction != null ? lpAction.name() : null));
            proofOfCoverageRepository.save(policies);
        }
    }
}
