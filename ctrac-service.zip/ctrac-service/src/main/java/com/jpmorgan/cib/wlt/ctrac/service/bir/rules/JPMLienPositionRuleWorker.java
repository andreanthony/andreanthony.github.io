package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.LookUpCodeService;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailRuleDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class JPMLienPositionRuleWorker extends AbstractBIRRuleWorker {

	protected static final String CONST_OPTION_NOT_LISTED = "NL";
	protected static final String CONST_OPTION_FIRST_OPTION = "FST";

	public JPMLienPositionRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRRuleConclusionDTO jpmLienPositionConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if (BIRRuleHelper.isCondoAssociationPolicy(borrowerInsuranceReviewData)) {
			birConclusion = BorrowerInsuranceReviewConclusion.NONE;
		} else if (ArrayUtils.contains(new String[]{CONST_OPTION_NOT_LISTED,CONST_OPTION_FIRST_OPTION}
			,borrowerInsuranceReviewData.getJpmLienPosition())) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		}
		if (birConclusion != null) {
			jpmLienPositionConclusion.setConclusion(birConclusion.name());
		}
	}

	@Override
	public void populateExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData) {
		BIRExceptionEmailRuleDTO birExceptionEmailRuleDTO = new BIRExceptionEmailRuleDTO();
		birExceptionEmailRuleDTO.setCurrentPolicyValue(getJPMLienPositionDescription(borrowerInsuranceReviewData.getJpmLienPosition()));
		exceptionEmailData.getPolicyExceptions().put(key, birExceptionEmailRuleDTO);
	}
	
	private String getJPMLienPositionDescription(String jpmLienPosition) {
		if (StringUtils.isBlank(jpmLienPosition)) {
			return "";
		}
		LookUpCodeService lookUpCodeService = ApplicationContextProvider.getContext().getBean(LookUpCodeService.class);
		List<LookUpCode> jpmLienPosCodes = lookUpCodeService.findByCodeSetInSortOrder("BRW_INS_REVIEW_JPM_LIEN_POSITION");
		for (LookUpCode jpmLienPos : jpmLienPosCodes) {
			if (jpmLienPosition.equals(jpmLienPos.getCode())) {
				return jpmLienPos.getDescription();
			}
		}
		return "";
	}

}
