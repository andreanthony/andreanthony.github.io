package com.jpmorgan.cib.wlt.ctrac.service.helper;

import java.util.Date;
import java.util.UUID;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;



public class PerfectionTaskBuilder {

	private  final PerfectionTask perfectionTask;
	
	public PerfectionTaskBuilder(WorkItem perfectionItem, String workflowStep, TaskStatus taskStatus, String insertedBy) {
		this.perfectionTask = new PerfectionTask();
		perfectionTask.setWorkItem(perfectionItem);
		perfectionTask.setWorkflowStep(workflowStep);
		perfectionTask.setTaskStatus(taskStatus.name());
        perfectionTask.setInitialAuditInfo(insertedBy);
		perfectionTask.setTmTaskId(UUID.randomUUID().toString());
		perfectionTask.setInInsuranceReview("N");
	}
	
	public PerfectionTaskBuilder slaDaysRemaining(int slaDaysRemaining) {
		perfectionTask.setSlaDaysRemaining(slaDaysRemaining);
		return this;
	}
	
	public PerfectionTaskBuilder wakeUpDate(Date wakeUpDate) {
		perfectionTask.setWakeUpDate(wakeUpDate);
		return this;
	}
	
	public PerfectionTaskBuilder inInsuranceReview(String inInsuranceReview) {
		perfectionTask.setInInsuranceReview(inInsuranceReview);
		return this;
	}
	
	public PerfectionTaskBuilder tmTaskType(TMTaskType tmTaskType) {
		perfectionTask.setTmTaskType(tmTaskType.name());
		return this;
	}
	
	public PerfectionTaskBuilder executionDate(Date executionDate) {
		perfectionTask.setExecutionDate(executionDate);
		return this;
	}
	
	public PerfectionTask build() {
		return perfectionTask;
	}
	
}