package com.jpmorgan.cib.wlt.ctrac.service.dto.admin;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

public class LoanBorrowerAddressMaintenanceDTO implements Serializable {

	private static final long serialVersionUID = 5252457557658647560L;

	private String successMsg = null;
	
	private String errorMsg = null;
		
	private List<LoanBorrowerAddressDTO> loanBorrowerAddressData;
	
	private int unverifiedRecordsCount;
	
	private int autoCorrectLoanBorrowerAddressCount;

	private String mode;
	
	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public int getAutoCorrectLoanBorrowerAddressCount() {
		return autoCorrectLoanBorrowerAddressCount;
	}

	public void setAutoCorrectLoanBorrowerAddressCount(int autoCorrectLoanBorrowerAddressCount) {
		this.autoCorrectLoanBorrowerAddressCount = autoCorrectLoanBorrowerAddressCount;
	}

	public int getUnverifiedRecordsCount() {
		return unverifiedRecordsCount;
	}

	public void setUnverifiedRecordsCount(int unverifiedRecordsCount) {
		this.unverifiedRecordsCount = unverifiedRecordsCount;
	}

	public String getSuccessMsg() {
		return successMsg;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<LoanBorrowerAddressDTO> getLoanBorrowerAddressData() {
		return loanBorrowerAddressData;
	}

	public void setLoanBorrowerAddressData(List<LoanBorrowerAddressDTO> loanBorrowerAddressData) {
		this.loanBorrowerAddressData = loanBorrowerAddressData;
	}
}
