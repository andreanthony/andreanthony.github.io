package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.MoreThanOneExcessPolicyException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.InsuranceRenewalItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.*;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.helper.coverage.ProvidedCoverageUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import microsoft.exchange.webservices.data.Importance;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class PrimaryExcessRule extends InsurableAssetCoverageRule {

	private static final Logger logger = Logger.getLogger(PrimaryExcessRule.class);
	
	private CtracEmailSender ctracEmailSender;
	
	protected PrimaryExcessRule(Collateral collateral, WorkItem triggerWorkItem, InsurableAsset insurableAsset,
			CoverageActionData coverageActionData) {
		super(collateral, triggerWorkItem, insurableAsset, coverageActionData);
	}

	@Override
	public void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult globalResults) {
		try {
			logger.debug("execute::BEGIN");
			Date date = globalResults.getCoverageDate();
			InsurableAssetDTO insurableAssetDTO = insurableAssetService.mapInsurableAsset(insurableAsset);
			Collection<FloodInsuranceDTO> requiredLpPolicies = LenderPlaceCalculator.calculateRequiredLPs(coverageActionData, date, insurableAssetDTO);
			logger.debug("calculateCoverageDate->" + date + ", number of LPs->" + requiredLpPolicies.size());
			
			List<ProvidedCoverage> activeLpCoverages = coverageActionData.getActiveLpCoverages(date);
			List<ProofOfCoverage> lpPoliciesToCancel = new ArrayList<ProofOfCoverage>();

			if (requiredLpPolicies == null || requiredLpPolicies.isEmpty()) {
				for (ProvidedCoverage lpCoverage : activeLpCoverages) {
					lpPoliciesToCancel.add(lpCoverage.getProofOfCoverage());
				}
			} else {
				Iterator<ProvidedCoverage> lpCoverageIter = activeLpCoverages.iterator();
				while (lpCoverageIter.hasNext()) {
					ProvidedCoverage currentLpCoverage = lpCoverageIter.next();
					ProofOfCoverage currentLpPolicy = currentLpCoverage.getProofOfCoverage();
					boolean foundMatch = false;
					Iterator<FloodInsuranceDTO> requiredLpIter = requiredLpPolicies.iterator();
					while (requiredLpIter.hasNext()) {
						FloodInsuranceDTO requiredLPPolicy = requiredLpIter.next();
						// find requirement with same coverage type
						if (currentLpCoverage.getProofOfCoverage().getCoverageType_() == requiredLPPolicy.getCoverageType()) { 	
							foundMatch = true;
							boolean isMatchingAmount = processMatchingCurrentLpPolicy(
									currentLpCoverage, requiredLPPolicy, lpPoliciesToCancel, globalResults);
							if (isMatchingAmount) {
								// remove requirement since we have a perfectly matching policy
								requiredLpIter.remove();
							}
							break;
						}
					}
					if (!foundMatch) {
						// cancel policy if we didn't processMatchingCurrentLpPolicy
						logger.debug("Active LP policy is no longer needed: " + currentLpPolicy.getRid());
						lpPoliciesToCancel.add(currentLpPolicy);
					}
				}
			}
			for (FloodInsuranceDTO requiredLpPolicy : requiredLpPolicies) {
				processLpIssuance(globalResults, requiredLpPolicy, lpPoliciesToCancel);
			}
			for (ProofOfCoverage lpPolicy : lpPoliciesToCancel) {
				cancelLpPolicy(globalResults, date, lpPolicy);
			}
			
		} catch (MoreThanOneExcessPolicyException e) {
			logger.error(e.getMessage());
			sendMoreThanOneExcessEmail(e);
		}
		logger.debug("execute::END");
	}

	protected boolean processMatchingCurrentLpPolicy(ProvidedCoverage currentLpCoverage, FloodInsuranceDTO requiredLPPolicy, 
			List<ProofOfCoverage> lpPoliciesToCancel, CoverageActionResult globalResults) {
		if(requiredLPPolicy == null){
			throw new IllegalArgumentException("Required LP Policy is null");
		}
		ProofOfCoverage currentLp = currentLpCoverage.getProofOfCoverage();

		BigDecimal requiredLpAmount = getProvidedCoverageAmount(requiredLPPolicy);
		BigDecimal currentLpAmount = currentLpCoverage.getCoverageDetails().getCoverageAmount();
		if(isMatchingAmount(requiredLpAmount, currentLpAmount, currentLpCoverage.getProofOfCoverage().getInsuranceAgency())){
			logger.debug("we have an existing active LP policy that covers the exact requirement->" + currentLp.getRid());
			if (isDateLapse(requiredLPPolicy) && requiredLPPolicy.getExpirationDate_().before(currentLp.getExpirationDate())) {
				logger.debug("Cancel or expire active LP policy, Date Lapse scenario ->" + currentLp.getRid());
				currentLp.setGapBorrowerPolicyRid(requiredLPPolicy.getParentPolicyRid()); //Rid of borrower policy that initiated the lapse
				globalResults.addProofOfCoverageToIssueWithGap(requiredLPPolicy);
				lpPoliciesToCancel.add(currentLp);
			}
			return true;
		} else {
            logger.debug("cancel the active LP policy CancelAndIssue scenario ->" + currentLp.getRid());
            currentLp.setGapBorrowerPolicyRid(requiredLPPolicy.getParentPolicyRid());
			lpPoliciesToCancel.add(currentLp);
		}
		return false;
	}
 
	protected boolean isMatchingAmount(BigDecimal requiredLpAmount, BigDecimal currentLpAmount, String insuranceAgency) {
		LpInsuranceVendor lpInsuranceVendor = LpInsuranceVendor.findByDisplayName(insuranceAgency);
		RoundingMode roundingMode = LenderPlaceCalculator.ALTHANS_ROUNDING_MODE;
		if(LpInsuranceVendor.ASSURANT.equals(lpInsuranceVendor)) {
			roundingMode = LenderPlaceCalculator.ASSURANT_ROUNDING_MODE;
		}
		return (currentLpAmount.setScale(0, roundingMode).compareTo(requiredLpAmount.setScale(0, roundingMode)) == 0);
	}

	private boolean isDateLapse(FloodInsuranceDTO lPPolicy) {	
		ProofOfCoverage borrowerPolicyRecieved = getBorrowerPolicyRecieved(lPPolicy.getCoverageType(), lPPolicy.getEffectiveDate_());
		return LenderPlaceReason.BORROWER_POLICY_RECEIVED_DATE_LAPSE == lPPolicy.getLenderPlaceReason() ||
				(borrowerPolicyRecieved != null && borrowerPolicyRecieved.getEffectiveDate().after(lPPolicy.getEffectiveDate_()));
	}

	protected void processLpIssuance(CoverageActionResult globalResults, FloodInsuranceDTO requiredLpPolicy, List<ProofOfCoverage> lpPoliciesToCancel){

		ProofOfCoverage expiringLpPolicy = getExpiringLPPolicy(requiredLpPolicy);
		if (expiringLpPolicy != null) {
			// this is an LP renewal scenario
			processLpRenewalIssue(globalResults, requiredLpPolicy, lpPoliciesToCancel, expiringLpPolicy);
		} else {
			// not an LP renewal scenario
			globalResults.addProofOfCoverageToIssue(requiredLpPolicy);
		}
	}

	protected void processLpRenewalIssue(CoverageActionResult globalResults, FloodInsuranceDTO requiredLpPolicy,
			List<ProofOfCoverage> lpPoliciesToCancel, ProofOfCoverage expiringLpPolicy) {
		PaymentMethod paymentMethod = expiringLpPolicy.getPreRenewalPaymentMethod();
		if (paymentMethod != null) {
			CtracObjectMapper ctracObjectMapper = ApplicationContextProvider.getContext().getBean(CtracObjectMapper.class);
			requiredLpPolicy.setInvoicePaymentMethod(ctracObjectMapper.map(paymentMethod, PaymentMethodDTO.class));
		}
        requiredLpPolicy.setPendingLpAction(LPActions.NEW_LP);

		if (isMatchForAutoRenewal(expiringLpPolicy, requiredLpPolicy)) {
			requiredLpPolicy.setPolicyStatus(PolicyStatus.PRE_INVOICED);
			// auto-renewal to the same amount				
			//preRenewalLetter from CTRAC
			if(!coverageActionData.isPreRenewalLetterSent() &&
					LpInsuranceVendor.ASSURANT.getDisplayName().equals(expiringLpPolicy.getInsuranceAgency())) {
				logger.debug("autorenewal ASSURANT->" + requiredLpPolicy.getRid());
				requiredLpPolicy.setPendingLpAction(LPActions.NO_ACTION);
				requiredLpPolicy.setPolicyStatus(PolicyStatus.INVOICED);
				requiredLpPolicy.setInsuranceAgency(LpInsuranceVendor.ASSURANT.getDisplayName());
			} else {
				logger.debug("autorenewal ALTHANS->" + requiredLpPolicy.getRid());
				if(LpInsuranceVendor.ALTHANS.getDisplayName().equals(expiringLpPolicy.getInsuranceAgency())){
					requiredLpPolicy.setPendingLpAction(LPActions.RENEW_LP);
				}
				requiredLpPolicy.setInsuranceAgency(LpInsuranceVendor.ALTHANS.getDisplayName());
				InsuranceRenewalItem renewalItem = expiringLpPolicy.findInsuranceRenewalItem();
				if (renewalItem != null) {
					requiredLpPolicy.setExpiredPreRenewalLetterDate(renewalItem.getPreRenewalLetterDate());
				}
			}  
			requiredLpPolicy.setParentPolicyRid(expiringLpPolicy.getRid());
			globalResults.getLpToRenewalNoChange().add(requiredLpPolicy);

		} else {
			requiredLpPolicy.setPolicyStatus(PolicyStatus.PENDING_LETTER_CYCLE);
			logger.debug("cancel and reissue->" + requiredLpPolicy.getRid());
			if(!isDateMatchForRenewal(requiredLpPolicy.getEffectiveDate_(), expiringLpPolicy.getExpirationDate())) {
                lpPoliciesToCancel.add(expiringLpPolicy);
                globalResults.getLpCoveragesToIssuesWithCancellation().add(requiredLpPolicy);
            }
			requiredLpPolicy.setPreviousExpiredAmount(getProvidedCoverageAmount(expiringLpPolicy));
			globalResults.addProofOfCoverageToIssue(requiredLpPolicy);
		}
	}
	
	protected ProofOfCoverage getExpiringLPPolicy(FloodInsuranceDTO requiredLpPolicy){
		Collection<ProofOfCoverage> allLpExpiring = ProvidedCoverageUtil.getExpiringProofOfCovOfType(
				PolicyType.lpPolicyTypes(), coverageActionData.getMaxDateForLetterProcessing(), coverageActionData.getAllActivePolicies());	
		if (allLpExpiring != null && !allLpExpiring.isEmpty()) {
			for (ProofOfCoverage lpExpiring : allLpExpiring) {
				if(lpExpiring.getCoverageType_().equals(requiredLpPolicy.getCoverageType())) {
					return lpExpiring;
				}
			}
		}
		ProofOfCoverage expiringProofOfCoverage = coverageActionData.getTriggerProofOfCoverage();
		if (expiringProofOfCoverage != null && expiringProofOfCoverage.getPolicyStatus_().isExpiring()
				&& expiringProofOfCoverage.getPolicyType_().isLenderPlaced()
				&& expiringProofOfCoverage.getCoverageType_().equals(requiredLpPolicy.getCoverageType())) {
			return expiringProofOfCoverage;
		}
		return null;
	}
	
	protected boolean isMatchForAutoRenewal(ProofOfCoverage expiringLpPolicy, ProofOfCoverageDTO requiredLpPolicy) {
		if (expiringLpPolicy == null || requiredLpPolicy == null) {
			return false;
		}
		BigDecimal requiredLpAmount = getProvidedCoverageAmount(requiredLpPolicy);
		BigDecimal expiringLpAmount = getProvidedCoverageAmount(expiringLpPolicy);
		boolean match = isDateMatchForRenewal(requiredLpPolicy.getEffectiveDate_(), expiringLpPolicy.getExpirationDate()) &&
				isMatchingAmount(expiringLpAmount, requiredLpAmount, expiringLpPolicy.getInsuranceAgency());
		if (match) {
			logger.info("\n Found an LP renewal candidate for the amount : " + expiringLpAmount);
		} else {
			logger.info("\n Didn't find an LP renewal candidate for the amount : " + expiringLpAmount);
			logger.info("\n Cancelling and reissuing for new amount : " + requiredLpAmount);
		}
		return match;
	}

    boolean isDateMatchForRenewal(Date effectiveDate, Date expirationDate) {
        return new DateTime(effectiveDate).withTimeAtStartOfDay().equals(
            new DateTime(expirationDate).withTimeAtStartOfDay());
    }

    private BigDecimal getProvidedCoverageAmount(ProofOfCoverageDTO proofOfCoverageDTO){
		ProvidedCoverageDTO providedCoverage = getProvidedCoverage(proofOfCoverageDTO);
		if(providedCoverage == null){
			return BigDecimal.ZERO;
		}
		return AmountFormatter.parse(providedCoverage.getCoverageDetailsDTO().getCoverageAmount());
	}
	
	private BigDecimal getProvidedCoverageAmount(ProofOfCoverage proofOfCoverage){
		if(proofOfCoverage == null){
			return BigDecimal.ZERO;
		}
		ProvidedCoverage providedCoverage = proofOfCoverage.getProvidedCoverages().get(0);
		return providedCoverage.getCoverageDetails().getCoverageAmount();
	}
	
	private ProvidedCoverageDTO getProvidedCoverage(ProofOfCoverageDTO proofOfCoverage){
		if(proofOfCoverage == null){
			return null;
		}
		ProvidedCoverageDTO providedCoverage = proofOfCoverage.getProvidedCoverageDTOs().get(0);
		
		return providedCoverage;
	}
	
	protected void sendMoreThanOneExcessEmail(MoreThanOneExcessPolicyException e) {
		if (ctracEmailSender == null) {
			ctracEmailSender = ApplicationContextProvider.getContext().getBean(CtracEmailSender.class);
		}
		ctracEmailSender.sendAlertEmailToFloodTeam(e.getMessage(), e.getMessage(), Importance.High);
	}
	
	@Override
	public Integer getPriority() {
		return 15;
	}
	
}
