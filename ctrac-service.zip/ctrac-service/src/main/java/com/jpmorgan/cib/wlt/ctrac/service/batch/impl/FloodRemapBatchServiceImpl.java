package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FileProcessingUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReconciliationLog;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.TaskDetailsData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.TaskSoruceDetailsData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CtracReferenceDateRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.FloodRemapRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.ReconciliationLogRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.TaskDetailsDataRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.TaskSoruceDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.tm.model.TMReconciliationView;
import com.jpmorgan.cib.wlt.ctrac.dao.tm.repository.TMReconcilationViewRepository;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.impl.PolicyAggregationRequestData;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapBatchService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapDataExtract;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ReconcilationResult;
import com.jpmorgan.cib.wlt.ctrac.service.dto.letters.CombinableLetter;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.email.impl.EmailAlertSender;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterFileGenerationService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import microsoft.exchange.webservices.data.Importance;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.format.DateTimeFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.File;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.BatchExitStatus.*;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.*;

@Service(value = "floodRemapBatchService")
public class FloodRemapBatchServiceImpl extends AbstractRemapServiceImpl implements FloodRemapBatchService {

	private static final Logger logger = Logger.getLogger(FloodRemapBatchServiceImpl.class);
    private static final String UNKNOWN_SERVICER_SUBJECT_1 = "Unknown servicer number(s) found in ";
    private static final String UNKNOWN_SERVICER_SUBJECT_2 = " remap file.";
    private static final String UNKNOWN_SERVICER_BODY_1 = "CTRAC received a remap file from ";
    private static final String UNKNOWN_SERVICER_BODY_2 = " with one or more servicer numbers that it does not recognize. If each remap record meets the criteria for a zone change a New Item task was created with the LOB as unknown. To avoid these emails in the future, request an update to the CTRAC mapping. The mapping request will require a LOB, unknown is an option, and indicate if the LOB is supported in CTRAC. Following is a list of the unrecognized servicer numbers from the file received.";
    private static final String UNKNOWN_SERVICER_BODY_3 = "<br/><br/>Unknown Servicer Numbers: ";

    private static final String GDSLETTERS_XMLFILE_OUTGOING_DIR = "gdsLetters.xmlfile.outgoing.directory";
	private static final String GDSLETTERS_XMLFILE_OUTGOING_TEMP_DIR = "gdsLetters.xmlfile.outgoing.temp.directory";
	private static final String GDSLETTERS_XMLFILE_ARCHIVE_DIR ="gdsLetters.xmlfile.archive.directory";

	@Autowired private ReconciliationLogRepository reconciliationLogRepository;
	@Autowired protected FloodRemapRepository floodRemapRepository;
	@Autowired private MessageSource messageSource;
	@Autowired private CtracReferenceDateRepository ctracReferenceDateRepository;

	@Qualifier("althansResponseDataExtract")
	private FloodRemapDataExtract althansResponseDataExtract;

	@Autowired
	@Qualifier("wireProcessingService")
	WireProcessingService wireProcessingService;
	@Qualifier("lenderPlaceService") LenderPlaceService lenderPlaceService;
	@Resource private Environment env;
	@Autowired private ReconcilationUtil reconcilationUtil;
	@Autowired private TaskDetailsDataRepository taskDetailsDataRepository;
	@Autowired private TaskSoruceDetailsRepository taskSoruceDetailsRepository;
	@Autowired private TMReconcilationViewRepository tmReconcilationViewRepository;
	@Autowired protected EmailAlertSender emailAlertSender;
	@Autowired private FloodEmailService floodEmailService;
	@Autowired protected LetterFileGenerationService letterFileGenerationService;



	@Transactional( value="transactionManager")
	@Override
	public void createNewFloodRemapTasks() {
		int successCount = 0;
		int failCount = 0;
		int totalInputRecords = 0;
		StringBuffer exceptionTrace = new StringBuffer("");

		try{
			// Get new flood remaps from DB.
			List<FloodRemap> floodRemaps = floodRemapRepository.getNewFloodRemaps();
			// Iterate Remap List
			if (floodRemaps != null && !floodRemaps.isEmpty()) {
				//updateLastRemapFileReceived();
				totalInputRecords = floodRemaps.size();
				String unknownLob = remapLineOfBusinessConverter.getUnknownLOB();
				Map<RemapVendor, List<String>> unknownServicerCodesMap = new HashMap<>();
				for (FloodRemap floodRemap : floodRemaps) {
					try {
					    setRemapLineOfBusiness(floodRemap);
                        if (floodRemap.getLineOfBusiness() == null) {
                            floodRemap.setLineOfBusiness(unknownLob);
                            RemapVendor remapVendor = RemapVendor.getFromDisplayName(floodRemap.getSourceSystem());
                            List<String> unknownServicerCodes = unknownServicerCodesMap.get(remapVendor);
                            if (unknownServicerCodes == null) {
                                unknownServicerCodes = new ArrayList<>();
                                unknownServicerCodesMap.put(remapVendor, unknownServicerCodes);
                            }
                            unknownServicerCodes.add(floodRemap.getDeptCode());
                        }
                        createNewTaskInTM(floodRemap);
						logger.debug("Loan number: " + floodRemap.getLoanNumber() + " was processed successfully");
						++successCount;
					}
					catch (Exception ex) {
						++failCount;
						logger.error(ex.getMessage() + floodRemap.getRid(), ex);
						logger.error(ex.getMessage(), ex);
						exceptionTrace.append(" " + ex.getMessage());
					}
				}

				for (Map.Entry<RemapVendor, List<String>> entry : unknownServicerCodesMap.entrySet()) {
                    sendUnknownServicerEmail(entry.getValue(), entry.getKey());
                }

				logger.info(successCount + " flood remaps were processed successfully.");
				if (failCount != 0) {
					logger.info(failCount + " flood remaps process failed.");
					//TODO send an email to ctrac dev team with list of count
				} else{
					logger.info("No problem.");
				}
			} else {
				logger.info("No Remaps were available for processing. No Tasks were created in TM.");
			}
		} finally {
			ReconciliationLog reconciliationLog =new ReconciliationLog();
			reconciliationLog.batchName(NEW_TASK_JOB.getName()).inputCount(totalInputRecords).processedCount(successCount).rejectedCount(0).fileName("NA_"+ NEW_TASK_JOB.getName()).exitLog(exceptionTrace.toString());
			logReconciliationAndExitInfoToDatabase(reconciliationLog,failCount);
		}
	}

	private void sendUnknownServicerEmail(List<String> servicerNumbersList, RemapVendor remapVendor) {
		StringBuffer servicerNumbers = new StringBuffer();
		for (String servicerNumber : servicerNumbersList) {
			CtracStringUtil.addValueWithSeparator(servicerNumbers, servicerNumber, ", ");
		}
		String remapVendorName = remapVendor.getDisplayName();
		emailAlertSender.sendAlertEmailToFloodTeam(
				UNKNOWN_SERVICER_SUBJECT_1 + remapVendorName + UNKNOWN_SERVICER_SUBJECT_2,
				UNKNOWN_SERVICER_BODY_1 + remapVendorName + UNKNOWN_SERVICER_BODY_2 +
                        UNKNOWN_SERVICER_BODY_3 + servicerNumbers.toString(), Importance.Normal);
	}

	@Override
	public void logReconciliationAndExitInfoToDatabase (ReconciliationLog reconciliationLog,  int exceptionRecordsCnt){
		try{

			reconciliationLog.setProcessedTimestamp(new Date());
			reconciliationLog.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);

			if( (reconciliationLog.getInputCount()!=(reconciliationLog.getProcessedCount()+reconciliationLog.getRejectedCount()+exceptionRecordsCnt)) ){
				reconciliationLog.setExitLog(FAILLED_TO_RECONCILE.getStatusDescription() +"Exception record: "+exceptionRecordsCnt);
				reconciliationLog.setGlobalExitStatus(FAILLED_TO_RECONCILE.name());
			}
			else{
				//Since we are validating, we expect exceptionRecordsCnt to be zero unless something weird happened
				if(exceptionRecordsCnt>0 || (reconciliationLog.getProcessedCount()<reconciliationLog.getRejectedCount()) ){
					reconciliationLog.setExitLog(PARTIALLY_FAIL.getStatusDescription() +"Exception record: "+exceptionRecordsCnt);
					reconciliationLog.setGlobalExitStatus(PARTIALLY_FAIL.name());
				}else if(reconciliationLog.getProcessedCount()<=0){
					reconciliationLog.setExitLog(NO_ACTION_TAKEN.getStatusDescription());
					reconciliationLog.setGlobalExitStatus(NO_ACTION_TAKEN.name());
				}else{
					reconciliationLog.setExitLog(ALL_SUCCESSFUL.getStatusDescription());
					reconciliationLog.setGlobalExitStatus(ALL_SUCCESSFUL.name());
				}

			}

			reconciliationLogRepository.save(reconciliationLog);

		}catch(Exception ex){
			logger.error(ex.getMessage(), ex);
			logger.error("Not able to save the reconcile audit in database.");
		}

	}

	/**
	 * Check if ctrac received a serviceLink file in the past 7 days
     * if not then send email notification
	 */
    @Override
	public void checkSLLastRemapFileReceivedDateAndNotify(){
    	logger.debug("checkSLLastRemapFileReceivedDateAndNotify():");

    	DateTime lastSLRemapReceivedDate = calendarDayUtil.getLastSLRemapFileReceivedDateTime();
		DateTime currentDate = new DateTime(calendarDayUtil.getCurrentReferenceDate());

		int days = Days.daysBetween(lastSLRemapReceivedDate, currentDate).getDays();
	 	logger.debug("Current date: "+currentDate +"Last remap inserted from SL: "+lastSLRemapReceivedDate+" Days between them: "+ days);
	 	//Send email notification if no email received in the past seven days for service link
	 	if(days> CtracAppConstants.MAX_SL_FILE_NOT_RECEIVED_DATE)
	 	{
	 		String subject = messageSource.getMessage("email.notification.subject.NoEmailReceivedSL", null, Locale.getDefault());
			String emailBody = messageSource.getMessage("email.notification.dateSinceLastRemapSL", null, Locale.getDefault()) +
					" " + lastSLRemapReceivedDate.toString(DateTimeFormat.forPattern("MMMM d',' YYYY").withLocale(Locale.US));
	 		notifyTooLongSinceLastRemapFile(subject, emailBody);
	 	}
    }

    /**
     * Check if ctrac received a coreLogic file in the past 7 days
     * if not then send email notification
     *
     */
    @Override
    public void checkCLLastRemapFileReceivedDateAndNotify(){
    	logger.debug("checkSLLastRemapFileReceivedDateAndNotify():");
    	DateTime lastCLRemapReceivedDate = calendarDayUtil.getLastCLRemapFileReceivedDateTime();
    	DateTime currentDate = new DateTime(calendarDayUtil.getCurrentReferenceDate());

		int days = Days.daysBetween(lastCLRemapReceivedDate, currentDate).getDays();
	 	logger.debug("Current date: "+currentDate +"Last remap inserted from CL: "+lastCLRemapReceivedDate+" Days between them: "+ days);

	 	//Send email notification if no email received in the past seven days for service link
	 	if(days> CtracAppConstants.MAX_CL_FILE_NOT_RECEIVED_DATE)
	 	{
	 		String subject = messageSource.getMessage("email.notification.subject.NoEmailReceivedCL", null, Locale.getDefault());
			String emailBody = messageSource.getMessage("email.notification.dateSinceLastRemapCL", null, Locale.getDefault()) +
					" " + lastCLRemapReceivedDate.toString(DateTimeFormat.forPattern("MMMM d',' YYYY").withLocale(Locale.US));
	 		notifyTooLongSinceLastRemapFile(subject, emailBody);
	 	}
    }

    void notifyTooLongSinceLastRemapFile(String subject, String emailBody) {
		EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
		emailAttributeHolder.addToAddress(env.getRequiredProperty("product.owner.team.email"));
		emailAttributeHolder.addCcAddress(env.getRequiredProperty("reconciliation.email.to"));
		emailAttributeHolder.setFromAddress(env.getRequiredProperty("from.email.address.ctrac.system"));
		emailAttributeHolder.setSubject(subject);
		emailAttributeHolder.setEmailBody(emailBody);
		try{
			logger.info("Attempting to send notification email...");
			floodEmailService.sendEmail(emailAttributeHolder);
			logger.info("Notification email sent successfully!");
		} catch (MailException e) {
			logger.error("Error occurred while ");
			throw new CTracApplicationException("E0141", CtracErrorSeverity.APPLICATION);
		}
	}

	/**
	 * Batch Process Method - Moves tasks from WFSID to another WFSID.
	 * TODO:  what if one of the job fail? have a last successful runtime used to determine if the job
	 *       should be considered or not
	 * TODO: individual operations need to be transactional not the whole
	 */
	@Override
	@Transactional
	public void calculateSLAandMoveTaskToNextWFStep() {
		int successCount = 0;
		int failCount = 0;
		int totalInputRecords = 0;
		StringBuffer exceptionTrace = new StringBuffer("");
		try {
			// Generic logic to age items.
			List<CombinableLetter> letters = new ArrayList<CombinableLetter>();
			List<PerfectionTask> allTasks = perfectionTaskRepository.findAllActivePerfectionTasks();
			if (allTasks != null && !allTasks.isEmpty()) {
				totalInputRecords = allTasks.size();
				for (PerfectionTask task : allTasks) {
					try {
						Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
						inputParameterMap.put(StateParameterType.PERFECTION_TASK, task);
						inputParameterMap.put(StateParameterType.LETTERS, letters);
						taskService.completeEODBatchOperations(inputParameterMap);
						++successCount;
					} catch (Exception ex) {
						++failCount;
						logger.error(ex.getStackTrace(), ex);
						logger.error(ErrorCodeToMessageConverter.convertToMessage("E0126", CtracErrorSeverity.CRITICAL) + task.getTmTaskId());
						exceptionTrace.append(" " + ex.getMessage());
					}
				}
			} else {
				logger.error(ErrorCodeToMessageConverter.convertToMessage("E0125", CtracErrorSeverity.APPLICATION));
			}
			letterFileGenerationService.sendLetterFile(letters);
		} finally {

			ReconciliationLog reconciliationLog = new ReconciliationLog();
			reconciliationLog.batchName(STATE_AND_SLA_JOB.getName()).inputCount(totalInputRecords).processedCount(successCount).rejectedCount(0).exitLog(exceptionTrace.toString());
			logReconciliationAndExitInfoToDatabase(reconciliationLog,failCount);
		}
	}

	/**
	 * Batch Process Method - Moves tasks matching the passed parameter from WFSID to another WFSID.
	 */
	@Override
	@Transactional
	public void completeEODBatchOperationsByWFStep(WorkflowStateDefinition workflowStateDefinition) {
		int successCount = 0;
		int failCount = 0;
		int totalInputRecords = 0;
		StringBuffer exceptionTrace = new StringBuffer("");
		try {
			List<PerfectionTask> allTasks = perfectionTaskRepository.findAllActivePerfectionTasksByWorkflowStep(workflowStateDefinition.getName());
			if (allTasks != null && !allTasks.isEmpty()) {
				totalInputRecords = allTasks.size();
				for (PerfectionTask task : allTasks) {
					try {
						Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
						inputParameterMap.put(StateParameterType.PERFECTION_TASK, task);
						taskService.completeEODBatchOperations(inputParameterMap);
						++successCount;
					} catch (Exception ex) {
						++failCount;
						logger.error(ex.getStackTrace(), ex);
						logger.error(ErrorCodeToMessageConverter.convertToMessage("E0126", CtracErrorSeverity.CRITICAL) + task.getTmTaskId());
						exceptionTrace.append(" " + ex.getMessage());
					}
				}
			} else {
				logger.error(ErrorCodeToMessageConverter.convertToMessage("E0125", CtracErrorSeverity.APPLICATION));
			}
		} finally {

			ReconciliationLog reconciliationLog = new ReconciliationLog();
			reconciliationLog.batchName(COMPLETE_EOD_BATCH_OPERATIONS.getName()).inputCount(totalInputRecords).processedCount(successCount).rejectedCount(0).exitLog(exceptionTrace.toString());
			logReconciliationAndExitInfoToDatabase(reconciliationLog,failCount);
		}
	}




	public void processWiredPolicy() {

		PolicyAggregationRequestData aggeationType = PolicyAggregationRequestData.getAggregationDataForLPremuinPayment();
		wireProcessingService.processWiredPolicy(aggeationType);

		aggeationType = PolicyAggregationRequestData.getAggregationDataForLPRefundRequest();
		wireProcessingService.processWiredPolicy(aggeationType);
	}

	@Override
	@Transactional
	public void updateReferenceDate(){
		try{
			ReferenceDate referenceDate = ctracReferenceDateRepository.findByName(CtracAppConstants.REFERENCE_DATE);
			Date nextCalendarDate = calendarDayUtil.getNextCalendarDate(referenceDate.getReferencDate());
			referenceDate.setReferencDate(nextCalendarDate);
			ctracReferenceDateRepository.save(referenceDate);
			logger.info("App reference date has been set to: "+nextCalendarDate);
		}catch(Exception e){
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0167", CtracErrorSeverity.CRITICAL));
			logger.error(e.getMessage(), e);
		}
	}

	@Override
    @Transactional
    public DateTime updateReferenceDate(int daysToAdd){
        ReferenceDate referenceDate = ctracReferenceDateRepository.findByName(CtracAppConstants.REFERENCE_DATE);
        Date nextCalendarDate = referenceDate.getReferencDate();

        if (daysToAdd > 0) {
            for (int i = 0; i < daysToAdd; i++) {
                nextCalendarDate = dateCalculator.getNextCalendarDate(nextCalendarDate);
            }
        } else {
            for (int i = 0; i > daysToAdd; i--) {
                nextCalendarDate = dateCalculator.getPreviousCalendarDate(nextCalendarDate);
            }
        }

        referenceDate.setReferencDate(nextCalendarDate);
        referenceDate = ctracReferenceDateRepository.save(referenceDate);
        return new DateTime(referenceDate.getReferencDate());
    }

	@Override
	public void processConfirmedWiredRequest() {
		wireProcessingService.processConfirmedWiredRequest();
	}

	@Override
	public void processPendingSendLOBEmailForAlthans() {
		wireProcessingService.processPendingSendLOBEmailForAlthans();
	}

	/**
	 * Method to reconcile CTrac database records vs TM database for all the OPEN tasks.
	 * 1.Fetch records from CTrac database with OPEN status
	 * 2.Fetch records from TM database with OPEN status
	 * 3.Compare each records field data,if there is any mismatch in any of the field populate a list
	 * with ReconcilationResult for each record with invalid data.
	 */
	@Override
	public void reconcileCtracAndTM() {
		try {

			//Get list of CTRAC and TM records for OPEN TASK STATUS.
			List<ReconcilationResult> reconResults = new  ArrayList<ReconcilationResult>();
			List<TaskDetailsData> taskDetailsDataList = taskDetailsDataRepository.findByTaskStatus(TaskStatus.OPEN.name());
			List<TaskSoruceDetailsData> taskSoruceDetailsDataList = taskSoruceDetailsRepository.findByTaskStatus(TaskStatus.OPEN.name());
			List<String> taskStates = new ArrayList<>(Arrays.asList("OPEN","LOCKED"));
			List<TMReconciliationView> tmDataList = tmReconcilationViewRepository.findByTaskStateIn(taskStates);


			if(!CollectionUtils.isEmpty(taskDetailsDataList) || !CollectionUtils.isEmpty(tmDataList)){
				List<ReconcilationResult> reconInsurancePolicyResults = reconcilationUtil.getReconcilationResult(taskDetailsDataList,taskSoruceDetailsDataList,tmDataList,CtracAppConstants.RECONCILE_FIELD_METADATA);
				reconResults.addAll(reconInsurancePolicyResults);
			}

			// Closing the tasks in Task Manager that mismatched in CTRAC recon file
			for (ReconcilationResult reconcilationResult : reconResults) {
				if (StringUtils.equals(reconcilationResult.getFieldName(),CtracAppConstants.TM_TASK_ID) && !StringUtils.equals(reconcilationResult.getId(),reconcilationResult.getSourceValue())) {
					TMReconciliationView tmReconciliationView = tmReconcilationViewRepository.findByTaskId(reconcilationResult.getId());
					tmReconciliationView.setTaskState(TaskStatus.CLOSED.name());
					tmReconciliationView.setTmWorkflowStep(WorkflowStateDefinition.COMPLETE.getName());
					tmReconcilationViewRepository.save(tmReconciliationView);
				}
			}
			prepareReconciliationReportAndSendEmail(CtracAppConstants.RECONCILE_XLXS_HEADER, CtracAppConstants.RECONCILE_REPORT_FILENAME,reconResults);
		}finally{
			ReconciliationLog reconciliationLog =reconcilationUtil.getReconciliationLog();
			reconciliationLog.setBatchName(POST_FULL_EOD_JOB.getName());
			reconciliationLog.setFileName(CtracAppConstants.RECONCILE_REPORT_FILENAME);
			reconciliationLogRepository.save(reconciliationLog);
		}
	}

	/**
	 * Prepares the Reconciliation report and send's a notification email.
	 * with the records details which are mismatching [CTrac db vs TM db]
	 * @param xlxsHeader
	 * @param reportFileName
	 * @param reconResults
	 */
	private void prepareReconciliationReportAndSendEmail(String[] xlxsHeader,
			String reportFileName, List<ReconcilationResult> reconResults) {
		if(!CollectionUtils.isEmpty(reconResults)) {
			EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
			File reconReport = reconcilationUtil.prepareReconciliationReport(reconResults, xlxsHeader, reportFileName , "CTRAC_TM_RECON");
			emailAttributeHolder.setSingleFileAttachment(reconReport);
			emailAttributeHolder.setSubject("Recon file from ctrac");
			emailAttributeHolder.setEmailBody("Recon file from ctrac");
			emailAttributeHolder.addToAddress(env.getRequiredProperty("reconciliation.email.to"));
			emailAttributeHolder.addCcAddress(env.getRequiredProperty("product.owner.team.email"));
			emailAttributeHolder.addCcAddress(env.getRequiredProperty("autocopy.email.address.flood.service"));
			emailAttributeHolder.addCcAddress(env.getRequiredProperty("autocopy.email.address.ctl.flood.service"));
			emailAttributeHolder.setFromAddress(env.getRequiredProperty("from.email.address.ctrac.system"));
			floodEmailService.sendEmail(emailAttributeHolder);
		}
	}

	@Override
	public void processAlthansResponseFile() {
		try{

			logger.debug("AlthansResponse files processed and moved to archive folder.");
			althansResponseDataExtract.processAlthansResponse();
			logger.debug("AlthansResponse files processed and moved to archive folder.");

		}catch(Exception e)
		{
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0325", CtracErrorSeverity.CRITICAL));
			logger.error(e.getMessage(), e);
		}
	}
	
	@Override
	public void migrateOpenTasksToTM() {		
		try {
			logger.debug("migrateOpenTasksToTM started.");
			tmService.migrateTasksToTM();
			logger.debug("migrateOpenTasksToTM ended");

		} catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0325", CtracErrorSeverity.CRITICAL));
			logger.error(ex.getMessage(), ex);
			throw new CTracApplicationException("E0128", CtracErrorSeverity.APPLICATION, ex);			
		}		
	}

	@Override
	public void placeValidLetterFile()
	{
		logger.debug("placeValidLetterFile started.");
		StringBuilder sourceDirectoryPath = new StringBuilder();
		sourceDirectoryPath.append(env.getProperty(GDSLETTERS_XMLFILE_OUTGOING_TEMP_DIR))
				.append(CtracAppConstants.PATH_SEPERATOR);

		StringBuilder destinationDirectoryPath = new StringBuilder();
		destinationDirectoryPath.append(env.getProperty(GDSLETTERS_XMLFILE_OUTGOING_DIR))
				.append(CtracAppConstants.PATH_SEPERATOR);

		FileProcessingUtil.moveAndOverwrite(
				sourceDirectoryPath.toString(), destinationDirectoryPath.toString());
		logger.debug("placeValidLetterFile end.");
	}

	@Override
	public void archiveInValidLetterFile()
	{
		logger.debug("archiveInValidLetterFile started.");
		StringBuilder sourceDirectoryPath = new StringBuilder();
		sourceDirectoryPath.append(env.getProperty(GDSLETTERS_XMLFILE_OUTGOING_TEMP_DIR))
				.append(CtracAppConstants.PATH_SEPERATOR);

		StringBuilder destinationDirectoryPath = new StringBuilder();
		destinationDirectoryPath.append(env.getProperty(GDSLETTERS_XMLFILE_ARCHIVE_DIR))
				.append(CtracAppConstants.PATH_SEPERATOR);

		FileProcessingUtil.archiveEntireDirectory(sourceDirectoryPath.toString(), destinationDirectoryPath.toString());
	}
}
