package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.ReviewCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ExpiringPolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class ExpiringPolicyServiceImpl implements ExpiringPolicyService {

    private ActivePolicyService activePolicyService;
    private BusinessDayUtil businessDayUtil;
    private CollateralInsuranceRepository collateralInsuranceRepository;
    private InsuranceMngtService insuranceMngtService;
    private ReviewCollateralService reviewCollateralService;

    @Autowired
    public ExpiringPolicyServiceImpl(ActivePolicyService activePolicyService, BusinessDayUtil businessDayUtil,
                                     CollateralInsuranceRepository collateralInsuranceRepository,
                                     InsuranceMngtService insuranceMngtService,
                                     ReviewCollateralService reviewCollateralService) {
        this.activePolicyService = activePolicyService;
        this.businessDayUtil = businessDayUtil;
        this.collateralInsuranceRepository = collateralInsuranceRepository;
        this.insuranceMngtService = insuranceMngtService;
        this.reviewCollateralService = reviewCollateralService;
    }

    @Override
    public boolean updateExpiringPolicyStatus(ProofOfCoverage proofOfCoverage) {
        Date today = businessDayUtil.getCurrentReferenceDateAtStartOfDay();
        if (proofOfCoverage.getPolicyStatus_() == PolicyStatus.EXPIRING_EA) {
            return updateExpiringEAPolicyStatus(proofOfCoverage, today);
        }
        LPActions lpAction = proofOfCoverage.getLpAction_();
        if (proofOfCoverage.isExpiring(today, true) && !hasOutstandingReviewCollateral(proofOfCoverage.getRid())) {
            if (LPActions.CANCEL_LP != lpAction && LPActions.NO_ACTION != lpAction &&
                    insuranceMngtService.hasOutstandingCoverageRequest(proofOfCoverage.getRid())) {
                // update policies that had expired but we don't have the fiat and haven't ran c3 (lLPActions != NO_ACTION)
                if (insuranceMngtService.isPolicyCoversBusinessAssetSBAOnly(proofOfCoverage)) {
                    proofOfCoverage.setPolicyStatus(PolicyStatus.EXPIRING_SBA_COVERAGE_NR.name());
                    activePolicyService.setAllPolicyStatuses(proofOfCoverage, PolicyStatus.EXPIRING_SBA_COVERAGE_NR);
                } else {
                    proofOfCoverage.setPolicyStatus(PolicyStatus.EXPIRING_FIAT_NR.name());
                    activePolicyService.setAllPolicyStatuses(proofOfCoverage, PolicyStatus.EXPIRING_FIAT_NR);
                }
            } else if (lpAction == null || LPActions.NO_ACTION == lpAction) {
                // update expired policy for which an LP replacement had been computed and there is no pending action
                proofOfCoverage.setPolicyStatus(PolicyStatus.EXPIRED.name());
                activePolicyService.setAllPolicyStatuses(proofOfCoverage, PolicyStatus.EXPIRED);
                return true;
            }
        }
        return false;
    }

    private boolean updateExpiringEAPolicyStatus(ProofOfCoverage proofOfCoverage, Date today) {
        if (proofOfCoverage.isExpiring(today, true) &&
                insuranceMngtService.isRenewalPolicyAccepted(proofOfCoverage)) {
            activePolicyService.setAllPolicyStatuses(proofOfCoverage, PolicyStatus.EXPIRED);
            return true;
        }
        return false;
    }

    private boolean hasOutstandingReviewCollateral(Long proofOfCoverageRid) {
        List<CollateralInsuranceViewData> collateralInsuranceRelations =
                collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverageRid);
        for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceRelations) {
            Long collateralRid = collateralInsurance.getCollateral().getRid();
            if (reviewCollateralService.hasActiveReviewCollateralTask(collateralRid)) {
                return true;
            }
        }
        return false;
    }
}
