package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class SignedByAgentRuleWorker extends AbstractBIRRuleWorker {

	public SignedByAgentRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {

		BIRRuleConclusionDTO signedByAgentConclusion  = 
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if (borrowerInsuranceReviewData.getSignedByAgent() == null) {
			return;
		} else if ("Yes".equals(borrowerInsuranceReviewData.getSignedByAgent())) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
		}
		signedByAgentConclusion.setConclusion(birConclusion.name());
	}
}
