package com.jpmorgan.cib.wlt.ctrac.service.bir;

public enum EmailSequence {

	FIRST("First"),
	SECOND("Second"),
	THIRD("Third"),
	FINAL("Final");
	
	private final String displayValue;
	
	private EmailSequence(String displayValue) {
		this.displayValue = displayValue;
	}
	
	public String getDisplayValue() {
		return displayValue;
	}
	
}
