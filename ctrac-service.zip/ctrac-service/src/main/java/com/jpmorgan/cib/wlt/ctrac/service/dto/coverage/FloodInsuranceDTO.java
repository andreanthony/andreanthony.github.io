package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LpInsuranceVendor;


public class FloodInsuranceDTO extends ProofOfCoverageDTO implements Cloneable {

	private static final long serialVersionUID = 1L;
	
	private String floodCoverageType;
	
	private String floodCoverageIncluded;

	private String coversAllRiskOfFlood;

	private String floodZonesListed;
	
	private String piaAssessmentExceptions;

    public FloodInsuranceDTO() {
        super(InsuranceType.FLOOD, LpInsuranceVendor.ALTHANS.getDisplayName());
    }

	public String getFloodCoverageType() {
		return floodCoverageType;
	}

	public void setFloodCoverageType(String floodCoverageType) {
		this.floodCoverageType = floodCoverageType;
	}

	public String getFloodCoverageIncluded() {
		return floodCoverageIncluded;
	}

	public void setFloodCoverageIncluded(String floodCoverageIncluded) {
		this.floodCoverageIncluded = floodCoverageIncluded;
	}

	public String getCoversAllRiskOfFlood() {
		return coversAllRiskOfFlood;
	}

	public void setCoversAllRiskOfFlood(String coversAllRiskOfFlood) {
		this.coversAllRiskOfFlood = coversAllRiskOfFlood;
	}

	public String getFloodZonesListed() {
		return floodZonesListed;
	}

	public void setFloodZonesListed(String floodZonesListed) {
		this.floodZonesListed = floodZonesListed;
	}

	public String getPiaAssessmentExceptions() {
		return piaAssessmentExceptions;
	}

	public void setPiaAssessmentExceptions(String piaAssessmentExceptions) {
		this.piaAssessmentExceptions = piaAssessmentExceptions;
	}
	@Override
	protected FloodInsuranceDTO clone() throws CloneNotSupportedException {
		return (FloodInsuranceDTO) super.clone();
	}

}
