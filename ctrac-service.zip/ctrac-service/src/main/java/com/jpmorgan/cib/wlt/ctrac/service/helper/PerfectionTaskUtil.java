package com.jpmorgan.cib.wlt.ctrac.service.helper;



import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.SleepingTaskState;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;



public class PerfectionTaskUtil {

	private static final Logger logger = Logger.getLogger(PerfectionTaskUtil.class);

	public static PerfectionTask instantiate(
			TaskStatus taskStatus, WorkItem perfectionItem, TaskState state,
			TMTaskType tmTaskType, String insertedBy, Map<StateParameterType, Object> inputParameterMap) {
		logger.debug("instantiatePerfectionTask::BEGIN");
		if (inputParameterMap == null) {
			inputParameterMap = new HashMap<StateParameterType, Object>();
		}
		if(!inputParameterMap.containsKey(StateParameterType.WORK_ITEM)){
			inputParameterMap.put(StateParameterType.WORK_ITEM, perfectionItem);
		}
		Date wakeUpDate = null;
		if (taskStatus == TaskStatus.SLEEPING) {
			if(!(state instanceof SleepingTaskState)) {
				logger.error("Workflow transition error: The task in state " + state.getName() + " cannot be put to sleep");
				throw new CTracApplicationException("E0156", CtracErrorSeverity.APPLICATION);
			}
			wakeUpDate = ((SleepingTaskState) state).getWakeupDate(inputParameterMap);
		} else if (taskStatus == TaskStatus.TRANSIENT && state instanceof SleepingTaskState) {
			wakeUpDate = ((SleepingTaskState) state).getWakeupDate(inputParameterMap);
		}
		
		int slaDaysRemaining = state.computeInitialSLADays(inputParameterMap);
		PerfectionTask perfectionTask = new PerfectionTaskBuilder(perfectionItem, state.getName(), taskStatus, insertedBy).
				slaDaysRemaining(slaDaysRemaining).tmTaskType(tmTaskType).wakeUpDate(wakeUpDate).build();
		logger.debug("instantiatePerfectionTask::END");
		return perfectionTask;
	}

}