package com.jpmorgan.cib.wlt.ctrac.service.admin;

import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.TaskAdminDTO;

public interface TaskAdminService {

	TaskAdminDTO prepareTaskAdminData();
	
	boolean validateTaskAdminData(TaskAdminDTO taskAdminData);
	
	void submitTaskAdminData(TaskAdminDTO taskAdminData);
	
}
