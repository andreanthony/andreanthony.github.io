package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.*;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.propertytype.FIATPropertyType;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class InsurancePolicyRequirementDto implements Serializable, Cloneable{

    /**
	 */
    private static final long serialVersionUID = 1L;
    private static final Logger logger = Logger.getLogger(InsurancePolicyRequirementDto.class);

    private InsurancePolicyRequirementDto loadTimeValue;
    private InsuranceCoverageMap<RequiredCoverageDTO> requiredCoverageMap = new InsuranceCoverageMap<RequiredCoverageDTO>(RequiredCoverageDTO.class);

    private RequiredCoverageSourceDto  requiredCoverageSourceDto;

    private String action = "edit";
    private String successMessage = null;
    //True if there is no active policy insuring any building/structure tied to this fiat
    private boolean canDelete = true;
    private String minDocumentDate = null;
    private String[] residentialPropertyTypes = null;

    /**
     * @return the requiredCoverageMap
     */
    public InsuranceCoverageMap<RequiredCoverageDTO> getRequiredCoverageMap() {
        return requiredCoverageMap;
    }

    public void saveACopy() {
        try {
            this.getRequiredCoverageSourceDto().saveACopy();
           Iterator<RequiredCoverageDTO> requiredCoverageIter =  this.getRequiredCoverages().iterator();
            while (requiredCoverageIter.hasNext()) {
                RequiredCoverageDTO requiredCoverageDTO = requiredCoverageIter.next();
                requiredCoverageDTO.saveACopy();
            }
            this.loadTimeValue = this.clone();

        } catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
        }
    }


    public boolean hasChanged() {
        if (this.loadTimeValue == null ) {
            return true;
        }
        return !deepEquals(this.loadTimeValue);
    }

    public boolean deepEquals(Object obj){
        if(this == obj) {
            return true;
        }
        if(obj == null) {
            return false;
        }
        if(getClass() != obj.getClass()) {
            return false;
        }
        if(getRequiredCoverageSourceDto().hasChanged()) {
            return false;
        }
        Iterator<RequiredCoverageDTO> requiredCoverageIter =  this.getRequiredCoverages().iterator();
        while (requiredCoverageIter.hasNext()) {
            RequiredCoverageDTO requiredCoverageDTO = requiredCoverageIter.next();
            if(requiredCoverageDTO.hasChanged()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public InsurancePolicyRequirementDto clone() throws CloneNotSupportedException {
        return (InsurancePolicyRequirementDto) super.clone();
    }


    /**
     * @param requiredCoverageMap
     *            the requiredCoverageMap to set
     */
    public void setRequiredCoverageMap(InsuranceCoverageMap<RequiredCoverageDTO> requiredCoverageMap) {
        this.requiredCoverageMap = requiredCoverageMap;
    }

    public boolean isEmpty() {
        return this.getRequiredCoverageMap().getInsurableAssetCoverageData() == null
                || this.getRequiredCoverageMap().getInsurableAssetCoverageData().isEmpty();
    }

    public void addCoverageRequirement(RequiredCoverageDTO requiredCoverageDTO) {
        requiredCoverageMap.put(requiredCoverageDTO);

        //New required coverage: read coverage source from this object if populated
        if(this.requiredCoverageSourceDto!=null && requiredCoverageDTO.getRequiredCoverageSourceDto()==null){
            requiredCoverageDTO.setRequiredCoverageSourceDto( this.requiredCoverageSourceDto);
        }
        //initial loading of req cov from db:, read coverage source info from reqcov if available
        if( this.requiredCoverageSourceDto==null && requiredCoverageDTO.getRequiredCoverageSourceDto()!=null ){
            this.requiredCoverageSourceDto = requiredCoverageDTO.getRequiredCoverageSourceDto();
        }

        if(requiredCoverageDTO.getHadSomeCoverage()){
            this.canDelete = false;
        }
    }

    public RequiredCoverageSourceDto getRequiredCoverageSourceDto() {
        return requiredCoverageSourceDto;
    }

    public void setRequiredCoverageSourceDto(RequiredCoverageSourceDto requiredCoverageSourceDto) {
        this.requiredCoverageSourceDto = requiredCoverageSourceDto;
    }

    public void addCoverageRequirement(Collection<RequiredCoverageDTO> requiredCoverageDTOs) {

        for (RequiredCoverageDTO requiredCoverageDTO : requiredCoverageDTOs) {
            addCoverageRequirement(requiredCoverageDTO);
        }
    }

    public Collection<RequiredCoverageDTO> getRequiredCoverages() {

        Collection<RequiredCoverageDTO> allCoverages = requiredCoverageMap.getAllCoverages(true, null);

       for (RequiredCoverageDTO requiredCoverageDTO : allCoverages) {
          requiredCoverageDTO.setRequiredCoverageSourceDto(this.requiredCoverageSourceDto);
        }

        return allCoverages;
    }

    /**
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

    public void prepareForVerification() {
        Collection<RequiredCoverageDTO> allCoverages = requiredCoverageMap.getAllCoverages(true, null);
        for (RequiredCoverageDTO requiredCoverageDTO : allCoverages) {
        	if (requiredCoverageDTO.getPrimaryCoverageDetailsDto() != null) {
        		requiredCoverageDTO.getPrimaryCoverageDetailsDto().prepareForVerify();
        	}

        	if (requiredCoverageDTO.getExcessCoverageDetailsDto() != null) {
        		requiredCoverageDTO.getExcessCoverageDetailsDto().prepareForVerify();
        	}
        }
        this.canDelete = true;
        this.setAction("verify");
    }
	public void prepareForEdit() {
        Collection<RequiredCoverageDTO> allCoverages = requiredCoverageMap.getAllCoverages(true, null);
        for (RequiredCoverageDTO requiredCoverageDTO : allCoverages) {
            //requiredCoverageDTO.getCoverageDetailsDTO().prepareForEdit();
        	if (requiredCoverageDTO.getPrimaryCoverageDetailsDto() != null) {
        		requiredCoverageDTO.getPrimaryCoverageDetailsDto().prepareForEdit();
                requiredCoverageDTO.setPrimaryHold(requiredCoverageDTO.getPrimaryCoverageDetailsDto().getHoldDTO());
        	}

        	if (requiredCoverageDTO.getExcessCoverageDetailsDto() != null) {
        		requiredCoverageDTO.getExcessCoverageDetailsDto().prepareForEdit();
                requiredCoverageDTO.setExcessHold(requiredCoverageDTO.getExcessCoverageDetailsDto().getHoldDTO());
            }
        }
        this.setAction("edit");

	}


    public void finalizeVerification() {

        Collection<RequiredCoverageDTO> allCoverages = requiredCoverageMap.getAllCoverages(true, null);

        if(allCoverages==null|| allCoverages.isEmpty() || requiredCoverageSourceDto==null ){
            return; //nothing to be saved
        }


        if(CoverageRequirementStatus.PENDING_VERIFICATION.name().equals(requiredCoverageSourceDto.getStatus())){
            requiredCoverageSourceDto.setStatus(CoverageRequirementStatus.VERIFIED.name());
        }else if(CoverageRequirementStatus.VERIFIED.name().equals(requiredCoverageSourceDto.getStatus())){
                requiredCoverageSourceDto.setStatus( CoverageRequirementStatus.INACTIVE.name() );
        }


        for (RequiredCoverageDTO requiredCoverageDTO : allCoverages) {
            requiredCoverageDTO.setRequiredCoverageSourceDto(requiredCoverageSourceDto);
        }
    }

    public Boolean canDelete(){
        return this.canDelete;
    }

    public void setCanDelete(boolean canDelete){
        this.canDelete= canDelete;
    }

    public boolean isLast( Long collateralId ){
        return (1>= requiredCoverageMap.size(collateralId));
    }

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public String getMinDocumentDate() {
		return minDocumentDate;
	}

	public void setMinDocumentDate(String minDocumentDate) {
		this.minDocumentDate = minDocumentDate;
	}

	public String[] getResidentialPropertyTypes() {
		return(FIATPropertyType.getResidentialPropertyType());
	}

	public void setResidentialPropertyTypes(String[] residentialPropertyTypes) {
		this.residentialPropertyTypes = residentialPropertyTypes;
	}
}
