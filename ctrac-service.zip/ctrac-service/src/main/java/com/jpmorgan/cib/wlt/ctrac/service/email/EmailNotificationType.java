package com.jpmorgan.cib.wlt.ctrac.service.email;



public enum EmailNotificationType {

    PRE_LP_ZONE_CHANGE_EMAIL ("Zone Change Market Email", "PRE_LP_INIT_LOB_EMAIL"),
    //PRE_LP_EMAIL_AT_RISK ("Zone Change Market Email Action Required.", "PRE_LP_INIT_LOB_EMAIL"),
    LP_INITIATED_MARKET("Lender placement intitiated Market email ", "LP_REQUEST_SEND_LOD_EMAIL"),
    INSURANCE_EXCEPTION_EMAIL("INSURANCE_EXCEPTION_EMAIL", "INSURANCE_EXCEPTION_EMAIL"),
	INSURANCE_NO_EXCEPTION_EMAIL("INSURANCE_NO_EXCEPTION_EMAIL", "INSURANCE_NO_EXCEPTION_EMAIL"),
    LEAD_AGENT_EMAIL("LEAD_AGENT_EMAIL", "LEAD_AGENT_EMAIL"),
    MARKET_HOLD_EMAIL("MARKET_HOLD_EMAIL", "MARKET_HOLD_EMAIL");

    private String displayName;
    private String emailCategory;

    private EmailNotificationType(String displayName, String category){ this.displayName= displayName; this.emailCategory = category;}

    public String getDisplayName() {
        return displayName;
    }

    public String getEmailCategory() {
        return emailCategory;
    }

}
