package com.jpmorgan.cib.wlt.ctrac.service.insurableasset.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracBaseException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DefaultDateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.JavaScriptDateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CoverageDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Hold;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.RequiredCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralSearchViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.HoldDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.HoldHistoryViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.HoldWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItemRelation;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralSearchViewDataRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.CommonTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.WorkItemAndRelationsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CompleteItemData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.HoldDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.HoldStatusDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.HoldDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.HoldHistoryViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskBuilder;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.CollateralCoverageComputationService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TaskUniqueIdGenerator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.HOLD_PERIODS;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.HOLD_TYPES;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.*;

@Service
public class HoldServiceImpl implements HoldService {
	private static final Logger logger = Logger.getLogger(HoldServiceImpl.class);

	@Autowired private TMService otmService;
	@Autowired private WorkItemRepository workItemRepository;
	@Autowired private OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher;
	@Autowired private DateCalculator dateCalculator;
	@Autowired private WorkItemAndRelationsService workItemAndRelationsService;
	@Autowired private PerfectionTaskService perfectionTaskService;
	@Autowired private HoldWorkItemRepository holdWorkItemRepository;
	@Autowired private WorkItemRelationRepository workItemRelationRepository;
	@Autowired private HoldRepository holdRepository;
	@Autowired private CollateralDocumentRepository collateralDocumentRepository;
	@Autowired private HoldDetailsRepository holdDetailsRepository;
	@Autowired private CollateralSearchViewDataRepository collateralSearchViewDataRepository;
	@Autowired private LookupCodeRepository lookupCodeRepository;
	@Autowired private CtracObjectMapper ctracObjectMapper;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	@Autowired private CollateralDocumentService collateralDocumentService;
	@Autowired private CoverageDetailsRepository coverageDetailsRepository;
	@Autowired private CommonTaskService commonTaskService;
	@Autowired private AuditInformationService auditInformationService;
	@Autowired private TaskService taskService;
	@Autowired private HoldHistoryViewDataRepository holdHistoryViewDataRepository;
	@Autowired private CollateralRepository collateralRepository;
	@Autowired private CollateralCoverageComputationService collateralCoverageComputationService;
	@Autowired private RequiredCoverageRepository requiredCoverageRepository;

	private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
	private static final DateFormatter JAVASCRIPT_DATE_FORMATTER = new JavaScriptDateFormatter();
	private static final int REMAP_TASK_UNIQUE_ID_LENGTH = 6;

    @Override
    public Collateral processHold(Collection<RequiredCoverageDTO> requiredCoverageDtos, Long collateralRid) throws Exception {
    	//Key: HoldType|ExpiryDate    Value: ParentWorkItem
    	HashMap<String, WorkItem> holdTypeExpiryDate = new HashMap<>();
    	Collateral collateral = collateralRepository.findOne(collateralRid);
		for (RequiredCoverageDTO dto : requiredCoverageDtos) {
            startHoldWorkflow(dto.getPrimaryHold(), holdTypeExpiryDate, collateral);
            startHoldWorkflow(dto.getExcessHold(), holdTypeExpiryDate, collateral);
        }
		return collateral;
    }

    void startHoldWorkflow(HoldDTO holdDTO, Map<String, WorkItem> holdTypeExpiryDate, Collateral collateral) throws Exception {
        if(holdDTO != null  && holdDTO.getRid() != null &&
                CollectionUtils.isEmpty(holdWorkItemRepository.findByHoldRid(holdDTO.getRid()))) {
            createAggregateHoldTasks(holdDTO, holdTypeExpiryDate, collateral);
        }
    }

    void createAggregateHoldTasks(HoldDTO holdDto, Map<String, WorkItem> holdTypeExpiryDate, Collateral collateral) throws Exception {
		if (holdDto != null && holdDto.getRid() != null) {
			Date holdStartDate = DATE_FORMATTER.parse(holdDto.getStartDate());

			String holdPeriod = holdDto.getHoldPeriod();

			Date holdExpiryDate = getHoldPeriodExpirationDate(holdStartDate, holdPeriod);

			String holdExpiryDateStr = DATE_FORMATTER.print(holdExpiryDate);

			// Create Child WorkItem
			WorkItem childWorkItem = createHoldWorkItem(holdDto.getHoldType(), PerfectionItemSubType.HOLD.name(), holdDto.getRid());

			WorkItem parentWorkItem =  holdTypeExpiryDate.get(holdDto.getHoldType()+"|"+holdExpiryDateStr);

			if (parentWorkItem == null) {
				 parentWorkItem = createHoldWorkItem(holdDto.getHoldType(), PerfectionItemSubType.HOLD.name(), 0L);
				 holdTypeExpiryDate.put(holdDto.getHoldType()+"|"+holdExpiryDateStr, parentWorkItem);
				 Map<StateParameterType, Object> inputParameterMap = new HashMap<>();
				 inputParameterMap.put(StateParameterType.HOLD_END_DATE, holdExpiryDate);
				 perfectionTaskService.createSleepingTask(parentWorkItem, UPDATE_HOLD_STATUS.getFloodRemapTaskState(), TMTaskType.FLOOD_INSURANCE, inputParameterMap);
				 createSendMarketHoldEmailTask(holdExpiryDate, parentWorkItem);
			 }

			 workItemAndRelationsService.createRelation(parentWorkItem, childWorkItem, TaskRelationType.HOLDTOFIAT, "SYSTEM");

			 collateral.addWorkItem(parentWorkItem);
			 collateralRepository.save(collateral);
		}
    }

    WorkItem createHoldWorkItem(String perfectionType, String perfectionItemSubType, Long holdRid) {
        HoldWorkItem workItem = new HoldWorkItem();
        workItem.setWorkFlowID(generateWorkflowId());
        workItem.setInitiationDate(dateCalculator.getCurrentReferenceDate());
        workItem.setPerfectionType(perfectionType);
        workItem.setPerfectionSubType(perfectionItemSubType);
        workItem.setInitialAuditInfo("SYSTEM");
        workItem.setHoldRid(holdRid);
        workItem = workItemRepository.save(workItem);
        return workItem;
    }

    String generateWorkflowId() {
        return TaskUniqueIdGenerator.generateAlphaNumericUniqueId(REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher);
    }

    @Transactional
    @Override
    public HoldStatusDto prepareHoldHelperData(TMParams TMParams, String janusUserId) {
        String otmTaskId = TMParams.getId_task();
        final PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(otmTaskId);

        HoldWorkItem parentHoldWorkItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), HoldWorkItem.class);

        // Get Child WorkItems
        List<WorkItemRelation> workItemRelations = workItemRelationRepository.findByParentWorkItemAndRelationType(parentHoldWorkItem, TaskRelationType.HOLDTOFIAT.name());

        // For all holds under this AggregateTask, updatedBy will be same. So we can get any hold. In this case we got first one.
        HoldWorkItem childHoldWorkItem = CtracBaseEntity.deproxy(workItemRelations.get(0).getChildWorkItem(), HoldWorkItem.class);
        Hold hold = holdRepository.findOne(childHoldWorkItem.getHoldRid());

        if (VERIFY_HOLD_STATUS.getName().equals(perfectionTask.getWorkflowStep())) {
            if (janusUserId.equals(hold.getUpdatedBy())) {
                throw new CTracBaseException("E0251", CtracErrorSeverity.TRIVIAL);
            }
        }

		HoldStatusDto holdStatusDto = new HoldStatusDto();
		holdStatusDto.setTmParams(TMParams);

		if (parentHoldWorkItem.getDocumentRid() != null) {
			CollateralDocument collateralDocument = collateralDocumentRepository.findByRid(parentHoldWorkItem.getDocumentRid());
			holdStatusDto.setDocRid(collateralDocument.getRid());
			holdStatusDto.setFileName(collateralDocument.getFileName());
		}

		holdStatusDto.setPerfectionTask(perfectionTask);
		holdStatusDto.setTmTaskId(perfectionTask.getTmTaskId());

		List<HoldDetailsViewData> holdDetailsViewDataList = holdDetailsRepository.findByParentWorkItemRid(parentHoldWorkItem.getRid());
		List<HoldDetailsViewDto> holdDetailsViewDtoList = ctracObjectMapper.mapAsList(holdDetailsViewDataList, HoldDetailsViewDto.class);

		// Reset the value of HoldPeriod as blank to show blank on screen by default
		String curWkflStep = perfectionTask.getWorkflowStep();
		if (!VERIFY_HOLD_STATUS.getName().equals(curWkflStep)) {
			holdStatusDto.setMode("edit");
			for (HoldDetailsViewDto holdDetailsViewDto: holdDetailsViewDtoList) {
				holdDetailsViewDto.setHoldPeriod("");
			}
		} else {
			holdStatusDto.setMode("verify");
		}

		holdStatusDto.setHoldDetailsViewDtoList(holdDetailsViewDtoList);

		// For all holds under this AggregateTask, holdType and CollateralRID will be same. So we can get any hold. In this case we got first one.
		holdStatusDto.setHoldType(holdDetailsViewDataList.get(0).getHoldType());
		Long collateralRid = holdDetailsViewDataList.get(0).getCollateralRid();

		CollateralSearchViewData collateralSearchViewData = collateralSearchViewDataRepository.findByCollateralRid(collateralRid).get(0);
		holdStatusDto.setBorrowerName(collateralSearchViewData.getBorrowerName());
		holdStatusDto.setCollateralID(collateralRid);

		holdStatusDto.setPropertyAddress(collateralSearchViewData.getPropertyAddress());
		holdStatusDto.setCity(collateralSearchViewData.getPropertyCity());
		holdStatusDto.setStateCode(collateralSearchViewData.getPropertyState());
		holdStatusDto.setZipcode(collateralSearchViewData.getPropertyZipCode());

		if(holdStatusDto.getHoldTypes() == null){
        	holdStatusDto.setHoldTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(HOLD_TYPES));
        }

		if(holdStatusDto.getHoldPeriods()== null){
        	holdStatusDto.setHoldPeriods(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(HOLD_PERIODS));
        }

		holdStatusDto.setCurrentReferenceDate(JAVASCRIPT_DATE_FORMATTER.print(dateCalculator.getCurrentReferenceDate()));

		return holdStatusDto;
    }

	@Transactional
	@Override
	public void processUpdateHoldStatus(HoldStatusDto holdStatusDto) {
		logger.info("Inside processUpdateHoldStatus() method");
		try {
            PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(holdStatusDto.getPerfectionTask().getTmTaskId());
			HoldWorkItem holdWorkItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), HoldWorkItem.class);

			if (holdStatusDto.getDocumentAttachment() != null) {
				CollateralDocument holdDocument =
					collateralDocumentService.saveCollateralDocument(holdStatusDto.getDocumentAttachment(), CtracAppConstants.HOLD_DOCUMENT_IDENTIFIER, new Date(), null);
				holdWorkItem.setDocumentRid(holdDocument.getRid());
			} else {
				holdWorkItem.setDocumentRid(null);
			}

			holdWorkItemRepository.save(holdWorkItem);

			//Process Hold updates for all Child Work Items and return any c3 actions that need to be taken in a map
			Map<Date,Set<Long>> c3CoverageActions = processHoldStatusWorkItems(holdWorkItem,perfectionTask.getWorkflowStep(),holdStatusDto);
			//Execute C3 for each date in chronological order for the Insurable Assets were Hold was lifted
			callCoverageComputationService(holdStatusDto.getCollateralID(),c3CoverageActions, perfectionTask.getWorkflowStep());

			//Workflow transitions
			transitionHoldWorkflow(holdStatusDto, perfectionTask);
		}catch (Exception e) {
			logger.error("createNewTaskInTM failed with error message: " + e.getMessage(), e);
			throw new CTracApplicationException("E0347", CtracErrorSeverity.APPLICATION);
		}
	}


	/**
	 * Given a update hold status task, the task will get transitioned to verify state / Complete state
	 * @param holdStatusDto - The HoldStatus DTO Object to pass
	 * @param perfectionTask - Task to transition
	 */
    void transitionHoldWorkflow(final HoldStatusDto holdStatusDto, PerfectionTask perfectionTask){
		//Workflow transitions
	try {
        final TMParams TMParams = holdStatusDto.getTmParams();
		if (VERIFY_HOLD_STATUS.getName().equals(perfectionTask.getWorkflowStep())) {
			// Close and complete the current open Verify Hold Status Task
            perfectionTaskService.closeTask(perfectionTask, COMPLETE);

			CompleteItemData completeItemData = commonTaskService.prepareCompleteItem(TMParams);
			otmService.completeTMTask(TMParams, completeItemData.getTMAttributes());
		}else{
			//complete and continue down the Hold status workflow for verification
			final PerfectionTask perfTask = perfectionTask;
			final HoldWorkItem holdWorkItemParam = CtracBaseEntity.deproxy(perfTask.getWorkItem(), HoldWorkItem.class);
			Map<StateParameterType, Object> worflowData = new HashMap<StateParameterType, Object>(){{
				put(StateParameterType.HELPER_DATA, holdStatusDto);
				put(StateParameterType.WORK_ITEM, holdWorkItemParam);
				put(StateParameterType.PERFECTION_TASK, perfTask);
				put(StateParameterType.TM_PARAMS, TMParams);
			}};
			taskService.completeWorkFlowStepOperations(worflowData);
		}
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0354", CtracErrorSeverity.APPLICATION, ex);
		}
		
	}

    void callCoverageComputationService(Long collateralRid, Map<Date,Set<Long>> c3CoverageActions, String curWkflStep){
		if (VERIFY_HOLD_STATUS.getName().equals(curWkflStep)) {
			List<Date> calcCoverageDates = new ArrayList<>(c3CoverageActions.keySet());
			//Order calculated coverage dates in Chronological order
			Collections.sort(calcCoverageDates, new Comparator<Date>() {
				@Override
				public int compare(Date o1, Date o2) {
					return o1.compareTo(o2);
				}
			});
			//For each date, call the C3 and apply the coverage Actions on it
			for (Date coverageDate : calcCoverageDates) {
				CoverageActionResult result = collateralCoverageComputationService.evaluateInsurableAssetCoverageActions(
						collateralRid, c3CoverageActions.get(coverageDate), coverageDate);
				collateralCoverageComputationService.applyInsuranceCoverageActions(result, null);
			}
		}
	}

    Map<Date,Set<Long>> processHoldStatusWorkItems(HoldWorkItem parentHoldWorkItem, String curWkflStep, HoldStatusDto holdStatusDto) throws Exception {
		Map<Date,Set<Long>> c3CoverageActions = new HashMap<>();
		List<WorkItemRelation> workItemRelations = workItemRelationRepository.findByParentWorkItemAndRelationType(parentHoldWorkItem, TaskRelationType.HOLDTOFIAT.name());
		//Key: HoldType|ExpiryDate    Value: ParentWorkItem
		HashMap<String, WorkItem> holdTypeExpiryDate = new HashMap<>();
		Collateral collateral = collateralRepository.findOne(holdStatusDto.getCollateralID());
		for (WorkItemRelation workItemRelation: workItemRelations) {
			HoldWorkItem childHoldWorkItem = holdWorkItemRepository.findOne(workItemRelation.getChildWorkItem().getRid());
			Hold existingHold = holdRepository.findOne(childHoldWorkItem.getHoldRid());
			HoldDetailsViewDto holdDetailsViewDto = getHoldDetailsViewDto(existingHold.getRid(), holdStatusDto);
			if (VERIFY_HOLD_STATUS.getName().equals(curWkflStep)) {
				// if Verify mode
				//Get the coverage details from the parent hold and re-link them to the "hold to be verified"
				updateCoverageDetailsToHoldRelation(existingHold);
				//Update the hold with values coming from the form
				existingHold = updateHoldOnVerify(existingHold, holdDetailsViewDto);
				if (StringUtils.isNotEmpty(holdDetailsViewDto.getHoldPeriod())) {
					//If hold is extended - create new aggregate items
					HoldDTO existingHoldDto = ctracObjectMapper.map(existingHold, HoldDTO.class);
					createAggregateHoldTasks(existingHoldDto, holdTypeExpiryDate, collateral);
				} else { // LPI Date is not null. Save it with lpi date in map to trigger C3 afterwards
					Date coverageDate = new DateTime(DATE_FORMATTER.parse(holdDetailsViewDto.getLpiDate())).withTimeAtStartOfDay().toDate();
					if(!c3CoverageActions.containsKey(coverageDate)){
						c3CoverageActions.put(coverageDate,new HashSet<Long>());
					}
					c3CoverageActions.get(coverageDate).addAll(getInsurableAssetRidsFromHold(existingHold));
				}
			} else {
				// if Edit mode
				//Create new Hold Extension based from the existing hold
				Hold newHoldExtension = createNewHoldExtension(existingHold,holdDetailsViewDto);
				//Save the new hold and update the workItem to link to the new hold for verification
				saveNewHold(newHoldExtension, workItemRelation.getChildWorkItem());
			}
		}
		return c3CoverageActions;
	}


	/**
	 * Create a new Hold (extension) from an existing hold and populate the values coming from the HoldDetailsView form
	 * @param existingHold - Hold to use as base for the extension
	 * @param holdDetailsDto - Hold details view
	 * @return Extension Hold
	 * @throws ParseException
	 */
    Hold createNewHoldExtension(Hold existingHold, HoldDetailsViewDto holdDetailsDto) throws ParseException {
		Hold newHold = new Hold();
		String currentUser = auditInformationService.getLoggedInUserSid();
		//When existing hold has a parent, same parent will be used as parent on new hold
		newHold.setParentHold(existingHold.getParentHold() != null &&
				existingHold.getParentHold().getRid() != null ? existingHold.getParentHold():existingHold);
		newHold.setHoldType(existingHold.getHoldType());
		newHold.setInitialAuditInfo(currentUser);
		//Populate hold fields from DTO
		if (StringUtils.isNotEmpty(holdDetailsDto.getHoldPeriod())) {
			newHold.setStartDate(getHoldPeriodExpirationDate(existingHold.getStartDate(), existingHold.getHoldPeriod()));
			newHold.setHoldPeriod(holdDetailsDto.getHoldPeriod());
		} else if (StringUtils.isNotEmpty(holdDetailsDto.getLpiDate())) {
			newHold.setLpiDate(DATE_FORMATTER.parse(holdDetailsDto.getLpiDate()));
		}
		return newHold;
	}

	/**
	 * Saving New Hold object and updating hold work item with the new Hold RID
	 * @param holdToSave - New Hold
	 * @param workItem - The work item to update
	 */
    void saveNewHold(Hold holdToSave, WorkItem workItem) {
		HoldWorkItem holdWorkItem = CtracBaseEntity.deproxy(workItem, HoldWorkItem.class);
		Hold newHold = holdRepository.save(holdToSave);

		// update relationship
		HoldWorkItem hwi = holdWorkItemRepository.findOne(holdWorkItem.getRid());
		hwi.setHoldRid(newHold.getRid());
	}

	/**
	 * Update CoverageDetails from Parent With new Hold
	 * @param holdToVerify - Newer hold
	 */
    void updateCoverageDetailsToHoldRelation(Hold holdToVerify){
		//Find all verified holds that have the same given parent and take the last verified one to lookup the coverage Details objects
		List<Hold> allVerifiedHolds = holdRepository.findByParentHoldAndHoldStatusOrderByVerifiedDateDesc(holdToVerify.getParentHold(),
				VerificationStatus.VERIFIED.getName());
		//When no verified holds where found take the parent hold as it means the coverages are still linked to the parent
		Hold linkedCovHold = CollectionUtils.isNotEmpty(allVerifiedHolds) ? allVerifiedHolds.get(0) : holdToVerify.getParentHold();
		List<CoverageDetails> coverageDetailsList = coverageDetailsRepository.findByHold(linkedCovHold);
		for (CoverageDetails coverageDetails : coverageDetailsList) {
			coverageDetails.setHold(holdToVerify);
			coverageDetailsRepository.save(coverageDetails);
		}
	}

	/**
	 * Update the Hold on verification with the correct values coming from the Hold details view
	 * @param holdToVerify - Hold to verify
	 * @param holdDetailsViewDto - Hold details view containing the values to save
	 * @return The verified Hold
	 * @throws ParseException
	 */
    Hold updateHoldOnVerify(Hold holdToVerify, HoldDetailsViewDto holdDetailsViewDto) throws ParseException {
		String currentUser = auditInformationService.getLoggedInUserSid();
		if (StringUtils.isNotEmpty(holdDetailsViewDto.getHoldPeriod())) {
			holdToVerify.setStartDate(getHoldPeriodExpirationDate(holdToVerify.getParentHold().getStartDate(),
					holdToVerify.getParentHold().getHoldPeriod()));
			holdToVerify.setHoldPeriod(holdDetailsViewDto.getHoldPeriod());
			holdToVerify.setLpiDate(null);
		}	else if (StringUtils.isNotEmpty(holdDetailsViewDto.getLpiDate())) {
			holdToVerify.setStartDate(null);
			holdToVerify.setHoldPeriod(null);
			holdToVerify.setLpiDate(DATE_FORMATTER.parse(holdDetailsViewDto.getLpiDate()));
		}
		holdToVerify.setHoldStatus(VerificationStatus.VERIFIED.getName());
		holdToVerify.setVerifiedBy(currentUser);
		holdToVerify.setVerifiedDate(new Date());
		return holdRepository.save(holdToVerify);
	}

    Set<Long> getInsurableAssetRidsFromHold(Hold hold){
		Set<Long> uniqueInsurableAssetRids = new HashSet<>();
		List<RequiredCoverage> reqCovList = requiredCoverageRepository.findRequiredCoveragesByHoldRid(hold.getRid());
		for(RequiredCoverage requiredCoverage: reqCovList){
			uniqueInsurableAssetRids.add(requiredCoverage.getInsurableAsset().getRid());
		}
		return uniqueInsurableAssetRids;
	}


	 private HoldDetailsViewDto getHoldDetailsViewDto(Long holdRid, HoldStatusDto holdStatusDto) {
		 for (HoldDetailsViewDto holdDetailsViewDto: holdStatusDto.getHoldDetailsViewDtoList()) {
			 if (holdRid.longValue() == holdDetailsViewDto.getHoldRid().longValue()) {
					return holdDetailsViewDto;
				}
		 }
		 logger.error("Could not find hold rid=" + holdRid);
		 throw new CtracException("Could not find hold rid=" + holdRid);
    }

    @Override
    public Collection<HoldHistoryViewDto> getHoldHistory(Long collateralRid) {
        Collection<HoldHistoryViewDto> holdHistoryViewDtos = new ArrayList<>();
        List<HoldHistoryViewData> holdHistoryViewDataList = holdHistoryViewDataRepository.findByCollateralRid(collateralRid);
        if(holdHistoryViewDataList != null) {
            for (HoldHistoryViewData holdHistoryViewData : holdHistoryViewDataList) {
                holdHistoryViewDtos.add(ctracObjectMapper.map(holdHistoryViewData, HoldHistoryViewDto.class ));
            }
        }
        return holdHistoryViewDtos;
    }

    private Date getHoldPeriodExpirationDate(Date startDate, String holdPeriod) {
        DateTime expirationDate = new DateTime(startDate);
        String[] holdPeriodParts = holdPeriod.split(" ");
        int numberOfMonthsOrYears = new Integer(holdPeriodParts[0]);
        if (holdPeriod.contains("Month")) {
            expirationDate = expirationDate.plusMonths(numberOfMonthsOrYears);
        } else if (holdPeriod.contains("Year")) {
            expirationDate = expirationDate.plusYears(numberOfMonthsOrYears);
        }
        return expirationDate.toDate();
    }

    @Override
    public Date getHoldPeriodExpirationDate(String startDate, String holdPeriod) {
        return getHoldPeriodExpirationDate(DATE_FORMATTER.parse(startDate), holdPeriod);
    }

    @Override
    public List<HoldDetailsViewDto> getHoldDetailsViewDtos(WorkItem holdWorkItem) {
        List<HoldDetailsViewData> holdDetailsViewDataList = holdDetailsRepository.findByParentWorkItemRid(holdWorkItem.getRid());
        return ctracObjectMapper.mapAsList(holdDetailsViewDataList, HoldDetailsViewDto.class);
    }

    PerfectionTask createSendMarketHoldEmailTask(Date holdExpiryDate,WorkItem workItem) {
        logger.debug("createSendMarketHoldEmailTask::begin");
        PerfectionTask perfectionTask =null;
        try {
            Date wakeUpDate = dateCalculator.subtractBusinessDaysExclusive(5, holdExpiryDate);
            perfectionTask = new PerfectionTaskBuilder(workItem, SEND_MARKET_HOLD_EMAIL.getName(), TaskStatus.TRANSIENT, "SYSTEM")
                    .wakeUpDate(wakeUpDate).tmTaskType(TMTaskType.FLOOD_INSURANCE).build();
            perfectionTaskService.saveTask(perfectionTask);
            logger.debug("createSendMarketHoldEmailTask::end");
        } catch(Exception e){
            logger.error(e.getMessage());
            throw new CTracApplicationException("E0258", CtracErrorSeverity.APPLICATION);
        }
        return perfectionTask;
    }
}
