package com.jpmorgan.cib.wlt.ctrac.service.insurance;

import java.util.Date;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;
import org.springframework.transaction.annotation.Transactional;


public interface CollateralCoverageComputationService {

    CoverageActionResult evaluateInsuranceCoverageActions(CoverageActionRequest coverageActionRequest);

    @Transactional
    CoverageActionResult evaluateInsurableAssetCoverageActions(Long collateralRid, Set<Long> insurableAssetRids, Date overrideCalculatedDate);

    CoverageActionResult evaluateInsurableAssetCoverageActions(Long collateralRid, Set<Long> insurableAssetRids);
    
    void applyInsuranceCoverageActions(CoverageActionResult coverageActionResult, WorkItem triggerWorkItem);
	
}
