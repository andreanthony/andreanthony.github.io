package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon;

import com.jpmorgan.cib.wlt.ctrac.service.excel.ColumnDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;

public class ReconPremiumsTableDefinition {

	public static final ColumnDefinition[] DEFINITION = {
		new ColumnDefinition("Policy Number", "policyNumber", FieldType.STRING),
		new ColumnDefinition("Loan System", "loanSystem", FieldType.STRING),
		new ColumnDefinition("Insured Name", "insuredName", FieldType.STRING),
		new ColumnDefinition("Policy Effective Date", "policyEffectiveDate", FieldType.DATE),
		new ColumnDefinition("Premium Amount", "premiumAmount", FieldType.AMOUNT),	
	};
	
}
