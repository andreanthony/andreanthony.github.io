package com.jpmorgan.cib.wlt.ctrac.service.dto.base.escrowbalance;

import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.LPPolicyCollateralData;

public class EscrowBalanceData extends LPPolicyCollateralData {
	
	private static final long serialVersionUID = 1L;	
	
	private String escrowBalanceAmount;
	
	private String negativeEscrowBalance;
	
	public String getNegativeEscrowBalance() {
		return negativeEscrowBalance;
	}

	public void setNegativeEscrowBalance(String negativeEscrowBalance) {
		this.negativeEscrowBalance = negativeEscrowBalance;
	}


	
	public String getEscrowBalanceAmount() {
		return escrowBalanceAmount;
	}

	public void setEscrowBalanceAmount(String escrowBalanceAmount) {
		this.escrowBalanceAmount = escrowBalanceAmount;
	}
}
