package com.jpmorgan.cib.wlt.ctrac.service.batch;

/**
 * @author N664895
 *
 */
public interface ProcessGDSImage {
	boolean processLetterImages();
}
