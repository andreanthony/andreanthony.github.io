package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import java.util.HashMap;

public class BIRRuleConclusionMap extends HashMap<String, BIRRuleConclusionDTO> {

	private static final long serialVersionUID = -6706900586806234339L;

	@Override
	public BIRRuleConclusionDTO get(Object key) {
		if (!super.containsKey(key)) {
			BIRRuleConclusionDTO birRuleConclusionDTO = new BIRRuleConclusionDTO();
			birRuleConclusionDTO.setFieldName((String) key);
			super.put((String) key, birRuleConclusionDTO);
		}
		return super.get(key);
	}
	
}
