package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ExcelTable;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;
import static com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.LoanSystemsOrder.*;

public class ReconExcelRefundsSheet extends AbstractReconExcelSheet{

	private static final String SHEET_NAME = "Refunds";
	private static final int LARGE_HEADER_COL_SPAN = ReconRefundsTableDefinition.DEFINITION.length - 1;
	private static final String TITLE = "CTRAC FLOOD POLICY REFUNDS";
	
	
	public ReconExcelRefundsSheet(){
		this.title = TITLE;
		this.definition = ReconRefundsTableDefinition.DEFINITION;
	}
	
	public void insertInto(XSSFWorkbook workbook, Map<LoanSystem, List<ReconRefundsRow>> refunds, Date reportDate, Date activityDate){
		XSSFSheet sheet = workbook.createSheet(SHEET_NAME);
		sheet.setDefaultColumnWidth(20);
		sheet.setColumnWidth(LARGE_HEADER_COL_SPAN, 40 * 256);
		int currentRow = 0;
		currentRow = insertTitle(sheet, currentRow);
		currentRow = insertBlankRow(currentRow);
		currentRow = insertDateTable(sheet, reportDate, activityDate, currentRow);
		currentRow = insertBlankRow(currentRow);
		currentRow = insertTableHeader(sheet, currentRow);
		currentRow = insertTableBody(sheet, refunds, currentRow);
	}
	
	private int insertTableBody(XSSFSheet sheet, Map<LoanSystem, List<ReconRefundsRow>> refunds, int currentRow) {
		if(refunds == null ||  refunds.size() == 0){
			return currentRow;
		}
		for(LoanSystem loanSystem : LOAN_SYSTEM_ORDER){
			if(!refunds.containsKey(loanSystem)){
				continue;
			}
			currentRow = insertTableBody(sheet, refunds.get(loanSystem), currentRow);
			currentRow = insertTotalRow(sheet, refunds.get(loanSystem), currentRow);
			currentRow = insertBlankRow(currentRow);
		}
		return insertGrandTotalRow(sheet, refunds, currentRow);
	}
	
	
	private int insertTableBody(XSSFSheet sheet, List<ReconRefundsRow> rows, int currentRow){
		XSSFCellStyle amountStyle = generateAmountCellStyle(sheet.getWorkbook(), true);
		XSSFCellStyle stringStyle = generateStringCellStyle(sheet.getWorkbook(), true);
		XSSFCellStyle dateStyle = generateDateCellStyle(sheet.getWorkbook(), false);
		
		ExcelTable excelTable = new ExcelTable(definition, rows).customStyle(FieldType.AMOUNT, amountStyle).customStyle(FieldType.STRING, stringStyle).customStyle(FieldType.DATE, dateStyle);
		return excelTable.insertBodyInto(sheet, currentRow, 0);
	}
	
	private int insertGrandTotalRow(XSSFSheet sheet, Map<LoanSystem, List<ReconRefundsRow>> rows, int currentRow){
		BigDecimal sum = BigDecimal.ZERO;
		for(Map.Entry<LoanSystem, List<ReconRefundsRow>> row: rows.entrySet()){
			for(ReconRefundsRow r: row.getValue()){
				sum = sum.add(r.getRefundAmount());
			}
		}
		return insertTotalRow(sheet, sum, currentRow, "Grand Total", true);
	}
	

	private int insertTotalRow(XSSFSheet sheet, List<ReconRefundsRow> rows, int currentRow) {
		BigDecimal sum = BigDecimal.ZERO;
		for(ReconRefundsRow row: rows){
			sum = sum.add(row.getRefundAmount());
		}
		return insertTotalRow(sheet, sum, currentRow, "Total", false);
	}

}
