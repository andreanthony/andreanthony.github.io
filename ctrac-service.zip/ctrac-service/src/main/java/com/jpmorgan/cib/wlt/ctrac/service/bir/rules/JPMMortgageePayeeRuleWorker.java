package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class JPMMortgageePayeeRuleWorker extends AbstractBIRRuleWorker {

	public JPMMortgageePayeeRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRRuleConclusionDTO jpmListedAsMortgageePayeeConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		BorrowerInsuranceReviewConclusion birConclusion = null;
		boolean isCondoAssociationPolicy = BIRRuleHelper.isCondoAssociationPolicy(borrowerInsuranceReviewData);
		boolean hasBuildingCoverage = BIRRuleHelper.hasBuildingCoverage(borrowerInsuranceReviewData);
		if (isCondoAssociationPolicy || !hasBuildingCoverage) {
			birConclusion = BorrowerInsuranceReviewConclusion.NONE;
		} else if ("Yes".equals(borrowerInsuranceReviewData.getJpmListedAsMortgageePayee())) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.ACTION_REQUIRED;
		}
		jpmListedAsMortgageePayeeConclusion.setConclusion(birConclusion.name());
	}

}
