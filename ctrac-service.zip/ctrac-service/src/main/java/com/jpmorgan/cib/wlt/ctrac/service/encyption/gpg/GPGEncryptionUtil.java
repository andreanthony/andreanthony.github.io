package com.jpmorgan.cib.wlt.ctrac.service.encyption.gpg;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity.CRITICAL;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.bouncycastle.openpgp.PGPException;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;

public abstract class GPGEncryptionUtil {
	
	private static final Logger logger = Logger.getLogger(GPGEncryptionUtil.class);
	
	private static final String PROPERTY_NAME_PATH_TO_KEY = "ctrac.gpg.encrypt.keyfile.path";
	
	private static GPGEncryptor encryptor = new GPGEncryptor();
	
	public static void encrypt(File inputFile, String outputFileNamePath) {
		try {
			initialize();		
			encryptor.encryptFile(inputFile,outputFileNamePath+"/"+inputFile.getName()+".gpg");
		} catch (Exception e) {
			logger.error("Error encrypting file");
			throw new CTracApplicationException("E0148", CRITICAL);
		}		
	}
	
	private static void initialize() throws IOException, PGPException {
			encryptor.setArmored(false);
			encryptor.setCheckIntegrity(true);
			encryptor.setPublicKeyFilePath(System.getProperty(PROPERTY_NAME_PATH_TO_KEY));
	}	
}