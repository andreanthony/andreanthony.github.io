package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;

public class ExternallyAgentedRule extends InsurableAssetCoverageRule {

    public ExternallyAgentedRule(
            Collateral collateral, WorkItem triggerWorkItem,
            InsurableAsset insurableAsset, CoverageActionData coverageActionData){
        super(collateral, triggerWorkItem, insurableAsset,coverageActionData);
    }

    @Override
    public void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult partialResult)
    {
        partialResult.setMoreActionsNeeded(!coverageActionData.isExternallyAgented());
    }

    @Override
    public Integer getPriority() {
        return 26;
    }
}
