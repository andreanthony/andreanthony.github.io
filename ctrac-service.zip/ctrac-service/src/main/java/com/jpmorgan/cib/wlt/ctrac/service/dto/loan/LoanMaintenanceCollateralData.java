package com.jpmorgan.cib.wlt.ctrac.service.dto.loan;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralType;

public class LoanMaintenanceCollateralData implements Serializable {

	private static final long serialVersionUID = -1777231909194174618L;

	private Long collateralRid;
	
	private CollateralType collateralType;
	
	private CollateralStatus collateralStatus;
	
	private String propertyAddress;

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public CollateralType getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(CollateralType collateralType) {
		this.collateralType = collateralType;
	}

	public CollateralStatus getCollateralStatus() {
		return collateralStatus;
	}

	public void setCollateralStatus(CollateralStatus collateralStatus) {
		this.collateralStatus = collateralStatus;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	
}
