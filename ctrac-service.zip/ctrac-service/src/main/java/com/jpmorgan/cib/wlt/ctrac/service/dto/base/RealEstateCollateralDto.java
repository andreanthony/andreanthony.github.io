package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;




public  class RealEstateCollateralDto extends CollateralDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String propertyTypeDescription;

	public RealEstateCollateralDto(){
		
	}
	
	public RealEstateCollateralDto propertyType(String subType) {
		setCollateralSubType(subType);
		return this;
	}

	public String getPropertyTypeDisplayValue() {
		return propertyTypeDescription;
	}

	public String getPropertyTypeDescription() {
		return propertyTypeDescription;
	}

	public void setPropertyTypeDescription(String propertyTypeDescription) {
		this.propertyTypeDescription = propertyTypeDescription;
	}


	@Override
	protected CollateralDto clone() throws CloneNotSupportedException {
		return (CollateralDto) super.clone();
	}

	public boolean deepEquals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollateralDto other = (CollateralDto) obj;
		if (other instanceof RealEstateCollateralDto) {
			RealEstateCollateralDto rec = (RealEstateCollateralDto) other;
			if (propertyTypeDescription == null) {
				if (rec.propertyTypeDescription != null)
					return false;
			} else if (!propertyTypeDescription.equals(rec.propertyTypeDescription))
				return false;
		}
		return super.deepEquals(obj);
	}
}
