package com.jpmorgan.cib.wlt.ctrac.service.collateral.details.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.propertytype.AssurantPropertyType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.propertytype.FIATPropertyType;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.FIATPropertyTypeService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.SelectOption;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by E704298 on 7/11/2017.
 */
@Service
public class FIATPropertyTypeServiceImpl implements FIATPropertyTypeService {

    @Override
    public List<SelectOption> getPropertyTypesForDescription(String description) {
        List<SelectOption> propertyTypes = new ArrayList<>();
        if (FIATPropertyType.findByDisplayName(description) == null &&
                AssurantPropertyType.findByDisplayName(description) != null) {
            for (AssurantPropertyType value : AssurantPropertyType.values()) {
                propertyTypes.add(new SelectOption(value.name(), value.getDisplayName()));
            }
        } else {
            for (FIATPropertyType value : FIATPropertyType.values()) {
                propertyTypes.add(new SelectOption(value.name(), value.getDisplayName()));
            }
        }
        return propertyTypes;
    }
}
