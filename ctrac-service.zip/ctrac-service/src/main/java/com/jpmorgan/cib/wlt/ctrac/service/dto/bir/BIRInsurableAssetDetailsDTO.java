package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class BIRInsurableAssetDetailsDTO implements Cloneable, Serializable {

	private static final long serialVersionUID = -7652365771456950200L;
	private static final Logger logger = Logger.getLogger(BIRInsurableAssetDetailsDTO.class);
	
	private Long rid;
	
	private Long birCollateralDetailsRid;
	
	private Long insurableAssetSortOrder;
	
	private String propertyType;

	private BIRInsurableAssetDetailsDTO loadTimeValue;
	
	private Map<String, BIRRuleConclusionDTO> birRuleConclusions = new BIRRuleConclusionMap();

	public List<BIRRuleConclusionDTO> getAllBIRRuleConclusions(Long proofOfCoverageRid, Long collateralRid) {
		List<BIRRuleConclusionDTO> allBIRRuleConclusions = new ArrayList<BIRRuleConclusionDTO>();
		for (Entry<String, BIRRuleConclusionDTO> insurableAssetEntry : birRuleConclusions.entrySet()) {
			BIRRuleConclusionDTO birRuleConclusion = insurableAssetEntry.getValue();
			birRuleConclusion.populateValues(proofOfCoverageRid, collateralRid, insurableAssetSortOrder,
					insurableAssetEntry.getKey(), birRuleConclusion.getConclusion());
			allBIRRuleConclusions.add(birRuleConclusion);
		}
		return allBIRRuleConclusions;
	}
	
	public boolean isDisabled(String key, PolicyStatus policyStatus, String reasonForVerification) {
		return BIRDisabledFieldHelper.isDisabled(birRuleConclusions, key, policyStatus, reasonForVerification);
	}
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getBirCollateralDetailsRid() {
		return birCollateralDetailsRid;
	}

	public void setBirCollateralDetailsRid(Long birCollateralDetailsRid) {
		this.birCollateralDetailsRid = birCollateralDetailsRid;
	}

	public Long getInsurableAssetSortOrder() {
		return insurableAssetSortOrder;
	}

	public void setInsurableAssetSortOrder(Long insurableAssetSortOrder) {
		this.insurableAssetSortOrder = insurableAssetSortOrder;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public Map<String, BIRRuleConclusionDTO> getBirRuleConclusions() {
		return birRuleConclusions;
	}

	public void setBirRuleConclusions(Map<String, BIRRuleConclusionDTO> birRuleConclusions) {
		this.birRuleConclusions = birRuleConclusions;
	}

	private boolean deepEquals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		BIRInsurableAssetDetailsDTO other = (BIRInsurableAssetDetailsDTO) obj;
		if (!StringUtils.equals(propertyType, other.propertyType)) {
			return false;
		}
		return true;
	}

	public boolean hasChanged(){
		if(this.loadTimeValue ==null || this.getRid()==null){
			return true;
		}
		return !deepEquals(this.loadTimeValue);
	}

	public void saveACopy() {
		try {
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	protected BIRInsurableAssetDetailsDTO clone() throws CloneNotSupportedException {
		return (BIRInsurableAssetDetailsDTO) super.clone();
	}


}
