package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

public class AutoSuggestionsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long rid;

	private String description;

	private String lable;
	
	private String value;
	
    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLable() {
		return lable;
	}

	public void setLable(String lable) {
		this.lable = lable;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
