package com.jpmorgan.cib.wlt.ctrac.service.entitlements;


import java.io.IOException;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.MessageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ServiceProvider;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.GroupDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.UsersDto;
import com.jpmorgan.cib.wlt.ctrac.service.xml.XMLMessageLogger;

import net.jpmchase.cbhub.rsam.ProvisioningRequest;
import net.jpmchase.cbhub.rsam.ProvisioningResponse;
import net.jpmchase.cbhub.rsam.handlers.AutoProvisioningHandler;

/**
 * Created by I569445 on 2/18/2016.
 */
@Component("autoProvisioningHandler")
public class CtracAutoProvisionHandler extends AutoProvisioningHandler {

    Logger _logger = Logger.getLogger(CtracAutoProvisionHandler.class);

    public static final String SID_PARAMETER = "SID";
    public static final String ACTION_PARAMETER = "ACTION";
    public static final String JANUS_USERNAME_PARAMETER = "JANUSUSERNAME";
    public static final String LOB_PARAMETER = "LOB";
    public static final String ROLE_PARAMETER = "ROLE";
    public static final String FIRSTNAME_PARAMETER = "FIRSTNAME";
    public static final String LASTNAME_PARAMATER = "LASTNAME";

    @Autowired
    private UserEntitlementService userEntitlementService;

    @Autowired
    private XMLMessageLogger xmlMessageLogger;

    @Transactional
    @Override
    public String processProvisioningRequest(String request) throws IOException {
        xmlMessageLogger.logMessageToDB(request, null, ServiceProvider.RSAM, MessageType.REQUEST);
        String response = super.processProvisioningRequest(request);
        xmlMessageLogger.logMessageToDB(response, null, ServiceProvider.RSAM, MessageType.RESPONSE);
        return response;
    }


    @Transactional
    protected ProvisioningResponse processProvisioningRequest(ProvisioningRequest provisioningRequest) {

        //Build user request to handle auto provisioning
        UsersDto request = new UsersDto();

        StringBuilder errorMessage = new StringBuilder();
        errorMessage.append("Failed to handle auto-provisioning request due to missing parameter ");

        //SID is required parameter cannot continue without it.
        if(provisioningRequest.getProvAttributeMap().get(SID_PARAMETER) != null && StringUtils.isNotEmpty(provisioningRequest.getProvAttributeMap().get(SID_PARAMETER))) {
            request.setSid(provisioningRequest.getProvAttributeMap().get(SID_PARAMETER));
        } else {
            errorMessage.append(SID_PARAMETER);
            throw new IllegalArgumentException(errorMessage.toString());
        }

        //Action is required parameter to process the request cannot continue without it.
        if(provisioningRequest.getProvAttributeMap().get(ACTION_PARAMETER) != null) {
            request.setAction(RSAMActionEnum.getByCode(provisioningRequest.getProvAttributeMap().get(ACTION_PARAMETER)));
        } else {
            errorMessage.append(ACTION_PARAMETER);
            throw new IllegalArgumentException(errorMessage.toString());
        }

        //JanusUserName is required parameter to process the request cannot continue without it.
        if(provisioningRequest.getProvAttributeMap().get(JANUS_USERNAME_PARAMETER) != null) {
            request.setUsername(provisioningRequest.getProvAttributeMap().get(JANUS_USERNAME_PARAMETER));
        } else {
            errorMessage.append(JANUS_USERNAME_PARAMETER);
            throw new IllegalArgumentException(errorMessage.toString());
        }
        if (provisioningRequest.getProvAttributeMap().get(ROLE_PARAMETER) != null && StringUtils.isNotEmpty(provisioningRequest.getProvAttributeMap().get("ROLE"))) {
            request.getGroups().add(new GroupDto(provisioningRequest.getProvAttributeMap().get(ROLE_PARAMETER)));
        } else if (!request.getAction().equals(RSAMActionEnum.REMOVE)) {
            //role is required for all actions except when remove since you are removing everything
            errorMessage.append(ROLE_PARAMETER);
            throw new IllegalArgumentException(errorMessage.toString());
        }

        //optional parameters
        if(provisioningRequest.getProvAttributeMap().get(LOB_PARAMETER) != null) {
            request.setLob(provisioningRequest.getProvAttributeMap().get(LOB_PARAMETER));
        }
        if(provisioningRequest.getProvAttributeMap().get(FIRSTNAME_PARAMETER) != null && StringUtils.isNotEmpty(provisioningRequest.getProvAttributeMap().get(FIRSTNAME_PARAMETER))) {
            request.setFirstName(provisioningRequest.getProvAttributeMap().get(FIRSTNAME_PARAMETER));
        }
        if(provisioningRequest.getProvAttributeMap().get(LASTNAME_PARAMATER) != null && StringUtils.isNotEmpty(provisioningRequest.getProvAttributeMap().get(LASTNAME_PARAMATER))) {
            request.setLastName(provisioningRequest.getProvAttributeMap().get(LASTNAME_PARAMATER));
        }

        _logger.info("RSAM Auto Provisioning Request Received: SID=" + provisioningRequest.getProvAttributeMap().get(SID_PARAMETER) + " ACTION= "+ request.getAction().getCode() + ROLE_PARAMETER +"=" + provisioningRequest.getProvAttributeMap().get(ROLE_PARAMETER) );

        //Build expected response to IDNow.
        ProvisioningResponse response = new ProvisioningResponse();
        RSAMResponseCodeEnum responseCodeEnum = null;

        try {
            //Handle auto provisioning
            userEntitlementService.processAutoProvisioning(request);
            responseCodeEnum = RSAMResponseCodeEnum.ACTION_TAKEN;
            _logger.info("RSAM Auto Provisioning Request Successful" + "User: " + request.getSid() + " Action: " + request.getAction().getCode());
        } catch (CTracApplicationException ce) {
            _logger.info("RSAM Auto Provisioning request successful but no actions taken.");
            responseCodeEnum = RSAMResponseCodeEnum.NO_ACTION;
        } catch (IllegalArgumentException iae) {
            _logger.error("RSAM Auto Provisioning request failed due to invalid request.");
            responseCodeEnum = RSAMResponseCodeEnum.FAILURE_CLIENT;
        } catch (Exception e) {
            _logger.error("RSAM Auto Provisioning request failed due to exception.", e);
            responseCodeEnum = RSAMResponseCodeEnum.FAILURE_SERVICE;
        }

        response.setStatus(responseCodeEnum.getMessage());
        response.setStatusCode(responseCodeEnum.getCode());
        return response;
    }

    public enum RSAMActionEnum {

        ADD("ADD"), DELETE("DELETE"), REMOVE("REMOVE");

        private String code;

        private RSAMActionEnum(String c) {
            code = c;
        }

        public String getCode() {
            return code;
        }

        public static RSAMActionEnum getByCode(String code) {
            for(RSAMActionEnum e : RSAMActionEnum.values()) {
                if(e.getCode().equalsIgnoreCase(code)) {
                    return e;
                }
            }
            return null;
        }
    }

    public enum RSAMResponseCodeEnum {
        ACTION_TAKEN(0, "Successfully handled the entitlements"), NO_ACTION(800, "Not action taken"), FAILURE_SERVICE(500, "Unexpected exception"), FAILURE_CLIENT(905, "Missing mandatory parameters from the input");

        private int code;
        private String message;

        private RSAMResponseCodeEnum(int c, String message) {
            this.code = c;
            this.message = message;
        }

        public int getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }

        public static RSAMResponseCodeEnum getByCode(int code) {
            for(RSAMResponseCodeEnum e : RSAMResponseCodeEnum.values()) {
                if(e.getCode() == code ) {
                    return e;
                }
            }
            return null;
        }

    }

}
