package com.jpmorgan.cib.wlt.ctrac.service.email;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;

public interface FloodEmailService {

	/***
	 * Must contain collateral IDs if not providing From/Auto-Cc
	 * @param emailAttributeHolder
	 */
	public void sendEmail(EmailAttributeHolder emailAttributeHolder);
	
	public void sendInternalEmailThroughEWS(final EmailAttributeHolder emailAttributeHolder);
	
	public String getCTLFloodEmail();
	
	public String getWLSFloodEmail();

    String getMarketEmailToAddress(Collateral collateral);
}
