package com.jpmorgan.cib.wlt.ctrac.service.dto.admin;

import java.io.Serializable;
import java.util.List;

public class TaskAdminDTO implements Serializable {

	private static final long serialVersionUID = 3252457557658647559L;

	private String taskId;
	
	private List<String> actions;
	
	private String action;
	
	private boolean generateNewTaskId = false;
	
	private List<String> taskStatuses;
	
	private String taskStatus;
	
	private String wakeUpDate;
	
	private String executionDate;
	
	private String workflowStep;
	
	private String currentTaskStatus;
	
	private String currentWakeUpDate;
	
	private String currentExecutionDate;
	
	private String currentWorkflowStep;
	
	private String adminMessage;

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public List<String> getActions() {
		return actions;
	}

	public void setActions(List<String> actions) {
		this.actions = actions;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public boolean isGenerateNewTaskId() {
		return generateNewTaskId;
	}

	public void setGenerateNewTaskId(boolean generateNewTaskId) {
		this.generateNewTaskId = generateNewTaskId;
	}

	public List<String> getTaskStatuses() {
		return taskStatuses;
	}

	public void setTaskStatuses(List<String> taskStatuses) {
		this.taskStatuses = taskStatuses;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getWakeUpDate() {
		return wakeUpDate;
	}

	public void setWakeUpDate(String wakeUpDate) {
		this.wakeUpDate = wakeUpDate;
	}

	public String getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(String executionDate) {
		this.executionDate = executionDate;
	}

	public String getWorkflowStep() {
		return workflowStep;
	}

	public void setWorkflowStep(String workflowStep) {
		this.workflowStep = workflowStep;
	}

	public String getCurrentTaskStatus() {
		return currentTaskStatus;
	}

	public void setCurrentTaskStatus(String currentTaskStatus) {
		this.currentTaskStatus = currentTaskStatus;
	}

	public String getCurrentWakeUpDate() {
		return currentWakeUpDate;
	}

	public void setCurrentWakeUpDate(String currentWakeUpDate) {
		this.currentWakeUpDate = currentWakeUpDate;
	}

	public String getCurrentExecutionDate() {
		return currentExecutionDate;
	}

	public void setCurrentExecutionDate(String currentExecutionDate) {
		this.currentExecutionDate = currentExecutionDate;
	}

	public String getCurrentWorkflowStep() {
		return currentWorkflowStep;
	}

	public void setCurrentWorkflowStep(String currentWorkflowStep) {
		this.currentWorkflowStep = currentWorkflowStep;
	}

	public String getAdminMessage() {
		return adminMessage;
	}

	public void setAdminMessage(String adminMessage) {
		this.adminMessage = adminMessage;
	}
	
}
