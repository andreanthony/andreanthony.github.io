package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import static com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewRule.FLOOD_ZONE_RULE;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.validation.Valid;

public class BIRCollateralDetailsDTO implements Cloneable, Serializable {

	private static final long serialVersionUID = -7652365771456950200L;
	private static final Logger logger = Logger.getLogger(BIRCollateralDetailsDTO.class);
	
	private Long rid;
	
	private Long borrowerInsuranceReviewDetailsRid;
	
	private Long collateralRid;
	
	private boolean allowToVerify = false;
	
	private boolean wantToVerify = false;
	
	private boolean showMismatchAmounts = false;

	private PolicyStatus policyStatus;
	
	private String reasonForVerification;
	public String getReasonForVerification() {
		return reasonForVerification;
	}

	public void setReasonForVerification(String reasonForVerification) {
		this.reasonForVerification = reasonForVerification;
	}

	private String collateralDescription;
	
	private String borrowerName;
	
	private String ownerName;
	
	private AddressDto collateralAddressData;
	
	private String collateralFloodZone;

	@Valid
	private AddressDto policyAddressData;

	@NoInvalidCharacters
	private String policyFloodZone;
	
	private String grandfathered;

	private BIRCollateralDetailsDTO loadTimeValue;
	
	private Map<Long, BIRInsurableAssetDetailsDTO> insurableAssetDetailsMap = new HashMap<Long, BIRInsurableAssetDetailsDTO>();
	
	private Map<String, BIRRuleConclusionDTO> birRuleConclusions = new BIRRuleConclusionMap();

	public List<BIRRuleConclusionDTO> getAllBIRRuleConclusions(Long proofOfCoverageRid) {
		List<BIRRuleConclusionDTO> allBIRRuleConclusions = new ArrayList<BIRRuleConclusionDTO>();
		for (Entry<String, BIRRuleConclusionDTO> collateralEntry : birRuleConclusions.entrySet()) {
			BIRRuleConclusionDTO birRuleConclusion = collateralEntry.getValue();
			birRuleConclusion.populateValues(proofOfCoverageRid, collateralRid, null,
					collateralEntry.getKey(), birRuleConclusion.getConclusion());
			allBIRRuleConclusions.add(birRuleConclusion);
		}
		for (Entry<Long, BIRInsurableAssetDetailsDTO> insurableAssetEntry : insurableAssetDetailsMap.entrySet()) {
			allBIRRuleConclusions.addAll(insurableAssetEntry.getValue().getAllBIRRuleConclusions(proofOfCoverageRid, collateralRid));
		}
		return allBIRRuleConclusions;
	}
	
	public boolean isDisabled(String key, Long insurableAssetSortOrder) {
		if (insurableAssetSortOrder != null) {
			BIRInsurableAssetDetailsDTO insurableAssetDetailsData = insurableAssetDetailsMap.get(insurableAssetSortOrder);
			return insurableAssetDetailsData == null || insurableAssetDetailsData.isDisabled(key, policyStatus, reasonForVerification);
		}
		return BIRDisabledFieldHelper.isDisabled(birRuleConclusions, key, policyStatus, reasonForVerification);
	}
	
	public boolean requiresZoneVarianceEmails() {
		return birRuleConclusions.get(FLOOD_ZONE_RULE.getKey()).hasException();
	}
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getBorrowerInsuranceReviewDetailsRid() {
		return borrowerInsuranceReviewDetailsRid;
	}

	public void setBorrowerInsuranceReviewDetailsRid(Long borrowerInsuranceReviewDetailsRid) {
		this.borrowerInsuranceReviewDetailsRid = borrowerInsuranceReviewDetailsRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}
	
	public boolean isAllowToVerify() {
		return allowToVerify;
	}

	public void setAllowToVerify(boolean allowToVerify) {
		this.allowToVerify = allowToVerify;
	}

	public boolean isWantToVerify() {
		return wantToVerify;
	}

	public void setWantToVerify(boolean wantToVerify) {
		this.wantToVerify = wantToVerify;
	}

	public boolean isShowMismatchAmounts() {
		return showMismatchAmounts;
	}

	public void setShowMismatchAmounts(boolean showMismatchAmounts) {
		this.showMismatchAmounts = showMismatchAmounts;
	}

	public PolicyStatus getPolicyStatus() {
		return policyStatus;
	}
	
	public void setPolicyStatus(PolicyStatus policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getCollateralDescription() {
		return collateralDescription;
	}

	public void setCollateralDescription(String collateralDescription) {
		this.collateralDescription = collateralDescription;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public AddressDto getCollateralAddressData() {
		return collateralAddressData;
	}

	public void setCollateralAddressData(AddressDto collateralAddressData) {
		this.collateralAddressData = collateralAddressData;
	}
	
	public AddressDto getPolicyAddressData() {
		return policyAddressData;
	}

	public void setPolicyAddressData(AddressDto policyAddressData) {
		this.policyAddressData = policyAddressData;
	}

	public String getCollateralFloodZone() {
		return collateralFloodZone;
	}

	public void setCollateralFloodZone(String collateralFloodZone) {
		this.collateralFloodZone = collateralFloodZone;
	}

	public String getPolicyFloodZone() {
		return policyFloodZone;
	}

	public void setPolicyFloodZone(String policyFloodZone) {
		this.policyFloodZone = policyFloodZone;
	}

	public String getGrandfathered() {
		return grandfathered;
	}

	public void setGrandfathered(String grandfathered) {
		this.grandfathered = grandfathered;
	}

	public Map<Long, BIRInsurableAssetDetailsDTO> getInsurableAssetDetailsMap() {
		return insurableAssetDetailsMap;
	}

	public void setInsurableAssetDetailsMap(Map<Long, BIRInsurableAssetDetailsDTO> insurableAssetDetailsMap) {
		this.insurableAssetDetailsMap = insurableAssetDetailsMap;
	}

	public Map<String, BIRRuleConclusionDTO> getBirRuleConclusions() {
		return birRuleConclusions;
	}

	public void setBirRuleConclusions(Map<String, BIRRuleConclusionDTO> birRuleConclusions) {
		this.birRuleConclusions = birRuleConclusions;
	}

	private boolean deepEquals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		BIRCollateralDetailsDTO other = (BIRCollateralDetailsDTO) obj;
		if (!StringUtils.equals(policyFloodZone, other.policyFloodZone)) {
			return false;
		}
		if (!StringUtils.equals(grandfathered, other.grandfathered)) {
			return false;
		}
		if (policyAddressData == null) {
			if (other.policyAddressData != null) {
				return false;
			}
		} else if (policyAddressData.hasChanged()) {
			return false;
		}

		if (insurableAssetDetailsMap == null) {
			if (other.insurableAssetDetailsMap != null) {
				return false;
			}
		} else{
			for(Long key: insurableAssetDetailsMap.keySet()){
				BIRInsurableAssetDetailsDTO insurableAssetDetailsDTO = insurableAssetDetailsMap.get(key);
				if(insurableAssetDetailsDTO.hasChanged()){
					return false;
				}
			}
		}
		return true;
	}

	public boolean hasChanged(){
		if(this.loadTimeValue ==null || this.getRid()==null){
			return true;
		}
		return !deepEquals(this.loadTimeValue);
	}

	public void saveACopy() {
		try {
			if(policyAddressData != null) {
				policyAddressData.saveACopy();
			}
			for(Long key: insurableAssetDetailsMap.keySet()){
				BIRInsurableAssetDetailsDTO insurableAssetDetailsDTO = insurableAssetDetailsMap.get(key);
				insurableAssetDetailsDTO.saveACopy();
			}
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	protected BIRCollateralDetailsDTO clone() throws CloneNotSupportedException {
		return (BIRCollateralDetailsDTO) super.clone();
	}

}
