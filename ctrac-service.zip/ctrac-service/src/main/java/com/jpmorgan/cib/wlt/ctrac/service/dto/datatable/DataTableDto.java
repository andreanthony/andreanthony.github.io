package com.jpmorgan.cib.wlt.ctrac.service.dto.datatable;

import javax.servlet.http.HttpServletRequest;

public interface DataTableDto {

	void parseRequestAttributes (HttpServletRequest httpReq);
}
