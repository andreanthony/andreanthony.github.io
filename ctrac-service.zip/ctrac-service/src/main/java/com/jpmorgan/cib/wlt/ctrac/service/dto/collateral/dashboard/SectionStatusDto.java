package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.io.Serializable;
import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;

public class SectionStatusDto extends BaseDto implements Serializable {

	private static final long serialVersionUID = -8437562668852409463L;
	
	private Long rid;
	
	private Long collateralRid;

	private String verifiedBy;

	private String verifiedDateStr;

	private CollateralDetailsSection sectionId;

	private VerificationStatus statusId;

	private String modifiedBy;

	private String modifiedDateStr;
	
	private Boolean showVerify;
	
	private Date modifiedDate;
	
	private Date verifiedDate;
	

	public String getVerifiedDateStr() {
		return DateConverter.convert(verifiedDate);
	}

	public String getModifiedDateStr() {
		return DateConverter.convert(modifiedDate);
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Date getVerifiedDate() {
		return verifiedDate;
	}

	public void setVerifiedDate(Date verifiedDate) {
		this.verifiedDate = verifiedDate;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public CollateralDetailsSection getSectionId() {
		return sectionId;
	}

	public void setSectionId(CollateralDetailsSection sectionId) {
		this.sectionId = sectionId;
	}

	public VerificationStatus getStatusId() {
		return statusId;
	}

	public void setStatusId(VerificationStatus statusId) {
		this.statusId = statusId;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Boolean getShowVerify() {
		return showVerify;
	}

	public void setShowVerify(Boolean showVerify) {
		this.showVerify = showVerify;
	}


}
