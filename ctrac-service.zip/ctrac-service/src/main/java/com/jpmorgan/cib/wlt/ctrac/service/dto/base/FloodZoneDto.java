package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

public class FloodZoneDto {
	private String floodZone;
	
	public FloodZoneDto(String floodZone) {
		this.setFloodZone(floodZone);
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}
}
