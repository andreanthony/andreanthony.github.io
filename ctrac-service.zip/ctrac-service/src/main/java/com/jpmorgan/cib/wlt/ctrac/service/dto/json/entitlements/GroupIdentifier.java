package com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements;

import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Groups;

import java.io.Serializable;

/**
 * Created by V704662 on 8/21/2017.
 */
public class GroupIdentifier implements Serializable {

    private static final long serialVersionUID = 8228635990157281209L;
    private Long groupId;
    private String groupName;

    public GroupIdentifier(Groups group){
        this.groupId = group.getId();
        this.groupName = group.getGroupName();
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
