package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

public class GenericScreenProperties implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private final String pageUrl;

	private final String screenID;
	
	private final String pageTitle;
	
	private final String actionUrl;
	
	
	public GenericScreenProperties(String pageUrl, String screenID){
		this.pageUrl =pageUrl;
		this.screenID =screenID;
		this.pageTitle = null;
		this.actionUrl=null;
	}
	
	public GenericScreenProperties(String pageUrl, String screenID,String pageTitle,String actionUrl){
		
		this.pageUrl =pageUrl;
		this.screenID =screenID;
		this.pageTitle = pageTitle;
		this.actionUrl=actionUrl;
	}
	

	public String getPageUrl() {
		return pageUrl;
	}

	public String getScreenID() {
		return screenID;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public String getActionUrl() {
		return actionUrl;
	}
}
