package com.jpmorgan.cib.wlt.ctrac.service.insurableasset.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.HoldDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureBook;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureManager;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Service
public class HoldMappingServiceImpl implements HoldMappingService {

    private FeatureManager featureManager;

    @Autowired
    public HoldMappingServiceImpl(FeatureManager featureManager) {
        assert(featureManager != null);
        this.featureManager = featureManager;
    }

    @Override
    public void mapHoldsToCoverageDetails(Collection<RequiredCoverageDTO> requiredCoverageDTOs) {
        Map<Long, Map<Integer, HoldDTO>> primaryHolds = new HashMap<>();
        Map<Long, Map<Integer, HoldDTO>> excessHolds = new HashMap<>();
        for (RequiredCoverageDTO requiredCoverageDTO : requiredCoverageDTOs) {
            extractHoldInformation(requiredCoverageDTO, primaryHolds, excessHolds);
        }
        for (RequiredCoverageDTO requiredCoverageDTO : requiredCoverageDTOs) {
            updateContentsHoldInformation(requiredCoverageDTO, primaryHolds, excessHolds);
        }
    }

    @Override
    public void mapCoverageDetailsToHold(Collection<RequiredCoverageDTO> requiredCoverageDTOs) {
        Map<Long, Map<Integer, HoldDTO>> primaryHolds = new HashMap<>();
        Map<Long, Map<Integer, HoldDTO>> excessHolds = new HashMap<>();
        for (RequiredCoverageDTO requiredCoverageDTO : requiredCoverageDTOs) {
            extractCoverageDetailsInformation(requiredCoverageDTO, primaryHolds, excessHolds);
        }
        for (RequiredCoverageDTO requiredCoverageDTO : requiredCoverageDTOs) {
            updateBuildingHoldInformation(requiredCoverageDTO, primaryHolds, excessHolds);
        }
    }

    private void putHold(Map<Long, Map<Integer, HoldDTO>> holdsBySource, RequiredCoverageDTO requiredCoverageDTO, Integer sortOrder, HoldDTO hold) {
        Map<Integer, HoldDTO> myHolds = getHolds(holdsBySource, requiredCoverageDTO.getRequiredCoverageSourceDto().getRid());
        myHolds.put(sortOrder, hold);
    }

    private Map<Integer, HoldDTO> getHolds(Map<Long, Map<Integer, HoldDTO>> holdsBySource, Long requiredCoverageSourceRid) {
        Map<Integer, HoldDTO> holds = holdsBySource.get(requiredCoverageSourceRid);
        if (holds == null) {
            holds = new HashMap<>();
            holdsBySource.put(requiredCoverageSourceRid, holds);
        }
        return holds;
    }

    private void extractCoverageDetailsInformation(RequiredCoverageDTO requiredCoverageDTO, Map<Long, Map<Integer, HoldDTO>> primaryHolds, Map<Long, Map<Integer, HoldDTO>> excessHolds) {
        Integer sortOrder = requiredCoverageDTO.getSortOrder();
        if (requiredCoverageDTO.getPrimaryCoverageDetailsDto() != null) {
            HoldDTO primaryHold = requiredCoverageDTO.getPrimaryCoverageDetailsDto().getHoldDTO();
            if (primaryHold != null && primaryHold.isEntered()) {
                primaryHold.setRequired(true);
                requiredCoverageDTO.setPrimaryHold(primaryHold);
                putHold(primaryHolds, requiredCoverageDTO, sortOrder, primaryHold);
            }
        }
        if (requiredCoverageDTO.getExcessCoverageDetailsDto() != null) {
            HoldDTO excessHold = requiredCoverageDTO.getExcessCoverageDetailsDto().getHoldDTO();
            if (excessHold != null && excessHold.isEntered()) {
                excessHold.setRequired(true);
                requiredCoverageDTO.setExcessHold(excessHold);
                putHold(excessHolds, requiredCoverageDTO, sortOrder, excessHold);
            }
        }
    }

    private void updateBuildingHoldInformation(RequiredCoverageDTO requiredCoverageDTO, Map<Long, Map<Integer, HoldDTO>> primaryHolds, Map<Long, Map<Integer, HoldDTO>> excessHolds) {
        InsurableAssetType assetType = requiredCoverageDTO.getInsurableAssetDTO().getInsurableAssetType();
        Integer sortOrder = requiredCoverageDTO.getSortOrder();
        if (assetType == InsurableAssetType.STRUCTURE) {
            HoldDTO primaryHold = requiredCoverageDTO.getPrimaryHold();
            if (primaryHold == null || !primaryHold.isRequired()) {
                Map<Integer, HoldDTO> myPrimaryHolds = getHolds(primaryHolds, requiredCoverageDTO.getRequiredCoverageSourceDto().getRid());
                if (myPrimaryHolds.containsKey(sortOrder)) {
                    requiredCoverageDTO.setPrimaryHold(myPrimaryHolds.get(sortOrder).copyHoldInfo());
                }
            }
            HoldDTO excessHold = requiredCoverageDTO.getExcessHold();
            if (excessHold == null || !excessHold.isRequired()) {
                Map<Integer, HoldDTO> myExcessHolds = getHolds(excessHolds, requiredCoverageDTO.getRequiredCoverageSourceDto().getRid());
                if (myExcessHolds.containsKey(sortOrder)) {
                    requiredCoverageDTO.setExcessHold(myExcessHolds.get(sortOrder).copyHoldInfo());
                }
            }
        }
    }

    private void extractHoldInformation(RequiredCoverageDTO requiredCoverageDTO, Map<Long, Map<Integer, HoldDTO>> primaryHolds, Map<Long, Map<Integer, HoldDTO>> excessHolds) {
        InsurableAssetType assetType = requiredCoverageDTO.getInsurableAssetDTO().getInsurableAssetType();
        if (assetType == InsurableAssetType.BASE_INSURABLE_ASSET) {
            return;
        }
        Integer sortOrder = requiredCoverageDTO.getSortOrder();
        HoldDTO primaryHold = requiredCoverageDTO.getPrimaryHold();
        HoldDTO excessHold = requiredCoverageDTO.getExcessHold();
        if (assetType == InsurableAssetType.STRUCTURE && primaryHold.isEntered()) {
            putHold(primaryHolds, requiredCoverageDTO, sortOrder, primaryHold);
            setCoverageDetailsHold(requiredCoverageDTO, CoverageType.PRIMARY, primaryHold);
        }
        if (assetType == InsurableAssetType.STRUCTURE && excessHold.isEntered()) {
            putHold(excessHolds, requiredCoverageDTO, sortOrder, excessHold);
            setCoverageDetailsHold(requiredCoverageDTO, CoverageType.EXCESS, excessHold);
        }
        if (assetType == InsurableAssetType.BUSINESS_INCOME && primaryHold.isEntered()) {
            setCoverageDetailsHold(requiredCoverageDTO, CoverageType.PRIMARY, primaryHold);
        }
    }

    private void updateContentsHoldInformation(RequiredCoverageDTO requiredCoverageDTO, Map<Long, Map<Integer, HoldDTO>> primaryHolds, Map<Long, Map<Integer, HoldDTO>> excessHolds) {
        InsurableAssetType assetType = requiredCoverageDTO.getInsurableAssetDTO().getInsurableAssetType();
        Integer sortOrder = requiredCoverageDTO.getSortOrder();
        if (assetType == InsurableAssetType.BASE_INSURABLE_ASSET) {
            Map<Integer, HoldDTO> myPrimaryHolds = getHolds(primaryHolds, requiredCoverageDTO.getRequiredCoverageSourceDto().getRid());
            setContentsCoverageDetailsHold(requiredCoverageDTO, CoverageType.PRIMARY, myPrimaryHolds.get(sortOrder), requiredCoverageDTO.getPrimaryHold());
            Map<Integer, HoldDTO> myExcessHolds = getHolds(excessHolds, requiredCoverageDTO.getRequiredCoverageSourceDto().getRid());
            setContentsCoverageDetailsHold(requiredCoverageDTO, CoverageType.EXCESS, myExcessHolds.get(sortOrder), requiredCoverageDTO.getExcessHold());
        }
    }

    private void setContentsCoverageDetailsHold(RequiredCoverageDTO requiredCoverageDTO, CoverageType coverageType, HoldDTO buildingHold, HoldDTO contentsHold) {
        if (buildingHold != null && holdIsRequired(contentsHold)) {
            contentsHold.setHoldType(buildingHold.getHoldType());
            contentsHold.setHoldPeriod(buildingHold.getHoldPeriod());
            contentsHold.setStartDate(buildingHold.getStartDate());
            setCoverageDetailsHold(requiredCoverageDTO, coverageType, contentsHold);
        }
    }

    private void setCoverageDetailsHold(RequiredCoverageDTO requiredCoverageDTO, CoverageType coverageType, HoldDTO holdDTO) {
        if (!holdIsRequired(holdDTO)) {
            return;
        }
        if (coverageType == CoverageType.PRIMARY) {
            requiredCoverageDTO.getPrimaryCoverageDetailsDto().setHoldDTO(holdDTO);
        } else if (coverageType == CoverageType.EXCESS) {
            requiredCoverageDTO.getExcessCoverageDetailsDto().setHoldDTO(holdDTO);
        }
    }

    private boolean holdIsRequired(HoldDTO hold) {
        return hold != null && hold.isRequired();
    }
}
