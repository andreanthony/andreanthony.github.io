package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.cls;

import com.jpmorgan.cib.wlt.ctrac.service.excel.ColumnDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;

public class CLSTableDefinition {

	public static final ColumnDefinition[] CLS_TABLE_DEFINITION = {
		new ColumnDefinition("Amount", "amount", FieldType.AMOUNT),
		new ColumnDefinition("Account", "account", FieldType.STRING),
		new ColumnDefinition("Company Code", "companyCode", FieldType.STRING),
		new ColumnDefinition("Cost Center", "costCenter", FieldType.GRAYABLE),
		new ColumnDefinition("Description", "description", FieldType.STRING),	
		new ColumnDefinition("Serial Field", "serialField", FieldType.STRING),	
	};
	
}
