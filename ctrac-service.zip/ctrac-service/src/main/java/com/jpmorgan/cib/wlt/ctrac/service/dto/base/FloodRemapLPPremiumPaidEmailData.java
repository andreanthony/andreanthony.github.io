package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.LPPremiumPolicyData;

public class FloodRemapLPPremiumPaidEmailData extends FloodRemapSendEmailData implements Serializable {	
	
	private static final long serialVersionUID = -2356815145247254815L;
	
	private List<LPPremiumPolicyData> lpPremiumPolicyDataList = new ArrayList<LPPremiumPolicyData>();
	
	private Long perfectionRid;
	private String screenTitle;
	
	public Long getPerfectionRid() {
		return perfectionRid;
	}

	public void setPerfectionRid(Long perfectionRid) {
		this.perfectionRid = perfectionRid;
	}

	public List<LPPremiumPolicyData> getLpPremiumPolicyDataList() {
		return lpPremiumPolicyDataList;
	}

	public void setLpPremiumPolicyDataList(
			List<LPPremiumPolicyData> lpPremiumPolicyDataList) {
		this.lpPremiumPolicyDataList = lpPremiumPolicyDataList;
	}

	/**
	 * @return the screenTitle
	 */
	public String getScreenTitle() {
		return screenTitle;
	}

	/**
	 * @param screenTitle the screenTitle to set
	 */
	public void setScreenTitle(String screenTitle) {
		this.screenTitle = screenTitle;
	}
}
