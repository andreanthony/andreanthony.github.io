package com.jpmorgan.cib.wlt.ctrac.service.email;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LpInsuranceVendor;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;

import java.io.File;
import java.util.List;

/**
 * @author n595724
 */
public interface EmailNotificationService {

    void releaseLpInitiatedMarketEmail(List<? extends ProofOfCoverageDTO> lpCoveragesToCancels, Collateral collateral);

    /**
     * This email is send to notify the market that a given collateral need
     * coverage and will be Lender placed after the letter cycle.
     */
    void releasePreLpMarketEmail(Long triggerworkItemId);

    /**
     * for combined email
     */
    void releaseLpMarketCancellationEmail(List<? extends ProofOfCoverageDTO> lpCoveragesToCancels, Long collateralId, List<? extends ProofOfCoverageDTO> lpCoveragesToIssue);


    /**
     * this is the email send to the insurance vendor to request LP initiation
     */
    void requestLPInitiationVendorEmail(File insuranceReqFile, LpInsuranceVendor lpVendor);

	void sendBIRExceptionEmails(PerfectionTask perfectionTask, TaskState currentTaskState, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);

	void sendBIRPolicyAcceptedWithNoExceptionEmails(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);

	void releaseCombinedIssueAndCancelLPEmail(List<ProofOfCoverageDTO> lpCoveragesToIssuesWithCancellation, Collateral collateral);

	void sendLettersReviewEmail();

    void sendMarketHoldEmail(PerfectionTask perfectionTask);

    public void sendLeadbankEmails(PerfectionTask perfectionTask, TaskState currentTaskState );

    void sendCoverageGapReportEmail();
}
