package com.jpmorgan.cib.wlt.ctrac.service.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.command.Command;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.WorkflowStateAttributes;
import com.jpmorgan.cib.wlt.ctrac.service.helper.LookupCodeUtil;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.DASHBOARD_WORKABLE_STATUS;

/**
 * @author n595724
 *
 */

@Service(value="taskService")
public class TaskServiceImpl implements TaskService {

	private static final Logger logger = LoggerFactory.getLogger(TaskServiceImpl.class);

	@Autowired
	private LookupCodeUtil lookupCodeUtil;

	@Autowired @Qualifier("TMService")
	private TMService otmService;

	@Autowired
	private PerfectionTaskRepository perfectionTaskRepository;

	@Autowired
	private PerfectionTaskService perfectionTaskService;

	@Autowired
	private AuditInformationService auditInformationService;


	@Override
	@Transactional
	public String getHelperUrl(TMParams TMParams) {
		return getHelperUrl(TMParams, Arrays.asList(TaskStatus.OPEN));
	}

	/**
	 * This method is invoke when we receive a request to launch a given helper page from TM.
	 * Interact with the work-flow engine to determine the helper url. 
	 * @param TMParams
	 * @return
	 */

	@Override
	@Transactional
	public String getHelperUrl(TMParams TMParams, List<TaskStatus> status) {
		//Attempt to retrieve the task from the repository.
		PerfectionTask perfectionTask = getPerfectionTask(TMParams, status);

		//If we have a valid task, we get the workflow step.
		String workflowStep_string = perfectionTask.getWorkflowStep();
		TaskState taskState = WorkflowStateDefinition.findByWorkflowStep(workflowStep_string).getFloodRemapTaskState();

		//The method getParameterTypesNeededForURL() will tell us what our current workflow step needs to 
		// return a URL. We populate a map. 
		HashMap<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
		inputParameterMap.put(StateParameterType.PERFECTION_TASK, perfectionTask);

		//We pass the map to the Workflow step and retrieve the URL
		return taskState.getHelperURL(inputParameterMap);
	}



	/**
	 * @see com.jpmorgan.cib.wlt.ctrac.service.TaskService#completeWorkFlowStepOperations(java.util.Map)
	 *
	 * This method execute all the operations needed to update the workflow state; In particular, the Tasks state and transitions if needed.
	 * TM state is updated as part of this call. 
	 * This does not save non workflow data such as user inputs, loand data ...
	 * @param inputParameterMap
	 * @return
	 */
	@Override
	@Transactional
	public Map<String, Object> completeWorkFlowStepOperations (Map<StateParameterType, Object> inputParameterMap) {
		String userId = auditInformationService.getLoggedInUserSid();
		inputParameterMap.put(StateParameterType.USER_ID, userId);
		TaskState currentState = getTaskStateFromParamMap(inputParameterMap);
		WorkflowStateAttributes workflowStateAttributes = currentState.computeNextStateAttributes(inputParameterMap);
		SortedSet<? extends Command> ctracOperations = currentState.computeCtracActions(workflowStateAttributes, inputParameterMap);
		executeOperations(ctracOperations);
		SortedSet<? extends Command> tmTODOOperations = currentState.computeTMActions(workflowStateAttributes, inputParameterMap);
		executeOperations(tmTODOOperations);
		return null; //TODO do we need to report anything back?
	}

	@Override
	public Map<String, Object> completeEODBatchOperations(Map<StateParameterType, Object> inputParameterMap) {
		TaskState currentState = getTaskStateFromParamMap(inputParameterMap);
		SortedSet<? extends Command> eodBatchOperations = currentState.computeEODBatchActions(inputParameterMap);
		executeOperations(eodBatchOperations);
		return null;
	}


	/**
	 * @see com.jpmorgan.cib.wlt.ctrac.service.TaskService#isLaunchHelperEnabled(com.jpmorgan.cib.wlt.ctrac.dto.TMParams)
	 * This method determine if there are rules preventing this helper from being lunched, for instance if the task is in review or on any other state that forbid 
	 * the helper from being launched.
	 * @param TMParams
	 * @return
	 */
	@Override
	@Transactional
	public boolean isHelperPageDisabled(TMParams TMParams, List<TaskStatus> status) {

		boolean result = false;

		PerfectionTask perfectionTask = getPerfectionTask(TMParams, status);

		String isInReview = perfectionTask.getInInsuranceReview();
		if (!StringUtils.isBlank(isInReview)) {
			result = "Y".equalsIgnoreCase(isInReview);
		}

		//If the task is in review status, there's no further need to check
		//the workflow step. The helper is disabled.
		if(result) {
			return result;
		}

		//If the task was launched from the dashboard, 
		//we need to make sure that the task is in an eligible workflow. 
		if(TMParams.isLaunchedFromCtrac()){
			result = true;
			List<LookUpCode> lookUpCodes = lookupCodeUtil.getLookupCodes(DASHBOARD_WORKABLE_STATUS);
			for(LookUpCode lookUpCode: lookUpCodes){
				if(lookUpCode.getDescription().equalsIgnoreCase(perfectionTask.getWorkflowStep())){
					result = false;
				}
			}
		}

		return result;

	}

	@Override
	public Map<String, Object> initiateWorkflow(Map<StateParameterType, Object> inputParameterMap) {
		// TODO Auto-generated method stub
		throw new RuntimeException("Method not yet implemented ");
	}

	/**
	 *
	 */
	@Override
	@Transactional
	public void abortWorkflow(Map<StateParameterType, Object> inputParameterMap, String CompleteReaseon) {
		try {
			Set<PerfectionTask> workflowTasks = new HashSet<PerfectionTask>();
			PerfectionTask oneTasks = (PerfectionTask) inputParameterMap.get(StateParameterType.PERFECTION_TASK);
			if(oneTasks!=null){
				workflowTasks.add(oneTasks);
			}
			WorkItem workItem = (WorkItem) inputParameterMap.get(StateParameterType.WORK_ITEM);
			if(workItem!=null){
				Collection<PerfectionTask> tasks = perfectionTaskRepository.findByWorkItemRid(workItem.getRid());
				workflowTasks.addAll(tasks);
			}

			for(PerfectionTask task : workflowTasks){

				if(TaskStatus.OPEN.name().equalsIgnoreCase(task.getTaskStatus())){
					otmService.cancelTask(task);
				}

				if(! TaskStatus.CLOSED.name().equals(task.getTaskStatus())){
					task.setTaskStatus(TaskStatus.CLOSED.name());
					task = perfectionTaskRepository.save(task);
				}
			}
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		} catch (Exception ex) {
			throw new CTracApplicationException("E0146", CtracErrorSeverity.APPLICATION, ex);
		}
	}

	private TaskState getTaskStateFromParamMap(Map<StateParameterType, Object> inputParameterMap){
		PerfectionTask perfectionTask = (PerfectionTask) inputParameterMap.get(StateParameterType.PERFECTION_TASK);
		String wfStep = perfectionTask.getWorkflowStep();
		TaskState result = WorkflowStateDefinition.findByWorkflowStep(wfStep).getFloodRemapTaskState();
		return result;
	}

	private void executeOperations(SortedSet<? extends Command> operations){
		String currentCommandClass= "";
		try {
			for (Command command : operations) {
				currentCommandClass = command.getClass().getName();
				command.execute();
			}
		} catch (Exception swallow) {
			logger.error("An exception occured while completing a command: {}", currentCommandClass, swallow);
			throw new CTracApplicationException("E0235", CtracErrorSeverity.APPLICATION);
		}
	}


	private PerfectionTask getPerfectionTask(TMParams TMParams, List<TaskStatus> status) {
		PerfectionTask perfectionTask = null;
		String task = TMParams.getId_task();
		try {
			List<String> allowedStatus = new ArrayList<>();
			for (TaskStatus stat : status) {
				allowedStatus.add(stat.name());
			}
			perfectionTask = perfectionTaskRepository.findByTmTaskIdAndTaskStatusIn(task,allowedStatus);
		} catch (Exception e) {
			logger.error("An exception occured while getting the perfection task with the task id: {}", task, e);
			throw new CTracApplicationException("E0234", CtracErrorSeverity.APPLICATION);
		}
		if(perfectionTask == null){
			logger.error("No open perfection task was found for taskID: {}", task);
			throw new CTracApplicationException("E0233", CtracErrorSeverity.APPLICATION);
		}
		return perfectionTask;
	}

	@Override
	public void validateTMParams(TMParams tMParams) {
		if(tMParams == null || tMParams.getId_task() == null){
			logger.error("Task UUID from TM is null");
			throw new CTracApplicationException("E0109", CtracErrorSeverity.CRITICAL);
		}

		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskIdAndTaskStatusIn(
				tMParams.getId_task(), Arrays.asList(TaskStatus.OPEN.toString(), TaskStatus.SLEEPING.toString(),TaskStatus.TRANSIENT.toString()));
		if (perfectionTask == null) {
			logger.error("Task not found for the given UUID: {}", tMParams.getId_task());
			throw new CTracApplicationException("E0111", CtracErrorSeverity.APPLICATION);
		}
	}
}
