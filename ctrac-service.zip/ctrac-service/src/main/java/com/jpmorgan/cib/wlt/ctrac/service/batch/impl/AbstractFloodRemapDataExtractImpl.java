package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProcessType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FileProcessingUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CtracReferenceDateRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileException;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileExceptionSender;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileValidator;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapLineOfBusinessConverter;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.impl.MultipleFilesException;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CtracBaseHelperData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import net.lingala.zip4j.exception.ZipException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.*;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.PROCESS_VENDOR_CERTIFICATES;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.PROCESS_VENDOR_FILE;

public abstract class AbstractFloodRemapDataExtractImpl {
	
	private static final Logger logger = Logger.getLogger(AbstractFloodRemapDataExtractImpl.class);	
	private static final String FROM_ADDRESS = "from.email.address.ctrac.system";
	private static final String EMAIL_SUBJECT_UNEXPECTED_ERROR = "gdsLetters.email.notification.subject.unExpectedError";
	private static final String EMAIL_NOTIFICATION_ERROR = "gdsLetters.email.notification.unExpectedError";
	private static final String REDUNDANT_FILES_FOUND = "Redundant files found.";
	private static final String EMAIL_SUBJECT = "althans.response.invalid.subject";
	private static final String ALTHANS_INBOUND_LANDING_DIR = "althans.landing.inbound.directory";
	private static final String ALTHANS_INBOUND_XLSX_LANDING_DIR = "althans.landing.inbound.xlsx.directory";
	private static final String ALTHANS_INBOUND_ZIP_LANDING_DIR = "althans.landing.inbound.zip.directory";
	
	protected String arrPoEmailAddress[];
	protected String arrCtracEmailAddress[];
	protected RemapVendor remapVendor = null;

	@Autowired protected Environment env;
	@Autowired private MessageSource messageSource;
	@Autowired protected CalendarDayUtil calendarDayUtil;
	@Autowired private CtracReferenceDateRepository ctracReferenceDateRepository;
	@Autowired protected CollateralDocumentService collateralDocumentService;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	@Autowired private TaskService taskService;
	@Autowired private RemapFileValidator remapFileValidator;
	@Autowired private RemapFileExceptionSender remapFileExceptionSender;
	@Autowired protected RemapLineOfBusinessConverter remapLineOfBusinessConverter;
	@Autowired 
	protected FloodEmailService floodEmailService;

   /**
    * Main method to process remap files 
    */
	@Transactional
	public void processRemapFiles() {
        assertRemapVendorNotNull();
	    List<RemapFileException> exceptions = new ArrayList<>();
		setEmailReceiver();
		File[] files = getAllFiles();
		if (files != null) {
			if (files.length > 1) {
                exceptions.add(new MultipleFilesException(remapVendor));
            }
			updateLastFileReceivedDate();
			for (File file : files) {
			    exceptions.addAll(remapFileValidator.validateRemapFile(remapVendor, file.getName()));
				if (isValidZipFile(file)) {
					extractContents(file);
					if (areValidContents()) {
						processContents();
					}
					archiveContents();
				}
				archiveFile(file);			
			}
		}
		if (exceptions.size() > 0) {
		    remapFileExceptionSender.sendExceptions(remapVendor, exceptions);
        }
	}

	private void assertRemapVendorNotNull() {
        if (remapVendor == null) {
            logger.error("No remapVendor specified for processRemapFiles.");
            throw new CTracApplicationException("E0137", CtracErrorSeverity.CRITICAL);
        }
    }
	
	/**
    * Main method to process remap files 
    */
	@Transactional
	public void processDataLoad() {
		setEmailReceiver();
		File[] files = getAllFiles();
		if (files != null) {
			updateLastFileReceivedDate();
			for (File file : files) {					
				if (areValidContents()) {
					processContents(file);
				}
				archiveFile(file);			
			}
		}
	}
	
	/**
	    * Main method to process image and ack file
	    */
	@Transactional
	public boolean processLetterImages() {
		try {
			setEmailReceiver();
			if (areValidContents()) {
				updateLastFileReceivedDate();
				processContents();
				archiveContents();
				return true;
			}
			archiveContents();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			archiveContents();
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0313", CtracErrorSeverity.CRITICAL));
			sendNotificationEmail(EMAIL_NOTIFICATION_ERROR, arrPoEmailAddress, arrCtracEmailAddress,EMAIL_SUBJECT_UNEXPECTED_ERROR);
		}
		return false; 
	}
	
	
	@Transactional
	public void processAlthansResponse() {
		//1 If there are any transient tasks in Process_Vendor_File with wake-up date today or earlier
		althansPreBatchProcess();
		setEmailReceiver();
		List<PerfectionTask> tasks = getTasks();
		for(PerfectionTask task: tasks){
			File file = getFile(task.getRid());
			if(isValidFile(file, task.getRid())){
				processContents(file);
				processBatchTask(task);
			}
			archiveFile(file);			
		}
		handleRedundantFiles(PROCESS_VENDOR_FILE);
	}
	

	@Transactional
	public void processAlthansCertificateFile() {
		althansPreBatchProcess();
		setEmailReceiver();
		List<PerfectionTask> tasks = getTasks();
		for (PerfectionTask task : tasks) {
			File zipfile = getFile(task.getRid());
			if (isValidFile(zipfile, task.getRid())) {
				extractContents(zipfile);				
				processContents(task.getWorkItem().getRid());
				processBatchTask(task);
			}
			archiveFile(zipfile);
			archiveContents();
		}
		handleRedundantFiles(PROCESS_VENDOR_CERTIFICATES);
	}
	
	protected void processBatchTask(PerfectionTask task) {
		CtracBaseHelperData ctracBaseHelperData = new CtracBaseHelperData();
		ctracBaseHelperData.setWorkflowTransitionProcess(ProcessType.BATCH_PROCESS.getName());
		Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
		inputParameterMap.put(StateParameterType.HELPER_DATA, ctracBaseHelperData);
		inputParameterMap.put(StateParameterType.PERFECTION_TASK, task);
		inputParameterMap.put(StateParameterType.WORK_ITEM, task.getWorkItem());
		taskService.completeWorkFlowStepOperations(inputParameterMap);
	}

	protected abstract File[] getAllFiles();
	protected abstract boolean isValidZipFile(File file);
	protected abstract void extractContents(File file);
	protected abstract boolean areValidContents();
	protected abstract void processContents();
	protected void processContents(Long batchItem) {
		//Eligible subclass should implement it		
	}
	protected abstract void processContents(File file);
	protected abstract void archiveContents();
	protected abstract void archiveFile(File file);
	protected abstract void updateLastFileReceivedDate();
	protected abstract boolean isValidFileName(File file);
	
	
	protected void althansPreBatchProcess() {
		File contentsDirectory = new File(env.getRequiredProperty(ALTHANS_INBOUND_LANDING_DIR));
		File[] contents = contentsDirectory.listFiles();
		for (File file : contents) {
			String extension = FilenameUtils.getExtension(file.getName());
			if ("xlsx".equalsIgnoreCase(extension)) {
				FileProcessingUtil.moveAndOverwrite(file, env.getRequiredProperty(ALTHANS_INBOUND_XLSX_LANDING_DIR));
			} else if ("zip".equalsIgnoreCase(extension)) {
				FileProcessingUtil.moveAndOverwrite(file, env.getRequiredProperty(ALTHANS_INBOUND_ZIP_LANDING_DIR));
			} else if (!file.isDirectory()){
				logger.debug("Invalid Althans file type: " + extension);	
				logger.debug("Invalid file will be handled by the certificate batch");	
				FileProcessingUtil.moveAndOverwrite(file, env.getRequiredProperty(ALTHANS_INBOUND_ZIP_LANDING_DIR));
			}
		}	
	}

	/**
	 * Validation for all the flood remap records from vendor file if each record has a matching PDF file. if this is not the case this validation fails
	 * @param floodRemapRequestNumbers - List Of all flood remap records extracted from file
	 * @param floodDeterminationsByFileName - Map containing all the PDF documents that were received in the vendor zip file
	 * @return flag
	 */
	protected boolean remapRecordsHaveCorrespondingFiles(List<String> floodRemapRequestNumbers,
														 Map<String, CollateralDocument> floodDeterminationsByFileName) {
		logger.debug("remapRecordsHaveCorrespondingFiles::START");
		if(!CollectionUtils.isEmpty(floodRemapRequestNumbers)){
			for(String requestNumber: floodRemapRequestNumbers){
				//When record number was not found as a file - reject the file
				if(!floodDeterminationsByFileName.containsKey(requestNumber)){
					logger.debug("Record " + requestNumber + " does not have any matching PDF file");
					return false;
				}
			}
		}
		logger.debug("remapRecordsHaveCorrespondingFiles::END");
		return true;
	}
	
	protected List<PerfectionTask> getTasks(){
		return null;
	}
	
	protected File getFile(Long taskRid){
		PerfectionTask task = perfectionTaskRepository.findOne(taskRid);
		Long targetFileId = task.getWorkItem().getRid();
		for(File file: getAllFiles()){
			if(targetFileId.equals(getFileId(file))){
				return file;
			}
		}
		return null;
	}

	protected Long getFileId(File file) {
		return null;
	}
	
	protected boolean isValidFile(File file, Long taskRid) {
		return true;
	}

	
	protected void sendNotificationEmail(String messageLabel, String[] toAddresses, String[] ccAddress, String subject) {
		EmailAttributeHolder emailAttributeHolder = populateEmail(toAddresses, ccAddress, subject);
		String emailMessage = messageSource.getMessage(messageLabel, null, Locale.getDefault());
		emailAttributeHolder.setEmailBody(emailMessage);
		floodEmailService.sendEmail(emailAttributeHolder);		
	}

	//this method allow the use of an array of arguments that will be filled in for params within the message (params look like "{0}", "{1,date}", "{2,time}" within a message)
	protected void sendNotificationEmail(String messageLabel, String[] toAddresses, String[] ccAddress, String subject, String[] args) {
		EmailAttributeHolder emailAttributeHolder = populateEmail(toAddresses, ccAddress, subject);
		String emailMessage = messageSource.getMessage(messageLabel, args, Locale.getDefault());
		emailAttributeHolder.setEmailBody(emailMessage);
		floodEmailService.sendEmail(emailAttributeHolder);
	}

	protected void sendNotificationEmailAttachments(String message, String[] toAddresses, String[] ccAddress, String subject, List<File> attachment){
		EmailAttributeHolder emailAttributeHolder = populateEmail(toAddresses, ccAddress, subject);	
		emailAttributeHolder.setEmailBody(message);
		emailAttributeHolder.setAttachments(attachment);
		floodEmailService.sendEmail(emailAttributeHolder);		
	}
	
	protected void sendNotificationEmailAttachment(String messageLabel, String[] toAddresses, String[] ccAddress, String subject,File fileAttachment) {
		EmailAttributeHolder emailAttributeHolder = populateEmail(toAddresses, ccAddress, subject);
		String emailMessage = messageSource.getMessage(messageLabel, null, Locale.getDefault());
		emailAttributeHolder.setEmailBody(emailMessage);
		emailAttributeHolder.setSingleFileAttachment(fileAttachment);
		floodEmailService.sendEmail(emailAttributeHolder);		
	}
	
	protected void sendNotificationEmailAttachmentMessage(String message, String[] toAddresses, String[] ccAddress, String subject,File fileAttachment) {
		EmailAttributeHolder emailAttributeHolder = populateEmail(toAddresses, ccAddress, subject);
		emailAttributeHolder.setEmailBody(message);
		emailAttributeHolder.setSingleFileAttachment(fileAttachment);
		floodEmailService.sendEmail(emailAttributeHolder);		
	}

	/**
	 * Get all the file from a landing dir
	 * @param landingZipDir
	 * @return
	 */
	protected File[] getAllFiles(String landingZipDir) {
		File landingDirectory = new File(env.getRequiredProperty(landingZipDir));
		File[] landingDirectoryFiles = landingDirectory.listFiles();
		logger.debug(landingDirectoryFiles.length+" files found in landing directory.");
		if (landingDirectoryFiles.length > 0) {
			return landingDirectoryFiles;
		}
		return null;
	}
	
	/**
	 * If it is a zip file and has a valid name
	 *  return true
	 * Else
	 *  return false
	 *  
	 * @param file
	 * @param emailNotificationSubject
	 * @param emailContent
	 * @return
	 */
	protected boolean isValidZipFile(File file, String emailNotificationSubject, String emailContent) {
		if (!file.exists()) {
			logger.error("The file does not exist: " + file.getAbsolutePath());
		} else if (!file.canRead()) {
			logger.error("The file exists but cannot be read: " + file.getAbsolutePath());
		} else if (FileProcessingUtil.isZipFile(file) && isValidFileName(file)) {
			logger.debug("This is a valid zip file with proper name: " + file.getName());
			return true;
		} else {
			logger.error("This is an invalid zip file: " + file.getAbsolutePath());
		}
		sendNotificationEmail(emailContent, arrPoEmailAddress, arrCtracEmailAddress, emailNotificationSubject);
		return false;
	}
	
	protected boolean isValidFileName(File file, String fileNamePrefix) {
		if(file != null){
			String fileName = file.getName();
			if(fileName != null && fileName.startsWith(fileNamePrefix)){
				logger.debug("file name starts with "+fileNamePrefix);
				return true;
			}else {
				logger.debug("file name does not starts with "+fileNamePrefix+" : Invalid file.");
			}
		}
		return false;
	}

	
	/**
	 * Method to save service link pdf document to Colletral documents table
	 * @param 
	 * @return 
	 * @return void
	 */
	protected Map<String, CollateralDocument> savePDFFiles(String dataLandingDir) {
		logger.debug("savePDFFiles::BEGIN");
		Map<String, CollateralDocument> floodDeterminationsByFileName = new HashMap<String, CollateralDocument>();
		try {
			File dir = new File(env.getProperty(dataLandingDir) + PATH_SEPERATOR);
			List<CollateralDocument> collateralDocuments = createNewCollateralDocuments(dir.listFiles(), CollateralDocumentType.SFHDF);
			for (CollateralDocument collateralDocument : collateralDocuments) {
				addFloodDeterminationByFileName(floodDeterminationsByFileName, collateralDocument);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new CTracApplicationException("E0213", CtracErrorSeverity.CRITICAL);
		}
		logger.debug("savePDFFiles::END");
		return floodDeterminationsByFileName;
	}
	
	private void addFloodDeterminationByFileName(Map<String, CollateralDocument> floodDeterminationsByFileName, CollateralDocument collateralDocument) {
		String key = collateralDocument.getFileName();
		if (floodDeterminationsByFileName.containsKey(key)) {
			floodDeterminationsByFileName.put(key, null);
		} else {
			floodDeterminationsByFileName.put(key, collateralDocument);
		}
	}

	private List<CollateralDocument> createNewCollateralDocuments(File[] fileList, CollateralDocumentType collateralDocumentType) {
		List<CollateralDocument> collateralDocuments = new ArrayList<CollateralDocument>();
		if (fileList == null || fileList.length == 0) {
			logger.debug("No CollateralDocument(s) in fileList");
			return collateralDocuments;
		}
		
		for (File file : fileList) {
			CollateralDocument collateralDocument = collateralDocumentService.saveCollateralDocument(file, collateralDocumentType.getName(), null, null);
			if (collateralDocument != null) {
				collateralDocuments.add(collateralDocument);
			}
		}
		
		logger.debug("CollateralDocument(s) saved");
		return collateralDocuments;
	}
	
	public enum CollateralDocumentType {
		SFHDF("SFHDF"),
		PREMIUM_CERTIFICATE("PREMIUM_CERTIFICATE"),
		REFUND_CERTIFICATE("REFUND_CERTIFICATE");
		
		private String name;
		private CollateralDocumentType(String name) {
			this.name = name;
		}
		public String getName() {
			return name;
		}
	}
	
	protected void extractContents(File file, String dir) {
		try {
			FileProcessingUtil.extractZipFile(file, env.getRequiredProperty(dir));
		} catch (ZipException e) {
			logger.error("Error unzipping Core Logic zip file: " + e.getMessage(), e);
		}
	}
	
	/**
	 * Update the last file received date in reference date table 
	 * @param batchName
	 */
	protected void updateLastFileReceivedDate(String batchName) {
		ReferenceDate lastRemapFileRecievedDate = ctracReferenceDateRepository.findByName(batchName);
		Date current = calendarDayUtil.getCurrentReferenceDate();
		logger.debug("Updating "+batchName+" lastRemapFileReceived: " + current.toString());
		lastRemapFileRecievedDate.setReferencDate(current);
		ctracReferenceDateRepository.save(lastRemapFileRecievedDate);
		logger.info(batchName+" last remap file recieved date has been set to: "+current);
	}
	
	protected boolean isValidRemapData(String statusChange) {
		boolean isValidRemapData = false;
		if(statusChange != null &&  !statusChange.isEmpty()){
			isValidRemapData = true;
			List<String> listRemapTypes = Arrays.asList(FLOOD_REMAP_TYPES);
			isValidRemapData = listRemapTypes.contains(statusChange.trim().toUpperCase());
		}
		return isValidRemapData;		
	}
	
	protected void handleRedundantFiles( WorkflowStateDefinition workflowStateDefinition) {
		List<File> redundantFiles = new ArrayList<File>();
		for(File file: getAllFiles()){
			if(!validForFutureProcessing(file,workflowStateDefinition)){
				redundantFiles.add(file);
			}
		}
		if(redundantFiles.size() > 0){
			sendNotificationEmailAttachments(REDUNDANT_FILES_FOUND, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT, redundantFiles);
			for(File file: redundantFiles){
				archiveFile(file);	
			}
		}
	}
	
	private boolean validForFutureProcessing(File file, WorkflowStateDefinition workflowStateDefinition) {
		try{
			Long fileId = getFileId(file);
			List<PerfectionTask> perfectionTasks = perfectionTaskRepository.findByWorkItemRid(fileId);
			for(PerfectionTask task: perfectionTasks){
				if(workflowStateDefinition.getName().equals(task.getWorkflowStep()) && new DateTime(task.getWakeUpDate()).toLocalDate().isAfter(new LocalDate())){
					return true;
				}
			}
		}
		catch (Exception e){
			logger.error(e.getMessage());
		}
		return false;
	}


	
	/**
	 * Method to check whether the SFHDF file size > 10MB or not.  
	 * @param fileContents
	 * @return true if size <= 10 MB else false.
	 */
	private boolean isValidFileSize(byte[] fileContents) {
		long fileLength = (fileContents.length/SQUARE1024);
		if(fileLength > MAX_SFHDF_FILE_SIZE){			
			return false;
		}		
		return true;
	}	
	
	protected void setEmailReceiver(){
		arrPoEmailAddress = new String[] { env.getRequiredProperty("product.owner.team.email") };
		arrCtracEmailAddress = new String[] { env.getRequiredProperty("reconciliation.email.to") };
	}
	
	private EmailAttributeHolder populateEmail(String[] toAddresses, String[] ccAddress, String subject) {
		EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
		emailAttributeHolder.setSubject(messageSource.getMessage(subject, null, Locale.getDefault()));
		emailAttributeHolder.setFromAddress(env.getProperty(FROM_ADDRESS));
		emailAttributeHolder.setToAddresses(new HashSet<>(Arrays.asList(toAddresses)));
		emailAttributeHolder.setCcAddresses(new HashSet<>(Arrays.asList(ccAddress)));
		return emailAttributeHolder;
	}

}
