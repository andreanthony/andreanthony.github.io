package com.jpmorgan.cib.wlt.ctrac.service.bir.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.WorkflowMainDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BorrowerCancelItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.CancelWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.LookUpCodeService;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.bir.*;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AgentResponseData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.PIARequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.EntitlementUtil;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.*;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.STATES_CODES;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.*;

@Service
@Transactional(readOnly=true)
public class BorrowerInsuranceReviewServiceImpl implements BorrowerInsuranceReviewService {

	private static final Logger logger = LoggerFactory.getLogger(BorrowerInsuranceReviewServiceImpl.class);

	@Autowired private ActivePolicyService activePolicyService;

	@Autowired private AgentResponseItemRepository agentResponseItemRepository;

	@Autowired private BIRActionRequiredService birActionRequiredService;

	@Autowired private BIRManagementService birManagementService;

	@Autowired private BIRRuleConclusionService birRuleConclusionService;

	@Autowired private BorrowerPolicyStatusService borrowerPolicyStatusService;

	@Autowired private CalendarDayUtil calendarDayUtil;

	@Autowired private CollateralCoverageComputationService collateralCoverageComputationService;

	@Autowired private CollateralDocumentService collateralDocumentService;

	@Autowired private CollateralInsuranceRepository collateralInsuranceRepository;

	@Autowired private CollateralManagementService collateralManagementService;

	@Autowired private CtracObjectMapper ctracObjectMapper;

	@Autowired private InsuranceMngtService insuranceMngtService;

	@Autowired private LoanManagementService loanManagementService;

    @Autowired private LoanService loanService;

	@Autowired private LookUpCodeService lookUpCodeService;

	@Autowired private TMService tmService;

	@Autowired private PerfectionTaskRepository perfectionTaskRepository;

	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;

	@Autowired private ProofOfCovWorkItemRepository proofOfCovWorkItemRepository;

	@Autowired private TaskService taskService;

	@Autowired private CancelWorkflowService cancelWorkflowService;

	@Autowired private CollateralWorkflowService collateralWorkflowService;

	@Autowired private DateCalculator dateCalculator;

	@Autowired private CollateralRepository collateralRepository;

	@Autowired private BorrowerCancelItemRepository borrowerCancelItemRepository;

	@Autowired private LineOfBusinessService lobService;

	@Autowired private ReadyForLenderPlaceService readyForLPService;

	@Autowired private WorkflowDetailsService workflowDetailsService;

    @Autowired private PerfectionTaskService perfectionTaskService;

	@Override
	public BorrowerInsuranceReviewDTO prepareNewBIR(Long collateralRid) {
		return birManagementService.prepareNewBIRWithCollateralRid(collateralRid);
	}

	@Override
	public BorrowerInsuranceReviewDTO prepareExistingBIR(Long proofOfCoverageRid, Long collateralRid) {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData =
				birManagementService.getBorrowerInsuranceReviewData(proofOfCoverageRid, collateralRid);
		birRuleConclusionService.loadBIRFieldConclusions(borrowerInsuranceReviewData);
		borrowerInsuranceReviewData.setReadOnlyUserRole(!EntitlementUtil.hasAuthority(EntitlementRoles.WRITER_ROLE)? true:false );
		return borrowerInsuranceReviewData;
	}

	@Override
	public BorrowerInsuranceReviewDTO prepareExistingBIR(PerfectionTask perfectionTask) {
		if (perfectionTask == null) {
			return null;
		}
		WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);
		if (!(workItem instanceof AgentResponseItem)) {
			logger.error("Not an AgentResponseItem: " + perfectionTask.getTmTaskId());
			return null;
		}
		return prepareExistingBIR(((AgentResponseItem) workItem).getProofOfCoverageRid(), null);
	}

	@Override
	public BorrowerInsuranceReviewDTO prepareBIRByBIRMode(Long proofOfCoverageRid, Long collateralRid, BIRMode birMode) {
		BorrowerInsuranceReviewDTO sourceBIRData =
				birManagementService.getBorrowerInsuranceReviewData(proofOfCoverageRid, collateralRid);
		// TODO: ensure this policy doesn't already have a renewal
		BorrowerInsuranceReviewDTO targetBIRData = cloneBIR(sourceBIRData, birMode);
		// auto-populate JPM Lien Position conclusion if it should appear
		BorrowerInsuranceReviewRule.JPM_LIEN_POSITION_RULE.execute(targetBIRData);
		targetBIRData.setReadOnlyUserRole(!EntitlementUtil.hasAuthority(EntitlementRoles.WRITER_ROLE));
		return targetBIRData;
	}

	private BorrowerInsuranceReviewDTO cloneBIR(BorrowerInsuranceReviewDTO sourceBIRData, BIRMode birMode) {
		BorrowerInsuranceReviewDTO targetBIRData = birManagementService.prepareNewBIRWithCollateralRid(null);
		BIRCloningHelper.cloneBIRData(sourceBIRData, targetBIRData, birMode);

		ProofOfCoverageDTO sourceProofOfCoverageData = sourceBIRData.getProofOfCoverageData();
		List<CollateralInsuranceViewData> collateralInsuranceViewData =
				collateralInsuranceRepository.findByProofOfCoverageRid(sourceProofOfCoverageData.getRid());
		for (CollateralInsuranceViewData collateralInsuranceViewDatum : collateralInsuranceViewData) {
			addCollateralToBIR(collateralInsuranceViewDatum.getCollateral().getRid(), targetBIRData);
		}

		for (BIRCollateralDetailsDTO targetCollateralDetailsData : targetBIRData.getCollateralDetailsMap().values()) {
			BIRCollateralDetailsDTO sourceCollateralDetailsData =
					sourceBIRData.getCollateralDetailsMap().get(targetCollateralDetailsData.getCollateralRid());
			BIRCloningHelper.cloneBIRCollateralDetailsDTO(sourceCollateralDetailsData, targetCollateralDetailsData);
		}
		return targetBIRData;
	}

	@Override
	public BorrowerInsuranceReviewDTO prepareVerifyBIR(Long proofOfCoverageRid, Long collateralRid) {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = prepareExistingBIR(proofOfCoverageRid, collateralRid);
		setVerificationAttributes(borrowerInsuranceReviewData, collateralRid);
		return borrowerInsuranceReviewData;
	}

	private void setVerificationAttributes(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, Long launchedCollateralRid) {


		GenericProofOfCoverageDTO proofOfCoverageData = borrowerInsuranceReviewData.getProofOfCoverageData();
		proofOfCoverageData.saveACopy();

		for (BIRCollateralDetailsDTO collateralDetailsData : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
			boolean allowToVerify = PolicyStatus.PENDING_VERIFICATION == collateralDetailsData.getPolicyStatus();
			collateralDetailsData.setAllowToVerify(allowToVerify);
		}
		BIRCollateralDetailsDTO thisCollateralDetailsData =
				borrowerInsuranceReviewData.getCollateralDetailsMap().get(launchedCollateralRid);
		if (thisCollateralDetailsData.isAllowToVerify()) {
			thisCollateralDetailsData.setWantToVerify(true);
		}

		if(PolicyReasonForVerification.CANCELATION_DATE_ENTERED.name().equals(proofOfCoverageData.getReasonForVerification())){
			return;
		}

		if (activePolicyService.getPolicyStatus(proofOfCoverageData, null) == PolicyStatus.PENDING_VERIFICATION) {
			clearBlanketAmounts(borrowerInsuranceReviewData.getProofOfCoverageData());
		}
		for (BIRCollateralDetailsDTO collateralDetailsData : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
			Long collateralRid = collateralDetailsData.getCollateralRid();
			if (collateralDetailsData.isAllowToVerify()) {
				//if(StringUtils.isBlank(proofOfCoverageData.getCancellationEffectiveDate())){
					clearCollateralCoverageAmounts(proofOfCoverageData, collateralRid);
				//}
			}
		}
	}

	/**
	 * The renewal policy should not retain any amounts from the expiring policy.
	 * @param proofOfCoverageData
	 */
	private void clearBlanketAmounts(ProofOfCoverageDTO proofOfCoverageData) {
		BlanketCoverageDTO blanketCoverageData = proofOfCoverageData.getBlanketCoverageData();
		if (blanketCoverageData != null) {
			blanketCoverageData.saveACopy();
			blanketCoverageData.setBlanketBuildingAmount(null);
			blanketCoverageData.setBlanketContentAmount(null);
			blanketCoverageData.setBlanketCombinedAmount(null);
		}
	}

	private void clearCollateralCoverageAmounts(GenericProofOfCoverageDTO proofOfCoverageData, Long collateralRid) {
		Collection<ProvidedCoverageDTO> providedCoveragesDTOs =
				proofOfCoverageData.getProvidedCoverageMap().getAllCoverages(collateralRid, true, null);
		for (ProvidedCoverageDTO providedCoverageDTO : providedCoveragesDTOs) {
			providedCoverageDTO.saveACopy();
			providedCoverageDTO.setCoverageAmount(null);
		}
	}

	@Override
	public ReferenceValues getBorrowerInsuranceReviewReferenceValues(BIRMode birMode) {
		ReferenceValues referenceValues = new ReferenceValues();
		referenceValues.setInsuranceTypes(lookUpCodeService.findByCodeSetInSortOrder("INSURANCE_TYPES"));
    	referenceValues.setCoverageTypes(lookUpCodeService.findByCodeSetInSortOrder("COVERAGE_TYPES"));
    	referenceValues.setStates(lookUpCodeService.findByCodeSetInSortOrder(STATES_CODES));
    	referenceValues.setCtracReferenceDate(DateConverter.convert(calendarDayUtil.getCurrentReferenceDate()));
    	referenceValues.setBorrowerPolicyTypes(lookUpCodeService.findByCodeSetInSortOrder("POLICY_TYPES"));
    	referenceValues.setProofOfPaymentTypes(lookUpCodeService.findByCodeSetInSortOrder("BRW_INS_REVIEW_PROOF_OF_PAYMENT"));
    	referenceValues.setPropertyTypes(lookUpCodeService.findByCodeSetInSortOrder("BRW_INS_REVIEW_COVERAGE_TYPE"));
    	referenceValues.setJpmLienPositions(lookUpCodeService.findByCodeSetInSortOrder("BRW_INS_REVIEW_JPM_LIEN_POSITION"));
    	referenceValues.setBlanketCoverageTypes(lookUpCodeService.findByCodeSetInSortOrder("BLANKET_COVERAGE_TYPES"));
		List<LookUpCode> eoiTypes = lookUpCodeService.findByCodeSetInSortOrder("BRW_INS_REVIEW_EVIDENCE_OF_INSURANCE");
		//When in renewal mode - filter out the Binder AND Application from evidenceOfInsuranceTypes
		if(BIRMode.REPLACE == birMode){
			CollectionUtils.filter(eoiTypes,new Predicate() {
				@Override
				public boolean evaluate(Object code) {
					LookUpCode lookUpCode = (LookUpCode)code;
					return !(StringUtils.equals("AWP",lookUpCode.getCode()) || StringUtils.equals("BWP",lookUpCode.getCode()));
				}
			});
		}
		referenceValues.setEvidenceOfInsuranceTypes(eoiTypes);
		return referenceValues;
	}

	@Override
	public void addCollateralToBIR(Long collateralId, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		insuranceMngtService.addCollateralToPolicy(borrowerInsuranceReviewData.getProofOfCoverageData(), collateralId);
		birManagementService.addCollateralDetails(collateralId, borrowerInsuranceReviewData);
	}

	@Override
	public void removeCollateralFromBIR(Long collateralId, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		InsuranceCoverageMap<ProvidedCoverageDTO> providedCoverageMap =
				borrowerInsuranceReviewData.getProofOfCoverageData().getProvidedCoverageMap();
		if (providedCoverageMap != null) {
			providedCoverageMap.getInsurableAssetCoverageData().remove(collateralId);
		}
		borrowerInsuranceReviewData.getCollateralDetailsMap().remove(collateralId);
	}

	@Override
	public void reviewBorrowerInsurance(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, boolean isSubmitting) {
		BorrowerInsuranceReviewConclusion policyConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		boolean shouldTriggerRules = notMigratedAndAllPledged(borrowerInsuranceReviewData);
		if (shouldTriggerRules) {
			for (BorrowerInsuranceReviewRule birRule : BorrowerInsuranceReviewRule.values()) {
				birRule.execute(borrowerInsuranceReviewData);
			}
			if (!borrowerInsuranceReviewData.getProofOfCoverageData().getPolicyStatus().isActive(false)) {
				List<BIRRuleConclusionDTO> birRuleConclusions = borrowerInsuranceReviewData.getAllBIRRuleConclusions();
				for (BIRRuleConclusionDTO birRuleConclusion : birRuleConclusions) {
					if (BorrowerInsuranceReviewConclusion.REJECTED.name().equals(birRuleConclusion.getConclusion())) {
						policyConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
					}
				}
			}
		}
		borrowerInsuranceReviewData.setPolicyConclusion(policyConclusion);

		if (borrowerInsuranceReviewData.getBirMode() == BIRMode.VERIFY) {

			boolean isBlanket = false;
			if (borrowerInsuranceReviewData.getProofOfCoverageData().getBlanketCoverageData() != null) {
				String blanketType = borrowerInsuranceReviewData.getProofOfCoverageData().getBlanketCoverageData().getBlanketCoverageType();
				isBlanket = StringUtils.isNotBlank(blanketType) && !"IND".equals(blanketType);
			}

			for (BIRCollateralDetailsDTO collateralDetailsData : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
				if (collateralDetailsData.isWantToVerify()) {
					if (isSubmitting || isBlanket) {
						collateralDetailsData.setShowMismatchAmounts(false);
					} else {
						Collection<ProvidedCoverageDTO> providedCoverages =
								borrowerInsuranceReviewData.getProofOfCoverageData().getProvidedCoverageMap().getAllCoverages(
										collateralDetailsData.getCollateralRid(), true, null);
						collateralDetailsData.setShowMismatchAmounts(anyCoverageAmountsMismatch(providedCoverages));
					}
				} else {
				    //prevent saving $0 amounts for collateral which are not being verified
					if(isSubmitting){
						Collection<ProvidedCoverageDTO> providedCoverages =
								borrowerInsuranceReviewData.getProofOfCoverageData().getProvidedCoverageMap().getAllCoverages(
										collateralDetailsData.getCollateralRid(), true, null);
						for (ProvidedCoverageDTO providedCoverageDTO : providedCoverages) {
							AmountMismatchUtil.setLoadTimeValueAmount(providedCoverageDTO);
						}
					}
				}
			}
		}
		borrowerInsuranceReviewData.setDisableSubmit(false);
		popPolicyAttachments(borrowerInsuranceReviewData.getProofOfCoverageData(), borrowerInsuranceReviewData.getCollateralRid());
	}

	private boolean anyCoverageAmountsMismatch(Collection<ProvidedCoverageDTO> providedCoverages) {
		boolean isFound = false;
		for (ProvidedCoverageDTO providedCoverage : providedCoverages) {
			if (AmountMismatchUtil.amountsMismatch(providedCoverage)) {
				AmountMismatchUtil.setMismatch(providedCoverage);
				isFound = true;
			} else {
				AmountMismatchUtil.setMatch(providedCoverage);
			}
		}
		return isFound;
	}

	@Override
	@Transactional(readOnly=false)
	public void submitBorrowerInsuranceReview(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		reviewBorrowerInsurance(borrowerInsuranceReviewData, true);
		deletePolicyAttachments(borrowerInsuranceReviewData);
		birManagementService.saveBorrowerInsuranceReview(borrowerInsuranceReviewData);
		boolean exceptionChangedIndicator = birRuleConclusionService.saveBIRFieldConclusions(borrowerInsuranceReviewData);
		performBorrowerPolicyStatusActions(borrowerInsuranceReviewData);
		closeLogPIAReviewTask(borrowerInsuranceReviewData);
		if(exceptionChangedIndicator) {
			closeExceptionContactTask(borrowerInsuranceReviewData);
		}
		savePolicyAttachments(borrowerInsuranceReviewData);
		resetVerificationAttributes(borrowerInsuranceReviewData);
	}

	private void resetVerificationAttributes(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		if (borrowerInsuranceReviewData.getBirMode() == BIRMode.VERIFY) {
			for (BIRCollateralDetailsDTO collateralDetailsData : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
				if (collateralDetailsData.isAllowToVerify() && !collateralDetailsData.isWantToVerify()) {
					clearCollateralCoverageAmounts(borrowerInsuranceReviewData.getProofOfCoverageData(), collateralDetailsData.getCollateralRid());
				}
			}
		}
	}

	@Override
	public PIARequestData preparePIARequestData(TMParams tmParams) {
		logger.debug("preparePIARequestData::begin");
		String taskId = tmParams.getId_task();
		PIARequestData pIARequestData = new PIARequestData();
		pIARequestData.setTmParams(tmParams);
		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(taskId);
		AgentResponseItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), AgentResponseItem.class);

		//1.grab policy information
		ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(workItem.getProofOfCoverageRid());
		ProofOfCoverageDTO proofOfCoverageDto = ctracObjectMapper.map(proofOfCoverage, ProofOfCoverageDTO.class);

		pIARequestData.setProofOfCoverageDto(proofOfCoverageDto);
		//2.grab all related collateral info with this proof of coverage
		List<CollateralDto> collateralDtos = collateralManagementService.getCollateralDtosByProofOfCoverage(proofOfCoverageDto);
		pIARequestData.setCollateralDtoList(collateralDtos);

		//3.grab all related loan borrower with this collateral
        setLOBDesription(collateralDtos);
		pIARequestData.setLoanDtoList(loanManagementService.getPrimaryLoans(collateralDtos));
		pIARequestData.setAgentResponseId(workItem.getRid());
		pIARequestData.setTmTaskRererenceId(workItem.getTmTaskRererenceId());
		pIARequestData.setPolicyExpiryDate(proofOfCoverageDto.getExpirationDate());
		logger.debug("preparePIARequestData::end");
		return pIARequestData;
	}

	private void setLOBDesription(List<CollateralDto> collateralDtos) {
		Iterator<CollateralDto> collateralIter = collateralDtos.iterator();
		while (collateralIter.hasNext()) {
			CollateralDto collateralDto = collateralIter.next();
			Iterator<LoanData> iter = collateralDto.getLoansData().iterator();
			while (iter.hasNext()) {
				LoanData loanData = iter.next();
                LineOfBusinessDTO lob = null;
                if (loanData.getLineOfBusiness() != null) {
                    lob = lobService.findByCode(loanData.getLineOfBusiness());
				}
                if (lob != null) {
                    loanData.setLobDescription(lob.getDescription());
                }
			}
		}
	}

	@Override
	@Transactional
	public void processPIARequestData(final PIARequestData pIARequestData) {
		logger.debug("processPIARequestData::begin");
		String tmTaskId = pIARequestData.getTmParams().getId_task();
		final PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmTaskId);
		AgentResponseItem agentResponseItem = agentResponseItemRepository.findOne(pIARequestData.getAgentResponseId());
		if (perfectionTask == null || agentResponseItem == null) {
			throw new RuntimeException("No PerfectionTask/AgentResponseItem found for TM Task ID: " + tmTaskId);
		}
		agentResponseItem.setTmTaskRererenceId(pIARequestData.getTmTaskRererenceId());
		final AgentResponseItem savedAgentResponseItem = agentResponseItemRepository.saveAndFlush(agentResponseItem);
		final TMParams tmParams = pIARequestData.getTmParams();
		Map<StateParameterType, Object> worflowData = new HashMap<StateParameterType, Object>() {
			private static final long serialVersionUID = 1L;
		{
			put(StateParameterType.HELPER_DATA, pIARequestData);
			put(StateParameterType.PERFECTION_TASK, perfectionTask);
			put(StateParameterType.WORK_ITEM, savedAgentResponseItem);
			put(StateParameterType.TM_PARAMS, tmParams);
		}};
		taskService.completeWorkFlowStepOperations(worflowData);
		// insert action requried in BIR FIeld Conlusion table for the Exception
		birRuleConclusionService.createOrUpdateException(agentResponseItem.getProofOfCoverageRid(), null,
				BorrowerInsuranceReviewRule.PIA_ASSESSMENT_EXCEPTIONS_RULE, BorrowerInsuranceReviewConclusion.ACTION_REQUIRED);
		birRuleConclusionService.createOrUpdateException(agentResponseItem.getProofOfCoverageRid(), null,
				BorrowerInsuranceReviewRule.EVIDENCE_OF_INSURANCE_RULE, BorrowerInsuranceReviewConclusion.ACCEPTABLE);
		logger.debug("processPIARequestData::end");
	}

	@Override
	public AgentResponseData getAgentResponse(TMParams tmParams) {
		logger.debug("getAgentResponseData::begin");
		String taskId = tmParams.getId_task();

		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(taskId);
		AgentResponseItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), AgentResponseItem.class);
		AgentResponseData agentResponseData  = ctracObjectMapper.map(workItem, AgentResponseData.class);
		List<CollateralInsuranceViewData> collateralsProofOfCoverage =
				collateralInsuranceRepository.findByProofOfCoverageRid(agentResponseData.getProofOfCoverageRid());
		agentResponseData.setCollateralRid(collateralsProofOfCoverage.get(0).getCollateral().getRid());

		logger.debug("getAgentResponseData::end");
		return agentResponseData;
	}

	void performBorrowerPolicyStatusActions(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRMode birMode = borrowerInsuranceReviewData.getBirMode();
		borrowerInsuranceReviewData.setDisableSubmit(true);
		if (birMode == BIRMode.NEW || birMode == BIRMode.RENEWAL || birMode == BIRMode.REPLACE) {
			borrowerPolicyStatusService.initialize(borrowerInsuranceReviewData);
		} else if (birMode == BIRMode.EDIT) {
			borrowerPolicyStatusService.edit(borrowerInsuranceReviewData);
		} else if (birMode == BIRMode.VERIFY) {
			boolean notMigratedAndAllPledged = notMigratedAndAllPledged(borrowerInsuranceReviewData);
			borrowerPolicyStatusService.verify(borrowerInsuranceReviewData);
			if (areAllVerified(borrowerInsuranceReviewData)) {
				// all collateral links are verified
				triggerPolicyVerifiedActions(borrowerInsuranceReviewData, notMigratedAndAllPledged);
			}
		}
	}

	protected void triggerPolicyVerifiedActions(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			boolean notMigratedAndAllPledged) {
		ProofOfCoverageDTO proofOfCoverageData = borrowerInsuranceReviewData.getProofOfCoverageData();
		if(proofOfCoverageData.hasCancellationDate()) {
			// policy was just cancelled
			triggerRequestFiatForCancelledPolicy(borrowerInsuranceReviewData);
		} else if(notMigratedAndAllPledged) {
			// policy is not migrated and all collateral being covered are pledged
			if (!borrowerInsuranceReviewData.requiresRejectionEmails()) {
				// policy was accepted
				triggerPolicyAcceptedActions(borrowerInsuranceReviewData);
			} else {
				// policy was rejected
				birActionRequiredService.triggerRejectionExceptionEmails(borrowerInsuranceReviewData);
			}
		}
		// doesn't do anything if policy is migrated or if it's covering any draft collateral

		if (proofOfCoverageData.getPendingLpAction() == LPActions.NEW_BP) {
			proofOfCoverageData.setPendingLpAction(null);
		}
		insuranceMngtService.saveProofOfCoverage(proofOfCoverageData);
	}

	void triggerPolicyAcceptedActions(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		ProofOfCoverageDTO proofOfCoverageData = borrowerInsuranceReviewData.getProofOfCoverageData();
        ProofOfCoverage parentPolicy = getRenewalParentPolicy(proofOfCoverageData.getParentPolicyRid());
        triggerCancellingWorkflows(borrowerInsuranceReviewData, parentPolicy);
        boolean isRenewalBeforeExpiration = isRenewalBeforeExpiration(parentPolicy);

        if(proofOfCoverageData.getPendingLpAction() == LPActions.NEW_BP){
            if(parentPolicy != null && !isRenewalBeforeExpiration && PolicyStatus.EXPIRING_EA == parentPolicy.getPolicyStatus_()){
                activePolicyService.setAllPolicyStatuses(parentPolicy, PolicyStatus.EXPIRED);
			} else {
				// check for outstanding FIAT Requests
				if (!insuranceMngtService.hasOutstandingCoverageRequest(proofOfCoverageData.getRid())) {
					for (BIRCollateralDetailsDTO collateralDetailsData : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
						triggerC3ForBIR(collateralDetailsData.getCollateralRid(), null);
					}
				} else if (!isRenewalBeforeExpiration) {
					// there's an outstanding FIAT request, trigger C3 at a later date
					proofOfCoverageData.setPendingLpAction(LPActions.PENDING_C3);
				}

				if(isRenewalBeforeExpiration) {
					readyForLPService.updateForPolicyCancelled(proofOfCoverageData.getParentPolicyRid());
				}
			}
        }
        collateralWorkflowService.removeCoverageRequestToWorkItemLinks(
                proofOfCoverageData, borrowerInsuranceReviewData.getCollateralRid());

        triggerActionRequiredWorkflows(borrowerInsuranceReviewData);
	}

	private boolean isValidReplacementPolicy(ProofOfCoverageDTO childPolicy, ProofOfCoverageDTO parentPolicy){
		return parentPolicy != null && parentPolicy.isPolicyReplaceable() &&
				!childPolicy.getEffectiveDate_().after(parentPolicy.getEffectiveDate_()) &&
				!childPolicy.getExpirationDate_().before(parentPolicy.getExpirationDate_());
	}

	boolean isRenewalBeforeExpiration(ProofOfCoverage parentPolicy) {
		if (parentPolicy == null) {
			return false;
		}
		DateTime currentReferenceDate = new DateTime(calendarDayUtil.getCurrentReferenceDate()).withTimeAtStartOfDay();
		DateTime expirationDate = new DateTime(parentPolicy.getExpirationDate()).withTimeAtStartOfDay();
		return !parentPolicy.getPolicyType_().isApplicationOrBinder() &&
		parentPolicy.getPolicyStatus_().isActive(false) && currentReferenceDate.isBefore(expirationDate);
	}

    ProofOfCoverage getRenewalParentPolicy(Long parentPolicyRid) {
        if (parentPolicyRid != null) {
            return proofOfCoverageRepository.findOne(parentPolicyRid);
        }
        return null;
    }

    private void triggerRequestFiatForCancelledPolicy(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		/**
		 * TODO: Somewhere in this method we need to close active workflows for this cancelled borrower policy
		 *       e.g. Exception email workflow
		 */
		long lastCollateralRid = 0L;
		HashSet<Collateral> collaterals = new HashSet<Collateral>();
		for (BIRCollateralDetailsDTO collateralDetailsData : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
			Collateral collateral = CtracBaseEntity.deproxy(collateralRepository.findOne(collateralDetailsData.getCollateralRid()), Collateral.class);
			lastCollateralRid = collateral.getRid();
			try {
				// making a list of all pledged collaterals
				if(CollateralStatus.PLEDGED == CollateralStatus.valueOf(collateral.getCollateralStatus())){
					collaterals.add(collateral);
				}
			} catch (Exception e) {
				logger.debug("Invalid Collateral RID or invalid status: " + collateralDetailsData.getCollateralRid(), e);
			}

		}
		collateralWorkflowService.removeCollateralsUnqualifiedForWorkfow(collaterals);

		Date wakeupDate = dateCalculator.addCalendarDays(30, borrowerInsuranceReviewData.getProofOfCoverageData().getCancellationEffectiveDate_(), false);

		BorrowerCancelItem borrowerCancelItem = new BorrowerCancelItem();
		borrowerCancelItemRepository.save(borrowerCancelItem);

		//skip FIAT request for externally agented loan types
		if (!loanService.hasExternallyAgented(lastCollateralRid)) {
			for (Collateral collateral : collaterals) {
				collateralWorkflowService.initRequiredCoverageRequestWorkFlow(borrowerCancelItem,
						collateral.getRid(), PerfectionItemSubType.BORROWER_CANCEL, TMTaskType.FLOOD_INSURANCE, wakeupDate);
			}
		}
	}

	/**
	 * Trigger the cancelling workFlows of the parent - When new policy has been verified and the policy is a renewal or replacement
	 * The function will call first to validate if the renewal or replacement is Valid - IF Not it will not cancel the parent policy workflow
     * @param borrowerInsuranceReviewData
     * @param parentPolicy
     */
	void triggerCancellingWorkflows(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, ProofOfCoverage parentPolicy) {
        ProofOfCoverageDTO proofOfCoverageData = borrowerInsuranceReviewData.getProofOfCoverageData();
		if(!isValidRenewalOrReplacementPolicy(borrowerInsuranceReviewData)){
            if(parentPolicy != null) {
                // this is a renewal policy - stop calling the agent
                cancelWorkflowService.cancelRenewalOrReplacementWorkflow(proofOfCoverageData.getParentPolicyRid());
            }
			proofOfCoverageData.setParentPolicyRid(null);
			return;
		}
		//1. cancel renewal / replacement workflow for this policy
		cancelWorkflowService.cancelRenewalOrReplacementWorkflow(proofOfCoverageData.getParentPolicyRid());

		//2. cancel fiat workflows for each collateral if needed
	    Map<Long, BIRCollateralDetailsDTO> newPolicyCollaterals = borrowerInsuranceReviewData.getCollateralDetailsMap();
		for(Long collateralRid: newPolicyCollaterals.keySet()){
			cancelWorkflowService.cancelRequestingCoverageWorkflow(collateralRid,proofOfCoverageData.getParentPolicyRid());
		}

		//3. For replacement - set the status of the replaced policy to  REPLACED
		ProofOfCoverageDTO oldPolicy = insuranceMngtService.mapProofsOfCoverage(parentPolicy,
				borrowerInsuranceReviewData.getCollateralRid());
		if(oldPolicy.isPolicyReplaceable()){
			//if replacement is valid - set all the
			// included collateral details status for that policy to Replaced
			activePolicyService.setAllPolicyStatuses(parentPolicy, PolicyStatus.REPLACED);
		}
	}

	/**
	 *  Validate that the BIR Form if it corresponds to a Renewal or Replacement(for binders/application)
	 *	1. the new policy must be a renewal of the expiring borrower policy OR a replacement of the binder / application
	 *	2. the coverage amounts on the new policy must be equal to or greater than the coverage amounts of the expiring policy
	 *	3. there must be no gap in the dates for a renewal
	 *	4. new policy has to overlap the effective date and expiration date of the old policy to be a valid replacement
	 * @param borrowerInsuranceReviewData
	 * @return
	 */
	boolean isValidRenewalOrReplacementPolicy(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		//the new policy must be a renewal of the expiring borrower policy OR a replacement of the binder / application
		if(borrowerInsuranceReviewData == null || borrowerInsuranceReviewData.getProofOfCoverageData() == null || borrowerInsuranceReviewData.getProofOfCoverageData().getParentPolicyRid() == null){
			return false;
		}
		ProofOfCoverageDTO newPolicy = borrowerInsuranceReviewData.getProofOfCoverageData();
		ProofOfCoverageDTO oldPolicy = insuranceMngtService.getProofOfCoverageData(newPolicy.getParentPolicyRid(), borrowerInsuranceReviewData.getCollateralRid());

		boolean isReplacementPolicy = oldPolicy.getPolicyType().isApplicationOrBinder();
		// there must be no gap in the dates when the policy is not a replacement
		if(!isReplacementPolicy && newPolicy.getEffectiveDate_().after(oldPolicy.getExpirationDate_())){
			return false;
		}
		// new policy has to overlap the effective date and expiration date of the old policy to be a valid replacement
		if(isReplacementPolicy && !isValidReplacementPolicy(newPolicy, oldPolicy)){
			return false;
		}
		//Coverage type needs to match
		if(newPolicy.getCoverageType() != oldPolicy.getCoverageType()){
			return false;
		}
		//if coverage type is excess then new policy's deductiable should be equal or less than the exisiting policy's deductible
		if(CoverageType.EXCESS == newPolicy.getCoverageType()){
			BigDecimal newBuildingDeductible = AmountFormatter.parse(newPolicy.getBuildingDeductible());
			BigDecimal newContentsDeductible = AmountFormatter.parse(newPolicy.getContentsDeductible());
			BigDecimal oldBuildingDeductible = AmountFormatter.parse(oldPolicy.getBuildingDeductible());
			BigDecimal oldContentsDeductible = AmountFormatter.parse(oldPolicy.getContentsDeductible());
			if(newBuildingDeductible.compareTo(oldBuildingDeductible) > 0 || newContentsDeductible.compareTo(oldContentsDeductible) > 0){
				return false;
			}
		}
		//the coverage amounts on the new policy must be equal to or greater than the coverage amounts of the expiring policy
	    Map<Long, ProvidedCoverageDTO> oldProvidedCoverageMap = oldPolicy.getInsurableAssetProvidedCoverageMap();
	    Map<Long, ProvidedCoverageDTO> newProvidedCoverageMap = newPolicy.getInsurableAssetProvidedCoverageMap();
		for(Map.Entry<Long, ProvidedCoverageDTO> oldProvidedCoverageMapEntry: oldProvidedCoverageMap.entrySet()){
			ProvidedCoverageDTO newProvidedCoverageDTO = newProvidedCoverageMap.get(oldProvidedCoverageMapEntry.getKey());
			if(newProvidedCoverageDTO == null){
				return false;
			}
			BigDecimal newCoverageAmount = AmountFormatter.parse(newProvidedCoverageDTO.getCoverageAmount());
			BigDecimal oldCoverageAmount = AmountFormatter.parse(oldProvidedCoverageMapEntry.getValue().getCoverageAmount());
			if(newCoverageAmount.compareTo(oldCoverageAmount) < 0){
				return false;
			}
		}
		return true;
	}

	/**
	 * C3 is run as a part of borrowerPolicyStatusService
	 *
	 * In the future, We might need to make the call to evaluate the
	 * coverage as part of the review and only make the call to apply
	 * during the saving of the BIR verification. We might also need a
	 * workItem (trigger workItem ) if type BIRITEM so that c3 nows how
	 * to differentiate calls from various workflows..
	 * @param collateralRid
	 * @param triggerWorkItem
	 */
	private void triggerC3ForBIR(Long collateralRid, WorkItem triggerWorkItem) {
		Long triggerWorkItemId = triggerWorkItem != null ? triggerWorkItem.getRid() : null;
		CoverageActionRequest coverageActionRequest = new CoverageActionRequest(collateralRid, triggerWorkItemId, null);
		CoverageActionResult coverageActionResult =
				collateralCoverageComputationService.evaluateInsuranceCoverageActions(coverageActionRequest);
		collateralCoverageComputationService.applyInsuranceCoverageActions(coverageActionResult, triggerWorkItem);
	}

	private boolean notMigratedAndAllPledged(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		Boolean migrated = borrowerInsuranceReviewData.getProofOfCoverageData().getMigrated();
		return migrated != null && !migrated.booleanValue() && areAllCollateralPledged(borrowerInsuranceReviewData);
	}

	private boolean areAllCollateralPledged(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		for (Long collateralRid : borrowerInsuranceReviewData.getCollateralDetailsMap().keySet()) {
			CollateralStatus collateralStatus = collateralManagementService.getCollateralStatus(collateralRid);
			if (collateralStatus == null || collateralStatus != CollateralStatus.PLEDGED) {
				return false;
			}
		}
		return true;
	}

	private boolean areAllVerified(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		ProofOfCoverageDTO proofOfCoverageDTO = borrowerInsuranceReviewData.getProofOfCoverageData();
		PolicyStatus overallPolicyStatus = activePolicyService.getPolicyStatus(proofOfCoverageDTO, null);
		if (overallPolicyStatus == PolicyStatus.PENDING_VERIFICATION) {
			return false;
		}
		for (Long collateralRid : borrowerInsuranceReviewData.getCollateralDetailsMap().keySet()) {
			PolicyStatus collateralPolicyStatus = activePolicyService.getPolicyStatus(proofOfCoverageDTO, collateralRid);
			if (collateralPolicyStatus == PolicyStatus.PENDING_VERIFICATION) {
				return false;
			}
		}
		return true;
	}

	void triggerActionRequiredWorkflows(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		// first, reload conclusions in case something changed, specifically inside C3
		birRuleConclusionService.loadBIRFieldConclusions(borrowerInsuranceReviewData);

		boolean policyAcceptedWithNoException = true;
		if (borrowerInsuranceReviewData.requiresPIAWorkflow()) {
			birActionRequiredService.triggerPIAWorkflow(borrowerInsuranceReviewData);
		}
		if (borrowerInsuranceReviewData.requiresInsuranceExceptionEmails()) {
			birActionRequiredService.triggerInsuranceExceptionEmailWorkflow(borrowerInsuranceReviewData);
			policyAcceptedWithNoException=false;
		}

		for (BIRCollateralDetailsDTO collateralDetailsData : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
			if (collateralDetailsData.requiresZoneVarianceEmails()) {
				birActionRequiredService.triggerZoneVarianceWorkflow(borrowerInsuranceReviewData, collateralDetailsData.getCollateralRid());
				policyAcceptedWithNoException=false;
			}
		}

		if(policyAcceptedWithNoException){
			birActionRequiredService.triggerPolicyAcceptedWithNoExceptionEmails(borrowerInsuranceReviewData);
		}
	}

	void closeLogPIAReviewTask(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		String piaAssessmentExceptions = borrowerInsuranceReviewData.getProofOfCoverageData().getPiaAssessmentExceptions();
		//close Log PIA review task if the value is set
		if (StringUtils.isNotBlank(piaAssessmentExceptions)) {
			// TODO: test passing null for collateral rid
			AgentResponseItem agentResponseItem = agentResponseItemRepository.findByProofOfCoverageRidAndCollateralRid(
					borrowerInsuranceReviewData.getProofOfCoverageData().getRid(), null);

			List<String> taskStatuses = new ArrayList<String>();
			taskStatuses.add(TaskStatus.OPEN.name());
			taskStatuses.add(TaskStatus.SLEEPING.name());
			List<PerfectionTask> perfectionTasksToClose = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatusIn(
					agentResponseItem, LOG_PIA_REVIEW.getName(), taskStatuses);
			if(!CollectionUtils.isEmpty(perfectionTasksToClose)){
				for (PerfectionTask perfectionTask : perfectionTasksToClose) {
					if (TaskStatus.SLEEPING.name().equals(perfectionTask.getTaskStatus())) {
                        perfectionTaskService.closeTask(perfectionTask,true);
					} else {
						try {
							tmService.cancelTask(perfectionTask.getTmTaskId());
							tmService.cancelTmTask(perfectionTask);

						} catch (TMServiceApplicationException ex ) {
							throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
						}
						catch (Exception ex){
							logger.error(ex.getMessage(), ex);

						}
					}
				}
			}
			if ("yes".equalsIgnoreCase(piaAssessmentExceptions)) {
				perfectionTaskService.createTask(
						TaskStatus.TRANSIENT, agentResponseItem, WorkflowStateDefinition.SEND_PIA_LETTER.getFloodRemapTaskState(),
						TMTaskType.FLOOD_INSURANCE, null, null);

			}
		}
	}

	private void closeExceptionContactTask(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		Long proofOfCoverageRid = borrowerInsuranceReviewData.getProofOfCoverageData().getRid();
		boolean hasActionRequired = birRuleConclusionService.hasException(proofOfCoverageRid);
		if (!hasActionRequired) {
			try {
				List<String> workflowSteps = Arrays.asList(POLICY_EXCEPTION_1ST_CONTACT.getName(),
						POLICY_EXCEPTION_2ND_CONTACT.getName(),
						POLICY_EXCEPTION_3RD_CONTACT.getName(),
						POLICY_EXCEPTION_FINAL_CONTACT.getName());
				List<String> taskStatuses = Collections.singletonList(TaskStatus.TRANSIENT.name());
				List<ProofOfCovWorkItem> listProofOfCovWorkItem = proofOfCovWorkItemRepository.findByProofOfCoverageRidAndItemType(proofOfCoverageRid,
						ProofOfCoverageWorkItemRelationType.AGENT_RESPONSE_TO_POLICY.getName());
				for (ProofOfCovWorkItem proofOfCovWorkItem : listProofOfCovWorkItem) {
					List<PerfectionTask> perfectionTaskList = perfectionTaskService.findTasksForWorkItem(
							proofOfCovWorkItem.getWorkItem(), workflowSteps, taskStatuses);
					for (PerfectionTask perfectionTask : perfectionTaskList) {
						tmService.cancelTask(perfectionTask);
					}
				}
			} catch (Exception e) {
				logger.error("{} Unable to close Exception contact task for proofOfCoverageRid: {}",
						CtracAppConstants.ERR_SEVERITY_APPLICATION_MESSAGE, proofOfCoverageRid, e);
			}
		}
	}

   private void popPolicyAttachments(ProofOfCoverageDTO proofOfCoverageData, Long collateralRid){
		String key = proofOfCoverageData.getRid() != null ?
				proofOfCoverageData.getRid().toString() : "NEW_POLICY_" + collateralRid.toString();
		List<MultipartFile> policyAttachments = collateralDocumentService.fetchAttachedDocuments(key);
		if (policyAttachments != null && !policyAttachments.isEmpty()) {
			proofOfCoverageData.getPolicyDocuments().addAll(collateralDocumentService.getCollateralDocument(
					policyAttachments, null, null, new Date(), CtracAppConstants.POLICY_DOCUMENT_IDENTIFIER));
		}
   }

	private void savePolicyAttachments(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData){
		ProofOfCoverageDTO proofOfCoverageData = borrowerInsuranceReviewData.getProofOfCoverageData();
		if (borrowerInsuranceReviewData.getBirMode() != BIRMode.VERIFY || borrowerInsuranceReviewData.hasCancellationDate()) {
			for (CollateralDocument collateralDocument : proofOfCoverageData.getPolicyDocuments()) {
				collateralDocument.setProofOfCoverageRid(proofOfCoverageData.getRid());
			}
			collateralDocumentService.saveCollateralDocuments(proofOfCoverageData.getPolicyDocuments());
		} else {
			collateralDocumentService.removeCollateralDocuments(proofOfCoverageData.getPolicyDocuments());
			borrowerInsuranceReviewData.getProofOfCoverageData().getPolicyDocuments().clear();
		}
	}

	private void deletePolicyAttachments(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData){
		if (borrowerInsuranceReviewData.getBirMode() != BIRMode.VERIFY || borrowerInsuranceReviewData.hasCancellationDate()) {
			return;
		}
		if (birManagementService.isAllCollateralsVerified(
				borrowerInsuranceReviewData.getRid(), borrowerInsuranceReviewData.getCollateralRid())) {
			borrowerInsuranceReviewData.getProofOfCoverageData().getPolicyDocuments().clear();
		}
	}

	@Override
	@Transactional
	public void deleteBorrowerInsuranceReview(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		if (borrowerInsuranceReviewData != null) {
			birManagementService.deleteBorrowerInsuranceReview(borrowerInsuranceReviewData);
			if (borrowerInsuranceReviewData.getProofOfCoverageData() != null &&
					borrowerInsuranceReviewData.getProofOfCoverageData().getRid() != null) {
				try {
					Long proofOfCoverageRid = borrowerInsuranceReviewData.getProofOfCoverageData().getRid();
					proofOfCoverageRepository.delete(proofOfCoverageRid);
					proofOfCoverageRepository.flush();
					birManagementService.performBIProofOfCoveragePublishEvent(borrowerInsuranceReviewData, CollateralEventType.DELETED, false);
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}

	@Override
	public LoanData getPrimaryLoanOfBorrowerInsurance(Long collateralRid) {
		return collateralManagementService.getCollateralDto(collateralRid).getPrimaryLoan();
	}

	@Override
	public boolean validateBorrowerInsurancePolicyDeletion(Long policyRid, Long collateralRid, boolean isDeleteButtonVisible ) {
		List<WorkflowMainDetailsViewData> workflowMainDetailsViewDataList = workflowDetailsService.
				getWorkflowMainDetailsViewData(collateralRid, policyRid);
		for (WorkflowMainDetailsViewData workflowData : workflowMainDetailsViewDataList) {
			if (!TaskStatus.CLOSED.name().equals(workflowData.getTaskStatus()) && isDeleteButtonVisible) {
				return false;
			}
		}
		return true;
	}
}
