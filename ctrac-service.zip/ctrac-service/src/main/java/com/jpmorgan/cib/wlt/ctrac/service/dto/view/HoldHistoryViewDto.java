package com.jpmorgan.cib.wlt.ctrac.service.dto.view;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import org.apache.commons.lang.StringUtils;

public class HoldHistoryViewDto {

    private Long collateralRid;
    private String buildingName;
    private String insurableAssetType;
    private String coverageType;
    private Long parentHoldRid;
    private String holdType;
    private String startDate;
    private String holdPeriod;
    private String lpiDate;
    private String holdStatus;
    private String verifiedBy;
    private String verifiedDate;


    public Long getCollateralRid() {
        return collateralRid;
    }

    public HoldHistoryViewDto setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
        return this;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public HoldHistoryViewDto setBuildingName(String buildingName) {
        this.buildingName = buildingName;
        return this;
    }

    public String getInsurableAssetType() {
        return insurableAssetType;
    }

    public HoldHistoryViewDto setInsurableAssetType(String insurableAssetType) {
        this.insurableAssetType = (StringUtils.isNotEmpty(insurableAssetType) &&
                InsurableAssetType.findByName(insurableAssetType) != null) ?
                InsurableAssetType.findByName(insurableAssetType).getDisplayName()
                :insurableAssetType;
        return this;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public HoldHistoryViewDto setCoverageType(String coverageType) {
        this.coverageType = coverageType;
        return this;
    }

    public Long getParentHoldRid() {
        return parentHoldRid;
    }

    public HoldHistoryViewDto setParentHoldRid(Long parentHoldRid) {
        this.parentHoldRid = parentHoldRid;
        return this;
    }

    public String getHoldType() {
        return holdType;
    }

    public HoldHistoryViewDto setHoldType(String holdType) {
        this.holdType = holdType;
        return this;
    }

    public String getStartDate() {
        return startDate;
    }

    public HoldHistoryViewDto setStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    public String getHoldPeriod() {
        return holdPeriod;
    }

    public HoldHistoryViewDto setHoldPeriod(String holdPeriod) {
        this.holdPeriod = holdPeriod;
        return this;
    }

    public String getLpiDate() {
        return lpiDate;
    }

    public HoldHistoryViewDto setLpiDate(String lpiDate) {
        this.lpiDate = lpiDate;
        return this;
    }

    public String getHoldStatus() {
        return holdStatus;
    }

    public HoldHistoryViewDto setHoldStatus(String holdStatus) {
        this.holdStatus = holdStatus;
        return this;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public HoldHistoryViewDto setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
        return this;
    }

    public String getVerifiedDate() {
        return verifiedDate;
    }

    public HoldHistoryViewDto setVerifiedDate(String verifiedDate) {
        this.verifiedDate = verifiedDate;
        return this;
    }
}
