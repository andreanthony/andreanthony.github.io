package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;


import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.InsurableAssetService;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

public class InsuranceCoverageMap<T extends BaseCoverageDataDTO> implements Serializable {

    private static final long serialVersionUID = 8288718953839901271L;

    private static final Logger logger = Logger.getLogger(InsuranceCoverageMap.class);

    public InsuranceCoverageMap(Class<T> coverageDataClass) {
        this.coverageDataClass = coverageDataClass;
    }

    private Class<T> coverageDataClass;

    /**
     * Collection of InsurableAssetCoverageData mapped by ProofOfCoverage RID. Contains building
     * and contents coverage information for the InsurableAssets covered by a given policy.
     */
    //TODO &FIXME rename; this is more like a collateralCoverageDataMap
    private TreeMap<Long, TreeMap<Integer, InsurableAssetCoverageData<T>>> insurableAssetCoverageData =
            new TreeMap<Long, TreeMap<Integer, InsurableAssetCoverageData<T>>>();

    public TreeMap<Long, TreeMap<Integer, InsurableAssetCoverageData<T>>> getInsurableAssetCoverageData() {
        return insurableAssetCoverageData;
    }

    public void setInsurableAssetCoverageData(
            TreeMap<Long, TreeMap<Integer, InsurableAssetCoverageData<T>>> insurableAssetCoverageData) {
        this.insurableAssetCoverageData = insurableAssetCoverageData;
    }

    /**
     * ProofOfCoverageDTO and InsurableAssetDTO must be set in ProvidedCoverageDTO//Required
     *
     * @param coverageData
     */
    public void put(T coverageData) {

        if (coverageData.getSortOrder() == null) {
            /*
             * TODO review, Let the map manage the assignment of new sort order from the data
             * already in the map if SortOrder is null, assign a new suitable one
             */
            logger.debug("Sort order not defined for the coverageData data: assuming a new insurable asset must be created");
        }

        Integer insurableAssetSortOrder = coverageData.getSortOrder();
        InsurableAssetDTO insurableAssetData = coverageData.getInsurableAssetDTO();
        InsurableAssetCoverageData<T> insurableAssetCoverageData = getCoverageData(
                insurableAssetData.getCollateralRid(), insurableAssetSortOrder);
        if (insurableAssetData.getInsurableAssetType() == InsurableAssetType.STRUCTURE && !insurableAssetCoverageData.hasBuildingCoverage()) {
            insurableAssetCoverageData.setBuildingCoverageData(coverageData);
            coverageData.setSortOrder(insurableAssetCoverageData.getSortOrder());
        } else if (insurableAssetData.getInsurableAssetType() == InsurableAssetType.BASE_INSURABLE_ASSET && !insurableAssetCoverageData.hasContentsCoverage()) {
            insurableAssetCoverageData.setContentsCoverageData(coverageData);
            coverageData.setSortOrder(insurableAssetCoverageData.getSortOrder());
        } else if (insurableAssetData.getInsurableAssetType() == InsurableAssetType.BUSINESS_INCOME && !insurableAssetCoverageData.hasBusinessIncomeCoverage()) {
            insurableAssetCoverageData.setBusinessIncomeCoverageData(coverageData);
            coverageData.setSortOrder(insurableAssetCoverageData.getSortOrder());
        }
    }

    public InsurableAssetCoverageData<T> pop(Long collateralRid, Integer sortOrder) {
        TreeMap<Integer, InsurableAssetCoverageData<T>> insurableAssetCoverageDataMap =
                insurableAssetCoverageData.get(collateralRid);
        InsurableAssetCoverageData<T> coverageData = null;
        if (insurableAssetCoverageDataMap != null) {
            coverageData = insurableAssetCoverageDataMap.remove(sortOrder);
        }
        return coverageData;
    }

    public boolean containsCollateral(Long collateralRid) {
        return insurableAssetCoverageData.containsKey(collateralRid);
    }

    public void addCollateral(Long collateralRid) {
        // TODO: based on collateral state
        InsurableAssetService insurableAssetService =
                ApplicationContextProvider.getContext().getBean(InsurableAssetService.class);
        Collection<InsurableAssetDTO> insurableAssetDTOs =
                insurableAssetService.findInsurableAssetByCollateral(collateralRid, InsuranceType.FLOOD);
        if (insurableAssetDTOs.isEmpty()) {
            throw new CTracApplicationException("E0250", CtracErrorSeverity.TRIVIAL);
        }
        for (InsurableAssetDTO insurableAssetDTO : insurableAssetDTOs) {
            try {
                T coverageDTO = coverageDataClass.newInstance();
                coverageDTO.setInsurableAssetDTO(insurableAssetDTO);
                coverageDTO.setCoverageAmount(CtracAppConstants.DEFAULT_AMOUNT);
                coverageDTO.setPropertyType(insurableAssetDTO.getPropertyType());


                put(coverageDTO);
            } catch (InstantiationException | IllegalAccessException e) {
                logger.error(e.getMessage(), e);
            }
        }
    }

    public void purgeUnneededCoverage() {
        for (Entry<Long, TreeMap<Integer, InsurableAssetCoverageData<T>>> insurableAssetEntry : insurableAssetCoverageData.entrySet()) {
            List<Integer> coveragesToPurge = new ArrayList<Integer>();
            for (Entry<Integer, InsurableAssetCoverageData<T>> coverages : insurableAssetEntry.getValue().entrySet()) {
                if (!coverages.getValue().hasBuildingCoverage() && !coverages.getValue().hasContentsCoverage() && !coverages.getValue().hasBusinessIncomeCoverage()) {
                    coveragesToPurge.add(coverages.getKey());
                }
            }
            for (Integer purgeMe : coveragesToPurge) {
                pop(insurableAssetEntry.getKey(), purgeMe);
            }
        }
    }

    public void setBalanceType(ProofOfCoverageDTO proofOfCoverageDTO) {
        if (insurableAssetCoverageData != null && !insurableAssetCoverageData.isEmpty()) {
            for (TreeMap<Integer, InsurableAssetCoverageData<T>> insurableAssetCoverageDatas : insurableAssetCoverageData.values()) {
                for (InsurableAssetCoverageData<T> insurableAssetCoverageData : insurableAssetCoverageDatas.values()) {
                    if (insurableAssetCoverageData.getBuildingCoverageData() != null && insurableAssetCoverageData.getBuildingCoverageData().hasNonZeroCoverage()) {
                        insurableAssetCoverageData.getBuildingCoverageData().getCoverageDetailsDTO().setBalanceType(getBalanceType(insurableAssetCoverageData.getBuildingCoverageData().getInsurableAssetDTO(), proofOfCoverageDTO.getCoverageType().getDisplayValue()));
                    }
                    if (insurableAssetCoverageData.getContentsCoverageData() != null && insurableAssetCoverageData.getContentsCoverageData().hasNonZeroCoverage()) {
                        insurableAssetCoverageData.getContentsCoverageData().getCoverageDetailsDTO().setBalanceType(getBalanceType(insurableAssetCoverageData.getContentsCoverageData().getInsurableAssetDTO(), proofOfCoverageDTO.getCoverageType().getDisplayValue()));
                    }
                }
            }

        }

    }

    protected String getBalanceType(InsurableAssetDTO insurableAsstDTO, String coverageType) {
        ViewDataRetrievalService viewDataRetrievalService =
                ApplicationContextProvider.getContext().getBean(ViewDataRetrievalService.class);
        RequiredCoverageViewDto requiredCoverageViewDto = viewDataRetrievalService.getRequiredCoverageViewData(insurableAsstDTO.getCollateralRid(), insurableAsstDTO.getRid());
        if (CoverageType.PRIMARY.getDisplayValue().equalsIgnoreCase(coverageType))
         {
             return requiredCoverageViewDto != null? requiredCoverageViewDto.getPrimaryBuildingContentBalanceType():null;

         } else if (CoverageType.EXCESS.getDisplayValue().equalsIgnoreCase(coverageType)) {
            return requiredCoverageViewDto != null? requiredCoverageViewDto.getExcessBuildingContentBalanceType():null;
        }
        return null;
    }





        public List<T> getAllCoverages(boolean includeZeroes, String blanketCoverageType) {
    	List<T> allCoverages = new ArrayList<T>();
    	if (insurableAssetCoverageData != null && !insurableAssetCoverageData.isEmpty()) {
    	    for (TreeMap<Integer, InsurableAssetCoverageData<T>> insurableAssetCoverageDatas : insurableAssetCoverageData.values()) {
        		Collection<T> temp = getInsuranceCoverages(insurableAssetCoverageDatas, includeZeroes, blanketCoverageType);
        		if (temp != null && !temp.isEmpty()) {
        		    allCoverages.addAll(temp);
        		}
    	    }
    	}
    	return allCoverages;
    }

    public Collection<T> getAllCoverages(Long collateralRid, boolean includeZeroes, String blanketCoverageType) {
    	if (insurableAssetCoverageData != null && !insurableAssetCoverageData.isEmpty()) {
    	    TreeMap<Integer, InsurableAssetCoverageData<T>> insurableAssetCoverageDatas = insurableAssetCoverageData.get(collateralRid);
    	    if (insurableAssetCoverageDatas != null && !insurableAssetCoverageDatas.isEmpty()) {
    		    return getInsuranceCoverages(insurableAssetCoverageDatas, includeZeroes, blanketCoverageType);
    	    }
    	}
    	return null;
    }

    public int size( Long collateralRid ){
        if (insurableAssetCoverageData != null && !insurableAssetCoverageData.isEmpty()) {
            TreeMap<Integer, InsurableAssetCoverageData<T>> insurableAssetCoverageDatas = insurableAssetCoverageData.get(collateralRid);
            if (insurableAssetCoverageDatas != null) {
                return insurableAssetCoverageDatas.size();
            }
        }
        return 0;
    }

    private Collection<T> getInsuranceCoverages(
    		TreeMap<Integer, InsurableAssetCoverageData<T>> insurableAssetCoverageDatas, boolean includeZeroes, String blanketCoverageType) {
    	Collection<T> allCoverages = new ArrayList<T>();
    	for (InsurableAssetCoverageData<T> insurableAssetCoverageData : insurableAssetCoverageDatas.values()) {

    		boolean isCombinedCoverage = false;
    	    if (insurableAssetCoverageData.getBuildingCoverageData() != null &&
    	    		(includeZeroes || insurableAssetCoverageData.getBuildingCoverageData().hasNonZeroCoverage())) {
    	    	isCombinedCoverage = "COMB".equals(blanketCoverageType);
    	        allCoverages.add(insurableAssetCoverageData.getBuildingCoverageData());
    	    }

    	    T contentsCoverageData = insurableAssetCoverageData.getContentsCoverageData();
    	    if (contentsCoverageData != null &&
    	    		(includeZeroes || contentsCoverageData.hasNonZeroCoverage() || isCombinedCoverage)) {
    	    	if (isCombinedCoverage && contentsCoverageData instanceof ProvidedCoverageDTO) {
    	    		((ProvidedCoverageDTO) contentsCoverageData).setCoveredByBlanketPolicy("Y");
    	    	}
    	        allCoverages.add(contentsCoverageData);
    	    }

    	    T businessIncomeCoverageData = insurableAssetCoverageData.getBusinessIncomeCoverageData();
    	    // LCP-4510
    	    if (businessIncomeCoverageData != null &&
    	    		(includeZeroes || businessIncomeCoverageData.hasNonZeroCoverage() || isCombinedCoverage)) {
    	    	if (isCombinedCoverage && businessIncomeCoverageData instanceof ProvidedCoverageDTO) {
    	    		((ProvidedCoverageDTO) businessIncomeCoverageData).setCoveredByBlanketPolicy("Y");
    	    	}
    	        allCoverages.add(businessIncomeCoverageData);
    	    }
        }
    	return allCoverages;
    }

    private InsurableAssetCoverageData<T> getCoverageData(Long collateralRid, Integer insurableAssetSortOrder) {

    	// 1) Find the TreeMap with the coverages for this Collateral
    	TreeMap<Integer, InsurableAssetCoverageData<T>> insurableAssetCoverageDataMap = insurableAssetCoverageData.get(collateralRid);
    	if (insurableAssetCoverageDataMap == null) {
    	    insurableAssetCoverageDataMap = new TreeMap<Integer, InsurableAssetCoverageData<T>>();
    	    insurableAssetCoverageData.put(collateralRid, insurableAssetCoverageDataMap);
    	}

    	// 2) if The sort order is null, derived an appropriate sortOrder from
    	// what's already in the map
    	if (insurableAssetSortOrder == null) {
    	    insurableAssetSortOrder = 0;
    	    for (Integer aSortOrder : insurableAssetCoverageDataMap.keySet()) {
        		if (insurableAssetSortOrder <= aSortOrder) {
        		    insurableAssetSortOrder = aSortOrder + 1;
        		}
    	    }
    	}

    	// 3) Find the InsurableAsset with the appropriate sort order
    	InsurableAssetCoverageData<T> coverageData = insurableAssetCoverageDataMap.get(insurableAssetSortOrder);
    	if (coverageData == null) {
    	    coverageData = new InsurableAssetCoverageData<T>(coverageDataClass);
    	    insurableAssetCoverageDataMap.put(insurableAssetSortOrder, coverageData);
    	}

    	coverageData.setSortOrder(insurableAssetSortOrder);

    	return coverageData;
    }

}
