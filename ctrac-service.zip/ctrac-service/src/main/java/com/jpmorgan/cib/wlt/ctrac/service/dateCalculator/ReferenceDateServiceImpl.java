package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CtracReferenceDateRepository;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
@Transactional
public class ReferenceDateServiceImpl implements ReferenceDateService {

    private CtracReferenceDateRepository ctracReferenceDateRepository;
    private DateCalculator dateCalculator;

    @Autowired
    public ReferenceDateServiceImpl(CtracReferenceDateRepository ctracReferenceDateRepository, DateCalculator dateCalculator) {
        assert(ctracReferenceDateRepository != null);
        this.ctracReferenceDateRepository = ctracReferenceDateRepository;
        assert(dateCalculator != null);
        this.dateCalculator = dateCalculator;
    }

    @Override
    public void updateReferenceDate(Date newReferenceDate) {
        ReferenceDate referenceDate = getReferenceDate();
        saveReferenceDate(referenceDate, newReferenceDate);
    }

    @Override
    public void advanceReferenceDate() {
        ReferenceDate referenceDate = getReferenceDate();
        saveReferenceDate(referenceDate, dateCalculator.addCalendarDays(
                1, referenceDate.getReferencDate(), false));
    }

    @Override
    public void advanceReferenceDate(String dayOfWeek) {
        ReferenceDate referenceDate = getReferenceDate();
        DateTime date = new DateTime(dateCalculator.addCalendarDays(
                1, referenceDate.getReferencDate(), false))
                .withTimeAtStartOfDay();
        int day = getDayOfWeek(dayOfWeek);
        if (day == -1) {
            throw new CtracAjaxException("Invalid dayOfWeek");
        }
        while (date.getDayOfWeek() != day) {
            date = date.plusDays(1);
        }
        saveReferenceDate(referenceDate, date.toDate());
    }

    private int getDayOfWeek(String dayOfWeek) {
        switch (dayOfWeek.toLowerCase()) {
            case "monday":
                return DateTimeConstants.MONDAY;
            case "wednesday":
                return DateTimeConstants.WEDNESDAY;
            case "friday":
                return DateTimeConstants.FRIDAY;
            case "tuesday":
                return DateTimeConstants.TUESDAY;
            case "thursday":
                return DateTimeConstants.THURSDAY;
            case "sunday":
                return DateTimeConstants.SUNDAY;
            case "saturday":
                return DateTimeConstants.SATURDAY;
            default:
                return -1;
        }
    }

    private ReferenceDate getReferenceDate() {
        return ctracReferenceDateRepository.findByName(CtracAppConstants.REFERENCE_DATE);
    }

    private void saveReferenceDate(ReferenceDate referenceDate, Date date) {
        referenceDate.setReferencDate(date);
        ctracReferenceDateRepository.save(referenceDate);
    }
}
