package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;

public class FloodZonesListedRuleWorker extends AbstractBIRRuleWorker {

	public FloodZonesListedRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		GenericProofOfCoverageDTO floodInsuranceData = borrowerInsuranceReviewData.getProofOfCoverageData();
		if (floodInsuranceData.getInsuranceType() != InsuranceType.FLOOD) {
			return;
		}
		BIRRuleConclusionDTO floodZonesListedConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if (privatePolicyOrFloodZonesListed(floodInsuranceData)) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
		}
		floodZonesListedConclusion.setConclusion(birConclusion.name());
	}
	
	private boolean privatePolicyOrFloodZonesListed(GenericProofOfCoverageDTO floodInsuranceData) {
		return floodInsuranceData.getPolicyType() == PolicyType.PRIVATE ||
				"Yes".equals(floodInsuranceData.getFloodZonesListed());
	}

}
