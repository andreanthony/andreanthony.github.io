/*package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import java.util.Map;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
















///////////////////////////////////////////////TODO FIXME  implement for all task types
                                               *//**
                                                * Not ready, work in progress
                                                *//*





*//**
 * 
 * @author n595724
 * if at some point we decide to make sprint manage it live circle, the scope must stay prototype
 * 
 *//*
public class InitiateWorkflowCommand extends AbstractCommand {
	
    private final  Map<StateParameterType, Object> inputParameterMap;
    private final PerfectionItemType workFlowType;

	private static final Logger logger = Logger.getLogger(InitiateWorkflowCommand.class);
	
	*//**
	 *//*
	public InitiateWorkflowCommand(PerfectionItemType workflowType,   Map<StateParameterType, Object> inputParameterMap){
	     this.inputParameterMap = inputParameterMap;
		 this.priority=0;
	     this.workFlowType =workflowType;
	}
	
	*//** 
	 *//*
	public InitiateWorkflowCommand(PerfectionItemType workflowType,   Map<StateParameterType, Object> inputParameterMap, int priotity){
	      this.inputParameterMap = inputParameterMap;
	      this.workFlowType =workflowType;
		  this.priority = priotity;
	}
	
	
	@Override
	public void execute() {
	   
	    
        WorkItem workItem =  (WorkItem) inputParameterMap.get(StateParameterType.WORK_ITEM);
        PerfectionTask perfectionTask = (PerfectionTask) inputParameterMap.get(StateParameterType.PERFECTION_TASK);
       
	    
	    
		try {
		    switch( workFlowType ){
		    
    		    case COLLATERAL:{
    		        
    		        DateCalculator dateCalculator =(DateCalculator) ApplicationContextProvider.getContext().getBean("dateCalculator");
    		        CollateralWorkflowService collateralWorkflowService = (CollateralWorkflowService) ApplicationContextProvider.getContext().getBean("CollateralWorkflowService");
    		        TMTaskType tmType = TMTaskType.valueOf(perfectionTask.getTmTaskType());
    		        collateralWorkflowService.initFiatRequestWorkFlow(workItem.getPreferredCollateral().getRid(),PerfectionItemSubType.FLOOD_RENEWAL, tmType, dateCalculator.getCurrentReferenceDate() );
    		        
       		    }
    		    case FLOOD_POLICY :{
                    //
                }
    		    //TODO FIXME  implement for all task types
            default:
                break;
    		     
		    }
			    	    
			} catch (Exception fatal) {
			    String message = "Error initiating a workflow of type :  " + workFlowType +" " +fatal.getMessage();
				logger.error(message);
				throw fatal;
			}
	}
	


}
*/