package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.io.Serializable;


public class PaymentMethodDTO implements Serializable, Cloneable {

    private static final long serialVersionUID = -58814565563439328L;
    private static final Logger logger = Logger.getLogger(PaymentMethodDTO.class);

    private Long rid;
    private String paymentMethod;
    @NoInvalidCharacters
    private String paymentAccount;
    private AddressDto address;

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PaymentMethodDTO other = (PaymentMethodDTO) obj;
        if (rid == null) {
            if (other.rid != null)
                return false;
        } else if (!rid.equals(other.rid))
            return false;
        if (paymentMethod == null) {
            if (other.paymentMethod != null)
                return false;
        } else if (!paymentMethod.equals(other.paymentMethod))
            return false;
        if (paymentAccount == null) {
            if (other.paymentAccount != null)
                return false;
        } else if (!paymentAccount.equals(other.paymentAccount))
            return false;
        if (address == null) {
            if (other.address != null)
                return false;
        } else if (!address.equals(other.address))
            return false;
        return true;
    }

    private PaymentMethodDTO loadTimeValue;
    
	public PaymentMethodDTO(){
		
	}
	
	public PaymentMethodDTO(Long rid, String paymentMethod){
		this.rid = rid;
		this.paymentMethod = paymentMethod;
	}
	
    public Long getRid() {
        return rid;
    }
    
    public void setRid(Long rid) {
        this.rid = rid;
    }
    
    public String getPaymentMethod() {
        return paymentMethod;
    }
    
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    
    public String getPaymentAccount() {
        return paymentAccount;
    }
    
    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }
    
    public AddressDto getAddress() {
        return address;
    }
    
    public void setAddress(AddressDto address) {
        this.address = address;
    }
    
    public boolean isBlank() {
    	return StringUtils.isBlank(paymentMethod) || (StringUtils.isBlank(paymentAccount) && address == null);
    }

    public void saveACopy() {
	    if (address != null) {
	    	address.saveACopy();
        }
        try {
            this.loadTimeValue = (PaymentMethodDTO) this.clone();
        } catch (CloneNotSupportedException e) {
	        logger.error(e.getMessage(), e);
        }
	}

    @Override
    protected PaymentMethodDTO clone() throws CloneNotSupportedException {
        return (PaymentMethodDTO) super.clone();
    }

    public boolean hasChanged() {
	    if(this.loadTimeValue == null) {
	        return !isBlank();
        }
        return !deepEquals(this.loadTimeValue);
    }

	private boolean deepEquals(PaymentMethodDTO obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PaymentMethodDTO other = (PaymentMethodDTO) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (paymentAccount == null) {
			if (other.paymentAccount != null)
				return false;
		} else if (!paymentAccount.equals(other.paymentAccount))
			return false;
		if (paymentMethod == null) {
			if (other.paymentMethod != null)
				return false;
		} else if (!paymentMethod.equals(other.paymentMethod))
			return false;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

}
