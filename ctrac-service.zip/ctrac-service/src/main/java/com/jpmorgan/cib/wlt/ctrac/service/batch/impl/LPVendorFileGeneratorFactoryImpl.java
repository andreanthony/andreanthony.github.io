package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LpInsuranceVendor;
import com.jpmorgan.cib.wlt.ctrac.service.batch.LPVendorFileGenerator;
import com.jpmorgan.cib.wlt.ctrac.service.batch.LPVendorFileGeneratorFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class LPVendorFileGeneratorFactoryImpl implements LPVendorFileGeneratorFactory {

	private static final Logger logger = Logger.getLogger(LPVendorFileGeneratorFactoryImpl.class);
	
	@Autowired @Qualifier("althansLPFileGenerator")
	private LPVendorFileGenerator althansLPFileGenerator;
	
	@Autowired @Qualifier("assurantLPFileGenerator")
	private LPVendorFileGenerator assurantLPFileGenerator;
	
	@Override
	public LPVendorFileGenerator getLPVendorFileGeneratorFactory(LpInsuranceVendor vendor) {
		switch (vendor) {
		case ALTHANS:
			return althansLPFileGenerator;
		case ASSURANT:
			return assurantLPFileGenerator;
		default:
			logger.error("No LPVendorFileGenerator for vendor: " + (vendor != null ? vendor.getDisplayName() : "null"));
			return null;
		}
	}

}
