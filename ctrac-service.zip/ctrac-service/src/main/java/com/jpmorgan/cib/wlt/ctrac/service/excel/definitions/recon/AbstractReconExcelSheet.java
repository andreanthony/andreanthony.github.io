package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.jpmorgan.cib.wlt.ctrac.service.excel.ColumnDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ExcelTable;

public abstract class AbstractReconExcelSheet {
	
	protected String title;
	protected ColumnDefinition[] definition;
	
	private static byte[] LIGHT_GREY = {(byte) 217, (byte) 217, (byte) 217};
	private static byte[] DARK_BLUE = {(byte) 31, (byte) 73, (byte) 125};
	protected int insertTitle(XSSFSheet sheet, int currentRow) {
		Row row = sheet.createRow(currentRow);
		Cell cell = row.createCell(0);
		cell.setCellStyle(generateTitleStyle(sheet.getWorkbook()));
		cell.setCellValue(this.title);
		return currentRow + 1;
	}
	
	protected int insertBlankRow(int currentRow){
		return currentRow + 1;
	}
	
	protected int insertDateTable(XSSFSheet sheet, Date reportDate, Date activityDate, int currentRow){
		currentRow = insertDateRow(sheet, "Report Date", reportDate, currentRow);
		currentRow = insertDateRow(sheet, "For Activity", activityDate, currentRow);
		return currentRow;
	}
	
	protected int insertTableHeader(XSSFSheet sheet, int currentRow){
		ExcelTable headerTable = new ExcelTable(this.definition);
		XSSFCellStyle headerCellStyle = generateHeaderCellStyle(sheet.getWorkbook());
		headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
		headerTable.headerStyle(headerCellStyle);
		headerTable.insertInto(sheet, currentRow, 0);
		return currentRow + 1;
	}

	private int insertDateRow(XSSFSheet sheet, String headerValue, Date date, int currentRow) {
		Row row = sheet.createRow(currentRow++);
		Cell reportDateHeader = row.createCell(0);
		XSSFCellStyle headerCellStyle = generateHeaderCellStyle(sheet.getWorkbook());
		headerCellStyle.setAlignment(HorizontalAlignment.LEFT);
		reportDateHeader.setCellStyle(headerCellStyle);
		reportDateHeader.setCellValue(headerValue);
		Cell reportDateCell = row.createCell(1);
		reportDateCell.setCellStyle(generateDateCellStyle(sheet.getWorkbook(), true));
		reportDateCell.setCellValue(date);
		return currentRow;
	}
	
	protected int insertTotalRow(XSSFSheet sheet, BigDecimal sum, int currentRow, String labelValue, boolean doubleLining){
		int startIndex = ReconPremiumsTableDefinition.DEFINITION.length - 2;
		Row row = sheet.createRow(currentRow);
		Cell totalHeaderCell = row.createCell(startIndex);
		totalHeaderCell.setCellValue(labelValue);
		XSSFCellStyle totalHeaderCellStyle = generateStringCellStyle(sheet.getWorkbook(), false);
		totalHeaderCellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		if(doubleLining){
			totalHeaderCellStyle.setBorderTop(BorderStyle.DOUBLE);
		}
		totalHeaderCell.setCellStyle(totalHeaderCellStyle);
		
		Cell totalAmountCell = row.createCell(startIndex + 1);
	    totalAmountCell.setCellValue(sum.doubleValue());
		XSSFCellStyle totalAmountCellStyle = generateAmountCellStyle(sheet.getWorkbook(), false);
		totalAmountCellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		if(doubleLining){
			totalAmountCellStyle.setBorderTop(BorderStyle.DOUBLE);
		}
		totalAmountCell.setCellStyle(totalAmountCellStyle);
		return currentRow + 1;
	}
	
	private XSSFCellStyle generateHeaderCellStyle(XSSFWorkbook workbook) {
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setFillForegroundColor(new XSSFColor(LIGHT_GREY));
		cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		XSSFFont font = getBodyFont(workbook);
		font.setBold(true);
		cellStyle.setFont(font);
		addBorder(cellStyle);
		return cellStyle;
	}
	
	private XSSFCellStyle generateTitleStyle(XSSFWorkbook workbook){
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		XSSFFont font = workbook.createFont(); 
	    font.setBold(true);
		cellStyle.setFont(font);
		return cellStyle;
	}
	
	protected XSSFCellStyle generateDateCellStyle(XSSFWorkbook workbook, boolean fullBorder) {
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setAlignment(HorizontalAlignment.RIGHT);
		cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
		cellStyle.setDataFormat(workbook.createDataFormat().getFormat("dd-mmm-yy"));
		XSSFFont font = getBodyFont(workbook);
		cellStyle.setFont(font);
		if(fullBorder)
			addBorder(cellStyle);
		return cellStyle;
	}
	
	protected XSSFCellStyle generateStringCellStyle(XSSFWorkbook workbook, boolean darkblue) {
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setAlignment(HorizontalAlignment.LEFT);
		cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
		cellStyle.setWrapText(true);
		if(darkblue){
			XSSFFont font = getBodyFont(workbook);
			cellStyle.setFont(font);
		}
		return cellStyle;
	}
	
	protected XSSFCellStyle generateAmountCellStyle(XSSFWorkbook workbook, boolean darkBlue) {
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setAlignment(HorizontalAlignment.RIGHT);
		cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
		cellStyle.setDataFormat((short)7);
		cellStyle.setWrapText(true);
		if(darkBlue){
			XSSFFont font = getBodyFont(workbook);
			cellStyle.setFont(font);
		}
		return cellStyle;
	}
	
	private void addBorder(XSSFCellStyle cellStyle) {
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
	}
	
	private XSSFFont getBodyFont(XSSFWorkbook workbook){
		XSSFFont font = workbook.createFont();
		font.setColor(new XSSFColor(DARK_BLUE));
		return font;
	}

}
