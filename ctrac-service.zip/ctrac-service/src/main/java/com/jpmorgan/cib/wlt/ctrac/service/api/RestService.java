package com.jpmorgan.cib.wlt.ctrac.service.api;

import java.util.List;
import java.util.Map;

public interface RestService<T> {
    List<T> retrieveAll(Object criteria, Map<RestPathVariable, Object> pathVariables);

    T create(T t, Map<RestPathVariable, Object> pathVariables);

    T retrieve(Long id, Map<RestPathVariable, Object> pathVariables);

    T update(T t, Map<RestPathVariable, Object> pathVariables);

    T verify(T t, Map<RestPathVariable, Object> pathVariables);

    void delete(Long id, Map<RestPathVariable, Object> pathVariables);

    void deleteAll(Object criteria, Map<RestPathVariable, Object> pathVariables);
}
