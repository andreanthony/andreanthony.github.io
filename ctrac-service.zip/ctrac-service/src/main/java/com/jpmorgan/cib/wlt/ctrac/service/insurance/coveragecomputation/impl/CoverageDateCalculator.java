package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracCheckedException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredCoverageViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.email.impl.EmailAlertSender;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;
import microsoft.exchange.webservices.data.Importance;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.util.*;

public class CoverageDateCalculator {
	
	private static final Logger logger = Logger.getLogger(CoverageDateCalculator.class);
	
	public static Date calculateCoverageDate(CoverageActionData coverageActionData, Collateral collateral, WorkItem triggerWorkItem) throws CtracCheckedException {
        Date targetCoverageDate = null;

        triggerWorkItem = CtracBaseEntity.deproxy(triggerWorkItem, WorkItem.class);
        if (triggerWorkItem != null && triggerWorkItem instanceof FloodRemapItem) {
            FloodRemapItem floodRemapItem = (FloodRemapItem) triggerWorkItem;
            FloodRemap floodRemap = CtracBaseEntity.deproxy(floodRemapItem.getFloodRemap(), FloodRemap.class);
            if ("OUT".equals(floodRemapItem.getRemapCategory())) {
                // if this is a zone out scenario, use the date of map change
                if (floodRemap.getLomarDate() != null) {
                    targetCoverageDate = floodRemapItem.getFloodRemap().getLomarDate();
                    logger.debug("Zone Out, returning lomar date: " + targetCoverageDate);
                    return targetCoverageDate;
                } else {
                    targetCoverageDate = floodRemapItem.getFloodRemap().getRevisedMapDate();
                    logger.debug("Zone Out, returning revised map date: " + targetCoverageDate);
                    return targetCoverageDate;
                }
            } else if ("IN".equals(floodRemapItem.getRemapCategory())) {
                targetCoverageDate = coverageActionData.getFourtySixthDay();
                logger.debug("Zone In, returning fourtySixthDay: " + targetCoverageDate);
                return targetCoverageDate;
            }
        }
        CoverageType triggerCoverageType = null;
        Date primaryLpEffectiveDate = null;
        Date excessLpEffectiveDate = null;
        ProofOfCoverage cancelledBorrowerPolicy = coverageActionData.getCancelledBorrowerPolicy();
        if (cancelledBorrowerPolicy != null) {
            // BP just get cancelled
            if (cancelledBorrowerPolicy.getPolicyType_().isApplicationOrBinder()) {
                // if an application or binder is cancelled, use its effective date
                targetCoverageDate = cancelledBorrowerPolicy.getEffectiveDate();
                logger.debug("Cancelling Application/Binder, using effective date: " + targetCoverageDate);
            } else {// if a policy is a cancelled borrower policy, use its cancellation effective date
                targetCoverageDate = cancelledBorrowerPolicy.getCancellationEffectiveDate();
                logger.debug("Cancelling Policy, using cancellation effective date: " + targetCoverageDate);
            }
            triggerCoverageType = cancelledBorrowerPolicy.getCoverageType_();
        }
        Collection<ProofOfCoverage> allActivePolicies = coverageActionData.getAllActivePolicies();
        Long newBorrowerPolicyRid = null;
        for (ProofOfCoverage proofOfCoverage : allActivePolicies) {
            // find the LP effective date to make sure you don't cancel it prior to LP effective date
            PolicyType policyType = proofOfCoverage.getPolicyType_();
            if (policyType == PolicyType.LP || policyType == PolicyType.LP_GAP) {
                primaryLpEffectiveDate = proofOfCoverage.getEffectiveDate();
            } else if (policyType == PolicyType.LP_EXCESS) {
                excessLpEffectiveDate = proofOfCoverage.getEffectiveDate();
            }
            LPActions lpAction = proofOfCoverage.getLpAction_();
            if (lpAction != null && (lpAction == LPActions.NEW_BP || lpAction == LPActions.PENDING_C3) &&
                isNullOrAfter(targetCoverageDate, proofOfCoverage.getEffectiveDate())) {
                targetCoverageDate = proofOfCoverage.getEffectiveDate();
                triggerCoverageType = proofOfCoverage.getCoverageType_();
                newBorrowerPolicyRid = proofOfCoverage.getRid();
                logger.debug("New Borrower Policy, using effective date: " + targetCoverageDate);
            }
        }
        Date maxExpirationDate = coverageActionData.getMaxDateForLetterProcessing();
        if (targetCoverageDate != null && targetCoverageDate.after(maxExpirationDate)) {
            maxExpirationDate = targetCoverageDate;
        }
        for (ProofOfCoverage proofOfCoverage : allActivePolicies) {
            Date targetExpiringCoverageDate = getTargetExpiringCoverageDate(maxExpirationDate, proofOfCoverage);
            if (isNullOrAfter(targetCoverageDate, targetExpiringCoverageDate)) {
                targetCoverageDate = targetExpiringCoverageDate;
                triggerCoverageType = proofOfCoverage.getCoverageType_();
            }
        }
        Long lpPolicyRid = coverageActionData.getMatchingInaciveLpPolicyEffectiveOn(
                newBorrowerPolicyRid != null, targetCoverageDate, triggerCoverageType);
        if(lpPolicyRid != null) {
            sendAlertEmailForInactiveLpPolicies(collateral.getRid(), lpPolicyRid);
        }
		targetCoverageDate = verifyTargetCoverageDateBasedOnRequiredCoverage(coverageActionData, targetCoverageDate);

		// don't cancel LP prior to LP effective date
		if (targetCoverageDate != null && triggerCoverageType != null) {
            targetCoverageDate = adjustToHoldLPIDate(targetCoverageDate, coverageActionData,
                    collateral.getRid(), triggerCoverageType, newBorrowerPolicyRid);
            if(targetCoverageDate != null) {
                Date restrictedDate = getRestrictedDate(targetCoverageDate, triggerCoverageType, primaryLpEffectiveDate, excessLpEffectiveDate);
                if (restrictedDate != null) {
                    logger.debug("Restricting date for Primary and Excess policy to " + restrictedDate);
                    getEmailAlertSender().sendAlertEmailToFloodTeam("Effective date calculation- Recheck needed",
                            "Collateral ID: " + collateral.getRid(), Importance.High);
                    return restrictedDate;
                }
            }
        }
 		// if we determined a coverage date from the policies, return it
		if (targetCoverageDate != null) {
			return targetCoverageDate;
		}
		throw new CtracCheckedException("No date calculated");
	}

    private static boolean isNullOrAfter(Date date1, Date date2) {
        return date1 == null || (date2 != null && date1.after(date2));
    }

    private static Date getTargetExpiringCoverageDate(Date maxExpirationDate, ProofOfCoverage proofOfCoverage) {
        if (proofOfCoverage.isExpiring(maxExpirationDate, false)) {
            if (proofOfCoverage.getPolicyType_().isApplicationOrBinder()) {
                logger.debug("Expiring Application/Binder, using effective date: " + proofOfCoverage.getEffectiveDate());
                return proofOfCoverage.getEffectiveDate();
            } else {
                logger.debug("Expiring Policy, using expiration date: " + proofOfCoverage.getExpirationDate());
                return proofOfCoverage.getExpirationDate();
            }
        }
        return null;
    }

    static void sendAlertEmailForInactiveLpPolicies(Long collateralRid, Long lpPolicyRid) {
        getEmailAlertSender().sendAlertEmailToFloodTeam("Alert: " + collateralRid +
                        " - Policy Received Effective During Inactive LP Period",
                "Alert: Collateral ID " + collateralRid + " and LP Policy RID: " + lpPolicyRid +
                        " - A borrower policy has been received where the effective date falls before the coverage " +
                        "end date of an inactive LP policy. CTRAC is not taking any actions on the inactive policies. " +
                        "Please review the inactive LP policies and determine if any actions are required including " +
                        "cancellations or new issues.", Importance.High);
    }

    static Date adjustToHoldLPIDate(Date targetCoverageDate, CoverageActionData coverageActionData, Long collateralRid,
                                            CoverageType coverageType, Long newBorrowerPolicyRid) {
        // don't calculate coverage prior to Hold date
        Date holdStartDate = coverageActionData.getLastHoldDate(coverageType);
        if(holdStartDate != null) {
            Date lpiDate = coverageActionData.getHoldLPIDate(coverageType);
            if (targetCoverageDate.before(holdStartDate)) {
                logger.debug("Calculated coverage date " + targetCoverageDate + " is prior to a hold date " + holdStartDate);
                if(newBorrowerPolicyRid != null) {
                    getEmailAlertSender().sendAlertEmailToFloodTeam("CTRAC Hold Action Required",
                            "Because there is a Hold in place, CTRAC will not take lender placement actions as of " +
                                    targetCoverageDate + " on Policy number " + newBorrowerPolicyRid +
                                    " Collateral ID: " + collateralRid, Importance.High);
                }
                targetCoverageDate = null;
            }
            // don't calculate coverage within Hold period
            else if(lpiDate == null) {
                logger.debug("Calculated coverage date is within a current Hold period " + targetCoverageDate);
                targetCoverageDate = null;
            }
            // adjust back-dated target date to LPI date
            else if(targetCoverageDate.before(lpiDate)) {
                logger.debug("Calculated coverage date " + targetCoverageDate + " is adjusted to Hold LPI date " + lpiDate);
                targetCoverageDate = lpiDate;
            }
        }
        return targetCoverageDate;
    }

    private static EmailAlertSender getEmailAlertSender() {
        return ApplicationContextProvider.getContext().getBean(EmailAlertSender.class);
    }

    private static Date getRestrictedDate(Date targetCoverageDate, CoverageType triggerCoverageType, Date primaryLpEffectiveDate, Date excessLpEffectiveDate) {
        if (primaryLpEffectiveDate != null && excessLpEffectiveDate != null && triggerCoverageType == CoverageType.PRIMARY_AND_EXCESS) {
            Date earlierDate = primaryLpEffectiveDate;
            Date laterDate = excessLpEffectiveDate;
            if (excessLpEffectiveDate.before(primaryLpEffectiveDate)) {
                earlierDate = excessLpEffectiveDate;
                laterDate = primaryLpEffectiveDate;
            }
            if (targetCoverageDate.before(earlierDate)) {
                return earlierDate;
            } else if (targetCoverageDate.before(laterDate)) {
                return laterDate;
            }
        }
        if (primaryRestrictionExists(targetCoverageDate, triggerCoverageType, primaryLpEffectiveDate)) {
            return primaryLpEffectiveDate;
        } else if (excessRestrictionExists(targetCoverageDate, triggerCoverageType, excessLpEffectiveDate)) {
            return excessLpEffectiveDate;
        }
        return null;
    }

    private static boolean primaryRestrictionExists(Date targetCoverageDate, CoverageType triggerCoverageType, Date primaryLpEffectiveDate) {
	    return dateRestrictionExists(CoverageType.PRIMARY, targetCoverageDate, triggerCoverageType, primaryLpEffectiveDate);
    }

    private static boolean excessRestrictionExists(Date targetCoverageDate, CoverageType triggerCoverageType, Date excessLpEffectiveDate) {
        return dateRestrictionExists(CoverageType.EXCESS, targetCoverageDate, triggerCoverageType, excessLpEffectiveDate);
    }

    private static boolean dateRestrictionExists(CoverageType expectedCoverageType, Date targetCoverageDate, CoverageType triggerCoverageType, Date effectiveDate) {
        return effectiveDate != null && triggerCoverageType == expectedCoverageType && targetCoverageDate.before(effectiveDate);
    }

    /**
	 * Verify the required Coverage and calculate the targetCoverageDate for C3 when conditions apply:
	 *  - New Required Coverage is De-scoped and has a Cancellation Effective Date
	 *  - Input targetCoverageDate has not yet been set and either
     *   -- new asset added or
     *   -- asset of the fiat has a coverage amount > 0 and Had inactive Fiats where coverage amount is zero or
     *   -- new hold added
	 */
	protected static Date verifyTargetCoverageDateBasedOnRequiredCoverage(CoverageActionData coverageActionData, Date targetCoverageDate){
        RequiredCoverage requiredCoverage = coverageActionData.getRequiredCoverage();
		Date calculatedDate = targetCoverageDate;
		if(requiredCoverage != null){
            RequiredCoverageSource source = requiredCoverage.getRequiredCoverageSource();
			if ("Yes".equalsIgnoreCase(requiredCoverage.getIsDescoped()) && source.getCancellationEffectiveDate() != null) {
				calculatedDate = source.getCancellationEffectiveDate();
				logger.debug("Descoping building, using req cov cancellation effective date: " + calculatedDate);
			} else if (targetCoverageDate == null) {
                if (coverageActionData.isNewInsurableAssetAdded()) {
                    calculatedDate = source.getDocumentDate();
                    logger.debug("New insurable asset added, using req cov document date: " + calculatedDate);
                } else if (assetHasInactiveFiatZeroCoverage(coverageActionData)) {
                    calculatedDate = source.getDocumentDate();
                    logger.debug("Asset Has Inactive Fiat Zero Coverage, using req cov document date: " + calculatedDate);
                }
                else {
                    calculatedDate = coverageActionData.getStartDateOfNewHoldAdded();
                    // if no new hold was added, then calculatedDate will remain null
                    if(calculatedDate != null) {
                        logger.debug("Asset Has new hold added, using Hold Start Date: " + calculatedDate);
                    }
                }
            }
		}
		return calculatedDate;
	}

    /**
	 * Validate for the RequiredCoverage that the coverage amount is greater than zero and
	 * if it has for the same asset an old inactive Fiat where the coverage amount is null or zero
	 * @param coverageActionData newRequiredCoverage - The new Required Coverage
	 * @return Flag check
	 */
    static boolean assetHasInactiveFiatZeroCoverage(CoverageActionData coverageActionData){
        RequiredCoverage newRequiredCoverage = coverageActionData.getRequiredCoverage();
        RequiredCoverageViewData oldRequiredCoverage = coverageActionData.getPreviousRequiredCoveragesForInsurableAsset();
        if(oldRequiredCoverage == null){
            //No inactive fiats found - return false already
            return false;
        }
        BigDecimal newPrimaryAmount = newRequiredCoverage.getPrimaryCoverageDetails() == null? null :
                newRequiredCoverage.getPrimaryCoverageDetails().getCoverageAmount();
        BigDecimal newExcessAmount = newRequiredCoverage.getExcessCoverageDetails() == null? null :
                newRequiredCoverage.getExcessCoverageDetails().getCoverageAmount();

        //Condition Check: Old inactive coverage found for same asset as the new required Coverage
        // and the coverage amount of old is zero or null and new Coverage amount is greater than zero
        return newAmountIsGreaterThanZeroAndOldAmountIsZero(newPrimaryAmount, oldRequiredCoverage.getPrimaryCoverageAmount()) ||
                newAmountIsGreaterThanZeroAndOldAmountIsZero(newExcessAmount, oldRequiredCoverage.getExcessCoverageAmount());
    }

    static boolean newAmountIsGreaterThanZeroAndOldAmountIsZero(BigDecimal newAmount, BigDecimal oldAmount){
        //If New Coverage amount is null - already false
        if(newAmount == null){
            return false;
        }
        //When old inactive coverage is null OR zero and new Coverage is greater than zero the condition is true
        return newAmount.compareTo(BigDecimal.ZERO) > 0 && (oldAmount == null || oldAmount.compareTo(BigDecimal.ZERO) == 0);
    }

}
