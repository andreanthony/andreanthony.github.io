package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;

public class BasicMultipartFile implements MultipartFile ,Serializable
 {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private byte[] fileContent;
	private String name;
	private String originalFilename;
	private String contentType;
	
	
	public BasicMultipartFile(byte[] fileContent, String name,
			String originalFilename, String contentType) {
		super();
		this.fileContent = fileContent;
		this.name = name;
		this.originalFilename = originalFilename;
		this.contentType = contentType;
	}
	

	@Override
	public String getContentType() {
		return contentType;
	}

	@Override
	public InputStream getInputStream() throws IOException {
		
		return new ByteArrayInputStream(fileContent);

	}
	
	@Override
	public String getOriginalFilename() {
		return originalFilename;
	}

	@Override
	public long getSize() {
		
		if(fileContent!=null) return fileContent.length;
		
		return 0;
	}

	@Override
	public boolean isEmpty() {
		
		if(fileContent==null || fileContent.length<=0) return true;
		
		return false;
	}

	@Override
	@Deprecated
	public void transferTo(File arg0) throws IOException, IllegalStateException {
		// TODO implement and reb=move deprecation if you need this.
		
	}

	@Override
	public byte[] getBytes() throws IOException {
		return fileContent;
	}

	@Override
	public String getName() {
		return name;
	}

}