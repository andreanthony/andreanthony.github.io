package com.jpmorgan.cib.wlt.ctrac.service.datamover.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.ServiceLinkFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.FloodRemapRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.external.ServiceLinkFloodRemapRepository;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataMoverAdaptor;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataProcessor;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.Seperator;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessCategory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_REMAP_TYPES;

@Component("serviceLinkDataMoverAdapter")
public class ServiceLinkDataMoverAdapter extends DataMoverAdaptor<ServiceLinkFloodRemap, FloodRemap >{
	
	public ServiceLinkDataMoverAdapter() {
		super(SchedulerJob.NEW_TASK_JOB_SL, LineOfBusinessCategory.SERVICE_LINK);
	}

	private static final Logger logger = Logger.getLogger(ServiceLinkDataMoverAdapter.class);

	@Autowired protected ServiceLinkFloodRemapRepository serviceLinkFloodRemapRepository;
	@Autowired protected FloodRemapRepository floodRemapRepository;	
	
	@Override
	protected List<ServiceLinkFloodRemap> fetchSourceData() {
		logger.info("fetchSourceData()::Begin");
		List<ServiceLinkFloodRemap> sourceData = serviceLinkFloodRemapRepository.findByDataProcessingStatus("N");
		logger.info("fetchSourceData()::End");
		return sourceData;
		
	}

	@Override
	protected List<DataProcessor> preparePreStepProcessors() {
		logger.info("preparePreStepProcessors()::Begin");
		List<DataProcessor> preStepsProcessors = new ArrayList<>();
		preStepsProcessors.add(new SetFieldValueUpdateProcessor("dataProcessingStatus","E"));		
		preStepsProcessors.add(new SetFieldValueUpdateProcessor("remapCreationDate",calendarDayUtil.getCurrentReferenceDate()));		
		preStepsProcessors.add(new NotNullFilterProcessor("statusChange"));
		preStepsProcessors.add(new NotEqualFilterProcessor("updateDescription", "QC"));	
		preStepsProcessors.add(new NotEqualFilterProcessor("updateDescription", "Dispute"));	
		Set<Object> statusChange = new HashSet<Object>(Arrays.asList(FLOOD_REMAP_TYPES));
		preStepsProcessors.add(new EqualFilterProcessor("statusChange", statusChange));
		preStepsProcessors.add(new NotInFilterProcessor("customerNumber", retrieveServicerCodesByActive(false)));
		preStepsProcessors.add(new CombineFieldsUpdateProcessor("borrowerName",Seperator.SPACE,"borrowerFirstName,borrowerLastName",Seperator.COMMA));
		logger.info("preparePreStepProcessors()::End");
		return preStepsProcessors;
		
	}
	
	@Override
	protected void executeMove() {
		logger.info("executeMove()::Begin");
		FloodRemap newFloodRemap;
		List<FloodRemap> tempTargetData= new ArrayList<FloodRemap>();
		List<ServiceLinkFloodRemap> filteredSourceData =  getFilteredDataToMove();
		for(ServiceLinkFloodRemap record : filteredSourceData){
			try {
				newFloodRemap = ctracObjectMapper.map(record, FloodRemap.class);
				tempTargetData.add(newFloodRemap);
				super.successCount++;
			} catch (Exception e) {
				logger.error("executeMove()::Service Link to FloodRemap data move failed for Service Link RID:"+ record.getRid(), e);
				super.exceptionRecordsCnt++;
			}
			
		}	
		setTargetData(tempTargetData);
		logger.info("executeMove()::End");
	}


	@Override
	protected List<DataProcessor> preparePostStepProcessors() {
		logger.info("preparePostStepProcessors()::Begin");
		List<DataProcessor> postStepsProcessors = new ArrayList<DataProcessor>();
		postStepsProcessors.add(new SetFieldValueUpdateProcessor("dataProcessingStatus","Y"));
		logger.info("preparePostStepProcessors()::End");
		return postStepsProcessors;			
	}

	@Override
	protected void saveData(List<ServiceLinkFloodRemap> sourceData, List<FloodRemap> targetData) {
		floodRemapRepository.save(targetData);
		serviceLinkFloodRemapRepository.save(sourceData);
	}
}
