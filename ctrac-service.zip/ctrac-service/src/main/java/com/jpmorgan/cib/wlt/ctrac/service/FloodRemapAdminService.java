package com.jpmorgan.cib.wlt.ctrac.service;


import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapDto;

public interface FloodRemapAdminService {
	
    /**
     * Create a new remap task and return the tm task id
     * @param foodRemapDto
     * @return
     */
    public PerfectionTask processCreateNewRemap(FloodRemapDto foodRemapDto);
    
    public FloodRemapDto prepareDisplayCreateNewRemap( );
    
    
	//Responsible for creating a new record in the landing table < fload_Remap>
	/*TODO Not required for 6.0
	public FloodRemapCreateNewRecordData prepareCreateNewRecord();

	public void awakenSleepingTaskFromDashboard(String tmTaskID, String userId);

	void anesthetizeTask(String tmTaskId, String userId);*/
	
	public ReferenceDate getAppReferenceDate();
	
}
