package com.jpmorgan.cib.wlt.ctrac.service.command;

public interface Command extends Comparable<Command> {
		
	public void execute();
	
	public Integer getPriority();
}
