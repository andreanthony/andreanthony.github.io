package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.cls;

import static com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.LoanSystemsOrder.LOAN_SYSTEM_ORDER;
import static com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.cls.CLSPaymentInstructionsRow.PREMIUM_DEBIT_ROW_TEMPLATE;
import static com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.cls.CLSPaymentInstructionsRow.PREMIUM_CREDIT_ROW_TEMPLATE;
import static com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.cls.CLSPaymentInstructionsRow.REFUND_DEBIT_ROW_TEMPLATE;
import static com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.cls.CLSPaymentInstructionsRow.REFUND_CREDIT_ROW_TEMPLATE;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ExcelTable;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;

public class CLSExcelFile {

	private static final String DEBIT_HEADER = "DEBIT";
	private static final String CREDIT_HEADER = "CREDIT";
	private static final String DESCRIPTION_DATE_FORMAT = "MM/dd/yy";
	private static final int LARGE_COL_INDEX = 4;
	private static final int LAST_COLUMN_INDEX = CLSTableDefinition.CLS_TABLE_DEFINITION.length - 1;
	private static final byte[] DARK_GREY = {(byte) 166, (byte) 166, (byte) 166};

	private Map<LoanSystem, BigDecimal> premiumDebits = new HashMap<LoanSystem, BigDecimal>();
	private Map<LoanSystem, BigDecimal> refundDebits = new HashMap<LoanSystem, BigDecimal>(); 
	
/*	public static void main(String[] args) {
		try {
			File testFile = new File("H:/wlt-dev/Althans Weekly Posting 2017-04-07.xlsx");
			FileOutputStream fos = new FileOutputStream(testFile);
			XSSFWorkbook lpWorkbook = new XSSFWorkbook();
			CLSExcelFile excelFile = new CLSExcelFile();
			
			// Premium debits
			Map<LoanSystem, BigDecimal> premiumDebits =  new HashMap<LoanSystem, BigDecimal>();
			Map<LoanSystem, BigDecimal> refundDebits = new HashMap<LoanSystem, BigDecimal>();
			premiumDebits.put(LoanSystem.VLS, new BigDecimal("11399"));
			premiumDebits.put(LoanSystem.LIQ, new BigDecimal("3606"));
			premiumDebits.put(LoanSystem.ACBS, new BigDecimal("5679"));
			premiumDebits.put(LoanSystem.ABLE, new BigDecimal("1844"));

			// Refund debits
			refundDebits.put(LoanSystem.VLS, new BigDecimal("689.75"));
			refundDebits.put(LoanSystem.LIQ, new BigDecimal("183.73"));
			refundDebits.put(LoanSystem.ACBS, new BigDecimal("2"));
			refundDebits.put(LoanSystem.ABLE, new BigDecimal("1"));
	
			// Generate excel
			excelFile.setRefundDebits(refundDebits);
			excelFile.setPremiumDebits(premiumDebits);
			excelFile.insertInto(lpWorkbook, new DateTime().withDate(2017, 4, 7).toDate());
			lpWorkbook.write(fos);
			lpWorkbook.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}*/
	
	
	public void addPremiumDebit(LoanSystem loanSystem, BigDecimal amount) {
		premiumDebits.put(loanSystem, amount);
	}
	
	public void addRefundDebit(LoanSystem loanSystem, BigDecimal amount) {
		refundDebits.put(loanSystem, amount);
	}
	
	public Map<LoanSystem, BigDecimal> getPremiumDebits() {
		return premiumDebits;
	}

	public void setPremiumDebits(Map<LoanSystem, BigDecimal> premiumDebits) {
		this.premiumDebits = premiumDebits;
	}
	
	public Map<LoanSystem, BigDecimal> getRefundDebits() {
		return refundDebits;
	}

	public void setRefundDebits(Map<LoanSystem, BigDecimal> refundDebits) {
		this.refundDebits = refundDebits;
	}
	
	public void insertInto(XSSFWorkbook workbook, Date effectiveDate) {
		int currentRow = 0;
		Sheet sheet = workbook.createSheet("Althans Weekly " + DateFormatter.toString("yyyy-MM-dd", effectiveDate));
		sheet.setDefaultColumnWidth(20);
		sheet.setColumnWidth(LARGE_COL_INDEX, 40 * 256);

		CellStyle titleStyle = generateTitleCellStyle(workbook);
		CellStyle debitsTitleStyle = generateHeaderCellStyle(workbook, Color.YELLOW, HorizontalAlignment.LEFT);
		CellStyle creditsTitleStyle = generateHeaderCellStyle(workbook, Color.ORANGE, HorizontalAlignment.LEFT);
		CellStyle debitsHeaderStyle = generateHeaderCellStyle(workbook, Color.YELLOW, HorizontalAlignment.CENTER);
		CellStyle creditsHeaderStyle = generateHeaderCellStyle(workbook, Color.ORANGE, HorizontalAlignment.CENTER);
		
		insertLargeHeader("MITS Transaction", titleStyle, sheet, currentRow++, LAST_COLUMN_INDEX);
		insertLargeHeader("EFFECTIVE DATE: " + DateFormatter.toString(effectiveDate), null, sheet, currentRow++, LAST_COLUMN_INDEX);
		
		currentRow = insertInto(DEBIT_HEADER, debitsTitleStyle, getPremiumDebitsTable(workbook, debitsHeaderStyle), sheet, currentRow);
		currentRow = insertInto(CREDIT_HEADER, creditsTitleStyle, getPremiumCreditsTable(workbook, creditsHeaderStyle), sheet, currentRow);
		currentRow = insertInto(DEBIT_HEADER, debitsTitleStyle, getRefundDebitsTable(workbook, debitsHeaderStyle), sheet, currentRow);
		currentRow = insertInto(CREDIT_HEADER, creditsTitleStyle, getRefundCreditsTable(workbook, creditsHeaderStyle, effectiveDate), sheet, currentRow);
	}
	
	private XSSFCellStyle generateGrayableCellStyle(XSSFWorkbook workbook) {
		XSSFCellStyle cellStyle = generateStringCellStyle(workbook);
		cellStyle.setFillForegroundColor(new XSSFColor(DARK_GREY));
		cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		return cellStyle;
	}

	private XSSFCellStyle generateTitleCellStyle(XSSFWorkbook workbook) {
		return generateHeaderCellStyle(workbook, Color.LIGHT_GRAY, HorizontalAlignment.LEFT);
	}

	private XSSFCellStyle generateHeaderCellStyle(XSSFWorkbook workbook, Color color, HorizontalAlignment alignment) {
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setFillForegroundColor(new XSSFColor(color));
		cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		cellStyle.setAlignment(alignment);
		addBorder(cellStyle);
		return cellStyle;
	}

	private XSSFCellStyle generateAmountCellStyle(XSSFWorkbook workbook) {
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setAlignment(HorizontalAlignment.RIGHT);
		cellStyle.setDataFormat(workbook.createDataFormat().getFormat("#,##0.00"));
		addBorder(cellStyle);
		return cellStyle;
	}
	
	private XSSFCellStyle generateStringCellStyle(XSSFWorkbook workbook) {
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		addBorder(cellStyle);
		return cellStyle;
	}
	
	private void addBorder(XSSFCellStyle cellStyle) {
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
	}
	
	private void insertLargeHeader(String headerText, CellStyle headerStyle, Sheet sheet, int row, int colSpan) {
		Row headerRow = sheet.createRow(row);
		for (int i = 0; i <= colSpan; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellStyle(headerStyle);
			if (i == 0) {
				cell.setCellValue(headerText);
			}
		}
		sheet.addMergedRegion(new CellRangeAddress(row, row, 0, colSpan));
	}
	
	private int insertInto(String headerText, CellStyle headerStyle, ExcelTable table, Sheet sheet, int currentRow) {
		if (table != null) {
			insertLargeHeader(headerText, headerStyle, sheet, currentRow++, LAST_COLUMN_INDEX);
			table.insertInto(sheet, currentRow, 0);
			currentRow += (table.getRows().size() + 2);
		}
		return currentRow;
	}
	
	private ExcelTable getPremiumDebitsTable(XSSFWorkbook workbook, CellStyle headerStyle) {
		return getTable(premiumDebits, PREMIUM_DEBIT_ROW_TEMPLATE, "", " P", workbook, headerStyle);
	}
	
	private ExcelTable getPremiumCreditsTable(XSSFWorkbook workbook, CellStyle headerStyle) {
		BigDecimal premiumCreditAmount = getPremiumCreditAmount();
		if (BigDecimal.ZERO.compareTo(premiumCreditAmount) == 0) {
			return null;
		}
		List<CLSPaymentInstructionsRow> premiumCreditRows = new ArrayList<CLSPaymentInstructionsRow>();
		CLSPaymentInstructionsRow row = PREMIUM_CREDIT_ROW_TEMPLATE.clone();
		row.setAmount(AmountFormatter.format(premiumCreditAmount));
		premiumCreditRows.add(row);
		CellStyle amountStyle = generateAmountCellStyle(workbook);
		CellStyle stringStyle = generateStringCellStyle(workbook);
		CellStyle grayableStyle = generateGrayableCellStyle(workbook);
		return new ExcelTable(CLSTableDefinition.CLS_TABLE_DEFINITION, premiumCreditRows).headerStyle(headerStyle)
				.customStyle(FieldType.AMOUNT, amountStyle).customStyle(FieldType.STRING, stringStyle).customStyle(FieldType.GRAYABLE, grayableStyle);
	}
	
	private ExcelTable getRefundDebitsTable(XSSFWorkbook workbook, CellStyle headerStyle) {
		return getTable(refundDebits, REFUND_DEBIT_ROW_TEMPLATE, "", " R", workbook, headerStyle);
	}
	
	private ExcelTable getRefundCreditsTable(XSSFWorkbook workbook, CellStyle headerStyle, Date effectiveDate) {
		String refundPrefix = "Althans ";
		String refundSuffix = " Refund Payment " + DateFormatter.toString(DESCRIPTION_DATE_FORMAT, effectiveDate);
		List<CLSPaymentInstructionsRow> refundCreditRows = new ArrayList<CLSPaymentInstructionsRow>();
		refundCreditRows.addAll(getRowsWithTemplate(refundDebits, REFUND_CREDIT_ROW_TEMPLATE, refundPrefix, refundSuffix));
		if (refundCreditRows.isEmpty()) {
			return null;
		}
		CellStyle amountStyle = generateAmountCellStyle(workbook);
		CellStyle stringStyle = generateStringCellStyle(workbook);
		CellStyle grayableStyle = generateGrayableCellStyle(workbook);
		return new ExcelTable(CLSTableDefinition.CLS_TABLE_DEFINITION, refundCreditRows).headerStyle(headerStyle)
				.customStyle(FieldType.AMOUNT, amountStyle).customStyle(FieldType.STRING, stringStyle).customStyle(FieldType.GRAYABLE, grayableStyle);
	}
	
	private ExcelTable getTable(Map<LoanSystem, BigDecimal> amountsBySystem, Map<LoanSystem, CLSPaymentInstructionsRow> template, 
			String descriptionPrefix, String descriptionSuffix, XSSFWorkbook workbook, CellStyle headerStyle) {
		List<CLSPaymentInstructionsRow> rows = getRowsWithTemplate(amountsBySystem, template, descriptionPrefix, descriptionSuffix);
		if (rows.isEmpty()) {
			return null;
		}
		CellStyle amountStyle = generateAmountCellStyle(workbook);
		CellStyle stringStyle = generateStringCellStyle(workbook);
		CellStyle grayableStyle = generateGrayableCellStyle(workbook);
		return new ExcelTable(CLSTableDefinition.CLS_TABLE_DEFINITION, rows).headerStyle(headerStyle)
				.customStyle(FieldType.AMOUNT, amountStyle).customStyle(FieldType.STRING, stringStyle).customStyle(FieldType.GRAYABLE, grayableStyle);
	}
	
	private List<CLSPaymentInstructionsRow> getRowsWithTemplate(Map<LoanSystem, BigDecimal> amountsByLoanSystem,
			Map<LoanSystem, CLSPaymentInstructionsRow> template, String descriptionPrefix, String descriptionSuffix) {
		List<CLSPaymentInstructionsRow> rows = new ArrayList<CLSPaymentInstructionsRow>();
		for (LoanSystem loanSystem : LOAN_SYSTEM_ORDER) {
			BigDecimal amount = amountsByLoanSystem.get(loanSystem);
			if (amount != null && BigDecimal.ZERO.compareTo(amount) < 0) {
				CLSPaymentInstructionsRow row = template.get(loanSystem).clone();
				row.setAmount(AmountFormatter.format(amount));
				StringBuffer description = new StringBuffer(descriptionPrefix).append(loanSystem.name()).append(descriptionSuffix);
				row.setDescription(description.toString());
				rows.add(row);
			}
		}
		return rows;
	}

	private BigDecimal getPremiumCreditAmount(){
		BigDecimal premiumCreditAmount = BigDecimal.ZERO;
		for(BigDecimal debit: premiumDebits.values()){
			premiumCreditAmount = premiumCreditAmount.add(debit);
		}
		return premiumCreditAmount;
	}
	
}
