package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import java.util.Date;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;

public class ReferenceDateUtil {

	private static final Logger logger = Logger.getLogger(ReferenceDateUtil.class);
	
	public static boolean isOnOrBeforeToday(Date date) {
		if (date == null) {
			logger.debug("date is null. returning false.");
			return false;
		}
		
		CalendarDayUtil calendarDayUtil = ApplicationContextProvider.getContext().getBean(CalendarDayUtil.class);
		DateTime referenceDate = new DateTime(calendarDayUtil.getCurrentReferenceDate()).withTimeAtStartOfDay();
		DateTime testDate = new DateTime(date).withTimeAtStartOfDay();
		return !testDate.isAfter(referenceDate);
	}
	
}
