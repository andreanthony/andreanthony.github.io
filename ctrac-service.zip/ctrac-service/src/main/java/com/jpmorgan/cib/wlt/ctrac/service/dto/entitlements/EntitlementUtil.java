package com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.security.CtracGrantedAuthority;

/**
 * Created by I569445 on 5/27/2016.
 */
public final class EntitlementUtil {

    public static Collection<CtracGrantedAuthority> getLoggedInUserProfiles() {
    	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    	if (authentication == null || authentication.getAuthorities() == null) {
    		return new ArrayList<CtracGrantedAuthority>();
    	}
        return (Collection<CtracGrantedAuthority>) authentication.getAuthorities();
    }

    public static boolean hasAuthority(String authorityName) {
        for(CtracGrantedAuthority authority : getLoggedInUserProfiles()) {
            if(authority.getAuthority().equalsIgnoreCase(authorityName)) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasAnyOfAuthorities(String[] listOfAuthorities) {
        boolean hasAuthority = false;
        for(String authorityName : listOfAuthorities) {
            if(hasAuthority(authorityName)) {
                return true;
            }
        }
        return false;
    }
    
	public static boolean hasLOBAccessAuthority(List<LoanData> loans) {
		ArrayList<String> lineOfBusinesss = new ArrayList<String>();
		for (GrantedAuthority gm : EntitlementUtil.getLoggedInUserProfiles()) {
			CtracGrantedAuthority cAuthority = ((CtracGrantedAuthority) gm);
			lineOfBusinesss.addAll(cAuthority.getLineOfBusinesses());
		}

		for (LoanData loan : loans) {
			String lineOfBusinessCode = loan.getLineOfBusiness();
			if (lineOfBusinesss.contains(lineOfBusinessCode)) {
				return true;
			}
		}
		return false;
	}
}
