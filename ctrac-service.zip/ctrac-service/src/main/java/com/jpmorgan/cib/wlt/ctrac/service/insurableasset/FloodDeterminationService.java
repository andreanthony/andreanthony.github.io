package com.jpmorgan.cib.wlt.ctrac.service.insurableasset;

import java.util.Collection;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.FloodDeterminationDto;

public interface FloodDeterminationService {
	
	void persistFloodDeterminationSection(CollateralDetailsMainDto collateralDetailsMainDto,  FloodDeterminationDto floodDeterminationDto, String action);
	
	void verifyFloodDeterminationSection(CollateralDetailsMainDto collateralDetailsMainDto);
    
	
    /**
     * @param collateralRid
     * @return
     */
    Collection<FloodDeterminationDto> findFloodDeterminationByCollateral(Long collateralRid);
   
    
    /**
     * @param floodDeterminationDto
     * @param lineOfBusiness
     * @param eventType
     */
    FloodDeterminationDto saveFloodDetermination(FloodDeterminationDto floodDeterminationDto, String lineOfBusiness,
                                                 CollateralEventType eventType, String userName);


    void deleteFloodDeterminations(Collection<FloodDeterminationDto> floodDeterminations); 
    
    void deleteFloodDetermination(FloodDeterminationDto floodDetermination); 
    
    void deleteFloodDeterminationsByIds(Collection<Long> floodDeterminationIds);
    
    FloodDeterminationDto createFloodDetermination(FloodRemapItem floodRemapItem);
    
}
