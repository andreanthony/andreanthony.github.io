package com.jpmorgan.cib.wlt.ctrac.service.dto.email;

import java.util.*;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.HoldDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.HoldDTO;
import org.apache.commons.lang.StringUtils;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.FloodInsurancePolicyDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.LPPremiumPolicyData;

public class EmailDataDto {
	
	final static List<String> lobsForCombinedCB = Arrays.asList(new String[] {"MM", "CBC", "CCC", "FF", "GNPH","CCB","REB","CDB", "CIB","DCS","WM" });
	
	private String borrowerName="";

	private String propertyAddress="";
	private String cityStateZip="";
	private String fullFormatedAddress="";

    private String taskUUId;

	private String remapType;

	private String loanNumber;

	private String lineOfBusiness; 
	private String lineOfBusinessCodeConst;

	private boolean hasBusinessBankingLOB =  false;

	private boolean hasCTLLOB =  false;

	private String taskUniqueID;

	private String collateralID;

	private boolean exposureExist;
	private boolean combinedCBLOB =  false;	
	
	public String getCollateralID() {
		return collateralID;
	}

	public void setCollateralID(String collateralID) {
		this.collateralID = collateralID;
	}

	private String lpAmount;
	
	private EmailAttributeHolder emailAttributeHolder;
	
	private List<FloodInsurancePolicyDto> propertyList;
	private List<FloodInsurancePolicyDto> fiatPropertyList;
	private String combinedAmount;

	private List<FloodInsurancePolicyDto> priorPropertyList;
		
	private List<LPPremiumPolicyData> lpPremiumPolicyList;
	
	private List<LPPremiumPolicyData> bankPreiumAmountList;
	private boolean hasBankPortion =  false;	
	
	private List<HoldDetailsViewDto> holdList;
	
	private String insuredName="";
	private String floodZone;
	private String letterSentDate="";
	private String BIRFloodZone="";
	private String effectiveDate="";
	private String policyNumber;
	private String policyAmt="";
	private String ctracCorrID="";
	
	private String insGapAmt;
	private String cancelDate="";
	private String expirationDate="";
	private String todayDate="";
	private String severityOneDate="";
	private String severityTwoDate="";
	
	//i.e. First, Second, Third
	private String ordinalNotice;
	
	private String combinedLpPolicyAmounts;
	private String lenderPlacedAmt;
	private String lenderPlacedRefundAmt;
	private String thirtyDayRegulatoryDate;
	private String applicableReason;
	private String vendorPaymentMethod;
	private String vendorPaymentValue;
	
	private String cancellationReason="";
	private boolean gapInCoverageAmounts;
	private boolean gapInCoverageEffectiveDates;
	
	private String accountNumber;
	private String policyExpirationDate;
	private String reminderTypeShort;
	private String reminderTypeShortLowerCase;
	private String reminderTypeAction;
	private String optionalWord="";
    private List<CollateralDto> collateralList;
    private List<LoanData> loanDataList;
    private String borrowerCoverageGapDetails;
  

	private String requiredLPCoverageGapDetails;
	private String effectiveDateForBir;
	private String combinedLPEffectiveDates;
	
	private boolean primaryLoanLOBCTL =  false;


	private Set<String> toAddresses = new HashSet<>();

	public boolean isPrimaryLoanLOBCTL() {
		primaryLoanLOBCTL =  false;
		if(loanDataList == null) return primaryLoanLOBCTL;
		
		for(LoanData data : loanDataList){
			
			boolean isPrimary = data.getChkPrimaryLoan() != null ? data.getChkPrimaryLoan().booleanValue() : false;
			isPrimary = isPrimary || ("Yes".equals(data.getPrimaryFlag()));
			
			if(isPrimary && "CTL".equals(data.getLineOfBusinessCodeConst())){
				primaryLoanLOBCTL =  true;	
				break;
			}			
		}
		return primaryLoanLOBCTL;
	}

	public void setPrimaryLoanLOBCTL(boolean primaryLoanLOBCTL) {
		this.primaryLoanLOBCTL = primaryLoanLOBCTL;
	}
	
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	
	public boolean isHasBusinessBankingLOB() {
		hasBusinessBankingLOB =  false;	
		for(LoanData data : loanDataList){
			if("BB".equals(data.getLineOfBusinessCodeConst())){
				hasBusinessBankingLOB =  true;	
				break;
			}			
		}
		return hasBusinessBankingLOB;
	}
	
	public boolean isHasCTLLOB() {
		hasCTLLOB =  false;	
		for(LoanData data : loanDataList){
			if("CTL".equals(data.getLineOfBusinessCodeConst())){
				hasCTLLOB =  true;	
				break;
			}			
		}
		return hasCTLLOB;
	}

	public boolean isLoanType(String checkForLoanType) {

		for(LoanData data : loanDataList){
			if(checkForLoanType.equals(data.getLoanType())){
				return(true);
			}			
		}
		
		return false;
	}
	
	public boolean isCombinedCBLOB()
	{
		return lobsForCombinedCB.contains(this.lineOfBusinessCodeConst);
	}
	
	
	public String getReminderTypeShortLowerCase() {
		return reminderTypeShortLowerCase;
	}

	public void setReminderTypeShortLowerCase(String reminderTypeShortLowerCase) {
		this.reminderTypeShortLowerCase = reminderTypeShortLowerCase;
	}
	public String getOptionalWord() {
		return optionalWord;
	}

	public void setOptionalWord(String optionalWord) {
		this.optionalWord = optionalWord;
	}
	
	public String getSeverityOneDate() {
		return severityOneDate;
	}

	public void setSeverityOneDate(String severityOneDate) {
		this.severityOneDate = severityOneDate;
	}

	public String getSeverityTwoDate() {
		return severityTwoDate;
	}

	public void setSeverityTwoDate(String severityTwoDate) {
		this.severityTwoDate = severityTwoDate;
	}

	/**
	 * @return the cityStateZip
	 */
	public String getCityStateZip() {
		return cityStateZip;
	}

	/**
	 * @param cityStateZip the cityStateZip to set
	 */
	public void setCityStateZip(String cityStateZip) {
		this.cityStateZip = cityStateZip;
	}

	/**
	 * @return the ctracCorrID
	 */
	public String getCtracCorrID() {
		return ctracCorrID;
	}

	/**
	 * @param ctracCorrID the ctracCorrID to set
	 */
	public void setCtracCorrID(String ctracCorrID) {
		this.ctracCorrID = ctracCorrID;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public String getTaskUUId() {
		return taskUUId;
	}

	public void setTaskUUId(String taskUUId) {
		this.taskUUId = taskUUId;
	}

	public String getRemapType() {
		return remapType;
	}

	public void setRemapType(String remapType) {
		this.remapType = remapType;
	}
	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getTaskUniqueID() {
		return taskUniqueID;
	}

	public void setTaskUniqueID(String taskUniqueID) {
		this.taskUniqueID = taskUniqueID;
	}

	public String getLpAmount() {
		return lpAmount;
	}

	public void setLpAmount(String lpAmount) {
		this.lpAmount = lpAmount;
	}

	public List<CollateralDto> getCollateralList() {
		return collateralList;
	}

	public void setCollateralList(List<CollateralDto> collateralList) {
		this.collateralList = collateralList;
	}

	public EmailAttributeHolder getEmailAttributeHolder() {
		return emailAttributeHolder;
	}

	public void setEmailAttributeHolder(EmailAttributeHolder emailAttributeHolder) {
		this.emailAttributeHolder = emailAttributeHolder;
	}

	public List<FloodInsurancePolicyDto> getPropertyList() {
		return propertyList;
	}

	public void setPropertyList(List<FloodInsurancePolicyDto> propertyList) {
		this.propertyList = propertyList;
		List<FloodInsurancePolicyDto> priorList = new ArrayList<FloodInsurancePolicyDto>();
		List<FloodInsurancePolicyDto> fiatList = new ArrayList<FloodInsurancePolicyDto>();
		String cmbAmount  = "";
		for(FloodInsurancePolicyDto listElem: this.propertyList){
			if(listElem.getInputSourceType().equals("PRIOR")){
				priorList.add(listElem);
				//cmbAmount += listElem.getTotalCoverageAmount() + ","+ listElem.getCoverageAmount();
				cmbAmount += ("".equals(cmbAmount)? "" : "; ") + listElem.getTotalCoverageAmount();
			}else {
				fiatList.add(listElem);
			}
		}
		setPriorPropertyList(priorList);
		setFiatPropertyList(fiatList);
		setCombinedAmount(cmbAmount);
	}
	
	public List<FloodInsurancePolicyDto> getPriorPropertyList() {
		return this.priorPropertyList;
	}
	
	public List<FloodInsurancePolicyDto> getFiatPropertyList() {
		return this.fiatPropertyList;
	}
	
	public void setFiatPropertyList(List<FloodInsurancePolicyDto> fiatPropertyList) {		
		this.fiatPropertyList = fiatPropertyList;
	}

	public void setPriorPropertyList(List<FloodInsurancePolicyDto> priorPropertyList) {
		this.priorPropertyList = priorPropertyList;
	}
	
	public String getCombinedAmount() {
		return combinedAmount;
	}

	public void setCombinedAmount(String combinedAmount) {
		this.combinedAmount = combinedAmount;
	}
	
	public String getCombinedLPPriorAmounts(){
		
		String result="";
		
		for(FloodInsurancePolicyDto insCov: getPriorPropertyList()){
			String amt = insCov.getCoverageAmount();
			if(!StringUtils.isBlank(amt) && isValueGreaterThanZero(amt) ){
				result += amt + ", ";
			}
		}
	return result;
	}
	
	private boolean isValueGreaterThanZero(String value){
		double amount =0.0;
		if(StringUtils.isEmpty(value)){
			return false;
		}
		try {
			amount = Double.parseDouble(value.replace(",", ""));
		} catch (NumberFormatException e) {
			return false;
		}
		return (amount > 0);
		
	}
	
	public List<LPPremiumPolicyData> getLpPremiumPolicyList() {
		return lpPremiumPolicyList;
	}

	public void setLpPremiumPolicyList(List<LPPremiumPolicyData> lpPremiumPolicyList) {
		this.lpPremiumPolicyList = lpPremiumPolicyList;
	}

	//public InsuranceRejectionEmailTable getInsuranceRejectionEmailTable() {
	//	return insuranceRejectionEmailTable;
	//}

	//public void setInsuranceRejectionEmailTable(
	//		InsuranceRejectionEmailTable insuranceRejectionEmailTable) {
	//	this.insuranceRejectionEmailTable = insuranceRejectionEmailTable;
	//}

	
	/**
	 * @return the floodRemapFloodZone
	 */
	public String getFloodZone() {
		return floodZone;
	}

	/**
	 * @param floodRemapFloodZone the floodRemapFloodZone to set
	 */
	public void setFloodZone(String floodRemapFloodZone) {
		this.floodZone = floodRemapFloodZone;
	}

	/**
	 * @return the letterSentDate
	 */
	public String getLetterSentDate() {
		return letterSentDate;
	}

	/**
	 * @param letterSentDate the letterSentDate to set
	 */
	public void setLetterSentDate(String letterSentDate) {
		this.letterSentDate = letterSentDate;
	}

	/**
	 * @return the bIRFloodZone
	 */
	public String getBIRFloodZone() {
		return BIRFloodZone;
	}

	/**
	 * @param bIRFloodZone the bIRFloodZone to set
	 */
	public void setBIRFloodZone(String bIRFloodZone) {
		BIRFloodZone = bIRFloodZone;
	}

	/**
	 * @return the effectiveDate
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the policyNumber
	 */
	public String getPolicyNumber() {
		return policyNumber;
	}

	/**
	 * @param policyNumber the policyNumber to set
	 */
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	
	/**
	 * @return the policyAmt
	 */
	public String getPolicyAmt() {
		return policyAmt;
	}

	/**
	 * @param policyAmt the policyAmt to set
	 */
	public void setPolicyAmt(String policyAmt) {
		this.policyAmt = policyAmt;
	}
	

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	/**
	 * @return the insGapAmt
	 */
	public String getInsGapAmt() {
		return insGapAmt;
	}

	/**
	 * @param insGapAmt the insGapAmt to set
	 */
	public void setInsGapAmt(String insGapAmt) {
		this.insGapAmt = insGapAmt;
	}

	/**
	 * @return the cancelDate
	 */
	public String getCancelDate() {
		return cancelDate;
	}

	/**
	 * @param cancelDate the cancelDate to set
	 */
	public void setCancelDate(String cancelDate) {
		this.cancelDate = cancelDate;
	}

	/**
	 * @return the expirationDate
	 */
	public String getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the todayDate
	 */
	public String getTodayDate() {
		return todayDate;
	}

	/**
	 * @param todayDate the todayDate to set
	 */
	public void setTodayDate(String todayDate) {
		this.todayDate = todayDate;
	}

	public String getLenderPlacedAmt() {
		return lenderPlacedAmt;
	}

	public void setLenderPlacedAmt(String lenderPlacedAmt) {
		this.lenderPlacedAmt = lenderPlacedAmt;
	}

	public String getLenderPlacedRefundAmt() {
		return lenderPlacedRefundAmt;
	}

	public void setLenderPlacedRefundAmt(String lenderPlacedRefundAmt) {
		this.lenderPlacedRefundAmt = lenderPlacedRefundAmt;
	}

	public String getThirtyDayRegulatoryDate() {
		return thirtyDayRegulatoryDate;
	}

	public void setThirtyDayRegulatoryDate(String thirtyDayRegulatoryDate) {
		this.thirtyDayRegulatoryDate = thirtyDayRegulatoryDate;
	}

	public String getApplicableReason() {
		return applicableReason;
	}

	public void setApplicableReason(String applicableReason) {
		this.applicableReason = applicableReason;
	}

	public String getVendorPaymentMethod() {
		return vendorPaymentMethod;
	}

	public void setVendorPaymentMethod(String vendorPaymentMethod) {
		this.vendorPaymentMethod = vendorPaymentMethod;
	}

	public String getVendorPaymentValue() {
		return vendorPaymentValue;
	}

	public void setVendorPaymentValue(String vendorPaymentValue) {
		this.vendorPaymentValue = vendorPaymentValue;
	}

	public String getCancellationReason() {
		return cancellationReason;
	}

	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}

	public boolean isGapInCoverageAmounts() {
		return gapInCoverageAmounts;
	}

	public void setGapInCoverageAmounts(boolean gapInCoverageAmounts) {
		this.gapInCoverageAmounts = gapInCoverageAmounts;
	}

	public boolean isGapInCoverageEffectiveDates() {
		return gapInCoverageEffectiveDates;
	}

	public void setGapInCoverageEffectiveDates(boolean gapInCoverageEffectiveDates) {
		this.gapInCoverageEffectiveDates = gapInCoverageEffectiveDates;
	}

	public String getCombinedLpPolicyAmounts() {
		return combinedLpPolicyAmounts;
	}

	public void setCombinedLpPolicyAmounts(String combinedLpCoverageAmounts) {
		this.combinedLpPolicyAmounts = combinedLpCoverageAmounts;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPolicyExpirationDate() {
		return policyExpirationDate;
	}

	public void setPolicyExpirationDate(String policyExpirationDate) {
		this.policyExpirationDate = policyExpirationDate;
	}

	public String getReminderTypeShort() {
		return reminderTypeShort;
	}

	public void setReminderTypeShort(String reminderTypeShort) {
		this.reminderTypeShort = reminderTypeShort;
	}

	public String getReminderTypeAction() {
		return reminderTypeAction;
	}

	public void setReminderTypeAction(String reminderTypeAction) {
		this.reminderTypeAction = reminderTypeAction;
	}

	public String getOrdinalNotice() {
		return ordinalNotice;
	}

	public void setOrdinalNotice(String ordinalNotice) {
		this.ordinalNotice = ordinalNotice;
	}

    public boolean isExposureExist() {
        return exposureExist;
    }

    public void setExposureExist(boolean exposureExist) {
        this.exposureExist = exposureExist;
    }
    
    /**
     * @return the fullFormatedAddress
     */
    public String getFullFormatedAddress() {
        if(StringUtils.isBlank(fullFormatedAddress)){
            fullFormatedAddress = propertyAddress +" ,"+cityStateZip;
        }
        return fullFormatedAddress;
    }

    /**
     * @param fullFormatedAddress the fullFormatedAddress to set
     */
    public void setFullFormatedAddress(String fullFormatedAddress) {
        this.fullFormatedAddress = fullFormatedAddress;
    }

	public List<LoanData> getLoanDataList() {
		return loanDataList;
	}

	public void setLoanDataList(List<LoanData> loanDataList) {
		this.loanDataList = loanDataList;
	}

	
	  public String getBorrowerCoverageGapDetails() {
			return borrowerCoverageGapDetails;
		}
	public void setBorrowerCoverageGapDetails(String borrowerCoverageGapDetails) {
		this.borrowerCoverageGapDetails = borrowerCoverageGapDetails;
	}

	public String getRequiredLPCoverageGapDetails() {
		return requiredLPCoverageGapDetails;
	}

	public void setRequiredLPCoverageGapDetails(String requiredLPCoverageGapDetails) {
		this.requiredLPCoverageGapDetails = requiredLPCoverageGapDetails;
	}

	public String getEffectiveDateForBir() {
		return effectiveDateForBir;
	}

	public void setEffectiveDateForBir(String effectiveDateForBir) {
		this.effectiveDateForBir = effectiveDateForBir;
	}

	public String getCombinedLPEffectiveDates() {
		return combinedLPEffectiveDates;
	}

	public void setCombinedLPEffectiveDates(String combinedLPEffectiveDates) {
		this.combinedLPEffectiveDates = combinedLPEffectiveDates;
	}

	public List<LPPremiumPolicyData> getBankPreiumAmountList() {
		return bankPreiumAmountList;
	}

	public void setBankPreiumAmountList(List<LPPremiumPolicyData> bankPreiumAmountList) {
		this.bankPreiumAmountList = bankPreiumAmountList;
	}

	public boolean isHasBankPortion() {
		return hasBankPortion;
	}

	public void setHasBankPortion(boolean hasBankPortion) {
		this.hasBankPortion = hasBankPortion;
	}

	public String getLineOfBusinessCodeConst() {
		return lineOfBusinessCodeConst;
	}

	public void setLineOfBusinessCodeConst(String lineOfBusinessCodeConst) {
		this.lineOfBusinessCodeConst = lineOfBusinessCodeConst;
	}

    public List<HoldDetailsViewDto> getHoldList() {
        return holdList;
    }

    public void setHoldList(List<HoldDetailsViewDto> holdList) {
        this.holdList = holdList;
    }

	public Set<String> getToAddresses() {
		return toAddresses;
	}

	public void setToAddresses(Set<String> toAddresses) {
		this.toAddresses = toAddresses;
	}

}
