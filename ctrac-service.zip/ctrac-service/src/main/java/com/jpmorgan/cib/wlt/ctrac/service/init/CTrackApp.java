package com.jpmorgan.cib.wlt.ctrac.service.init;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//
//import com.jpmorgan.cib.wlt.ctrac.config.BaseAppConfig;
//import com.jpmorgan.cib.wlt.ctrac.scheduler.TaskOnDemandScheduler;

import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AddressRepository;
import com.jpmorgan.cib.wlt.ctrac.service.config.BaseServiceConfig;

public class CTrackApp {

	private static final Logger logger = Logger.getLogger(CTrackApp.class);

	private static String processName = null;

	/**
	 * @param args
	 */
	@SuppressWarnings("resource")
	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(BaseServiceConfig.class);
		if( args == null || args.length != 1 )
		{
			 AddressRepository repo = (AddressRepository) context.getBean("addressRepository");
			 repo.findAll();
			 logger.warn("Incorrect Parameter." );
			return;

		}
		else {

/*			
 *    processName = args[0]; 

			logger.info("Starting "+processName+ " process to create the tasks in TM !!!");
			if (processName.equals(FLOOD_REMAP_PROCESS_NAME)) {
				TaskOnDemandScheduler taskOnDemandScheduler = (TaskOnDemandScheduler) context.getBean("taskOnDemandScheduler");
				taskOnDemandScheduler.runNewTaskCreationJob(true);
			} else if (processName.equals(RUN_BATCH_PROCESS)) {
				TaskOnDemandScheduler taskOnDemandScheduler = (TaskOnDemandScheduler) context.getBean("taskOnDemandScheduler");
				taskOnDemandScheduler.runStatesAndSLAUpdateEndOfTheDayJob(true);
				
			} else if (processName.equals(RUN_SERVICElINK_PROCESS)) {
				//the following change is for PBI121.02, to process records from service link
				TaskOnDemandScheduler taskOnDemandScheduler = (TaskOnDemandScheduler) context.getBean("taskOnDemandScheduler");
				taskOnDemandScheduler.runServiceLinkJob(true);
			} else if (processName.equals(RUN_CORELOGIC_PROCESS)) {
				TaskOnDemandScheduler taskOnDemandScheduler = (TaskOnDemandScheduler) context.getBean("taskOnDemandScheduler");
				taskOnDemandScheduler.runCoreLogicDataJob(true);
			} else if(processName.equals(RUN_ENTIRE_EOD_PROCESS)) {
				TaskOnDemandScheduler taskOnDemandScheduler = (TaskOnDemandScheduler) context.getBean("taskOnDemandScheduler");
				taskOnDemandScheduler.runEndOfTheDayJob(true);
			} else  if(processName.equals(RUN_CREATE_WIRE_REQUEST_PROCESS)){
				
				 * Kanban PBI 117.34 - Seperate the batch job that creates the "Create Wire task" 
				 * to run during the day (at 11 am ET instead of 8:59 pm ET business day)	 * 
				 
				TaskOnDemandScheduler taskOnDemanScheduler = (TaskOnDemandScheduler) context.getBean("taskOnDemandScheduler");
				taskOnDemanScheduler.runProcessWireRequestJob(true);				
			} else {
				logger.info("Invalid input parameter");
			}*/
	
		}

	}

}
