package com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements;

import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by V704662 on 8/18/2017.
 */
public class ManageUserEntitlementRequest implements Serializable {

    private static final long serialVersionUID = -5082948611324591835L;
    private final String[] DISALLOWED_FIELDS = new String[]{};

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setDisallowedFields(DISALLOWED_FIELDS);
    }

    @NoInvalidCharacters
    private String sid;

    @NoInvalidCharacters
    private String username;

    @NoInvalidCharacters
    private String firstName;

    @NoInvalidCharacters
    private String lastName;

    private List<Long> groups;

    private boolean enabled;
    private String displayMsg;

    public ManageUserEntitlementRequest(){
    }

    public ManageUserEntitlementRequest(String sid){
        this.sid = sid;
        groups = new ArrayList<>();
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<Long> getGroups() {
        return groups;
    }

    public void setGroups(List<Long> groups) {
        this.groups = groups;
    }

    public String getDisplayMsg() {
        return displayMsg;
    }

    public void setDisplayMsg(String displayMsg) {
        this.displayMsg = displayMsg;
    }
}
