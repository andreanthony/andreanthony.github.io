package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import java.util.*;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DateRange;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredCoverageViewData;
import org.springframework.util.CollectionUtils;

public class CoverageActionData {

	private Long insurableAssetRid;
	
	private RequiredCoverage requiredCoverage;
	
	private Collection<ProofOfCoverage> allActivePolicies = new ArrayList<ProofOfCoverage>();

	private Collection<ProvidedCoverage> allActiveProvidedCoverages = new ArrayList<ProvidedCoverage>();

	private Collection<ProvidedCoverage> allProvidedCoverages = new ArrayList<ProvidedCoverage>();

	private Date today;

	private Date nextBusinessDay;

	private Date fourtySixthDay;

	private Date maxDateForLetterProcessing;

	private ProofOfCoverage cancelledBorrowerPolicy;

	private String insuredName;

	private ProofOfCoverage triggerProofOfCoverage;

	private boolean isPreRenewalLetterSent;


	private boolean isExternallyAgented;

    private DateRange primaryHold = new DateRange();
    private DateRange excessHold = new DateRange();

    private Collection<RequiredCoverageViewData> previousRequiredCoveragesForCollateral;
    private InsurableAsset insurableAsset;

    public CoverageActionData(Long insurableAssetRid) {
		this.insurableAssetRid = insurableAssetRid;
	}

    public CoverageActionData allActivePolicies(Collection<ProofOfCoverage> allActivePolicies) {
		this.allActivePolicies = allActivePolicies;
		return this;
	}

	public CoverageActionData allActiveProvidedCoverages(Collection<ProvidedCoverage> allActiveProvidedCoverages) {
		this.allActiveProvidedCoverages = allActiveProvidedCoverages;
		return this;
	}

	public CoverageActionData nextBusinessDay(Date nextBusinessDay) {
		this.nextBusinessDay = nextBusinessDay;
		return this;
	}


	public CoverageActionData fourtySixthDay(Date fourtySixthDay) {
		this.fourtySixthDay = fourtySixthDay;
		return this;
	}

	public CoverageActionData maxDateForLetterProcessing(Date maxDateForLetterProcessing) {
		this.maxDateForLetterProcessing = maxDateForLetterProcessing;
		return this;
	}
	
	public Date getMaxDateForLetterProcessing() {
		return maxDateForLetterProcessing;
	}

	public CoverageActionData today(Date today) {
		this.today = today;
		return this;
	}

	public CoverageActionData insuredName(String insuredName) {
		this.insuredName = insuredName;
		return this;
	}

	public List<ProvidedCoverage> getActiveBorrowerCoverages(Date date) {
		return getActiveCoveragesOfType(date, PolicyType.borrowerPolicyTypes());
	}

	public List<ProvidedCoverage> getActiveLpCoverages(Date date) {
		return getActiveCoveragesOfType(date, PolicyType.lpPolicyTypes());
	}

	private List<ProvidedCoverage> getActiveCoveragesOfType(Date date, Collection<PolicyType> policyTypes) {
		List<ProvidedCoverage> activeCoverages = new ArrayList<ProvidedCoverage>();
		for (ProvidedCoverage providedCoverage : allActiveProvidedCoverages) {
			ProofOfCoverage proofOfCoverage = providedCoverage.getProofOfCoverage();
			if ((policyTypes == null || policyTypes.contains(proofOfCoverage.getPolicyType_()))
					&& proofOfCoverage.getPolicyStatus_().isActive(false) && proofOfCoverage.isEffectiveOn(date)
					&& !isInactiveApplicationOrBinder(proofOfCoverage)) {
				activeCoverages.add(providedCoverage);
			}
		}
		return activeCoverages;
	}

	public List<ProvidedCoverage> getBorrowerCoveragesEffectiveOn(Date date) {
		List<ProvidedCoverage> coverages = new ArrayList<ProvidedCoverage>();
		for (ProvidedCoverage providedCoverage : allProvidedCoverages) { //all policies that are/were effective on that date
			ProofOfCoverage proofOfCoverage = providedCoverage.getProofOfCoverage();
			if (PolicyType.borrowerPolicyTypes().contains(proofOfCoverage.getPolicyType_())
					&& !proofOfCoverage.getPolicyStatus_().isInvalid() && !proofOfCoverage.getPolicyStatus_().isPendingVerification()
					&& proofOfCoverage.isEffectiveAndNotCancelledOn(date)
					&& !isInactiveApplicationOrBinder(proofOfCoverage)) {
				coverages.add(providedCoverage);
			}
		}
		return coverages;
	}

	public Collection<ProvidedCoverage> getAllProvidedCoverages() {
		return allProvidedCoverages;
	}

	public CoverageActionData allProvidedCoverages(Collection<ProvidedCoverage> allProvidedCoverages) {
		this.allProvidedCoverages = allProvidedCoverages;
		return this;
	}

	private boolean isInactiveApplicationOrBinder(ProofOfCoverage proofOfCoverage) {
		return proofOfCoverage.getPolicyType_().isApplicationOrBinder()
				&& !proofOfCoverage.isEffectiveOn(maxDateForLetterProcessing);
	}

	public Long getInsurableAssetRid() {
		return insurableAssetRid;
	}
	
	public RequiredCoverage getRequiredCoverage() {
		return requiredCoverage;
	}

	public void setRequiredCoverage(RequiredCoverage requiredCoverage) {
		this.requiredCoverage = requiredCoverage;
	}
	
	public Collection<ProofOfCoverage> getAllActivePolicies() {
		return allActivePolicies;
	}

	public Collection<ProvidedCoverage> getAllActiveProvidedCoverages() {
		return allActiveProvidedCoverages;
	}

	public Date getToday() {
		return today;
	}

	public Date getNextBusinessDay() {
		return nextBusinessDay;
	}

	public Date getFourtySixthDay() {
		return fourtySixthDay;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public ProofOfCoverage getTriggerProofOfCoverage() {
		return triggerProofOfCoverage;
	}

	public void setTriggerProofOfCoverage(ProofOfCoverage triggerProofOfCoverage) {
		this.triggerProofOfCoverage = triggerProofOfCoverage;
	}

	public boolean isPreRenewalLetterSent() {
		return isPreRenewalLetterSent;
	}

	public void setPreRenewalLetterSent(boolean isPreRenewalLetterSent) {
		this.isPreRenewalLetterSent = isPreRenewalLetterSent;
	}

	public ProofOfCoverage getCancelledBorrowerPolicy() {
		return cancelledBorrowerPolicy;
	}

	public void setCancelledBorrowerPolicy(ProofOfCoverage cancelledBorrowerPolicy) {
		this.cancelledBorrowerPolicy = cancelledBorrowerPolicy;
	}

    public Collection<RequiredCoverageViewData> getPreviousRequiredCoveragesForCollateral() {
        return previousRequiredCoveragesForCollateral;
    }

    public void setPreviousRequiredCoveragesForCollateral(Collection<RequiredCoverageViewData> previousRequiredCoveragesForCollateral) {
        this.previousRequiredCoveragesForCollateral = previousRequiredCoveragesForCollateral;
    }

    @Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CoverageActionData [allActivePolicies=");
		builder.append(allActivePolicies != null ? allActivePolicies.size() : 0);
		builder.append(", allActiveProvidedCoverages=");
		builder.append(allActiveProvidedCoverages != null ? allActiveProvidedCoverages.size() : 0);
        builder.append(", insurableAssetRid=");
        builder.append(insurableAssetRid);
		builder.append(", today=");
		builder.append(today);
		builder.append(", nextBusinessDay=");
		builder.append(nextBusinessDay);
		builder.append(", isLPRenewalScenario=");
		builder.append(", cancelledRorrowerPolicy=");
		builder.append(cancelledBorrowerPolicy);
		builder.append(", insuredName=");
		builder.append(insuredName);
		builder.append(", isPreRenewalLetterSent=");
		builder.append(isPreRenewalLetterSent);
		builder.append("]");
		return builder.toString();
	}

    public ProofOfCoverage getEarliestPolicyEffectiveAfter(Date date, CoverageType coverageType) {
        Date earliestEffectiveDate = null;
        ProofOfCoverage firstPolicy = null;
        for (ProofOfCoverage policy : this.allActivePolicies) {
            if (policy.getCoverageType_().isMatching(coverageType) &&
                    policy.getPolicyType_().isBorrowerPolicy() &&
                    (date != null && policy.getEffectiveDate().after(date)) &&
                    (earliestEffectiveDate == null || policy.getEffectiveDate().before(earliestEffectiveDate))) {
                firstPolicy = policy;
                earliestEffectiveDate = policy.getEffectiveDate();
            }
        }
        return firstPolicy;
    }

    /* return true when
	- there was at least one previous inactive FIAT for the collateral AND
	- the building did not exist on the latest previous previous inactive FIAT
	 */
    public boolean isNewInsurableAssetAdded() {
        return !CollectionUtils.isEmpty(previousRequiredCoveragesForCollateral) &&
                getPreviousRequiredCoveragesForInsurableAsset() == null;
    }

    public RequiredCoverageViewData getPreviousRequiredCoveragesForInsurableAsset() {
        if(!CollectionUtils.isEmpty(previousRequiredCoveragesForCollateral)) {
            for (RequiredCoverageViewData requiredCoverageViewData : previousRequiredCoveragesForCollateral) {
                if (insurableAssetRid.equals(requiredCoverageViewData.getInsurableAssetRid())) {
                    return requiredCoverageViewData;
                }
            }
        }
        return null;
    }

    public List<ProofOfCoverage> getBorrowerPoliciesEffectiveOnOrAfter(Date date, CoverageType coverageType) {
        List<ProofOfCoverage> policies = new ArrayList<>();
        for (ProvidedCoverage providedCoverage : allProvidedCoverages) {
            ProofOfCoverage proofOfCoverage = providedCoverage.getProofOfCoverage();
            if (proofOfCoverage.getPolicyType_().isBorrowerPolicy()
                    && coverageType.isMatching(proofOfCoverage.getCoverageType_())
                    && !proofOfCoverage.getPolicyStatus_().isInvalid() && !proofOfCoverage.getPolicyStatus_().isPendingVerification()
                    && (proofOfCoverage.isEffectiveAndNotCancelledOn(date) || proofOfCoverage.isEffectiveAfter(date))) {
                policies.add(proofOfCoverage);
            }
        }
        return policies;
    }

    public Date getLastHoldDate(CoverageType coverageType) {
        //if both coverages are on hold, C3 will use the latest of two LPI dates (getLatest=true)
        return getDateByHoldCoverageType(primaryHold.getStartDate(), excessHold.getStartDate(), coverageType, true);
    }

    public Date getHoldLPIDate(CoverageType coverageType) {
        //if both coverages are on hold, C3 will use the earlier of two LPI dates (getLatest=false)
        return getDateByHoldCoverageType(primaryHold.getEndDate(), excessHold.getEndDate(), coverageType, false);
    }

    public Set<Date> getCurrentHoldLpiDates(Date date) {
        Set<Date> holdLpiDates = new TreeSet<>();
        if (primaryHold.isWithinDateRange(date) && primaryHold.getEndDate() != null) {
            holdLpiDates.add(primaryHold.getEndDate());
        }
        if (excessHold.isWithinDateRange(date) && excessHold.getEndDate() != null) {
            holdLpiDates.add(excessHold.getEndDate());
        }
        return holdLpiDates;
    }

    private Date getDateByHoldCoverageType(Date primaryDate, Date excessDate, CoverageType coverageType, boolean getLatest) {
        if (CoverageType.PRIMARY == coverageType) {
            return primaryDate;
        }
        else if (CoverageType.EXCESS == coverageType) {
            return excessDate;
        }
        else if (primaryDate == null) {
            return excessDate;
        }
        else if (excessDate == null) {
                return  primaryDate;
        }
        else if(getLatest && primaryDate.after(excessDate) ||
                !getLatest && !primaryDate.after(excessDate)) {
            return primaryDate;
        }
        return excessDate;
    }

    public DateRange getPrimaryHold() {
        return primaryHold;
    }

    public DateRange getExcessHold() {
        return excessHold;
    }

    public void populateHolds(Hold primaryHold, Hold excessHold) {
        // primary hold parameter is the last (or only) hold extension period
        if(primaryHold != null) {
            this.primaryHold = new DateRange(getHoldStartDate(primaryHold), getHoldEndDate(primaryHold));
        }
        if(excessHold != null) {
            this.excessHold = new DateRange(getHoldStartDate(excessHold), getHoldEndDate(excessHold));
        }
    }

    private Date getHoldEndDate(Hold hold) {
        Date endDate = hold.getLpiDate();
        if (!VerificationStatus.VERIFIED.name().equals(hold.getHoldStatus())) {
            endDate = null;
        }
        return endDate;
    }

    private Date getHoldStartDate(Hold hold) {
        Date startDate = hold.getStartDate();
        // Initial hold start date is in the parent hold row
        if (hold.getParentHold() != null) {
            startDate = hold.getParentHold().getStartDate();
        }
        return startDate;
    }

    public Date getStartDateOfNewHoldAdded() {
        Date startDate = null;
        if (previousRequiredCoveragesForCollateral != null) {
            if (isNewHold(requiredCoverage.getPrimaryHold())) {
                startDate = requiredCoverage.getPrimaryHold().getStartDate();
            }
            if (isNewHold(requiredCoverage.getExcessHold()) &&
                    (startDate == null || startDate.before(requiredCoverage.getExcessHold().getStartDate()))) {
                startDate = requiredCoverage.getExcessHold().getStartDate();
            }
        }
        return startDate;
    }

    boolean isNewHold(Hold hold) {
        return hold != null && hold.isNewHold();
    }

    public void setInsurableAsset(InsurableAsset insurableAsset) {
        this.insurableAsset = insurableAsset;
    }

    public InsurableAsset getInsurableAsset() {
        return insurableAsset;
    }


	public boolean isExternallyAgented() {
		return isExternallyAgented;
	}

	public void setExternallyAgented(boolean externallyAgented) {
		isExternallyAgented = externallyAgented;
	}

    public Long getMatchingInaciveLpPolicyEffectiveOn(boolean triggeredByNewBp, Date date, CoverageType coverageType) {
        if(triggeredByNewBp) {
            for (ProvidedCoverage providedCoverage : allProvidedCoverages) {
                ProofOfCoverage proofOfCoverage = providedCoverage.getProofOfCoverage();
                if (proofOfCoverage.getPolicyType_().isLenderPlaced()
                        && proofOfCoverage.getCoverageType_().isMatching(coverageType)
                        && proofOfCoverage.getPolicyStatus_().isInactive()
                        && (proofOfCoverage.isEffectiveAndNotCancelledOn(date))) {
                    return proofOfCoverage.getRid();
                }
            }
        }
        return null;
    }
}
