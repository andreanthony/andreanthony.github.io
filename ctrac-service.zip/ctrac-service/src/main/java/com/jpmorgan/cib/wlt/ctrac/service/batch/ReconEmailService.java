package com.jpmorgan.cib.wlt.ctrac.service.batch;

public interface  ReconEmailService {
	
	void createAndSendEmail(Long taskId);

	void createAndSendNoTransactionEmail();
}
