package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.util;

import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

public class CoverageLapseDetector {

	public static boolean hasLapseInCoverageDates(ProofOfCoverageDTO lpPolicyBeingCancelled) {
		// covers both scenarios: by updating expiration date or by setting cancellationDate
		Date effectiveDate = lpPolicyBeingCancelled.getEffectiveDate_();
		Date expirationDate = lpPolicyBeingCancelled.getExpirationDate_();
		Date cancellationDate = lpPolicyBeingCancelled.getCancellationEffectiveDate_();
		return hasLapse(effectiveDate, expirationDate, cancellationDate);
	}

	public static boolean hasLapseInCoverageDates(ProofOfCoverage lpPolicy) {
		Date effectiveDate = lpPolicy.getEffectiveDate();
		Date expirationDate = lpPolicy.getExpirationDate();
		Date cancellationDate = lpPolicy.getCancellationEffectiveDate();
		return hasLapse(effectiveDate, expirationDate, cancellationDate);
	}

	public static boolean hasLapse(Date effectiveDate, Date expirationDate, Date cancellationDate) {
		boolean hasLapseBeforeCancellation = cancellationDate == null || cancellationDate.after(effectiveDate);		
		if(!hasLapseBeforeCancellation) {
			return false; // flat cancelled
		}
		return expirationDate.after(effectiveDate);
	}

}
