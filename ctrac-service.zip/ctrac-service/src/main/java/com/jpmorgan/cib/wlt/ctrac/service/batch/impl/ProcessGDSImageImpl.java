package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.IMAGE_FILE;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipFile;

import javax.xml.transform.stream.StreamSource;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TaskUniqueIdGenerator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FileProcessingUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.letters.LetterData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.letters.LetterFile;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LetterItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CtracReferenceDateRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.letters.LetterDataRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.letters.LetterFileRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.letters.LetterItemRepository;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.ProcessGDSImage;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.letters.ack.CtracLetterConfirmationFile;
import com.jpmorgan.cib.wlt.ctrac.service.helper.XMLUtil;

/**
 * @author N664895
 *
 */
@Service(value = "processGDSImage")
public class ProcessGDSImageImpl extends AbstractFloodRemapDataExtractImpl implements ProcessGDSImage {

	private static final Logger logger = Logger.getLogger(ProcessGDSImageImpl.class);

	// Landing directories
	public static final String GDSIMAGE_LANDING_ZIP_DIR = "gdsLetters.zipfile.landing.incoming.directory";
	public static final String GDSIMAGE_LANDING_XML_DIR = "gdsLetters.xmlfile.landing.incoming.directory";

	// Archive directories
	public static final String GDSIMAGE_ARCHIVE_ZIP_DIR = "gdsLetters.zipfile.archive.incoming.directory";
	public static final String GDSIMAGE_ARCHIVE_XML_DIR = "gdsLetters.xmlfile.archive.incoming.directory";

	public static final String ZIPFILE_CONTENT_INVALID = "gdsLetters.email.notification.invalidZipFile";
	public static final String ZIPFILE_NOTEXIST = "gdsLetters.email.notification.ZipFileNotExist";
	public static final String ZIPFILE_MORETHAN_ONE = "gdsLetters.email.notification.ZipFileMoreThanOne";
	public static final String ZIPFILE_ZERO_LETTER = "gdsLetters.email.notification.ZipFileZeroLetter";
	public static final String XMLFILE_CONTENT_INVALID = "gdsLetters.email.notification.invalidXmlFile";
	public static final String XMLFILE_NOTEXIST = "gdsLetters.email.notification.XmlFileNotExist";
	public static final String XMLFILE_NOTRECEIVED = "gdsLetters.email.notification.XmlFileNotReceived";
	public static final String XMLFILE_MORETHAN_ONE = "gdsLetters.email.notification.XmlFileMoreThanOne";
	public static final String XMLFILE_FAILURE_STATUS = "gdsLetters.email.notification.XmlFileFailure";

	public static final String EMAIL_SUBJECT = "gdsLetters.email.notification.subject.fileInvalid";
	public static final String EMAIL_SUBJECT_FAILURE = "gdsLetters.email.notification.subject.xmlFileFailure";
	public static final String EMAIL_SUBJECT_FILENOTFFOUND = "gdsLetters.email.notification.subject.XmlFileNotFound";
	public static final String EMAIL_SUBJECT_ZIPFILENOTFOUND = "gdsLetters.email.notification.subject.ZipFileNotFound";
	public static final String EMAIL_SUBJECT_FILENOTRECEIVED = "gdsLetters.email.notification.subject.XmlFileNotReceived";
	public static final String EMAIL_SUBJECT_MORETHAN_ONE = "gdsLetters.email.notification.subject.XmlFileMoreThanOne";
	public static final String EMAIL_SUBJECT_ZIPMORETHAN_ONE = "gdsLetters.email.notification.subject.ZipFileMoreThanOne";
	public static final String EMAIL_SUBJECT_ZERO_LETTER = "gdsLetters.email.notification.subject.ZipFileZeroLetter";
	public static final String INVALID_GDSIMAGE_FILE = "gdsLetters.email.notification.invalidRemap";

	public static final String GDSIMAGE_VALID_FILE_NAME_PREFIX = "ctrac_images_";
	public static final int REMAP_TASK_UNIQUE_ID_LENGTH = 6;

	@Autowired private OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher;
	@Autowired private LetterFileRepository letterFileRepository;
	@Autowired @Qualifier("TMService")private TMService tmService;
	@Autowired private BusinessDayUtil businessDayUtil;
	@Autowired private LetterItemRepository letterItemRepository;
	@Autowired private AuditInformationService auditInformationService;
	@Autowired private LetterDataRepository letterDataRepository;
	@Autowired private CollateralDocumentService collateralDocumentService;
	@Autowired private CtracReferenceDateRepository ctracReferenceDateRepository;

	// TODO FIXME: don't put at class level
	private File zipFile = null;
	private File xmlFile = null;

	@Override
	protected File[] getAllFiles() {
		return getAllFiles(GDSIMAGE_LANDING_ZIP_DIR);
	}

	@Override
	protected boolean isValidZipFile(File file) {
		return isValidZipFile(file, EMAIL_SUBJECT, ZIPFILE_CONTENT_INVALID);
	}

	@Override
	protected boolean isValidFileName(File file) {
		return isValidFileName(file, GDSIMAGE_VALID_FILE_NAME_PREFIX);
	}

	@Override
	protected void extractContents(File file) {
		// extractContents(file, CORELOGIC_LANDING_ZIP_CONTENTS_DIR);
	}

	@Override
	@Transactional
	protected void processContents() {
		try {
		
		logger.debug("Inside processContents()");
		if (zipFile != null && xmlFile != null) {
			PerfectionTask perfectionTask = tmService.createTask(TMTaskType.FLOOD_INSURANCE,
					createLetterItem(PerfectionItemSubType.IMAGE), IMAGE_FILE.getFloodRemapTaskState());
			logger.info(" Data is saved to TLCP_LTTER_FILE with perfection item ID " + perfectionTask.getRid());
			CtracLetterConfirmationFile ctracLetterConfirmationFile = processXmlFile(xmlFile);
			String zipFileName = processImageFile(zipFile);
			if(!ctracLetterConfirmationFile.getFileId().equals("null")){
				LetterFile letterfile = letterFileRepository.findOne(Long.parseLong(ctracLetterConfirmationFile.getFileId()));
				if(letterfile.getZipFileName()==null){
					letterfile.setZipFileName(zipFileName);
					if (perfectionTask != null) {
						letterfile.setPerfectionTaskRid(perfectionTask.getRid());
					}
					try {
						letterfile.setAckDate(DateFormatter.parseDateTime(ctracLetterConfirmationFile.getFileDateTime()));
					} catch (ParseException swallow) {
						logger.error(" could not parse the Ack date time " + ctracLetterConfirmationFile.getFileDateTime());
					}
					letterfile.setStatus(ctracLetterConfirmationFile.getProcessingStatus());
					letterfile = letterFileRepository.save(letterfile);
				}
			}else{
				logger.debug("FileId is null in GDS ACK file");
			}
		}
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
		}
	}

	@Override
	protected void archiveContents() {
		FileProcessingUtil.archiveGDSImageEntireDirectory(env.getRequiredProperty(GDSIMAGE_LANDING_ZIP_DIR),
				env.getRequiredProperty(GDSIMAGE_ARCHIVE_ZIP_DIR));
		FileProcessingUtil.archiveGDSImageEntireDirectory(env.getRequiredProperty(GDSIMAGE_LANDING_XML_DIR),
				env.getRequiredProperty(GDSIMAGE_ARCHIVE_XML_DIR));
	}

	@Override
	protected void archiveFile(File file) {
		FileProcessingUtil.archiveFile(file, env.getRequiredProperty(GDSIMAGE_ARCHIVE_ZIP_DIR));
	}

	@Override
	@Transactional
	protected void updateLastFileReceivedDate() {
		updateLastFileReceivedDate(CtracAppConstants.IMAGE_FILE_RECEIVED_DATE);
	}

	@Override
	protected void processContents(File file) {

	}

	@Transactional
	protected CtracLetterConfirmationFile processXmlFile(File file) {
		CtracLetterConfirmationFile ctracLetterConfirmationFileObject = null;
		try {
			logger.debug("Start processing xml file:");
			if (XMLUtil.validateXML(CtracAppConstants.GDSIMAGE_XML_SCHEMA, new StreamSource(file))) {
				logger.debug("Xml schema is valid.");
				ctracLetterConfirmationFileObject = XMLUtil.convertXmlFileToLetterAck(file);
			} else {
				logger.debug("Xml schema is invalid.");
				sendNotificationEmail(INVALID_GDSIMAGE_FILE, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
				return null;
			}
		} catch (Exception e) {
			sendNotificationEmail(INVALID_GDSIMAGE_FILE, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
		}
		return ctracLetterConfirmationFileObject;
	}

	/**
	 * @param file
	 * @return
	 */
	@Transactional
	private String processImageFile(File file) {
		CollateralDocument collateralDocument =
				collateralDocumentService.saveCollateralDocument(file, CtracAppConstants.IMAGE_FILE_IDENTIFIER, null, null);
		return collateralDocument.getFileName();
	}


	private boolean isAllBBOrCTL(CtracLetterConfirmationFile ctracLetterConfirmationFile, Map<String, Integer> expectedImageCountMap)
	{
		boolean isAllBBOrCTL = true;
		List<LetterData> letterDataList = letterDataRepository.findByLetterFileRid(Long.parseLong(ctracLetterConfirmationFile.getFileId()));
		for(int i=0;letterDataList.size() >i ;i++){
			LetterData letterData =letterDataList.get(i);
			if(!LineOfBusinessDTO.isBusinessBanking(letterData.getLineOfBusiness()) && !LineOfBusinessDTO.isCommercialTermLending(letterData.getLineOfBusiness()))
			{
				isAllBBOrCTL = false;
				expectedImageCountMap.put(letterData.getLineOfBusiness(), expectedImageCountMap.containsKey(letterData.getLineOfBusiness()) ? expectedImageCountMap.get(letterData.getLineOfBusiness())+1 : 1);
			}
		}
		return isAllBBOrCTL;
	}

	private int getTotalImageCount(Map<String, Integer> expectedImageCountMap) {
		int totalCount = 0;
		if (expectedImageCountMap != null) {
			for (Map.Entry<String, Integer> entry : expectedImageCountMap.entrySet()) {
				totalCount = totalCount + entry.getValue();
			}
		}
		return totalCount;
	}


	protected File getNewFile(String path) {
		return new File(path);
	}

	protected ZipFile getNewZipFile(File file) throws IOException {
		return new ZipFile(file);
	}

	@Override
	protected boolean areValidContents() {

		ReferenceDate referenceDate = ctracReferenceDateRepository.findByName(CtracAppConstants.REFERENCE_DATE);
		// Date referenceDt = referenceDate.getReferencDate();
		// java.sql.Date sqlDate = new java.sql.Date(referenceDt.getTime());

		List<LetterFile> letterFileList = letterFileRepository.findBySentDate(referenceDate.getReferencDate());

		boolean fileFlag = false;
		CtracLetterConfirmationFile ctracLetterConfirmationFile = null;
		File xmlFolderContentsDirectory = getNewFile(env.getRequiredProperty(GDSIMAGE_LANDING_XML_DIR));

		if (letterFileList.size() == 0) {
					sendNotificationEmail(XMLFILE_NOTRECEIVED, arrPoEmailAddress, arrCtracEmailAddress,EMAIL_SUBJECT_FILENOTRECEIVED);
					logger.debug("ACK file is not received");
					fileFlag = false;
		} else {
			xmlFile = checkGDSAckFile(xmlFolderContentsDirectory);
			if (xmlFile != null) {
				ctracLetterConfirmationFile = processXmlFile(xmlFile);
				if ((ctracLetterConfirmationFile.getNumberOfLetters() == 0 && ctracLetterConfirmationFile.getProcessingStatus().equalsIgnoreCase("SUCCESS"))) {
					logger.debug("Value of numberOfLetters tag is 0 in GDS ACK file");
					fileFlag = false;
					return fileFlag;
				}
			}
			if (xmlFile != null && !ctracLetterConfirmationFile.getFileId().equals("null")) {
				updateLetterDataStatus(ctracLetterConfirmationFile);
				
				if (ctracLetterConfirmationFile.getProcessingStatus().equalsIgnoreCase("FAILURE")) {
					fileFlag = false;
					sendNotificationEmail(XMLFILE_FAILURE_STATUS, arrPoEmailAddress, arrCtracEmailAddress,EMAIL_SUBJECT_FAILURE);
				}else {
					File zipFolderContentsDirectory = getNewFile(env.getRequiredProperty(GDSIMAGE_LANDING_ZIP_DIR));

					//skip for a mix of BB and CTL,
					//otherwise send email notification when total expected image file number don't match the total from zip file
					Map<String, Integer> expectedImageCountMap = new HashMap<String, Integer>();
					if(!isAllBBOrCTL(ctracLetterConfirmationFile, expectedImageCountMap))
					{
						zipFile = checkGDSImageFile(zipFolderContentsDirectory);
						ZipFile zipFileContent = null;
						try {
							if(zipFile != null){
								zipFileContent = getNewZipFile(zipFile);
								int totalImageCountExpected = getTotalImageCount(expectedImageCountMap);
								if(zipFileContent.size() != totalImageCountExpected){
									fileFlag = false;

									StringBuffer imageCountMessage = new StringBuffer();
									for (Map.Entry<String, Integer> entry : expectedImageCountMap.entrySet()) {
										imageCountMessage.append("<tr><td>"+entry.getKey()+"</td><td>"+entry.getValue()+"</td></tr>");
									}
									String[] args = new String[]{imageCountMessage.toString()};
									sendNotificationEmail(ZIPFILE_ZERO_LETTER, arrPoEmailAddress, arrCtracEmailAddress,EMAIL_SUBJECT_ZERO_LETTER, args);
									zipFile = null;
								}else{
									fileFlag = true;
								}
								zipFileContent.close();
							}
						} catch (IOException e) {
							logger.error(e.getMessage(), e);
							fileFlag = false;
							logger.error(ErrorCodeToMessageConverter.convertToMessage("E0313", CtracErrorSeverity.CRITICAL));
						}
					}
					else
					{
						zipFile = null;
						fileFlag = true;
					}
				}
			}
		}
		return fileFlag;
	}

	/**
	 * This method is for insertion of letter item data into 
	 * @param perfectionItemSubType
	 * @return object of letterItem
	 */
	@Transactional
	public LetterItem createLetterItem(PerfectionItemSubType perfectionItemSubType) {
		LetterItem letterItem = new LetterItem();
		letterItem.setPerfectionType(PerfectionItemType.LETTER_ITEM.name());
		letterItem.setPerfectionSubType(PerfectionItemSubType.IMAGE.name());
		letterItem.setInitialAuditInfo(auditInformationService.getLoggedInUserSid());
		Date createDate = businessDayUtil.getCurrentReferenceDate();
		letterItem.setInitiationDate(createDate);
		letterItem.setCreatedDate(createDate);
		letterItem.setWorkFlowID(TaskUniqueIdGenerator.generateAlphaNumericUniqueId(REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher));
		return letterItemRepository.save(letterItem);
	}

	@Transactional
	public void updateLetterDataStatus(CtracLetterConfirmationFile ctracLetterConfirmationFile) {
		if(!ctracLetterConfirmationFile.getFileId().equals("null")){
			List<LetterData> letterDataList = letterDataRepository.findByLetterFileRid(Long.parseLong(ctracLetterConfirmationFile.getFileId()));
			for(int i=0;letterDataList.size() >i ;i++){
				LetterData letterData =letterDataList.get(i);
				letterData.setStatus(ctracLetterConfirmationFile.getProcessingStatus());
				letterDataRepository.save(letterData);
			}
		}else{
			logger.debug("FileId is null in GDS ACK file");
		}
	}

	protected File checkGDSAckFile(File xmlFolderContentsDirectory){

		File[] xmlFolderContents = xmlFolderContentsDirectory.listFiles();
		if (xmlFolderContents.length == 1) {
			if (XMLUtil.isXmlFile(xmlFolderContents[0]) && XMLUtil.validateXML(CtracAppConstants.GDSIMAGE_XML_SCHEMA,new StreamSource(xmlFolderContents[0]))) {
				return xmlFile = xmlFolderContents[0];
			} else {
				sendNotificationEmail(XMLFILE_CONTENT_INVALID, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
				logger.debug("Invalid ACK file");
			}
		} else {
			if(xmlFolderContents.length > 1){
				sendNotificationEmail(XMLFILE_MORETHAN_ONE, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT_MORETHAN_ONE);
				logger.debug("ACK file is more than one in this path : "+xmlFolderContentsDirectory.getAbsolutePath());
			}else{
				sendNotificationEmail(XMLFILE_NOTEXIST, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT_FILENOTFFOUND);
				logger.debug("ACK file is not exist in this path : "+xmlFolderContentsDirectory.getAbsolutePath());
			}
		}

		return null;
	}

	protected File checkGDSImageFile(File zipFolderContentsDirectory){
		File[] zipFolderContents = zipFolderContentsDirectory.listFiles();
		if (zipFolderContents.length == 1) {
			if (isValidZipFile(zipFolderContents[0])) {
				return zipFile = zipFolderContents[0];
			} else {
				//sendNotificationEmail(ZIPFILE_CONTENT_INVALID, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
				logger.debug("Invalid image file");
			}
		} else {
			if(zipFolderContents.length > 1){
				sendNotificationEmail(ZIPFILE_MORETHAN_ONE, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT_ZIPMORETHAN_ONE);
				logger.debug("Image file is more than one in this path : "+zipFolderContentsDirectory.getAbsolutePath());
			}else{
				sendNotificationEmail(ZIPFILE_NOTEXIST, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT_ZIPFILENOTFOUND);
				logger.debug("Image file is not exist in this path : "+zipFolderContentsDirectory.getAbsolutePath());
			}
		}
		return null;
	}
}
