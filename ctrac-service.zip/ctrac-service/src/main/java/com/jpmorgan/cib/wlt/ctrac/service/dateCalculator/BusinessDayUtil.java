package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Component;


@Component
public class BusinessDayUtil extends AbstractDateCalculatorUtil{

		public Date getCurrentBusinessDate(){
		//TODO: refactor
		return getCurrentReferenceDate();
	}
	
	/**
	 * @param businessDays the number of calendar days to add
	 * @return the Date x number of business days in the future
	 */
	public Date addBusinessDays(int businessDays, Date start){
		
		DateTime fromDate = new DateTime(start);
	
		int counter = 0;
		while(counter < businessDays){
			
			fromDate = fromDate.plusDays(1);
			
			if(isWorkingDay(fromDate)){
				counter++;
			}
		}

		return fromDate.toDate();
	}
	
	/**
	 * @param businessDays the number of calendar days to subtract
	 * @return the Date x number of business days in the future
	 */
	public Date subtractBusinessDaysExclusive(int businessDays, Date start){
		
		DateTime fromDate = new DateTime(start);
	
		int counter = businessDays;
		while(counter > 0){
			
			fromDate = fromDate.minusDays(1);
			
			if(isWorkingDay(fromDate)){
				counter--;
			}
		}
		return fromDate.toDate();
	}
	
	public Date substractBusinessDaysInclusive(int businessDays, Date start){
		DateTime fromDate = new DateTime(start);
		int counter = businessDays;
		if(isWorkingDay(fromDate)){
			counter--;
		}
		while(counter > 0){
			fromDate = fromDate.minusDays(1);
			if(isWorkingDay(fromDate)){
				counter--;
			}
		}
		return fromDate.toDate();
	}
	
	/**
	 * Return the days between two dates
	 * 
	 * i.e. if the startDate is 06/02 and the endDate is 06/01 
	 * returns -1
	 * i.e. if the startDate is 06/01 and the endDate is 06/02
	 * returns 1
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public int getBusinessDaysBetween(Date startDate, Date endDate){
		int count = 0;
		DateTime firstDateTime =new DateTime(startDate);
		DateTime secondDateTime = new DateTime(endDate);
		LocalDate startLocalDate = firstDateTime.toLocalDate();
		LocalDate endLocalDate = secondDateTime.toLocalDate();
		if(startLocalDate.isBefore(endLocalDate)){
			while(startLocalDate.isBefore(endLocalDate)){
				if(isWorkingDay(startLocalDate.toDateTimeAtCurrentTime())){
					count++;
				}
				startLocalDate = startLocalDate.plusDays(1);
			}
			return count;
		}
		else if(startLocalDate.isAfter(endLocalDate)){
			while(startLocalDate.isAfter(endLocalDate)){
				if(isWorkingDay(startLocalDate.toDateTimeAtCurrentTime())){
					count--;
				}
				startLocalDate = startLocalDate.minusDays(1);
			}
			return count;
		}
		else{
			return 0;
		}
	}
	


	public Date getNextBusinessDate(Date curDate){
		return addBusinessDays(1, curDate);
	}
	
	public Date getPreviousBusinessDate(Date curDate){
		return subtractBusinessDaysExclusive(1,curDate);
	}
}
