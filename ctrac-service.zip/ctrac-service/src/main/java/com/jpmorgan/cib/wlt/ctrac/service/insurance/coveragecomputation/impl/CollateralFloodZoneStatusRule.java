package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import java.util.Date;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.FloodDetermination;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.FloodDeterminationRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.FloodRemapItemRepository;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;

/**
 * @author n595724
 *
 */
public  class CollateralFloodZoneStatusRule extends CollateralCoverageRule {
	
	private FloodDeterminationRepository floodDeterminationRepository;

	private static final Logger logger = Logger.getLogger(CollateralFloodZoneStatusRule.class);

	public  CollateralFloodZoneStatusRule(Collateral collateral, WorkItem triggerWorkItem,Date today){
		super(collateral,triggerWorkItem, today);
	}
	
	/**
	 * We must have at least one active loan attached to the collateral
	 */
	@Override
	public void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult globalResults) {
		init();

		/**
		 * find the latest verified flood determination attached to the insurable asset
		 */
		FloodDetermination floodDetermination =
				floodDeterminationRepository.findTop1ByCollateralRidAndStatusOrderByDateOfDeterminationDesc(
						collateral.getRid(), CoverageRequirementStatus.VERIFIED.name());
		/**
		 *if we do not need coverage, we need to cancel all the LP policy associated with the Asset
		 */
		//TODO Inquiry if we should cancel the LP policies when the flood determination is null 
		if ( /* floodDetermination == null || */ floodDetermination != null && !floodDetermination.isInFloodZone()) {
			Date cancellationEffDate = floodDetermination.getDateOfMapChange();
			if (cancellationEffDate == null) {
				logger.error("No Date of Map Change found for flood determination:" + floodDetermination.getRid());
				throw new CTracApplicationException("E0307", CtracErrorSeverity.CRITICAL);
			}
			prepareCancelCollateralLpPolicies(
					globalResults, cancellationEffDate, CancellationReason.INSURANCE_NOT_NEEDED);
			if (globalResults.getLpCoveragesToCancels().size() > 0) {
				FloodRemapItemRepository remapRepo =
						ApplicationContextProvider.getContext().getBean(FloodRemapItemRepository.class);
				FloodRemapItem floodRemapItem = remapRepo.findOne(coverageActionRequest.getTriggerWorkItemId());
				floodRemapItem.setCancellationEffDate(cancellationEffDate);
				remapRepo.save(floodRemapItem);
			}
		}

	}

	@Override
	public void init() {
		super.init();
		floodDeterminationRepository =
				ApplicationContextProvider.getContext().getBean(FloodDeterminationRepository.class);
	}

	@Override
	public Integer getPriority() {
		return 1003;
	}

}
