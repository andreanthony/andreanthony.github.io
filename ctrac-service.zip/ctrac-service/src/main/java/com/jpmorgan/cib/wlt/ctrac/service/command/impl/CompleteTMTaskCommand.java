package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.Attributes;


/**
 * 
 * @author n595724
 * This Class scope should stay "prototype";
 * if at some point we decide to make sprint manage it live circle, the scope must stay prototype
 * 
 */
public class CompleteTMTaskCommand extends AbstractCommand {

	private final Attributes attributes;
	private final TMParams tmParams;
	private final PerfectionTask perfectionTask;
	
	private static final Logger logger = Logger.getLogger(CompleteTMTaskCommand.class);
	
	public CompleteTMTaskCommand(Attributes attributes, TMParams tmParams, PerfectionTask perfectionTask){
		this(attributes, tmParams, perfectionTask, 0);
	}

	public CompleteTMTaskCommand(Attributes attributes, TMParams tmParams, PerfectionTask perfectionTask, int priority) {
		this.attributes = attributes;
		this.tmParams = tmParams;
		this.perfectionTask = perfectionTask;
		this.priority = priority;
	}
	
	
	@Override
	public void execute() {
		//TODO handle bean not found exceptions
		TMService tmService = (TMService) ApplicationContextProvider.getContext().getBean("TMService");
		boolean webservice = false;
		try{
			if (perfectionTask != null) {
				if((attributes != null && tmParams != null) && perfectionTask.getTmTaskId().equals(tmParams.getId_task())){
					logger.info("trying to complete task with tm web service : " + tmParams.getId_task());
					webservice =  true;
					tmService.completeTMTask(tmParams, attributes);						
				}else{
					logger.info("trying to complete task via jmx msg : " + perfectionTask.getTmTaskId());
					tmService.cancelTmTask(perfectionTask);
				}
			} else if (attributes != null && tmParams != null) {
				logger.info("trying to complete task with tm web service : " + tmParams.getId_task());
				webservice =  true;
				tmService.completeTMTask(tmParams, attributes);			
			} else {
				logger.error("Invalid parameters for CompleteTMTaskCommand::execute");
				throw new RuntimeException("Invalid parameters for CompleteTMTaskCommand::execute");
			}		
		} catch (Exception swallow) {			
			if(webservice){
				logger.warn("completing task with tm web service failled: trying to send a jmx msg " + tmParams.getId_task());
				try { 
					tmService.cancelTmTask(perfectionTask);
				} catch (TMServiceApplicationException ex) {
					throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		    	} catch (Exception ex) {			
					throw new CTracApplicationException("E0146", CtracErrorSeverity.APPLICATION, ex);
				}
			}else{
				logger.error("Completing task with tm web service and/or jms  failled while attempting CompleteTMTaskCommand::execute");
				throw new RuntimeException("Completing task with tm web service and/or jms  failled while attempting CompleteTMTaskCommand::execute");
			}
		}
	}

	@Override
	public int hashCode() {
		
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((attributes == null) ? 0 : attributes.hashCode());
		result = prime * result
				+ ((tmParams == null) ? 0 : tmParams.hashCode());
		result = prime * result
				+ ((perfectionTask == null) ? 0 : perfectionTask.hashCode());
		result = prime * result
				+ ((priority == null) ? 0 : priority.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompleteTMTaskCommand other = (CompleteTMTaskCommand) obj;
		if (attributes == null) {
			if (other.attributes != null)
				return false;
		} else if (!attributes.equals(other.attributes))
			return false;
		if (tmParams == null) {
			if (other.tmParams != null)
				return false;
		} else if (!tmParams.equals(other.tmParams))
			return false;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		return true;
	}

	public Attributes getAttributes() {
		return attributes;
	}

	public TMParams getTmParams() {
		return tmParams;
	}

}