package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.Collection;
import java.util.TreeSet;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import org.hibernate.validator.constraints.NotEmpty;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;

public class CustomerData  extends BaseDto implements Cloneable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private Long rid;

	@NoInvalidCharacters
	@NotEmpty(message="{invalid.customerData.name}")
	@Size(max=255, message="{invalid.customerData.name}")
	private String borrowerName;// TOdo should we remane to "name"


	@Valid
	private ContactDetailDto contactDetailDto;

	private Collection<Long> relatedCollateral = new TreeSet<Long>();

	private CustomerData loadTimeValue;

	private boolean same;

	private boolean remove;

	public String getRelatedCollateralIds() {
		StringBuffer sb = new StringBuffer();
		for (Long collateralId : relatedCollateral) {
			CtracStringUtil.addValueWithSeparator(sb, collateralId.toString(), ", ");
		}
		return sb.toString();
	}

	public CustomerData(){
		contactDetailDto = new ContactDetailDto();
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public ContactDetailDto getContactDetailDto() {
		return contactDetailDto;
	}

	public void setContactDetailDto(ContactDetailDto contactDetailDto) {
		this.contactDetailDto = contactDetailDto;
	}

	public Collection<Long> getRelatedCollateral() {
		return relatedCollateral;
	}

	public void setRelatedCollateral(Collection<Long> relatedCollateral) {
		this.relatedCollateral = relatedCollateral;
	}

	public boolean getSame() {
		return same;
	}

	public void setSame(boolean same) {
		this.same = same;
	}

	public boolean isRemove() {
		return remove;
	}

	public void setRemove(boolean remove) {
		this.remove = remove;
	}

	public boolean hasChanged(){

		if(this.loadTimeValue ==null || this.getRid()==null){
			return true;
		}

		return !deepEquals( this.loadTimeValue );
	}

	public void saveACopy () {
		if(this.getContactDetailDto()!= null){
			this.getContactDetailDto().saveACopy();
		}
		//this.loadTimeValue = (CustomerData)SerializationUtils.clone(this);
		try {
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException swallow) {
		}
	}

	private boolean deepEquals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerData other = (CustomerData) obj;

		if (borrowerName == null) {
			if (other.borrowerName != null)
				return false;
		} else if (!borrowerName.equals(other.borrowerName))
			return false;


		if (contactDetailDto == null) {
			if (other.contactDetailDto != null)
				return false;
		} else if (contactDetailDto.hasChanged() || !contactDetailDto.equals(other.contactDetailDto)){
			return false;
		}
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerData other = (CustomerData) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}


	@Override
	protected CustomerData clone() throws CloneNotSupportedException {
		return (CustomerData) super.clone();
	}


}
