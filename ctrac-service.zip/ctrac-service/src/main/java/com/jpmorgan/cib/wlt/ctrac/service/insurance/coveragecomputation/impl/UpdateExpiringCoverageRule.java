package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import java.util.Collection;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.helper.coverage.ProvidedCoverageUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;

public class UpdateExpiringCoverageRule extends InsurableAssetCoverageRule{

	public UpdateExpiringCoverageRule(
			Collateral collateral, WorkItem triggerWorkItem,
			InsurableAsset insurableAsset, CoverageActionData coverageActionData){
		super(collateral, triggerWorkItem, insurableAsset,coverageActionData);
	}
	
	/**
	 * create a new LP policy with status invoiced and effective date = old
	 * expiration date; set the old policy status to expired populate the
	 * gobalResuls accordingly;
	 * 
	 * @param gobalResuls
	 * @param missingCoverageAmount
	 * @return
	 */
	@Override
	public void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult gobalResuls) {
        Collection<ProofOfCoverage> expiringPolicies = 
        		ProvidedCoverageUtil.getExpiringProofOfCovOfType(
        				null, coverageActionData.getMaxDateForLetterProcessing(), coverageActionData.getAllActivePolicies());
		for (ProofOfCoverage expiringBorrowerPolicy : expiringPolicies) {
			gobalResuls.getPolicyToExpire().add(expiringBorrowerPolicy.getRid());
		}
	}
	
	@Override
	public Integer getPriority() {
		return 19;
	}

}
