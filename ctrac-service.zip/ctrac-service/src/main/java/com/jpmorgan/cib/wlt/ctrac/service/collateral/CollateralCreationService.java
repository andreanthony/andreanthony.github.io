package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CreateNewCollateralRecord;

public interface CollateralCreationService {
    CollateralDto createCollateral(CreateNewCollateralRecord createNewCollateralRecord);
}
