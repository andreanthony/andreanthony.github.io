package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ExcelTable;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;

import static com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.LoanSystemsOrder.*;
public class ReconExcelPremiumsSheet extends AbstractReconExcelSheet{

	private static final String SHEET_NAME = "Premiums";
	private static final int LARGE_HEADER_COL_SPAN = ReconPremiumsTableDefinition.DEFINITION.length - 1;
	private static final String TITLE = "CTRAC FLOOD POLICY PREMIUMS";
	
	
	public ReconExcelPremiumsSheet(){
		this.title = TITLE;
		this.definition = ReconPremiumsTableDefinition.DEFINITION;
	}
	
	public void insertInto(XSSFWorkbook workbook, Map<LoanSystem, List<ReconPremiumsRow>> premiums, Date reportDate, Date activityDate){
		XSSFSheet sheet = workbook.createSheet(SHEET_NAME);
		sheet.setDefaultColumnWidth(20);
		sheet.setColumnWidth(LARGE_HEADER_COL_SPAN, 40 * 256);
		int currentRow = 0;
		currentRow = insertTitle(sheet, currentRow);
		currentRow = insertBlankRow(currentRow);
		currentRow = insertDateTable(sheet, reportDate, activityDate, currentRow);
		currentRow = insertBlankRow(currentRow);
		currentRow = insertTableHeader(sheet, currentRow);
		currentRow = insertTableBody(sheet, premiums, currentRow);
	}
	
	private int insertTableBody(XSSFSheet sheet, Map<LoanSystem, List<ReconPremiumsRow>> premiums, int currentRow) {
		if(premiums == null ||  premiums.size() == 0){
			return currentRow;
		}
		for(LoanSystem loanSystem : LOAN_SYSTEM_ORDER){
			if(!premiums.containsKey(loanSystem)){
				continue;
			}
			currentRow = insertTableBody(sheet, premiums.get(loanSystem), currentRow);
			currentRow = insertTotalRow(sheet, premiums.get(loanSystem), currentRow);
			currentRow = insertBlankRow(currentRow);
		}
		return insertGrandTotalRow(sheet, premiums, currentRow);
	}
	
	
	private int insertTableBody(XSSFSheet sheet, List<ReconPremiumsRow> rows, int currentRow){
		XSSFCellStyle amountStyle = generateAmountCellStyle(sheet.getWorkbook(), true);
		XSSFCellStyle stringStyle = generateStringCellStyle(sheet.getWorkbook(), true);
		XSSFCellStyle dateStyle = generateDateCellStyle(sheet.getWorkbook(), false);
		ExcelTable excelTable = new ExcelTable(definition, rows).customStyle(FieldType.AMOUNT, amountStyle).customStyle(FieldType.STRING, stringStyle).customStyle(FieldType.DATE, dateStyle);
		return excelTable.insertBodyInto(sheet, currentRow, 0);
	}
	
	private int insertGrandTotalRow(XSSFSheet sheet, Map<LoanSystem, List<ReconPremiumsRow>> rows, int currentRow){
		BigDecimal sum = BigDecimal.ZERO;
		for(Map.Entry<LoanSystem, List<ReconPremiumsRow>> row: rows.entrySet()){
			for(ReconPremiumsRow r: row.getValue()){
				sum = sum.add(r.getPremiumAmount());
			}
		}
		return insertTotalRow(sheet, sum, currentRow, "Grand Total", true);
	}
	

	private int insertTotalRow(XSSFSheet sheet, List<ReconPremiumsRow> rows, int currentRow) {
		BigDecimal sum = BigDecimal.ZERO;
		for(ReconPremiumsRow row: rows){
			sum = sum.add(row.getPremiumAmount());
		}
		return insertTotalRow(sheet, sum, currentRow, "Total", false);
	}

}
