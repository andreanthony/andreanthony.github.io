package com.jpmorgan.cib.wlt.ctrac.service.batch;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LpInsuranceVendor;

public interface LPVendorFileGeneratorFactory {

	LPVendorFileGenerator getLPVendorFileGeneratorFactory(LpInsuranceVendor vendor);

}
