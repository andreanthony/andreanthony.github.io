package com.jpmorgan.cib.wlt.ctrac.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.FloodRemapRuleEngine;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.FloodRemapRuleEngineRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AppRuleInput;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.WorkflowStateAttributes;
import com.jpmorgan.cib.wlt.ctrac.service.specifications.FloodRemapBusinessRuleSpecs;




/**
 * @author n446693
 *
 */
@Service(value = "nextWorkflowStepRetrievalService")
public class NextWorkflowStepRetrievalService {

	private static final Logger logger = Logger.getLogger(NextWorkflowStepRetrievalService.class);
	@Autowired
	FloodRemapRuleEngineRepository floodRemapRuleEngineRepository;
	
	@Autowired protected BusinessDayUtil businessDayUtil;
	@Autowired protected CalendarDayUtil calendarDayUtil;
	
	
	@SuppressWarnings("deprecation")
	public WorkflowStateAttributes findNextWorkflowStepData (AppRuleInput appRuleInput){
		
		Specification<FloodRemapRuleEngine> allFilteringCriteria = FloodRemapBusinessRuleSpecs.deriveAllSearchCritera(appRuleInput);
		
		
		List<FloodRemapRuleEngine> oneRule = floodRemapRuleEngineRepository.findAll(allFilteringCriteria);
		
		if(oneRule.size()!=1){
			if(oneRule.isEmpty()){
				logger.debug("NO WORKFLOW STEP FOUND. Check the App Rule table.");
			}else{
				logger.debug("MULTIPLE WORKFLOW STEPS FOUND. Check the App Rule table.");
			}
			
			throw new CTracApplicationException("E0194", CtracErrorSeverity.APPLICATION);
		}
		FloodRemapRuleEngine floodRemapRuleEngine = oneRule.get(0);
		
		WorkflowStateAttributes wfSlaData = new WorkflowStateAttributes();
		
		//setting input
		wfSlaData.setCurrentWorflowStep(appRuleInput.getCurrentWorkFlowStep());
		
		
		//setting out
		wfSlaData.setTransition(floodRemapRuleEngine.getTransitionValue());
		wfSlaData.setNextWorflowStep(floodRemapRuleEngine.getNextWorkFlowStep());
		wfSlaData.setWorkflowState(floodRemapRuleEngine.getNextWorkFlowStep()); //keep for backward compatibility
		wfSlaData.setTrackingType(floodRemapRuleEngine.getTrackingType());
		wfSlaData.setTransition(floodRemapRuleEngine.getTransitionValue());
		wfSlaData.setNextTaskStatus(floodRemapRuleEngine.getNextTaskStatus());
		wfSlaData.setComments(floodRemapRuleEngine.getComments());
		
		return wfSlaData;		
		
	}		
}
