package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanType;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;


public class LoanBorrowerSectionDto extends SectionDto{

	private static final long serialVersionUID = -4486322778686021757L;

	private static final Long LOAN_RID = -1L;

	private final Collection<LoanData> activeLoansData = new ArrayList<LoanData>();

	private final Collection<LoanData> inActiveLoansData = new ArrayList<LoanData>();

	private Collection<LoanData> deletedLoans = new ArrayList<LoanData>();

	private List<String> allowedEmailDomains;

	private LoanData loanData;

	private boolean verifyMode = false;

	private boolean standardLoanExists = false;
	private boolean sbaLoanExists = false;
	private boolean chargedOffLoanExists = false;
	private boolean FNMAExists = false;
	private boolean FHMCExists = false;

	private Long collateralRid = null;
	private boolean launchingNew = false;

	public LoanBorrowerSectionDto(){
		this.sectionStatusDto = new SectionStatusDto();
		sectionStatusDto.setSectionId(CollateralDetailsSection.LOAN_BORROWER);
	}

	public LoanData getPrimaryLoan() {
        for (LoanData loan : getActiveLoansData()) {
            if (loan.isPrimary()) {
                return loan;
            }
        }
        for (LoanData loan : getInActiveLoansData()) {
            if (loan.isPrimary()) {
                return loan;
            }
        }
		return null;
	}

	public LoanData getloanData(Long rid) {
		if (LOAN_RID.equals(rid)) {
			loanData = new LoanData();
			loanData.setCancel(true);
			if (activeLoansData.isEmpty()) {
				// if no other loans then make this the primary by default
				loanData.setPrimaryFlag("Yes");
			}
			activeLoansData.add(loanData);
			return loanData;

		}
		LoanData loan = getloanData(rid, activeLoansData);
		if (loan != null) {
			return loan;
		}
        loan = getloanData(rid, inActiveLoansData);
		if (loan != null) {
			return loan;
		}
		throw new CtracAjaxException("Invalid request.");
	}

	private LoanData getloanData(Long rid, Collection<LoanData> loans) {
		for (LoanData loan : loans) {
			if (loan.getRid() != null && loan.getRid().equals(rid)) {
				return loan;
			}
		}
		return null;
	}

	public void addLoanToDele(Integer index) {

		if (index == null) {
			return;
		}

		LoanData loan = null;
		if (this.getActiveLoansData() != null && !this.getActiveLoansData().isEmpty()) {
			List<LoanData> loansDataList = (List<LoanData>) this.getActiveLoansData();
			int temp = index;
            loan = loansDataList.remove(temp);
		}
		if (loan != null && loan.getRid() != null) {
			this.getDeletedLoans().add(loan);
		}
	}


	public void addLoanToDele(LoanData loanData) {
		if (loanData != null && loanData.getRid() != null) {
			this.getDeletedLoans().add(loanData);
		}

		if (this.getActiveLoansData() != null && !this.getActiveLoansData().isEmpty()) {
			Iterator<LoanData> iter = this.getActiveLoansData().iterator();
			while(iter.hasNext()) {
				LoanData ld = iter.next();
				if(ld.equals(loanData)) {
					iter.remove();
				}
			}
		}
	}


	public boolean areAllLoansVerified() {
		for (LoanData loan : getActiveLoansData()) {
			if (loan.getStatus() == LoanStatus.PENDING_VERIFICATION) {
				return false;
			}
		}
		return true;
	}

	public boolean areAllLoansRelease() {
		for (LoanData loan : getActiveLoansData()) {
			if (StringUtils.isBlank(loan.getReleasedDate())) {
				return false;
			}
		}
		return true;
	}





	public LoanData getLoanData() {
		return loanData;
	}

	public void setLoanData(LoanData loanData) {
		this.loanData = loanData;
	}

	public Collection<LoanData> getActiveLoansData() {
		return activeLoansData;
	}

	public Collection<LoanData> getInActiveLoansData() {
		return inActiveLoansData;
	}

	public List<String> getAllowedEmailDomains() {
		return allowedEmailDomains;
	}

	public void setAllowedEmailDomains(List<String> allowedEmailDomains) {
		this.allowedEmailDomains = allowedEmailDomains;
	}

	public Collection<LoanData> getDeletedLoans() {
		return deletedLoans;
	}

	public void setDeletedLoans(Collection<LoanData> deletedLoans) {
		this.deletedLoans = deletedLoans;
	}

	public boolean isVerifyMode() {
		return verifyMode;
	}

	public void setVerifyMode(boolean verifyMode) {
		this.verifyMode = verifyMode;
	}

	public LoanData findLoanById(long loanRid) {
		for (LoanData ld : getActiveLoansData()) {
			if (loanRid == ld.getRid()) {
				return ld;
			}
		}
		return null;
	}

	private boolean checkLoanTypeExistsInActiveLoans(LoanType loanType){
		for (LoanData current : getActiveLoansData()) {
			if (loanType.getDisplayName().equalsIgnoreCase(current.getLoanType())) {
				return true;
			}
		}
		return false;
	}

	public boolean isStandardLoanExist() {
		return checkLoanTypeExistsInActiveLoans(LoanType.STANDARD);
	}

	public void setStandardLoanExists(boolean standardLoanExist) {
		this.standardLoanExists = standardLoanExist;
	}

	public boolean isSbaLoanExists() {
		return checkLoanTypeExistsInActiveLoans(LoanType.SBA);
	}

	public void setSbaLoanExists(boolean sbaLoanExists) {
		this.sbaLoanExists = sbaLoanExists;
	}

	public boolean isChargedOffLoanExists() {
		return checkLoanTypeExistsInActiveLoans(LoanType.CHARGED_OFF);
	}

	public void setChargedOffLoanExists(boolean chargedOffLoanExists) {
		this.chargedOffLoanExists = chargedOffLoanExists;
	}

	public boolean isFNMAExists() {
		return checkLoanTypeExistsInActiveLoans(LoanType.FNMA);
	}

	public void setFNMAExists(boolean fNMAExists) {
		FNMAExists = fNMAExists;
	}

	public boolean isFHMCExists() {
		return checkLoanTypeExistsInActiveLoans(LoanType.FHMC);
	}

	public void setFHMCExists(boolean fHMCExists) {
		FHMCExists = fHMCExists;
	}

	public boolean isStandardLoanExists() {
		return checkLoanTypeExistsInActiveLoans(LoanType.STANDARD);
	}

	public boolean hasExternallyAgentedMixed(LoanData newLoan) {
        int externallyAgentedCount = getExternallyAgentedCount();
        if (newLoan != null && LoanType.EXTERNALLY_AGENTED.getDisplayName().equals(newLoan.getLoanType())) {
            externallyAgentedCount++;
        }
        int totalCount = activeLoansData.size() + inActiveLoansData.size() + (newLoan != null ? 1 : 0);
        return externallyAgentedCount > 0 && externallyAgentedCount != totalCount;
	}

	private int getExternallyAgentedCount() {
        int externallyAgentedCount = 0;
        for (LoanData activeLoan : activeLoansData) {
            if (LoanType.EXTERNALLY_AGENTED.getDisplayName().equals(activeLoan.getLoanType())) {
                externallyAgentedCount++;
            }
        }
        for (LoanData inactiveLoan : inActiveLoansData) {
            if (LoanType.EXTERNALLY_AGENTED.getDisplayName().equals(inactiveLoan.getLoanType())) {
                externallyAgentedCount++;
            }
        }
        return externallyAgentedCount;
    }

	public boolean hasAllExternallyAgented() {
        int externallyAgentedCount = getExternallyAgentedCount();
        int totalCount = activeLoansData.size() + inActiveLoansData.size();
        return externallyAgentedCount > 0 && externallyAgentedCount == totalCount;
    }

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public boolean isLaunchingNew() {
        return launchingNew;
    }

    public void setLaunchingNew(boolean launchingNew) {
        this.launchingNew = launchingNew;
    }
}
