package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import java.io.Serializable;
import java.util.Collection;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LookUpCodeData;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;

public class ReferenceValues implements Serializable {

	private static final long serialVersionUID = 9137903589245540922L;
	
	private String ctracReferenceDate;
	
	private Collection<LookUpCode> blanketCoverageTypes;
	
	private Collection<LookUpCode> borrowerPolicyTypes;

	private Collection<LookUpCode> collateralTypes;
	
	private Collection<LookUpCode> collateralStatuses;
	
	private Collection<LookUpCode> coverageTypes;
	
	private Collection<LookUpCode> evidenceOfInsuranceTypes;

	private Collection<LookUpCode> insuranceTypes;
	
	private Collection<LookUpCodeData> invoicePaymentMethodTypes;
	
	private Collection<LookUpCode> jpmLienPositions;
	
	private Collection<LineOfBusinessDTO> linesOfBusiness;
	
	private Collection<LookUpCode> loanAccountingSystems;
	
	private Collection<LookUpCode> escrowTypes;
	
	private Collection<LookUpCode> loanTypes;
	
	private Collection<LookUpCode> lpInsuranceCompanies;
	
	private Collection<LookUpCode> lpPolicyTypes;
	
	private Collection<LookUpCode> proofOfPaymentTypes;
	
	private Collection<LookUpCode> propertyTypes;
	
	private Collection<LookUpCode> balanceTypes;
	
	private Collection<LookUpCodeData> refundPaymentMethodTypes;
	
	private Collection<LookUpCode> states;
	
	private Collection<LookUpCode> letterCycleWorkflowSteps;
	
	private Collection<LookUpCode> lenderPlaceReasons;

	public String getCtracReferenceDate() {
		return ctracReferenceDate;
	}

	public void setCtracReferenceDate(String ctracReferenceDate) {
		this.ctracReferenceDate = ctracReferenceDate;
	}

	public Collection<LookUpCode> getBlanketCoverageTypes() {
		return blanketCoverageTypes;
	}

	public void setBlanketCoverageTypes(Collection<LookUpCode> blanketCoverageTypes) {
		this.blanketCoverageTypes = blanketCoverageTypes;
	}

	
	public Collection<LookUpCode> getBorrowerPolicyTypes() {
		return borrowerPolicyTypes;
	}

	public void setBorrowerPolicyTypes(Collection<LookUpCode> borrowerPolicyTypes) {
		this.borrowerPolicyTypes = borrowerPolicyTypes;
	}

	public Collection<LookUpCode> getCollateralTypes() {
		return collateralTypes;
	}

	public void setCollateralTypes(Collection<LookUpCode> collateralTypes) {
		this.collateralTypes = collateralTypes;
	}

	public Collection<LookUpCode> getCoverageTypes() {
		return coverageTypes;
	}

	public void setCoverageTypes(Collection<LookUpCode> coverageTypes) {
		this.coverageTypes = coverageTypes;
	}

	public Collection<LookUpCode> getEvidenceOfInsuranceTypes() {
		return evidenceOfInsuranceTypes;
	}

	public void setEvidenceOfInsuranceTypes(Collection<LookUpCode> evidenceOfInsuranceTypes) {
		this.evidenceOfInsuranceTypes = evidenceOfInsuranceTypes;
	}

	public Collection<LookUpCode> getInsuranceTypes() {
		return insuranceTypes;
	}

	public void setInsuranceTypes(Collection<LookUpCode> insuranceTypes) {
		this.insuranceTypes = insuranceTypes;
	}

	public Collection<LookUpCodeData> getInvoicePaymentMethodTypes() {
		return invoicePaymentMethodTypes;
	}

	public void setInvoicePaymentMethodTypes(Collection<LookUpCodeData> invoicePaymentMethodTypes) {
		this.invoicePaymentMethodTypes = invoicePaymentMethodTypes;
	}

	public Collection<LookUpCode> getJpmLienPositions() {
		return jpmLienPositions;
	}

	public void setJpmLienPositions(Collection<LookUpCode> jpmLienPositions) {
		this.jpmLienPositions = jpmLienPositions;
	}

	public Collection<LineOfBusinessDTO> getLinesOfBusiness() {
		return linesOfBusiness;
	}

	public void setLinesOfBusiness(Collection<LineOfBusinessDTO> linesOfBusiness) {
		this.linesOfBusiness = linesOfBusiness;
	}

	public Collection<LookUpCode> getLoanAccountingSystems() {
		return loanAccountingSystems;
	}

	public void setLoanAccountingSystems(Collection<LookUpCode> loanAccountingSystems) {
		this.loanAccountingSystems = loanAccountingSystems;
	}

	
	public Collection<LookUpCode> getEscrowTypes() {
		return escrowTypes;
	}

	public void setEscrowTypes(Collection<LookUpCode> escrowTypes) {
		this.escrowTypes = escrowTypes;
	}

	public Collection<LookUpCode> getLoanTypes() {
		return loanTypes;
	}

	public void setLoanTypes(Collection<LookUpCode> loanTypes) {
		this.loanTypes = loanTypes;
	}

	public Collection<LookUpCode> getLpInsuranceCompanies() {
		return lpInsuranceCompanies;
	}

	public void setLpInsuranceCompanies(Collection<LookUpCode> lpInsuranceCompanies) {
		this.lpInsuranceCompanies = lpInsuranceCompanies;
	}

	public Collection<LookUpCode> getLpPolicyTypes() {
		return lpPolicyTypes;
	}

	public void setLpPolicyTypes(Collection<LookUpCode> lpPolicyTypes) {
		this.lpPolicyTypes = lpPolicyTypes;
	}

	public Collection<LookUpCode> getProofOfPaymentTypes() {
		return proofOfPaymentTypes;
	}

	public void setProofOfPaymentTypes(Collection<LookUpCode> proofOfPaymentTypes) {
		this.proofOfPaymentTypes = proofOfPaymentTypes;
	}

	public Collection<LookUpCode> getPropertyTypes() {
		return propertyTypes;
	}

	public void setPropertyTypes(Collection<LookUpCode> propertyTypes) {
		this.propertyTypes = propertyTypes;
	}

	public Collection<LookUpCodeData> getRefundPaymentMethodTypes() {
		return refundPaymentMethodTypes;
	}

	public void setRefundPaymentMethodTypes(Collection<LookUpCodeData> refundPaymentMethodTypes) {
		this.refundPaymentMethodTypes = refundPaymentMethodTypes;
	}

	public Collection<LookUpCode> getStates() {
		return states;
	}

	public void setStates(Collection<LookUpCode> states) {
		this.states = states;
	}

	public Collection<LookUpCode> getCollateralStatuses() {
		return collateralStatuses;
	}

	public void setCollateralStatuses(Collection<LookUpCode> collateralStatuses) {
		this.collateralStatuses = collateralStatuses;
	}

	public Collection<LookUpCode> getBalanceTypes() {
		return balanceTypes;
	}

	public void setBalanceTypes(Collection<LookUpCode> balanceTypes) {
		this.balanceTypes = balanceTypes;
	}

	public Collection<LookUpCode> getLetterCycleWorkflowSteps() {
		return this.letterCycleWorkflowSteps;
	}

	public void setLetterCycleWorkflowSteps(Collection<LookUpCode> letterCycleWorkflowSteps) {
		this.letterCycleWorkflowSteps = letterCycleWorkflowSteps;
	}

	public Collection<LookUpCode> getLenderPlaceReasons() {
		return lenderPlaceReasons;
	}

	public void setLenderPlaceReasons(Collection<LookUpCode> lenderPlaceReasons) {
		this.lenderPlaceReasons = lenderPlaceReasons;
	}

}
