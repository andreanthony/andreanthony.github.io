package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;

public class CoverageDetail implements Serializable {

    private static final long serialVersionUID = -4905289283650284170L;

    private String buildingCoverageAmount = CtracAppConstants.DEFAULT_AMOUNT;
    private String contentsCoverageAmount = CtracAppConstants.DEFAULT_AMOUNT;
    private String verifierBuildingCoverageAmount;
    private String verifierContentsCoverageAmount;
    private String verifierBuildingSecondTouchCoverageAmount = CtracAppConstants.DEFAULT_AMOUNT;
    private String verifierContentsSecondTouchCoverageAmount = CtracAppConstants.DEFAULT_AMOUNT;
    private String buildingName;
    private Date effectiveDate;
    private int sortOrder;
    private boolean buildingAmountMatch;
    private boolean contentAmountMatch;
    private Long buildingInsurableAssetRid;
    private Long contentsInsurableAssetRid;
    private boolean verified;
    
	public CoverageDetail(String buildingCoverageAmount, String contentsCoverageAmount, Long buildingInsurableAssetRid, Long contentsInsurableAssetRid, boolean verified, String buildingName, int sortOrder){
    	this.contentsCoverageAmount = contentsCoverageAmount;
    	this.buildingCoverageAmount = buildingCoverageAmount;
    	this.buildingInsurableAssetRid = buildingInsurableAssetRid;
    	this.contentsInsurableAssetRid = contentsInsurableAssetRid;
    	this.verified = verified;
    	this.buildingName = buildingName;
    	this.sortOrder = sortOrder;
    }
    
    public CoverageDetail(){
    	
    }
    
    public boolean isVerified() {
  		return verified;
  	}

  	public void setVerified(boolean verified) {
  		this.verified = verified;
  	}

    
    public Long getBuildingInsurableAssetRid() {
        return buildingInsurableAssetRid;
    }

    public void setBuildingInsurableAssetRid(Long buildingInsurableAssetRid) {
        this.buildingInsurableAssetRid = buildingInsurableAssetRid;
    }

    public Long getContentsInsurableAssetRid() {
        return contentsInsurableAssetRid;
    }

    public void setContentsInsurableAssetRid(Long contentsInsurableAssetRid) {
        this.contentsInsurableAssetRid = contentsInsurableAssetRid;
    }

    public String getBuildingCoverageAmount() {
        return buildingCoverageAmount;
    }

    public String getContentsCoverageAmount() {
        return contentsCoverageAmount;
    }

    public String getVerifierBuildingCoverageAmount() {
        return verifierBuildingCoverageAmount;
    }

    public String getVerifierContentsCoverageAmount() {
        return verifierContentsCoverageAmount;
    }

    public String getVerifierBuildingSecondTouchCoverageAmount() {
        return verifierBuildingSecondTouchCoverageAmount;
    }

    public String getVerifierContentsSecondTouchCoverageAmount() {
        return verifierContentsSecondTouchCoverageAmount;
    }

    public void setBuildingCoverageAmount(String buildingCoverageAmount) {
        this.buildingCoverageAmount = buildingCoverageAmount;
    }

    public void setBuildingCoverageAmount(BigDecimal buildingCoverageAmount) {
        this.buildingCoverageAmount = AmountFormatter.format(buildingCoverageAmount);
    }

    public void setVerifierBuildingCoverageAmount(String verifierBuildingCoverageAmount) {
        this.verifierBuildingCoverageAmount = verifierBuildingCoverageAmount;
    }

    public void setVerifierBuildingCoverageAmount(BigDecimal verifierBuildingCoverageAmount) {
        this.verifierBuildingCoverageAmount = AmountFormatter
                .format(verifierBuildingCoverageAmount);
    }

    public void setVerifierBuildingSecondTouchCoverageAmount(
            String verifierBuildingSecondTouchCoverageAmount) {
        this.verifierBuildingSecondTouchCoverageAmount = verifierBuildingSecondTouchCoverageAmount;
    }

    public void setVerifierBuildingSecondTouchCoverageAmount(
            BigDecimal verifierBuildingSecondTouchCoverageAmount) {
        this.verifierBuildingSecondTouchCoverageAmount = AmountFormatter
                .format(verifierBuildingSecondTouchCoverageAmount);
    }

    public void setContentsCoverageAmount(String contentsCoverageAmount) {
        this.contentsCoverageAmount = contentsCoverageAmount;
    }

    public void setContentsCoverageAmount(BigDecimal contentsCoverageAmount) {
        this.contentsCoverageAmount = AmountFormatter.format(contentsCoverageAmount);
    }

    public void setVerifierContentsCoverageAmount(String verifierContentsCoverageAmount) {
        this.verifierContentsCoverageAmount = verifierContentsCoverageAmount;
    }

    public void setVerifierContentsCoverageAmount(BigDecimal verifierContentsCoverageAmount) {
        this.verifierContentsCoverageAmount = AmountFormatter
                .format(verifierContentsCoverageAmount);
    }

    public void setVerifierContentsSecondTouchCoverageAmount(
            String verifierContentsSecondTouchCoverageAmount) {
        this.verifierContentsSecondTouchCoverageAmount = verifierContentsSecondTouchCoverageAmount;
    }

    public void setVerifierContentsSecondTouchCoverageAmount(
            BigDecimal verifierContentsSecondTouchCoverageAmount) {
        this.verifierContentsSecondTouchCoverageAmount = AmountFormatter
                .format(verifierContentsSecondTouchCoverageAmount);
    }

    public BigDecimal getBuildingCoverageAmountNumber() {
        return AmountFormatter.parse(buildingCoverageAmount);
    }

    public BigDecimal getContentsCoverageAmountNumber() {
        return AmountFormatter.parse(contentsCoverageAmount);
    }

    public BigDecimal getVerifierBuildingCoverageAmountNumber() {
        return AmountFormatter.parse(verifierBuildingCoverageAmount);
    }

    public BigDecimal getVerifierContentsCoverageAmountNumber() {
        return AmountFormatter.parse(verifierContentsCoverageAmount);
    }

    public BigDecimal getVerifierBuildingSecondTouchCoverageAmountNumber() {
        return AmountFormatter.parse(verifierBuildingSecondTouchCoverageAmount);
    }

    public BigDecimal getVerifierContentsSecondTouchCoverageAmountNumber() {
        return AmountFormatter.parse(verifierContentsSecondTouchCoverageAmount);
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public int getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(int sortOrder) {
        this.sortOrder = sortOrder;
    }

    public boolean isBuildingAmountMatch() {
        boolean buildingAmountMatch = true;
        buildingAmountMatch = getBuildingCoverageAmountNumber().compareTo(
                getVerifierBuildingCoverageAmountNumber()) == 0;
        return buildingAmountMatch;
    }

    public void setBuildingAmountMatch(boolean buildingAmountMatch) {
        this.buildingAmountMatch = buildingAmountMatch;
    }

    public boolean isContentAmountMatch() {
        boolean contentAmountMatch = true;
        contentAmountMatch = getContentsCoverageAmountNumber().compareTo(
                getVerifierContentsCoverageAmountNumber()) == 0;
        return contentAmountMatch;
    }

    public void setContentAmountMatch(boolean contentAmountMatch) {
        this.contentAmountMatch = contentAmountMatch;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((buildingCoverageAmount == null) ? 0
                        : buildingCoverageAmount.hashCode());
        result = prime
                * result
                + ((buildingInsurableAssetRid == null) ? 0
                        : buildingInsurableAssetRid.hashCode());
        result = prime
                * result
                + ((contentsCoverageAmount == null) ? 0
                        : contentsCoverageAmount.hashCode());
        result = prime
                * result
                + ((contentsInsurableAssetRid == null) ? 0
                        : contentsInsurableAssetRid.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CoverageDetail other = (CoverageDetail) obj;
        if (buildingCoverageAmount == null) {
            if (other.buildingCoverageAmount != null)
                return false;
        } else if (!buildingCoverageAmount.equals(other.buildingCoverageAmount))
            return false;
        if (buildingInsurableAssetRid == null) {
            if (other.buildingInsurableAssetRid != null)
                return false;
        } else if (!buildingInsurableAssetRid
                .equals(other.buildingInsurableAssetRid))
            return false;
        if (contentsCoverageAmount == null) {
            if (other.contentsCoverageAmount != null)
                return false;
        } else if (!contentsCoverageAmount.equals(other.contentsCoverageAmount))
            return false;
        if (contentsInsurableAssetRid == null) {
            if (other.contentsInsurableAssetRid != null)
                return false;
        } else if (!contentsInsurableAssetRid
                .equals(other.contentsInsurableAssetRid))
            return false;
        return true;
    }
    

}
