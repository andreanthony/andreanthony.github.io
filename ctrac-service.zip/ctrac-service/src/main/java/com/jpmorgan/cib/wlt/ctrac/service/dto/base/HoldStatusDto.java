package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.springframework.web.multipart.MultipartFile;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;


public class HoldStatusDto extends CtracBaseHelperData implements Serializable {
	private String borrowerName;
	private String propertyAddress;
	private String city;	
	private String zipcode;
	private String stateCode;	
	private long collateralID;
	private long holdRid;
	public long getHoldRid() {
		return holdRid;
	}

	public void setHoldRid(long holdRid) {
		this.holdRid = holdRid;
	}
	
	private String tmTaskId;
	
	private Long docRid;
	private String fileName;
	private String holdType;
	private String mode;
	
	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getHoldType() {
		return holdType;
	}

	public void setHoldType(String holdType) {
		this.holdType = holdType;
	}

	private  MultipartFile documentAttachment;
	private PerfectionTask perfectionTask;
	
    private List<LookUpCode> holdTypes ;
    private List<LookUpCode> holdPeriods;
    private List<HoldDetailsViewDto> holdDetailsViewDtoList;
    
    private TMParams tmParams;
    
    private static final long serialVersionUID = 4745787017846213869L;
	 	
	protected Set <String> getAllOptionsAsSetFromList( List<LookUpCode> input, String accessKeyType ){
        SortedSet <String> response = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
        if(input!=null){
            for(LookUpCode entry :input ){
                if("description".equalsIgnoreCase(accessKeyType)){
                    response.add(entry.getDescription());
                }
                if("code".equalsIgnoreCase(accessKeyType)){
                    response.add(entry.getCode());
                }
                //TODO need more?
            }
        }
        return response;
    }

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public long getCollateralID() {
		return collateralID;
	}

	public void setCollateralID(long collateralID) {
		this.collateralID = collateralID;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public MultipartFile getDocumentAttachment() {
		return documentAttachment;
	}

	public void setDocumentAttachment(MultipartFile documentAttachment) {
		this.documentAttachment = documentAttachment;
	}

	public List<LookUpCode> getHoldTypes() {
		return holdTypes;
	}

	public void setHoldTypes(List<LookUpCode> holdTypes) {
		this.holdTypes = holdTypes;
	}

	public List<LookUpCode> getHoldPeriods() {
		return holdPeriods;
	}

	public void setHoldPeriods(List<LookUpCode> holdPeriods) {
		this.holdPeriods = holdPeriods;
	}

	public List<HoldDetailsViewDto> getHoldDetailsViewDtoList() {
		return holdDetailsViewDtoList;
	}

	public void setHoldDetailsViewDtoList(List<HoldDetailsViewDto> holdDetailsViewDtoList) {
		this.holdDetailsViewDtoList = holdDetailsViewDtoList;
	}

	public PerfectionTask getPerfectionTask() {
		return perfectionTask;
	}

	public void setPerfectionTask(PerfectionTask perfectionTask) {
		this.perfectionTask = perfectionTask;
	}

	public String getTmTaskId() {
		return tmTaskId;
	}

	public void setTmTaskId(String tmTaskId) {
		this.tmTaskId = tmTaskId;
	}

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	public Long getDocRid() {
		return docRid;
	}

	public void setDocRid(Long docRid) {
		this.docRid = docRid;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
