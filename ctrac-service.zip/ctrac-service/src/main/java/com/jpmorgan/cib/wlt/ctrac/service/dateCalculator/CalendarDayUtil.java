package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import java.util.Calendar;
import java.util.Date;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.springframework.stereotype.Component;


@Component
public class CalendarDayUtil extends AbstractDateCalculatorUtil{

	/**
	 * @param calanderDays the number of calendar days to add
	 * @return the Date X number of calendar days in the future
	 */
	public Date addCalendarDays(int calanderDays, Date start, Boolean endOnBusinessDay){
		
		DateTime fromDate = new DateTime(start);
		fromDate = fromDate.plusDays(calanderDays);
		
		if(endOnBusinessDay){
			while(!isWorkingDay(fromDate)){
				fromDate = fromDate.minusDays(1);
			}
		}
		
		return fromDate.toDate();
	}
	
	/**
	 * @param calanderDays the number of calendar days to subtract
	 * @return the Date X number of calendar days in the past
	 */
	public Date subtractCalendarDays(int calanderDays, Date start, Boolean endOnBusinessDay){
		
		DateTime fromDate = new DateTime(start);
		fromDate = fromDate.minusDays(calanderDays);
		
		if(endOnBusinessDay){
			while(!isWorkingDay(fromDate)){
				fromDate = fromDate.minusDays(1);
			}
		}
		
		return fromDate.toDate();
	}


	public  Date getNextCalendarDate(Date referencDate) {
		return addCalendarDays(1, referencDate, false);
	}
	
	public   Date getPreviousCalendarDate(Date referencDate) {
		return subtractCalendarDays(1, referencDate, false);
	}
	
	public static int calculateDiffBetweenDates(Date start,Date end){
		int numOfDays=0;
		if(start!=null && end!=null){
			DateTime dtStart=new DateTime(start);
			DateTime dtEnd=new DateTime(end);
			numOfDays=Days.daysBetween(dtStart, dtEnd).getDays();
		}
		return numOfDays;
	}
	
	public static Date addCalendarDays(int calanderDays, Date start){
		
		DateTime fromDate = new DateTime(start);
		fromDate = fromDate.plusDays(calanderDays);
		
		return fromDate.toDate();
	}
	
	public static Date subtractCalendarDays(int calanderDays, Date start){
		
		DateTime fromDate = new DateTime(start);
		fromDate = fromDate.minusDays(calanderDays);
		
		return fromDate.toDate();
	}

	public boolean isReferenceDateAfterDate(Date date){
			return (new DateTime(getCurrentReferenceDate()).withTimeAtStartOfDay().isAfter(new DateTime(date).withTimeAtStartOfDay()));
	}


}
