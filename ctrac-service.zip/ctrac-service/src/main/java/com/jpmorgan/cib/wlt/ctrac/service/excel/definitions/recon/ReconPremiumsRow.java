package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon;

import java.math.BigDecimal;
import java.util.Date;

public class ReconPremiumsRow {
	
	private String policyNumber;
	private String loanSystem;
	private String insuredName;
	private Date policyEffectiveDate;
	private BigDecimal premiumAmount;

	public ReconPremiumsRow(String policyNumber, String loanSystem, String insuredName, Date policyEffectiveDate, BigDecimal premiumAmount){
		this.policyEffectiveDate = policyEffectiveDate;
		this.policyNumber = policyNumber;
		this.loanSystem = loanSystem;
		this.insuredName = insuredName;
		this.premiumAmount = premiumAmount;
	}
	
	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getLoanSystem() {
		return loanSystem;
	}

	public void setLoanSystem(String loanSystem) {
		this.loanSystem = loanSystem;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setIsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public Date getPolicyEffectiveDate() {
		return policyEffectiveDate;
	}

	public void setPolicyEffectiveDate(Date policyEffectiveDate) {
		this.policyEffectiveDate = policyEffectiveDate;
	}

	public BigDecimal getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

}
