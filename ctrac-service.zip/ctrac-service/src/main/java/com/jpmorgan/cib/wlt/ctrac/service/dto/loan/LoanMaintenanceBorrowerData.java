package com.jpmorgan.cib.wlt.ctrac.service.dto.loan;

import java.io.Serializable;

public class LoanMaintenanceBorrowerData implements Serializable {

	private static final long serialVersionUID = 5776566245913762790L;

	private Long customerRid;
	
	private String entityName;
	
	private String mailingAddress;

	public Long getCustomerRid() {
		return customerRid;
	}

	public void setCustomerRid(Long customerRid) {
		this.customerRid = customerRid;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	
}
