package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FileProcessingUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.CoreLogicFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.external.CoreLogicFloodRemapRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapDataExtract;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.helper.vendor.CoreLogicFile;
import com.jpmorgan.cib.wlt.ctrac.service.helper.vendor.CoreLogicReportsUtil;
import com.jpmorgan.cib.wlt.ctrac.service.helper.vendor.CoreLogicUtil;
import org.apache.commons.beanutils.BeanToPropertyValueTransformer;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service(value = "coreLogicDataExtract")
public class CoreLogicDataExtractImpl extends AbstractFloodRemapDataExtractImpl implements FloodRemapDataExtract {
	
	private static final Logger logger = Logger.getLogger(CoreLogicDataExtractImpl.class);	
	
	// Landing directories
	private static final String CORELOGIC_LANDING_ZIP_DIR = "corelogic.zipfile.landing.directory";
	private static final String CORELOGIC_LANDING_ZIP_CONTENTS_DIR = "corelogic.contents.landing.directory";
	private static final String CORELOGIC_LANDING_TXT_DIR = "corelogic.remap.landing.directory";
	private static final String CORELOGIC_LANDING_PDF_DIR ="corelogic.sfhdf.landing.directory";
	
	// Archive directories
	private static final String CORELOGIC_ARCHIVE_ZIP_DIR = "corelogic.zipfile.archive.directory";	
	private static final String CORELOGIC_ARCHIVE_ZIP_CONTENTS_DIR = "corelogic.contents.archive.directory";
	private static final String CORELOGIC_ARCHIVE_TXT_DIR ="corelogic.remap.archive.directory";
	private static final String CORELOGIC_ARCHIVE_PDF_DIR ="corelogic.sfhdf.archive.directory";
	
	private static final String INVALID_FILE = "coreLogic.email.notification.invalidFile";
	private static final String ZIPFILE_CONTENT_INVALID = "coreLogic.email.notification.invalidZipFileContent";
	private static final String EMAIL_SUBJECT = "coreLogic.email.notification.subject.fileInvalid";
	private static final String CORELOGIC_COUNT_NOT_MATCH = "coreLogic.email.notification.countNotMatch";
	private static final String CORELOGIC_REMAP_FILE_MISSMATCH = "coreLogic.email.notification.misMatchRemapFile";
	private static final String INVALID_CORELOGIC_RECORDS_FOUND = "coreLogic.email.notification.invalidrecords";
	private static final String INVALID_REMAP_FILE="coreLogic.email.notification.invalidRemap";
	private static final String CORELOGIC_VALID_FILE_NAME_PREFIX = "LOL_CL_";
	
	@Autowired private CalendarDayUtil calendarDayUtil;
	@Autowired private CoreLogicFloodRemapRepository coreLogicFloodRemapRepository;
	@Autowired private CoreLogicReportsUtil coreLogicReportsUtil;

	public CoreLogicDataExtractImpl() {
		super();
		this.remapVendor = RemapVendor.CORE_LOGIC;
	}

	@Override
	protected File[] getAllFiles() {
		return getAllFiles(CORELOGIC_LANDING_ZIP_DIR);
	}

	@Override
	protected boolean isValidZipFile(File file) {
		return isValidZipFile(file,EMAIL_SUBJECT,INVALID_FILE);
	}

	@Override
	protected boolean isValidFileName(File file) {
		return isValidFileName(file, CORELOGIC_VALID_FILE_NAME_PREFIX);
	}
	
	@Override
	protected void extractContents(File file) {
		 extractContents(file, CORELOGIC_LANDING_ZIP_CONTENTS_DIR);
	}

	@Override
	protected boolean areValidContents() {
		File contentsDirectory = new File(env.getRequiredProperty(CORELOGIC_LANDING_ZIP_CONTENTS_DIR));
		File[] contents = contentsDirectory.listFiles();
		int numTxtFiles = 0;
		int numExtraFiles = 0;
		for (File file : contents) {
			String extension = FilenameUtils.getExtension(file.getName());
			if ("txt".equalsIgnoreCase(extension)) {
				FileProcessingUtil.moveAndOverwrite(file, env.getRequiredProperty(CORELOGIC_LANDING_TXT_DIR));
				numTxtFiles++;
			} else if ("pdf".equalsIgnoreCase(extension)) {
				FileProcessingUtil.moveAndOverwrite(file, env.getRequiredProperty(CORELOGIC_LANDING_PDF_DIR));
			} else {
				logger.debug("Invalid Core Logic file type: " + extension);
				numExtraFiles++;
			}
		}
		
		if (numTxtFiles == 1 && numExtraFiles == 0) {
			return true;
		} else {
			sendNotificationEmail(ZIPFILE_CONTENT_INVALID, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
			return false;
		}
	}

	@Override
	protected void processContents() {
		Map<String, CollateralDocument> floodDeterminationsByFileName = savePDFFiles(CORELOGIC_LANDING_PDF_DIR);
		processTxtFile(floodDeterminationsByFileName);
	}

	 void processTxtFile(Map<String, CollateralDocument> floodDeterminationsByFileName) {
		logger.debug("processTxtFile::BEGIN");
		File txtFileLandingDirectory = new File(env.getRequiredProperty(CORELOGIC_LANDING_TXT_DIR));
		
		// Already validated contents, can assume exactly one text file
		File txtFile = txtFileLandingDirectory.listFiles()[0];
		try {
			CoreLogicFile coreLogicFile = getCoreLogicFileFromTextFile(txtFile);
			List<CoreLogicFloodRemap> coreLogicFloodRemaps = coreLogicFile.getFloodRemapData();
			//Validate the record count of the file matches the flood remap records
			if (coreLogicFile.getRecordCount() != null && coreLogicFloodRemaps.size() == coreLogicFile.getRecordCount()) {
				logger.info("Core logic file  : Total Number of records :"+ coreLogicFile.getRecordCount());
				List<String> floodRemapRequestNumbers = (List<String>) CollectionUtils.collect(coreLogicFloodRemaps,
						new BeanToPropertyValueTransformer("requestNum"));
				//Validate pdf files with flood remap records
				if(remapRecordsHaveCorrespondingFiles(floodRemapRequestNumbers, floodDeterminationsByFileName)){
					processCoreLogicRemapRecords(coreLogicFloodRemaps, floodDeterminationsByFileName);
				}else{
					logger.debug("Not a valid CoreLogic Flood Remap Record File: Corresponding PDF file not found");
					sendNotificationEmail(CORELOGIC_REMAP_FILE_MISSMATCH, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
				}
			} else {
				sendNotificationEmail(CORELOGIC_COUNT_NOT_MATCH, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
			}
		} catch (Exception e) {
			logger.error("Error occured while processing corelogic txt remap file", e);
			sendNotificationEmail(INVALID_REMAP_FILE, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
		}
	}

	CoreLogicFile getCoreLogicFileFromTextFile(File txtFile) throws Exception {
		return CoreLogicUtil.convertFromPipeDelimitedFile(txtFile);
	}

	@Transactional
	private void processCoreLogicRemapRecords(List<CoreLogicFloodRemap> floodRemapData, Map<String, CollateralDocument> floodDeterminationsByFileName) {
		logger.debug("processCoreLogicRemapRecords::BEGIN");
		List<CoreLogicFloodRemap> invalidFloodRemapRecords = new ArrayList<>();
		for(CoreLogicFloodRemap coreLogicFloodRemap : floodRemapData){
			coreLogicFloodRemap.setFloodRemapSFHDF(floodDeterminationsByFileName.get(coreLogicFloodRemap.getRequestNum()));
			coreLogicFloodRemap = coreLogicFloodRemapRepository.save(coreLogicFloodRemap);
			if(!isValidRemapData(coreLogicFloodRemap.getStatusChange())){
				logger.debug("Not a valid CoreLogic Flood Remap Record: " + coreLogicFloodRemap.getRid());
				invalidFloodRemapRecords.add(coreLogicFloodRemap);
			}			
		}
		if (!invalidFloodRemapRecords.isEmpty()) {
			logger.info("Core logic file  : Number of invalid records :"+ invalidFloodRemapRecords.size());
			File errorReportFile = coreLogicReportsUtil.prepareCoreLogicErrorData(invalidFloodRemapRecords);
			sendNotificationEmailAttachment(INVALID_CORELOGIC_RECORDS_FOUND, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT,errorReportFile);
		}
		logger.debug("processCoreLogicRemapRecords::END");
	}

	@Override
	protected void archiveContents() {
		FileProcessingUtil.archiveEntireDirectory(
				env.getRequiredProperty(CORELOGIC_LANDING_ZIP_CONTENTS_DIR),
				env.getRequiredProperty(CORELOGIC_ARCHIVE_ZIP_CONTENTS_DIR));
		FileProcessingUtil.archiveEntireDirectory(
				env.getRequiredProperty(CORELOGIC_LANDING_TXT_DIR),
				env.getRequiredProperty(CORELOGIC_ARCHIVE_TXT_DIR));
		FileProcessingUtil.archiveEntireDirectory(
				env.getRequiredProperty(CORELOGIC_LANDING_PDF_DIR),
				env.getRequiredProperty(CORELOGIC_ARCHIVE_PDF_DIR));
	}

	@Override
	protected void archiveFile(File file) {
		FileProcessingUtil.archiveSingleFile(
				file, env.getRequiredProperty(CORELOGIC_ARCHIVE_ZIP_DIR));
	}

	@Override
	@Transactional
	protected void updateLastFileReceivedDate() {
		updateLastFileReceivedDate(CtracAppConstants.CL_LAST_REMAP_FILE_RECEIVED_DATE);
	}

	@Override
	protected void processContents(File file) {
		//Implementation not required		
	}	

}
