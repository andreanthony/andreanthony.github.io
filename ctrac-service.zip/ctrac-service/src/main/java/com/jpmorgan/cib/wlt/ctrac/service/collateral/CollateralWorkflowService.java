package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMTaskDataParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralWorkflowParam;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;

import java.util.Date;
import java.util.List;
import java.util.Set;

public interface CollateralWorkflowService {

	/**
	 * this method will trigger corresponding collateral related workflows
	 * based on collateral workflow param
	 *
	 * @param param
	 */
	void triggerCollateralWorkflow(CollateralWorkflowParam param);

	Date getSBACoverageRequestedDate(Long collateralRid);

	boolean isSBACoverageRequested(Long collateralRid);


	/**
	 * Initiate collateral work flow from Draft to Verify
	 * @param collateralID
	 *
	 */
	void initiateVerifyCollateralWorkflow(Long collateralID, PerfectionItemSubType perfectionItemSubType,TMParams tmParams);

	/**
	 * Cancel verify collateral workflow
	 */
	void completeVerifyCollateralWorkflow(CollateralWorkflowParam param);


    /**
     * Create fiat request task if there is no fiat related task exists
     * @param collateralRid
     * @param tmTaskType
     * @param lpDueDate
     */
	void initRequiredCoverageRequestWorkFlow(WorkItem workItem, Long collateralRid, PerfectionItemSubType perfectionItemSubType, TMTaskType tmTaskType, Date lpDueDate);


	/**
	 *
	 * @param collateralRid
	 */
	void cancelRequiredCoverageRequestWorkflow(Long collateralRid);

	void cancelCollateralWorkflow(Long collateralRid);

	void completeRequiredCoverageRequestWorkflow(Set<PerfectionTask> tasks);

	void initiatePolicyRenewalWorkflow(ProofOfCoverage proofOfCoverage, PerfectionItemSubType perfectionItemSubType, WorkflowStateDefinition initialWorkFlowStepState , List<WorkflowStateDefinition> avoidIfExistingworkFlowStep);

    boolean isFiatRequested(Long collateralRid);

	Date getFiatRequestedDate(Long collateralRid);

	Set<PerfectionTask> getRequiredCoverageRequestTasks(Long collateralRid);

	Set<PerfectionTask> getAgentAndTasks(Long collateralRid);

	CollateralItem getActiveCollateralItem(Long collateralRid, List<String> workflowSteps);

	void triggerInsuranceCoverageEvaluation(Long triggerWorkItemRid, CollateralDto collateralDto);

	boolean isInValidStateForRenewal(Collateral collateral);

	Set<Collateral> removeCollateralsUnqualifiedForWorkfow(Set<Collateral> collaterals);

	void triggerInsuranceCoverageEvaluation(Long triggerWorkItemRid, CollateralDto collateralDto, Long cancelledRorrowerPolicyRid);

    void removeCoverageRequestToWorkItemLinks(ProofOfCoverageDTO proofOfCoverageData, Long collateralRid);

	CollateralItem createCollateralWorkItem(Long collateralRid, PerfectionItemSubType hold);


	void createCollateralTasks(ProofOfCoverage proofOfCoverage, List<TMTaskDataParams> tMTaskDataParams);

	void initiateCollateralWorkflow(Collateral collateral, PerfectionItemSubType perfectionItemSubType, WorkflowStateDefinition workFlowStepState,
									List<TMTaskDataParams> tMTaskDataParams, List<WorkflowStateDefinition> avoidIfExistingworkFlowStep);


	void createSleepingCollateralTasks(List<TMTaskDataParams> tMTaskDataParams, ProofOfCoverage policy);
	Set<PerfectionTask> getPreRenewalLetterTask(Long rid);
}
