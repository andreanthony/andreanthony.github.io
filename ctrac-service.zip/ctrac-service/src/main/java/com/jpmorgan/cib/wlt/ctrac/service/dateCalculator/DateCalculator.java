package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import java.util.Date;

public interface DateCalculator {

	Date addBusinessDays(int businessDays, Date start);

	Date subtractBusinessDaysExclusive(int businessDays, Date start);
	
	Date substractBusinessDaysInclusive(int businessDays, Date start);

	int getBusinessDaysBetween(Date firstDate, Date secondDate);

	Date addCalendarDays(int calanderDays, Date start, Boolean endOnBusinessDay);

	Date subtractCalendarDays(int calanderDays, Date start, Boolean endOnBusinessDay);

	Date getNextBusinessDate(Date curDate);

	Date getPreviousBusinessDate(Date curDate);

	Date getNextCalendarDate(Date referencDate);

	Date getPreviousCalendarDate(Date referencDate);
	
	Date getCurrentReferenceDate();
	
	boolean isBusinessDay(Date referencDate);
	
	/**
	 * Tests the date against current reference date WITHOUT taking into
	 * account the timestamp portion of the date.
	 * @param date is the date to compare against current reference date
	 * @return
	 */
	boolean isOnOrBeforeToday(Date date);

	Date advanceDateBasedOnCurrentRefYear(Date inputDate, int wakeUpConstant);

	
}
