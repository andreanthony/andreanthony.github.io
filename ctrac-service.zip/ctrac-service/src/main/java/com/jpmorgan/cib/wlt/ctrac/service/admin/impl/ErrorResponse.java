package com.jpmorgan.cib.wlt.ctrac.service.admin.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "number",
        "source",
        "description",
        "helpFile",
        "helpContext"
})
public class ErrorResponse {
    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Number" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="Source" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="HelpFile" type="{http://www.w3.org/2001/XMLSchema}anyType"/>
     *         &lt;element name="HelpContext" type="{http://www.w3.org/2001/XMLSchema}anyType"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     *
     *
     */

    @XmlElement(name = "Number")
    protected int number;
    @XmlElement(name = "Source", required = true)
    protected String source;
    @XmlElement(name = "Description", required = true)
    protected String description;
    @XmlElement(name = "HelpFile", required = true)
    protected Object helpFile;
    @XmlElement(name = "HelpContext", required = true)
    protected Object helpContext;

    /**
     * Gets the value of the number property.
     *
     */
    public int getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     *
     */
    public void setNumber(int value) {
        this.number = value;
    }

    /**
     * Gets the value of the source property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setSource(String value) {
        this.source = value;
    }

    /**
     * Gets the value of the description property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the helpFile property.
     *
     * @return
     *     possible object is
     *     {@link Object }
     *
     */
    public Object getHelpFile() {
        return helpFile;
    }

    /**
     * Sets the value of the helpFile property.
     *
     * @param value
     *     allowed object is
     *     {@link Object }
     *
     */
    public void setHelpFile(Object value) {
        this.helpFile = value;
    }

    /**
     * Gets the value of the helpContext property.
     *
     * @return
     *     possible object is
     *     {@link Object }
     *
     */
    public Object getHelpContext() {
        return helpContext;
    }

    /**
     * Sets the value of the helpContext property.
     *
     * @param value
     *     allowed object is
     *     {@link Object }
     *
     */
    public void setHelpContext(Object value) {
        this.helpContext = value;
    }
}
