package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ContactDetailDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;

import java.util.Collection;
import java.util.List;



/**
 * @author n595724
 *
 */
public interface LoanManagementService {

	Collection<LoanData> getLoanByCollateral(Long collateralRId);

	Collection<CustomerData> getBorrowersByLoan(Long loanRid);

	String getBranchCode(Long loanRid);

	Collection<CustomerData> geBorrowersByCollateral(Long collateralRId);

	Collection<LoanData> saveLoans(Long collateralID,Collection<LoanData> loansData);

	LoanData saveLoan(Long collateralID,LoanData loan);

	void  removeLoanCollateral(long collateralID, Collection<LoanData> loanCollateral);

    List<LoanData> getPrimaryLoans(List<CollateralDto> collateralDtoList);

	boolean hasAtLeastOneActiveLoan(Long collateralRid);

	LoanData findByRid(Long loanRid, Long collateralRid);

	Collection<LoanData> findByLoanNumber(String loanNumber);

	Collection<LoanData> findByBorrowerName(String borrowerName);

	LoanSystem getLoanSystem(Long lpPolicyRid);

}
