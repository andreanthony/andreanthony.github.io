package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Address;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ContactDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AddressRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ContactDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.AddressDataService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.ContactDetailDataService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ContactDetailDto;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ContactDetailDataServiceImpl implements ContactDetailDataService {

    @Autowired
    private AddressDataService addressDataService;
    @Autowired
    private AddressRepository addressRepository;
    @Autowired
    private ContactDetailsRepository contactDetailsRepository;
    @Autowired
    private CtracObjectMapper ctracObjectMapper;

    private static final Logger logger = Logger.getLogger(ContactDetailDataServiceImpl.class);

    @Override
    @Transactional
    public ContactDetailDto saveContactDetail(ContactDetailDto contactDetailDto) {

        logger.debug("saveContactDetail(" + contactDetailDto + ")::BEGIN");

        // 1- First save the inner properties recursively
        if (contactDetailDto.getAddress() != null) {
            addressDataService.saveAddress(contactDetailDto.getAddress());
        }

        // Then save the top level object assuming the inner properties are all
        // saved
        ContactDetails contactDetail = new ContactDetails();
        if (contactDetailDto.getRid() != null) {
            contactDetail = contactDetailsRepository.findOne(contactDetailDto.getRid());
        }

        // Even though not strictly necessary, load the attributes stored
        // previously
        if (contactDetailDto.getAddress() != null) {
            Address address = addressRepository.findOne(contactDetailDto.getAddress().getRid());
            contactDetail.setMailingAddress(address);
        }

        if (!contactDetailDto.hasChanged()) {
            return contactDetailDto;
        }

        ctracObjectMapper.map(contactDetailDto, contactDetail);

        contactDetail = contactDetailsRepository.saveAndFlush(contactDetail);
        contactDetailDto.setRid(contactDetail.getRid());
        contactDetailDto.refreshAuditUpdate(contactDetail);
        // cache a copy for comparison when saving back the object
        // if the properties values had not changed, skip saving to the DB
        contactDetailDto.saveACopy();

        logger.debug("saveContactDetail::End");

        return contactDetailDto;
    }

    @Override
    @Transactional
    public void deleteContactDetail(ContactDetailDto contactDetailDto) {

        if (contactDetailDto.getRid() != null) {
            contactDetailsRepository.delete(contactDetailDto.getRid());
        }
    }


}
