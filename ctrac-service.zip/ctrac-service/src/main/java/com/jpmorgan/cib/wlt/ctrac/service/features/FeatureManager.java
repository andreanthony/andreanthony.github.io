package com.jpmorgan.cib.wlt.ctrac.service.features;

import com.jpmorgan.cib.wlt.ctrac.dao.model.feature.FeatureSwitch;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.feature.FeatureSwitchRepository;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.List;


@Component
public class FeatureManager {

    private static final Logger LOG = Logger.getLogger(FeatureManager.class);

    private List<FeatureSwitch> featureSwitches = null;

    @Autowired
    FeatureManager(FeatureSwitchRepository featureSwitchRepository){
        try {
            featureSwitches = featureSwitchRepository.findAll();
        }catch(Exception ex){
            LOG.error("Error occurred while loading the feature switches from the database",ex);
        }
    }

    public boolean isActive(final FeatureBook feature){
        if(feature == null){
            //Unknown feature
            return false;
        }
        if(CollectionUtils.isNotEmpty(featureSwitches)){
            FeatureSwitch featureSwitch = (FeatureSwitch) CollectionUtils.find(featureSwitches, new Predicate() {
                @Override
                public boolean evaluate(Object o) {
                    FeatureSwitch featureSwitchObject = (FeatureSwitch)o;
                    return featureSwitchObject.getFeatureName().equals(feature.name());
                }
            });
            if(featureSwitch != null){
                LOG.debug("Feature " + feature.name() + " found and has status " + featureSwitch.isEnabled());
                return featureSwitch.isEnabled();
            }
        }
        LOG.debug("Feature " + feature.name() + " was not found in DB so is enabled by default");
        return true;
    }

    public boolean isActive(String feature){
        return isActive(FeatureBook.valueOf(feature));
    }




}
