package com.jpmorgan.cib.wlt.ctrac.service;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapResearchDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;

public interface FloodRemapService {

	// Responsible for preparing the ResearchItem page
	public FloodRemapResearchDto populateResearchItemData(TMParams tmParams); 
	
	public boolean isValidForLinking(FloodRemapResearchDto floodRemapResearchDto, Long collateralId);
	
	//Responsible for saving response research
	public void processResearchResponse(FloodRemapResearchDto floodRemapResearchData);
	
}
