package com.jpmorgan.cib.wlt.ctrac.service.batch.remap.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LobAvailability;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.LobAvailabilityRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapLineOfBusinessConverter;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessCategory;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by E704298 on 8/21/2017.
 */
@Service
public class RemapLineOfBusinessConverterImpl implements RemapLineOfBusinessConverter {

    private static final Logger logger = Logger.getLogger(RemapLineOfBusinessConverterImpl.class);

    public static final String UNKNOWN_LOB = "Unknown";

    @Autowired
    private LineOfBusinessService lobService;

    @Autowired
    private LobAvailabilityRepository lobAvailabilityRepository;

    @Override
    public String convertToDescription(String code, LineOfBusinessCategory lobCategory) {
        if (lobCategory == LineOfBusinessCategory.CORE_LOGIC || lobCategory == LineOfBusinessCategory.SERVICE_LINK) {
            List<LobAvailability> lobAvailabilities = lobAvailabilityRepository.findByCategoryAndServicerCode(lobCategory.name(), code);
            if (lobAvailabilities.size() > 1) {
                logger.debug("More than 1 mapping found for category and code: " + lobCategory.name() + ", " + code + "; using first found");
            }
            if (!lobAvailabilities.isEmpty()) {
                return lobAvailabilities.get(0).getLineOfBusiness().getCode();
            }
        } else {
            LineOfBusinessDTO lob = lobService.findByCode(code);
            if (lob != null) {
                return lob.getCode();
            }
        }
        logger.debug("No mapping found for category and code: " + lobCategory.name() + ", " + code + "; using Unknown");
        return null;
    }

    @Override
    public String getUnknownLOB() {
        return UNKNOWN_LOB;
    }

}
