package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import org.apache.commons.lang.StringUtils;

public class BaseDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long rid;

	private Date updatedDate;

	private Date insertedDate;

	private String insertedBy;

	private String updatedBy;


    private static final String FORMATTER= CtracAppConstants.DATE_FORMAT_US;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void refreshAuditUpdate(CtracBaseEntity entity){
	    if (insertedDate == null) {
	        insertedDate =  entity.getInsertedDate();
	    }
	    if (StringUtils.isBlank(this.insertedBy)) {
			insertedBy = entity.getInsertedBy();
		}
	    updatedDate = entity.getUpdatedDate();
	    updatedBy = entity.getUpdatedBy();
	}


	public String getFormatedInsertedDate(){

	  String result="";
	  if(this.insertedDate!=null){
	    try {
           result=  DateFormatter.toString(FORMATTER, this.insertedDate);
         } catch (Exception swallow) {}
	   }
	  return result;
	}

	public String getFormatedUpdatedDate(){
	   String result="";
	   if(this.updatedDate!=null){
	      try {
             result=  DateFormatter.toString(FORMATTER, this.updatedDate);
          } catch (Exception swallow) {}
	    }
	   return result;
	}



}
