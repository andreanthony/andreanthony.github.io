package com.jpmorgan.cib.wlt.ctrac.service;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.service.aspect.AuditInformationBean;

public interface AuditInformationService {

	String getLoggedInUserSid();

	void setLoggedInUserSid(String loggedInUser);

	void updateAuditInfo(CtracBaseEntity entity);
	void setAuditInformation(String loggedInUser, String firstName, String LastName);
	AuditInformationBean getAuditInformation();


	}
