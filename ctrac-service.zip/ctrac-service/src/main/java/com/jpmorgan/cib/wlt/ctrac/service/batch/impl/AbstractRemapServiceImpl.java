package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.CoreLogicFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.ServiceLinkFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.FloodRemapRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.FloodRemapItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapLineOfBusinessConverter;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CompleteTaskData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessCategory;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.Attributes;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TaskUniqueIdGenerator;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Arrays;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.*;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.COMPLETE;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.NEW_ITEM;

public abstract class AbstractRemapServiceImpl {
	private static final Logger logger = Logger.getLogger(AbstractRemapServiceImpl.class); 
	
	private static final int REMAP_TASK_UNIQUE_ID_LENGTH = 6;
	@Autowired private OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher;
	
	@Autowired protected FloodRemapRepository floodRemapRepository;
	@Autowired protected FloodRemapItemRepository floodRemapItemRepository;
	@Autowired protected TMService tmService;
	@Autowired protected TaskService taskService;
	@Autowired protected CtracObjectMapper ctracObjectMapper;
	@Autowired protected FloodEmailService floodEmailService;
	@Autowired protected LookupCodeRepository lookupCodeRepository;
	@Autowired protected CalendarDayUtil calendarDayUtil;
	@Autowired protected PerfectionTaskRepository perfectionTaskRepository;
	@Autowired protected DateCalculator dateCalculator;
    @Autowired protected RemapLineOfBusinessConverter remapLineOfBusinessConverter;
    @Autowired protected PerfectionTaskService perfectionTaskService;

	@Resource protected Environment env;

	/**
	 * This method add the remap tasks into FloodRemapTask table, generate IBML
	 * message, validate IBML message, send the message to TM , log message
	 * into database table and update the remap processing status in the
	 * FloodRemap table.
	 * 
	 * @param floodRemap
	 * @date 11-Sep-2013
	 */
	@Transactional( value="transactionManager", propagation =Propagation.REQUIRES_NEW)
	protected PerfectionTask createNewTaskInTM(FloodRemap floodRemap) {

		//1.Create FloodRemap Item 
		PerfectionTask perfectionTask = null;
		try {
			FloodRemapItem floodRemapItem = new FloodRemapItem();
			ctracObjectMapper.map(floodRemap,floodRemapItem);
			floodRemapItem.setInitiationDate(dateCalculator.getCurrentReferenceDate());
			floodRemapItem.setWorkFlowID(TaskUniqueIdGenerator.generateAlphaNumericUniqueId(REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher));
			floodRemapItem.setFloodRemap(floodRemap);
			//set Flood Remap Status Change
			LookUpCode statusDesciption = lookupCodeRepository.findByCodeAndCodeSet(floodRemap.getStatusChange(), CODE_SET_REMAP);
			floodRemapItem.setPerfectionType(PerfectionItemType.FLOOD_REMAP.name());
			//FIXME
			floodRemapItem.setStatusChange(statusDesciption);
			if(TMTaskType.FLOOD_INSURANCE.name().equals(floodRemap.getTmTaskType())){
				floodRemapItem.setPerfectionSubType(PerfectionItemSubType.FLOOD_RENEWAL.name());
			}else{
				floodRemapItem.setPerfectionSubType(PerfectionItemSubType.REMAP.name());
			}	
			floodRemapItem.setInitialAuditInfo(floodRemap.getInsertedBy());	
				
			// Set processing status to Y and save
			floodRemap.setProcessingStatus("Y");
			floodRemapItem.setRemapCategory(getRemapFloodZoneStatus(floodRemap));
			floodRemap = floodRemapRepository.save(floodRemap);
			
			// Save flood remap item to DB
			floodRemapItem = floodRemapItemRepository.save(floodRemapItem);
			//2.Create TMPerfection Task 
			TMTaskType tmTaskType = TMTaskType.valueOf(floodRemap.getTmTaskType());
			perfectionTask = tmService.createTask(tmTaskType, floodRemapItem, NEW_ITEM.getFloodRemapTaskState());
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
		}
			//return tmService.createTask(tmTaskType, floodRemapItem, NEW_ITEM.getFloodRemapTaskState());
		return perfectionTask;
	}

	protected void validateTMParams(TMParams TMParams) {
		if(TMParams == null || TMParams.getId_task() == null){
			logger.error("Task UUID from TM is null");
			throw new CTracApplicationException("E0109", CtracErrorSeverity.CRITICAL);
		}
		
		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskIdAndTaskStatusIn(
				TMParams.getId_task(), Arrays.asList(TaskStatus.OPEN.toString(), TaskStatus.SLEEPING.toString()));
		if (perfectionTask == null) {
			logger.error("Task not found for the given UUID: " + TMParams.getId_task());
			throw new CTracApplicationException("E0111", CtracErrorSeverity.APPLICATION);
		}
	}

	/**
	 * This method is used to compelte aggregated task and move child to the next workflow step
	 */
    // the workflow engine should return 2 command to do this
	@Deprecated
	protected void completeAggregatedTaskAndMoveChildToNextWorkflowStep(String perfectionTaskUUID, TaskRelationType parentToChildRelation) {
		logger.info("completeParentAndMoveChildToNextDormentWorkflowStep::Start()");
		PerfectionTask perfectionTask = getPerfectionTaskByUUID(perfectionTaskUUID);
        perfectionTaskService.closeTask(perfectionTask,null);
		logger.debug("Parent and Child Perfection tasks saved successfully for parent task: " + perfectionTask.getRid());
		logger.info("completeParentAndMoveChildToNextDormentWorkflowStep::End()");
	}
	
	public void completeTMTask(TMParams tmParams) {
		try {
			Attributes tmAttributes = new Attributes();
			tmAttributes.getTaskAttributes().put("id_src_task_status","Completed");
			tmService.updateAttributes(tmAttributes, tmParams);
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {			
			throw new CTracApplicationException("E0353", CtracErrorSeverity.APPLICATION, ex);
		}
	}
	
	protected PerfectionTask getPerfectionTaskByUUID(String tmTaskId) {
		return perfectionTaskRepository.findByTmTaskId(tmTaskId);
	}

	protected void setRemapLineOfBusiness(FloodRemap floodRemap) {
		LineOfBusinessCategory lobCategory = LineOfBusinessCategory.MANUAL_REMAP;
		if (floodRemap.getFloodRemapLandingRId() == null) {
            lobCategory = LineOfBusinessCategory.MANUAL_REMAP;
		} else if (CoreLogicFloodRemap.CORE_LOGIC_SOURCE_SYSTEM.equals(floodRemap.getSourceSystem())) {
			lobCategory = LineOfBusinessCategory.CORE_LOGIC;
		} else if (ServiceLinkFloodRemap.SERVICE_LINK_SOURCE_SYSTEM.equals(floodRemap.getSourceSystem())) {
			lobCategory = LineOfBusinessCategory.SERVICE_LINK;
		}
		floodRemap.setLineOfBusiness(
				remapLineOfBusinessConverter.convertToDescription(floodRemap.getDeptCode(), lobCategory));
	}
	
	protected String getRemapFloodZoneStatus(FloodRemap floodRemap) {
		if (O2I.equals(floodRemap.getStatusChange().trim()) || P2I.equals(floodRemap.getStatusChange().trim())
				|| O2P.equals(floodRemap.getStatusChange().trim()) || I2P.equals(floodRemap.getStatusChange().trim())) {
			return FLOOD_ZONE_STATUS_IN;
		}		
		if (TMTaskType.FLOOD_INSURANCE.name().equals(floodRemap.getTmTaskType())) {
			return FLOOD_ZONE_STATUS_IN;
		}
		return FLOOD_ZONE_STATUS_OUT;
	}
	
	
}
