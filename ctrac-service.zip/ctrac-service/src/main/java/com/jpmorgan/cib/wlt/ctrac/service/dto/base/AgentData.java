package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import org.apache.log4j.Logger;

import javax.validation.Valid;
import java.io.Serializable;

public class AgentData implements Serializable, Cloneable{

	private static final Logger logger = Logger.getLogger(AgentData.class);
	/**
     * 
     */
    private static final long serialVersionUID = 1L;

	private Long rid;

	@Valid
	private ContactDetailDto contactDetailDto;

    private AgentData loadTimeValue;
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}
	/**
	 * @return the contactDetailDto
	 */
	public ContactDetailDto getContactDetailDto() {
		return contactDetailDto;
	}

	/**
	 * @param contactDetailDto the contactDetailDto to set
	 */
	public void setContactDetailDto(ContactDetailDto contactDetailDto) {
		this.contactDetailDto = contactDetailDto;
	}
	
	public void copy(AgentData primaryBorrower) {
		this.contactDetailDto =  primaryBorrower.getContactDetailDto();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgentData other = (AgentData) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

	public void saveACopy() {
	    if (this.getContactDetailDto() != null) {
            this.getContactDetailDto().saveACopy();
        }        
        try {
            this.loadTimeValue = this.clone();
        } catch (CloneNotSupportedException e) {
			logger.error(e.getMessage(), e);
		}
	}

    public boolean hasChanged() {
        if (this.loadTimeValue == null || this.getRid() == null) {
            return true;
        }

		if (contactDetailDto != null && contactDetailDto.hasChanged()){
        	return true;
		}
        return !deepEquals( this.loadTimeValue );
    }
    
    private boolean deepEquals(AgentData obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AgentData other = (AgentData) obj;
        if (contactDetailDto == null) {
            if (other.contactDetailDto != null)
                return false;
        } else if (!contactDetailDto.equals(other.contactDetailDto))
            return false;
        if (rid == null) {
            if (other.rid != null)
                return false;
        } else if (!rid.equals(other.rid))
            return false;
        return true;
    }

    @Override
    protected AgentData clone() throws CloneNotSupportedException {
        return (AgentData) super.clone();
    }
    
}
