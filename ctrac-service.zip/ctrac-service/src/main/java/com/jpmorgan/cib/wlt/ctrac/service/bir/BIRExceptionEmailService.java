package com.jpmorgan.cib.wlt.ctrac.service.bir;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRAcceptedPolicyEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;

public interface BIRExceptionEmailService {

	BIRExceptionEmailDTO populateExceptionEmailData(
			WorkItem agentResponseItem, TaskState currentTaskState, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);

	BIRAcceptedPolicyEmailDTO populateAcceptedPolicyWithNoExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
}
