package com.jpmorgan.cib.wlt.ctrac.service.collateral.details.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.SectionStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.DeterminationDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.SectionStatusRepository;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.ReviewCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus.*;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.NEW_ITEM;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.VERIFY_RESEARCH;

@Service(value = "collateralDetailsStatusService")
public class CollateralDetailsStatusServiceImpl implements CollateralDetailsStatusService {

	private static final Logger logger = Logger.getLogger(CollateralDetailsStatusServiceImpl.class);

	@Autowired private ActivePolicyService activePolicyService;
	@Autowired private AuditInformationService auditInformationService;
	@Autowired private CollateralInsuranceRepository collateralInsuranceRepository;
	@Autowired private CollateralRepository collateralRepository;
	@Autowired private CollateralWorkflowService collateralWorkflowService;
	@Autowired private CtracObjectMapper ctracObjectMapper;
	@Autowired private InsuranceMngtService insuranceMngtService;
	@Autowired private ReviewCollateralService reviewCollateralService;
	@Autowired private SectionStatusRepository sectionStatusRepository;
	@Autowired private ViewDataRetrievalService viewDataRetrievalService;
	@Autowired private CalendarDayUtil calendarDayUtil;

    private static final Map<VerificationStatus, VerificationStatus> sectionStatusTransition;
    static{
    	sectionStatusTransition = new HashMap<VerificationStatus, VerificationStatus>();
    	sectionStatusTransition.put(DRAFT, PENDING_VERIFICATION);
    	sectionStatusTransition.put(PENDING_VERIFICATION, VERIFIED);
    }

    @Override
	@Transactional
	public void initAllCollateralSectionsStatus(Long collateralId) {
		logger.debug("initCollateralDetailSections::BEGIN");
		Collateral collateral = collateralRepository.findOne(collateralId);
		List<SectionStatus> sections = sectionStatusRepository.findByCollateral(collateral);
		if (sections != null && !sections.isEmpty()) {
			return;
		}
		sections = new ArrayList<SectionStatus>();
		for (CollateralDetailsSection section : CollateralDetailsSection.values()) {
			//for now WORKFLOW_DETAILS section does not need to be verified TODO review requirements
			String verificationStatus = DRAFT.name();
			if(CollateralDetailsSection.WORKFLOW_DETAILS.equals(section)) {
				verificationStatus = VERIFIED.name();
			}
			sections.add(new SectionStatus(collateral, section.name(),
					verificationStatus, auditInformationService.getLoggedInUserSid(), new Date()));
		}
		sectionStatusRepository.save(sections);
		logger.debug("initCollateralDetailSections::END");
	}

	@Override
    @Transactional(readOnly = true)
	public void loadAllCollateralSectionsStatus(CollateralDto collateralDto, List<SectionStatusDto> sectionStatusDtos) {
		logger.debug("loadAllCollateralSectionsStatus::BEGIN");
		if (collateralDto == null || collateralDto.getRid() == null ||
				sectionStatusDtos == null || sectionStatusDtos.isEmpty()) {
        	return;
        }
		Map<String, SectionStatusDto> sectionStatusDtosById = new HashMap<String, SectionStatusDto>();
    	List<SectionStatus> sectionStatuses = findSectionStatuses(
    			collateralDto.getRid(), sectionStatusDtos, sectionStatusDtosById);
    	mapSectionStatusesIntoDtos(sectionStatuses, sectionStatusDtosById);
    	collateralDto.setShowVerify(showSubmitForVerification(sectionStatusDtos));
    	logger.debug("loadAllCollateralSectionsStatus::END");
	}

	private List<SectionStatus> findSectionStatuses(Long collateralRid,
			List<SectionStatusDto> sectionStatusDtos, Map<String, SectionStatusDto> sectionStatusDtosById) {
		Set<String> sectionIds = new HashSet<String>();
    	for (SectionStatusDto sectionStatusDto : sectionStatusDtos) {
    		String sectionId = sectionStatusDto.getSectionId().name();
    		sectionIds.add(sectionId);
    		sectionStatusDtosById.put(sectionId, sectionStatusDto);
    	}
    	return sectionStatusRepository.findByCollateralRidAndSectionIdIn(collateralRid, sectionIds);
	}

	private void mapSectionStatusesIntoDtos(List<SectionStatus> sectionStatuses,
			Map<String, SectionStatusDto> sectionStatusDtosById) {
		for (SectionStatus sectionStatus : sectionStatuses) {
    		String sectionStatusId = sectionStatus.getSectionId();
    		if (!sectionStatusDtosById.containsKey(sectionStatusId)) {
    			logger.error("Cannot find SectionStatusDto for SectionStatus ID: " + sectionStatusId);
    		}
    		SectionStatusDto sectionStatusDto = sectionStatusDtosById.get(sectionStatusId);
			ctracObjectMapper.map(sectionStatus, sectionStatusDto);
    		sectionStatusDto.setShowVerify(getShowVerification(sectionStatusDto));
    	}
	}

	private boolean showSubmitForVerification(List<SectionStatusDto> sectionStatusDtos) {
		for (SectionStatusDto sectionStatusDto : sectionStatusDtos) {
			if (sectionStatusDto.getStatusId() != DRAFT) {
				return false;
			}
		}
		return true;
	}

	@Override
	@Transactional
	public void advanceAllSections(CollateralDto collateralDto, List<SectionStatusDto> sectionStatusDtos) {
		logger.debug("advanceAllSectionsStatusAndCollateralStatus::BEGIN Collateral ID: " + collateralDto.getRid());
		for (int i = 0; i< sectionStatusDtos.size(); i++) {
			advanceSectionStatus(sectionStatusDtos.get(i));
		}
		collateralDto.setShowVerify(false);
    	logger.debug("advanceAllSectionsStatusAndCollateralStatus::END Collateral ID: "+ collateralDto.getRid());
	}

	@Override
	@Transactional
	public CollateralWorkflowParam advanceSection(CollateralDto collateralDto, TMParams tmParams,
			SectionStatusDto sectionStatusDto, CollateralScreenAction action) {
		logger.debug("advanceSectionStatusAndCollateralStatus::BEGIN Section Id: " + sectionStatusDto.getSectionId().name());
		CollateralWorkflowParam param = new CollateralWorkflowParam();
		Long collateralRid = collateralDto.getRid();
		param.setAction(action);
		param.setCollateralDto(collateralDto);
		if (sectionStatusDto.getStatusId() == DRAFT) {
			sectionStatusDto.setModifiedBy(auditInformationService.getLoggedInUserSid());
			sectionStatusDto.setModifiedDate(new Date());
			saveSectionStatus(sectionStatusDto);
			return param;
		}
		if (CollateralScreenAction.VERIFY == action) {
			sectionStatusDto.setVerifiedBy(auditInformationService.getLoggedInUserSid());
			sectionStatusDto.setVerifiedDate(new Date());
			advanceSectionStatus(sectionStatusDto);
			reviewCollateralService.advancePendingVerifyCollateral(collateralRid);
		} else if (CollateralScreenAction.EDIT == action) {
			if (CollateralDetailsSection.getSectionsVerifiedAllAtOnce().contains(sectionStatusDto.getSectionId())) {
				sectionStatusDto.setStatusId(PENDING_VERIFICATION);
				sectionStatusDto.setModifiedBy(auditInformationService.getLoggedInUserSid());
				sectionStatusDto.setModifiedDate(new Date());
			}
			saveSectionStatus(sectionStatusDto);
		} else {
			throw new CTracApplicationException("NOPIMPL", CtracErrorSeverity.APPLICATION);
		}
		checkAllSectionsStatus(collateralRid, param);
		Date releaseDate = DateConverter.convert(collateralDto.getReleaseDate());
		checkReadyForRelease(collateralRid, releaseDate, param);

		param.setTmParams(tmParams);
		logger.debug("advanceSectionStatusAndCollateralStatus::END Section Id: " + sectionStatusDto.getSectionId().name());
		return param;
	}


	// This is used for concurrency check
	@Override
	@Transactional
	public void saveSectionsStatus(List<SectionStatusDto> sectionStatusDtos) {
		for (SectionStatusDto sectionStatusDto: sectionStatusDtos) {
			saveSectionStatus(sectionStatusDto);
		}
	}

	private void checkAllSectionsStatus(Long collateralRid, CollateralWorkflowParam param){
		logger.debug("checkAllSectionStatus::BEGIN");
		List<SectionStatus> sectionsStatuses = sectionStatusRepository.findByCollateralRid(collateralRid);
		param.setAllVerified(areAllSectionsVerified(sectionsStatuses));
		logger.debug("checkAllSectionStatus::END");
	}

	private void checkReadyForRelease(Long collateralRid, Date releaseDate, CollateralWorkflowParam param){
		logger.debug("checkAllSectionStatus::BEGIN");
		param.setReadyForRelease(false);
		if(hasEnoughVerifiedForRelease(collateralRid)){
			Date referenceDate = calendarDayUtil.getCurrentReferenceDate();
			if(releaseDate!= null && !releaseDate.after(referenceDate)){
				param.setReadyForRelease(true);
			}
		}
		logger.debug("checkAllSectionStatus::END");
	}

	private boolean hasEnoughVerifiedForRelease(Long collateralRid) {
		List<SectionStatus> sectionsStatuses = sectionStatusRepository.findByCollateralRid(collateralRid);
		return areSectionsVerified(sectionsStatuses, CollateralDetailsSection.getCheckForReleaseCollateralSections());
	}

	private void advanceSectionStatus(SectionStatusDto sectionStatusDto) {
		VerificationStatus newSectionStatus = sectionStatusTransition.get(sectionStatusDto.getStatusId());
		if (newSectionStatus == null) {
			logger.debug("null transition");
			return;
		}
		sectionStatusDto.setStatusId(newSectionStatus);
		if (sectionStatusDto.getSectionId() == CollateralDetailsSection.FLOOD_HAZARD_DETERMINATION_FORM &&
				newSectionStatus == PENDING_VERIFICATION) {
			List<DeterminationDetailsViewData> floodDeterminations =
					viewDataRetrievalService.findDeterminationsByCollateralRidAndStatus(
							sectionStatusDto.getCollateralRid(), "PENDING_VERIFICATION");
			if (floodDeterminations != null && floodDeterminations.isEmpty()) {
				sectionStatusDto.setStatusId(VerificationStatus.VERIFIED);
			}

		} else if (sectionStatusDto.getSectionId() == CollateralDetailsSection.REQUIRED_INSURANCE_COVERAGE &&
				newSectionStatus == PENDING_VERIFICATION) {
			List<RequiredCoverageViewDto> requiredCoverages =
					viewDataRetrievalService.getRequiredCoverageByStatus(
							sectionStatusDto.getCollateralRid(), "PENDING_VERIFICATION");
			if (requiredCoverages != null && requiredCoverages.isEmpty()) {
				sectionStatusDto.setStatusId(VerificationStatus.VERIFIED);
			}
		} else if (sectionStatusDto.getSectionId() == CollateralDetailsSection.INSURANCE_POLICIES &&
				newSectionStatus == PENDING_VERIFICATION) {
			List<ProofOfCoverageDTO> proofsOfCoverage =
					insuranceMngtService.findActiveByCollateral(sectionStatusDto.getCollateralRid());
			if (proofsOfCoverage != null && proofsOfCoverage.isEmpty()) {
				sectionStatusDto.setStatusId(VerificationStatus.VERIFIED);
			}
		}
		saveSectionStatus(sectionStatusDto);
	}

	private Boolean getShowVerification(SectionStatusDto sectionStatusDto){
		return sectionStatusDto.getStatusId() == PENDING_VERIFICATION &&
				!auditInformationService.getLoggedInUserSid().equals(sectionStatusDto.getModifiedBy());
	}

	private void saveSectionStatus(SectionStatusDto sectionStatusDto) {
		SectionStatus sectionStatus = ctracObjectMapper.map(sectionStatusDto, SectionStatus.class);
		sectionStatus.setCollateral(collateralRepository.findOne(sectionStatusDto.getCollateralRid()));
		sectionStatus = sectionStatusRepository.saveAndFlush(sectionStatus);
		sectionStatusDto.setRid(sectionStatus.getRid());
		sectionStatusDto.refreshAuditUpdate(sectionStatus);
	}

	@Override
	@Transactional
	public void updateLoanBorrowerSection(CollateralDetailsMainDto collateralDetailsData) {
		CollateralScreenAction action = CollateralScreenAction.EDIT;
		LoanBorrowerSectionDto loanBorrowerSectionData = collateralDetailsData.getLoanBorrowerSectionData();
		SectionStatusDto sectionStatusDto = loanBorrowerSectionData.getSectionStatusDto();
		if (!loanBorrowerSectionData.isVerifyMode()) {
			if (sectionStatusDto.getStatusId() != DRAFT) {
				sectionStatusDto.setStatusId(PENDING_VERIFICATION);
			}
			sectionStatusDto.setModifiedBy(auditInformationService.getLoggedInUserSid());
		} else if (loanBorrowerSectionData.areAllLoansVerified()) {
			action = CollateralScreenAction.VERIFY;
			loanBorrowerSectionData.setVerifyMode(false);
		}
		CollateralWorkflowParam param = advanceSection(collateralDetailsData.getCollateralDto(),
				collateralDetailsData.getTmParams(), sectionStatusDto, action);
		collateralWorkflowService.triggerCollateralWorkflow(param);

        /**
         * if we are verifying and all loan are released, trigger C3
         * TODO move the method advance collateral status so that we
         * can enforce the dependency on basic sections being verified
         */
		if (action == CollateralScreenAction.VERIFY) {
			LoanBorrowerSectionDto loanSection = collateralDetailsData.getLoanBorrowerSectionData();
			if (loanSection.areAllLoansVerified() && loanSection.areAllLoansRelease()) {
				collateralWorkflowService.triggerInsuranceCoverageEvaluation(null, collateralDetailsData.getCollateralDto());
			}
		}
	}

	@Override
	@Transactional
	public void updateInsurancePoliciesSection(CollateralDto collateralDto, CollateralScreenAction action, TMParams tmParams) {
		Long collateralRid = collateralDto.getRid();
		SectionStatus sectionStatus = sectionStatusRepository.findByCollateralRidAndSectionId(
				collateralRid, CollateralDetailsSection.INSURANCE_POLICIES.name());
		SectionStatusDto sectionStatusDto = ctracObjectMapper.map(sectionStatus, SectionStatusDto.class);
		if (action == CollateralScreenAction.EDIT) {
			if (sectionStatusDto.getStatusId() != DRAFT) {
				sectionStatusDto.setStatusId(PENDING_VERIFICATION);
			}
			sectionStatusDto.setModifiedBy(auditInformationService.getLoggedInUserSid());
		} else if (action == CollateralScreenAction.VERIFY && !areAllPoliciesVerified(collateralRid)) {
			action = CollateralScreenAction.EDIT;
		}
		CollateralWorkflowParam param = advanceSection(collateralDto, tmParams, sectionStatusDto, action);
		collateralWorkflowService.triggerCollateralWorkflow(param);
	}

	private boolean areAllPoliciesVerified(Long collateralRid) {
		List<CollateralInsuranceViewData> collateralInsuranceViewData =
				collateralInsuranceRepository.findByCollateralRid(collateralRid);
		for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceViewData) {
			PolicyStatus policyStatus = activePolicyService.getPolicyStatus(
					collateralInsurance.getProofOfCoverage(), collateralRid);
			if (policyStatus == PolicyStatus.PENDING_VERIFICATION) {
				return false;
			}
		}
		return true;
	}

	@Override
	@Transactional
	public boolean isValidForLinking(Long collateralId, WorkflowStateDefinition workflowStep) {
		List<SectionStatus> sectionStatuses = sectionStatusRepository.findByCollateralRid(collateralId);
		if (workflowStep == NEW_ITEM) {
			return !isAnySectionInDraft(sectionStatuses);
		} else if (workflowStep == VERIFY_RESEARCH) {
			return areBasicSectionsVerified(sectionStatuses);
		}
		return false;
	}

	private boolean isAnySectionInDraft(List<SectionStatus> sectionStatuses) {
		Set<CollateralDetailsSection> nonDraftSections = new HashSet<CollateralDetailsSection>();
		for (SectionStatus sectionStatus : sectionStatuses) {
			CollateralDetailsSection section = CollateralDetailsSection.valueOf(sectionStatus.getSectionId());
			if (CollateralDetailsSection.getAllCollateralSections().contains(section) &&
					!DRAFT.name().equals(sectionStatus.getStatusId())) {
				nonDraftSections.add(section);
			}
		}
		return CollateralDetailsSection.getAllCollateralSections().size() != nonDraftSections.size();
	}

	@Override
	@Transactional
	public boolean areAllSectionsVerified(Long collateralId) {
		return areAllSectionsVerified(findSectionStatusesByCollateralId(collateralId));
	}

	@Override
	@Transactional
	public boolean areBasicSectionsVerified(Long collateralId) {
		return areBasicSectionsVerified(findSectionStatusesByCollateralId(collateralId));
	}

	private List<SectionStatus> findSectionStatusesByCollateralId(Long collateralId) {
		return sectionStatusRepository.findByCollateralRid(collateralId);
	}

	private boolean areAllSectionsVerified(List<SectionStatus> sectionsStatus) {
		return areSectionsVerified(sectionsStatus, CollateralDetailsSection.getAllCollateralSections());
	}

	private boolean areBasicSectionsVerified(List<SectionStatus> sectionsStatus) {
		return areSectionsVerified(sectionsStatus, CollateralDetailsSection.getBasicCollateralSections());
	}

	private boolean areSectionsVerified(List<SectionStatus> sectionStatuses, Set<CollateralDetailsSection> sections) {
		Set<CollateralDetailsSection> verifiedSections = new HashSet<CollateralDetailsSection>();
		for (SectionStatus sectionStatus : sectionStatuses) {
			CollateralDetailsSection section = CollateralDetailsSection.valueOf(sectionStatus.getSectionId());
			if (sections.contains(section) && VERIFIED.name().equals(sectionStatus.getStatusId())) {
				verifiedSections.add(section);
			}
		}
		return sections.size() == verifiedSections.size();
	}

	@Override
	public void saveSectionStatus(Long collateralId) {
		List<SectionStatus> sectionStatuses=findSectionStatusesByCollateralId(collateralId);
		for(SectionStatus sectionStatus:sectionStatuses){
			if(sectionStatus.getSectionId().equals("FLOOD_HAZARD_DETERMINATION_FORM")
					&& sectionStatus.getStatusId().equals("PENDING_VERIFICATION")){
				sectionStatus.setStatusId("VERIFIED");
				sectionStatusRepository.save(sectionStatus);
				break;
			}
		}
	}

    @Override
    @Transactional(readOnly = true)
    public List<SectionStatusDto> getSectionStatuses(Long collateralId) {
	    return ctracObjectMapper.mapAsList(sectionStatusRepository.findByCollateralRid(collateralId), SectionStatusDto.class);
    }

    @Override
	@Transactional
	public void allowAnyVerification(Long collateralId) {
        List<SectionStatus> sectionStatuses = sectionStatusRepository.findByCollateralRid(collateralId);
	    List<SectionStatus> updatedSectionStatuses = new ArrayList<>();
        for (SectionStatus sectionStatus : sectionStatuses) {
	        if (VerificationStatus.PENDING_VERIFICATION.name().equals(sectionStatus.getStatusId())) {
	            sectionStatus.setModifiedBy("ADMIN");
                updatedSectionStatuses.add(sectionStatus);
            }
        }
        if (!updatedSectionStatuses.isEmpty()) {
			sectionStatusRepository.save(updatedSectionStatuses);
		}
	}
}
