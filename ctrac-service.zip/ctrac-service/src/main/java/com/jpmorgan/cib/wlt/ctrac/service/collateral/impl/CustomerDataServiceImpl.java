package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ContactDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ContactDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CustomerRepository;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.ContactDetailDataService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CustomerDataService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Service
public class CustomerDataServiceImpl implements CustomerDataService {

    @Autowired
    private ContactDetailsRepository contactDetailsRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CtracObjectMapper ctracObjectMapper;
    @Autowired
    private ContactDetailDataService contactDetailDataService;

    private static final Logger logger = Logger.getLogger(CustomerDataServiceImpl.class);

    @Override
    @Transactional
    public Collection<CustomerData> saveCustomers(Collection<CustomerData> customersData) {
        for (CustomerData oneCustomerData : customersData) {
            saveCustomer(oneCustomerData);
        }
        return customersData;
    }

    @Override
    @Transactional
    public CustomerData saveCustomer(CustomerData customerData) {

        logger.debug(" saveCustomer start: customer id is : " + customerData.getRid());
        // 1- First save the inner properties recursively
        // TODO add checking mechanism to enforce that we only save inner
        // properties if it has changed
        if (customerData.getContactDetailDto() != null) {
            contactDetailDataService.saveContactDetail(customerData.getContactDetailDto());
        }

        // 2 Create a new customer of fetch and existing one that need to be
        // updated
        Customer customer = new Customer();
        if (customerData.getRid() != null) {
            customer = customerRepository.findOne(customerData.getRid());
        }

        // 2 if the customer don't have the link/id of the contact detail stored
        // in step1, create the relation
        // TODO de we need to care about re-pointing/updated?
        if (customerData.getContactDetailDto() != null) {
            ContactDetails contactDetail = contactDetailsRepository.findOne(customerData.getContactDetailDto().getRid());
            customer.setContactDetails(contactDetail);
        }

        if (!customerData.hasChanged()) {
            return customerData;
        }

        ctracObjectMapper.map(customerData, customer);

        customer = customerRepository.save(customer);

        customerData.setRid(customer.getRid());
        customerData.refreshAuditUpdate(customer);
        // cache a copy for comparison when saving back the object
        // if the properties values had not changed, skip saving to the DB
        customerData.saveACopy();

        logger.debug(" saveCustomer end: customer id is : " + customerData.getRid());

        return customerData;
    }
}
