package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;

public interface AddressDataService {
    AddressDto saveAddress(AddressDto address);
    void deleteAddress(AddressDto addressDto);
}
