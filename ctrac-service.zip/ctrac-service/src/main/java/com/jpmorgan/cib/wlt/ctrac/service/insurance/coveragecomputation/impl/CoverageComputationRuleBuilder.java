package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import java.util.Date;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;


public class CoverageComputationRuleBuilder {

	private final Collateral collateral;
	private final WorkItem triggerWorkItem;
	private InsurableAsset insurableAsset;
	private final Date today;
	
	private static final Logger logger = Logger.getLogger(CoverageComputationRuleBuilder.class);

	
	public CoverageComputationRuleBuilder( Collateral collateral, final WorkItem triggerWorkItem, Date today){
		this.collateral =collateral;
		this.triggerWorkItem = triggerWorkItem;
		this.today = today;
	}
	
	public TreeSet<C3Rule> getCollateralBasedCoverageRules() {
		checkCollateralVariableStatus();
		
		@SuppressWarnings("serial")
		TreeSet<C3Rule> allCollateralCoverageRules = new TreeSet<C3Rule>(){{
        	add(new CollateralStatusRule(collateral, triggerWorkItem, today));
	        add(new CollateralFloodZoneStatusRule(collateral, triggerWorkItem,today));
	        add(new CollateralLoanStatusRule(collateral, triggerWorkItem,today));
        }};
		return allCollateralCoverageRules;
		
	}

	public TreeSet<C3Rule> getInsurableAssetBasedCoverageRules(final CoverageActionData coverageActionData ){
		checkCollateralVariableStatus();
		checkInsurableAssetVariableStatus();
		TreeSet<C3Rule> allInsurableAssetCoverageRules = new TreeSet<C3Rule>() {
			private static final long serialVersionUID = 6337605251372427527L; {
				add(new CalculateCoverageDateRule(collateral, triggerWorkItem, insurableAsset, coverageActionData));		 // 25
				add(new UpdateExpiringCoverageRule(collateral, triggerWorkItem, insurableAsset, coverageActionData)); 		 // 19
				add(new SkipAssetWithBlanketCoverageRules(collateral, triggerWorkItem, insurableAsset, coverageActionData)); // 18
				add(new PrimaryExcessRule(collateral, triggerWorkItem, insurableAsset, coverageActionData));				 // 15
				add(new ExternallyAgentedRule(collateral, triggerWorkItem, insurableAsset, coverageActionData));			 // 14
			}
		};
		return allInsurableAssetCoverageRules;
	}
	
	public CoverageComputationRuleBuilder withInsurableAsset(InsurableAsset insurableAsset){
		this.insurableAsset = insurableAsset;
		return this;
	}
	
	private void checkCollateralVariableStatus() {
		if(collateral==null){
			String message = "Invalid input parameters, collateral "+collateral+" workITem : "+triggerWorkItem;
			logger.error(message);
		    throw new RuntimeException(message);
		}
	}
	
	private void checkInsurableAssetVariableStatus() {
		if(insurableAsset==null){
			String message = "Invalid input parameters, insurableAsset is : "+insurableAsset;
			logger.error(message);
		    throw new RuntimeException(message);
		}
	}
}
