package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AgentData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.LenderPlaceItemDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.validation.Valid;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;

public abstract class ProofOfCoverageDTO extends BaseDto implements Serializable, Cloneable {

	private static final long serialVersionUID = 1635002973565311076L;
    private static final Logger logger = Logger.getLogger(ProofOfCoverageDTO.class);

	private Long rid;
	private Long parentPolicyRid;
	private PolicyType policyType;
	private PolicyStatus policyStatus;
	private Boolean migrated = Boolean.FALSE;
	private PolicyStatus collateralPolicyStatus;
	private String reasonForVerification;
	public String getReasonForVerification() {
		return reasonForVerification;
	}

	public void setReasonForVerification(String reasonForVerification) {
		this.reasonForVerification = reasonForVerification;
	}

	private String lenderPlaceVendor;
	private String issuanceDate;
	private String effectiveDate;
	private String expirationDate;
	private String cancellationEffectiveDate;
	private String cancellationLetterDate;
	@NoInvalidCharacters
	private String insuranceAgency;
	@Valid
	private AgentData agentData;
	private String buildingDeductible;
	private String contentsDeductible;
	private CancellationReason cancellationReason;
	private String thirtyDayRegulatoryPeriod;
	private BigDecimal previousExpiredAmount;
	private String lpLetterCycleRestartedDate;
	private String preRenewalLetterDate;
	private LenderPlaceReason lenderPlaceReason;
	private ManualLetterCycle manualLetterCycle = new ManualLetterCycle();
	private WorkflowStateDefinition letterCycleWorkflowStep;
	@Valid
	private PaymentMethodDTO invoicePaymentMethod;
	@Valid
	private PaymentMethodDTO refundPaymentMethod;
	@Valid
	private PaymentMethodDTO preRenewalPaymentMethod;
	private List<ProvidedCoverageDTO> providedCoverageDTOs = new ArrayList<>();
	private List<CollateralDocument> policyDocuments = new ArrayList<>();

	private ProvidedCoverageDTO primaryProvidedCoverage = null;

	private InsuranceCoverageMap<ProvidedCoverageDTO> providedCoverageMap;

	private ProofOfCoverageDTO loadTimeValue;

    private InsuranceType insuranceType;

    private CoverageType coverageType;

    private String displayMessage;

    private LPActions pendingLpAction;

    private LenderPlaceItemDTO lenderPlaceItemData;

    private BlanketCoverageDTO blanketCoverageData;

    private Date cancellationTargetDate;

	private Date lpTargetDate;

	private boolean hasException;

	private boolean isRenewable;

	private boolean renewed;

	private boolean canRestartLetterCycle;

	private Long gapBorrowerPolicyRid;

	private String indRenewal = "N";

	private Boolean invalid = false;

	@NoInvalidCharacters
	private String policyNumber;
	@NoInvalidCharacters
	private String insuredName;
	@NoInvalidCharacters
	private String floodZone;

    private boolean isCancelledInLetterCycle;

    public boolean isCancelledInLetterCycle() {
        return isCancelledInLetterCycle;
    }

    public void setCancelledInLetterCycle(boolean cancelledInLetterCycle) {
        isCancelledInLetterCycle = cancelledInLetterCycle;
    }

	public boolean enableInvoicePaymentMethod() {
		return policyStatus.requiresInvoicePaymentMethod() && (
				(lenderPlaceItemData != null && !lenderPlaceItemData.premiumAmountRecorded()) || (invoicePaymentMethod != null && invoicePaymentMethod.isBlank()));
	}

	public boolean enableRefundPaymentMethod(){
		return policyStatus.isCancelled() && lenderPlaceItemData != null &&
				(lenderPlaceItemData.premiumAmountRecorded() || Boolean.TRUE.equals(migrated))
				&& !lenderPlaceItemData.refundAmountRecorded();
	}

	public String getPolicyTypeDisplayName() {
		if (blanketCoverageData != null && blanketCoverageData.getBlanketCoverageType() != null && !"IND".equals(blanketCoverageData.getBlanketCoverageType())) {
			return "Blanket " + policyType.getDisplayName();
		}
		return policyType.getDisplayName();
	}

	public String getBuildingDisplayAmount(Long collateralRid, Integer insurableAssetSortOrder) {
		return getDisplayAmount(collateralRid, insurableAssetSortOrder, InsurableAssetType.STRUCTURE);
	}

	public String getContentsDisplayAmount(Long collateralRid, Integer insurableAssetSortOrder) {
		return getDisplayAmount(collateralRid, insurableAssetSortOrder, InsurableAssetType.BASE_INSURABLE_ASSET);
	}
	
	public String getBusinessIncomeDisplayAmount(Long collateralRid, Integer insurableAssetSortOrder) {
		return getDisplayAmount(collateralRid, insurableAssetSortOrder, InsurableAssetType.BUSINESS_INCOME);
	}

	private String getDisplayAmount(Long collateralRid, Integer insurableAssetSortOrder, InsurableAssetType insurableAssetType) {
		if (collateralPolicyStatus != null && collateralPolicyStatus == PolicyStatus.PENDING_VERIFICATION) {
			return "Pending";
		}
		if (blanketCoverageData != null) {
			String blanketCoverageType = blanketCoverageData.getBlanketCoverageType();
			if ("BLDG".equals(blanketCoverageType) || "CONTS".equals(blanketCoverageType) || "AND_OR".equals(blanketCoverageType)) {
				String amount = "";
				if (insurableAssetType ==  InsurableAssetType.STRUCTURE) {
					amount = blanketCoverageData.getBlanketBuildingAmount(); 					
				} else if (insurableAssetType ==  InsurableAssetType.BASE_INSURABLE_ASSET) {
					amount = blanketCoverageData.getBlanketContentAmount(); 					
				}
				
				return StringUtils.isNotEmpty(amount) ? amount : "0.00";
			} else if ("COMB".equals(blanketCoverageType)) {
				return blanketCoverageData.getBlanketCombinedAmount();
			}
		}
		InsurableAssetCoverageData<ProvidedCoverageDTO> insurableAssetCoverageData =
				providedCoverageMap.getInsurableAssetCoverageData().get(collateralRid).get(insurableAssetSortOrder);
		if (insurableAssetCoverageData == null) {
			return "0.00";
		}
		if (insurableAssetType ==  InsurableAssetType.STRUCTURE && insurableAssetCoverageData.getBuildingCoverageData() != null) {
			return insurableAssetCoverageData.getBuildingCoverageData().getCoverageAmount();
		} else if (insurableAssetType ==  InsurableAssetType.BASE_INSURABLE_ASSET && insurableAssetCoverageData.getContentsCoverageData() != null) {
			return insurableAssetCoverageData.getContentsCoverageData().getCoverageAmount();
		} else if (insurableAssetType ==  InsurableAssetType.BUSINESS_INCOME && insurableAssetCoverageData.getBusinessIncomeCoverageData() != null) {
			return insurableAssetCoverageData.getBusinessIncomeCoverageData().getCoverageAmount();
		}
		return "0.00";
	}

	public BlanketCoverageDTO getBlanketCoverageData() {
		return blanketCoverageData;
	}

	public void setBlanketCoverageData(BlanketCoverageDTO blanketCoverageData) {
		this.blanketCoverageData = blanketCoverageData;
	}

	public String getDisplayMessage() {
		return displayMessage;
	}

	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}

	public ProofOfCoverageDTO(InsuranceType insuranceType, String insuranceAgency) {
        super();
        this.insuranceType = insuranceType;
        this.insuranceAgency = insuranceAgency;
    }

	public List<ProvidedCoverageDTO> getProvidedCoverageDTOs() {
		for(ProvidedCoverageDTO providedCoverageDTO : this.providedCoverageDTOs){
			providedCoverageDTO.setProofOfCoverageDto(this);
		}
		return providedCoverageDTOs;
	}

	public void setProvidedCoverageDTOs(List<ProvidedCoverageDTO> providedCoverageDTOs) {

		for(ProvidedCoverageDTO providedCoverageDTO:providedCoverageDTOs){
			providedCoverageDTO.setProofOfCoverageDto(this);
		}
		this.providedCoverageDTOs = providedCoverageDTOs;
	}

	public void addProvidedCoverageDTO(ProvidedCoverageDTO providedCoverageDTO){

		providedCoverageDTO.setProofOfCoverageDto(this);

	    if(providedCoverageDTO.getRid()!=null && providedCoverageDTOs.contains(providedCoverageDTO)){
	        providedCoverageDTOs.remove(providedCoverageDTO);
	    }

	    providedCoverageDTOs.add(providedCoverageDTO);
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getParentPolicyRid() {
		return parentPolicyRid;
	}

	public void setParentPolicyRid(Long parentPolicyRid) {
		this.parentPolicyRid = parentPolicyRid;
	}

	public PolicyType getPolicyType() {
		return policyType;
	}

	public boolean isRenewed() {
		return renewed;
	}

	public void setRenewed(boolean wasRenewed) {
		this.renewed = wasRenewed;
	}

	public void setPolicyType(PolicyType policyType) {
		this.policyType = policyType;
	}

	public PolicyStatus getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(PolicyStatus policyStatus) {
		this.policyStatus = policyStatus;
	}

	public Boolean getMigrated() {
		return migrated;
	}

	public void setMigrated(Boolean migrated) {
		this.migrated = migrated;
	}

	public PolicyStatus getCollateralPolicyStatus() {
		return collateralPolicyStatus;
	}

	public void setCollateralPolicyStatus(PolicyStatus collateralPolicyStatus) {
		this.collateralPolicyStatus = collateralPolicyStatus;
	}

	public String getLenderPlaceVendor() {
		return lenderPlaceVendor;
	}

	public void setLenderPlaceVendor(String lenderPlaceVendor) {
		this.lenderPlaceVendor = lenderPlaceVendor;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getIssuanceDate() {
		return issuanceDate;
	}

	public void setIssuanceDate(String issuanceDate) {
		this.issuanceDate = issuanceDate;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public Date getEffectiveDate_() {
		return DateConverter.convert(effectiveDate);
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public Date getExpirationDate_() {
		return DateConverter.convert(expirationDate);
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public boolean hasCancellationDate() {
		return StringUtils.isNotBlank(cancellationEffectiveDate);
	}

	public String getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}

	public Date getCancellationEffectiveDate_() {
		return DateConverter.convert(cancellationEffectiveDate);
	}

	public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}

	public Date getCancellationTargetDate() {
		return cancellationTargetDate;
	}

	public void setCancellationTargetDate(Date cancellationTargetDate) {
		this.cancellationTargetDate = cancellationTargetDate;
	}

	public Date getLpTargetDate() {
		return lpTargetDate;
	}

	public void setLpTargetDate(Date lpTargetDate) {
		this.lpTargetDate = lpTargetDate;
	}

	public String getCancellationLetterDate() {
		return cancellationLetterDate;
	}

	public void setCancellationLetterDate(String cancellationLetterDate) {
		this.cancellationLetterDate = cancellationLetterDate;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getInsuranceAgency() {
		return insuranceAgency;
	}

	public void setInsuranceAgency(String insuranceAgency) {
		this.insuranceAgency = insuranceAgency;
	}

	public AgentData getAgentData() {
		if (agentData == null) {
			agentData = new AgentData();
		}
		return agentData;
	}

	public void setAgentData(AgentData agentData) {
		this.agentData = agentData;
	}

    public InsuranceCoverageMap<ProvidedCoverageDTO> getProvidedCoverageMap() {
        return providedCoverageMap;
    }

    public void setProvidedCoverageMap(InsuranceCoverageMap<ProvidedCoverageDTO> providedCoverageMap) {
        this.providedCoverageMap = providedCoverageMap;
    }

	public String getFloodZone() {
        return floodZone;
    }

    public void setFloodZone(String floodZone) {
        this.floodZone = floodZone;
    }

    public boolean isInFloodZone(){
		return floodZone != null && (floodZone.toUpperCase().trim().startsWith("A") || floodZone.toUpperCase().trim().startsWith("V"));
    }

    public String getBuildingDeductible() {
        return buildingDeductible;
    }

    public void setBuildingDeductible(String buildingDeductible) {
        this.buildingDeductible = buildingDeductible;
    }

    public String getContentsDeductible() {
        return contentsDeductible;
    }

    public void setContentsDeductible(String contentsDeductible) {
        this.contentsDeductible = contentsDeductible;
    }

    public PaymentMethodDTO getInvoicePaymentMethod() {
        return invoicePaymentMethod;
    }

    public void setInvoicePaymentMethod(PaymentMethodDTO invoicePaymentMethod) {
        this.invoicePaymentMethod = invoicePaymentMethod;
    }

    public PaymentMethodDTO getRefundPaymentMethod() {
        return refundPaymentMethod;
    }

    public void setRefundPaymentMethod(PaymentMethodDTO refundPaymentMethod) {
        this.refundPaymentMethod = refundPaymentMethod;
    }

	public PaymentMethodDTO getPreRenewalPaymentMethod() {
		return preRenewalPaymentMethod;
	}

	public void setPreRenewalPaymentMethod(PaymentMethodDTO preRenewalPaymentMethod) {
		this.preRenewalPaymentMethod = preRenewalPaymentMethod;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		ProofOfCoverageDTO other = (ProofOfCoverageDTO) obj;
		if (rid == null || !rid.equals(other.rid)) {
			return false;
		}
		return true;
	}

	public boolean hasChanged(){
		if (this.loadTimeValue == null || this.getRid() == null) {
			return true;
		}

		if(agentData != null && agentData.hasChanged()) {
			return true;
		}

		if (CollectionUtils.isNotEmpty(providedCoverageDTOs)) {
			for(ProvidedCoverageDTO providedCoverageDTO:providedCoverageDTOs){
				if(providedCoverageDTO.hasChanged()){
					return true;
				}
			}
		}

		return !this.deepEquals(this.loadTimeValue);
	}

	public ProofOfCoverageDTO getLoadTimeValue() {
    	return loadTimeValue;
	}

	public void saveACopy() {
		if (this.getProvidedCoverageMap() != null){
			List<ProvidedCoverageDTO> providedCoverageDTOList = this.getProvidedCoverageMap()
					.getAllCoverages(true, null);
			if (CollectionUtils.isNotEmpty(providedCoverageDTOList)) {
				for (ProvidedCoverageDTO elem : providedCoverageDTOList) {
					elem.saveACopy();
				}
			}
		}
        if (agentData != null) {
        	agentData.saveACopy();
        }
        if (invoicePaymentMethod != null) {
        	invoicePaymentMethod.saveACopy();
        }
        if (refundPaymentMethod != null) {
        	refundPaymentMethod.saveACopy();
        }
        try {
            this.loadTimeValue = this.clone();
        } catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
        }
	}

	private boolean deepEquals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ProofOfCoverageDTO other = (ProofOfCoverageDTO) obj;
		if (agentData == null) {
			if (other.agentData != null) {
				return false;
			}
		} else if (!agentData.equals(other.agentData)) {
			return false;
		}
		if(!StringUtils.equals(buildingDeductible, other.buildingDeductible)){
			return false;
		}
		if(!StringUtils.equals(cancellationEffectiveDate, other.cancellationEffectiveDate)){
			return false;
		}
		if(!StringUtils.equals(cancellationLetterDate, other.cancellationLetterDate)){
			return false;
		}
		if(!StringUtils.equals(contentsDeductible, other.contentsDeductible)){
			return false;
		}
		if (coverageType != other.coverageType) {
			return false;
		}
		if(!StringUtils.equals(effectiveDate, other.effectiveDate)){
			return false;
		}
		if(!StringUtils.equals(expirationDate, other.expirationDate)){
			return false;
		}
		if(!StringUtils.equals(floodZone, other.floodZone)){
			return false;
		}
		if(!StringUtils.equals(insuranceAgency, other.insuranceAgency)){
			return false;
		}
		if (insuranceType != other.insuranceType) {
			return false;
		}
		if(!StringUtils.equals(insuredName, other.insuredName)){
			return false;
		}
		if (invoicePaymentMethod == null) {
			if (other.invoicePaymentMethod != null) {
				return false;
			}
		} else if (invoicePaymentMethod.hasChanged()) {
			return false;
		}
		if(!StringUtils.equals(issuanceDate, other.issuanceDate)){
			return false;
		}
		if(!StringUtils.equals(lenderPlaceVendor, other.lenderPlaceVendor)){
			return false;
		}
		if (policyDocuments == null) {
			if (other.policyDocuments != null) {
				return false;
			}
		} else if (!policyDocuments.equals(other.policyDocuments)) {
			return false;
		}
		if(!StringUtils.equals(policyNumber, other.policyNumber)){
			return false;
		}
		if (policyStatus != other.policyStatus) {
			return false;
		}
		if (policyType != other.policyType) {
			return false;
		}
		if (primaryProvidedCoverage == null) {
			if (other.primaryProvidedCoverage != null) {
				return false;
			}
		} else if (!primaryProvidedCoverage.equals(other.primaryProvidedCoverage)) {
			return false;
		}
		if (providedCoverageDTOs == null) {
			if (other.providedCoverageDTOs != null) {
				return false;
			}
		} else if (!providedCoverageDTOs.equals(other.providedCoverageDTOs)) {
			return false;
		}
		if (providedCoverageMap == null) {
			if (other.providedCoverageMap != null) {
				return false;
			}
		} else if (!providedCoverageMap.equals(other.providedCoverageMap)) {
			return false;
		}
        if (refundPaymentMethod == null) {
            if (other.refundPaymentMethod != null) {
                return false;
            }
        } else if (refundPaymentMethod.hasChanged()) {
            return false;
        }
		if (rid == null) {
			if (other.rid != null) {
				return false;
			}
		} else if (!rid.equals(other.rid)) {
			return false;
		}
		return true;
	}

	@Override
	protected ProofOfCoverageDTO clone() throws CloneNotSupportedException {
		return (ProofOfCoverageDTO) super.clone();
	}

    public InsuranceType getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(InsuranceType insuranceType) {
        this.insuranceType = insuranceType;
    }

    public CoverageType getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(CoverageType coverageType) {
        this.coverageType = coverageType;
    }

	public List<CollateralDocument> getPolicyDocuments() {
		return policyDocuments;
	}

	public void setPolicyDocuments(List<CollateralDocument> policyDocuments) {
		this.policyDocuments = policyDocuments;
	}

	public ProvidedCoverageDTO getPrimaryProvidedCoverage() {
		if (providedCoverageDTOs != null && !providedCoverageDTOs.isEmpty()) {
			primaryProvidedCoverage = providedCoverageDTOs.get(0);
		}
		return primaryProvidedCoverage;
	}

	public void setPrimaryProvidedCoverage(ProvidedCoverageDTO primaryProvidedCoverage) {
		this.primaryProvidedCoverage = primaryProvidedCoverage;
	}

	public LenderPlaceItemDTO getLenderPlaceItemData() {
		return lenderPlaceItemData;
	}

	public void setLenderPlaceItemData(LenderPlaceItemDTO lenderPlaceItemData) {
		this.lenderPlaceItemData = lenderPlaceItemData;
	}

    public LPActions getPendingLpAction() {
        return pendingLpAction;
    }

    public void setPendingLpAction(LPActions pendingLpAction) {
        this.pendingLpAction = pendingLpAction;
    }

    public CancellationReason getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(CancellationReason cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

	public String getThirtyDayRegulatoryPeriod() {
		return thirtyDayRegulatoryPeriod;
	}

	public void setThirtyDayRegulatoryPeriod(String thirtyDayRegulatoryPeriod) {
		this.thirtyDayRegulatoryPeriod = thirtyDayRegulatoryPeriod;
	}

	public boolean isDisplayCancellationDate() {
		return (policyStatus.isActive(false)) ||
                (PolicyReasonForVerification.CANCELATION_DATE_ENTERED.name().equals(reasonForVerification) && policyStatus == PolicyStatus.PENDING_VERIFICATION);
	}

	public boolean isHasException() {
		return hasException;
	}

	public void setHasException(boolean hasException) {
		this.hasException = hasException;
	}

	public BigDecimal getPreviousExpiredAmount() {
		return previousExpiredAmount;
	}

	public void setPreviousExpiredAmount(BigDecimal previousExpiredAmount) {
		this.previousExpiredAmount = previousExpiredAmount;
	}

	public String getPreRenewalLetterDate() {
		return preRenewalLetterDate;
	}

	/**
	 * Used to hold the pre-renewal letter date of the expired policy
	 */
	private Date expiredPreRenewalLetterDate;

	public Date getExpiredPreRenewalLetterDate() {
		return expiredPreRenewalLetterDate;
	}

	public void setExpiredPreRenewalLetterDate(Date expiredPreRenewalLetterDate) {
		this.expiredPreRenewalLetterDate = expiredPreRenewalLetterDate;
	}

	public void setPreRenewalLetterDate(String preRenewalLetterDate) {
		this.preRenewalLetterDate = preRenewalLetterDate;
	}

	public Map<Long, ProvidedCoverageDTO> getInsurableAssetProvidedCoverageMap(){
		Map<Long, ProvidedCoverageDTO> map = new HashMap<Long, ProvidedCoverageDTO>();
		for(ProvidedCoverageDTO provideCoverageDTO: this.getProvidedCoverageDTOs()){
			map.put(provideCoverageDTO.getInsurableAssetDTO().getRid(), provideCoverageDTO);
		}
		return map;
	}

	public boolean isRenewable() {
		return isRenewable;
	}

	public void setRenewable(boolean isRenewable) {
		this.isRenewable = isRenewable;
	}

	public boolean isCanRestartLetterCycle() {
		return canRestartLetterCycle;
	}

	public void setCanRestartLetterCycle(boolean canRestartLetterCycle) {
		this.canRestartLetterCycle = canRestartLetterCycle;
	}

	public String getLpLetterCycleRestartedDate() {
		return lpLetterCycleRestartedDate;
	}

	public void setLpLetterCycleRestartedDate(String lpLetterCycleRestartedDate) {
		this.lpLetterCycleRestartedDate = lpLetterCycleRestartedDate;
	}

	public LenderPlaceReason getLenderPlaceReason() {
		return lenderPlaceReason;
	}

	public void setLenderPlaceReason(LenderPlaceReason lenderPlaceReason) {
		this.lenderPlaceReason = lenderPlaceReason;
	}

	public Long getGapBorrowerPolicyRid() {
		return gapBorrowerPolicyRid;
	}

	public void setGapBorrowerPolicyRid(Long borrowerPolicyRid) {
		this.gapBorrowerPolicyRid = borrowerPolicyRid;
	}

	public String getIndRenewal() {
		return indRenewal;
	}

	public void setIndRenewal(String indRenewal) {
		this.indRenewal = indRenewal;
	}

	public Boolean getInvalid() {
		return invalid;
	}

	public void setInvalid(Boolean invalid) {
		this.invalid = invalid;
	}

	public boolean isPolicyReplaceable(){
		// When policy is not an Application or Binder type - it is not replaceable
		if(policyType == null || !policyType.isApplicationOrBinder()){
			return false;
		}
		PolicyStatus proofOfCoverageStatus = this.getPolicyStatus();
		// Policy is only replaceable when policy status is ACCEPTED / EXPIRING / EXPIRED
		return proofOfCoverageStatus != null && (PolicyStatus.ACCEPTED == proofOfCoverageStatus || proofOfCoverageStatus.isExpiring()
				|| PolicyStatus.EXPIRED == proofOfCoverageStatus);
	}

	public WorkflowStateDefinition getLetterCycleWorkflowStep() {
		return letterCycleWorkflowStep;
	}

	public void setLetterCycleWorkflowStep(WorkflowStateDefinition letterCycleWorkflowStep) {
		this.letterCycleWorkflowStep = letterCycleWorkflowStep;
	}

	public ManualLetterCycle getManualLetterCycle() {
		return manualLetterCycle == null? new ManualLetterCycle(): manualLetterCycle;
	}

	public class ManualLetterCycle  implements Serializable {
		private static final long serialVersionUID = 1L;
		private String firstLetterDate;
		private String secondLetterDate;
        private Boolean marketEmailNeeded;

		ManualLetterCycle() {
		}

		public Date getFirstLetterDate_() {
			return DateConverter.convert(firstLetterDate);
		}

		public Date getSecondLetterDate_() {
			return DateConverter.convert(secondLetterDate);
		}

		public String getFirstLetterDate() {
			return this.firstLetterDate;
		}

		public void setFirstLetterDate(String firstLetterDate) {
			this.firstLetterDate = firstLetterDate;
		}

		public String getSecondLetterDate() {
			return this.secondLetterDate;
		}

		public void setSecondLetterDate(String secondLetterDate) {
			this.secondLetterDate = secondLetterDate;
		}

        public Boolean isMarketEmailNeeded() {
            return marketEmailNeeded;
        }

        public Boolean getMarketEmailNeeded() {
            return marketEmailNeeded;
        }

        public void setMarketEmailNeeded(Boolean marketEmailNeeded) {
            this.marketEmailNeeded = marketEmailNeeded;
        }

    }



}
