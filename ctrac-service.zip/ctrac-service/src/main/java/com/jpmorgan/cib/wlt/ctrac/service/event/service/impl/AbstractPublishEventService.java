package com.jpmorgan.cib.wlt.ctrac.service.event.service.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralEvent;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.listener.CollateralEventStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralEventRepository;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.EventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonBuilder;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonParser;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.aspect.AuditInformationBean;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.request.PublishEventRequest;
import com.jpmorgan.cib.wlt.ctrac.service.event.store.client.CollateralEventSection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Iterator;
import java.util.UUID;

public class AbstractPublishEventService {

    private static final Logger log = LoggerFactory.getLogger(AbstractPublishEventService.class);

    @Autowired
    private CollateralEventRepository collateralEventRepository;
    @Autowired  private AuditInformationService auditInformationService;

    protected void publishEvent(String identifier, Long collateralRid, String lineOfBusiness, String description,
                                CollateralEventType eventType, CollateralEventSection collateralSection, String taskName) {

        publishEventWithUserName(identifier, collateralRid, lineOfBusiness, description,
                eventType, collateralSection, taskName, null);

    }

    protected void publishEventWithUserName(String identifier, Long collateralRid, String lineOfBusiness, String description,
                                                  CollateralEventType eventType, CollateralEventSection collateralSection, String taskName, String userName) {
        String userId = userName;
        String userFullName = userName;
        if (userName == null) {
            try {
                AuditInformationBean auditInformationBean = auditInformationService.getAuditInformation();
                if (auditInformationBean != null) {
                    userId = auditInformationBean.getUserSid();
                    userFullName = auditInformationBean.getUserFullName();
                }
            } catch (Exception e) {
                userId = PublishEventRequest.SYSTEM;
                userFullName = PublishEventRequest.SYSTEM;
                log.trace("Unable to get username from audit bean, default to {}: {}", PublishEventRequest.SYSTEM, e.getMessage());
            }
        }
		AuditEventDTO auditEventDTO = new AuditEventDTO();
		auditEventDTO.setEventType(eventType.toString());
		auditEventDTO.setPerformedBy(userId);
		auditEventDTO.setCollateralId(collateralRid);
		auditEventDTO.setIdentifier(identifier);
		auditEventDTO.setLineOfBusiness(lineOfBusiness);
		auditEventDTO.setDescription(description);
		auditEventDTO.setCollateralSection(collateralSection.toString());
		auditEventDTO.setTaskName(taskName);
		auditEventDTO.setUserFullName(userFullName);
		publishEvent(auditEventDTO);
	}

	@Transactional
	public void publishEvent(EventDTO eventDTO) {
        CollateralEvent collateralEvent = new CollateralEvent();
		collateralEvent.setEventStatus(CollateralEventStatus.PENDING.name());
		collateralEvent.setEventTime(eventDTO.getEventTime());
		collateralEvent.setEventUuid(eventDTO.getEventUuid());
        EventJsonBuilder eventJsonBuilder = new EventJsonBuilder().forDTO(eventDTO);
		collateralEvent.setEventJson(eventJsonBuilder.build());
		collateralEventRepository.save(collateralEvent);
	}

    protected void publishCollateralSectionEvent(PublishEventRequest publishRequest, CollateralEventSection collateralEventSection) {
        publishEventWithUserName(publishRequest.getIdentifier(), publishRequest.getCollateralRid(), publishRequest.getLineOfBusiness(),
                publishRequest.getDescription(), publishRequest.getCollateralEventType(),
                collateralEventSection, publishRequest.getTaskName(), publishRequest.getUser());
    }

    protected void republishEvent(UUID eventUuid) {
	    CollateralEvent event = collateralEventRepository.findByEventUuid(eventUuid);
	    if(event == null) {
	    	log.error("Cannot republish event. Event {} not found", eventUuid);
	    	return;
	    }
	    event.setLastPublishTime(new Date());
	    collateralEventRepository.save(event);
    }

	protected void republishEvents(Date fromDate, Date toDate) {
		Sort sort = new Sort(Sort.Direction.ASC, "rid");
		Pageable pageRequest = new PageRequest(0, 100, sort);
		int pageCount = 0;
		long throttleTime;
		while (pageRequest != null) {
			++pageCount;
			log.trace("Processing page {}", pageCount);
			throttleTime = System.currentTimeMillis();
			pageRequest = processPage(fromDate, toDate, pageRequest);
			throttleTime = System.currentTimeMillis() - throttleTime;
			if (throttleTime < 5000) {
				try {
					Thread.sleep(5000 - throttleTime);
				} catch (Exception e) {
					log.warn("Attempted throttling of republishEvents interrupted", e);
				}
			}
			log.trace("Finished processing page {}", pageCount);
		}
	}

	protected Pageable processPage(Date fromDate, Date toDate, Pageable pageable) {
		Page<CollateralEvent> collateralEvents = collateralEventRepository.findByEventTimeBetween(fromDate, toDate, pageable);
		Iterator<CollateralEvent> iter = collateralEvents.iterator();
		CollateralEvent event;
		while (iter.hasNext()) {
			event = iter.next();
			rebuildEvent(event);
			event.setLastPublishTime(new Date());
			collateralEventRepository.save(event);
		}
		return collateralEvents.nextPageable();
	}

	protected void rebuildEvent(CollateralEvent event) {
		EventJsonBuilder eventJsonBuilder = new EventJsonBuilder(EventJsonParser.parseEventToNode(event.getEventJson()));
		eventJsonBuilder.forTime(event.getEventTime());
		event.setEventUuid(eventJsonBuilder.getEventUuid());
		event.setEventJson(eventJsonBuilder.build());
	}
}
