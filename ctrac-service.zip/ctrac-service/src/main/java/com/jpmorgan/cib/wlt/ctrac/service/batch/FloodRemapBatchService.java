package com.jpmorgan.cib.wlt.ctrac.service.batch;

import java.text.ParseException;

import org.joda.time.DateTime;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReconciliationLog;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;

public interface FloodRemapBatchService {
	void createNewFloodRemapTasks();
	void logReconciliationAndExitInfoToDatabase(ReconciliationLog reconciliationLog,  int exceptionRecordsCnt);
	void checkSLLastRemapFileReceivedDateAndNotify() throws ParseException;	
	void checkCLLastRemapFileReceivedDateAndNotify() throws ParseException;
	void calculateSLAandMoveTaskToNextWFStep();
	void completeEODBatchOperationsByWFStep(WorkflowStateDefinition workflowStateDefinition);	
	void updateReferenceDate();
	DateTime updateReferenceDate(int daysToAdd);
	void processWiredPolicy();
	void processConfirmedWiredRequest();
	void reconcileCtracAndTM();
	void processAlthansResponseFile();
	void processPendingSendLOBEmailForAlthans();
	void migrateOpenTasksToTM();
	void placeValidLetterFile();
	void archiveInValidLetterFile();
	
}
