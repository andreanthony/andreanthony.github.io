package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Building;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ParentPolicyDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.BuildingRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ParentPolicyDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailCollateralDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailRuleDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;

import java.math.BigDecimal;
import java.util.*;
import java.util.Map.Entry;

public class GapInCoverageRuleWorker extends AbstractBIRRuleWorker {

	public GapInCoverageRuleWorker(String key) {
		super(key, false, true);
	}

	protected boolean ruleShouldRun(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		return true;
	}

	private ActivePolicyService activePolicyService = null;

	private BuildingRepository buildingRepository = null;

	private ParentPolicyDetailsRepository parentPolicyDetailsRepository = null;

	private ProofOfCoverageRepository proofOfCoverageRepository = null;

	private ViewDataRetrievalService viewDataRetrievalService = null;

	@Override
	public void populateExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData) {
		if (activePolicyService == null) {
			activePolicyService = ApplicationContextProvider.getContext().getBean(ActivePolicyService.class);
		}
		if (buildingRepository == null) {
            buildingRepository = ApplicationContextProvider.getContext().getBean(BuildingRepository.class);
        }
		if (parentPolicyDetailsRepository == null) {
			parentPolicyDetailsRepository = ApplicationContextProvider.getContext().getBean(ParentPolicyDetailsRepository.class);
		}
		if (proofOfCoverageRepository == null) {
			proofOfCoverageRepository = ApplicationContextProvider.getContext().getBean(ProofOfCoverageRepository.class);
		}
		if (viewDataRetrievalService == null) {
			viewDataRetrievalService = ApplicationContextProvider.getContext().getBean(ViewDataRetrievalService.class);
		}

		Map<Long, List<GapInCoverageRow>> collateralGapMap = new HashMap<Long, List<GapInCoverageRow>>();
		Long borrowerPolicyRid = borrowerInsuranceReviewData.getProofOfCoverageData().getRid();
		List<ParentPolicyDetailsViewData> parentPolicyChildren = parentPolicyDetailsRepository.findAllByParentPolicyRid(borrowerPolicyRid);
		for (ParentPolicyDetailsViewData childCoverage : parentPolicyChildren) {
			PolicyType childPolicyType = PolicyType.valueOf(childCoverage.getChildPolicyType());
			PolicyStatus childPolicyStatus = PolicyStatus.valueOf(childCoverage.getChildPolicyStatus());
			if (childPolicyType.isLenderPlaced() && childPolicyStatus.isActive(false)) {
				addGapToMap(collateralGapMap, childCoverage);
			}
		}

		for (Entry<Long, List<GapInCoverageRow>> collateralGapEntry : collateralGapMap.entrySet()) {
			// Sort by Insurable Asset sort order, Building then Contents
			List<GapInCoverageRow> gapInCoverageRows = collateralGapEntry.getValue();
			Collections.sort(gapInCoverageRows, new GapInCoverageRowComparator());

			// Add the collateralExceptionData for this collateralRid
			BIRExceptionEmailCollateralDTO collateralExceptionData =
					getExceptionEmailCollateralData(exceptionEmailData, collateralGapEntry.getKey());

			for (GapInCoverageRow gapRow : gapInCoverageRows) {
				BIRExceptionEmailRuleDTO gapInCoverageExceptionData = new BIRExceptionEmailRuleDTO();
				gapInCoverageExceptionData.setRowLabel(gapRow.getRowLabel());
				gapInCoverageExceptionData.setCurrentPolicyValue(gapRow.getCurrentPolicyValue());
				gapInCoverageExceptionData.setRequiredValue(gapRow.getRequiredValue());
				collateralExceptionData.getGapInCoverageExceptions().add(gapInCoverageExceptionData);
			}

			// Add row to exceptions so that they're picked up in table
			collateralExceptionData.getCollateralExceptions().put(key, new BIRExceptionEmailRuleDTO());
		}
	}



	private void addGapToMap(Map<Long, List<GapInCoverageRow>> collateralGapMap, ParentPolicyDetailsViewData childCoverage) {
		Long collateralRid = childCoverage.getCollateralRid();
		List<GapInCoverageRow> gapRows = collateralGapMap.get(collateralRid);
		if (gapRows == null) {
			gapRows = new ArrayList<>();
			collateralGapMap.put(collateralRid, gapRows);
		}

		GapInCoverageRow gapRow = new GapInCoverageRow();
		ProofOfCoverage parentPolicy = proofOfCoverageRepository.findOne(childCoverage.getParentPolicyRid());
		Date effectiveDate = parentPolicy.getEffectiveDate();
		List<ProvidedCoverage> providedCoverages = activePolicyService.findActiveCoverages(
				childCoverage.getInsurableAssetRid(), PolicyType.borrowerPolicyTypes(), effectiveDate, false);
		for (ProvidedCoverage providedCoverage : providedCoverages) {
			ProofOfCoverage proofOfCoverage = providedCoverage.getProofOfCoverage();
			PolicyData policyData = new PolicyData();
			policyData.setCoverageType(proofOfCoverage.getCoverageType_());
			policyData.setCoverageAmount(providedCoverage.getCoverageDetails().getCoverageAmount());
			if (providedCoverage.getInsurableAsset().getAssetType_() == InsurableAssetType.STRUCTURE) {
				policyData.setDeductibleAmount(proofOfCoverage.getBuildingDeductible());
			} else if (providedCoverage.getInsurableAsset().getAssetType_() == InsurableAssetType.BASE_INSURABLE_ASSET) {
				policyData.setDeductibleAmount(proofOfCoverage.getContentsDeductible());
			} 

			gapRow.getProvidedPolicies().add(policyData);
		}

		Integer sortOrder = childCoverage.getSortOrder();
		gapRow.setSortOrder(sortOrder);
		gapRow.setInsurableAssetType(InsurableAssetType.valueOf(childCoverage.getAssetType()));
        Building building = buildingRepository.findByCollateralIdAndSortOrder(collateralRid, sortOrder);
		gapRow.setBuildingName(building != null ? building.getBuildingName() : "");
		RequiredCoverageViewDto requiredCoverageViewDto =
				viewDataRetrievalService.getRequiredCoverageViewData(collateralRid, childCoverage.getInsurableAssetRid());
		gapRow.setRequiredCoverageViewDto(requiredCoverageViewDto);
		gapRows.add(gapRow);
	}

	private static void formatCoverageAmount(StringBuffer sb, BigDecimal coverageAmount, CoverageType coverageType){
		CtracStringUtil.addValueWithSeparator(sb, "$" + AmountFormatter.format(coverageAmount), "<br/>");
		CtracStringUtil.addValueWithSeparator(sb, coverageType.getDisplayValue(), " ");
	}

	private class GapInCoverageRow {

		private Integer sortOrder;
		private InsurableAssetType insurableAssetType;
		private String buildingName;
	    private List<PolicyData> providedPolicies = new ArrayList<>();
	    private RequiredCoverageViewDto requiredCoverageViewDto;

	    public String getRowLabel() {
	    	return buildingName + " (" + insurableAssetType.getDisplayName() + ")";
	    }

		public String getCurrentPolicyValue() {
			Collections.sort(providedPolicies, new PolicyDataComparator());
			StringBuffer sb = new StringBuffer();
			for (PolicyData policyData : providedPolicies) {
				CoverageType coverageType = policyData.getCoverageType();
				formatCoverageAmount(sb,policyData.getCoverageAmount(),coverageType);
				if (coverageType == CoverageType.EXCESS) {
					CtracStringUtil.addValueWithSeparator(sb, "($" + AmountFormatter.format(policyData.getDeductibleAmount()) + " deductible)", " ");
				}
			}
			return sb.toString();
		}

		public String getRequiredValue() {
			StringBuffer sb = new StringBuffer();
			if(requiredCoverageViewDto.getPrimaryCoverageAmount_().compareTo(BigDecimal.ZERO) > 0){
				formatCoverageAmount(sb,requiredCoverageViewDto.getPrimaryCoverageAmount_(),CoverageType.PRIMARY);
			}
			if(requiredCoverageViewDto.getExcessCoverageAmount_().compareTo(BigDecimal.ZERO) > 0){
				formatCoverageAmount(sb,requiredCoverageViewDto.getExcessCoverageAmount_(),CoverageType.EXCESS);
			}
	    	return sb.toString();
		}

		public Integer getSortOrder() {
			return sortOrder;
		}

		public void setSortOrder(Integer sortOrder) {
			this.sortOrder = sortOrder;
		}

		public InsurableAssetType getInsurableAssetType() {
			return insurableAssetType;
		}

		public void setInsurableAssetType(InsurableAssetType insurableAssetType) {
			this.insurableAssetType = insurableAssetType;
		}

		public void setBuildingName(String buildingName) {
			this.buildingName = buildingName;
		}

		public List<PolicyData> getProvidedPolicies() {
			return providedPolicies;
		}

		public void setRequiredCoverageViewDto(RequiredCoverageViewDto requiredCoverageViewDto) {
			this.requiredCoverageViewDto = requiredCoverageViewDto;
		}

	}

	private class GapInCoverageRowComparator implements Comparator<GapInCoverageRow> {

		@Override
		public int compare(GapInCoverageRow o1, GapInCoverageRow o2) {
			if (o2 == null) {
				return -1;
			}
			if (o1 == null) {
				return 1;
			}
			if (o2.getSortOrder() == null) {
				return -1;
			}
			if (o1.getSortOrder() == null) {
				return 1;
			}
			if (o1.getSortOrder() != o2.getSortOrder()) {
				return o1.getSortOrder() < o2.getSortOrder() ? -1 : 1;
			}
			if (o2.getInsurableAssetType() == null) {
				return -1;
			}
			if (o1.getInsurableAssetType() == null) {
				return 1;
			}
			if (o1.getInsurableAssetType() != o2.getInsurableAssetType()) {
				return o1.getInsurableAssetType() == InsurableAssetType.STRUCTURE ? -1 : 1;
			}
			return -1;
		}

	}

	private class PolicyData {

		private CoverageType coverageType;

		private BigDecimal coverageAmount;

	    private BigDecimal deductibleAmount;

		public CoverageType getCoverageType() {
			return coverageType;
		}

		public void setCoverageType(CoverageType coverageType) {
			this.coverageType = coverageType;
		}

		public BigDecimal getCoverageAmount() {
			return coverageAmount;
		}

		public void setCoverageAmount(BigDecimal coverageAmount) {
			this.coverageAmount = coverageAmount;
		}

		public BigDecimal getDeductibleAmount() {
			return deductibleAmount;
		}

		public void setDeductibleAmount(BigDecimal deductibleAmount) {
			this.deductibleAmount = deductibleAmount;
		}

	}

	private class PolicyDataComparator implements Comparator<PolicyData> {

		@Override
		public int compare(PolicyData o1, PolicyData o2) {
			if (o2 == null) {
				return -1;
			}
			if (o1 == null) {
				return 1;
			}
			if (o2.getCoverageType() == null) {
				return -1;
			}
			if (o1.getCoverageType() == null) {
				return 1;
			}
			if (o1.getCoverageType() != o2.getCoverageType()) {
				return o1.getCoverageType() == CoverageType.PRIMARY ? -1 : 1;
			}
			return -1;
		}

	}



}
