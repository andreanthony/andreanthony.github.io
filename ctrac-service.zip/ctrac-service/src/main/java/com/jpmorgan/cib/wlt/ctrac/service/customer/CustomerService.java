package com.jpmorgan.cib.wlt.ctrac.service.customer;

import java.util.List;
import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EntitySearchCriteria;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.DataTablesRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.EntityDataTableDto;

public interface CustomerService {
		
	List<Customer> findAllByNameSoudexOrLike(String name);

	List<EntityDataTableDto> getEntities(DataTablesRequest dataTablesRequest);
	
	List<EntityDataTableDto> getEntities(EntitySearchCriteria entitySearchCriteria, DataTablesRequest dataTablesRequest);
	
	void mergeTo(Map<Long, EntityDataTableDto> entities, Long entityRidToKeep);
}
 
