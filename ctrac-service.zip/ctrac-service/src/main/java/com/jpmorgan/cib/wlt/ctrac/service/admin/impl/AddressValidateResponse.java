package com.jpmorgan.cib.wlt.ctrac.service.admin.impl;
import org.apache.commons.lang3.StringUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Address">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Zip5" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="Zip4" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="Error">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Number" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                             &lt;element name="Source" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="HelpFile" type="{http://www.w3.org/2001/XMLSchema}anyType"/>
 *                             &lt;element name="HelpContext" type="{http://www.w3.org/2001/XMLSchema}anyType"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "address"
})
@XmlRootElement(name = "AddressValidateResponse")
public class AddressValidateResponse {

    @XmlElement(name = "Address", required = true)
    protected AddressValidateResponse.Address address;

    public boolean hasError() {
        return address.getError() != null && StringUtils.isNotBlank(address.getError().getDescription());
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link AddressValidateResponse.Address }
     *     
     */
    public AddressValidateResponse.Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressValidateResponse.Address }
     *     
     */
    public void setAddress(AddressValidateResponse.Address value) {
        this.address = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Zip5" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="Zip4" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="Error">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Number" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                   &lt;element name="Source" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="HelpFile" type="{http://www.w3.org/2001/XMLSchema}anyType"/>
     *                   &lt;element name="HelpContext" type="{http://www.w3.org/2001/XMLSchema}anyType"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "address1",
        "address2",
        "city",
        "state",
        "zip5",
        "zip4",
        "error"
    })
    public static class Address {

        @XmlElement(name = "Address1", required = true)
        protected String address1;
        @XmlElement(name = "Address2", required = true)
        protected String address2;
        @XmlElement(name = "City", required = true)
        protected String city;
        @XmlElement(name = "State", required = true)
        protected String state;
        @XmlElement(name = "Zip5")
        protected String zip5;
        @XmlElement(name = "Zip4")
        protected String zip4;
        @XmlElement(name = "Error", required = true)
        protected ErrorResponse error;

        /**
         * Gets the value of the address1 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAddress1() {
            return address1;
        }

        /**
         * Sets the value of the address1 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAddress1(String value) {
            this.address1 = value;
        }

        /**
         * Gets the value of the address2 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAddress2() {
            return address2;
        }

        /**
         * Sets the value of the address2 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAddress2(String value) {
            this.address2 = value;
        }

        /**
         * Gets the value of the city property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCity() {
            return city;
        }

        /**
         * Sets the value of the city property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCity(String value) {
            this.city = value;
        }

        /**
         * Gets the value of the state property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getState() {
            return state;
        }

        /**
         * Sets the value of the state property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setState(String value) {
            this.state = value;
        }

        /**
         * Gets the value of the zip5 property.
         * 
         */
        public String getZip5() {
            return zip5;
        }

        /**
         * Sets the value of the zip5 property.
         * 
         */
        public void setZip5(String value) {
            this.zip5 = value;
        }

        /**
         * Gets the value of the zip4 property.
         * 
         */
        public String getZip4() {
            return zip4;
        }

        /**
         * Sets the value of the zip4 property.
         * 
         */
        public void setZip4(String value) {
            this.zip4 = value;
        }

        /**
         * Gets the value of the error property.
         * 
         * @return
         *     possible object is
         *     {@link AddressValidateResponse.Address.Error }
         *     
         */
        public ErrorResponse getError() {
            return error;
        }

        /**
         * Sets the value of the error property.
         * 
         * @param value
         *     allowed object is
         *     {@link AddressValidateResponse.Address.Error }
         *     
         */
        public void setError(ErrorResponse value) {
            this.error = value;
        }

        }

}
