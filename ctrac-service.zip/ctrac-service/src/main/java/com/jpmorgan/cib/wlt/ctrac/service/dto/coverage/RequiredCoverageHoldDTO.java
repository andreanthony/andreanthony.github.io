package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import java.io.Serializable;

public class RequiredCoverageHoldDTO implements Serializable {
    private static final long serialVersionUID = 1;
    private HoldDTO holdDto;
    private CoverageDetailsDTO coverageDetailsDTO;
    private InsurableAssetDTO insurabeAssetDTO;

    public HoldDTO getHoldDto() {
        return holdDto;
    }

    public void setHoldDto(HoldDTO holdDto) {
        this.holdDto = holdDto;
    }

    public CoverageDetailsDTO getCoverageDetailsDTO() {
        return coverageDetailsDTO;
    }

    public RequiredCoverageHoldDTO setCoverageDetailsDTO(CoverageDetailsDTO coverageDetailsDTO) {
        this.coverageDetailsDTO = coverageDetailsDTO;
        return this;
    }

    public InsurableAssetDTO getInsurabeAssetDTO() {
        return insurabeAssetDTO;
    }

    public RequiredCoverageHoldDTO setInsurabeAssetDTO(InsurableAssetDTO insurabeAssetDTO) {
        this.insurabeAssetDTO = insurabeAssetDTO;
        return this;
    }
}
