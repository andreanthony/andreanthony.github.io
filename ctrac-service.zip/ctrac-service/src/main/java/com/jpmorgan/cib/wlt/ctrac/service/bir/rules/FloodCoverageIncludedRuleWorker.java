package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;

public class FloodCoverageIncludedRuleWorker extends AbstractBIRRuleWorker {

	public FloodCoverageIncludedRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		GenericProofOfCoverageDTO floodInsuranceData = borrowerInsuranceReviewData.getProofOfCoverageData();
		if (floodInsuranceData.getInsuranceType() != InsuranceType.FLOOD) {
			return;
		}
		BIRRuleConclusionDTO floodCoverageIncludedConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get("floodCoverageIncluded");
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if ("Yes".equals(floodInsuranceData.getFloodCoverageIncluded())) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
		}
		floodCoverageIncludedConclusion.setConclusion(birConclusion.name());
	}

}
