package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.FloodInsuranceDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

public class CoverageActionResult {

	/**
	 * New Lp proof of coverage to issue
	 */
    private final List<ProofOfCoverageDTO> lpCoveragesToIssues = new ArrayList<ProofOfCoverageDTO>();
    
    private final List<ProofOfCoverageDTO> lpToRenewalNoChange = new ArrayList<ProofOfCoverageDTO>();
    
    private final List<ProofOfCoverageDTO> lpCoveragesToIssuesWithCancellation = new ArrayList<ProofOfCoverageDTO>();

    private final List<ProofOfCoverageDTO> lpCoveragesToIssueWithGap = new ArrayList<ProofOfCoverageDTO>();

    private final List<ProofOfCoverageDTO> lpCoveragesToUpdate = new ArrayList<ProofOfCoverageDTO>();

    /**
     * proof of coverage to cancel because no longer needed;
     */
    private final List<ProofOfCoverageDTO> lpCoveragesToCancels = new ArrayList<ProofOfCoverageDTO>();
    
    private final List<ProofOfCoverageDTO> lpCoveragesToCancelWithIssurance = new ArrayList<ProofOfCoverageDTO>();
    /**
     * the workItem Id of workflows to cancel
     */
    private final Set<Long> workFlowToCancel =  new HashSet<Long>();
    
    /**
     * task to move to the next workflow step
     */
    private final Set<Long> perfectionTaskToAdvance = new HashSet<Long>();
    
    /**
     * 
     */
    private Set<Long> policyToExpire = new HashSet<Long>();
    
    private Set<Long> policyToDelete = new HashSet<Long>();
    
    private final Long collateralId;
    private final Long triggerWorkItemId;
   
    private boolean moreActionsNeeded = true;
    private boolean lapseEmailSent = false;
   
    private Date lpSendDate;
    
    private String details;

	private Date coverageDate;

    public Date getLpSendDate() {
        return lpSendDate;
    }
    
    public CoverageActionResult(Long collateralId, Long triggerWorkItemId){
    	this.collateralId =  collateralId;
        this.triggerWorkItemId = triggerWorkItemId;
    }
    
    /**
     * @return the lpCoveragesToIssues
     */
    public List<ProofOfCoverageDTO> getLpCoveragesToIssues() {
        return lpCoveragesToIssues;
    }

    /**
     * @return the lpCoveragesToCancels
     */
    public List<ProofOfCoverageDTO> getLpCoveragesToCancels() {
        return lpCoveragesToCancels;
    }

    public void setLpSendDate(Date lpSendDate) {
        this.lpSendDate = lpSendDate;
    }

    public void addProofOfCoverageToIssue(ProofOfCoverageDTO proofOfCoverageDTO) {
        addToList(lpCoveragesToIssues, proofOfCoverageDTO);
    }

    public void addProofOfCoverageToIssue(Collection<ProofOfCoverageDTO> proofOfCoverageDTOs) {
        for(ProofOfCoverageDTO proofOfCoverageDTO : proofOfCoverageDTOs){
            addProofOfCoverageToIssue(proofOfCoverageDTO);
        }
    }
    
    public void removeLPCoverageToIssue(ProofOfCoverageDTO proofOfCoverageDTO) {
        lpCoveragesToIssues.remove(proofOfCoverageDTO);

    }
    
    public void addProofOfCoverageToCancel(ProofOfCoverageDTO proofOfCoverageDTO) {
        addToList(lpCoveragesToCancels, proofOfCoverageDTO);
    }
    
    public void addProofOfCoverageToCancel(Collection<ProofOfCoverageDTO> proofOfCoverageDTOs) {
        for(ProofOfCoverageDTO proofOfCoverageDTO : proofOfCoverageDTOs){
            addProofOfCoverageToCancel(proofOfCoverageDTO);
        }
    }

    public void removeLPCoverageToCancel(ProofOfCoverageDTO proofOfCoverageDTO) {
        lpCoveragesToCancels.remove(proofOfCoverageDTO);
    }
    
    /**
     * @return the details
     */
    public String getDetails() {
        return details;
    }

    /**
     * @param details the details to set
     */
    public void setDetails(String details) {
        this.details = details;
    }
    
    /**
     * @return the collateralId
     */
	public Long getCollateralId() {
		return collateralId;
	}


    private void addToList(List<ProofOfCoverageDTO> proofOfCoverageDTOs, ProofOfCoverageDTO proofOfCoverageDTO) {
        
        if(proofOfCoverageDTO != null){
            
            if (proofOfCoverageDTO.getRid()!=null && proofOfCoverageDTOs.contains(proofOfCoverageDTO)) {
                proofOfCoverageDTOs.remove(proofOfCoverageDTO);
            }
            
            proofOfCoverageDTOs.add(proofOfCoverageDTO);
        }
    }


	public Set<Long> getPolicyToExpire() {
		return policyToExpire;
	}


	public void setPolicyToExpire(Set<Long> policyToExpire) {
		this.policyToExpire = policyToExpire;
	}


	public List<ProofOfCoverageDTO> getLpToRenewalNoChange() {
		return lpToRenewalNoChange;
	}

	public boolean areMoreActionsNeeded() {
		return moreActionsNeeded;
	}


	public void setMoreActionsNeeded(boolean moreActionsNeeded) {
		this.moreActionsNeeded = moreActionsNeeded;
	}


	public Long getTriggerWorkItemId() {
		return triggerWorkItemId;
	}

	public Set<Long> getWorkFlowToCancel() {
		return workFlowToCancel;
	}

	public Set<Long> getPerfectionTaskToAdvance() {
		return perfectionTaskToAdvance;
	}

	public List<ProofOfCoverageDTO> getLpCoveragesToIssuesWithCancellation() {
		return lpCoveragesToIssuesWithCancellation;
	}

	public List<ProofOfCoverageDTO> getLpCoveragesToCancelWithIssue() {
		return lpCoveragesToCancelWithIssurance;
	}

	public List<ProofOfCoverageDTO> getLpPoliciesToIssueOnly(){
		List<ProofOfCoverageDTO> listLpPoliciesToIssueOnly = new ArrayList<ProofOfCoverageDTO>();
		for (ProofOfCoverageDTO proofOfCoverageDTO : this.lpCoveragesToIssues) {
			if(!lpCoveragesToIssuesWithCancellation.contains(proofOfCoverageDTO) && !lpCoveragesToIssueWithGap.contains(proofOfCoverageDTO)){
				listLpPoliciesToIssueOnly.add(proofOfCoverageDTO);
			}
		}
		return listLpPoliciesToIssueOnly;
	}
	
	public List<ProofOfCoverageDTO> getLpPoliciesToCancelOnly(){
		List<ProofOfCoverageDTO> listLpPoliciesToCancelOnly = new ArrayList<ProofOfCoverageDTO>();
		for (ProofOfCoverageDTO proofOfCoverageDTO : this.lpCoveragesToCancels) {
			if(!lpCoveragesToCancelWithIssurance.contains(proofOfCoverageDTO)){
				listLpPoliciesToCancelOnly.add(proofOfCoverageDTO);
			}
		}
		return listLpPoliciesToCancelOnly;
	}

	public boolean isLapseEmailSent() {
		return lapseEmailSent;
	}

	public void setLapseEmailSent(boolean lapseEmailSent) {
		this.lapseEmailSent = lapseEmailSent;
	}

	public Set<Long> getPolicyToDelete() {
		return policyToDelete;
	}

	public void setPolicyToDelete(Set<Long> policyToDelete) {
		this.policyToDelete = policyToDelete;
	}

    public List<ProofOfCoverageDTO> getLpCoveragesToIssueWithGap() {
		return lpCoveragesToIssueWithGap;
	}

	public void addProofOfCoverageToIssueWithGap(FloodInsuranceDTO lpPolicy) {
		if(lpPolicy != null) {
			lpCoveragesToIssueWithGap.add(lpPolicy);
		}
	}

	public List<ProofOfCoverageDTO> getLpCoveragesToUpdate() {
		return lpCoveragesToUpdate;
	}

	public void addProofOfCoverageToUpdate(ProofOfCoverageDTO lpPolicy) {
		if(lpPolicy != null) {
			lpCoveragesToUpdate.add(lpPolicy);
		}
	}

	public Date getCoverageDate() {
		return coverageDate;
	}

	public void setCoverageDate(Date coverageDate) {
		this.coverageDate = coverageDate;
	}


}
