package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class ProofOfPaymentRuleWorker extends AbstractBIRRuleWorker {

	public ProofOfPaymentRuleWorker(String key) {
		super(key, true);
	}

	public static final Set<String> EOI_REQUIRING_POP;
	static {
		Set<String> requiresPOP = new HashSet<String>();
		requiresPOP.add("AWP");
		requiresPOP.add("BWP");
		EOI_REQUIRING_POP = Collections.unmodifiableSet(requiresPOP);
	}
	
	public static final Set<String> VALID_POP;
	static {
		Set<String> validPOP = new HashSet<String>();
		validPOP.add("SSRFIA");
		validPOP.add("OPE");
		validPOP.add("ACHR");
		validPOP.add("CCR");
		validPOP.add("COCC");
		validPOP.add("EFIA");
		validPOP.add("HTEAPPMAC");
		VALID_POP = Collections.unmodifiableSet(validPOP);
	}
	
	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRRuleConclusionDTO proofOfPaymentConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if (!EOI_REQUIRING_POP.contains(borrowerInsuranceReviewData.getEoiType())) {
			birConclusion = BorrowerInsuranceReviewConclusion.NONE;
		} else if (VALID_POP.contains(borrowerInsuranceReviewData.getProofOfPayment())) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
		}
		proofOfPaymentConclusion.setConclusion(birConclusion.name());
	}

}
