package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;

public class ReconExcelFile {

	private static final Logger LOG = Logger.getLogger(ReconExcelFile.class);

	private String filePath;
	private Date reportDate;
	private Date activityDate;
	private static final String FILE_NAME="CTRAC Althans Recon Report.xlsx";
	
	public ReconExcelFile(String filePath, Date reportDate, Date activityDate){
		this.filePath = filePath;
		this.reportDate = reportDate;
		this.activityDate = activityDate;
	}
	
	public File generate(Map<LoanSystem, List<ReconPremiumsRow>> premiums, Map<LoanSystem, List<ReconRefundsRow>> refunds) {
		FileOutputStream fos = null;
		try {
			File file = new File(filePath + FILE_NAME);
			fos = new FileOutputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook();
			insertPremiumSheet(workbook, premiums, reportDate, activityDate);
			insertRefundSheet(workbook, refunds, reportDate, activityDate);
			workbook.write(fos);
			workbook.close();
			return file;
		} catch (IOException e) {
			LOG.error("Something went wrong generating the Recon File",e);
			return null;
		} finally {
			if(fos != null){
				try {
					fos.close();
				} catch (IOException e) {
					LOG.error("Something went wrong closing the FileOutputStream",e);
				}
			}
		}
	}

	private void insertPremiumSheet(XSSFWorkbook lpWorkbook, Map<LoanSystem, List<ReconPremiumsRow>> premiums, Date reportDate, Date activityDate) {
		ReconExcelPremiumsSheet premiumSheet = new ReconExcelPremiumsSheet();
		premiumSheet.insertInto(lpWorkbook, premiums, reportDate, activityDate);
	}

	private void insertRefundSheet(XSSFWorkbook lpWorkbook, Map<LoanSystem, List<ReconRefundsRow>> refunds, Date reportDate, Date activityDate){
		ReconExcelRefundsSheet refundSheet = new ReconExcelRefundsSheet();
		refundSheet.insertInto(lpWorkbook, refunds, reportDate, activityDate);
	}
}
