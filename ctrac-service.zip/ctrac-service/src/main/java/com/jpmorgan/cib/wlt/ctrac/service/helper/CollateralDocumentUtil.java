package com.jpmorgan.cib.wlt.ctrac.service.helper;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.StreamManagementUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FileContent;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CollateralDocumentUtil {
	private static DateFormat  formatter_date_us = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
	private static String tableCSS  = "table tr, table td , table th{border : 1px solid #848484;}";
	private static final Logger logger = Logger.getLogger(CollateralDocumentUtil.class);
	
	public static CollateralDocument getCollateralDocument(EmailAttributeHolder emailAttributeHolder){
		logger.info("getCollateralDocument()::Begin");
		CollateralDocument document=new CollateralDocument();
		FileContent fileContent=new FileContent();
		document.setFileContent(fileContent);
		document.setFileName("ZONE_VARIANCE_AGENT_EMAIL");
		document.setFileNameWithExt("ZONE_VARIANCE_AGENT_EMAIL.PDF");
		document.getFileContent().setFileContent(getPdfAsByteArray(emailAttributeHolder));
		document.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);
		document.setDocIdentifier(CtracAppConstants.EMAIL_DOCUMENT_IDENTIFIER);
		logger.info("getCollateralDocument()::End");
		return document;
	}
	
	private static byte[] getPdfAsByteArray(EmailAttributeHolder emailAttributeHolder) {
		logger.info("getPdfAsByteArray()::Begin");
		InputStream emailBodyAsInputStream = null;
		InputStream emailStylingAsInputStream = null;
        String emailBody = emailAttributeHolder.getEmailBody();
        if(emailBody ==null){
            logger.error("No email body found to create PDF");
            return null;
        }
        emailBody = emailBody.replace("<body>", getEmailPrefix(emailAttributeHolder));
        return getPdfBytes(emailBodyAsInputStream, emailStylingAsInputStream, emailBody);
    }

    static byte[] getPdfBytes(InputStream emailBodyAsInputStream, InputStream emailStylingAsInputStream, String emailBody) {
        try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            Document document = new Document();
            PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
            document.open();
            emailBodyAsInputStream = IOUtils.toInputStream(emailBody, "UTF-8");
            emailStylingAsInputStream = IOUtils.toInputStream(tableCSS, "UTF-8");
            XMLWorkerHelper.getInstance().parseXHtml(writer, document, emailBodyAsInputStream ,emailStylingAsInputStream);
            document.close();
            logger.info("getPdfAsByteArray()::End");
            return byteArrayOutputStream.toByteArray();
        } catch (DocumentException e) {
            logger.error("DocumentException while creating the PDF"+ e.getMessage(),e);
            throw new CTracApplicationException("E0222", CtracErrorSeverity.APPLICATION);
        } catch (IOException e) {
            logger.error("IOException while creating the PDF"+ e.getMessage(),e);
            throw new CTracApplicationException("E0222", CtracErrorSeverity.APPLICATION);
        } finally {
            StreamManagementUtil.handleClosingStream(emailBodyAsInputStream,"the Reading of EmailBody InputStream");
            StreamManagementUtil.handleClosingStream(emailStylingAsInputStream,"the Reading of EmailStyle InputStream");
        }
    }


    static String getEmailPrefix(EmailAttributeHolder emailAttributeHolder){
		String prefix = "<body><p style='font-family:Verdana;font-size:13px;'><b>From:</b> <FROM><br></br><b>To:</b> <TO><br></br><b>Cc:</b> <CC><br></br><b>Sent:</b><SENT><br></br><b>Subject:</b><SUBJECT><br></br><br></br><br></br></p>";
		prefix = prefix.replace("<FROM>", StringUtils.defaultString(emailAttributeHolder.getFromAddress()));
		prefix = prefix.replace("<TO>", StringUtils.defaultString(StringUtils.join(emailAttributeHolder.getToAddresses(), "; ")));
		prefix = prefix.replace("<CC>", StringUtils.defaultString(StringUtils.join(emailAttributeHolder.getCcAddresses(), "; ")));
		prefix = prefix.replace("<SENT>",formatter_date_us.format(new Date()));
		prefix = prefix.replace("<SUBJECT>", StringUtils.defaultString(emailAttributeHolder.getSubject()));
		return prefix;
	}
	
}
