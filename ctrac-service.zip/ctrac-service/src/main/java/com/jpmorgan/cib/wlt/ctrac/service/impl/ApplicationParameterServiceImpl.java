package com.jpmorgan.cib.wlt.ctrac.service.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ApplicationParameter;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.ApplicationParameterRepository;
import com.jpmorgan.cib.wlt.ctrac.service.ApplicationParameterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;

@Service
public class ApplicationParameterServiceImpl implements ApplicationParameterService {

    @Autowired
    private ApplicationParameterRepository applicationParameterRepository;

    @Override
    public Date getDate(String key) {
        return getDate(key, null);
    }

    @Override
    public Date getDate(String key, Date defaultValue) {
        ApplicationParameter appParam = applicationParameterRepository.findOne(key);
        if (appParam == null || appParam.getDateValue() == null) {
            return defaultValue;
        }
        return (Date) appParam.getDateValue().clone();
    }

    @Override
    public Integer getInteger(String key) {
        return getInteger(key, null);
    }

    @Override
    public Integer getInteger(String key, Integer defaultValue) {
        ApplicationParameter appParam = applicationParameterRepository.findOne(key);
        if (appParam == null || appParam.getNumberValue() == null) {
            return defaultValue;
        }
        return appParam.getNumberValue().intValue();
    }

    @Override
    public BigDecimal getNumber(String key) {
        return getNumber(key, null);
    }

    @Override
    public BigDecimal getNumber(String key, BigDecimal defaultValue) {
        ApplicationParameter appParam = applicationParameterRepository.findOne(key);
        if (appParam == null || appParam.getNumberValue() == null) {
            return defaultValue;
        }
        return appParam.getNumberValue();
    }

    @Override
    public String getString(String key) {
        return getString(key, null);
    }

    @Override
    public String getString(String key, String defaultValue) {
        ApplicationParameter appParam = applicationParameterRepository.findOne(key);
        if (appParam == null || appParam.getStringValue() == null) {
            return defaultValue;
        }
        return appParam.getStringValue();
    }

}
