package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.util.HashMap;

public class SystemData implements Serializable {
	
	private static final long serialVersionUID = 390216082727337133L;
	private String dbName;
	private String dbServiceName;
	private String dbUserName;
	private String passwordProvider;
	private String tmEnvironment;
	
	private String projectName;
	private String projectVersion;
	private String buildNumber;
	private String svnURL;
	private String svnRevision;
	
	private String hostName;
	private String ipAddress;
	private String url;
	
	private String message;
	
	private HashMap<String, String> cronJobs = new  HashMap<String, String>();
	
	public HashMap<String, String> getCronJobs() {
		return cronJobs;
	}
	public void setCronJobs(HashMap<String, String> cronJobs) {
		this.cronJobs = cronJobs;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getDbServiceName() {
		return dbServiceName;
	}
	public void setDbServiceName(String dbServiceName) {
		this.dbServiceName = dbServiceName;
	}
	public String getDbUserName() {
		return dbUserName;
	}
	public void setDbUserName(String dbUserName) {
		this.dbUserName = dbUserName;
	}
	public String getPasswordProvider() {
		return passwordProvider;
	}
	public void setPasswordProvider(String passwordProvider) {
		this.passwordProvider = passwordProvider;
	}
	public String getTmEnvironment() {
		return tmEnvironment;
	}
	public void setTmEnvironment(String tmEnvironment) {
		this.tmEnvironment = tmEnvironment;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectVersion() {
		return projectVersion;
	}
	public void setProjectVersion(String projectVersion) {
		this.projectVersion = projectVersion;
	}
	public String getBuildNumber() {
		return buildNumber;
	}
	public void setBuildNumber(String buildNumber) {
		this.buildNumber = buildNumber;
	}
	public String getSvnURL() {
		return svnURL;
	}
	public void setSvnURL(String svnURL) {
		this.svnURL = svnURL;
	}
	public String getSvnRevision() {
		return svnRevision;
	}
	public void setSvnRevision(String svnRevision) {
		this.svnRevision = svnRevision;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
