package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.EscrowType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.ValidEmailAddress;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import java.util.*;

public class LoanData extends BaseDto implements Cloneable, Comparator<LoanData> {

    /**
	 *
	 */
    private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(LoanData.class);
    private String []  arrCommercialBankingLOBCodes = {"MM","CBC","CCC","FF","GNPH","CCB"};
    private Long rid;
    private LoanStatus status;
    public static final String CONST_PRIMARY_FLAG = "Yes";

    @NoInvalidCharacters
    private String loanNumber;

    private String loanAccountingSystem;
    private String lineOfBusiness;
    private String lineOfBusinessCodeConst;
    private String lobDescription;
	private String loanType;
	private String escrowType;
    @NoInvalidCharacters private String agentLeadBankName;
    @NoInvalidCharacters @ValidEmailAddress private String agentLeadBankEmail;
    private String loadedDate;
    private String releasedDate;
    private String primaryFlag;
    private boolean isCancel;
    private boolean displayReleaseDate = false;
    private Collection<Long> collateralRids = new ArrayList<>();
    private boolean businessBankingLOB = false;
    private boolean globalWealthManagementLOB = false;
    private boolean commercialBankingLOB = false;
    private boolean otherLOB = false;

    private Date releasedDt;
	//borrowersData will contain customer who are either collateral owners or only borrower
    private List<CustomerData> borrowersData = new ArrayList<>();
    private List<CustomerData> ownersList = new ArrayList<>();

    private Boolean chkPrimaryLoan;
	/*
     * Must not have a setter, This is just a pointer to and element inside the
     * borrowersData array: Update to this element are immediately reflected the
     * share object inside the array
     */
    //TODO remove this primary borrower
    @Deprecated
    private CustomerData primaryBorrower;

    private LoanData loadTimeValue;

	public String getAllBorrowerNames(){
    	String result = "";
    	for(CustomerData cd: borrowersData){
    		if(StringUtils.isBlank(cd.getBorrowerName())){
    			continue;
    		}
    		else{
    			result = result + cd.getBorrowerName() + " | ";
    		}
    	}
    	return result.length() < 3? result: result.substring(0, result.length() - 3);
    }

    public Date getReleasedDt() {
		return releasedDt;
	}

	public void setReleasedDt(Date releasedDt) {
		this.releasedDt = releasedDt;
	}



    public Long getRid() {
    	return rid;
    }

    public void setRid(Long rid) {
    	this.rid = rid;
    }

    public LoanStatus getStatus() {
		return status;
	}

	public void setStatus(LoanStatus status) {
		this.status = status;
	}

	public String getLoanNumber() {
    	return loanNumber;
    }

    public void setLoanNumber(String loanNumber) {
    	this.loanNumber = loanNumber;
    }

    public LoanData loanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
		return this;
    }

    public String getLoanAccountingSystem() {
    	return loanAccountingSystem;
    }


    public String getEscrowType() {
		return escrowType;
	}

	public void setEscrowType(String escrowType) {
		this.escrowType = escrowType;
	}

	public String getAgentLeadBankName() {
		return agentLeadBankName;
	}

	public void setAgentLeadBankName(String agentLeadBankName) {
		this.agentLeadBankName = agentLeadBankName;
	}

	public String getAgentLeadBankEmail() {
		return agentLeadBankEmail;
	}

	public void setAgentLeadBankEmail(String agentLeadBankEmail) {
		this.agentLeadBankEmail = agentLeadBankEmail;
	}

	public void setLoanAccountingSystem(String loanAccountingSystem) {
    	this.loanAccountingSystem = loanAccountingSystem;
    }

    public LoanData loanAccountingSystem(String loanAccountingSystem) {
    	this.loanAccountingSystem = loanAccountingSystem;
    	return this;
    }

    public String getLineOfBusiness() {
    	return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
    	this.lineOfBusiness = lineOfBusiness;
    }

    public LoanData lineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
		return this;
    }

    public String getLoanType() {
    	return loanType;
    }

    public void setLoanType(String loanType) {
    	this.loanType = loanType;
    }

    public LoanData loanType(String loanType) {
		this.loanType = loanType;
		return this;
	}

    public List<CustomerData> getBorrowersData() {
    	return borrowersData;
    }

    public void addAllBorrowersData(List<CustomerData> borrowers) {
		this.borrowersData.addAll(borrowers);
		getPrimaryBorrower();
    }

    /**
     * Use some criteria to identify and return the loan marked as primary; We
     * temporarily will assume the primary loan to be the one with the lowest
     * rid
     *
     * @return the PrimaryBorrower
     */
	public CustomerData getPrimaryBorrower() {
		if (borrowersData.isEmpty()) {
			return null;
		}
		if (primaryBorrower != null) {
			return primaryBorrower;
		}

		// for now, assume the primary borrowersData is the one with the lowest rid
		primaryBorrower = borrowersData.get(0);
		for (CustomerData customerData : borrowersData) {
			if (customerData.getRid() != null && (customerData.getRid() < this.primaryBorrower.getRid())) {
				primaryBorrower = customerData;
			}
		}
		return primaryBorrower;
	}

	public List<CustomerData> getOwnersList() {
		return ownersList;
	}

	public void setOwnersList(List<CustomerData> ownersList) {
		this.ownersList = ownersList;
	}

	public boolean hasChanged() {
		if (this.loadTimeValue == null || this.getRid() == null) {
			return true;
		}

		return !deepEquals(this.loadTimeValue);
    }


    public void saveACopy() {
	    
		if (this.getBorrowersData() != null && !this.getBorrowersData().isEmpty()) {
			for (CustomerData elem : this.getBorrowersData()) {
				elem.saveACopy();
			}
		}
		try {
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
		}
    }

	public boolean hasLoanChanged() {
		if (this.loadTimeValue == null || this.getRid() == null) {
			return true;
		}
		return !loanEquals(this.loadTimeValue);
	}
	private boolean loanEquals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		LoanData other = (LoanData) obj;
		if (escrowType == null) {
			if (other.escrowType != null) {
				return false;
			}
		} else if (other.escrowType != null &&!escrowType.equals(other.escrowType)) {
			return false;
		}
		if (!subDeepEquals(other)) return false;
		return true;
	}
    private boolean deepEquals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		LoanData other = (LoanData) obj;
		if(borrowerDataChanged()){
			return false;
		}
		if (status == null) {
			if (other.status != null) {
				return false;
			}
		} else if (!status.equals(other.status)) {
			return false;
		}
		if (!subDeepEquals(other)) return false;
		return true;
    }

	private boolean subDeepEquals(LoanData other) {
		if (lineOfBusiness == null) {
			if (other.lineOfBusiness != null) {
				return false;
			}
		} else if (!lineOfBusiness.equals(other.lineOfBusiness)) {
			return false;
		}
		if (loanAccountingSystem == null) {
			if (other.loanAccountingSystem != null) {
				return false;
			}
		} else if (!loanAccountingSystem.equals(other.loanAccountingSystem)) {
			return false;
		}
		if (escrowType == null) {
			if (other.escrowType != null) {
				return false;
			}
		} else if (!escrowType.equals(other.escrowType)) {
			return false;
		}
		if (loanNumber == null) {
			if (other.loanNumber != null) {
				return false;
			}
		} else if (!loanNumber.equals(other.loanNumber)) {
			return false;
		}
		if (loanType == null) {
			if (other.loanType != null) {
				return false;
			}
		} else if (!loanType.equals(other.loanType)) {
			return false;
		}
		if (rid == null) {
			if (other.rid != null) {
				return false;
			}
		} else if (!rid.equals(other.rid)) {
			return false;
		}
		if (StringUtils.isEmpty(releasedDate)) {
			if (StringUtils.isNotEmpty(other.releasedDate)) {
				return false;
			}
		} else if (!releasedDate.equals(other.releasedDate)) {
			return false;
		}

		if (loadedDate == null) {
			if (other.loadedDate != null) {
				return false;
			}
		} else if (!loadedDate.equals(other.loadedDate)) {
			return false;
		}
		if (agentLeadBankName == null) {
			if (other.agentLeadBankName != null) {
				return false;
			}
		} else if (!agentLeadBankName.equals(other.agentLeadBankName)) {
			return false;
		}
		if (agentLeadBankEmail == null) {
			if (other.agentLeadBankEmail != null) {
				return false;
			}
		} else if (!agentLeadBankEmail.equals(other.agentLeadBankEmail)) {
			return false;
		}
		if(!StringUtils.equals(other.getPrimaryFlag(),this.getPrimaryFlag())){
			return false;
		}

		return true;
	}

	public boolean borrowerDataChanged() {
		return this.isBorrowerChanged() || this.isBorrowerDeleted();
	}

	private boolean isBorrowerDeleted() {
		return this.loadTimeValue.getBorrowersData().stream().anyMatch(borrowerLoadTimeVal ->
				this.borrowersData.stream().noneMatch(borrower -> borrowerLoadTimeVal.getRid().equals(borrower.getRid())));
	}

	private boolean isBorrowerChanged() {
		return this.borrowersData.stream().anyMatch(CustomerData::hasChanged);
	}


    @Override
    public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
    }

    @Override
    public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		LoanData other = (LoanData) obj;
		if (rid == null) {
			if (other.rid != null) {
				return false;
			}
		} else if (!rid.equals(other.rid)) {
			return false;
		}
		return true;
    }

	@Override
	protected LoanData clone() throws CloneNotSupportedException {
		LoanData loanData = (LoanData) super.clone();
		loanData.borrowersData = new ArrayList<>(this.borrowersData);
		return loanData;
	}

	public Boolean getChkPrimaryLoan() {
		return chkPrimaryLoan;
	}

	public void setChkPrimaryLoan(Boolean chkPrimaryLoan) {
		this.chkPrimaryLoan = chkPrimaryLoan;
	}

	public boolean isPrimary() {
		return CONST_PRIMARY_FLAG.equalsIgnoreCase(primaryFlag);
	}

	public String getPrimaryFlag() {
		return primaryFlag;
	}

	public void setPrimaryFlag(String primaryFlag) {
		this.primaryFlag = primaryFlag;
	}

    @Override
    public int compare(LoanData loanData1, LoanData loanData2) {
    	if(loanData1.getLoadedDate()==null && loanData2.getLoadedDate()==null){
    		return 0;
    	}else if(loanData1.getLoadedDate()==null && loanData2.getLoadedDate()!=null){
			return -1;
		}else if(loanData1.getLoadedDate()!=null && loanData2.getLoadedDate()==null){
			return 1;
		}else{
			return loanData1.loadedDate.compareTo(loanData2.loadedDate);
		}
    }

	public void setLoadedDate(String loadedDate) {
		this.loadedDate = loadedDate;
	}

	public void setReleasedDate(String releasedDate) {
		this.releasedDate = releasedDate;
	}

	public String getLoadedDate() {
		return loadedDate;
	}

	public String getReleasedDate() {
		return releasedDate;
	}

	public boolean isCancel() {
		return isCancel;
	}

	public void setCancel(boolean isCancel) {
		this.isCancel = isCancel;
	}

    public boolean isDisplayReleaseDate() {
		return displayReleaseDate;
	}

	public void setDisplayReleaseDate(boolean displayReleaseDate) {
		this.displayReleaseDate = displayReleaseDate;
	}

    public String getLobDescription() {
		return lobDescription;
	}

	public void setLobDescription(String lobDescription) {
		this.lobDescription = lobDescription;
	}

	public Collection<Long> getCollateralRids() {
		return collateralRids;
	}

	public void setCollateralRids(Collection<Long> collateralRids) {
		this.collateralRids = collateralRids;
	}

	public boolean isBusinessBankingLOB() {
    	businessBankingLOB = false;
    	if("BB".equals(lineOfBusiness)){
    		businessBankingLOB = true;
    	}
		return businessBankingLOB;
	}

	public boolean isGlobalWealthManagementLOB() {
		globalWealthManagementLOB = false;
    	if("WM".equals(lineOfBusiness)){
    		globalWealthManagementLOB = true;
    	}
		return globalWealthManagementLOB;
	}

	public boolean isCommercialBankingLOB() {
		commercialBankingLOB = false;
		for(String lob : arrCommercialBankingLOBCodes){
			if(lob.equals(lineOfBusiness)){
	    		commercialBankingLOB = true;
	    		break;
	    	}
		}
		return commercialBankingLOB;
	}

	public boolean isOtherLOB() {
		otherLOB = false;
		if(isBusinessBankingLOB() || isGlobalWealthManagementLOB() || isCommercialBankingLOB()){
			otherLOB  = true;
		}
    	return otherLOB;
	}


	public boolean isNonEscrow(){
		return EscrowType.NON_ESCROW.name().equals(this.getEscrowType());
	}

	public String getLineOfBusinessCodeConst() {
		return lineOfBusinessCodeConst;
	}

	public void setLineOfBusinessCodeConst(String lineOfBusinessCodeConst) {
		this.lineOfBusinessCodeConst = lineOfBusinessCodeConst;
	}
}
