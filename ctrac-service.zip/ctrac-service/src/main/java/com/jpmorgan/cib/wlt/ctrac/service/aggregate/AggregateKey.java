package com.jpmorgan.cib.wlt.ctrac.service.aggregate;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LpInsuranceVendor;

public class AggregateKey {
	
	public AggregateKey(String key) {
		this.key = key;
	}
	
	public AggregateKey(String key, LpInsuranceVendor vendor) {
		this.key = key;
		this.vendor = vendor;
	}
	
	private String key;
	private LpInsuranceVendor vendor;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public LpInsuranceVendor getVendor() {
		return vendor;
	}
	public void setVendor(LpInsuranceVendor vendor) {
		this.vendor = vendor;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		result = prime * result + ((vendor == null) ? 0 : vendor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AggregateKey other = (AggregateKey) obj;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		if (vendor != other.vendor)
			return false;
		return true;
	}

}
