package com.jpmorgan.cib.wlt.ctrac.service.bir.impl;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.CoverageDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;

public class AmountMismatchUtil {

	static boolean amountsMismatch(ProvidedCoverageDTO currProvidedCoverage) {
		BigDecimal currCoverageAmount = null;
		CoverageDetailsDTO currCoverageDetails = currProvidedCoverage.getCoverageDetailsDTO();
		if (currCoverageDetails != null && StringUtils.isNotBlank(currCoverageDetails.getCoverageAmount())) {
			currCoverageAmount = AmountFormatter.parse(currCoverageDetails.getCoverageAmount());
		}
		BigDecimal prevCoverageAmount = null;
		if (currCoverageDetails != null && currCoverageDetails.getLoadTimeValue() != null &&
				StringUtils.isNotBlank(currCoverageDetails.getLoadTimeValue().getCoverageAmount())) {
			prevCoverageAmount = AmountFormatter.parse(currCoverageDetails.getLoadTimeValue().getCoverageAmount());
		}
		if (currCoverageAmount == null) {
			return prevCoverageAmount != null;
		} else if (prevCoverageAmount == null) {
			return true;
		}
		return currCoverageAmount.compareTo(prevCoverageAmount) != 0;
	}
	
	static void setMismatch(ProvidedCoverageDTO providedCoverage) {
		providedCoverage.setVerifyCovAmountPriorMissMatch(
				AmountFormatter.format(providedCoverage.getCoverageAmount()));
		providedCoverage.setCoverageAmount(null);
		providedCoverage.setShowMismatchAmounts(true);
	}
	
	static void setMatch(ProvidedCoverageDTO providedCoverage) {
		providedCoverage.setVerifyCovAmountPriorMissMatch(
				AmountFormatter.format(providedCoverage.getCoverageAmount()));
		providedCoverage.setCoverageAmount(
				AmountFormatter.format(providedCoverage.getCoverageAmount()));
		providedCoverage.setShowMismatchAmounts(false);
	}

	public static void setLoadTimeValueAmount(ProvidedCoverageDTO providedCoverage) {
		if(providedCoverage.getCoverageAmount() == null && providedCoverage.getCoverageDetailsDTO().getLoadTimeValue() != null) {
			providedCoverage.setCoverageAmount(
				AmountFormatter.format(providedCoverage.getCoverageDetailsDTO().getLoadTimeValue().getCoverageAmount()));
		}
	}
	
}
