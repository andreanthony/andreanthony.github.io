package com.jpmorgan.cib.wlt.ctrac.service.bir.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRMode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AgentData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ContactDetailDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRInsurableAssetDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.BlanketCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;

public class BIRCloningHelper {

	public static void cloneBIRData(BorrowerInsuranceReviewDTO sourceBIRData,
			BorrowerInsuranceReviewDTO targetBIRData,  BIRMode birMode) {
		cloneProofOfCoverageDTO(sourceBIRData.getProofOfCoverageData(), targetBIRData.getProofOfCoverageData(), birMode);
		targetBIRData.setCondoAssociationPolicy(sourceBIRData.getCondoAssociationPolicy());
		targetBIRData.setTotalNumberOfCondoUnits(sourceBIRData.getTotalNumberOfCondoUnits());
		targetBIRData.setIndividualCondoUnitNumbers(sourceBIRData.getIndividualCondoUnitNumbers());
		targetBIRData.setJpmListedAsMortgageePayee(sourceBIRData.getJpmListedAsMortgageePayee());
		targetBIRData.setJpmListedAsLenderLossPayee(sourceBIRData.getJpmListedAsLenderLossPayee());
		targetBIRData.setJpmLienPosition(sourceBIRData.getJpmLienPosition());
		//When a replacement - remove the Evidence of Insurance when cloning
		targetBIRData.setEoiType(BIRMode.REPLACE == birMode ?
				null : sourceBIRData.getEoiType());
	}
	
	/**
	 * - The renewal policy should have an effective date equal to the expiring policy's expiration
	 * date. The expiration date should be selected by the user.
	 * - The replace policy should have an effective date equal to the effective date of the source BIR
	 * @param sourceProofOfCoverageData
	 * @param targetProofOfCoverageData
	 */
	private static void cloneProofOfCoverageDTO(GenericProofOfCoverageDTO sourceProofOfCoverageData,
			GenericProofOfCoverageDTO targetProofOfCoverageData, BIRMode birMode) {
		if (targetProofOfCoverageData == null) {
			return;
		}
		targetProofOfCoverageData.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
		//When a renewal - effective date equals the expiration date of the source
		targetProofOfCoverageData.setEffectiveDate(BIRMode.RENEWAL == birMode ?
				sourceProofOfCoverageData.getExpirationDate() : sourceProofOfCoverageData.getEffectiveDate());
		targetProofOfCoverageData.setExpirationDate(null);
		//When a replacement - remove the policy type when cloning
		targetProofOfCoverageData.setPolicyType(BIRMode.REPLACE == birMode ?
				null : sourceProofOfCoverageData.getPolicyType());
		targetProofOfCoverageData.setPolicyNumber(sourceProofOfCoverageData.getPolicyNumber());
		targetProofOfCoverageData.setInsuredName(sourceProofOfCoverageData.getInsuredName());
		targetProofOfCoverageData.setInsuranceAgency(sourceProofOfCoverageData.getInsuranceAgency());
		targetProofOfCoverageData.setAgentData(cloneAgentData(sourceProofOfCoverageData.getAgentData()));
		targetProofOfCoverageData.setBuildingDeductible(sourceProofOfCoverageData.getBuildingDeductible());
		targetProofOfCoverageData.setContentsDeductible(sourceProofOfCoverageData.getContentsDeductible());
		targetProofOfCoverageData.setInsuranceType(sourceProofOfCoverageData.getInsuranceType());
		targetProofOfCoverageData.setCoverageType(sourceProofOfCoverageData.getCoverageType());
		targetProofOfCoverageData.setBlanketCoverageData(
				cloneBlanketCoverageData(sourceProofOfCoverageData.getBlanketCoverageData()));
		targetProofOfCoverageData.setFloodCoverageIncluded(sourceProofOfCoverageData.getFloodCoverageIncluded());
		targetProofOfCoverageData.setCoversAllRiskOfFlood(sourceProofOfCoverageData.getCoversAllRiskOfFlood());
		targetProofOfCoverageData.setFloodZonesListed(sourceProofOfCoverageData.getFloodZonesListed());
		targetProofOfCoverageData.setParentPolicyRid(sourceProofOfCoverageData.getRid());
	}

	private static AgentData cloneAgentData(AgentData sourceAgentData) {
		if (sourceAgentData == null) {
			return null;
		}
		AgentData targetAgentData = new AgentData();
		ContactDetailDto sourceContactDetailDto = sourceAgentData.getContactDetailDto();
		if (sourceContactDetailDto == null) {
			return targetAgentData;
		}
		ContactDetailDto targetContactDetailDto = new ContactDetailDto();
		targetContactDetailDto.setFaxNumber(sourceContactDetailDto.getFaxNumber());
		targetContactDetailDto.setPhoneNumber(sourceContactDetailDto.getPhoneNumber());
		targetContactDetailDto.setEmailAddress(sourceContactDetailDto.getEmailAddress());
		targetAgentData.setContactDetailDto(targetContactDetailDto);
		return targetAgentData;
	}
	
	private static BlanketCoverageDTO cloneBlanketCoverageData(BlanketCoverageDTO sourceBlanketCoverageData) {
		if (sourceBlanketCoverageData == null) {
			return null;
		}
		BlanketCoverageDTO targetBlanketCoverageData = new BlanketCoverageDTO();
		targetBlanketCoverageData.setBlanketCoverageType(sourceBlanketCoverageData.getBlanketCoverageType());
		targetBlanketCoverageData.setBlanketCombinedAmount(sourceBlanketCoverageData.getBlanketCombinedAmount());
		targetBlanketCoverageData.setBlanketBuildingAmount(sourceBlanketCoverageData.getBlanketBuildingAmount());
		targetBlanketCoverageData.setBlanketContentAmount(sourceBlanketCoverageData.getBlanketContentAmount());
		return targetBlanketCoverageData;
	}
	
	public static void cloneBIRCollateralDetailsDTO(BIRCollateralDetailsDTO expiringCollateralDetailsData,
			BIRCollateralDetailsDTO renewalCollateralDetailsData) {
		if (expiringCollateralDetailsData == null) {
			return;
		}
		renewalCollateralDetailsData.setPolicyAddressData(
				cloneAddressData(expiringCollateralDetailsData.getPolicyAddressData()));
		renewalCollateralDetailsData.setPolicyFloodZone(expiringCollateralDetailsData.getPolicyFloodZone());
		renewalCollateralDetailsData.setGrandfathered(expiringCollateralDetailsData.getGrandfathered());

		for (BIRInsurableAssetDetailsDTO renewalInsurableAssetDetailsData :
				renewalCollateralDetailsData.getInsurableAssetDetailsMap().values()) {
			BIRInsurableAssetDetailsDTO expiringInsurableAssetDetailsData =
					expiringCollateralDetailsData.getInsurableAssetDetailsMap().get(
							renewalInsurableAssetDetailsData.getInsurableAssetSortOrder());
			cloneBIRInsurableAssetDetailsDTO(expiringInsurableAssetDetailsData, renewalInsurableAssetDetailsData);
		}
	}
	
	public static void cloneBIRInsurableAssetDetailsDTO(BIRInsurableAssetDetailsDTO expiringInsurableAssetDetailsData,
			BIRInsurableAssetDetailsDTO renewalInsurableAssetDetailsData) {
		if (expiringInsurableAssetDetailsData == null) {
			return;
		}
		renewalInsurableAssetDetailsData.setPropertyType(expiringInsurableAssetDetailsData.getPropertyType());
	}
	
	private static AddressDto cloneAddressData(AddressDto expiringPolicyAddressData) {
		if (expiringPolicyAddressData == null) {
			return null;
		}
		AddressDto renewalPolicyAddressData = new AddressDto();
		renewalPolicyAddressData.setStreetAddress(expiringPolicyAddressData.getStreetAddress());
		renewalPolicyAddressData.setCity(expiringPolicyAddressData.getCity());
		renewalPolicyAddressData.setZipCode(expiringPolicyAddressData.getZipCode());
		renewalPolicyAddressData.setState(expiringPolicyAddressData.getState());
		renewalPolicyAddressData.setCounty(expiringPolicyAddressData.getCounty());
		renewalPolicyAddressData.setUnitOrBuilding(expiringPolicyAddressData.getUnitOrBuilding());
		return renewalPolicyAddressData;
	}

}
