package com.jpmorgan.cib.wlt.ctrac.service.impl;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_TASK_CLOSE_REASON;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CANCELLED;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import org.apache.commons.lang.WordUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.CommonTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CompleteItemData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;

@Service(value = "CommonTaskService")
public class CommonTaskServiceImpl implements CommonTaskService{
	private static final Logger logger = Logger.getLogger(TaskServiceImpl.class);

	@Autowired protected LookupCodeRepository lookupCodeRepository;
	
	@Autowired
	private CollateralManagementService collateralManagementSerivce;
	
	@Autowired
	private LoanManagementService loanManagementService;
	
	@Autowired
	private PerfectionTaskRepository perfectionTaskRepository;

    @Autowired
    private PerfectionTaskService perfectionTaskService;

	@Autowired
	private TMService tmService;
	
	@Override
	@Transactional
	public CompleteItemData prepareCompleteItem(TMParams tmParams) {
		validateTMParams(tmParams);	
		//1.create a new complete item dto
		CompleteItemData completeItemData = new CompleteItemData();
		completeItemData.setTmParams(tmParams);
		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmParams.getId_task());
		WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);
		//2. grab related loan/collateral information
		List<CollateralDto> collateralDtos = collateralManagementSerivce.getCollateralsByWorkItem(workItem);
		completeItemData.setCollateralDtoList(collateralDtos);
		completeItemData.setLoanDtoList(loanManagementService.getPrimaryLoans(collateralDtos));
		//3.get a list of dropdown options and set the dynamic heading
		List<LookUpCode> closeReasons = lookupCodeRepository.findByCodeSetAndActiveOrderBySortOrderAsc(FLOOD_TASK_CLOSE_REASON, "Y");
        String taskType = perfectionTask.getTmTaskType();
        completeItemData.setTaskType(taskType);
        completeItemData.setHelperTitle(WordUtils.capitalize(taskType.replace("_", " ").toLowerCase()) + " - ");
		completeItemData.setCloseReasons(closeReasons);
		return completeItemData;
	}

	@Override
	@Transactional
	public void processCompleteItem(CompleteItemData completeItemData) {	
	try {
		TMParams TMParams = completeItemData.getTmParams();
		String taskId = TMParams.getId_task();
		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(taskId);
        String closeReason = completeItemData.getCloseReason();
        String comments = completeItemData.getComments();
        perfectionTaskService.closeTask(perfectionTask, CANCELLED, closeReason, comments);
        tmService.completeTMTask(TMParams, completeItemData.getTMAttributes());
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0354", CtracErrorSeverity.APPLICATION, ex);
		}
	}


    public void validateTMParams(TMParams tmParams) {
		if(tmParams == null || tmParams.getId_task() == null){
			logger.error("Task UUID from TM is null");
			throw new CTracApplicationException("E0109", CtracErrorSeverity.CRITICAL);
		}
	}

}
