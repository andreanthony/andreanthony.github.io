package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.text.SimpleDateFormat;



public class InsurableAssetCoverageData<T extends BaseCoverageDataDTO> implements Serializable {

    private static final long serialVersionUID = 7390061225387462841L;

    public InsurableAssetCoverageData(Class<T> coverageDataClass) {
        this.coverageDataClass = coverageDataClass;
    }

    private Class<T> coverageDataClass;

    private T buildingCoverageData;

    private T contentsCoverageData;

    private T businessIncomeCoverageData;

    // Used for FIAT value
    private String propertyType= "";

    private String isDescoped= "No";

    private int sortOrder;//

    private boolean displayExcessRow = true;

    public boolean isDisplayExcessCoverage() {
    	if (isEmpty(getBuildingCoverageData().getExcessCoverageDetailsDto().getOrginalCoverageAmount()) &&
    			isEmpty(getContentsCoverageData().getExcessCoverageDetailsDto().getOrginalCoverageAmount()) &&
    			isEmpty(getBuildingCoverageData().getExcessCoverageDetailsDto().getVerifyCovAmountPriorMissMatch()) &&
    			isEmpty(getContentsCoverageData().getExcessCoverageDetailsDto().getVerifyCovAmountPriorMissMatch()) &&
    			// LCP - 4718 Issue while verifying a FIAT
    			isEmpty(getBuildingCoverageData().getExcessCoverageDetailsDto().getOrginalCoverageValue()) &&
    			isEmpty(getContentsCoverageData().getExcessCoverageDetailsDto().getOrginalCoverageValue()) &&
    			isEmpty(getBuildingCoverageData().getExcessCoverageDetailsDto().getVerifyCovValuePriorMissMatch()) &&
    			isEmpty(getContentsCoverageData().getExcessCoverageDetailsDto().getVerifyCovValuePriorMissMatch())

    			) {
    		displayExcessRow=false;
    	}

    	return(this.displayExcessRow);
    }

    private boolean isEmpty(String value) {
    	if (value == null || value.equals("") || value.equals("0.00")) {
    		return true;
    	} else {
    		return false;
    	}
    }

    public String getUpdatedDate() {
    	SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

        if (buildingCoverageData != null && !StringUtils.isEmpty(buildingCoverageData.getUpdatedDate())) {
            return  format.format(buildingCoverageData.getUpdatedDate());
        } else if (contentsCoverageData != null && !StringUtils.isEmpty(contentsCoverageData.getUpdatedDate())) {
            return format.format(contentsCoverageData.getUpdatedDate());
        } else if (businessIncomeCoverageData != null && !StringUtils.isEmpty(businessIncomeCoverageData.getUpdatedDate())) {
            return format.format(businessIncomeCoverageData.getUpdatedDate());
        }
        return "";
    }

    public String getInsertedDate() {
    	SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

        if (buildingCoverageData != null && !StringUtils.isEmpty(buildingCoverageData.getInsertedDate())) {
            return  format.format(buildingCoverageData.getInsertedDate());
        } else if (contentsCoverageData != null && !StringUtils.isEmpty(contentsCoverageData.getInsertedDate())) {
            return format.format(contentsCoverageData.getInsertedDate());
        } else if (businessIncomeCoverageData != null && !StringUtils.isEmpty(businessIncomeCoverageData.getInsertedDate())) {
            return format.format(businessIncomeCoverageData.getInsertedDate());
        }
        return "";
    }

    public void setBuildingName(String buildingName) {
        populateBuildingName(buildingCoverageData, buildingName);
        populateBuildingName(contentsCoverageData, buildingName);
        populateBuildingName(businessIncomeCoverageData, buildingName);
    }

    public void populateBuildingName(T coverageData, String buildingName) {
        if(!org.apache.commons.lang.StringUtils.isEmpty(buildingName) && coverageData != null && coverageData.getInsurableAssetDTO() != null) {
            coverageData.getInsurableAssetDTO().setBuildingName(buildingName);
        }
    }


    public String getBuildingName() {
        String buildingName = "";
        if (buildingCoverageData != null && !StringUtils.isEmpty(buildingCoverageData.getDescription())) {
            buildingName = buildingCoverageData.getDescription();
        }
        //For this Data Structure, if there is a building, then the description always must come from the building
        //Only Base Insurable asset with no building will have their own description
        else if (contentsCoverageData != null && !StringUtils.isEmpty(contentsCoverageData.getDescription())) {
            buildingName = contentsCoverageData.getDescription();
        } else if (businessIncomeCoverageData != null && !StringUtils.isEmpty(businessIncomeCoverageData.getDescription())) {
            buildingName = businessIncomeCoverageData.getDescription();
        }
        return buildingName;
    }

    public String getPropertyType() {
        if (buildingCoverageData != null && !StringUtils.isEmpty(buildingCoverageData.getPropertyType() )) {
            propertyType = buildingCoverageData.getPropertyType();
        } else if (contentsCoverageData != null && !StringUtils.isEmpty(contentsCoverageData.getPropertyType())) {
            propertyType = contentsCoverageData.getPropertyType();
        } else if (businessIncomeCoverageData != null && !StringUtils.isEmpty(businessIncomeCoverageData.getPropertyType())) {
            propertyType = businessIncomeCoverageData.getPropertyType();
        }
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        if (buildingCoverageData != null) {
            buildingCoverageData.setPropertyType(propertyType);
        }
        if(contentsCoverageData != null ) {
            contentsCoverageData.setPropertyType(propertyType);
        }
        if(businessIncomeCoverageData != null ) {
        	businessIncomeCoverageData.setPropertyType(propertyType);
        }
    }

    public T getBuildingCoverageData() {
        try {
            if (buildingCoverageData == null) {
                buildingCoverageData = coverageDataClass.newInstance();
                buildingCoverageData.setCoverageAmount(CtracAppConstants.DEFAULT_AMOUNT);
            }
        } catch (Exception e) {}
        return buildingCoverageData;
    }

    public void setBuildingCoverageData(T buildingProvidedCoverageData) {
        this.buildingCoverageData = buildingProvidedCoverageData;
    }

    public T getContentsCoverageData() {
        try {
            if (contentsCoverageData == null) {
                contentsCoverageData = coverageDataClass.newInstance();
                contentsCoverageData.setCoverageAmount(CtracAppConstants.DEFAULT_AMOUNT);
            }
        } catch (Exception e) {}
        return contentsCoverageData;
    }

    public void setContentsCoverageData(T contentsProvidedCoverageData) {
        this.contentsCoverageData = contentsProvidedCoverageData;
    }

    public T getBusinessIncomeCoverageData() {
        try {
            if (businessIncomeCoverageData == null) {
            	businessIncomeCoverageData = coverageDataClass.newInstance();
            	businessIncomeCoverageData.setCoverageAmount(CtracAppConstants.DEFAULT_AMOUNT);
            }
        } catch (Exception e) {}
        return businessIncomeCoverageData;
    }

    public void setBusinessIncomeCoverageData(T businessIncomeProvidedCoverageData) {
        this.businessIncomeCoverageData = businessIncomeProvidedCoverageData;
    }

    public int getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(int sortOrder) {
        this.sortOrder = sortOrder;
    }

    public boolean hasBuildingCoverage() {
        return buildingCoverageData != null && buildingCoverageData.hasNonZeroCoverage();
    }

    public boolean hasContentsCoverage() {
        return contentsCoverageData != null && contentsCoverageData.hasNonZeroCoverage();
    }

    public boolean hasBusinessIncomeCoverage() {
        return businessIncomeCoverageData != null && businessIncomeCoverageData.hasNonZeroCoverage();
    }

    public Boolean hasVerifyCovMissMatch(){

        if (buildingCoverageData != null && buildingCoverageData.getPrimaryCoverageDetailsDto() != null &&
        		(buildingCoverageData.getPrimaryCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        				buildingCoverageData.getPrimaryCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        				buildingCoverageData.getPrimaryCoverageDetailsDto().isVerificationBalanceTypeMissMatch() ||
        				buildingCoverageData.getPrimaryCoverageDetailsDto().isVerificationValueBalanceTypeMissMatch())) {
            return true;
        }
        if (buildingCoverageData != null && buildingCoverageData.getExcessCoverageDetailsDto() != null &&
        		(buildingCoverageData.getExcessCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        				buildingCoverageData.getExcessCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        				buildingCoverageData.getExcessCoverageDetailsDto().isVerificationBalanceTypeMissMatch() ||
        				buildingCoverageData.getExcessCoverageDetailsDto().isVerificationValueBalanceTypeMissMatch())) {
            return true;
        }

        if (contentsCoverageData != null && contentsCoverageData.getPrimaryCoverageDetailsDto() != null &&
        		(contentsCoverageData.getPrimaryCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        				contentsCoverageData.getPrimaryCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        				contentsCoverageData.getPrimaryCoverageDetailsDto().isVerificationBalanceTypeMissMatch()) ){
            return true;
        }
        if (contentsCoverageData != null && contentsCoverageData.getExcessCoverageDetailsDto() != null &&
        		(contentsCoverageData.getExcessCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        				contentsCoverageData.getExcessCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        				contentsCoverageData.getExcessCoverageDetailsDto().isVerificationBalanceTypeMissMatch())){
            return true;
        }


        if (businessIncomeCoverageData != null && businessIncomeCoverageData.getPrimaryCoverageDetailsDto() != null &&
		(businessIncomeCoverageData.getPrimaryCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
				businessIncomeCoverageData.getPrimaryCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
				businessIncomeCoverageData.getPrimaryCoverageDetailsDto().isVerificationBalanceTypeMissMatch()) ){
        	return true;
        }
        if (businessIncomeCoverageData != null && businessIncomeCoverageData.getExcessCoverageDetailsDto() != null &&
        		(businessIncomeCoverageData.getExcessCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        				businessIncomeCoverageData.getExcessCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        				businessIncomeCoverageData.getExcessCoverageDetailsDto().isVerificationBalanceTypeMissMatch())){
        	return true;
        }

        return false;
    }


    public Boolean canDelete (){

        if(buildingCoverageData!=null && buildingCoverageData.getHadSomeCoverage()){
            return false;
        }
        if(contentsCoverageData!=null && contentsCoverageData.getHadSomeCoverage()){
            return false;
        }
        if(businessIncomeCoverageData!=null && businessIncomeCoverageData.getHadSomeCoverage()){
            return false;
        }
        return true;
    }

	public String getIsDescoped() {
		checkDescoped(buildingCoverageData);
		checkDescoped(contentsCoverageData);
		checkDescoped(businessIncomeCoverageData);
		return isDescoped;
	}

	public void setIsDescoped(String isDescoped) {
		updateDescoped(buildingCoverageData, isDescoped);
		updateDescoped(contentsCoverageData, isDescoped);
		updateDescoped(businessIncomeCoverageData, isDescoped);
	}

	private void updateDescoped(T coverageData, String isDescoped) {
		if (coverageData != null && coverageData instanceof RequiredCoverageDTO) {
			((RequiredCoverageDTO) coverageData).setIsDescoped(isDescoped);
		}
	}

	private void checkDescoped(T coverageData) {
		if (coverageData != null && coverageData instanceof RequiredCoverageDTO) {
			if (!StringUtils.isEmpty(((RequiredCoverageDTO) coverageData).getIsDescoped())) {
				isDescoped = ((RequiredCoverageDTO) coverageData).getIsDescoped();
			}
		}
	}

}
