package com.jpmorgan.cib.wlt.ctrac.service;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;

public interface CancelWorkflowService {

	void cancelRequestingCoverageWorkflow(Long collateralRid, Long long1);
	
	void cancelRenewalOrReplacementWorkflow(Long proofOfCoverageRid);

	boolean hasPendingBorrowerCancelWorkflow(PerfectionTask requestCoverageTask);
}
