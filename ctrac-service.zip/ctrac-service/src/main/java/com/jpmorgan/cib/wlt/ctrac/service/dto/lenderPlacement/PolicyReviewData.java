package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import com.jpmorgan.cib.wlt.ctrac.service.dto.view.DeterminationDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.PrimaryLoanBorrowerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProofOfCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProvidedCoverageDetailsViewDto;

public class PolicyReviewData extends LenderPlaceData {

    private static final long serialVersionUID = -4643808195291814240L;
     
	private PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto;
    
    private ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto; 
    
    private ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto;
    
    private DeterminationDetailsViewDto determinationDetailsViewDto;
    
    private String vendorDocsImaged;
    
    private String policyInfoVerified;
    
    private String policyInImageSystem;
    
    private String wireSentDate;
    
    private String currentDate;
    
    private String lpCoverageType;
    
    public PrimaryLoanBorrowerViewDto getPrimaryLoanBorrowerViewDto() {
		return primaryLoanBorrowerViewDto;
	}
	public void setPrimaryLoanBorrowerViewDto(PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto) {
		this.primaryLoanBorrowerViewDto = primaryLoanBorrowerViewDto;
	}
    
	public ProofOfCoverageDetailsViewDto getProofOfCoverageDetailsViewDto() {
		return proofOfCoverageDetailsViewDto;
	}
	public void setProofOfCoverageDetailsViewDto(
			ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto) {
		this.proofOfCoverageDetailsViewDto = proofOfCoverageDetailsViewDto;
	}
	
	public ProvidedCoverageDetailsViewDto getProvidedCoverageDetailsViewDto() {
		return providedCoverageDetailsViewDto;
	}
	public void setProvidedCoverageDetailsViewDto(
			ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto) {
		this.providedCoverageDetailsViewDto = providedCoverageDetailsViewDto;
	}
	public String getVendorDocsImaged() {
		return vendorDocsImaged;
	}
	public void setVendorDocsImaged(String vendorDocsImaged) {
		this.vendorDocsImaged = vendorDocsImaged;
	}
	public String getPolicyInfoVerified() {
		return policyInfoVerified;
	}
	public void setPolicyInfoVerified(String policyInfoVerified) {
		this.policyInfoVerified = policyInfoVerified;
	}
	public String getPolicyInImageSystem() {
		return policyInImageSystem;
	}
	public void setPolicyInImageSystem(String policyInImageSystem) {
		this.policyInImageSystem = policyInImageSystem;
	}
	public String getWireSentDate() {
		return wireSentDate;
	}
	public void setWireSentDate(String wireSentDate) {
		this.wireSentDate = wireSentDate;
	}
	public String getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}
	public String getLpCoverageType() {
		return lpCoverageType;
	}
	public void setLpCoverageType(String lpCoverageType) {
		this.lpCoverageType = lpCoverageType;
	}
	public DeterminationDetailsViewDto getDeterminationDetailsViewDto() {
		return determinationDetailsViewDto;
	}
	public void setDeterminationDetailsViewDto(
			DeterminationDetailsViewDto determinationDetailsViewDto) {
		this.determinationDetailsViewDto = determinationDetailsViewDto;
	}
    
    

}
