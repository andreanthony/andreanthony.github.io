package com.jpmorgan.cib.wlt.ctrac.service.excel;

import org.apache.poi.ss.usermodel.Cell;

public enum FieldType {
	
	BLANK(Cell.CELL_TYPE_BLANK),
    BOOLEAN(Cell.CELL_TYPE_BOOLEAN),
    ERROR(Cell.CELL_TYPE_ERROR),
    FORMULA(Cell.CELL_TYPE_FORMULA),
    NUMERIC(Cell.CELL_TYPE_NUMERIC),
    STRING(Cell.CELL_TYPE_STRING),
    AMOUNT(Cell.CELL_TYPE_NUMERIC),
    DATE(Cell.CELL_TYPE_STRING),
    HEADER(Cell.CELL_TYPE_STRING),
    GRAYABLE(Cell.CELL_TYPE_STRING),
    LOCK(Cell.CELL_TYPE_STRING),
    AUTOWRAP(Cell.CELL_TYPE_STRING);
	
	private int apachePoiCellType;
	
	private FieldType(int apachePoiCellType) {
		this.apachePoiCellType = apachePoiCellType;
	}

	public int getApachePoiCellType() {
		return apachePoiCellType;
	}
	
}
