package com.jpmorgan.cib.wlt.ctrac.service.helper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;



@Component
public class LookupCodeUtil {
	@Autowired private LookupCodeRepository lookupCodeRepository;
	
	public List<LookUpCode> getLookupCodes(String codeSet){
		return lookupCodeRepository.findByCodeSet(codeSet);
	}
	
}
