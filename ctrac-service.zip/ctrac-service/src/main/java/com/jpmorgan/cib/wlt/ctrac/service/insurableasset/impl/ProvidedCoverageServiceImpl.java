package com.jpmorgan.cib.wlt.ctrac.service.insurableasset.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CoverageDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.CoverageDetailService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.ProvidedCoverageService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProvidedCoverageServiceImpl implements ProvidedCoverageService {

    @Autowired
    private CtracObjectMapper ctracObjectMapper;
    @Autowired
    private InsurableAssetRepository insurableAssetRepository;
    @Autowired
    CoverageDetailsRepository coverageDetailsRepository;

    @Autowired
    CoverageDetailService coverageDetailService;

    @Autowired
    @Qualifier("insuranceMngtService")
    InsuranceMngtService insuranceMngtService;
    @Autowired
    ProvidedCoverageRepository providedCoverageRepository;
    @Autowired
    RequiredCoverageRepository requiredCoverageRepository;
    @Autowired
    ProofOfCoverageRepository proofOfCoverageRepository;

    private static final Logger logger = Logger.getLogger(ProvidedCoverageServiceImpl.class);

    // ============== Provided Coverages ==========================
    @Override
    @Transactional
    public ProvidedCoverageDTO saveProvidedCoverage(ProvidedCoverageDTO providedCoverageDTO) {
        logger.debug("saveProvidedCoverage::BEGIN");
        // -1 first save the properties of this object
        if (providedCoverageDTO.getCoverageDetailsDTO() != null) {
            coverageDetailService.saveCoverageDetails(providedCoverageDTO.getCoverageDetailsDTO());
        }
        // We must always have a proof of coverage to sotore a provided
        // coverage.
        if (providedCoverageDTO.getProofOfCoverageDto() == null) {
            logger.error(" The provided coverage,  proof of coverage ( Insurance policy) cannot be null ");
            throw new RuntimeException(" Invalid state exception: cannot save a provided coverage without proof of coverage ");
        }

        // instantiate a model object or fecth an existing one if possible
        ProvidedCoverage providedCoverageToUpdate = new ProvidedCoverage();
        if (providedCoverageDTO.getRid() != null) {
            providedCoverageToUpdate = providedCoverageRepository.findOne(providedCoverageDTO.getRid());
        }

        if (!providedCoverageDTO.hasChanged()) {
            return providedCoverageDTO;
        }

        // if we need to refresh/update dependent objects
        if (providedCoverageDTO.getCoverageDetailsDTO() != null) {
            CoverageDetails coverageDetails = coverageDetailsRepository.findOne(providedCoverageDTO.getCoverageDetailsDTO().getRid());
            providedCoverageToUpdate.setCoverageDetails(coverageDetails);
        }

        if (providedCoverageDTO.getProofOfCoverageDto() != null) {
            ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(providedCoverageDTO.getProofOfCoverageDto().getRid());
            providedCoverageToUpdate.setProofOfCoverage(proofOfCoverage);
        }

        // TODO Assume the insurable asset had not changed
        if (providedCoverageDTO.getInsurableAssetDTO() != null) {
            InsurableAsset insurableAsset = insurableAssetRepository.findOne(providedCoverageDTO.getInsurableAssetDTO().getRid());
            providedCoverageToUpdate.setInsurableAsset(insurableAsset);
        }

        ctracObjectMapper.map(providedCoverageDTO, providedCoverageToUpdate);
        ProvidedCoverage savedProvidedCoverage = providedCoverageRepository.saveAndFlush(providedCoverageToUpdate);
        providedCoverageDTO.setRid(savedProvidedCoverage.getRid());
        providedCoverageDTO.refreshAuditUpdate(savedProvidedCoverage);
        logger.debug("saveProvidedCoverage::END");
        return providedCoverageDTO;
    }

    @Override
    @Transactional
    public List<ProvidedCoverageDTO> saveProvidedCoverage(List<ProvidedCoverageDTO> providedCoverageDTOList) {
        for (ProvidedCoverageDTO providedCoverageDTO : providedCoverageDTOList) {
            saveProvidedCoverage(providedCoverageDTO);
        }
        return providedCoverageDTOList;
    }

    protected List<ProvidedCoverageDTO> buildAndPopulateProvidedCoverageDto(InsuranceType coverageType, InsurableAsset insurableAsset,
            InsurableAssetDTO insDTO) {

        logger.debug("buildAndPopulateProvidedCoverageDto::END");
        List<ProvidedCoverageDTO> result = new ArrayList<ProvidedCoverageDTO>();
        if (insurableAsset == null) {
            return insDTO != null ? insDTO.getProvidedCoverageDTOs() : null;
        }

        for (ProvidedCoverage providedCoverage : insurableAsset.getProvidedCoverages()) {
            if (coverageType == null || coverageType.name().equals(providedCoverage.getCoverageDetails().getCoverageType())) {
                providedCoverage = CtracBaseEntity.deproxy(providedCoverage, ProvidedCoverage.class);
                ProvidedCoverageDTO providedCovDto = ctracObjectMapper.map(providedCoverage, ProvidedCoverageDTO.class);
                ProofOfCoverageDTO pocDto = getProofOfcoverage(providedCoverage);
                providedCovDto.setProofOfCoverageDto(pocDto);
                providedCovDto.setInsurableAssetDTO(insDTO);
                result.add(providedCovDto);
            }
        }

        logger.debug("buildAndPopulateProvidedCoverageDto::END");
        // TODO enable this line and simplify the code in the loop above when we
        // know how to map nested fields with ORIKA
        return result;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private ProofOfCoverageDTO getProofOfcoverage(ProvidedCoverage providedCoverage) {
        ProofOfCoverage pof = providedCoverage.getProofOfCoverage();
        pof = CtracBaseEntity.deproxy(pof, ProofOfCoverage.class);
        Class destinationClass = CtracObjectMapper.entityClassMapping.get(pof.getClass());
        ProofOfCoverageDTO pocDto = (ProofOfCoverageDTO) ctracObjectMapper.map(pof, destinationClass);
        return pocDto;
    }
}
