package com.jpmorgan.cib.wlt.ctrac.service.dto.letters;

public class CoverLetterSectionDTO {
	
	private String templateCode;
	
    private Integer sectionOrder;
	   
    private String sectionName;

	public String getTemplateCode() {
		return templateCode;
	}

	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}

	public Integer getSectionOrder() {
		return sectionOrder;
	}

	public void setSectionOrder(Integer sectionOrder) {
		this.sectionOrder = sectionOrder;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
}
