package com.jpmorgan.cib.wlt.ctrac.service.insurance;

import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public interface BorrowerPolicyStatusService {

	void initialize(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void edit(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void verify(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
}
