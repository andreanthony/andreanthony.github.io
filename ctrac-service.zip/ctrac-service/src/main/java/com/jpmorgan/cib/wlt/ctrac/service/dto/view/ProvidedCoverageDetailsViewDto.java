package com.jpmorgan.cib.wlt.ctrac.service.dto.view;

import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPConstants;

public class ProvidedCoverageDetailsViewDto {
	
	private Long proofOfCoverageRid;
	
	private Long collateralRid;
	
	private Long insurableAssetRid;
	
	private String assetType;
	
	private String assetFloodZone;
	
	private Integer assetSortOrder;
	
	private String coverageCreatedBy;
	
	private Date coverageCreatedDate;
	
	private String coverageLastUpdateddBy;
	
	private Date coverageLastUpdatedDate;
	
	private String buildingName;

	private String coverageAmount;
	
	private Integer isCoverageVerified;
	
	private String coverageType;
	
	private String balanceType;
	
	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getInsurableAssetRid() {
		return insurableAssetRid;
	}

	public void setInsurableAssetRid(Long insurableAssetRid) {
		this.insurableAssetRid = insurableAssetRid;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getAssetFloodZone() {
		return assetFloodZone;
	}

	public void setAssetFloodZone(String assetFloodZone) {
		this.assetFloodZone = assetFloodZone;
	}

	public Integer getAssetSortOrder() {
		return assetSortOrder;
	}

	public void setAssetSortOrder(Integer assetSortOrder) {
		this.assetSortOrder = assetSortOrder;
	}

	public String getCoverageCreatedBy() {
		return coverageCreatedBy;
	}

	public void setCoverageCreatedBy(String coverageCreatedBy) {
		this.coverageCreatedBy = coverageCreatedBy;
	}

	public Date getCoverageCreatedDate() {
		return coverageCreatedDate;
	}

	public void setCoverageCreatedDate(Date coverageCreatedDate) {
		this.coverageCreatedDate = coverageCreatedDate;
	}

	public String getCoverageLastUpdateddBy() {
		return coverageLastUpdateddBy;
	}

	public void setCoverageLastUpdateddBy(String coverageLastUpdateddBy) {
		this.coverageLastUpdateddBy = coverageLastUpdateddBy;
	}

	public Date getCoverageLastUpdatedDate() {
		return coverageLastUpdatedDate;
	}

	public void setCoverageLastUpdatedDate(Date coverageLastUpdatedDate) {
		this.coverageLastUpdatedDate = coverageLastUpdatedDate;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(String coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public Integer getIsCoverageVerified() {
		return isCoverageVerified;
	}

	public void setIsCoverageVerified(Integer isCoverageVerified) {
		this.isCoverageVerified = isCoverageVerified;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getCoverageTypeDisplay() {
     	String coverageType = LPConstants.CONTENTS.getDisplayName();
         if (InsurableAssetType.STRUCTURE.name().equals(getAssetType())) {
            // return LPConstants.FLOOD_ZONE_IN_BUILDING.getDisplayName(); // LP_COVERAGE_TYPE_BUILDING;
         	coverageType = LPConstants.BUILDING.getDisplayName();
         }
         return coverageType;
	}

	public String getBalanceType() {
		return balanceType;
	}

	public void setBalanceType(String balanceType) {
		this.balanceType = balanceType;
	}
	
}
