package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.AWAITING_VENDOR_CANCELLATION_LETTER;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.VERIFY_SECOND_VENDOR_LETTER;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.VERIFY_VENDOR_CANCELLATION_LETTER;

import com.jpmorgan.cib.wlt.ctrac.service.dto.view.CollateralMainDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.CollateralOwnerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.PrimaryLoanBorrowerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProofOfCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProvidedCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;

public class VerifyLetterData extends LenderPlaceData {

    private static final long serialVersionUID = 7815851528155885870L;
    
    // Mapped from LenderPlaceItem
    private String lpSendDate;
    private String firstLetterDate;
    private String secondLetterDate;
    
    // Mapped from LenderPlaceCancellationItem
    private String cancellationLetterDate;
    private String cancellationEffectiveDate;
   // private boolean imageCancellationChk=false;
    private String confirmImgLetter;
    
    // Used for Thymeleaf logic
    private Boolean secondLetter;
    private Boolean cancellationLetter;
    private String firstLetterDatePlusOne;
    private String floodZone;
    private String mortgagorNames;
    private String lpCoverageType;
    private PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto;
    
    private CollateralMainDetailsViewDto collateralMainDetailsViewDto;

    private CollateralOwnerViewDto collateralOwnerViewDto;
    
    private ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto;
     
    private ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto;
    
    private RequiredCoverageViewDto requiredCoverageViewDto;
    
    public String getLpSendDate() {
        return lpSendDate;
    }
    
    public void setLpSendDate(String lpSendDate) {
        this.lpSendDate = lpSendDate;
    }

    public String getFirstLetterDate() {
        return firstLetterDate;
    }

    public void setFirstLetterDate(String firstLetterDate) {
        this.firstLetterDate = firstLetterDate;
    }

    public String getSecondLetterDate() {
        return secondLetterDate;
    }

    public void setSecondLetterDate(String secondLetterDate) {
        this.secondLetterDate = secondLetterDate;
    }

    public String getCancellationLetterDate() {
        return cancellationLetterDate;
    }

    public void setCancellationLetterDate(String cancellationLetterDate) {
        this.cancellationLetterDate = cancellationLetterDate;
    }
    
    public String getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}

	public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}

	public Boolean getSecondLetter() {
        secondLetter = VERIFY_SECOND_VENDOR_LETTER.getName().equals(getCurrentWorkFlowStep());
        return secondLetter;
    }
    
    public Boolean getCancellationLetter() {
        cancellationLetter = AWAITING_VENDOR_CANCELLATION_LETTER.getName().equals(getCurrentWorkFlowStep()) ||
                VERIFY_VENDOR_CANCELLATION_LETTER.getName().equals(getCurrentWorkFlowStep());
        return cancellationLetter;
    }

    public String getFirstLetterDatePlusOne() {
        return firstLetterDatePlusOne;
    }

    public void setFirstLetterDatePlusOne(String firstLetterDatePlusOne) {
        this.firstLetterDatePlusOne = firstLetterDatePlusOne;
    }

	public CollateralMainDetailsViewDto getCollateralMainDetailsViewDto() {
		return collateralMainDetailsViewDto;
	}

	public void setCollateralMainDetailsViewDto(
			CollateralMainDetailsViewDto collateralMainDetailsViewDto) {
		this.collateralMainDetailsViewDto = collateralMainDetailsViewDto;
	}

	public CollateralOwnerViewDto getCollateralOwnerViewDto() {
		return collateralOwnerViewDto;
	}

	public void setCollateralOwnerViewDto(
			CollateralOwnerViewDto collateralOwnerViewDto) {
		this.collateralOwnerViewDto = collateralOwnerViewDto;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getMortgagorNames() {
		return mortgagorNames;
	}

	public void setMortgagorNames(String mortgagorNames) {
		this.mortgagorNames = mortgagorNames;
	}

	public ProvidedCoverageDetailsViewDto getProvidedCoverageDetailsViewDto() {
		return providedCoverageDetailsViewDto;
	}

	public void setProvidedCoverageDetailsViewDto(ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto) {
		this.providedCoverageDetailsViewDto = providedCoverageDetailsViewDto;
	}

	public PrimaryLoanBorrowerViewDto getPrimaryLoanBorrowerViewDto() {
		return primaryLoanBorrowerViewDto;
	}

	public String getLpCoverageType() {
		return lpCoverageType;
	}

	public void setLpCoverageType(String lpCoverageType) {
		this.lpCoverageType = lpCoverageType;
	}

	public void setPrimaryLoanBorrowerViewDto(PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto) {
		this.primaryLoanBorrowerViewDto = primaryLoanBorrowerViewDto;
	}

	public String getConfirmImgLetter() {
		return confirmImgLetter;
	}

	public void setConfirmImgLetter(String confirmImgLetter) {
		this.confirmImgLetter = confirmImgLetter;
	}

	public ProofOfCoverageDetailsViewDto getProofOfCoverageDetailsViewDto() {
		return proofOfCoverageDetailsViewDto;
	}

	public void setProofOfCoverageDetailsViewDto(
			ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto) {
		this.proofOfCoverageDetailsViewDto = proofOfCoverageDetailsViewDto;
	}

	public RequiredCoverageViewDto getRequiredCoverageViewDto() {
		return requiredCoverageViewDto;
	}

	public void setRequiredCoverageViewDto(RequiredCoverageViewDto requiredCoverageViewDto) {
		this.requiredCoverageViewDto = requiredCoverageViewDto;
	}
	
}
