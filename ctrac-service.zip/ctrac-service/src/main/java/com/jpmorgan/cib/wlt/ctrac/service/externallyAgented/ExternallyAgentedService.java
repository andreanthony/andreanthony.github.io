package com.jpmorgan.cib.wlt.ctrac.service.externallyAgented;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.dto.email.EmailDataDto;

public interface ExternallyAgentedService {

    void createLeadBankEmailNoticeTask(Long collateralRid);

}
