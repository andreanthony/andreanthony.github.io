package com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements;

import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;

import java.io.Serializable;
import java.util.List;

/**
 * Created by V704662 on 8/21/2017.
 */
public class GetAvailableGroupsResponse extends BaseApiResponse implements Serializable{

    private static final long serialVersionUID = -6519566022532191743L;
    private List<GroupIdentifier> availableGroups;

    public GetAvailableGroupsResponse(List<GroupIdentifier> availableGroups){
        super();
        this.availableGroups = availableGroups;
        this.setSuccess(true);
    }

    public List<GroupIdentifier> getAvailableGroups() {
        return availableGroups;
    }

    public void setAvailableGroups(List<GroupIdentifier> availableGroups) {
        this.availableGroups = availableGroups;
    }
}
