package com.jpmorgan.cib.wlt.ctrac.service.aspect;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Aspect
@Component
public class AuditingAspect {

	@Autowired private AuditInformationService auditInformationService;

	@PersistenceContext(unitName="entityManagerFactory")
	private EntityManager entityManager;

	@Before("execution(* com.jpmorgan.cib.wlt.ctrac.dao.repository..*.save(..)) && args(com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity)")
	public void setAuditInfo(JoinPoint joinPoint) {
		CtracBaseEntity ctracBaseEntity = (CtracBaseEntity) joinPoint.getArgs()[0];
		auditInformationService.updateAuditInfo((CtracBaseEntity) ctracBaseEntity);
	}

	@Before("execution(* com.jpmorgan.cib.wlt.ctrac.dao.repository..*.save(..)) && args(java.util.List<?>)")
	public void setListAuditInfo(JoinPoint joinPoint) {
		List<?> ctracBaseEntities = (List<?>) joinPoint.getArgs()[0];
		for (Object ctracBaseEntity : ctracBaseEntities) {
			if (ctracBaseEntity instanceof CtracBaseEntity) {
				auditInformationService.updateAuditInfo((CtracBaseEntity) ctracBaseEntity);
			}
		}
	}

	@Before("execution(* com.jpmorgan.cib.wlt.ctrac.dao.repository..*.saveAndFlush(..)) && args(com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity)")
	public void setAuditInfoFlush(JoinPoint joinPoint) {
		setAuditInfo(joinPoint);
	}

	@AfterReturning(pointcut="execution(* com.jpmorgan.cib.wlt.ctrac.dao.repository..*.saveAndFlush(..)) && args(com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity)",returning="ctracBaseEntity")
	public void refresh(CtracBaseEntity ctracBaseEntity) {
		entityManager.refresh(ctracBaseEntity);
	}

	@AfterReturning(pointcut="execution(* com.jpmorgan.cib.wlt.ctrac.dao.repository..*.save(..)) && args(java.util.List<?>)",returning="ctracBaseEntities")
	public void refreshList(List<?> ctracBaseEntities) {
		for (Object ctracBaseEntity : ctracBaseEntities) {
			if (ctracBaseEntity instanceof CtracBaseEntity) {
				refresh((CtracBaseEntity)ctracBaseEntity);
			}
		}
	}
}
