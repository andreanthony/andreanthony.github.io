package com.jpmorgan.cib.wlt.ctrac.service.impl;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.COMPLETE;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.NEW_ITEM;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.VERIFY_RESEARCH;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityNotFoundException;

import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracBaseException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PreLenderPlaceDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PreLenderPlaceDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.impl.AbstractRemapServiceImpl;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BasicMultipartFile;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CompleteTaskData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapResearchDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.FloodDeterminationService;
import com.jpmorgan.cib.wlt.ctrac.service.validator.UserValidator;



@Service(value = "floodRemapService")
@Transactional(value="transactionManager")
public class FloodRemapServiceImpl extends AbstractRemapServiceImpl implements FloodRemapService {
	
	private static final Logger logger = Logger.getLogger(FloodRemapServiceImpl.class);
	
	@Autowired private PreLenderPlaceDetailsRepository preLenderPlaceDetailsRepository;
    @Autowired private CollateralRepository collateralRepository;
    @Autowired private FloodDeterminationService floodDeterminationService;
    @Autowired private UserValidator userValidator;
	@Autowired private Environment env;
	@Autowired private CollateralWorkflowService collateralWorkflowService;
	@Autowired private CollateralDetailsStatusService collateralDetailsStatusService;
	@Autowired private CollateralManagementService collateralManagementService;
	@Autowired private AuditInformationService auditInformationService;
    @Autowired private PerfectionTaskService perfectionTaskService;

	@Override
	public FloodRemapResearchDto populateResearchItemData(TMParams TMParams) {
		logger.debug("populateResearchItemData:: start");
		validateTMParams(TMParams);
		String tmTaskId = TMParams.getId_task();
		final PerfectionTask perfectionTask = getPerfectionTaskByUUID(tmTaskId);
		FloodRemapItem floodRemapItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), FloodRemapItem.class);
		if (VERIFY_RESEARCH.getName().equals(perfectionTask.getWorkflowStep()) && 
				!userValidator.currentUserCanVerify(floodRemapItem)) {
			throw new CTracBaseException("E0251", CtracErrorSeverity.TRIVIAL);
		}
		if (StringUtils.isEmpty(floodRemapItem.getRemapCategory())) {
			floodRemapItem.setRemapCategory(getRemapFloodZoneStatus(floodRemapItem.getFloodRemap()));
		}
		
		FloodRemapResearchDto remapData = null;
		try {
			remapData = ctracObjectMapper.map(floodRemapItem, FloodRemapResearchDto.class);
		} catch (EntityNotFoundException e) {
			logger.debug("cannot find entity: " + e.getMessage());
			floodRemapItem.setCollateral(null);
			remapData = ctracObjectMapper.map(floodRemapItem, FloodRemapResearchDto.class);
		}
		
		remapData.setCurrentWorkflowStep(perfectionTask.getWorkflowStep());
		remapData.setScreenTitle(VERIFY_RESEARCH.getName().equals(perfectionTask.getWorkflowStep()) ?
				"Flood Remap - Verify Research" : "Flood Remap - Research");
		remapData.setTmParams(TMParams);
		remapData.setCollateralErrorMessage(NEW_ITEM.getName().equals(perfectionTask.getWorkflowStep()) ?
				"Submit the collateral record for verification in order to complete your research." : 
				"Complete verification for the collateral record in order to verify the research.");
		CompleteTaskData completeTaskData = remapData.getCompleteTaskData();
		completeTaskData.setCloseReasons(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc("RESEARCH_COMPLETE_REASON"));
		completeTaskData.setTmParams(TMParams);
		remapData.setStateCodes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(CtracAppConstants.STATES_CODES));
		remapData.setRemapTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(CtracAppConstants.CODE_SET_REMAP));
		remapData.setCcEmailAddress(env.getProperty("from.email.address.flood.service"));
		populateSFHDF(floodRemapItem, remapData);
		logger.debug("populateResearchItemData:: end");
		return remapData;
	}
	
	@Override
	public boolean isValidForLinking(FloodRemapResearchDto floodRemapResearchDto, Long collateralId) {
		String currentWorkflowStep = floodRemapResearchDto.getCurrentWorkFlowStep();
		if (NEW_ITEM.getName().equals(currentWorkflowStep)) {
			return collateralManagementService.getCollateralStatus(collateralId) == CollateralStatus.PLEDGED ||
					collateralDetailsStatusService.isValidForLinking(collateralId, NEW_ITEM);
		} else if (VERIFY_RESEARCH.getName().equals(currentWorkflowStep)) {
			return collateralManagementService.getCollateralStatus(collateralId) == CollateralStatus.PLEDGED &&
					collateralDetailsStatusService.isValidForLinking(collateralId, VERIFY_RESEARCH);
		}
		return false;
	}
	
	@Override
	public void processResearchResponse(final FloodRemapResearchDto floodRemapResearchData) {
		try {
		logger.debug("processResearchResponse:: start");
		final PerfectionTask perfectionTask = getPerfectionTaskByUUID(floodRemapResearchData.getTmParams().getId_task());
		String curWkflStep = perfectionTask.getWorkflowStep();
		final FloodRemapItem floodRemapItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), FloodRemapItem.class);
		if (floodRemapResearchData.getClientFound() == null || floodRemapResearchData.getClientFound() == 'N') {
			floodRemapResearchData.setPropertyPledge(null);
		}
		if (floodRemapResearchData.getPropertyPledge() == null || floodRemapResearchData.getPropertyPledge() == 'N') {
			floodRemapResearchData.setExposure(null);
		}
		ctracObjectMapper.map(floodRemapResearchData , floodRemapItem);
		PreLenderPlaceDetails preLenderPlaceDetails = floodRemapItem.getPreLenderPlaceDetails();
		if (floodRemapResearchData.getClientFound() == null ||
				StringUtils.isNotEmpty(floodRemapResearchData.getCompleteTaskData().getCloseReasonCode())) {
			if (preLenderPlaceDetails !=null) {
				// remove flood remap pre lp to DB
				floodRemapItem.setPreLenderPlaceDetails(null);
			}
		} else if (preLenderPlaceDetails != null) {
			// Save flood remap pre lp to DB
			preLenderPlaceDetailsRepository.save(floodRemapItem.getPreLenderPlaceDetails());	
		}
	
		if (!StringUtils.isBlank(floodRemapResearchData.getCollateralId())) {
			Collateral collateral = collateralRepository.findOne(Long.parseLong(floodRemapResearchData.getCollateralId()));
			floodRemapItem.setCollateral(collateral);
			floodRemapItem.getCollateralWorkItems().clear();
			floodRemapItem.addCollateral(collateral);
		}
		floodRemapRepository.save(floodRemapItem.getFloodRemap());			
		floodRemapItemRepository.save(floodRemapItem);
		
		if (VERIFY_RESEARCH.getName().equals(curWkflStep) &&
				(isZoneOutPropertyPledged(floodRemapItem) || isZoneInWithExposure(floodRemapItem))) {
			floodDeterminationService.createFloodDetermination(floodRemapItem);
		}

		//2.1 this include updating otm, updating the worflow step and task status in ctrac, updating the sla if needed
		if (VERIFY_RESEARCH.getName().equals(curWkflStep) &&
				floodRemapItem.getCompleteReason() != null && !StringUtils.isEmpty(floodRemapItem.getCompleteReason())) {
            perfectionTaskService.closeTask(perfectionTask, COMPLETE);
			tmService.completeTMTask(floodRemapResearchData, perfectionTask);
		} else {
			
			String updatedBy = auditInformationService.getLoggedInUserSid();
			if(!perfectionTask.getUpdatedBy().equals(updatedBy)){
				perfectionTask.setUpdatedBy(updatedBy);
			}
			Map<StateParameterType, Object> worflowData = new HashMap<StateParameterType, Object>(){{ 
				put(StateParameterType.HELPER_DATA, floodRemapResearchData);
				put(StateParameterType.WORK_ITEM, floodRemapItem);
				put(StateParameterType.PERFECTION_TASK, perfectionTask);
				put(StateParameterType.TM_PARAMS, floodRemapResearchData.getTmParams());
			}};
			taskService.completeWorkFlowStepOperations(worflowData);
		}
		
        //TODO FIXME use the workflow engine to perform this computation
        if(VERIFY_RESEARCH.getName().equals(curWkflStep)) {
        	if(isZoneInWithExposure(floodRemapItem)){
	            TMTaskType tmType = TMTaskType.valueOf(perfectionTask.getTmTaskType());  
	            
	            collateralWorkflowService.initRequiredCoverageRequestWorkFlow(floodRemapItem,
	            		floodRemapItem.getCollateral().getRid(), PerfectionItemSubType.REMAP,
	            		tmType, dateCalculator.addCalendarDays(30, floodRemapItem.getInitiationDate(), false));
	            
	            /***
	            if (collateralManagementService.isCollateralBusinessAssetSBAOnly(floodRemapItem.getCollateral().getRid())  ) {
	            	collateralWorkflowService.initSBACoverageRequestWorkFlow(
		            		floodRemapItem.getCollateral().getRid(), PerfectionItemSubType.REMAP,
		            		otmType, dateCalculator.addCalendarDays(30, floodRemapItem.getInitiationDate(), false));	            	
	            } else {
	            	collateralWorkflowService.initFiatRequestWorkFlow(floodRemapItem,
	            		floodRemapItem.getCollateral().getRid(), PerfectionItemSubType.REMAP,
	            		otmType, dateCalculator.addCalendarDays(30, floodRemapItem.getInitiationDate(), false));
	            }
	            ***/
        	}
        	else if(isZoneOutPropertyPledged(floodRemapItem)) {
        		// call Coverage & LP computations to cancel LP for Zone IN to OUT
        		collateralWorkflowService.triggerInsuranceCoverageEvaluation(floodRemapItem.getRid(), collateralManagementService.getCollateralDto(floodRemapItem.getCollateral().getRid()));
        	}
        }
        //TODO call Coverage & LP computations
		
		logger.info("Research data saved successfully.");
		logger.debug("processResearchResponse:: end");
		} catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0354", CtracErrorSeverity.APPLICATION, ex);
		}
	}

	private boolean isZoneInWithExposure(final FloodRemapItem floodRemapItem) {
		PreLenderPlaceDetails preLpDetails = floodRemapItem.getPreLenderPlaceDetails();
		boolean exposureExists = preLpDetails != null &&
				preLpDetails.getClientFoundFlag() != null && preLpDetails.getClientFoundFlag() == 'Y' &&
				preLpDetails.getPropertyPledgedFlag() != null && preLpDetails.getPropertyPledgedFlag() == 'Y' &&
				preLpDetails.getExposureExistsFlag() != null && preLpDetails.getExposureExistsFlag() == 'Y';
		return "IN".equals(floodRemapItem.getRemapCategory()) && exposureExists;
	}

	private boolean isZoneOutPropertyPledged(final FloodRemapItem floodRemapItem) {
		PreLenderPlaceDetails preLpDetails = floodRemapItem.getPreLenderPlaceDetails();
		boolean isPropertyPledged = preLpDetails != null &&
				preLpDetails.getClientFoundFlag() != null && preLpDetails.getClientFoundFlag() == 'Y' &&
				preLpDetails.getPropertyPledgedFlag() != null && preLpDetails.getPropertyPledgedFlag() == 'Y';
		return "OUT".equals(floodRemapItem.getRemapCategory()) && isPropertyPledged;
	}
	
	private void populateSFHDF(FloodRemapItem floodRemapItem, FloodRemapDto floodRemapData) {
		if (floodRemapItem != null) {
		    CollateralDocument floodDetermination = floodRemapItem.getFloodDetermination();
			if (floodDetermination != null) {
				floodRemapData.setSFHDF(new BasicMultipartFile(floodDetermination.getFileContent().getFileContent(), floodDetermination.getFileName(), floodDetermination.getFileNameWithExt(), "application/pdf"));
			} else {
				logger.info("Flood determination is null.");
			}
		}
	}
		
}
