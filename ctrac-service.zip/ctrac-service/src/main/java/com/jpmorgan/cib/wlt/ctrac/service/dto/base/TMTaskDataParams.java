package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;



public class TMTaskDataParams implements Serializable, Cloneable {
	
	private static final long serialVersionUID = 1L;

	private TMTaskType tmTaskType;
	
	private WorkItem workItem;
	
	private WorkflowStateDefinition workflowStateDefinition;
	
	private Long collateralRid;

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public TMTaskDataParams(TMTaskType tmTaskType, WorkItem workItem,
			WorkflowStateDefinition workflowStateDefinition,Long collateralRid) {
		super();
		this.tmTaskType = tmTaskType;
		this.workItem = workItem;
		this.workflowStateDefinition = workflowStateDefinition;
		this.collateralRid = collateralRid;
	}

	public TMTaskType getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(TMTaskType tmTaskType) {
		this.tmTaskType = tmTaskType;
	}

	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public WorkflowStateDefinition getFloodRemapItemState() {
		return workflowStateDefinition;
	}

	public void setFloodRemapItemState(WorkflowStateDefinition workflowStateDefinition) {
		this.workflowStateDefinition = workflowStateDefinition;
	}	
}
