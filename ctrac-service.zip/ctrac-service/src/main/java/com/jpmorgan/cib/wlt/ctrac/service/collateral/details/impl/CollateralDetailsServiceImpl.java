package com.jpmorgan.cib.wlt.ctrac.service.collateral.details.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CollateralOwner;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.SectionStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.FloodZoneRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailReqCoverageSectionHelper;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.ReviewCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ReferenceValues;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.EntitlementUtil;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.request.LPIProofOfCoveragePublishEventRequest;
import com.jpmorgan.cib.wlt.ctrac.service.event.store.client.CollateralEventSection;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ReadyForLenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.VendorPaymentMethodService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.WorkflowDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.validator.CollateralDetailsValidator;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus.DRAFT;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus.PENDING_VERIFICATION;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.*;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.VERIFY_RESEARCH;

@Service(value = "collateralDetailsService")
public class CollateralDetailsServiceImpl implements CollateralDetailsService {

	@Autowired private AuditInformationService auditInformationService;
    @Autowired private CalendarDayUtil calendarDayUtil;
    @Autowired private CollateralDetailsStatusService collateralDetailsStatusService;
    @Autowired private CollateralDetailsValidator collateralDetailsValidator;
    @Autowired private CollateralDetailReqCoverageSectionHelper collateralDetailReqCoverageSectionHelper;
    @Autowired private CollateralDocumentService collateralDocumentService;
    @Autowired private CollateralManagementService collateralManagementService;
    @Autowired private CollateralOwnerRepository collateralOwnerRepository;
    @Autowired private CollateralRepository collateralRepository;
    @Autowired private CollateralWorkflowService collateralWorkflowService;
    @Autowired private CtracObjectMapper ctracObjectMapper;
    @Autowired private CustomerRepository customerRepository;
    @Autowired private FloodRemapItemRepository floodRemapItemRepository;
    @Autowired private InsuranceMngtService insuranceMngtService;
    @Autowired private LenderPlaceItemRepository lenderPlaceItemRepository;
    @Autowired private LineOfBusinessService lobService;
    @Autowired private LoanManagementService loanManagementService;
    @Autowired private LoanService loanService;
    @Autowired private LookupCodeRepository lookupCodeRepository;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
    @Autowired private ReadyForLenderPlaceService readyForLenderPlaceService;
    @Autowired private ReviewCollateralService reviewCollateralService;
    @Autowired private SectionStatusRepository sectionStatusRepository;
	@Autowired private VendorPaymentMethodService vendorPaymentMethodService;
    @Autowired private WorkflowDetailsService workflowDetailsService;
    @Autowired private PublishEventService publishEventService;

    private static final Logger logger = Logger.getLogger(CollateralDetailsServiceImpl.class);

    @Override
    @Transactional(readOnly = true)
    public CollateralDetailsMainDto populateCollateralDetailsInformation(Long collateralRid) {
        logger.debug("populateCollateralDetailsInformation:BEGIN");
        CollateralDetailsMainDto collateralDetailsMainDto = new CollateralDetailsMainDto();
        refreshCollateralDto(collateralRid, collateralDetailsMainDto);
		CollateralDto collateralDto = collateralDetailsMainDto.getCollateralDto();
        collateralDetailsMainDto.setReviewCollateral(reviewCollateralService.hasActiveReviewCollateralTask(collateralRid));
        
        if (collateralDetailsMainDto.getCollateralDto().getCollateralStatus().getName().equals(CollateralStatus.DRAFT.getName())) {
        	boolean recordFoundVerifyFloodRemapItemBySameUser = hasVerifyFloodRemapItemBySameUser(collateralRid);
        	if (recordFoundVerifyFloodRemapItemBySameUser) {
        		collateralDetailsMainDto.setShowDeleteCollateral(false);
        	} else {
        		collateralDetailsMainDto.setShowDeleteCollateral(true);
        	}        	
        } else {
            collateralDetailsMainDto.setShowDeleteCollateral(false);
        }


        collateralDetailsMainDto.setReadOnlyUserRole(!EntitlementUtil.hasAuthority(EntitlementRoles.WRITER_ROLE)? true:false );
        
        collateralDetailsStatusService.loadAllCollateralSectionsStatus(collateralDto, collateralDetailsMainDto.getSectionStatusDtos());
        refreshCollateralSection(collateralDto, collateralDetailsMainDto.getCollateralSectionDto());
        refreshLoanBorrowerSection(collateralDto, collateralDetailsMainDto.getLoanBorrowerSectionData());
        refreshInsurancePoliciesSection(collateralRid, collateralDetailsMainDto.getInsuranceSectionData());
        refreshWorkflowDetailsSection(collateralRid, collateralDetailsMainDto.getWorkflowDetailsData());
        refreshRequiredCoverageSection(collateralRid, collateralDetailsMainDto.getRequiredCoverageSectionDto());
            // FIXME: use CoverageInputSource.FIAT?
        refreshFloodDeterminationSection(collateralDto, collateralDetailsMainDto.getFloodDeterminationSectionDto());
        logger.debug("populateCollateralDetailsInformation:END");
        return collateralDetailsMainDto;
    }

	private boolean hasVerifyFloodRemapItemBySameUser(Long collateralRid) {		
        logger.debug("hasVerifyFloodRemapItemBySameUser::START");
		boolean recordFound = false;
        
        String loggedInUserSid = auditInformationService.getLoggedInUserSid();
        
        // there can be multiple Flood Remap pointing to same Collateral
        List<FloodRemapItem> floodRemapItems = floodRemapItemRepository.getFloodRemapItems(collateralRid);
        
        for (FloodRemapItem floodRemapItem : floodRemapItems) {
        	List<PerfectionTask> perfectionTasks = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(floodRemapItem, VERIFY_RESEARCH.getName(), TaskStatus.OPEN.name());
        	
        	for (PerfectionTask perfectionTask: perfectionTasks) {
        		if (perfectionTask.getUpdatedBy().equals(loggedInUserSid)) {
        			recordFound = true;
        			break;
        		}
        	}
        }

        logger.debug("hasVerifyFloodRemapItemBySameUser::END");

        return recordFound;
	}

	
	private void refreshRequiredCoverageSection(Long collateralRid, RequiredCoverageSectionDto requiredCoverageSectionDto) {
		collateralDetailReqCoverageSectionHelper.prepareRequiredCoverageSection(
        		collateralRid, requiredCoverageSectionDto);
        setShowVerify(requiredCoverageSectionDto.getSectionStatusDto());
	}
    
    @Override
	public ReferenceValues getCollateralScreenReferenceValues() {
    	ReferenceValues referenceValues = new ReferenceValues();
    	referenceValues.setInsuranceTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc("INSURANCE_TYPES"));
    	referenceValues.setCoverageTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc("COVERAGE_TYPES"));
    	referenceValues.setLpInsuranceCompanies(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc("LP_INSURANCE_COMPANIES"));
    	referenceValues.setStates(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(STATES_CODES));
    	referenceValues.setCtracReferenceDate(DateConverter.convert(calendarDayUtil.getCurrentReferenceDate()));
    	referenceValues.setBorrowerPolicyTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc("POLICY_TYPES"));
    	referenceValues.setLpPolicyTypes(lookupCodeRepository.findByCodeSet(LP_POLICY_TYPES));
    	referenceValues.setInvoicePaymentMethodTypes(getInvoicePaymentMethods());
    	referenceValues.setRefundPaymentMethodTypes(getRefundPaymentMethods());
    	referenceValues.setLoanAccountingSystems(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(LOAN_ACCOUNTING_SYSTEM));
    	referenceValues.setLoanTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(LOAN_TYPES));
    	referenceValues.setLetterCycleWorkflowSteps(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(LETTER_CYCLE_WORKFLOW_STEPS));    	
     	referenceValues.setLenderPlaceReasons(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(LENDER_PLACE_REASONS));    	
    	referenceValues.setLinesOfBusiness(lobService.retrieveLinesOfBusiness());
    	referenceValues.setBlanketCoverageTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc("BLANKET_COVERAGE_TYPES"));
    	referenceValues.setCollateralTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(CODE_SET_COLLATERAL_TYPES));
    	referenceValues.setCollateralStatuses(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(CODE_SET_COLLATERAL_STATUSES));
		return referenceValues;
	}

	private void setShowVerify(SectionStatusDto sectionStatusDto) {
        String invalidSectionErrorMessage = "Invalid SectionStatusDto";
        if(sectionStatusDto == null){
            logger.error(invalidSectionErrorMessage);
            return;
        }
    	if (sectionStatusDto.getModifiedBy() == null ||
    			sectionStatusDto.getStatusId() == null) {
    		logger.error(invalidSectionErrorMessage);
    		sectionStatusDto.setShowVerify(false);
    	} else {
    		String loggedInUser = auditInformationService.getLoggedInUserSid();
    		sectionStatusDto.setShowVerify(!sectionStatusDto.getModifiedBy().equals(loggedInUser) &&
        			sectionStatusDto.getStatusId().equals(VerificationStatus.PENDING_VERIFICATION));
	    }    
    }
    
    @Override
    @Transactional
    public void saveCollateralSectionInfo(CollateralDetailsMainDto collateralDetailsMainDto, CollateralScreenAction action) {
        logger.debug("saveCollateralSectionInfo::BEGIN");
        CollateralDto collateralDto = collateralDetailsMainDto.getCollateralDto();
        boolean hasCollateralOwnerChanged = false;
        Set<Long> collateralToVerify = new HashSet<>();
		for (CustomerData oneCustomerData : collateralDto.getOwnerData()) {
			if (oneCustomerData.hasChanged()) {
                hasCollateralOwnerChanged = true;
				List<CollateralOwner> collateralOwners = collateralOwnerRepository.findByOwnerRid(oneCustomerData.getRid());
				for (CollateralOwner customer : collateralOwners) {
					collateralToVerify.add(customer.getCollateral().getRid());
				}
			}
		}
        collateralToVerify.remove(collateralDto.getRid());
       
        collateralManagementService.saveCollateral(collateralDto, null);
        if (hasCollateralOwnerChanged) {
            publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.EDITED, CollateralEventSection.COLLATERAL_OWNER);
        }
        if (CollateralScreenAction.VERIFY == action) {
        	// TODO: Uncomment and test the following line
        	//collateralDetailsValidator.validateCollateralDetailsCompleteVerification(collateralDetailsMainDto);
            collateralDocumentService.removeCollateralDocument(collateralDto.getRid(), CtracAppConstants.MORTGAGE_DOT_IDENTIFIER);
            publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.VERIFIED, CollateralEventSection.COLLATERAL_DETAILS);
        } else {
        	CollateralSectionDto collateralSectionDto = collateralDetailsMainDto.getCollateralSectionDto();
            collateralDocumentService.removeCollateralDoc(collateralSectionDto.getMortgageDocsToBeDeleted());
            collateralDocumentService.saveCollateralDocuments(collateralSectionDto.getNewFiles(), 
            		CtracAppConstants.MORTGAGE_DOT_IDENTIFIER, null, collateralDto.getRid());
            publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.EDITED, CollateralEventSection.COLLATERAL_DETAILS);
        }
       
        CollateralWorkflowParam result = collateralDetailsStatusService.advanceSection(
        		collateralDto, collateralDetailsMainDto.getTmParams(),
        		collateralDetailsMainDto.getCollateralSectionDto().getSectionStatusDto(), action);
    	collateralWorkflowService.triggerCollateralWorkflow(result);    	
    	
    	//For other collaterals related to this owner.
    	for (Long collateralRid : collateralToVerify) {
            CollateralDto otherCollateralDto = collateralManagementService.getCollateralDto(collateralRid);
            this.updateCollateralDetailsSection(otherCollateralDto, action,CollateralDetailsSection.COLLATERAL_BASIC_DETAILS);
            publishEventService.publishCollateralEvent(otherCollateralDto, CollateralEventType.EDITED, CollateralEventSection.COLLATERAL_OWNER);
       	}
    	  
        logger.debug("saveCollateralSectionInfo::END");
    }
    
    
    @Override
	@Transactional
	public void updateCollateralDetailsSection(CollateralDto collateralDto, CollateralScreenAction action, CollateralDetailsSection sectionName) {
		Long collateralRid = collateralDto.getRid();
		SectionStatus sectionStatus = sectionStatusRepository.findByCollateralRidAndSectionId(
				collateralRid, sectionName.name());
		SectionStatusDto sectionStatusDto = ctracObjectMapper.map(sectionStatus, SectionStatusDto.class);
		if (action == CollateralScreenAction.EDIT) {
			if (sectionStatusDto.getStatusId() != DRAFT) {
				sectionStatusDto.setStatusId(PENDING_VERIFICATION);
			}
			sectionStatusDto.setModifiedBy(auditInformationService.getLoggedInUserSid());
		} 
		CollateralWorkflowParam param = collateralDetailsStatusService.advanceSection(collateralDto, null, sectionStatusDto, action);
		collateralWorkflowService.triggerCollateralWorkflow(param);
	}

    @Override
    public CollateralDto removeCollateralOwner(CollateralDto collateralDto, int index) {
        logger.debug("deleteCollateralOwner::BEGIN " + index);
        if (index < collateralDto.getOwnerData().size()) {
            CustomerData customer = collateralDto.getOwnerData().get(index);
            collateralDto.addOwnerDataToBeDeleted(customer);
            collateralDto.getOwnerData().remove(index);
        }
        logger.debug("deleteCollateralOwner::END " + index);
        return collateralDto;
    }

    @Override
    @Transactional
    public CollateralDto removeCollateralOwner(CollateralDetailsMainDto collateralDetailsMainDto, CustomerData customerData) {
        logger.debug("removeCollateralOwner::BEGIN");
        CollateralDto collateralDto =  collateralDetailsMainDto.getCollateralDto();
        collateralDto.addOwnerDataToBeDeleted(customerData);
        collateralDto.getOwnerData().remove(customerData);
        collateralManagementService.delinkWithLoan(collateralDto);
        collateralManagementService.removeCollateralOwner(collateralDto);
        CollateralWorkflowParam result = collateralDetailsStatusService.advanceSection(
                collateralDto, collateralDetailsMainDto.getTmParams(),
                collateralDetailsMainDto.getCollateralSectionDto().getSectionStatusDto(), CollateralScreenAction.EDIT);
        collateralWorkflowService.triggerCollateralWorkflow(result);
        logger.debug("removeCollateralOwner::END");
        return collateralDto;
    }

    @Override
    public CollateralDto addCollateralOwner(CollateralDto collateralDto) {
        logger.debug("addCollateralOwner::BEGIN");
        CustomerData customerData = new CustomerData();
        collateralDto.getOwnerData().add(customerData);
        logger.debug("addCollateralOwner::END");
        return collateralDto;
    }
    
    @Override
    @Transactional
    public CollateralDetailsMainDto addExistingCollateralOwner(CollateralDetailsMainDto collateralDetailsMainDto, Long ownerRid) {
        logger.debug("addCollateralOwner::BEGIN");
        
        if (ownerRid == null) {
            return collateralDetailsMainDto;
        }
        Customer customer  = customerRepository.findOne(ownerRid);
        CustomerData customerData  = ctracObjectMapper.map(customer, CustomerData.class);
        collateralDetailsMainDto.getCollateralDto().getOwnerData().add(customerData);
        Collateral collateral  =  CtracBaseEntity.deproxy(collateralRepository.findOne(collateralDetailsMainDto.getCollateralDto().getRid()), Collateral.class);
        collateral.addOwner(customer);
        collateralRepository.save(collateral);
        publishEventService.publishCollateralEvent(
                collateralDetailsMainDto.getCollateralDto(), CollateralEventType.ADDED, CollateralEventSection.COLLATERAL_OWNER);
        CollateralWorkflowParam result = collateralDetailsStatusService.advanceSection(
        		collateralDetailsMainDto.getCollateralDto(), collateralDetailsMainDto.getTmParams(),
        		collateralDetailsMainDto.getCollateralSectionDto().getSectionStatusDto(), CollateralScreenAction.EDIT);
    	collateralWorkflowService.triggerCollateralWorkflow(result);    	
        logger.debug("addCollateralOwner::END");
        
        
        return collateralDetailsMainDto;
    }
    
    

    @Override
    public CollateralSectionDto removeMortgagorDoc(CollateralSectionDto collateralSectionDto, int index) {
        logger.debug("removeMortgagorDoc::BEGIN");
        CollateralDoc collateralDoc = collateralSectionDto.getMortgageDocs().get(index);
        collateralSectionDto.getMortgageDocs().remove(collateralDoc);
        collateralSectionDto.getMortgageDocsToBeDeleted().add(collateralDoc);
        logger.debug("removeMortgagorDoc::END");
        return collateralSectionDto;
    }

    private void refreshFloodDeterminationSection(CollateralDto collateralDto, FloodDeterminationSectionDto floodDeterminationSectionDto) {
        floodDeterminationSectionDto.setVendors(lookupCodeRepository.findByCodeSet(SOURCE_SYSTEM_NAME));
        Collection<FloodDeterminationDto> allFloodDeterminations = collateralDto.getFloodDeterminations();
        Collection<FloodDeterminationDto> inactiveFloodDeterminations = new ArrayList<FloodDeterminationDto>();
        for (FloodDeterminationDto floodDetermination : allFloodDeterminations) {
            if (CoverageRequirementStatus.PENDING_VERIFICATION.name().equals(floodDetermination.getStatus())) {
                floodDeterminationSectionDto.setPendingVerificationFloodDetermination(floodDetermination);
                floodDeterminationSectionDto.setHasFloodZone(FloodZoneRuleWorker.isHighRiskFloodZone(floodDetermination.getFloodZone()));
            } else if (CoverageRequirementStatus.VERIFIED.name().equals(floodDetermination.getStatus())) {
                floodDeterminationSectionDto.setActiveFloodDetermination(floodDetermination);
                floodDeterminationSectionDto.setHasFloodZone(FloodZoneRuleWorker.isHighRiskFloodZone(floodDetermination.getFloodZone()));

            } else if (CoverageRequirementStatus.INACTIVE.name().equals(floodDetermination.getStatus())) {
                inactiveFloodDeterminations.add(floodDetermination);
            }
        }
        floodDeterminationSectionDto.setInactiveFloodDetermination(inactiveFloodDeterminations);
        setShowVerify(floodDeterminationSectionDto.getSectionStatusDto());
    }

    private List<LookUpCodeData> getRefundPaymentMethods() {
		List<LookUpCodeData> refundMethods = new ArrayList<LookUpCodeData>();
		List<LookUpCode> invoicePaymentMethods = lookupCodeRepository
				.findByCodeSetOrderBySortOrderAsc(CtracAppConstants.FLOOD_REMAP_ASSURANT_PAYMENT_LIST);

		for (LookUpCode refundMethod : invoicePaymentMethods) {
			refundMethods.add(ctracObjectMapper.map(refundMethod, LookUpCodeData.class));
		}

		return refundMethods;

	}

	private List<LookUpCodeData> getInvoicePaymentMethods() {
		List<LookUpCode> invoicePaymentMethods = lookupCodeRepository
				.findByCodeSetOrderBySortOrderAsc(CtracAppConstants.FLOOD_REMAP_ASSURANT_PAYMENT_LIST);
		List<LookUpCodeData> refundMethods = new ArrayList<LookUpCodeData>();
		for (LookUpCode paymentMethod : invoicePaymentMethods) {
			if (PaymentType.CASHIERS_CHECK.getCode().equals(paymentMethod.getCode())) {
				continue;
			}
			else {
				refundMethods.add(ctracObjectMapper.map(paymentMethod, LookUpCodeData.class));
			}
		}
		return refundMethods;
	}

    @Override
    @Transactional
	public void refreshInsurancePoliciesSection(Long collateralRid, InsurancePoliciesSectionDto insurancePoliciesData) {
		insurancePoliciesData.setActivePolicies(insuranceMngtService.findActiveByCollateral(collateralRid));
        insurancePoliciesData.setInactivePolicies(insuranceMngtService.findInactiveByCollateral(collateralRid));
        setShowVerify(insurancePoliciesData.getSectionStatusDto());
	}
    @Override
    @Transactional
	public void refreshWorkflowDetailsSection(Long collateralRid, WorkflowDetailsSectionDto workflowDetailsSectionDto) {
        workflowDetailsSectionDto.setWorkflowDetails(workflowDetailsService.findByCollateralId(collateralRid));
        setShowVerify(workflowDetailsSectionDto.getSectionStatusDto());
	}
    
    @Override
    public FloodDeterminationDto prepareFloodDeterminationOverlayData(CollateralDto collateralDto,
            FloodDeterminationSectionDto floodDeterminationSectionDto, String action, Long floodDeterminationId) {

        logger.debug("prepareFloodDeterminationOverlayData::BEGIN");        
        
        FloodDeterminationDto insurancePolicyRequirementDto = floodDeterminationSectionDto.getPendingVerificationFloodDetermination();
        // 1) does the overlay need to display for edit purpose <=> a new requirement or the one in draft
        if ("new".equals(action) || "edit".equals(action) || "verify".equals(action)) {
			if (insurancePolicyRequirementDto == null || "new".equals(action)) {
				insurancePolicyRequirementDto = createNewFloodDeterminationPendingVerification(collateralDto, floodDeterminationSectionDto);
			}
			insurancePolicyRequirementDto.setVerifyMode(false);
			if ("verify".equals(action)) {
				insurancePolicyRequirementDto.setVerifyMode(true);
			}
			return insurancePolicyRequirementDto;
		}

        // 2) Are we trying to display the verifiedFiat?
        Long verifiedFloodDeterminationId = floodDeterminationSectionDto.getActiveFloodDetermination().getFloodDeterminationId();
        if (verifiedFloodDeterminationId != null && verifiedFloodDeterminationId.equals(floodDeterminationId)) {
            return floodDeterminationSectionDto.getActiveFloodDetermination();
        }

        // 3) Here, we should be trying to display and inactive fiat details
        for (FloodDeterminationDto inactiveFloodDetermination : floodDeterminationSectionDto.getInactiveFloodDetermination()) {
            Long inactiveFloodDeterminationId = inactiveFloodDetermination.getFloodDeterminationId();
            if (inactiveFloodDeterminationId != null && inactiveFloodDeterminationId.equals(floodDeterminationId)) {
                return inactiveFloodDetermination;
            }
        }
        // /Throw Invalid floodDeterminationId exception here ...
        logger.debug("prepareFloodDeterminationOverlayData::END");
		return insurancePolicyRequirementDto;
    }

    private FloodDeterminationDto createNewFloodDeterminationPendingVerification(final CollateralDto collateralDto,
            final FloodDeterminationSectionDto requiredCoverageSectionDto) {
        FloodDeterminationDto floodDeterminationDto = new FloodDeterminationDto();
        floodDeterminationDto.setCollateralRid(collateralDto.getRid());
        requiredCoverageSectionDto.setPendingVerificationFloodDetermination(floodDeterminationDto);
        return floodDeterminationDto;
    }
    
   

    @Override
    public LoanBorrowerSectionDto changePrimaryLoan(LoanBorrowerSectionDto loanBorrowerSectionDto, Long loanRid) {
        Collection<LoanData> activeLoansData = loanBorrowerSectionDto.getActiveLoansData();
        if (activeLoansData != null && !activeLoansData.isEmpty()) {
            for (LoanData loanData : activeLoansData) {
                if ((loanRid == null && loanData.getRid() == null) || (loanData.getRid().equals(loanRid))) {
                    // new borrower added and wanted to make primary it the primary
                	// OR existing borrower making the primary
                    if (loanData.getPrimaryFlag() == null) {
                        loanData.setPrimaryFlag("Yes");
                    }
                } else {
                    loanData.setPrimaryFlag(null);
                }
            }
        }
        return loanBorrowerSectionDto;
    }

    @Override
    public void deleteLoanBorrower(CollateralDetailsMainDto collateralDetailsMainDto, Long loanToDelete) {
    	LoanData toDelete = collateralDetailsMainDto.getLoanBorrowerSectionData().findLoanById(loanToDelete);
        collateralDetailsMainDto.getLoanBorrowerSectionData().addLoanToDele(toDelete);
        loanManagementService.removeLoanCollateral(collateralDetailsMainDto.getCollateralDto().getRid(), collateralDetailsMainDto.getLoanBorrowerSectionData().getDeletedLoans());
        collateralDetailsStatusService.updateLoanBorrowerSection(collateralDetailsMainDto);
    }

    @Override
    @Transactional
    public void savePolicy(CollateralDetailsMainDto collateralDetailsMainDto, ProofOfCoverageDTO proofOfCoverageDTO, List<MultipartFile> policyFiles) {
        validateLpAmounts(proofOfCoverageDTO);
        boolean hasChanged = proofOfCoverageDTO.hasChanged();
    	InsurancePoliciesSectionDto insurancePoliciesSectionDto = collateralDetailsMainDto.getInsuranceSectionData();
    	CollateralDto collateralDto = collateralDetailsMainDto.getCollateralDto();
    	Long collateralRid = collateralDto.getRid();
    	CollateralScreenAction action = CollateralScreenAction.EDIT;
        boolean isVerifyMode = insurancePoliciesSectionDto.isVerifyMode();
    	if (isVerifyMode) {
    		action = CollateralScreenAction.VERIFY;
    		verifyLenderPlacedPolicy(proofOfCoverageDTO);
   			proofOfCoverageDTO = insuranceMngtService.startLpLetterCycleWorkflowManually(collateralRid, proofOfCoverageDTO);
    	}
    	if (action != CollateralScreenAction.EDIT || !proofOfCoverageDTO.getPolicyStatus().isExpiring()) {
    		collateralDetailsStatusService.updateInsurancePoliciesSection(collateralDto, action,null);
    	}
    	insurancePoliciesSectionDto.setVerifyMode(false);

    	saveLPIProofOfCoverageAndPublishEvent(proofOfCoverageDTO, collateralDto, isVerifyMode, hasChanged);
     	if (CollateralScreenAction.VERIFY.equals(action)) {
    		deletePolicyDocuments(proofOfCoverageDTO);
    	} else {
    		savePolicyDocuments(proofOfCoverageDTO, policyFiles);
    	}
    }

    protected void saveLPIProofOfCoverageAndPublishEvent(ProofOfCoverageDTO proofOfCoverageDTO, CollateralDto collateralDto, boolean isVerifyMode, boolean hasChanged) {
        LPIProofOfCoveragePublishEventRequest publishRequest = new LPIProofOfCoveragePublishEventRequest(
                proofOfCoverageDTO, collateralDto.getRid(), collateralDto.getPrimaryLoan().getLineOfBusiness(), false);
        CollateralEventType collateralEventType = proofOfCoverageDTO.getRid() == null ? CollateralEventType.ADDED : CollateralEventType.EDITED;
        if(isVerifyMode) {
             collateralEventType = proofOfCoverageDTO.getLetterCycleWorkflowStep() == null? CollateralEventType.VERIFIED
                    : CollateralEventType.VERIFIED_LP_WITH_WORFLOW;
        }

        //set balance type
        proofOfCoverageDTO.getProvidedCoverageMap().setBalanceType(proofOfCoverageDTO);
        insuranceMngtService.saveProofOfCoverage(proofOfCoverageDTO);
        if(isVerifyMode && hasChanged) {
            publishEventService.publishLPProofOfCoverageEvent(publishRequest.forCollateralEventType(CollateralEventType.EDITED));
        }
        publishEventService.publishLPProofOfCoverageEvent(publishRequest.forCollateralEventType(collateralEventType));
    }

    private void validateLpAmounts(ProofOfCoverageDTO proofOfCoverageData) {
        if (proofOfCoverageData.getPolicyType().isLenderPlaced() &&
                proofOfCoverageData.getProvidedCoverageMap().getAllCoverages(false, null).size() != 1) {
            throw new CtracAjaxException("Only one coverage amount is allowed per policy.");
        }
    }

    private Date getLenderPlaceItemDate(String enteredDate) {
		if (enteredDate == null || enteredDate.trim().equals("")) {
			return(null);
		} else {
			return(DateConverter.convert(enteredDate));
		}
    }

    private BigDecimal getLenderPlaceItemAmount(String enteredAmount) {
		if (enteredAmount == null || enteredAmount.trim().equals("")) {
			return(null);
		} else {
			return(AmountFormatter.parse(enteredAmount));
		}
    }
    
    @Override
    @Transactional
    public void saveOverridePolicyOnly(CollateralDetailsMainDto collateralDetailsMainDto, ProofOfCoverageDTO proofOfCoverageData) {
    	if(proofOfCoverageData.getLenderPlaceItemData() != null && proofOfCoverageData.getLenderPlaceItemData().getRid() != null) {
	    	LenderPlaceItem lpi = lenderPlaceItemRepository.findOne(proofOfCoverageData.getLenderPlaceItemData().getRid());
	    	
	    	if (lpi != null) {
	    		lpi.setLpSendDate(getLenderPlaceItemDate(proofOfCoverageData.getLenderPlaceItemData().getLpSendDate()));
	    		lpi.setCancellationRequestDate(getLenderPlaceItemDate(proofOfCoverageData.getLenderPlaceItemData().getCancellationRequestDate()));
	    		lpi.setCancellationLetterDate(getLenderPlaceItemDate(proofOfCoverageData.getLenderPlaceItemData().getCancellationLetterDate()));
	    		lpi.setRefundCompletionDate(getLenderPlaceItemDate(proofOfCoverageData.getLenderPlaceItemData().getRefundCompletionDate()));
	    		lpi.setRefundAmount(getLenderPlaceItemAmount(proofOfCoverageData.getLenderPlaceItemData().getRefundAmount()));      		
	    		lenderPlaceItemRepository.save(lpi);
	    	}
    	}
    	if(!proofOfCoverageData.getPolicyStatus().isCancelled() && proofOfCoverageData.getCancellationEffectiveDate_() != null){
			proofOfCoverageData.setPolicyStatus(PolicyStatus.CANCELLED);
			readyForLenderPlaceService.updateForPolicyCancelledByAdmin(proofOfCoverageData.getRid());
    	}

    	insuranceMngtService.saveProofOfCoverage(proofOfCoverageData);
        CollateralDto collateralDto = collateralDetailsMainDto.getCollateralDto();
        publishEventService.publishLPProofOfCoverageEvent(new LPIProofOfCoveragePublishEventRequest(
                proofOfCoverageData, collateralDto.getRid(), collateralDto.getPrimaryLoan().getLineOfBusiness(), false)
                .forCollateralEventType(CollateralEventType.ADMIN_EDITED));
    }

	private void deletePolicyDocuments(ProofOfCoverageDTO proofOfCoverageData) {
		if (proofOfCoverageData.getPolicyDocuments() == null) {
			return;
		}
		List<CollateralDocument> policyDocuments = proofOfCoverageData.getPolicyDocuments();
		proofOfCoverageData.setPolicyDocuments(new ArrayList<CollateralDocument>());
		for (CollateralDocument policyDocument : policyDocuments) {
			collateralDocumentService.removeCollateralDocument(policyDocument.getRid());
		}
	}

	private void verifyLenderPlacedPolicy(ProofOfCoverageDTO proofOfCoverageData) {
		if (proofOfCoverageData == null || !proofOfCoverageData.getPolicyType().isLenderPlaced()) {
			throw new RuntimeException("Invalid call to verifyIndividualPolicy");
		}
    	proofOfCoverageData.setPolicyStatus(PolicyStatus.PAID);
	}

	private void savePolicyDocuments(ProofOfCoverageDTO proofOfCoverageData, List<MultipartFile> policyFiles) {
        if (policyFiles != null && !policyFiles.isEmpty()) {
            Collection<CollateralDocument> policyDocuments = collateralDocumentService.savePolicyDocuments(policyFiles, proofOfCoverageData.getRid());
            proofOfCoverageData.getPolicyDocuments().addAll(policyDocuments);
        }
	}

    @Override
    public CreateNewCollateralRecord prepareCreateNewCollateralRecord() {
        logger.info("Inside prepareCreateNewCollateralRecord() method");
        CreateNewCollateralRecord newRecord = new CreateNewCollateralRecord();
        newRecord.setCollateralTypes(lookupCodeRepository.findByCodeSet(CODE_SET_COLLATERAL_TYPES));
        newRecord.setStateCodes(lookupCodeRepository.findByCodeSet(STATES_CODES));
        newRecord.setLinesOfBusiness(lobService.retrieveLinesOfBusiness());
        logger.info("Exit prepareCreateNewCollateralRecord() method");
        return newRecord;
    }
    
    @Override
    @Transactional(readOnly = true)
	public void refreshCollateralSection(CollateralDetailsMainDto collateralDetailsMainDto) {
		refreshCollateralBasedInformation(collateralDetailsMainDto);
	}

	@Override
	@Transactional(readOnly = true)
	public void refreshLoanBorrowerSection(CollateralDetailsMainDto collateralDetailsMainDto) {
		refreshCollateralBasedInformation(collateralDetailsMainDto);
	}

	private void refreshCollateralBasedInformation(CollateralDetailsMainDto collateralDetailsMainDto) {
		refreshCollateralDto(collateralDetailsMainDto.getCollateralDto().getRid(), collateralDetailsMainDto);
		CollateralDto collateralDto = collateralDetailsMainDto.getCollateralDto();
		refreshCollateralSection(collateralDto, collateralDetailsMainDto.getCollateralSectionDto());
        refreshLoanBorrowerSection(collateralDto, collateralDetailsMainDto.getLoanBorrowerSectionData());
	}
	
	private void refreshCollateralDto(Long collateralRid, CollateralDetailsMainDto collateralDetailsMainDto) {
		CollateralDto collateralDto = collateralManagementService.getCollateralDto(collateralRid);
		if (collateralDto == null) {
			throw new CTracApplicationException("E0249", CtracErrorSeverity.TRIVIAL);
		}
		collateralDetailsMainDto.setCollateralDto(collateralDto);
		collateralDetailsMainDto.getCollateralDescriptions().put(collateralDto.getRid(), collateralDto.getCollateralDescription());
	}
	
	private void refreshCollateralSection(CollateralDto collateralDto, CollateralSectionDto collateralSectionDto) {
    	String subTypeCodeSet = CollateralType.findByDescription(collateralDto.getCollateralTypeDescription()).getSubTypeCodeSet();
    	if (subTypeCodeSet != null) {
    		List<LookUpCode> collateralSubTypes = lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(subTypeCodeSet);
			collateralSectionDto.setCollateralSubTypes(collateralSubTypes);
    		for (LookUpCode collateralSubType : collateralSubTypes) {
    			if (collateralSubType.getCode().equals(collateralDto.getCollateralSubType())) {
    				collateralDto.setCollateralSubTypeDescription(collateralSubType.getDescription());
    				break;
    			}
    		}
    	}
    	collateralManagementService.updateCollateralOwnerSameASBorrower(collateralDto.getOwnerData());
        collateralSectionDto.setMortgageDocs(collateralDocumentService.getCollateralDocs(collateralDto.getRid(), CtracAppConstants.MORTGAGE_DOT_IDENTIFIER));
        setShowVerify(collateralSectionDto.getSectionStatusDto());
	}
	
	private void refreshLoanBorrowerSection(CollateralDto collateralDto, LoanBorrowerSectionDto loanBorrowerSectionData) {
		List<LoanData> activeLoansData = loanService.filterByActive(collateralDto.getLoansData(), true);
        List<LoanData> inActiveLoansData = loanService.filterByActive(collateralDto.getLoansData(), false);
       
        if (activeLoansData != null && !activeLoansData.isEmpty()) {
            logger.info("activeLoansData list size - " + activeLoansData.size());
            Collections.sort(activeLoansData, new LoadedDateComparator());
        }

        Collections.sort(inActiveLoansData, new ReleaseDateComparator());
        loanBorrowerSectionData.getActiveLoansData().clear();
        loanBorrowerSectionData.getActiveLoansData().addAll(activeLoansData);
        loanBorrowerSectionData.getInActiveLoansData().clear();
        loanBorrowerSectionData.getInActiveLoansData().addAll(inActiveLoansData);
		setShowVerify(loanBorrowerSectionData.getSectionStatusDto());
	}
    
    @Override
    @Transactional
    public void putCollateralDescription(CollateralDetailsMainDto collateralDetailsMainDto, Long collateralId) {
        if (!collateralDetailsMainDto.getCollateralDescriptions().containsKey(collateralId)) {
            String collateralDescription = collateralManagementService.getCollateralDescription(collateralId);
            collateralDetailsMainDto.getCollateralDescriptions().put(collateralId, collateralDescription);
        }
    }

    @Override
    public boolean checkIfValidExpirationDate(CollateralDetailsMainDto collateralDetailsData, ProofOfCoverageDTO proofOfCoverageData) {
        String expirationDate = proofOfCoverageData.getExpirationDate();
        String effectiveDate = proofOfCoverageData.getEffectiveDate();
        Date referenceDate = calendarDayUtil.getCurrentReferenceDate();
        SimpleDateFormat sdf = new SimpleDateFormat(CtracAppConstants.DATE_FORMAT_US);
        Date expDate = null;
        if (expirationDate != null && effectiveDate != null) {
            try {
                expDate = sdf.parse(expirationDate);
            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
            }

            if (proofOfCoverageData.getPolicyType().getDisplayName().equals(PolicyType.APPLICATION.getDisplayName()) &&
                    CalendarDayUtil.calculateDiffBetweenDates(referenceDate, expDate) >= 30) {
                return false;
            }
            if (proofOfCoverageData.getPolicyType().getDisplayName().equals(PolicyType.BINDER.getDisplayName()) &&
                    CalendarDayUtil.calculateDiffBetweenDates(referenceDate, expDate) >= 90) {
                return false;
            }
        }
        return true;
    }

	@Override
	@Transactional
	@Secured({EntitlementRoles.WRITER_ROLE})
	public void saveLoanBorrower(CollateralDetailsMainDto collateralDetailsData, LoanData loansData, boolean isPrimary) {
		LoanBorrowerSectionDto loanBorrowerSectionData = collateralDetailsData.getLoanBorrowerSectionData();
   		LoanStatus calculatedLoanStatus = !loanBorrowerSectionData.isVerifyMode() ? LoanStatus.PENDING_VERIFICATION :
                (StringUtils.isNotBlank(loansData.getReleasedDate()) ? LoanStatus.RELEASED : LoanStatus.ACTIVE);

		if (isPrimary) {
            if (loansData.getPrimaryFlag() == null || !loansData.isPrimary()) {
                //When loan rid is not known - meaning this is a new loan object to save - set primary flag
                if(loansData.getRid() == null){
                    loansData.setPrimaryFlag(LoanData.CONST_PRIMARY_FLAG);
                }
                //verify the existing active loans on the collateral and remove the primary flag if
                // any primary loans exists that are different the the current loansData to save
                //This just changes primary flag of existing active loans when needed
                changePrimaryLoan(loanBorrowerSectionData, loansData.getRid());
            }
            if(LoanStatus.ACTIVE == calculatedLoanStatus){
                vendorPaymentMethodService.updatePaymentMethodInvoiceLoanNumber(collateralDetailsData.getCollateralDto().getRid(), loansData.getLoanNumber());
            }
        }
        if (loansData.getRid() == null) {
            //new loan add it to the list of loans to process
            collateralDetailsData.getCollateralDto().getLoansData().add(loansData);
        }
        if(loansData.hasChanged() || loanBorrowerSectionData.isVerifyMode()){
            loansData.setStatus(calculatedLoanStatus);
            collateralManagementService.saveCollateral(collateralDetailsData.getCollateralDto(), "");
            collateralDetailsStatusService.updateLoanBorrowerSection(collateralDetailsData);
        }
	}

	@Override
	@Transactional
	@Secured({EntitlementRoles.WRITER_ROLE})
	public CollateralDetailsMainDto submitForVerification(CollateralDetailsMainDto collateralDetailsData) {
		collateralDetailsValidator.validateSubmitForVerification(collateralDetailsData);		
		collateralDetailsStatusService.advanceAllSections(collateralDetailsData.getCollateralDto(), collateralDetailsData.getSectionStatusDtos());
		collateralWorkflowService.initiateVerifyCollateralWorkflow(collateralDetailsData.getCollateralDto().getRid(), PerfectionItemSubType.COLLATERAL,collateralDetailsData.getTmParams());
		return collateralDetailsData;
	}

	@Override
	@Transactional(readOnly = true)
	public void refreshFloodDeterminationSection(
			CollateralDetailsMainDto collateralDetailsMainDto) {
		refreshCollateralBasedInformation(collateralDetailsMainDto);
		refreshFloodDeterminationSection(collateralDetailsMainDto.getCollateralDto(),collateralDetailsMainDto.getFloodDeterminationSectionDto());
		
	}

    @Override
    @Transactional(readOnly = true)
    public String getAdminComments(Long collateralId) {
        try {
            return collateralRepository.getAdminCommentsFor(collateralId);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @Override
    @Transactional
    public void updateAdminComments(Long collateralId, String adminComments) {
        /*int numRecordsChanged = collateralRepository.setAdminCommentsFor(adminComments, collateralId);
        if (numRecordsChanged != 1) {
            throw new CtracAjaxException(numRecordsChanged + " records updated.");
        }*/
    }



}
