package com.jpmorgan.cib.wlt.ctrac.service.admin;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LoanBorrowerAddressData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.LoanBorrowerAddressDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.RestartLetterCycleDTO;

public interface LoanBorrowerAddressService {

	int getUnverifiedLoanBorrowerAddressDataCount();
	List<LoanBorrowerAddressDTO> prepareLoanBorrowerAddressData();
	List<LoanBorrowerAddressDTO> autoCorrectLoanBorrowerAddress();	
	void saveLoanBorrowerAddressRecords(List<LoanBorrowerAddressDTO> loanBorrowerAddressDataList);
	void setVerifiedPostalAddressFields(LoanBorrowerAddressDTO loanBorrowerAddressDTO);
}
