package com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;

public class LenderPlaceAndWireItemRelationDto implements Serializable {
	
	private static final long serialVersionUID = 6299894123235979770L;
	private Map<Long, List<LenderPlaceItem>> matchedLpItemMap;
	private List<LenderPlaceItem>  unmatchedLpItems;
	
	public List<LenderPlaceItem> getUnmatchedPolicies() {
		return unmatchedLpItems;
	}
	
	public void setUnmatchedPolicies(List<LenderPlaceItem> unmatchedPolicies) {
		this.unmatchedLpItems = unmatchedPolicies;
	}
	
	public Map<Long, List<LenderPlaceItem>> getMatchedPolicyMap() {
		return matchedLpItemMap;
	}
	
	public void setMatchedPolicyMap(Map<Long, List<LenderPlaceItem>> matchedPolicyMap) {
		this.matchedLpItemMap = matchedPolicyMap;
	}

}
