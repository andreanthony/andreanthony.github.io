package com.jpmorgan.cib.wlt.ctrac.service.collateral.details.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredCoverageViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.FloodRemapItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.InsurableAssetRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.CancelWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.*;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.builder.InsurableAssetDtoUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.*;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldMappingService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.InsurableAssetService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.RequiredCoverageService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.CollateralCoverageComputationService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LpActionService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.NfipProgramService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ReadyForLenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.workflow.RequiredCoverageLifeEvaluator;
import com.jpmorgan.cib.wlt.ctrac.service.workflow.WorkflowRuleEvaluator;
import com.jpmorgan.cib.wlt.ctrac.service.workflow.WorkflowRuleEvaluatorFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.*;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.FIAT_REQUESTED;


/**
 * @author n595724
 *
 */
@Service(value = "collateralDetailReqCoverageSectionHelper")
public class CollateralDetailReqCoverageSectionHelperImpl implements CollateralDetailReqCoverageSectionHelper {

    @Autowired
    private CollateralDocumentService collateralDocumentService;

    @Autowired
    private InsurableAssetService insurableAssetService;

    @Autowired
    private InsurableAssetRepository  insurableAssetRepository;

    @Autowired
    private LookupCodeRepository lookupCodeRepository;

    @Autowired
    private RequiredCoverageService requiredCoverageService;

    @Autowired
    private CollateralWorkflowService collateralWorkflowService;

    @Autowired
    private CollateralCoverageComputationService collateralCoverageComputationService;

	@Autowired
	private ReadyForLenderPlaceService readyForLenderPlaceService;

    @Autowired
    private CollateralDetailsStatusService collateralDetailsStatusService;

    @Autowired
    private  CollateralManagementService collateralManagementService;

    @Autowired
    private  CancelWorkflowService cancelWorkflowService;

    @Autowired
    private  CollateralDetailsService collateralDetailsService;

    @Autowired
    private  CollateralInsuranceRepository collateralInsuranceRepository;

    @Autowired
    private  ProofOfCoverageRepository proofOfCoverageRepository;

    @Autowired
    private  FloodRemapItemRepository floodRemapItemRepository;

    @Autowired
    private FIATPropertyTypeService fiatPropertyTypeService;

    @Autowired
    private NfipProgramService nfipProgramService;

    @Autowired
    private ReviewCollateralService reviewCollateralService;

    @Autowired
    private HoldService holdService;

    @Autowired
    private HoldMappingService holdMappingService;

    @Autowired
    private TMService tmService;

    @Autowired @Qualifier("fiatLifeEvaluator")
    private RequiredCoverageLifeEvaluator fiatLifeEvaluator;

    @Autowired
    private WorkflowRuleEvaluatorFactory workflowRuleEvaluatorFactory;

    @Autowired
    private DateCalculator dateCalculator;

    @Autowired
    private PublishEventService publishEventService;

    @Autowired
    private LpActionService lpActionService;

    private static final Logger logger = Logger.getLogger(CollateralDetailReqCoverageSectionHelperImpl.class);

    @Override
    public RequiredCoverageSectionDto prepareRequiredCoverageSection(Long collateralRid, RequiredCoverageSectionDto requiredCoverageSectionDto) {
        logger.debug("prepareRequiredCoverageSection::START");
        populateRequiredCoverage(collateralRid, requiredCoverageSectionDto);
        logger.debug("prepareRequiredCoverageSection::END");
        return requiredCoverageSectionDto;
    }

    @Override
    @Transactional
    public InsurancePolicyRequirementDto prepareRequiredCoverageOverlayData(final CollateralDto collateralDto,
            final RequiredCoverageSectionDto requiredCoverageSectionDto, String action, Long fiatId) {

        logger.debug("prepareRequiredCoverageOverlayData::BEGIN");

        // set draf to be the default, then iterate to find the proper fiat to
        InsurancePolicyRequirementDto insurancePolicyRequirementDto = requiredCoverageSectionDto.getPendingVerificationCoverageRequirement();

        // 1) does the overlay need to display for edit purpose <=> a new
        // requirement or the one in draft
        if ("new".equals(action) || "edit".equals(action)) {
            if (requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().isEmpty()) {
                return createNewCoverageRequirementPendingVerification(collateralDto, requiredCoverageSectionDto);
            }
            requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().prepareForEdit();
             return requiredCoverageSectionDto.getPendingVerificationCoverageRequirement();
        }

        // are we trying to veryfy a coverage requirement
        if ("verify".equals(action)) {
            requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().saveACopy();
            requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().prepareForVerification();
            return requiredCoverageSectionDto.getPendingVerificationCoverageRequirement();
        }

        // 2) Are we trying to display a fiat pending verification?
        if(insurancePolicyRequirementDto.getRequiredCoverageSourceDto()!=null ){
            Long fiatPendingVerificationId = insurancePolicyRequirementDto.getRequiredCoverageSourceDto().getRid();

            if (fiatPendingVerificationId != null && fiatPendingVerificationId.equals(fiatId)) {
                return insurancePolicyRequirementDto;
            }
        }

        if(requiredCoverageSectionDto.getActiveCoverageRequirement().getRequiredCoverageSourceDto()!=null){
            // 3) Are we trying to display the verifiedFiat?
            Long verifiedCovFiaID = requiredCoverageSectionDto.getActiveCoverageRequirement().getRequiredCoverageSourceDto().getRid();
            if (verifiedCovFiaID != null && verifiedCovFiaID.equals(fiatId)) {
                return requiredCoverageSectionDto.getActiveCoverageRequirement();
            }
        }


        // 4) Here, we should be trying to display and inactive fiat details
        for (InsurancePolicyRequirementDto inactiveCoverage : requiredCoverageSectionDto.getInactiveCoverageRequirement()) {
            Long inactiveFiatId = inactiveCoverage.getRequiredCoverageSourceDto().getRid();
            if (inactiveFiatId != null && inactiveFiatId.equals(fiatId)) {
                return inactiveCoverage;
            }
        }
        // TODO Throw Invalid FIAtId exception here ...
        logger.error("Error retrieving the fiat data: fiatId: " + fiatId + "Not found.prepareRequiredCoverageOverlayData::END");

        return insurancePolicyRequirementDto;
    }

    // TODO && FIXME remove sortOrder to avoid confusion, the coverage map //
    // automatically assign a sort order if null is passed
    @Override
    public void createAndAppendNewCoverageRequiremnetRow(CollateralDto collateralDto,
            InsurancePolicyRequirementDto coverageRequirementPendingVerification, Integer sortOrder, boolean initAssetDescription) {

        logger.debug("createAndAppendNewCoverageRequiremnetRow::BEGIN");

        if (coverageRequirementPendingVerification.getRequiredCoverageSourceDto() == null) {
            RequiredCoverageSourceDto requiredCoverageSourceDto = new RequiredCoverageSourceDto();
            requiredCoverageSourceDto.setStatus(CoverageRequirementStatus.PENDING_VERIFICATION.name());
            requiredCoverageSourceDto.setInsuranceType(InsuranceType.FLOOD.name());
            coverageRequirementPendingVerification.setRequiredCoverageSourceDto(requiredCoverageSourceDto);
        }

        InsurableAssetDTO newStructure = InsurableAssetDtoUtil.instantiate(collateralDto, InsurableAssetType.STRUCTURE, collateralDto.getRid(), " ", sortOrder);
        InsurableAssetDTO newContent = InsurableAssetDtoUtil.instantiate(collateralDto, InsurableAssetType.BASE_INSURABLE_ASSET, collateralDto.getRid(), " ", sortOrder);
        InsurableAssetDTO newBusinessIncome = InsurableAssetDtoUtil.instantiate(collateralDto, InsurableAssetType.BUSINESS_INCOME, collateralDto.getRid(), " ", sortOrder);

        RequiredCoverageDTO buildingCoverageRequirement = RequiredCoverageDTO.Build(newStructure, new CoverageDetailsDTO(), new CoverageDetailsDTO());

        // this operation will assign a new sort order to the building if sort
        // order is null
        coverageRequirementPendingVerification.addCoverageRequirement(buildingCoverageRequirement);

        RequiredCoverageDTO contentCoverageRequirement = getRequiredCoverageDTO(newContent, buildingCoverageRequirement.getSortOrder());
        coverageRequirementPendingVerification.addCoverageRequirement(contentCoverageRequirement);

        RequiredCoverageDTO businessIncomeCoverageRequirement = getRequiredCoverageDTO(newBusinessIncome, buildingCoverageRequirement.getSortOrder());
        coverageRequirementPendingVerification.addCoverageRequirement(businessIncomeCoverageRequirement);

        logger.debug("createAndAppendNewCoverageRequiremnetRow::END");
    }

    private RequiredCoverageDTO getRequiredCoverageDTO(InsurableAssetDTO insurableAssetDTO, Integer sortOrder) {
        // if the sort order was null, enforce that the building and the content and the business income
        // have the same sortOrder by setting it here
        if (insurableAssetDTO.getSortOrder() == null) {
            insurableAssetDTO.setSortOrder(sortOrder);
        }

        return RequiredCoverageDTO.Build(insurableAssetDTO, new CoverageDetailsDTO(), new CoverageDetailsDTO());
    }

    @Override
    @Transactional
    public void deleteAllRequiredCoverages(InsurancePolicyRequirementDto coverageRequirementPendingVerification,
    		CollateralDetailsMainDto collateralDetailsMainDto) {

        logger.debug("deleteAllRequiredCoverages::BEGIN");
        Set<Long> insurableAssetIDs = new HashSet<Long>();
        Collection<Long> pendingDeleteCoverages =  collateralDetailsMainDto.getRequiredCoverageSectionDto().getDeletedCoverageIds();
        if (pendingDeleteCoverages != null && !pendingDeleteCoverages.isEmpty()) {
            insurableAssetIDs.addAll(pendingDeleteCoverages);
        }
        for (RequiredCoverageDTO requiredCoverageDto : coverageRequirementPendingVerification.getRequiredCoverages()) {
            if (requiredCoverageDto.getInsurableAssetDTO() != null && requiredCoverageDto.getInsurableAssetDTO().getRid() != null) {
                insurableAssetIDs.add(requiredCoverageDto.getInsurableAssetDTO().getRid());
            }
        }
        boolean canDelete = coverageRequirementPendingVerification.canDelete();

        if(!canDelete){
        	 throw new RuntimeException(" Cannot delete a building/content with a policy attached to it");
        }

        insurableAssetService.deleteInsurableAssetCoverageRequirement(insurableAssetIDs, CoverageRequirementStatus.PENDING_VERIFICATION);
        String description =getDescriptionFromRequiredCoverageDTOs(coverageRequirementPendingVerification.getRequiredCoverages());
        coverageRequirementPendingVerification.getRequiredCoverageMap().getInsurableAssetCoverageData().clear();
	    CollateralWorkflowParam result  = collateralDetailsStatusService.advanceSection(
	    		collateralDetailsMainDto.getCollateralDto(), collateralDetailsMainDto.getTmParams(),
	    		collateralDetailsMainDto.getRequiredCoverageSectionDto().getSectionStatusDto(), CollateralScreenAction.VERIFY);
	    collateralWorkflowService.triggerCollateralWorkflow(result);

        logger.debug("deleteAllRequiredCoverages::END");
        publishEventService.publishRequiredFloodCoverageAmountEvent(coverageRequirementPendingVerification.getRequiredCoverageSourceDto().getDocumentDate(),
                collateralDetailsMainDto.getCollateralDto().getRid(),collateralDetailsMainDto.getCollateralDto().getPrimaryLoan().getLineOfBusiness(),
                description,
                CollateralEventType.DELETED);


    }



    @Override
    @Transactional
    public boolean areInsurableAssetDeletable (Set<Long> insurableAssetID){

    	boolean canDelete=true;

    	if( insurableAssetID!= null && !insurableAssetID.isEmpty()){
    		List<InsurableAsset> insurableAssets = insurableAssetRepository.findByRidIn(insurableAssetID);
    		for( InsurableAsset insurableAsset: insurableAssets){
    			if( !insurableAsset.getProvidedCoverages().isEmpty()){
    				List <ProvidedCoverage> providedCovs = insurableAsset.getProvidedCoverages();
    				for(ProvidedCoverage prov: providedCovs){
    					/**
    					 * @Christian FIXME: Does it matter if policyStatus is active?
    					 * Shouldn't we prevent delete no matter what if there is a policy?
    					 */
    					 PolicyStatus policyStatus = PolicyStatus.valueOf(prov.getProofOfCoverage().getPolicyStatus());
    					 if(policyStatus.isActive(true)){
    						 canDelete=false;
    						 break;
    					 }
    				}
    			}
    		}
    	}
    	return canDelete;

    }

    @Override
    @Transactional
    public Collection<RequiredCoverageDTO> persistCollateralInsurenaceRequirementSection(final CollateralDto collateralDto,
            final InsurancePolicyRequirementDto insurancePolicyRequirement, String action) {
        logger.debug("persistCollateralInsurenaceRequirementSection::BEGIN");
        // first store the fiat document if it has changed; the bucket key was
        // set to "Fiat_"+taskUUId
        Long collateralId = collateralDto.getRid();

        List<MultipartFile> fiatFile = null;
        if( !"verify verify-missmatch".contains( (String) action )){
        	fiatFile = collateralDocumentService.fetchAttachedDocuments("Fiat_" + collateralId.toString());
        }
        requiredCoverageService.saveRequiredCoverageSource(insurancePolicyRequirement.getRequiredCoverageSourceDto(), fiatFile);
        Collection<RequiredCoverageDTO> requiredCoverageDtoList = insurancePolicyRequirement.getRequiredCoverages();
        holdMappingService.mapHoldsToCoverageDetails(insurancePolicyRequirement.getRequiredCoverages());
        requiredCoverageService.saveRequiredCoverage(requiredCoverageDtoList);
        logger.debug("persistCollateralInsurenaceRequirementSection::END");
        return requiredCoverageDtoList;

    }

    @Override
    @Transactional
    public  void proccessRequiredCoverageSubmit(
            final InsurancePolicyRequirementDto insurancePolicyRequirementDto,
			CollateralDetailsMainDto collateralDetailsMainDto, String action) throws Exception {

        CollateralEventType collateralEventType = null;
        if(insurancePolicyRequirementDto.getRequiredCoverageSourceDto().getRid()==null){
            collateralEventType=CollateralEventType.ADDED;
        }

        // 1- are we dealing with the submit of verify-missmatch? or the submit of verify?
    	CollateralDto collateralDto = collateralDetailsMainDto.getCollateralDto();
        String documentDate= insurancePolicyRequirementDto.getRequiredCoverageSourceDto().getDocumentDate();
        boolean changeOnVerification = false;
		if( "verify verify-missmatch".contains( (String) action )){
            changeOnVerification=insurancePolicyRequirementDto.hasChanged();
            insurancePolicyRequirementDto.finalizeVerification();
		    //update the FIAT currently in verifies status to inactive; not need to save verified coverage req
		    InsurancePolicyRequirementDto activeInsurancePolicyRequirementDto = collateralDetailsMainDto.getRequiredCoverageSectionDto().getActiveCoverageRequirement();

		    if(!activeInsurancePolicyRequirementDto.isEmpty()){
		        activeInsurancePolicyRequirementDto.finalizeVerification();
		        requiredCoverageService.saveRequiredCoverageSource(activeInsurancePolicyRequirementDto.getRequiredCoverageSourceDto(), null);
		    }
		    CollateralWorkflowParam result  = collateralDetailsStatusService.advanceSection(
		    		collateralDto, collateralDetailsMainDto.getTmParams(),
		    		collateralDetailsMainDto.getRequiredCoverageSectionDto().getSectionStatusDto(), CollateralScreenAction.VERIFY);
		    collateralWorkflowService.triggerCollateralWorkflow(result);
		} else{
		    CollateralWorkflowParam result  = collateralDetailsStatusService.advanceSection(
		    		collateralDto, collateralDetailsMainDto.getTmParams(),
		    		collateralDetailsMainDto.getRequiredCoverageSectionDto().getSectionStatusDto(), CollateralScreenAction.EDIT);
		    collateralWorkflowService.triggerCollateralWorkflow(result);
		}

		Collection<Long> insAssetWithPendingReqCoverateToDelete = collateralDetailsMainDto.getRequiredCoverageSectionDto().getDeletedCoverageIds();

		insurableAssetService.deleteInsurableAssetCoverageRequirement(insAssetWithPendingReqCoverateToDelete,CoverageRequirementStatus.PENDING_VERIFICATION);


		if( "verify verify-missmatch".contains( (String) action )){
			deleteAttachedDocuments(insurancePolicyRequirementDto.getRequiredCoverageSourceDto().getCoverageSourceDocuments() );
		}

		// save the coverage pending verification
		Collection<RequiredCoverageDTO> requiredCoverageDtos = persistCollateralInsurenaceRequirementSection(
				collateralDto, insurancePolicyRequirementDto, action);
		/**
		 * re-initialize the coverage pending verification with the
		 * persisted values of the required coverage the params pointers
		 * being final, this changes will be automatically reflected inside
		 * the collateralMainDto.requiredCoverageSectionDto because we are
		 * not de-referentiating any pointer
		 */


		insurancePolicyRequirementDto.getRequiredCoverageMap().getInsurableAssetCoverageData().clear();

		insurancePolicyRequirementDto.addCoverageRequirement(requiredCoverageDtos);

		if( "verify verify-missmatch".contains( (String) action )){
			// Hold Processing
			holdService.processHold(requiredCoverageDtos, collateralDetailsMainDto.getCollateralDto().getRid());

			// has to be triggered after persisting the required coverage verification
			if(isBorrowerCancelWorkflow(collateralDetailsMainDto)) {
                processBorrowerCancellation(collateralDto);

                collateralDetailsService.refreshInsurancePoliciesSection(
						collateralDto.getRid(), collateralDetailsMainDto.getInsuranceSectionData());
			}
			/**
			 * if dealing with save of verify or verify miss-match, we need to refresh the coverage Rq section from DB
			 * as it is too wacky to try to rebuild it
			 */
		    RequiredCoverageSectionDto requiredCoverageSectionDto = prepareRequiredCoverageSection(
		    		collateralDto.getRid(), collateralDetailsMainDto.getRequiredCoverageSectionDto());
		    collateralDetailsMainDto.setRequiredCoverageSectionDto(requiredCoverageSectionDto);

		    // trigger fiat verified LCP-2337; cancel any fiat not receive ...
		    notifyFiatVerificationEvents(collateralDto.getRid(),requiredCoverageDtos);
		}
         if(changeOnVerification) {
             publishEventService.publishRequiredFloodCoverageAmountEvent(documentDate,
                     collateralDto.getRid(), collateralDetailsMainDto.getCollateralDto().getPrimaryLoan().getLineOfBusiness(),
                     getDescriptionFromRequiredCoverageDTOs(requiredCoverageDtos),
                     CollateralEventType.EDITED);
        }
        if(collateralEventType ==null) {
            collateralEventType = "edit".equals(action) ? CollateralEventType.EDITED : CollateralEventType.VERIFIED;
        }
        publishEventService.publishRequiredFloodCoverageAmountEvent(documentDate,
                collateralDto.getRid(), collateralDetailsMainDto.getCollateralDto().getPrimaryLoan().getLineOfBusiness(),
                getDescriptionFromRequiredCoverageDTOs(requiredCoverageDtos),
                collateralEventType);
    }

    protected void processBorrowerCancellation(CollateralDto collateralDto) {
        List<ProofOfCoverage> cancelledBorrowerPolicies = getCancelledBorrowerPoliciesOrderedByCancelDate(collateralDto.getRid());
        if (!CollectionUtils.isEmpty(cancelledBorrowerPolicies)) {
            // first cancelled policy with the earliest cancellation effective date
            ProofOfCoverage firstCancelledPolicy = cancelledBorrowerPolicies.iterator().next();
            collateralWorkflowService.triggerInsuranceCoverageEvaluation(null, collateralDto, firstCancelledPolicy.getRid());
            // clear C3 trigger
            lpActionService.updateLpAction(cancelledBorrowerPolicies.stream().map(ProofOfCoverage::getRid).collect(Collectors.toList()), null);
        } else {
            collateralWorkflowService.triggerInsuranceCoverageEvaluation(null, collateralDto);
        }
    }

    private String getDescriptionFromRequiredCoverageDTOs(Collection<RequiredCoverageDTO> requiredCoverageDtos) {
        Iterator<RequiredCoverageDTO> requiredCoverageIter = requiredCoverageDtos.iterator();
        while (requiredCoverageIter.hasNext()) {
            RequiredCoverageDTO requiredCoverageDTO = requiredCoverageIter.next();
            if((requiredCoverageDTO.getPrimaryHold()!=null &&requiredCoverageDTO.getPrimaryHold().getHoldType()!=null )
                    || (requiredCoverageDTO.getExcessHold()!=null && requiredCoverageDTO.getExcessHold().getHoldType()!=null)) {
              return "Hold Included";
            }
        }
        return "";
    }

    protected List<ProofOfCoverage> getCancelledBorrowerPoliciesOrderedByCancelDate(Long collateralRid) {
		List<CollateralInsuranceViewData> collateralInsuranceViewData = collateralInsuranceRepository.findByCollateralRid(collateralRid);
        List<ProofOfCoverage> cancelledPolicies = new ArrayList<>();
        for(CollateralInsuranceViewData collateralInsuranceData: collateralInsuranceViewData){
			if(collateralInsuranceData.getProofOfCoverage().getPolicyType_().isBorrowerPolicy() &&
					LPActions.CANCEL_BP.equals(collateralInsuranceData.getProofOfCoverage().getLpAction_())) {
                cancelledPolicies.add(collateralInsuranceData.getProofOfCoverage());
			}
		}
		Collections.sort(cancelledPolicies, new CancellationEffectiveDateComparator());
		return cancelledPolicies;
	}

	private boolean isBorrowerCancelWorkflow(CollateralDetailsMainDto collateralDetailsMainDto) {

		Set<PerfectionTask> tasks = collateralWorkflowService.getRequiredCoverageRequestTasks(
				collateralDetailsMainDto.getCollateralDto().getRid());
		if(tasks == null || tasks.isEmpty()){
			return false;
		}
		return cancelWorkflowService.hasPendingBorrowerCancelWorkflow(tasks.iterator().next());
	}

    @Override
	public void updateDescopedCoverageAmounts(InsurancePolicyRequirementDto insurancePolicyRequirementDto) {
		 Collection<RequiredCoverageDTO> requiredCoverageDtoList = insurancePolicyRequirementDto.getRequiredCoverages();
         for(RequiredCoverageDTO requiredCoverageDTO : requiredCoverageDtoList){
        	 if("Yes".equalsIgnoreCase(requiredCoverageDTO.getIsDescoped())){
        		 if (requiredCoverageDTO.getPrimaryCoverageDetailsDto() != null) {
        			 requiredCoverageDTO.getPrimaryCoverageDetailsDto().setCoverageAmount("0.00");
        			 requiredCoverageDTO.getPrimaryCoverageDetailsDto().setBalanceType(null);
        		 }

        		 if (requiredCoverageDTO.getExcessCoverageDetailsDto() != null) {
        			 requiredCoverageDTO.getExcessCoverageDetailsDto().setCoverageAmount("0.00");
        			 requiredCoverageDTO.getExcessCoverageDetailsDto().setBalanceType(null);
        		 }
 	     	}
         }
	}

	@Override
	@Transactional
	public void notifyFiatVerificationEvents(final Long collateralRid, Collection<RequiredCoverageDTO> requiredCoverageDtos) {

		Set<PerfectionTask> requestWorkflowTasks = collateralWorkflowService.getRequiredCoverageRequestTasks(collateralRid);
		boolean remapsDone = false;

		if (requestWorkflowTasks != null) {
			FloodRemapItem workItem = getFloodRemapItem(requestWorkflowTasks, collateralRid);
			if(workItem != null) {
				if(nfipProgramService.isRequiredCoverageWorkflowAllowed(workItem)){
					/**
					 * 1- For remap, trigger coverage computation and LP
					 * immediately,
					 */
					CoverageActionRequest coverageActionRequest = new CoverageActionRequest(collateralRid,
							workItem.getRid(), null);
					CoverageActionResult result = collateralCoverageComputationService
							.evaluateInsuranceCoverageActions(coverageActionRequest);
					collateralCoverageComputationService.applyInsuranceCoverageActions(result, workItem);
					remapsDone = true;
				} else { // Someone verified fiat when it should not be allowed for Zone In, what should we do?
					throw new RuntimeException("Fiat Verification for Zone In is not allowed");
				}
			}

            /**
             * 2- make the fiat / SBA Coverage workflow tasks advance to completion;
             */
            completeRequiredCoverageRequestWorkflow(collateralRid, requiredCoverageDtos, requestWorkflowTasks);
			/**
			 * 3 - For renewal, mark all the collateral<=>policies records in
			 * tlcp_ready_for_lp as true;
			 */
			if(!reviewCollateralService.hasActiveReviewCollateralTask(collateralRid)){
                readyForLenderPlaceService.updateRenewalStartedToReady(collateralRid);
            }
		} else { // Someone just randomly input a fiat, what should we do?
			logger.info(" Input and Verify Fiat happen unexpectelly !!! ");
		}

		if (!remapsDone) {
            Set<RequiredCoverageViewData> previousCoverages = requiredCoverageService.getLatestInactiveRequiredCoverages(collateralRid);
            if(!CollectionUtils.isEmpty(previousCoverages)) {
                Set<Long> insurableAssetRids = getDescopedInsurableAssets(requiredCoverageDtos);
                insurableAssetRids.addAll(getAddedNewInsurableAssets(requiredCoverageDtos, previousCoverages));
                insurableAssetRids.addAll(getInsurableAssetsWithNewHold(requiredCoverageDtos));
                if (!CollectionUtils.isEmpty(insurableAssetRids)) {
                    CoverageActionResult result = collateralCoverageComputationService.evaluateInsurableAssetCoverageActions(collateralRid, insurableAssetRids);
                    collateralCoverageComputationService.applyInsuranceCoverageActions(result, null);
                }
            }
		}
	}

    void completeRequiredCoverageRequestWorkflow(Long collateralRid, Collection<RequiredCoverageDTO> requiredCoverageDtos, Set<PerfectionTask> requestWorkflowTasks) {
        PerfectionTask fiatRequestedTask = getPerfectionTask(requestWorkflowTasks, WorkflowStateDefinition.FIAT_REQUESTED);
        if (fiatRequestedTask == null) {
            collateralWorkflowService.completeRequiredCoverageRequestWorkflow(requestWorkflowTasks);
        }
        else {
            Date firstExpirationDate = getFirstExpirationDateWithNoLivingRequiredCoverage(collateralRid, fiatRequestedTask);
            if(firstExpirationDate == null) {
                collateralWorkflowService.completeRequiredCoverageRequestWorkflow(requestWorkflowTasks);
            }
            else {
                PerfectionTask fiatNotReceivedTask = getPerfectionTask(requestWorkflowTasks, WorkflowStateDefinition.FIAT_NOT_RECEIVED);
                updateFiatRequestedExecutionDate(fiatRequestedTask, fiatNotReceivedTask, firstExpirationDate);
            }
        }
    }

    Date getFirstExpirationDateWithNoLivingRequiredCoverage(Long collateralRid, PerfectionTask fiatRequestedTask) {
        Date firstExpirationDateWithNoLivingRequiredCoverage = null;
        WorkflowStateDefinition workflowStateDefinition = WorkflowStateDefinition.findByWorkflowStep(fiatRequestedTask.getWorkflowStep());
        WorkflowRuleEvaluator reqCoverageWorkflowEvaluator = workflowRuleEvaluatorFactory.createReqCoverageWorkflowEvaluator(workflowStateDefinition);
        List<ProofOfCoverage> expiringPolicies = getExpiringPoliciesSortedByExpirationDate(collateralRid);
        for (ProofOfCoverage proofOfCoverage : expiringPolicies) {
            if(!reqCoverageWorkflowEvaluator.hasLivingRequiredCoverageOnExpiration(collateralRid, proofOfCoverage)) {
                firstExpirationDateWithNoLivingRequiredCoverage = proofOfCoverage.getExpirationDate();
                break;
            }
        }
        return firstExpirationDateWithNoLivingRequiredCoverage;
    }

    List<ProofOfCoverage> getExpiringPoliciesSortedByExpirationDate(Long collateralRid) {
        List<CollateralInsuranceViewData> collateralInsuranceViewData = collateralInsuranceRepository.findByCollateralRid(collateralRid);
        List<ProofOfCoverage> expiringPolicies = new ArrayList<>();
        for(CollateralInsuranceViewData collateralInsuranceData: collateralInsuranceViewData){
            if(collateralInsuranceData.getProofOfCoverage().getPolicyStatus_().isExpiring()) {
                expiringPolicies.add(collateralInsuranceData.getProofOfCoverage());
            }
        }
        Collections.sort(expiringPolicies, new ExpirationDateComparator());
        return expiringPolicies;
    }

    void updateFiatRequestedExecutionDate(PerfectionTask fiatRequestedTask, PerfectionTask fiatNotReceivedTask, Date expirationDate) {
        //update execute date to 5 BD before the first expiration date that is more than 75 days after the FIAT document date
    	Date executionDate = workflowRuleEvaluatorFactory.createReqCoverageWorkflowEvaluator(FIAT_REQUESTED).getRequestTaskDueDate(expirationDate);
    	try {
	        //Date executionDate = workflowRuleEvaluatorFactory.createReqCoverageWorkflowEvaluator(FIAT_REQUESTED).getRequestTaskDueDate(expirationDate);
	        fiatRequestedTask.setExecutionDate(executionDate);
	        tmService.amendTask(fiatRequestedTask);
    	}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
    	}catch (Exception ex) {			
			throw new CTracApplicationException("E0353", CtracErrorSeverity.APPLICATION, ex);
		}
        //close the FIAT Not Received task if the new execution date is in the future
    	try {
	        if(fiatNotReceivedTask != null && executionDate.after(dateCalculator.getCurrentReferenceDate())){
	            tmService.cancelTask(fiatNotReceivedTask);
	        }
    	} catch (TMServiceApplicationException ex) {
				throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
    	} catch (Exception ex) {			
			throw new CTracApplicationException("E0146", CtracErrorSeverity.APPLICATION, ex);
		}
    }

    PerfectionTask getPerfectionTask(Set<PerfectionTask> requestWorkflowTasks, WorkflowStateDefinition workflowStateDefinition) {
        for (PerfectionTask perfectionTask: requestWorkflowTasks) {
            if(workflowStateDefinition.getName().equals(perfectionTask.getWorkflowStep())){
                return perfectionTask;
            }
        }
        return null;
    }

    /*
	return rids of all insurable assets that were not found in previous fiats
	 */
    protected Set<Long> getAddedNewInsurableAssets(Collection<RequiredCoverageDTO> requiredCoverageDtos, Set<RequiredCoverageViewData> previousCoverages) {
        Set<Long> insurableAssetRids = new HashSet<>();
        if(!CollectionUtils.isEmpty(previousCoverages)) {
            for (RequiredCoverageDTO dto : requiredCoverageDtos) {
                Long insurableAssetRid = dto.getInsurableAssetDTO().getRid();
                if (isNewInsurableAssetAdded(previousCoverages, insurableAssetRid)) {
                    insurableAssetRids.add(dto.getInsurableAssetDTO().getRid());
                }
            }
        }
        return insurableAssetRids;
    }

    /*
     return rids of all insurable assets with a new hold added
      */
    protected Set<Long> getInsurableAssetsWithNewHold(Collection<RequiredCoverageDTO> requiredCoverageDTOs) {
        Set<Long> insurableAssetRids = new HashSet<>();
        for (RequiredCoverageDTO requiredCoverageDTO : requiredCoverageDTOs) {
            if (requiredCoverageDTO.hasNewHold()) {
                insurableAssetRids.add(requiredCoverageDTO.getInsurableAssetDTO().getRid());
            }
        }
        return insurableAssetRids;
    }

    protected boolean isNewInsurableAssetAdded(Set<RequiredCoverageViewData> previousCoverages, Long insurableAssetRid) {
        boolean isExisting = false;
        for (RequiredCoverageViewData requiredCoverageViewData : previousCoverages) {
            if (insurableAssetRid.equals(requiredCoverageViewData.getInsurableAssetRid())) {
                isExisting = true;
            }
        }
        return !isExisting;
    }

     protected Set<Long> getDescopedInsurableAssets(Collection<RequiredCoverageDTO> requiredCoverageDtos) {
        RequiredCoverageSourceDto source;
        Set<Long> insurableAssetRids = new HashSet<>();
        for (RequiredCoverageDTO dto : requiredCoverageDtos) {
            if ("Yes".equalsIgnoreCase(dto.getIsDescoped())) {
                source = dto.getRequiredCoverageSourceDto();
                if (source.getCancellationEffectiveDate() != null) {
                    insurableAssetRids.add(dto.getInsurableAssetDTO().getRid());
                }
            }
        }
        return insurableAssetRids;
    }

    protected FloodRemapItem getFloodRemapItem(Long collateralRid) {
		Set<PerfectionTask> requestWorkflowTasks = collateralWorkflowService.getRequiredCoverageRequestTasks(collateralRid);
		if (requestWorkflowTasks != null) {
			return getFloodRemapItem(requestWorkflowTasks, collateralRid);
		}
		return null;
	}

	protected FloodRemapItem getFloodRemapItem(Set<PerfectionTask> requestWorkflowTasks, Long collateralRid) {
		for (final PerfectionTask perfectionTask : requestWorkflowTasks) {
			if(TMTaskType.FLOOD_REMAP.name().equals(perfectionTask.getTmTaskType())) {
				List<FloodRemapItem> workItems = floodRemapItemRepository.findByCollateralRidOrderByRidDesc(collateralRid);
				//select the latest floodRemapItem
				if(workItems != null && !workItems.isEmpty()) {
					return workItems.get(0) ;
				}
			}
		}
		return null;
	}

	private void populateRequiredCoverage(Long collateralRid, RequiredCoverageSectionDto requiredCoverageSectionDto) {
        logger.debug("populateRequiredCoverage::BEGIN");
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        requiredCoverageSectionDto.setBalanceTypes(lookupCodeRepository.findByCodeSet(BALANCE_TYPE_CODES));
        reinitializeRequiredCoverageSection(requiredCoverageSectionDto);

        if (collateralManagementService.isCollateralBusinessAssetSBAOnly(collateralRid)) {
            requiredCoverageSectionDto.setSbaCoverageRequested(collateralWorkflowService.isSBACoverageRequested(collateralRid));
            Date sbaCoverageRequestedDate = collateralWorkflowService.getSBACoverageRequestedDate(collateralRid);
            String strSBACoverageRequestedDate = sbaCoverageRequestedDate == null ? "" : sdf.format(sbaCoverageRequestedDate);
            requiredCoverageSectionDto.setSbaCoverageRequestedDate(strSBACoverageRequestedDate);

        } else {
            requiredCoverageSectionDto.setFiatRequested(collateralWorkflowService.isFiatRequested(collateralRid));
            Date fiatRequestedDate = collateralWorkflowService.getFiatRequestedDate(collateralRid);
            String strFiatRequestedDate = fiatRequestedDate == null ? "" : sdf.format(fiatRequestedDate);
            requiredCoverageSectionDto.setFiatRequestedDate(strFiatRequestedDate);
        }

        Collection<RequiredCoverageDTO> allRequiredCoverages = requiredCoverageService.findRequiredCoverageByCollateral(collateralRid, null);
        Map<Long, Collection<RequiredCoverageDTO>> inactiveMap = new HashMap<>();
        for (RequiredCoverageDTO requiredCov : allRequiredCoverages) {
            RequiredCoverageSourceDto requiredCoverageSourceDto = requiredCov.getRequiredCoverageSourceDto();
            String coverageSourceStatus = requiredCoverageSourceDto.getStatus();
            if (CoverageRequirementStatus.PENDING_VERIFICATION.name().equals(coverageSourceStatus)) {
                requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().addCoverageRequirement(requiredCov);
                requiredCoverageSectionDto.setWorkflowAllowed(
                		nfipProgramService.isRequiredCoverageWorkflowAllowed(getFloodRemapItem(collateralRid)));
            } else if (CoverageRequirementStatus.VERIFIED.name().equals(coverageSourceStatus)) {
                requiredCoverageSectionDto.getActiveCoverageRequirement().addCoverageRequirement(requiredCov);
            } else if (CoverageRequirementStatus.INACTIVE.name().equals(coverageSourceStatus)) {
                Long sourceID = requiredCoverageSourceDto.getRid();
                Collection<RequiredCoverageDTO> fiatList = inactiveMap.get(sourceID);
                if (fiatList == null) {
                    fiatList = new ArrayList<>();
                    inactiveMap.put(sourceID, fiatList);
                }
                fiatList.add(requiredCov);
            }
            if (requiredCoverageSourceDto.getPropertyTypes() == null) {
                requiredCoverageSourceDto.setPropertyTypes(fiatPropertyTypeService.getPropertyTypesForDescription(requiredCov.getPropertyType()));
            }
            //for hold
            if(requiredCoverageSourceDto.getHoldTypes() == null){

                requiredCoverageSourceDto.setHoldTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(HOLD_TYPES));
            }

            //for hold
            if(requiredCoverageSourceDto.getHoldPeriods()== null){

                requiredCoverageSourceDto.setHoldPeriods(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(HOLD_PERIODS));
            }

        }
        holdMappingService.mapCoverageDetailsToHold(allRequiredCoverages);

        if (!inactiveMap.isEmpty()) {
            for (Entry<Long, Collection<RequiredCoverageDTO>> entries : inactiveMap.entrySet()) {
                InsurancePolicyRequirementDto inactivecoverage = new InsurancePolicyRequirementDto();
                inactivecoverage.addCoverageRequirement(entries.getValue());
                requiredCoverageSectionDto.getInactiveCoverageRequirement().add(inactivecoverage);
            }
        }
        inactiveMap.clear();
        allRequiredCoverages.clear();
        logger.debug("populateRequiredCoverage::END");
    }

    // TODO no DB operation => can be moved to a utility/helper class

    private InsurancePolicyRequirementDto createNewCoverageRequirementPendingVerification(final CollateralDto collateralDto,
            final RequiredCoverageSectionDto requiredCoverageSectionDto) {

        // 1) When recording a new FIAT, if there is a verified fiat, use it to
        // intialize the building and content of the new fiat.
        InsurancePolicyRequirementDto newCoverageRequirement = null;
        InsurancePolicyRequirementDto verifiedCoverageRequirement = requiredCoverageSectionDto.getActiveCoverageRequirement();
        if (!verifiedCoverageRequirement.isEmpty()) {
            InsurancePolicyRequirementDto newCoverageRequirementPendingVerification = initializeNewCoverageRequirementFromVerifiedFiat(verifiedCoverageRequirement);
            requiredCoverageSectionDto.setPendingVerificationCoverageRequirement(newCoverageRequirementPendingVerification);
            newCoverageRequirement = requiredCoverageSectionDto.getPendingVerificationCoverageRequirement();
        } else {
            // 2) If there is no verified fiat, create a new building and a new
            // structure.
            // TODO FIXME set the flood Zone ..
            InsurancePolicyRequirementDto insurancePolicyRequirementDto = new InsurancePolicyRequirementDto();
            createAndAppendNewCoverageRequiremnetRow(collateralDto, insurancePolicyRequirementDto, null, true);
            requiredCoverageSectionDto.setPendingVerificationCoverageRequirement(insurancePolicyRequirementDto);
            newCoverageRequirement = insurancePolicyRequirementDto;
        }
        newCoverageRequirement.getRequiredCoverageSourceDto().setPropertyTypes(fiatPropertyTypeService.getPropertyTypesForDescription(null));
        //for hold
        newCoverageRequirement.getRequiredCoverageSourceDto().setHoldTypes(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(HOLD_TYPES));
        newCoverageRequirement.getRequiredCoverageSourceDto().setHoldPeriods(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(HOLD_PERIODS));

        return newCoverageRequirement;
    }

    private InsurancePolicyRequirementDto initializeNewCoverageRequirementFromVerifiedFiat(InsurancePolicyRequirementDto verifiedCoverageRequirement) {
        InsuranceCoverageMap<RequiredCoverageDTO> requiredCoverageMap = verifiedCoverageRequirement.getRequiredCoverageMap();
        Collection<RequiredCoverageDTO> requiredCoverageDtos = requiredCoverageMap.getAllCoverages(true, null);
        InsurancePolicyRequirementDto newCoverageRequirementPendingVerification = new InsurancePolicyRequirementDto();

        if (requiredCoverageDtos != null && !requiredCoverageDtos.isEmpty()) {
            for (RequiredCoverageDTO requiredCoverageDTO : requiredCoverageDtos) {
                RequiredCoverageDTO copyOfCovPendingVerif = RequiredCoverageDTO.Build(
                        requiredCoverageDTO.getInsurableAssetDTO(), new CoverageDetailsDTO(), new CoverageDetailsDTO(),
                        checkHoldForVerifiedLpiDate(requiredCoverageDTO.getPrimaryHold()),
                        checkHoldForVerifiedLpiDate(requiredCoverageDTO.getExcessHold()));
                newCoverageRequirementPendingVerification.addCoverageRequirement(copyOfCovPendingVerif);
            }
            RequiredCoverageSourceDto copyCoverageSource = new RequiredCoverageSourceDto();
            copyCoverageSource.setStatus(CoverageRequirementStatus.PENDING_VERIFICATION.name());
            copyCoverageSource.setInsuranceType(InsuranceType.FLOOD.name());
            newCoverageRequirementPendingVerification.setRequiredCoverageSourceDto(copyCoverageSource);
        }
        holdMappingService.mapCoverageDetailsToHold(newCoverageRequirementPendingVerification.getRequiredCoverages());
        newCoverageRequirementPendingVerification.setMinDocumentDate(
        		verifiedCoverageRequirement.getRequiredCoverageSourceDto().getDocumentDate());

        return newCoverageRequirementPendingVerification;
    }

    HoldDTO checkHoldForVerifiedLpiDate(HoldDTO holdDTO) {
        if(holdDTO == null || holdDTO.hasVerifiedLpiDate()){
            return null;
        }
        return holdDTO;
    }

    private void reinitializeRequiredCoverageSection(RequiredCoverageSectionDto requiredCoverageSectionDto) {
        requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().getRequiredCoverageMap().getInsurableAssetCoverageData().clear();
        requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().setRequiredCoverageSourceDto(null);
        requiredCoverageSectionDto.getActiveCoverageRequirement().getRequiredCoverageMap().getInsurableAssetCoverageData().clear();
        requiredCoverageSectionDto.getActiveCoverageRequirement().setRequiredCoverageSourceDto(null);
        requiredCoverageSectionDto.getInactiveCoverageRequirement().clear();
    }

    private void deleteAttachedDocuments(Collection<CollateralDocument> attachedDocs){
    	List<CollateralDocument> attachedDocsList=new ArrayList<CollateralDocument>();
    	for(CollateralDocument collateralDoc : attachedDocs){
    		attachedDocsList.add(collateralDoc);
    	}
    	collateralDocumentService.removeCollateralDocuments(attachedDocsList);
    }

    private class CancellationEffectiveDateComparator implements Comparator<ProofOfCoverage> {
        @Override
        public int compare(ProofOfCoverage proofOfCoverage1, ProofOfCoverage proofOfCoverage2) {
            //CancellationEffectiveDate is never null on cancelled policies
            return proofOfCoverage1.getCancellationEffectiveDate().compareTo(proofOfCoverage2.getCancellationEffectiveDate());
        }
    }


    private class ExpirationDateComparator implements Comparator<ProofOfCoverage> {
        @Override
        public int compare(ProofOfCoverage proofOfCoverage1, ProofOfCoverage proofOfCoverage2) {
            //ExpirationDate is never null on any policy
            return proofOfCoverage1.getExpirationDate().compareTo(proofOfCoverage2.getExpirationDate());
        }
    }

}
