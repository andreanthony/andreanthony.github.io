package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ReadyForLpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ReadyForLP;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.InsurancePolicyBatchService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.MultiplePrimaryPoliciesService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.*;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterCycleDateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class InsurancePolicyBatchServiceImpl implements InsurancePolicyBatchService {

	@Autowired private ActivePolicyService activePolicyService;
	@Autowired private BusinessDayUtil businessDayUtil;
	@Autowired private CollateralCoverageComputationService collateralCoverageComputationService;
	@Autowired private ExpiringPolicyService expiringPolicyService;
	@Autowired private InsuranceMngtService insuranceMngtService;
	@Autowired private LetterCycleDateService letterCycleDateService;
	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;
	@Autowired private MultiplePrimaryPoliciesService multiplePrimaryPoliciesService;
	@Autowired private ReadyForLenderPlaceService readyForLenderPlaceService;
	@Autowired private NfipProgramService nfipProgramService;

	@Override
	@Transactional
	public Set<Long> processExpiringPolicies() {
		return processExpiringPolicies(null);
	}

	@Override
	@Transactional
	public Set<Long> processExpiringPolicies(Set<Long> collateralsProcessed) {
		if (collateralsProcessed == null) {
			collateralsProcessed = new HashSet<>();
		}

		Date today = businessDayUtil.getCurrentReferenceDateAtStartOfDay();
		Date nextBusinessDay = businessDayUtil.getNextBusinessDate(today);
		Date maxDate = letterCycleDateService.getMaxDateForLetterProcessing(today);
		List<ProofOfCoverage> expiringProofOfCoverageList = proofOfCoverageRepository.findAllProofOfCoverageExpiringOnOrBefore(maxDate);

		//Load all coverage ready for LP
		Map<ProofOfCoverage, List<ReadyForLP>> proofOfCoverageCollateralMap =
				buildProofOfCoverageCollateralMap(expiringProofOfCoverageList);
		// collecting all expired policies to check for multiple primary coverages
		Set<ProofOfCoverage> expiredPolicies = new HashSet<>();

		// 2 -  Initiate the LP action for qualifing proof of coverage
		for (Map.Entry<ProofOfCoverage, List<ReadyForLP>> entry : proofOfCoverageCollateralMap.entrySet()) {
			ProofOfCoverage proofOfCoverage = entry.getKey();
			if (shouldC3ActionBeAppliedForExpiration(proofOfCoverage, maxDate)) {
				boolean allReadyForLPProcessed = true;
				for (ReadyForLP readyForLP : entry.getValue()) {
					if (readyForLP.isReady()
							&& insuranceMngtService.hasLivingRequiredCoverageDocument(readyForLP.getCollateral().getRid(), readyForLP.getProofOfCoverage())) {
						applyC3ToQualifyingCollateral(collateralsProcessed, readyForLP.getCollateral(), proofOfCoverage);
						if (proofOfCoverage.getLpAction_() != LPActions.PENDING_C3) {
							readyForLP.setReady(ReadyForLpCode.LP_COMPLETED.getCode());
						}
					} else {
						allReadyForLPProcessed = false;
					}
				}

				if (allReadyForLPProcessed) {
					updatePolicyLPAction(nextBusinessDay, expiringProofOfCoverageList, expiredPolicies, proofOfCoverage);
				}
			}
		}

		// 3 - Update the status of all policy that had expired but don't have the FIAT (not LP ready)
        updateExpiringPoliciesStatus(expiringProofOfCoverageList, expiredPolicies);

        if(!expiringProofOfCoverageList.isEmpty()){
			proofOfCoverageRepository.save(expiringProofOfCoverageList);
		}

		multiplePrimaryPoliciesService.processMultiplePrimaryPolicies(expiredPolicies);

		return collateralsProcessed;
	}

    void updatePolicyLPAction(Date nextBusinessDay, List<ProofOfCoverage> expiringProofOfCoverageList, Set<ProofOfCoverage> expiredPolicies, ProofOfCoverage proofOfCoverage) {
        /**
         * if we applied c3 only because the policy was becoming effective, clear the flag
         */
        if (proofOfCoverage.getLpAction_() == LPActions.PENDING_C3) {
            proofOfCoverage.setLpAction(null);
        }
        else if (proofOfCoverage.getLpAction_() != LPActions.CANCEL_LP) {
            /**
            * we applied c3 because the the policy was expiring, no
            * more action is needed
            * NEW_LP, LP_GAP, NEW_BP, null
            */
            expiringProofOfCoverageList.remove(proofOfCoverage);
            proofOfCoverage.setLpAction(LPActions.NO_ACTION.name());
        }
        else {
            expiringProofOfCoverageList.remove(proofOfCoverage);
        }
        proofOfCoverage = proofOfCoverageRepository.saveAndFlush(proofOfCoverage);

        if (nextBusinessDay.after(proofOfCoverage.getExpirationDate()) &&
            	proofOfCoverage.getLpAction_() != LPActions.CANCEL_LP) {
            activePolicyService.setAllPolicyStatuses(proofOfCoverage, PolicyStatus.EXPIRED);
            expiredPolicies.add(proofOfCoverage);
        }
    }

    void updateExpiringPoliciesStatus(List<ProofOfCoverage> expiringProofOfCoverageList, Set<ProofOfCoverage> expiredPolicies) {
        for (ProofOfCoverage policy : expiringProofOfCoverageList) {
            if (expiringPolicyService.updateExpiringPolicyStatus(policy)) {
            	expiredPolicies.add(policy);
			}
        }
    }

	protected Map<ProofOfCoverage, List<ReadyForLP>> buildProofOfCoverageCollateralMap(List<ProofOfCoverage> expiringProofOfCoverageList) {
		List<ReadyForLP> readyForLpList = readyForLenderPlaceService.findReadyForLenderPlace();
		Map<ProofOfCoverage, List<ReadyForLP>> proofOfCoverageCollateralMap = new HashMap<>();

		//Initiating the hashmap which will be used to apply c3 to qualifying collateral
		for (ReadyForLP readyForLp : readyForLpList) {
			ProofOfCoverage proofOfCoverage = readyForLp.getProofOfCoverage();
			if (nfipProgramService.isPolicyExpirationWorkflowAllowed(proofOfCoverage.getPolicyType_())) {
				if (!proofOfCoverageCollateralMap.containsKey(proofOfCoverage)) {
					List<ReadyForLP> readyForLPList = new ArrayList<>();
					proofOfCoverageCollateralMap.put(proofOfCoverage, readyForLPList);
				}
				proofOfCoverageCollateralMap.get(proofOfCoverage).add(readyForLp);
				if (readyForLp.isRenewalStarted()) {
					expiringProofOfCoverageList.remove(proofOfCoverage);
				}
			} else {
				expiringProofOfCoverageList.remove(proofOfCoverage);
			}
		}
		return proofOfCoverageCollateralMap;
	}

	@Override
	@Transactional
	public Set<Long> processNewlyEffectivePolicies(Set<Long> collateralsProcessed) {
		if (collateralsProcessed == null) {
			collateralsProcessed = new HashSet<>();
		}
		//- 4 - load proof of coverages becoming effective today for which we haven't apply c 3 to them yet.
		//apply c3 to all the collateral affected by the POC getting effective for the first time today
		Date today = businessDayUtil.getCurrentReferenceDateAtStartOfDay();
        // this code will process ALL remaining PENDING_C3 policies and should be deleted in the next release
		List<ProofOfCoverage> pofPendingC3 =
				proofOfCoverageRepository.findAllProofOfCoverageBecomingEffective(365d);
		for (ProofOfCoverage policy : pofPendingC3) {
			if (shouldC3ActionBeAppliedForNewlyEffectivePolicy(policy, today)) {
				for (Collateral collateral : policy.getInsuredCollaterals()) {
					applyC3ToQualifyingCollateral(collateralsProcessed, collateral, policy);
					if (!policy.getPolicyStatus_().isExpiring()) {
						policy.setLpAction(LPActions.NO_ACTION.name());
						// unless the policy is expiring, there shouldnt be additional actions.
					} else {
						policy.setLpAction(null);
					}
				}
			}
		}
		return collateralsProcessed;
	}

    protected boolean shouldC3ActionBeAppliedForNewlyEffectivePolicy(ProofOfCoverage proofOfCoverage, Date maxDate) {
        /**
         * Don't apply C3 if there's an outstanding FIAT request
         */
        if(insuranceMngtService.hasOutstandingCoverageRequest(proofOfCoverage.getRid())) {
            return false;
        }
        /**
         * Apply C3 to collateral covered by of borrower proof of coverage becoming effective before the
         * next business day for which we haven't called c3 yet (LPActions.PENDING_C3)
         */
        if (proofOfCoverage.getLpAction_() == LPActions.PENDING_C3 &&
                proofOfCoverage.getPolicyType_().isBorrowerPolicy()) {
            return true;
        }
         // else the policy is not effective yet; wait before applying c3
        return false;
    }

    protected boolean shouldC3ActionBeAppliedForExpiration(ProofOfCoverage proofOfCoverage, Date maxDate) {
		/**
		 * Apply C3 to collateral covered by proof of coverage expiring today (or before the next business day)
		 * for which we haven't called c3 yet (LPActions.NO_ACTION => C3 was successfully applied)
		 */
		return proofOfCoverage.getLpAction_() != LPActions.NO_ACTION && !proofOfCoverage.getExpirationDate().after(maxDate);
	}

    void applyC3ToQualifyingCollateral(Set<Long> collateralsProcessed, Collateral collateral, ProofOfCoverage proofOfCoverage) {
 		Long triggerItemRid = null;
		WorkItem triggerItem = null;
		if (proofOfCoverage.getProofOfCovWorkItem() != null && !proofOfCoverage.getProofOfCovWorkItem().isEmpty()) {
			ProofOfCovWorkItem triggerWorkItemRel = proofOfCoverage.getProofOfCovWorkItem().get(0);
			triggerItem =triggerWorkItemRel.getWorkItem();
			triggerItemRid = triggerWorkItemRel.getWorkItem().getRid();
		}

		Long collateralRid = collateral.getRid();
		CoverageActionRequest coverageActionRequest = new CoverageActionRequest(collateralRid, triggerItemRid, null, proofOfCoverage);

		if (!collateralsProcessed.contains(collateralRid)) {
			CoverageActionResult coverageActionResult =
					collateralCoverageComputationService.evaluateInsuranceCoverageActions(coverageActionRequest);
			collateralCoverageComputationService.applyInsuranceCoverageActions(coverageActionResult, triggerItem);
			collateralsProcessed.add(collateralRid);
		}
	}
}
