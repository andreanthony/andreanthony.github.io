package com.jpmorgan.cib.wlt.ctrac.service.dto.view;

public class CollateralMainDetailsViewDto {

	private Long collateralRid;
	
	private String collateralTypeCode;

	private String collateralTypeDescription;
	
	private String collateralSubType;
	
	private String collateralSubTypeDescription;
	
	public String getCollateralSubTypeDescription() {
		return collateralSubTypeDescription;
	}

	public void setCollateralSubTypeDescription(String collateralSubTypeDescription) {
		this.collateralSubTypeDescription = collateralSubTypeDescription;
	}

	private String collateralStatus;
	
	private String collateralLegalDescription;
	
	private String collateralAddress;

	private String collateralCity;
	
	private String collateralState;
	
	private String collateralZipCode;
	
	private String collateralUnitBuilding;
	
	private String collateralEmailAddresses;

	public String getCollateralEmailAddresses() {
		return collateralEmailAddresses;
	}

	public void setCollateralEmailAddresses(String collateralEmailAddresses) {
		this.collateralEmailAddresses = collateralEmailAddresses;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getCollateralTypeCode() {
		return collateralTypeCode;
	}

	public void setCollateralTypeCode(String collateralTypeCode) {
		this.collateralTypeCode = collateralTypeCode;
	}

	public String getCollateralTypeDescription() {
		return collateralTypeDescription;
	}

	public void setCollateralTypeDescription(String collateralTypeDescription) {
		this.collateralTypeDescription = collateralTypeDescription;
	}

	public String getCollateralSubType() {
		return collateralSubType;
	}

	public void setCollateralSubType(String collateralSubType) {
		this.collateralSubType = collateralSubType;
	}

	public String getCollateralStatus() {
		return collateralStatus;
	}

	public void setCollateralStatus(String collateralStatus) {
		this.collateralStatus = collateralStatus;
	}

	public String getCollateralLegalDescription() {
		return collateralLegalDescription;
	}

	public void setCollateralLegalDescription(String collateralLegalDescription) {
		this.collateralLegalDescription = collateralLegalDescription;
	}

	public String getCollateralAddress() {
		return collateralAddress;
	}

	public void setCollateralAddress(String collateralAddress) {
		this.collateralAddress = collateralAddress;
	}

	public String getCollateralCity() {
		return collateralCity;
	}

	public void setCollateralCity(String collateralCity) {
		this.collateralCity = collateralCity;
	}

	public String getCollateralState() {
		return collateralState;
	}

	public void setCollateralState(String collateralState) {
		this.collateralState = collateralState;
	}

	public String getCollateralZipCode() {
		return collateralZipCode;
	}

	public void setCollateralZipCode(String collateralZipCode) {
		this.collateralZipCode = collateralZipCode;
	}

	public String getCollateralUnitBuilding() {
		return collateralUnitBuilding;
	}

	public void setCollateralUnitBuilding(String collateralUnitBuilding) {
		this.collateralUnitBuilding = collateralUnitBuilding;
	}
	
	public String getCityStateZipCodeUnit(){
		StringBuffer cityStateZip=new StringBuffer();
		cityStateZip.append(collateralCity);
		cityStateZip.append(", ");
		cityStateZip.append(collateralState);
		cityStateZip.append(", ");
		cityStateZip.append(collateralZipCode);
		cityStateZip.append(", ");
		cityStateZip.append(collateralUnitBuilding);
		return cityStateZip.toString();
	}
	public String getCityStateZipCode(){
		StringBuffer cityStateZip=new StringBuffer();
		cityStateZip.append(collateralCity);
		cityStateZip.append(", ");
		cityStateZip.append(collateralState);
		cityStateZip.append(", ");
		cityStateZip.append(collateralZipCode);
		return cityStateZip.toString();
	}
	public String getPropertyAddressUnitBuilding(){
		StringBuffer propAddrUnit=new StringBuffer();
		propAddrUnit.append(collateralAddress);
		propAddrUnit.append(", ");
		propAddrUnit.append(collateralUnitBuilding);
		return propAddrUnit.toString();
	}
	
}
