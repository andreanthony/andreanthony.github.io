package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.INSURANCE_REQ_XLXS_HEADER;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.POLICY_INSURANCE_LP_FILENAME;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.POLICY_INSURANCE_LP_FILESHEET;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.batch.ExcelFileUtil;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ExcelTable;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;
import com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.AlthansExcelDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.AlthansLPRequestRow;

@Component
public class LPInsuranceRequestUtil extends ExcelFileUtil {
	
	private static final Logger logger = Logger.getLogger(LPInsuranceRequestUtil.class);

    private static final String PASS_WORD = "password";
	
	/**
	 * Prepares the LP Insurace Request xlsx file need to be sent to Assurance to initiate
	 * Lender Place
	 * @param lpPolicyRequestList
	 * @return file - created LP Insurance Request xlsx file.
	 */
	public File prepareInsuranceRequestFile(List<LPPolicyRequest> lpPolicyRequestList) {		
			logger.debug("BEGIN::prepareInsuranceRequestFile()");
			if(lpPolicyRequestList != null){
				FileOutputStream fos = null;
				try{
					File insuranceReqFile = new File(env.getRequiredProperty(POLICY_INSURANCE_LP_FILENAME));
		    		fos = new FileOutputStream(insuranceReqFile);
		    		XSSFWorkbook lpWorkbook = new XSSFWorkbook();
		       		Sheet sheet = lpWorkbook.createSheet(env.getRequiredProperty(POLICY_INSURANCE_LP_FILESHEET));	
		       		sheet.setDefaultColumnWidth(40);
		       		//create date format style 
			       	CreationHelper createHelper = lpWorkbook.getCreationHelper();
			        CellStyle dateCellStyle = lpWorkbook.createCellStyle();
			        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-mmm-yy"));
			        CellStyle amtCellStyle = getAmountCellStyle(lpWorkbook);
		       		Row row;
		       		Cell cell;
		       		int rowIndex = 1; 
		       		createInsuranceReqFileHeader(sheet,lpWorkbook,INSURANCE_REQ_XLXS_HEADER);
					for(LPPolicyRequest lpPolicyRequest : lpPolicyRequestList){
						row = sheet.createRow(rowIndex++);
						cell = row.createCell(0);
						if(lpPolicyRequest.getReportDate() != null){
							 cell.setCellValue(lpPolicyRequest.getReportDate());
							 cell.setCellStyle(dateCellStyle);
						}		    	       
		    	        cell = row.createCell(1);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getRequestorName()));
		    	        cell = row.createCell(2);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getRequestorEmailAddress()));
		    	        cell = row.createCell(3);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getLenderBranchCode()));
		    	        cell = row.createCell(4);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getLoanNumber()));
		    	        cell = row.createCell(5);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getTransCode()));
		    	        cell = row.createCell(6);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getStatusId()));
		    	        cell = row.createCell(7);		    	        		    	       
		    	        if(lpPolicyRequest.getEffectiveDate() != null){		    	        	
		    	        	 cell.setCellValue(lpPolicyRequest.getEffectiveDate());
		    	        	 cell.setCellStyle(dateCellStyle);
		    	        }		    	       
		    	        cell = row.createCell(8);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getMortgagorAndBorrowerName()));
		    	        cell = row.createCell(9);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getMailingAddress()));
		    	        cell = row.createCell(10);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getPropertyAddress()));
		    	        cell = row.createCell(11);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getPropertyType()));
		    	        cell = row.createCell(12);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getBuildingContentsCoverage()));
		    	        cell = row.createCell(13);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getSpecialProcessing()));
		    	        cell = row.createCell(14);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getCoverageType()));
		    	        cell = row.createCell(15);
		    	        cell.setCellValue(isValidAmountString(lpPolicyRequest.getBuildingCoverageAmount()));
		    	        cell.setCellStyle(amtCellStyle);
		    	        cell = row.createCell(16);
		    	        cell.setCellValue(isValidAmountString(lpPolicyRequest.getContentsCoverageAmount()));
		    	        cell.setCellStyle(amtCellStyle);
		    	        cell = row.createCell(17);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getFloodZone()));
		    	        cell = row.createCell(18);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getComments()));
		    	        cell = row.createCell(19);
		    	        cell.setCellValue(isValidString(lpPolicyRequest.getStatusId()));
					}		
					setAutoSizeColumn(lpWorkbook,sheet);
					lpWorkbook.write(fos);					
					logger.debug("LP Insurance Request xlsx file created successfully.");
					return insuranceReqFile;
				}catch(Exception ex){
					logger.error(ex.getMessage(), ex);
					logger.error("Error while creating LP Insurance Request xlsx file.");
					throw new CTracApplicationException("E0170", CtracErrorSeverity.APPLICATION);
				} finally {
					if (fos != null) {
						try {
							fos.close();
						} catch (IOException e) {
							logger.error(e.getMessage());
						}
					}
				}
				
			}else {
				logger.debug("policyrequiescoverage is null ,no insurance policy need to be sent to assurant.");
			}
			logger.debug("END::prepareInsuranceRequestFile()");
			return null;
		}	
	
	/**
	 * Prepares the LP Insurace Request xlsx file need to be sent to Assurance to initiate
	 * Lender Place
	 * @param fileName 
	 * @param lpPolicyRequestList
	 * @param currentDate 
	 * @return file - created LP Insurance Request xlsx file.
	 */
	public File prepareInsuranceRequestFileAlthans(String fileName, List<LPPolicyRequest> lpPolicyRequestList, Date currentDate) {		
		logger.debug("BEGIN::prepareInsuranceRequestFile()");
		if (lpPolicyRequestList != null) {
            FileOutputStream fos = null;
            XSSFWorkbook lpWorkbook = null;
            try {
				File insuranceReqFile = new File(fileName);
				fos = new FileOutputStream(insuranceReqFile);
				logger.debug("Althans request file absolute path: " + insuranceReqFile.getAbsolutePath());
				lpWorkbook = new XSSFWorkbook();
				XSSFSheet sheet = lpWorkbook.createSheet(env.getRequiredProperty(POLICY_INSURANCE_LP_FILESHEET));
				sheet.protectSheet(PASS_WORD);
				sheet.lockFormatColumns(false);
				sheet.lockFormatRows(false);
				sheet.lockSort(false);
				sheet.lockSelectLockedCells(false);
				sheet.lockSelectUnlockedCells(false);
				
				setDefaultUnlock(sheet, AlthansExcelDefinition.ALTHANS_EXCEL_DEFINITION.length);
				
				List<AlthansLPRequestRow> althansLPRequestRows = ctracObjectMapper.mapAsList(lpPolicyRequestList, AlthansLPRequestRow.class);
				CellStyle dateCellStyle = getDateCellStyle(lpWorkbook);
				CellStyle amountCellStyle = getAmountCellStyle(lpWorkbook);
				CellStyle stringCellStyle = getStringCellStyle(lpWorkbook);
				CellStyle autoWrapCellStyle = getAutoWrapCellStyle(lpWorkbook);
				CellStyle lockedCellStyle = getLockedCellStyle(lpWorkbook);
				XSSFCellStyle headerCellStyle = createTableHeaader(lpWorkbook);
				
				// Insert submission date and record count
				int index = CreateDateCountTable(currentDate, lpWorkbook, sheet, althansLPRequestRows.size());
				/*// Sort by Loan Number, Property Street Address, Policy RID*/
				Collections.sort(althansLPRequestRows);
			
				// Insert headers and rows
				ExcelTable excelTable = new ExcelTable(AlthansExcelDefinition.ALTHANS_EXCEL_DEFINITION, althansLPRequestRows)
						.headerStyle(headerCellStyle)
						.customStyle(FieldType.DATE, dateCellStyle)
						.customStyle(FieldType.AMOUNT, amountCellStyle)
						.customStyle(FieldType.STRING, stringCellStyle)
						.customStyle(FieldType.LOCK, lockedCellStyle)
						.customStyle(FieldType.AUTOWRAP, autoWrapCellStyle);
				excelTable.insertInto(sheet, index++, 0);
				
				adjustColumn(sheet, AlthansExcelDefinition.ALTHANS_EXCEL_DEFINITION.length, AlthansExcelDefinition.COLUMNS_NOT_AUTO_SIZE);
				lpWorkbook.write(fos);
				logger.debug("LP Insurance Request xlsx file created successfully.");
				return insuranceReqFile;
			} catch (Exception ex) {
				logger.error(ex.getMessage(), ex);
				logger.error("Error while creating LP Insurance Request xlsx file.");
				throw new CTracApplicationException("E0170", CtracErrorSeverity.APPLICATION);
			} finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException e) {
                        logger.error(e.getMessage());
                    }
                }
                if (lpWorkbook != null) {
                    try {
                        lpWorkbook.close();
                    } catch (IOException e) {
                        logger.error(e.getMessage());
                    }
                }
            }

		} else {
			logger.debug("policyrequiescoverage is null ,no insurance policy need to be sent to assurant.");
		}
		logger.debug("END::prepareInsuranceRequestFile()");
		return null;
	}


    private int CreateDateCountTable(Date currentDate, XSSFWorkbook lpWorkbook, Sheet sheet, int size) {
		int index = 0;
		index++;
		
		XSSFFont font = lpWorkbook.createFont();
		font.setFontName("Arial");
		font.setFontHeight(11);
		font.setBold(true);
		
		CellStyle cell1Style = getHeaderCellStyle(lpWorkbook);
		cell1Style.setBorderTop(BorderStyle.MEDIUM);
		cell1Style.setFont(font);
		CellStyle cell2Style = getHeaderCellStyle(lpWorkbook);
		cell2Style.setBorderRight(BorderStyle.MEDIUM);
		cell2Style.setBorderTop(BorderStyle.MEDIUM);
		CreationHelper createHelper = lpWorkbook.getCreationHelper();
		cell2Style.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
		cell2Style.setAlignment(HorizontalAlignment.RIGHT);
		cell2Style.setFont(font);
		
		Row row = sheet.createRow(index++);
		Cell cell1 = row.createCell(0);
		cell1.setCellStyle(cell1Style);
		cell1.setCellValue("Submission Date");
		Cell cell2 = row.createCell(1);
		cell2.setCellStyle(cell2Style);
		cell2.setCellValue(DateFormatter.toString(currentDate));
		
		CellStyle cell21Style = getHeaderCellStyle(lpWorkbook);
		cell21Style.setBorderBottom(BorderStyle.MEDIUM);
		CellStyle cell22Style = getHeaderCellStyle(lpWorkbook);
		cell21Style.setFont(font);
		cell22Style.setBorderRight(BorderStyle.MEDIUM);
		cell22Style.setBorderBottom(BorderStyle.MEDIUM);
		cell22Style.setFont(font);
		
 		row = sheet.createRow(index++);
		cell1 = row.createCell(0);
		cell1.setCellStyle(cell21Style);
		cell1.setCellValue("Record Count");
		cell2 = row.createCell(1);
		cell2.setCellStyle(cell22Style);
		cell2.setCellValue(size);
		
		//blank row between the date table and the content
		index++;
		return index;
	}


    /**
	 * Creates the HEADER row for insurance request xlsx file,this file will
     * be sent to Assurant as an attachment with LP insurance request details
	 * @param sheet
	 * @param workbook
	 * @param headerValues
	 */
	private void createInsuranceReqFileHeader(Sheet sheet, Workbook workbook, String[] headerValues) {
		logger.debug("createInsuranceReqFileHeader::START");
		XSSFFont font = (XSSFFont)workbook.createFont();
		font.setBold(true);
		XSSFCellStyle style = (XSSFCellStyle)workbook.createCellStyle();
		style.setFont(font);
		//create the xlsx file HEADER row
		Row row = sheet.createRow(0);
		for(int i=0;i<headerValues.length;i++){
			Cell cell = row.createCell(i);
	        cell.setCellValue(headerValues[i]);
	        cell.setCellStyle(style);
		}
		logger.debug("createInsuranceReqFileHeader::END");
	}
	
}
