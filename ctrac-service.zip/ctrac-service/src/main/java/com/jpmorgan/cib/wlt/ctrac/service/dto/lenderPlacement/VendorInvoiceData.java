package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.AWAITING_REFUND_CONFIRMATION;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.AWAITING_VENDOR_REFUND_NOTICE;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.COLLECT_REFUND_CONFIRMATION;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.COLLECT_VENDOR_REFUND_NOTICE;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.PaymentMethodDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.CollateralMainDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.CollateralOwnerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.PrimaryLoanBorrowerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProofOfCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProvidedCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;

public class VendorInvoiceData extends LenderPlaceData {

    private static final long serialVersionUID = 4531613378112625010L;

    // Mapped from LenderPlaceItem
    private String firstLetterDate;
    private String secondLetterDate;
    private String premiumAmount = CtracAppConstants.DEFAULT_AMOUNT;
    
    // paymentMethod mapped from LenderPlaceItem and LenderPlaceCancellationItem
    private PaymentMethodDTO paymentMethod;
    private String billingDate;

    
    private String clwRefNumber;
    private String refundCompletionDate;
    private String refundAmount;

    // Used for Thymeleaf logic
    private List<LookUpCode> vendorPaymentMethods;
    private List<LookUpCode> stateCodes;
    private Boolean cancellation;
    private String firstLetterDatePlus1;
    private String branchCode;
    private String costCenterNumber;
    
    private Boolean isPolicyCancelled = Boolean.FALSE;
    
    public Boolean getIsPolicyCancelled() {
		return isPolicyCancelled;
	}
	public void setIsPolicyCancelled(Boolean isPolicyCancelled) {
		this.isPolicyCancelled = isPolicyCancelled;
	}
	
	private List<CollateralDoc> vendorCertificates;
    
    private CollateralDoc vendorCertificate;
    
    private boolean renewal;
    
    public boolean isRenewal() {
		return renewal;
	}
	public void setRenewal(boolean renewal) {
		this.renewal = renewal;
	}
	private String lpCoverageType;
  	private PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto;
    
    private CollateralMainDetailsViewDto collateralMainDetailsViewDto;
    
    private CollateralOwnerViewDto collateralOwnerViewDto;
    
    private ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto;
    
    private ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto;
    
    private RequiredCoverageViewDto requiredCoverageViewDto;
    
    public PrimaryLoanBorrowerViewDto getPrimaryLoanBorrowerViewDto() {
  		return primaryLoanBorrowerViewDto;
  	}
  	public void setPrimaryLoanBorrowerViewDto(PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto) {
  		this.primaryLoanBorrowerViewDto = primaryLoanBorrowerViewDto;
  	}

    public String getFirstLetterDate() {
        return firstLetterDate;
    }

    public void setFirstLetterDate(String firstLetterDate) {
        this.firstLetterDate = firstLetterDate;
    }
    
    public String getSecondLetterDate() {
        return secondLetterDate;
    }

    public void setSecondLetterDate(String secondLetterDate) {
        this.secondLetterDate = secondLetterDate;
    }

    public String getPremiumAmount() {
        return premiumAmount;
    }

    public void setPremiumAmount(String premiumAmount) {
        this.premiumAmount = premiumAmount;
    }
    
    public PaymentMethodDTO getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethodDTO paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

    public String getBillingDate() {
        return billingDate;
    }

    public void setBillingDate(String billingDate) {
        this.billingDate = billingDate;
    }

    public String getClwRefNumber() {
        return clwRefNumber;
    }

    public void setClwRefNumber(String clwRefNumber) {
        this.clwRefNumber = clwRefNumber;
    }

    public String getRefundCompletionDate() {
        return refundCompletionDate;
    }

    public void setRefundCompletionDate(String refundCompletionDate) {
        this.refundCompletionDate = refundCompletionDate;
    }
    
    

    public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public List<LookUpCode> getVendorPaymentMethods() {
        return vendorPaymentMethods;
    }

    public void setVendorPaymentMethods(List<LookUpCode> vendorPaymentMethods) {
        this.vendorPaymentMethods = vendorPaymentMethods;
    }

    public List<LookUpCode> getStateCodes() {
        return stateCodes;
    }

    public void setStateCodes(List<LookUpCode> stateCodes) {
        this.stateCodes = stateCodes;
    }

    public Boolean isCancellation() {
        cancellation = (isAwaitingVendorRefund() || isCollectVendorRefund());    
        return cancellation;
    }
    
    public boolean isAwaitingVendorRefund() {
        return (AWAITING_VENDOR_REFUND_NOTICE.getName().equals(getCurrentWorkFlowStep()) ||
                COLLECT_VENDOR_REFUND_NOTICE.getName().equals(getCurrentWorkFlowStep()));
    }
    
    public boolean isCollectVendorRefund() {
        return (AWAITING_REFUND_CONFIRMATION.getName().equals(getCurrentWorkFlowStep()) ||
                COLLECT_REFUND_CONFIRMATION.getName().equals(getCurrentWorkFlowStep()));
    }
    
    public String getFirstLetterDatePlus1() {
        if (firstLetterDatePlus1 != null) {
            return firstLetterDatePlus1;
        }
        if (firstLetterDate != null) {
            Date toConvert = DateConverter.convert(firstLetterDate);
            Calendar cal = Calendar.getInstance();
            cal.setTime(toConvert);
            cal.add(Calendar.DATE, 1);
            firstLetterDatePlus1 = DateConverter.convert(toConvert);
        }
        return firstLetterDatePlus1;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }
    
    
	public String getCostCenterNumber() {
		return costCenterNumber;
	}

	public void setCostCenterNumber(String costCenterNumber) {
		this.costCenterNumber = costCenterNumber;
	}

	public CollateralMainDetailsViewDto getCollateralMainDetailsViewDto() {
		return collateralMainDetailsViewDto;
	}

	public void setCollateralMainDetailsViewDto(
			CollateralMainDetailsViewDto collateralMainDetailsViewDto) {
		this.collateralMainDetailsViewDto = collateralMainDetailsViewDto;
	}

	public CollateralOwnerViewDto getCollateralOwnerViewDto() {
		return collateralOwnerViewDto;
	}

	public void setCollateralOwnerViewDto(
			CollateralOwnerViewDto collateralOwnerViewDto) {
		this.collateralOwnerViewDto = collateralOwnerViewDto;
	}

	public ProofOfCoverageDetailsViewDto getProofOfCoverageDetailsViewDto() {
		return proofOfCoverageDetailsViewDto;
	}

	public void setProofOfCoverageDetailsViewDto(
			ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto) {
		this.proofOfCoverageDetailsViewDto = proofOfCoverageDetailsViewDto;
	}

	public ProvidedCoverageDetailsViewDto getProvidedCoverageDetailsViewDto() {
		return providedCoverageDetailsViewDto;
	}

	public void setProvidedCoverageDetailsViewDto(
			ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto) {
		this.providedCoverageDetailsViewDto = providedCoverageDetailsViewDto;
	}
	public RequiredCoverageViewDto getRequiredCoverageViewDto() {
		return requiredCoverageViewDto;
	}
	public void setRequiredCoverageViewDto(
			RequiredCoverageViewDto requiredCoverageViewDto) {
		this.requiredCoverageViewDto = requiredCoverageViewDto;
	}
	public String getLpCoverageType() {
		return lpCoverageType;
	}
	public void setLpCoverageType(String lpCoverageType) {
		this.lpCoverageType = lpCoverageType;
	}
	public List<CollateralDoc> getVendorCertificates() {
		return vendorCertificates;
	}
	public void setVendorCertificates(List<CollateralDoc> vendorCertificates) {
		this.vendorCertificates = vendorCertificates;
	}
	public CollateralDoc getVendorCertificate() {
		return vendorCertificate;
	}
	public void setVendorCertificate(CollateralDoc vendorCertificate) {
		this.vendorCertificate = vendorCertificate;
	}	
        
}
