package com.jpmorgan.cib.wlt.ctrac.service.bir.impl;

import java.util.*;
import java.util.Map.Entry;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.AddressDataService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.request.BIProofOfCoveragePublishEventRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRCollateralDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRInsurableAssetDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BorrowerInsuranceReviewDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Address;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.DeterminationDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.bir.BIRCollateralDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.bir.BIRInsurableAssetDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.bir.BorrowerInsuranceReviewDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AddressRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRMode;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRInsurableAssetDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.FloodInsuranceDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;

@Service
@Transactional(readOnly=true)
public class BIRManagementServiceImpl implements BIRManagementService {

	private static final Logger logger = Logger.getLogger(BIRManagementServiceImpl.class);
	
	@Autowired private AddressRepository addressRepository;

	@Autowired AddressDataService addressDataService;
	
	@Autowired private BIRCollateralDetailsRepository birCollateralDetailsRepository;
	
	@Autowired private BIRInsurableAssetDetailsRepository birInsurableAssetDetailsRepository;
	
	@Autowired private BorrowerInsuranceReviewDetailsRepository borrowerInsuranceReviewDetailsRepository;
	
	@Autowired private CollateralInsuranceRepository collateralInsuranceRepository;
	
	@Autowired private CollateralManagementService collateralManagementService;
	
	@Autowired private CollateralRepository collateralRepository;
	
	@Autowired private CtracObjectMapper ctracObjectMapper;
	
	@Autowired private InsuranceMngtService insuranceMngtService;
	
	@Autowired private LoanManagementService loanManagementService;
	
	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;
	
	@Autowired private ViewDataRetrievalService viewDataRetrievalService;
	
	@Autowired private DateCalculator dateCalculator;

	@Autowired private PublishEventService publishEventService;
	
	
	@Override
	public BorrowerInsuranceReviewDTO getBorrowerInsuranceReviewData(Long proofOfCoverageRid, Long launchedCollateralRid) {
		BorrowerInsuranceReviewDetails borrowerInsuranceReviewDetails =
				borrowerInsuranceReviewDetailsRepository.findByProofOfCoverageRid(proofOfCoverageRid);
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = null;
		if (borrowerInsuranceReviewDetails == null) {
			// Existing policy prior to BIR implementation
			borrowerInsuranceReviewData = prepareNewBIRWithCollateralRid(null);
			borrowerInsuranceReviewData.setProofOfCoverageData(toGenericProofOfCoverageData(
					insuranceMngtService.getProofOfCoverageData(proofOfCoverageRid, launchedCollateralRid)));
			addAllCollateralDetails(proofOfCoverageRid, borrowerInsuranceReviewData);
		} else {
			borrowerInsuranceReviewData =
					ctracObjectMapper.map(borrowerInsuranceReviewDetails, BorrowerInsuranceReviewDTO.class);
			borrowerInsuranceReviewData.setProofOfCoverageData(toGenericProofOfCoverageData(
					insuranceMngtService.getProofOfCoverageData(proofOfCoverageRid, launchedCollateralRid)));
			List<BIRCollateralDetails> allBIRCollateralDetails =
					borrowerInsuranceReviewDetails.getAllBIRCollateralDetails();
			for (BIRCollateralDetails birCollateralDetails : allBIRCollateralDetails) {
				Long thisCollateralRid = birCollateralDetails.getCollateralRid();
				if (!collateralRepository.exists(thisCollateralRid)) {
					continue;
				}
				
				BIRCollateralDetailsDTO birCollateralDetailsDTO =
						ctracObjectMapper.map(birCollateralDetails, BIRCollateralDetailsDTO.class);
				birCollateralDetailsDTO.setReasonForVerification(borrowerInsuranceReviewData.getProofOfCoverageData().getReasonForVerification());
				
				List<BIRInsurableAssetDetails> allBIRInsurableAssetDetails =
						birCollateralDetails.getAllBIRInsurableAssetDetails();
				for (BIRInsurableAssetDetails birInsurableAssetDetails : allBIRInsurableAssetDetails) {
					BIRInsurableAssetDetailsDTO birInsurableAssetDetailsDTO =
							ctracObjectMapper.map(birInsurableAssetDetails, BIRInsurableAssetDetailsDTO.class);
					birCollateralDetailsDTO.getInsurableAssetDetailsMap().put(
							birInsurableAssetDetails.getInsurableAssetSortOrder(), birInsurableAssetDetailsDTO);
				}

				borrowerInsuranceReviewData.getProofOfCoverageData().getProvidedCoverageMap().addCollateral(thisCollateralRid);
				fillCollateralDetails(thisCollateralRid, birCollateralDetailsDTO);
				borrowerInsuranceReviewData.getCollateralDetailsMap().put(thisCollateralRid, birCollateralDetailsDTO);	
			}
		}
		return borrowerInsuranceReviewData;
	}
	
	private void addAllCollateralDetails(Long proofOfCoverageRid, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		List<CollateralInsuranceViewData> collateralInsuranceViewData =
				collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverageRid);
		for (CollateralInsuranceViewData collateralInsuranceViewDatum : collateralInsuranceViewData) {
			addCollateralDetails(collateralInsuranceViewDatum.getCollateral().getRid(), borrowerInsuranceReviewData);
		}
	}
	
	@Override
	public BorrowerInsuranceReviewDTO prepareNewBIRWithCollateralRid(Long collateralRid) {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = new BorrowerInsuranceReviewDTO();
		GenericProofOfCoverageDTO proofOfCoverageData =
				insuranceMngtService.createGenericInsuranceForCollateral(collateralRid);
		proofOfCoverageData.setInsuranceType(InsuranceType.FLOOD);
		borrowerInsuranceReviewData.setProofOfCoverageData(proofOfCoverageData);
		addCollateralDetails(collateralRid, borrowerInsuranceReviewData);
		return borrowerInsuranceReviewData;
	}
	
	@Override
	public boolean isAllCollateralsVerified(Long borrowerInsuranceReviewDetailsRid, Long currentCollateral) {
		if (borrowerInsuranceReviewDetailsRid == null) {
			return false;
		}
		List<BIRCollateralDetails> birCollateralDetails =
				birCollateralDetailsRepository.findByBorrowerInsuranceReviewDetailsRid(borrowerInsuranceReviewDetailsRid);
		for (BIRCollateralDetails collateralDetails : birCollateralDetails) {
			if (PolicyStatus.PENDING_VERIFICATION.name().equals(collateralDetails.getPolicyStatus()) && !currentCollateral.equals(collateralDetails.getCollateralRid())) {
				return false;
			}
		}
		return true;
	}
	
	private ProofOfCoverageDTO toAbstractProofOfCoverageData(GenericProofOfCoverageDTO genericProofOfCoverageData) {
		ProofOfCoverageDTO proofOfCoverageData = null;
		if (genericProofOfCoverageData.getInsuranceType() == InsuranceType.FLOOD) {
			proofOfCoverageData = ctracObjectMapper.map(genericProofOfCoverageData, FloodInsuranceDTO.class);
		} else if (genericProofOfCoverageData.getInsuranceType() == InsuranceType.HAZARD) {
			// TODO: proofOfCoverageData = ctracObjectMapper.map(genericProofOfCoverageData, HazardInsuranceDTO.class);
		}
		mapUnmappableObjects(genericProofOfCoverageData, proofOfCoverageData);
		return proofOfCoverageData;
	}
	
	private GenericProofOfCoverageDTO toGenericProofOfCoverageData(ProofOfCoverageDTO proofOfCoverageData) {
		GenericProofOfCoverageDTO genericProofOfCoverageData =
				ctracObjectMapper.map(proofOfCoverageData, GenericProofOfCoverageDTO.class);
		mapUnmappableObjects(proofOfCoverageData, genericProofOfCoverageData);
		return genericProofOfCoverageData;
	}
	
	private void mapUnmappableObjects(ProofOfCoverageDTO source, ProofOfCoverageDTO destination) {
		if (source == null || destination == null) {
			return;
		}
		destination.setProvidedCoverageDTOs(source.getProvidedCoverageDTOs());
		destination.setProvidedCoverageMap(source.getProvidedCoverageMap());
	}
	
	@Override
	public void addCollateralDetails(Long collateralId, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		if (collateralId == null) {
			return;
		}
		BIRCollateralDetailsDTO birCollateralDetails = new BIRCollateralDetailsDTO();
		birCollateralDetails.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
		fillCollateralDetails(collateralId, birCollateralDetails);
		if (StringUtils.isBlank(birCollateralDetails.getPolicyFloodZone()) && borrowerInsuranceReviewData.getProofOfCoverageData() != null) {
			birCollateralDetails.setPolicyFloodZone(borrowerInsuranceReviewData.getProofOfCoverageData().getFloodZone());
		}
		borrowerInsuranceReviewData.getCollateralDetailsMap().put(collateralId, birCollateralDetails);
		borrowerInsuranceReviewData.getProofOfCoverageData().getProvidedCoverageMap().addCollateral(collateralId);
	}

	private void fillCollateralDetails(Long collateralId, BIRCollateralDetailsDTO birCollateralDetails) {
		CollateralDto collateralDTO = collateralManagementService.getCollateralDto(collateralId);
		if (collateralDTO == null) {
			throw new RuntimeException("Collateral not found for collateralRid=" + collateralId);
		}
		birCollateralDetails.setCollateralRid(collateralId);
		birCollateralDetails.setCollateralDescription(collateralDTO.getCollateralDescription());
		
		// LCP 3139
		//birCollateralDetails.setBorrowerName(collateralDTO.getPrimaryLoan().getPrimaryBorrower().getBorrowerName());
		birCollateralDetails.setBorrowerName(collateralDTO.getPipeSeparatedPrimaryLoanBorrowerNames());
		
		birCollateralDetails.setOwnerName(collateralDTO.getCommaSeparatedCollateralOwners());
		birCollateralDetails.setCollateralAddressData(collateralDTO.getAddress());
		// TODO Tanaya: pull the verified SFHDF flood zone
		// If none are verified, pull the one that's Pending Verification
		// If there's none at all, leave blank
		birCollateralDetails.setCollateralFloodZone(getCollateralFloodZone(collateralId));
	}
	
	private String getCollateralFloodZone(Long collateralId){
		String floodZone=null;
		List<DeterminationDetailsViewData> determinationDetails=null;
		if(collateralId!=null){
			determinationDetails=viewDataRetrievalService.findDeterminationsByCollateralRidAndStatus(collateralId, VerificationStatus.VERIFIED.getName());
			if(determinationDetails!=null && !determinationDetails.isEmpty()){
				 floodZone=determinationDetails.get(0).getFloodZone();
			}else{
				determinationDetails=viewDataRetrievalService.findDeterminationsByCollateralRidAndStatus(collateralId, VerificationStatus.PENDING_VERIFICATION.getName());
				if(determinationDetails!=null && !determinationDetails.isEmpty()){
					 floodZone=determinationDetails.get(0).getFloodZone();
				}else{
					floodZone="";
				}
			}
		}
		return floodZone;
	}

	@Override
	@Transactional(readOnly=false)
	public void saveBorrowerInsuranceReview(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		GenericProofOfCoverageDTO genericProofOfCoverageData = borrowerInsuranceReviewData.getProofOfCoverageData();
		if (genericProofOfCoverageData == null) {
			// TODO: throw exception
			return;
		}

		ProofOfCoverageDTO proofOfCoverageData = toAbstractProofOfCoverageData(genericProofOfCoverageData);
		if (proofOfCoverageData == null) {
			// TODO: throw exception
			return;
		}
		boolean editChangeDuringVerification = false;
		if(BIRMode.VERIFY == borrowerInsuranceReviewData.getBirMode()) {
			setLPAction(proofOfCoverageData);
			editChangeDuringVerification = genericProofOfCoverageData.hasChanged();
		}
		proofOfCoverageData = insuranceMngtService.saveProofOfCoverage(proofOfCoverageData);
		genericProofOfCoverageData = toGenericProofOfCoverageData(proofOfCoverageData);
		borrowerInsuranceReviewData.setProofOfCoverageData(genericProofOfCoverageData);
		
		BorrowerInsuranceReviewDetails borrowerInsuranceReviewDetails = new BorrowerInsuranceReviewDetails();
		if (borrowerInsuranceReviewData.getRid() != null) {
			borrowerInsuranceReviewDetails = borrowerInsuranceReviewDetailsRepository.findOne(borrowerInsuranceReviewData.getRid());
		}
		
		if (proofOfCoverageData != null && borrowerInsuranceReviewData.getProofOfCoverageData() != null) {
			ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(proofOfCoverageData.getRid());
			borrowerInsuranceReviewDetails.setProofOfCoverage(proofOfCoverage);
		}

		ctracObjectMapper.map(borrowerInsuranceReviewData, borrowerInsuranceReviewDetails);
		borrowerInsuranceReviewDetails = borrowerInsuranceReviewDetailsRepository.saveAndFlush(borrowerInsuranceReviewDetails);
		borrowerInsuranceReviewData.setRid(borrowerInsuranceReviewDetails.getRid());
		borrowerInsuranceReviewData.refreshAuditUpdate(borrowerInsuranceReviewDetails);
		//Publish the BIR event
		performBIProofOfCoveragePublishEvent(borrowerInsuranceReviewData,null, editChangeDuringVerification);

		if (borrowerInsuranceReviewData.getCollateralDetailsMap() != null) {
			saveCollateralDetailsMap(borrowerInsuranceReviewData, borrowerInsuranceReviewDetails);
		}
		
		birInsurableAssetDetailsRepository.flush();
		birCollateralDetailsRepository.flush();
		borrowerInsuranceReviewDetailsRepository.flush();
	}

	@Transactional
	public void performBIProofOfCoveragePublishEvent(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, CollateralEventType overrideCollateralEventType,
													 boolean proofOfCoverageChangeDuringVerification){
		Map<Long,BIRCollateralDetailsDTO> collateralListOnPolicy = borrowerInsuranceReviewData.getCollateralDetailsMap();
		//When verify BIR event is happening, only publish event for the current collateral only
		boolean changeDuringVerifyForBIR = proofOfCoverageChangeDuringVerification ||
				(BIRMode.VERIFY.compareTo(borrowerInsuranceReviewData.getBirMode()) == 0 ? borrowerInsuranceReviewData.hasChanged(): false);
		Set<Long> collateralRids = BIRMode.VERIFY.compareTo(borrowerInsuranceReviewData.getBirMode()) == 0 ?
				Collections.singleton(borrowerInsuranceReviewData.getCollateralRid()): collateralListOnPolicy.keySet();
		for(Long collateralRid : collateralRids){
			CollateralDto collateralDto = collateralManagementService.getCollateralDto(collateralRid);
			if(collateralDto != null) {
							if(changeDuringVerifyForBIR){
					publishEventService.publishBIProofOfCoverageEvent(new BIProofOfCoveragePublishEventRequest(
							borrowerInsuranceReviewData, collateralDto.getPrimaryLoan(), collateralDto.getRid()).forCollateralEventType(CollateralEventType.EDITED));
				}
				publishEventService.publishBIProofOfCoverageEvent(new BIProofOfCoveragePublishEventRequest(
						borrowerInsuranceReviewData, collateralDto.getPrimaryLoan(), collateralDto.getRid()).forCollateralEventType(overrideCollateralEventType));
			}
		}
	}

	private void setLPAction(ProofOfCoverageDTO proofOfCoverageData) {
		if(proofOfCoverageData.hasCancellationDate()) {
			proofOfCoverageData.setPendingLpAction(LPActions.CANCEL_BP);			
		} else {
			proofOfCoverageData.setPendingLpAction(LPActions.NEW_BP);
		}
	}

	private void saveCollateralDetailsMap(BorrowerInsuranceReviewDTO borrowerInsuranceReviewDetails,
			BorrowerInsuranceReviewDetails borrowerInsuranceReviewDetails2) {
		Long borrowerInsuranceReviewDetailsRid = borrowerInsuranceReviewDetails.getRid();
		Set<Long> savedBIRCollateralDetailsToDelete =
				getSavedBIRCollateralDetails(borrowerInsuranceReviewDetails);
		
		for (BIRCollateralDetailsDTO birCollateralDetailsDTO : borrowerInsuranceReviewDetails.getCollateralDetailsMap().values()) {
			if (birCollateralDetailsDTO.getPolicyAddressData() != null) {
				addressDataService.saveAddress(birCollateralDetailsDTO.getPolicyAddressData());
			}

			BIRCollateralDetails birCollateralDetails = new BIRCollateralDetails();
			if (birCollateralDetailsDTO.getRid() != null) {
				savedBIRCollateralDetailsToDelete.remove(birCollateralDetailsDTO.getRid());
				birCollateralDetails = birCollateralDetailsRepository.findOne(birCollateralDetailsDTO.getRid());
			}
			
			if (birCollateralDetailsDTO.getPolicyAddressData() != null) {
				Address policyAddress = addressRepository.findOne(birCollateralDetailsDTO.getPolicyAddressData().getRid());
				birCollateralDetails.setPolicyAddress(policyAddress);
			}
			
			birCollateralDetailsDTO.setBorrowerInsuranceReviewDetailsRid(borrowerInsuranceReviewDetailsRid);
			ctracObjectMapper.map(birCollateralDetailsDTO, birCollateralDetails);
			birCollateralDetails = birCollateralDetailsRepository.saveAndFlush(birCollateralDetails);
			birCollateralDetailsDTO.setRid(birCollateralDetails.getRid());
			
			if (birCollateralDetailsDTO.getInsurableAssetDetailsMap() != null) {
				saveInsurableAssetDetailsMap(birCollateralDetailsDTO);
			}
		}
		
		deleteRemovedBIRCollateralDetails(savedBIRCollateralDetailsToDelete, borrowerInsuranceReviewDetails2);
	}
	
	private Set<Long> getSavedBIRCollateralDetails(BorrowerInsuranceReviewDTO borrowerInsuranceReviewDetails) {
		List<BIRCollateralDetails> savedBIRCollateralDetails =
				birCollateralDetailsRepository.findByBorrowerInsuranceReviewDetailsRid(borrowerInsuranceReviewDetails.getRid());
		Set<Long> savedBIRCollateralDetailsToDelete = new HashSet<Long>();
		for (BIRCollateralDetails birCollateralDetails : savedBIRCollateralDetails) {
			savedBIRCollateralDetailsToDelete.add(birCollateralDetails.getRid());
		}
		return savedBIRCollateralDetailsToDelete;
	}

	private void deleteRemovedBIRCollateralDetails(Set<Long> savedBIRCollateralDetailsToDelete,
			BorrowerInsuranceReviewDetails borrowerInsuranceReviewDetails) {
		for (Long birCollateralDetailsRid : savedBIRCollateralDetailsToDelete) {
			borrowerInsuranceReviewDetails.removeBIRCollateralDetails(birCollateralDetailsRid);
			birCollateralDetailsRepository.delete(birCollateralDetailsRid);
		}
		birCollateralDetailsRepository.flush();
	}
	
	private void saveInsurableAssetDetailsMap(BIRCollateralDetailsDTO birCollateralDetailsDTO) {
		Long birCollateralDetailsRid = birCollateralDetailsDTO.getRid();
		Set<Long> savedBIRInsurableAssetDetailsToDelete =
				getSavedBIRInsurableAssetDetailsByRid(birCollateralDetailsDTO);
		
		for (Entry<Long, BIRInsurableAssetDetailsDTO> birInsurableAssetDetailsEntry : birCollateralDetailsDTO.getInsurableAssetDetailsMap().entrySet()) {
			BIRInsurableAssetDetailsDTO birInsurableAssetDetailsDTO = birInsurableAssetDetailsEntry.getValue();
			BIRInsurableAssetDetails birInsurableAssetDetails = new BIRInsurableAssetDetails();
			if (birInsurableAssetDetailsDTO.getRid() != null) {
				savedBIRInsurableAssetDetailsToDelete.remove(birInsurableAssetDetailsDTO.getRid());
				birInsurableAssetDetails = birInsurableAssetDetailsRepository.findOne(birInsurableAssetDetailsDTO.getRid());
			}
			birInsurableAssetDetailsDTO.setInsurableAssetSortOrder(birInsurableAssetDetailsEntry.getKey());
			
			birInsurableAssetDetailsDTO.setBirCollateralDetailsRid(birCollateralDetailsRid);
			ctracObjectMapper.map(birInsurableAssetDetailsDTO, birInsurableAssetDetails);
			birInsurableAssetDetails = birInsurableAssetDetailsRepository.save(birInsurableAssetDetails);
			birInsurableAssetDetailsDTO.setRid(birInsurableAssetDetails.getRid());
		}
		deleteRemovedBIRInsurableAssetDetails(savedBIRInsurableAssetDetailsToDelete);
	}

	private Set<Long> getSavedBIRInsurableAssetDetailsByRid(BIRCollateralDetailsDTO birCollateralDetailsDTO) {
		List<BIRInsurableAssetDetails> savedBIRInsurableAssetDetails =
				birInsurableAssetDetailsRepository.findByBirCollateralDetailsRid(birCollateralDetailsDTO.getRid());
		Set<Long> savedBIRInsurableAssetDetailsToDelete = new HashSet<Long>();
		for (BIRInsurableAssetDetails birInsurableAssetDetails : savedBIRInsurableAssetDetails) {
			savedBIRInsurableAssetDetailsToDelete.add(birInsurableAssetDetails.getRid());
		}
		return savedBIRInsurableAssetDetailsToDelete;
	}
	
	private void deleteRemovedBIRInsurableAssetDetails(Set<Long> savedBIRInsurableAssetDetailsToDelete) {
		for (Long birInsurableAssetDetails : savedBIRInsurableAssetDetailsToDelete) {
			birInsurableAssetDetailsRepository.delete(birInsurableAssetDetails);
		}
		birInsurableAssetDetailsRepository.flush();
	}

	@Override
	@Transactional
	public void deleteBorrowerInsuranceReview(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		if (borrowerInsuranceReviewData != null && borrowerInsuranceReviewData.getRid() != null) {
			try {
				borrowerInsuranceReviewDetailsRepository.delete(borrowerInsuranceReviewData.getRid());
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}	
	}
}
