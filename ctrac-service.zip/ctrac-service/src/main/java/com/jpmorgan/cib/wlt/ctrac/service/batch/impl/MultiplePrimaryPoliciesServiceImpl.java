package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.service.batch.MultiplePrimaryPoliciesService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;

import microsoft.exchange.webservices.data.Importance;

@Service
public class MultiplePrimaryPoliciesServiceImpl implements MultiplePrimaryPoliciesService {

	@Autowired
	private CtracEmailSender ctracEmailSender;

	@Override
	public void processMultiplePrimaryPolicies(Collection<ProofOfCoverage> policies) {
		Set<Long> expiredMultiplePrimary = getMultiplePrimaryPolicies(policies);
		if (!expiredMultiplePrimary.isEmpty()) {
			StringBuffer message = new StringBuffer();
			message.append("Alert: ");
			StringBuffer collateralIds = new StringBuffer();
			for (Long collateralRid : expiredMultiplePrimary) {
				CtracStringUtil.addValueWithSeparator(collateralIds, collateralRid.toString(), ", ");
			}
			message.append(collateralIds);
			message.append(": Policy Expired - Multiple Primary Policies");
			ctracEmailSender.sendAlertEmailToFloodTeam(message.toString(), message.toString(), Importance.High);
		}
	}
	protected Set<Long> getMultiplePrimaryPolicies(Collection<ProofOfCoverage> policies) {
		Set<Long> multiplePrimary = new HashSet<Long>();
		if(policies == null || policies.isEmpty()) {
			return multiplePrimary;
		}
		for (ProofOfCoverage proofOfCoverage : policies) {
			if (proofOfCoverage.getCoverageType_() == CoverageType.PRIMARY) {
				Long thisRid = proofOfCoverage.getRid();
				Date dateCheck = new DateTime(proofOfCoverage.getExpirationDate()).withTimeAtStartOfDay().minusDays(1).toDate();
				for (ProvidedCoverage providedCoverage : proofOfCoverage.getProvidedCoverages()) {
					List<ProvidedCoverage> otherProvidedCoverages = providedCoverage.getInsurableAsset().getProvidedCoverages();
					for (ProvidedCoverage otherProvidedCoverage : otherProvidedCoverages) {
						ProofOfCoverage otherPolicy = otherProvidedCoverage.getProofOfCoverage();
						if (!thisRid.equals(otherPolicy.getRid()) && otherPolicy.getCoverageType_() == CoverageType.PRIMARY &&
								otherPolicy.getPolicyType_().isBorrowerPolicy() && otherPolicy.getPolicyStatus_().isActive(false) &&
								ProofOfCoverage.isEffectiveOn(otherPolicy.getEffectiveDate(), otherPolicy.getExpirationDate(), dateCheck)) {
							multiplePrimary.add(providedCoverage.getInsurableAsset().getBuilding().getCollateralRid());
						}
					}
				}
			}
		}
		return multiplePrimary;
	}

}
