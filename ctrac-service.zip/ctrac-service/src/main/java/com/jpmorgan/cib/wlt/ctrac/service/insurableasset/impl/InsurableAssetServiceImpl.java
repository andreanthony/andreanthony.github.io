package com.jpmorgan.cib.wlt.ctrac.service.insurableasset.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.CoverageDetailService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.InsurableAssetService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.ProvidedCoverageService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.RequiredCoverageService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class InsurableAssetServiceImpl implements InsurableAssetService {

    @Autowired
    private BuildingRepository buildingRepository;
    @Autowired
    private CtracObjectMapper ctracObjectMapper;
    @Autowired
    private InsurableAssetRepository insurableAssetRepository;
    @Autowired
    CoverageDetailsRepository coverageDetailsRepository;

    @Autowired
    CoverageDetailService coverageDetailService;

    @Autowired
    @Qualifier("insuranceMngtService")
    InsuranceMngtService insuranceMngtService;
    @Autowired
    ProvidedCoverageRepository providedCoverageRepository;
    @Autowired
    RequiredCoverageRepository requiredCoverageRepository;
    @Autowired
    ProofOfCoverageRepository proofOfCoverageRepository;
    @Autowired
    RequiredCoverageService requiredCoverageService;
    @Autowired
    ProvidedCoverageService providedCoverageService;

    private static final Logger logger = LoggerFactory.getLogger(InsurableAssetServiceImpl.class);

    @Override
    @Transactional
    public Collection<InsurableAssetDTO> findInsurableAssetByCollateral(Long collateralRid, InsuranceType coverageType) {
    	logger.debug("findInsurableAssetByCollateral(" + collateralRid + ")::BEGIN");
        Collection<InsurableAssetDTO> insurableAssetDTOs = new ArrayList<>();
        List<InsurableAsset> insurableAssets = insurableAssetRepository.findByBuildingCollateralRid(collateralRid);
        for (InsurableAsset insurableAsset : insurableAssets) {
            InsurableAssetDTO insAssetDto = mapInsurableAsset(insurableAsset);
            if (insAssetDto != null) {
                buildAndPopulateRequiredCoverageDto(coverageType, insurableAsset, insAssetDto);
                buildAndPopulateProvidedCoverageDto(coverageType, insurableAsset, insAssetDto);
                insAssetDto.setCollateralRid(collateralRid);
                insurableAssetDTOs.add(insAssetDto);
            }
        }
        logger.debug("findInsurableAssetByCollateral::END");
        return insurableAssetDTOs;
    }

    @Override
    @Transactional
    public void saveInsurableAssetAndCoverages(InsurableAssetDTO insurableAssetDTO, String userId) {

        logger.debug("saveInsurableAssetAndCoverages(" + insurableAssetDTO + ")::BEGIN");
        // 1 save the required and provided coverages;
        // Saving the provided or required coverage will persist the insurable
        // asset if not already persisted
        providedCoverageService.saveProvidedCoverage(insurableAssetDTO.getProvidedCoverageDTOs());

        requiredCoverageService.saveRequiredCoverage(insurableAssetDTO.getRequiredCoverageDTOs());

        saveInsurableAsset(insurableAssetDTO, userId);

        logger.debug("saveInsurableAssetAndCoverages ::END");

    }

    @Override
    @Transactional
    public void saveInsurableAssetAndCoverages(List<InsurableAssetDTO> insurableAssetDTOList, String userId) {
        for (InsurableAssetDTO insurableAssetDto : insurableAssetDTOList) {
            saveInsurableAssetAndCoverages(insurableAssetDto, userId);
        }

    }

    @Override
    @Transactional
    public void deleteInsurableAsset(Collection<Long> insurableAssetIds) {

        logger.debug("deleteInsurableAsset(" + insurableAssetIds + ")::BEGIN");

        if (insurableAssetIds == null || insurableAssetIds.isEmpty()) {
            return;
        }

        for (Long Id : insurableAssetIds) {
            try {

                insurableAssetRepository.delete(Id);

            } catch (Exception e) {
            }
        }

        logger.debug("deleteInsurableAsset::END");
    }


    @Override
    @Transactional
    public void deleteInsurableAssetCoverageRequirement(Collection<Long> insurableAssetIds, CoverageRequirementStatus coverageStatus) {

        logger.debug("deleteInsurableAssetCoverageRequirement(" + insurableAssetIds + ")::BEGIN");

        if (insurableAssetIds == null || insurableAssetIds.isEmpty()) {
            return;
        }

        for (Long Id : insurableAssetIds) {
            try {

               InsurableAsset insurableAsset = insurableAssetRepository.findOne(Id);
               List<RequiredCoverage> requiredCoverages = insurableAsset.getRequiredCoverages();
               for(RequiredCoverage requiredCoverage :requiredCoverages){
                   if(coverageStatus==null || coverageStatus.name().equals(requiredCoverage.getRequiredCoverageSource().getStatus())){

                       //delete the required coverage selected
                       insurableAsset.removeRequiredCoverage(requiredCoverage);

                       /**
                        * if there are no other coverage( required/provided/verified ) associated with the insurable asset, delete it
                        */
                       if(insurableAsset.getRequiredCoverages().isEmpty() && insurableAsset.getProvidedCoverages().isEmpty()){
                           insurableAssetRepository.delete(insurableAsset);
                       }else{
                           insurableAssetRepository.save(insurableAsset);
                       }
                   }
               }
            } catch (Exception e) {
            }
        }

        logger.debug("deleteInsurableAssetCoverageRequirement::END");
    }





    // TODO FIXME to break circular dependency, this method is duplicate in
    // requiredcoverage service
    @Transactional
    void saveInsurableAsset(InsurableAssetDTO insurableAssetDTO, String userId) {

        logger.debug("saveInsurableAsset(" + insurableAssetDTO + ")::BEGIN");
        if (!insurableAssetDTO.hasChanged()) {
            return;
        }
        // assume the collateral was already persisted; otherwise persist the
        // collateral
        Building building = buildingRepository.findOne(insurableAssetDTO.getBuildingRid());

        if (building == null) {
            logger.error(" The InsurableAssetDTO building ID was null or invalid");
            throw new RuntimeException(" Invalid state exception: cannot save and insurable asset without a valid building id");
        }
        InsurableAsset insurableAssetToUpdate = null;

        if (insurableAssetDTO.getRid() != null) {
            insurableAssetToUpdate = insurableAssetRepository.findOne(insurableAssetDTO.getRid());
            insurableAssetToUpdate.setBuilding(building);
        } else if (insurableAssetDTO.getInsurableAssetType() != null) {
            insurableAssetToUpdate = new InsurableAsset(insurableAssetDTO.getInsurableAssetType());
            insurableAssetToUpdate.setBuilding(building);
        }

        insurableAssetToUpdate = CtracBaseEntity.deproxy(insurableAssetToUpdate, InsurableAsset.class);

        ctracObjectMapper.map(insurableAssetDTO, insurableAssetToUpdate);

        insurableAssetRepository.save(insurableAssetToUpdate);
        insurableAssetDTO.setRid(insurableAssetToUpdate.getRid());

        logger.debug("saveInsurableAsset::END");

    }

    private List<ProvidedCoverageDTO> buildAndPopulateProvidedCoverageDto(InsuranceType insuranceType, InsurableAsset insurableAsset,
            InsurableAssetDTO insDTO) {

        if (insurableAsset == null) {
            return insDTO != null ? insDTO.getProvidedCoverageDTOs() : null;
        }

        for (ProvidedCoverage providedCoverage : insurableAsset.getProvidedCoverages()) {
            providedCoverage = CtracBaseEntity.deproxy(providedCoverage, ProvidedCoverage.class);
            ProvidedCoverageDTO providedCovDto = ctracObjectMapper.map(providedCoverage, ProvidedCoverageDTO.class);
            ProofOfCoverageDTO pocDto = getProofOfcoverage(providedCoverage);
            providedCovDto.setProofOfCoverageDto(pocDto);
            providedCovDto.setInsurableAssetDTO(insDTO);
            insDTO.addProvidedCoverage(providedCovDto);
        }
        return insDTO.getProvidedCoverageDTOs();
    }


    private List<RequiredCoverageDTO> buildAndPopulateRequiredCoverageDto(
    		InsuranceType insuranceType, InsurableAsset insurableAsset, InsurableAssetDTO insurableAssetDTO) {

		if (insurableAsset == null) {
			return insurableAssetDTO != null ? insurableAssetDTO.getRequiredCoverageDTOs() : null;
		}
		for (RequiredCoverage requiredCoverage : insurableAsset.getRequiredCoverages()) {
			if (insuranceType == null || insuranceType.name().equals(requiredCoverage.getRequiredCoverageSource().getInsuranceType())) {
				requiredCoverage = CtracBaseEntity.deproxy(requiredCoverage, RequiredCoverage.class);
				RequiredCoverageDTO requiredCovDto = ctracObjectMapper.map(requiredCoverage, RequiredCoverageDTO.class);
				requiredCovDto.setInsurableAssetDTO(insurableAssetDTO);
				insurableAssetDTO.addRequiredCoverage(requiredCovDto);
			}
		}
        return insurableAssetDTO.getRequiredCoverageDTOs();
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private ProofOfCoverageDTO getProofOfcoverage(ProvidedCoverage providedCoverage) {
        ProofOfCoverage pof = providedCoverage.getProofOfCoverage();
        pof = CtracBaseEntity.deproxy(pof, ProofOfCoverage.class);
        Class destinationClass = CtracObjectMapper.entityClassMapping.get(pof.getClass());
        ProofOfCoverageDTO pocDto = (ProofOfCoverageDTO) ctracObjectMapper.map(pof, destinationClass);
        return pocDto;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public InsurableAssetDTO mapInsurableAsset(InsurableAsset insurableAsset) {
        InsurableAssetDTO insurableAssetDTO = ctracObjectMapper.map(insurableAsset, InsurableAssetDTO.class);

        //manually adding mapping
        List<RequiredCoverage> requiredCoverages = insurableAsset.getRequiredCoverages();
        List<RequiredCoverageDTO> requiredCoverageDTOs = ctracObjectMapper.mapAsList(requiredCoverages, RequiredCoverageDTO.class);
        insurableAssetDTO.setRequiredCoverageDTOs(requiredCoverageDTOs);
        return insurableAssetDTO;
    }

}
