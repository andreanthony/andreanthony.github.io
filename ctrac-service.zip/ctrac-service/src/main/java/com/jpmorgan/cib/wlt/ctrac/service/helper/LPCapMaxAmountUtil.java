package com.jpmorgan.cib.wlt.ctrac.service.helper;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.RealEstateSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.propertytype.AlthansPropertyType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.helper.vendor.LPAlthansFilePropertyTypeConverter;

import java.math.BigDecimal;

public class LPCapMaxAmountUtil {

	public static BigDecimal capLPCoverageAmount(CoverageType coverageType, InsurableAssetDTO insurableAssetDTO, BigDecimal lpAmount){
		if(insurableAssetDTO == null ||  coverageType == null)
			return lpAmount;

		if(coverageType == CoverageType.PRIMARY){
			return capPrimaryLPCoverageAmount(insurableAssetDTO, lpAmount);
		}
		else if(coverageType == CoverageType.EXCESS){
			return capExcessLPCoverageAmount(insurableAssetDTO, lpAmount);
		}
		else{
			return lpAmount;
		}
	}

	private static BigDecimal capExcessLPCoverageAmount(InsurableAssetDTO insurableAssetDTO, BigDecimal lpAmount) {
		return cap(getMaximumExcessLPCoverageAmount(insurableAssetDTO), lpAmount);
	}


	private static BigDecimal capPrimaryLPCoverageAmount(InsurableAssetDTO insurableAssetDTO, BigDecimal lpAmount){
		return cap(getMaximumPrimaryLPCoverageAmount(insurableAssetDTO), lpAmount);
	}


    private static BigDecimal getMaximumExcessLPCoverageAmount(InsurableAssetDTO insurableAssetDTO){
        if(InsurableAssetType.STRUCTURE == insurableAssetDTO.getInsurableAssetType()){
            return new BigDecimal("25000000.00");
        }
        if(InsurableAssetType.BUSINESS_INCOME == insurableAssetDTO.getInsurableAssetType()) {
            return BigDecimal.ZERO;
        }
        return null;
    }

    private static BigDecimal getMaximumPrimaryLPCoverageAmount(InsurableAssetDTO insurableAssetDTO) {
        if(InsurableAssetType.BUSINESS_INCOME == insurableAssetDTO.getInsurableAssetType()) {
            return null;
        }
        String collateralSubType = getCollateralSubType(insurableAssetDTO.getCollateralRid());
        return getMaximumPrimaryLPCoverageAmount(insurableAssetDTO.getPropertyType(), collateralSubType);
    }

	public static BigDecimal getMaximumPrimaryLPCoverageAmount(String propertyType, String collateralSubType) {
		AlthansPropertyType althansPropertyType = ApplicationContextProvider.getContext().getBean(LPAlthansFilePropertyTypeConverter.class).
				convertPropertyTypeDescriptionToAlthans(propertyType);

		if(AlthansPropertyType.DWELLING_RESIDENTIAL == althansPropertyType){
			return new BigDecimal("250000.00");
		}
		else if(AlthansPropertyType.MULTI_FAMILY == althansPropertyType || AlthansPropertyType.COMMERCIAL == althansPropertyType){
			return new BigDecimal("500000.00");
		}
		else if(AlthansPropertyType.CONDO_ASSOC == althansPropertyType){
			if(RealEstateSubType.COMMERCIAL_CONDO_ASSOCIATION.getCode().equals(collateralSubType) ||
					RealEstateSubType.COMMERCIAL.getCode().equals(collateralSubType))
				return new BigDecimal("500000.00");
			else
				return new BigDecimal("250000.00");
		}
		else{
			return null;
		}
	}

	private static BigDecimal cap(BigDecimal capAmount, BigDecimal actualAmount){
		return (capAmount == null || actualAmount.compareTo(capAmount) == -1)? actualAmount: capAmount;
	}

	private static String getCollateralSubType(Long collateralRid){
		CollateralManagementService service = (CollateralManagementService)ApplicationContextProvider.getContext().getBean(CollateralManagementService.class);
		return service.getCollateralDto(collateralRid).getCollateralSubType();
	}
}
