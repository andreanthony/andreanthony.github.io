package com.jpmorgan.cib.wlt.ctrac.service.dto.admin;

import java.io.Serializable;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

public class RestartLetterCycleDTO implements Serializable {

	private static final long serialVersionUID = 5252457557658647559L;
	
	private Long collateralID;
	
	private String collateralAddress= "";
	
	private String successMsg = null;
	
	private String errorMsg = null;
	
	private Boolean displayInsuranceSection = false;
	
	private List<ProofOfCoverageDTO> ProofOfCoverage;

	private String selectedRIDs="";
	      
	
	public Long getCollateralID() {
		return collateralID;
	}

	public void setCollateralID(Long collateralID) {
		this.collateralID = collateralID;
	}

	public String getCollateralAddress() {
		return collateralAddress;
	}

	public void setCollateralAddress(String collateralAddress) {
		this.collateralAddress = collateralAddress;
	}

	public String getSuccessMsg() {
		return successMsg;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Boolean getDisplayInsuranceSection() {
		return displayInsuranceSection;
	}

	public void setDisplayInsuranceSection(Boolean displayInsuranceSection) {
		this.displayInsuranceSection = displayInsuranceSection;
	}

	public List<ProofOfCoverageDTO> getProofOfCoverage() {
		return ProofOfCoverage;
	}

	public void setProofOfCoverage(List<ProofOfCoverageDTO> proofOfCoverage) {
		ProofOfCoverage = proofOfCoverage;
	}

	public String getSelectedRIDs() {
		return selectedRIDs;
	}

	public void setSelectedRIDs(String selectedRIDs) {
		this.selectedRIDs = selectedRIDs;
	}

	
}
