package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;

public class BIRAcceptedPolicyEmailDTO {
	private String insuredName;
	private String policyNumber;
	private String expirationDate;
	private ArrayList<LoanData> loanBorrowerList = new ArrayList<LoanData>();
	private ArrayList<CollateralDto> collateralList = new ArrayList<CollateralDto>();
	private String collateralIds;

	public String getInsuredName() {
		if (insuredName != null) {
			return insuredName;
		}
		return "";
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getPolicyNumber() {
		if (policyNumber != null) {
			return policyNumber;
		}

		return "";
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getExpirationDate() {
		if (expirationDate != null) {
			return expirationDate;
		}
		return "";
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public ArrayList<LoanData> getLoanBorrowerList() {
		return loanBorrowerList;
	}

	public void setLoanBorrowerList(ArrayList<LoanData> loanBorrowerList) {
		this.loanBorrowerList = loanBorrowerList;
	}

	public ArrayList<CollateralDto> getCollateralList() {
		return collateralList;
	}

	public void setCollateralList(ArrayList<CollateralDto> collateralList) {
		this.collateralList = collateralList;
	}

	public String getCollateralIds() {
		return collateralIds;
	}

	public void setCollateralIds(String collateralIds) {
		this.collateralIds = collateralIds;
	}

	public Set<Long> getCollateralIdSet() {
		Set<Long> idSet = new HashSet<Long>();
		for (CollateralDto collateralDto : collateralList) {
			idSet.add(collateralDto.getRid());
		}
		return idSet;
	}

}
