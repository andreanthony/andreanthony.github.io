package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

/**
 * DTO object to carry the conditions
 * to find the next work flow transition for
 * remap tasks
 * 
 * @author R534783
 *
 */


//TODO refactor this object and make it the image of the DB table  TLCP_GENERIC_APP_RULE
// use 
public class AppRuleInput {

	

	/**
	 * TODO make this class the image of TLCP_GENERIC_APP_RULE
	 * private String cond1;
	 * 
	 * ...
	 * 
	 * private String cond2;
	 * 
	 * 
	 * private String action1;
	 * ...
	 * 
	 * private String action6;
	 */
	
	
	
	//TODO remove everything below
	private String clientFoundFlag;

	private String propertyPledgedFlag;

	private String exposureFlag;

	private String lobEmailSend;

	private String currentWorkFlowStep;

	private String remapType;
	
	private String escaltionFlag;
	
	private String completeFlag;
	
	private String workFlowTransitionProcess;
	
	private String ruleName;
	
	private String remapCategory;
	
	private String slaDaysRemaining;
	
	private String tmTaskType;
	
	private String perfectionTaskType;
	
	private String perfectionTaskSubType;
	
	private String reminderType;
	
	private String loanActiveFlag;
	
	private String comments;
		
	public static final String DEFAULT_ESCALATION_FLAG = "NA";
	
	public static final String DEFAULT_REMAP_TYPE= "ALL";
	
	//LCP-2449
	private String policyType;
	
	private String loanType;
	
	private String collateralType;
	//LCP-2449
	
	public String getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}
	
	public String getPerfectionTaskType() {
		return perfectionTaskType;
	}

	public void setPerfectionTaskType(String perfectionTaskType) {
		this.perfectionTaskType = perfectionTaskType;
	}

	public String getPerfectionTaskSubType() {
		return perfectionTaskSubType;
	}

	public void setPerfectionTaskSubType(String perfectionTaskSubType) {
		this.perfectionTaskSubType = perfectionTaskSubType;
	}
	
	public String getClientFoundFlag() {
		return clientFoundFlag;
	}

	public void setClientFoundFlag(String clientFoundFlag) {
		this.clientFoundFlag = clientFoundFlag;
	}

	public String getPropertyPledgedFlag() {
		return propertyPledgedFlag;
	}

	public void setPropertyPledgedFlag(String propertyPledgedFlag) {
		this.propertyPledgedFlag = propertyPledgedFlag;
	}

	public String getExposureFlag() {
		return exposureFlag;
	}

	public void setExposureFlag(String exposureFlag) {
		this.exposureFlag = exposureFlag;
	}

	public String getLobEmailSend() {
		return lobEmailSend;
	}

	public void setLobEmailSend(String lobEmailSend) {
		this.lobEmailSend = lobEmailSend;
	}

	public String getCurrentWorkFlowStep() {
		return currentWorkFlowStep;
	}

	public void setCurrentWorkFlowStep(String currentWorkFlowStep) {
		this.currentWorkFlowStep = currentWorkFlowStep;
	}

	public String getRemapType() {
		return remapType;
	}

	public void setRemapType(String remapType) {
		this.remapType = remapType;
	}

	public String getEscaltionFlag() {
		return escaltionFlag;
	}

	public void setEscaltionFlag(String escaltionFlag) {
		this.escaltionFlag = escaltionFlag;
	}

	public String getCompleteFlag() {
		return completeFlag;
	}

	public void setCompleteFlag(String completeFlag) {
		this.completeFlag = completeFlag;
	}

	public String getWorkFlowTransitionProcess() {
		return workFlowTransitionProcess;
	}

	public void setWorkFlowTransitionProcess(String workFlowTransitionProcess) {
		this.workFlowTransitionProcess = workFlowTransitionProcess;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRemapCategory() {
		return remapCategory;
	}

	public void setRemapCategory(String remapCategory) {
		this.remapCategory = remapCategory;
	}

	public String getSlaDaysRemaining() {
		return slaDaysRemaining;
	}

	public void setSlaDaysRemaining(String slaDaysRemaining) {
		this.slaDaysRemaining = slaDaysRemaining;
	}
	
	public String getReminderType() {
		return reminderType;
	}

	public void setReminderType(String reminderType) {
		this.reminderType = reminderType;
	}

	public String getLoanActiveFlag() {
		return loanActiveFlag;
	}

	public void setLoanActiveFlag(String loanActiveFlag) {
		this.loanActiveFlag = loanActiveFlag;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	//LCP-2449
	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}
	//LCP-2449
	

}
