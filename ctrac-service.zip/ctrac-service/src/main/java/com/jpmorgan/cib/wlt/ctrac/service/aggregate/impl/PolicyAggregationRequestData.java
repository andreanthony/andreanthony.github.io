package com.jpmorgan.cib.wlt.ctrac.service.aggregate.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskRelationType;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;



public class PolicyAggregationRequestData {

	private WorkflowStateDefinition childPolicyState;
	private WorkflowStateDefinition parentTaskState;
	private TaskRelationType parentChildRelationType;
	private PerfectionItemSubType parentPerfetionSubType;	

	private PolicyAggregationRequestData(){
		 super();
	}
	
	public static PolicyAggregationRequestData  getAggregationDataForLPremuinPayment(){
		PolicyAggregationRequestData result = new PolicyAggregationRequestData();
		result.childPolicyState = WorkflowStateDefinition.APPROVED_FOR_WIRE_REQUEST;
		result.parentTaskState = WorkflowStateDefinition.CREATE_WIRE_REQUEST;
		result.parentChildRelationType = TaskRelationType.WIRETOPOLICY;
		result.parentPerfetionSubType=  PerfectionItemSubType.WIRE;
		return result;
	}
	
	public static PolicyAggregationRequestData  getAggregationDataForLPRefundRequest(){
		PolicyAggregationRequestData result = new PolicyAggregationRequestData();
		result.childPolicyState = WorkflowStateDefinition.APPROVED_FOR_REFUND_REQUEST;
		result.parentTaskState = WorkflowStateDefinition.CREATE_REFUND_REQUEST;
		result.parentChildRelationType = TaskRelationType.REFUNDTOPOLICY;
		result.parentPerfetionSubType=  PerfectionItemSubType.REFUND;
		return result;
	}

	public WorkflowStateDefinition getChildPolicyState() {
		return childPolicyState;
	}

	public WorkflowStateDefinition getParentTaskState() {
		return parentTaskState;
	}

	public TaskRelationType getParentChildRelationType() {
		return parentChildRelationType;
	}

	public PerfectionItemSubType getParentPerfetionSubType() {
		return parentPerfetionSubType;
	}

}
