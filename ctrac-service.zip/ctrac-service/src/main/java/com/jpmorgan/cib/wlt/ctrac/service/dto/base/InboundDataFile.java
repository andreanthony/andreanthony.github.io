package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

public class InboundDataFile {

	private String fileName;

	private byte[] fileContent;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFileContent() {
		return fileContent;
	}

	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}

}