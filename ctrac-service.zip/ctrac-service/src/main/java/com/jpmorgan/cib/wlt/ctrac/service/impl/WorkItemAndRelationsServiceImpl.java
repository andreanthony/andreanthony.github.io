package com.jpmorgan.cib.wlt.ctrac.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskRelationType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItemRelation;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCovWorkItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.WorkItemRelationRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.WorkItemRepository;
import com.jpmorgan.cib.wlt.ctrac.service.WorkItemAndRelationsService;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.AggregateKey;



@Service(value = "workItemAndRelationsService")
public class WorkItemAndRelationsServiceImpl implements WorkItemAndRelationsService {

	@Autowired
	private WorkItemRelationRepository workItemRelationRepository;
	
	@Autowired
	private WorkItemRepository workItemRepository;
	
	@Autowired ProofOfCovWorkItemRepository proofOfCovWorkItemRepository;
	
	@Override
	public WorkItemRelation createRelation(WorkItem parent, WorkItem child, TaskRelationType relation, String insertedBy) {
		WorkItemRelation perfectionItemRelation = createPerfectionItemRelation(parent, child, relation, insertedBy);		
		return workItemRelationRepository.save(perfectionItemRelation);
	}

	@Override
	public List<WorkItemRelation> createRelations(WorkItem parent, List<? extends WorkItem> childrenItems, TaskRelationType relation, String insertedBy) {
		List<WorkItemRelation> perfectionItemRelations = new ArrayList<WorkItemRelation>();
		for (WorkItem childItem : childrenItems) {
			perfectionItemRelations.add(createPerfectionItemRelation(parent, childItem, relation, insertedBy));
		}
		return workItemRelationRepository.save(perfectionItemRelations);
	}
	
	@Override
	public List<WorkItemRelation> createRelations(WorkItem parent,Map<AggregateKey, List<WorkItem>> policyMap, TaskRelationType relation, String insertedBy) {
		List<WorkItemRelation> perfectionItemRelations = new ArrayList<WorkItemRelation>();
		for (AggregateKey key : policyMap.keySet()) {
			List<WorkItem> childrenItems = policyMap.get(key);
			for (WorkItem childItem : childrenItems) {
				perfectionItemRelations.add(createPerfectionItemRelation(parent, childItem, relation, insertedBy));
			}
		}		
		return workItemRelationRepository.save(perfectionItemRelations);
	}
	
	@Override
	public WorkItemRelation findParentByChildAndRelation(WorkItem child, TaskRelationType relation) {
		return workItemRelationRepository.findByChildWorkItemAndRelationType(child, relation.name());
	}

	@Override
	public List<WorkItemRelation> findChildrenByParentAndRelation(WorkItem parent, TaskRelationType relation) {
		return workItemRelationRepository.findByParentWorkItemAndRelationType(parent, relation.name());
	}
	
	@Override
	public void updateParentRelation(WorkItem child, TaskRelationType oldRelation, TaskRelationType newRelation) {
		WorkItemRelation childRelation = findParentByChildAndRelation(child, oldRelation);
		if (childRelation != null) {
			childRelation.setRelationType(newRelation.name());
			workItemRelationRepository.save(childRelation);
		}
	}
	
	@Override
	public void updateChildrenRelations(WorkItem parent, TaskRelationType oldRelation, TaskRelationType newRelation) {
		List<WorkItemRelation> children = findChildrenByParentAndRelation(parent, oldRelation);
		if (children != null && !children.isEmpty()) {
			for (WorkItemRelation child : children) {
				child.setRelationType(newRelation.name());
			}
			workItemRelationRepository.save(children);
		}
	}
	
	@Override
	public List<WorkItemRelation> findSleepingChildrenByParentAndRelation(WorkItem parent, TaskRelationType relation) {
		return workItemRelationRepository.findSleepingAndOpenRelationsByParentRidAndRelationType(parent.getRid(), relation.name());
	}
	
	private WorkItemRelation createPerfectionItemRelation(WorkItem parent, WorkItem child, TaskRelationType relation, String insertedBy) {
		WorkItemRelation perfectionItemRelation = new WorkItemRelation();
		perfectionItemRelation.setChildWorkItem(child);
		perfectionItemRelation.setParentWorkItem(parent);
		perfectionItemRelation.setRelationType(relation.name());
		return perfectionItemRelation;
	}

	@Override
	public List<WorkItem> getChildItemsByParentAndRelation(WorkItem parent, TaskRelationType relationType) {
		List<WorkItem> childItems = new ArrayList<WorkItem>();
		List<WorkItemRelation> relations = workItemRelationRepository.findByParentWorkItemAndRelationType(parent, relationType.name());
		if (relations != null) {
			for (WorkItemRelation relation : relations) {
				childItems.add(relation.getChildWorkItem());
			}
		}
		return childItems;
	}

	@Override
	public WorkItem getParentItemByChildAndRelation(WorkItem childPerfectionItem, TaskRelationType relationType){
		WorkItemRelation relation = workItemRelationRepository.findByChildWorkItemAndRelationType(childPerfectionItem, relationType.name());
		return relation == null ? null : relation.getParentWorkItem();
	}

	
/*	@Override
	public List<ProofOfCovWorkItem> createOrUpdateProofOfCovWorkItem(
			List<WorkItem> workItems, ProofOfCoverage proofOfCoverage) {

		List<ProofOfCovWorkItem> proofOfCovWorkItems = new ArrayList<ProofOfCovWorkItem>();
		
		for(WorkItem workItem : workItems){
			
			ProofOfCovWorkItem rel = proofOfCovWorkItemRepository.findByWorkItemRidAndProofOfCoverageRid(workItem.getRid(),proofOfCoverage.getRid());
			//if the relatio already exist, continue
			if(rel!=null){
				continue;
			}
			
			ProofOfCovWorkItem proofOfCovWorkItem= new ProofOfCovWorkItem();
			proofOfCovWorkItem.setWorkItem(workItem);
			proofOfCovWorkItem.setProofOfCoverage(proofOfCoverage);
			proofOfCovWorkItemRepository.save(proofOfCovWorkItem);
			
			proofOfCovWorkItems.add(proofOfCovWorkItem);
			
		}
		
		return proofOfCovWorkItems;
	}*/

	
}
