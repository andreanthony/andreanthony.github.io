package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.SEND_FINAL_LP_LETTER;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.WorkItemRepository;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateBuilder;
import com.jpmorgan.cib.wlt.ctrac.service.dto.letters.CombinableLetter;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.VendorPaymentMethodService;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterDateType;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterDateWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterTemplate;
import com.jpmorgan.cib.wlt.ctrac.service.letters.impl.LetterParameterType;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.SendFinalLPLetterState;

/**
 * 
 * @author n657508
 * 
 */
public class GenerateLetterCommand extends AbstractCommand {

	private static final Logger logger = Logger.getLogger(GenerateLetterCommand.class);

	private final Long collateralRid;
	private final Collection<CombinableLetter> combinableLetters;
	private final LetterTemplate letterTemplate;
	private final Long workItemRid;
	private final Long proofOfCoverageRid;
	private final Long perfectionTaskRid;
	private final Date letterDate;
	
	public GenerateLetterCommand(Long collateralRid, Long proofOfCoverageRid, Long workItemRid, Collection<CombinableLetter> combinedLetters,  LetterTemplate letterTemplate, Date letterDate, Long perfectionTaskRid) {
		this(collateralRid, proofOfCoverageRid, workItemRid,  combinedLetters, letterTemplate,letterDate, perfectionTaskRid, 0);
	}
	
	public GenerateLetterCommand(Long collateralRid, Long proofOfCoverageRid, Long workItemRid, Collection<CombinableLetter> letters, LetterTemplate letterTemplate, Date letterDate , Long perfectionTaskRid, int priority) {
		this.collateralRid = collateralRid;
		this.combinableLetters = letters;
		this.letterTemplate = letterTemplate;
		this.letterDate = letterDate;
		this.priority = priority;
		this.workItemRid = workItemRid;
		this.proofOfCoverageRid = proofOfCoverageRid;
		this.perfectionTaskRid = perfectionTaskRid;
	}
		
	@Override
	public void execute() {
		Date letterDate = this.getLetterDate();

		// create letters to be combined and add them to the list
		Map<LetterParameterType, Object> letterParams = new HashMap<LetterParameterType, Object>();
		letterParams.put(LetterParameterType.LETTER_DATE, letterDate);
		letterParams.put(LetterParameterType.LETTER_TEMPLATE, letterTemplate);
		letterParams.put(LetterParameterType.COLLATERAL_RID, collateralRid);
		letterParams.put(LetterParameterType.WORK_ITEM_RID, workItemRid);
		letterParams.put(LetterParameterType.PROOF_OF_COVERAGE_RID, proofOfCoverageRid);
		letterParams.put(LetterParameterType.PERFECTION_TASK_RID, perfectionTaskRid);
		
		saveWorkflowData(letterDate);
		Collection<CombinableLetter> addedLetters = letterTemplate.buildLetters(letterParams);
		combinableLetters.addAll(addedLetters);		
	}
	
	private void saveWorkflowData(Date letterDate) {
		
		// find ProofOfCoverage if necessary
		ProofOfCoverageRepository proofOfCoverageRepository = null;
		ProofOfCoverage proofOfCoverage = null;
		if (proofOfCoverageRid != null) {
			proofOfCoverageRepository = ApplicationContextProvider.getContext().getBean(ProofOfCoverageRepository.class);
			proofOfCoverage = CtracBaseEntity.deproxy(proofOfCoverageRepository.findOne(proofOfCoverageRid), ProofOfCoverage.class);
		}

		if (proofOfCoverage == null) {
			logger.error("Letter workflow save - ProofOfCoverage was not found with rid " + proofOfCoverageRid);
			return;
		}
		
		if (LetterTemplate.LP_45_DAY_1ST_LETTER.equals(letterTemplate)
				|| LetterTemplate.ZONE_IN_1ST_LETTER.equals(letterTemplate)
				|| LetterTemplate.LP_GAP_1ST_LETTER.equals(letterTemplate)) {
			
			// for zone in only, set the effective date to the 46th day
			Date fourtySixthDay = new DateBuilder(letterDate).addCalendarDays(45,false).build();
			if(LetterTemplate.ZONE_IN_1ST_LETTER.equals(letterTemplate)){
				Date expirationDate = new DateTime(fourtySixthDay).plusYears(1).toDate();
				proofOfCoverage.setEffectiveDate(fourtySixthDay);
				proofOfCoverage.setExpirationDate(expirationDate);
			}
			
			// move to letter cycle, set LP target date to the 46th day, and default the payment method
			proofOfCoverage.setPolicyStatus(PolicyStatus.LETTER_CYCLE.name());
			proofOfCoverage.setLpTargetDate(fourtySixthDay);
			proofOfCoverage = proofOfCoverageRepository.save(proofOfCoverage);
			setDefaultInvoicePaymentMethod(proofOfCoverage);
		}
				
		// For Final Letters(LetterDateType.POLICY || LetterDateType.PRERENEWAL_PREMIUM), don't make any database changes, this letter might be skipped
		// set the letter date
		LetterDateWorkflowService letterDateWorkflowService = ApplicationContextProvider.getContext().getBean(LetterDateWorkflowService.class);
		LetterDateType letterDateType = letterDateWorkflowService.getLetterDateType(letterTemplate);
		if (proofOfCoverage != null && letterDateType != null && !(letterDateType.equals(LetterDateType.POLICY)  || letterDateType.equals(LetterDateType.PRERENEWAL_PREMIUM))) {
			logger.debug("Setting " + letterDateType.name() + " letter date to " + DateFormatter.toString(letterDate) + " for policy rid " + proofOfCoverage.getRid());
			letterDateWorkflowService.setLetterDate(proofOfCoverage, letterDateType, letterDate);
		}
	}

	private void setDefaultInvoicePaymentMethod(ProofOfCoverage proofOfCoverage) {
		WorkItemRepository workItemRepository = ApplicationContextProvider.getContext().getBean(WorkItemRepository.class);
		WorkItem workItem = CtracBaseEntity.deproxy(workItemRepository.findOne(workItemRid), WorkItem.class);
		VendorPaymentMethodService vendorPaymentMethodService = ApplicationContextProvider.getContext().getBean(VendorPaymentMethodService.class);
		vendorPaymentMethodService.setDefaultInvoicePaymentMethod(proofOfCoverage, workItem);
	}
	
	public Object getLetterTemplate() {
		return letterTemplate;
	}	

	public Long getCollateralRid() {
		return collateralRid;
	}
	
	public Long getWorkItemRid() {
		return workItemRid;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}
	
	public Date getLetterDate() {
		return letterDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((collateralRid == null) ? 0 : collateralRid.hashCode());
		result = prime * result + ((combinableLetters == null) ? 0 : combinableLetters.hashCode());
		result = prime * result + ((letterTemplate == null) ? 0 : letterTemplate.hashCode());
		result = prime * result + ((proofOfCoverageRid == null) ? 0 : proofOfCoverageRid.hashCode());
		result = prime * result + ((workItemRid == null) ? 0 : workItemRid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GenerateLetterCommand other = (GenerateLetterCommand) obj;
		if (collateralRid == null) {
			if (other.collateralRid != null)
				return false;
		} else if (!collateralRid.equals(other.collateralRid))
			return false;
		if (combinableLetters == null) {
			if (other.combinableLetters != null)
				return false;
		} else if (!combinableLetters.equals(other.combinableLetters))
			return false;
		if (letterTemplate != other.letterTemplate)
			return false;
		if (proofOfCoverageRid == null) {
			if (other.proofOfCoverageRid != null)
				return false;
		} else if (!proofOfCoverageRid.equals(other.proofOfCoverageRid))
			return false;
		if (workItemRid == null) {
			if (other.workItemRid != null)
				return false;
		} else if (!workItemRid.equals(other.workItemRid))
			return false;
		return true;
	}

}