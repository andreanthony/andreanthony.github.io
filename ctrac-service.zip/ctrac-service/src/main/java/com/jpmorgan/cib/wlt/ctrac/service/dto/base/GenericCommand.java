package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

public interface GenericCommand <T extends GenericCommandParams> {
		/**
		 * @param genericCommandDto
		 * 
		 */
		public void execute(T genericCommandParam);
}
