package com.jpmorgan.cib.wlt.ctrac.service.aspect;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Aspect
@Component
public class PerfectionTaskAuditingAspect {

	@AfterReturning(pointcut="execution(* com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository.find*(..))",returning="returnedObject")
	public void setLoadTimeValues(Object returnedObject) {
	    if(returnedObject instanceof PerfectionTask) {
            ((PerfectionTask)returnedObject).setLoadTimeValues();
        }
        else if(returnedObject instanceof List<?>) {
	        List<?> returnedObjects = (List<?>)returnedObject;
            for (Object perfectionTask : returnedObjects) {
                if(perfectionTask instanceof PerfectionTask) {
                    ((PerfectionTask)perfectionTask).setLoadTimeValues();
                }
            }
        }
	}

}
