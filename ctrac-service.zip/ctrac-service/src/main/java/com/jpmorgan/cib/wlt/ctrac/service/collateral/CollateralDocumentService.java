package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import java.io.File;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;


public interface CollateralDocumentService {

	CollateralDoc getCollateralDocByRid(Long collateralDocumentRid);
	
	List<CollateralDoc> getCollateralDocs(Long collateralId);

	void removeCollateralDoc(List<CollateralDoc> files);
	
	void removeCollateralDocument(Long documentRid);
	
	void removeCollateralDocument(Long collateralId, String docType);
	
	void removeCollateralDocuments(List<CollateralDocument> collateralDocs);
	
	CollateralDocument saveCollateralDocument(MultipartFile multiPartFile, String documentIdentifier,Date documentDate, Long collateralRid);
	
	CollateralDocument saveCollateralDocument(File file, String documentIdentifier, Date documentDate, Long collateralRid);
	
	Collection<CollateralDocument> saveCollateralDocuments(Collection<MultipartFile> multiPartFiles, String documentIdentifier,Date documentDate, Long collateralRid);
	
	CollateralDocument savePolicyDocument(MultipartFile multipartFile, Long proofOfCoverageRid);
	
	Collection<CollateralDocument> savePolicyDocuments(Collection<MultipartFile> multipartFile, Long proofOfCoverageRid);
	
	List<MultipartFile> fetchAttachedDocuments(String BucketKey);
	
	CollateralDocument updateCollateralDocument(MultipartFile multiPartFile,CollateralDocument collateralDocument, String documentIdentifier,Date documentDate, Long collateralRid);

	CollateralDocument updateCollateralDocument(MultipartFile multiPartFile,CollateralDocument collateralDocument, String documentIdentifier,Date documentDate, Long collateralRid, Long proofOfCoverageRid);

	List<CollateralDoc> getCollateralDocs(Long collateralId, String docType);
	
	List<CollateralDoc> getPolicyDocs(Long proofOfCoverageRid, String docType);

	List<CollateralDocument> getCollateralDocument(List<MultipartFile> multipartFiles, Long collateralRid,	Long proofOfCoverageRid, Date documentDate, String documentIdentifier);

	void saveCollateralDocuments(List<CollateralDocument> collateralDocs);

	CollateralDocument saveCollateralDocument(File file, String documentIdentifier, Long proofOfCoverageRid);

	CollateralDoc getUniquePolicyDoc(Long proofOfCoverageRid, String docType);
	
}
