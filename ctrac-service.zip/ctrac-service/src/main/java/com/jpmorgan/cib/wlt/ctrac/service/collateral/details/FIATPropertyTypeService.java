package com.jpmorgan.cib.wlt.ctrac.service.collateral.details;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.SelectOption;

import java.util.List;

/**
 * Created by E704298 on 7/11/2017.
 */
public interface FIATPropertyTypeService {

    List<SelectOption> getPropertyTypesForDescription(String description);

}
