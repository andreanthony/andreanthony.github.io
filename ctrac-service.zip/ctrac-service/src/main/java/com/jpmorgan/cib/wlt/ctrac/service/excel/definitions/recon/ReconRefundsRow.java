package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon;

import java.math.BigDecimal;
import java.util.Date;

public class ReconRefundsRow {
	
	private String policyNumber;
	private String loanSystem;
	private String insuredName;
	private Date policyCancellationDate;
	BigDecimal refundAmount;
	
	public ReconRefundsRow(String policyNumber, String loanSystem, String insuredName, Date policyCancellationDate, BigDecimal refundAmount){
		this.policyNumber = policyNumber;
		this.loanSystem = loanSystem;
		this.insuredName = insuredName;
		this.policyCancellationDate = policyCancellationDate;
		this.refundAmount = refundAmount;
	}
	
	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getLoanSystem() {
		return loanSystem;
	}

	public void setLoanSystem(String loanSystem) {
		this.loanSystem = loanSystem;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public Date getPolicyCancellationDate() {
		return policyCancellationDate;
	}

	public void setPolicyCancellationDate(Date policyCancellationDate) {
		this.policyCancellationDate = policyCancellationDate;
	}

	public BigDecimal getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(BigDecimal refundAmount) {
		this.refundAmount = refundAmount;
	}
}
