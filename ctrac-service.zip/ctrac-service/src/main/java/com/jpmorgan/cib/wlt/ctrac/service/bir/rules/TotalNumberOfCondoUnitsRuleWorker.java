package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class TotalNumberOfCondoUnitsRuleWorker extends AbstractBIRRuleWorker {

	public TotalNumberOfCondoUnitsRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRRuleConclusionDTO totalNumberOfCondoUnitsConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if (!BIRRuleHelper.isCondoAssociationPolicy(borrowerInsuranceReviewData)) {
			birConclusion = BorrowerInsuranceReviewConclusion.NONE;
		} else if (coversAtLeastOneCondoUnit(borrowerInsuranceReviewData)) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
		}
		totalNumberOfCondoUnitsConclusion.setConclusion(birConclusion.name());
	}
	
	private boolean coversAtLeastOneCondoUnit(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		Long totalNumberOfCondoUnits = borrowerInsuranceReviewData.getTotalNumberOfCondoUnits();
		return totalNumberOfCondoUnits != null && totalNumberOfCondoUnits > 0;
	}

}
