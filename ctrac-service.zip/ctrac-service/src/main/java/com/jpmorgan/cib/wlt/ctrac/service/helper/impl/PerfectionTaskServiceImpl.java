package com.jpmorgan.cib.wlt.ctrac.service.helper.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.request.PerfectionTaskPublishEventRequest;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskUtil;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Component
public class PerfectionTaskServiceImpl implements PerfectionTaskService {

    public static final String SYSTEM = "SYSTEM";

    @Autowired
	private PerfectionTaskRepository perfectionTaskRepository;

	@Autowired
	PublishEventService publishEventService;

	@Override
	public PerfectionTask createOpenTask(WorkItem workItem, TaskState state, TMTaskType tmTaskType,
			Map<StateParameterType, Object> inputParameterMap) {
		return createTask(TaskStatus.OPEN, workItem, state, tmTaskType, SYSTEM, inputParameterMap);
	}
	
	@Override
	public PerfectionTask createSleepingTask(WorkItem workItem, TaskState state, TMTaskType tmTaskType,
			Map<StateParameterType, Object> inputParameterMap) {
		return createTask(TaskStatus.SLEEPING, workItem, state, tmTaskType, SYSTEM, inputParameterMap);
	}

	@Override
	public PerfectionTask createTransientTask(WorkItem workItem, TaskState state, TMTaskType tmTaskType,
			Map<StateParameterType, Object> inputParameterMap) {
		return createTask(TaskStatus.TRANSIENT, workItem, state, tmTaskType, SYSTEM, inputParameterMap);
	}

    @Override
    public PerfectionTask createTask(TaskStatus taskStatus, WorkItem workItem, TaskState state,
                                     TMTaskType tmTaskType, String insertedBy, Map<StateParameterType, Object> inputParameterMap) {
	    return createTask(taskStatus, workItem, state, tmTaskType, insertedBy, false, inputParameterMap);
    }

    @Override
    public PerfectionTask closeTask(PerfectionTask perfectionTask, WorkflowStateDefinition workflowStateDefinition) {
	    return closeTask(perfectionTask, workflowStateDefinition, false, null, null);
    }

    @Override
    public PerfectionTask closeTask(PerfectionTask perfectionTask, WorkflowStateDefinition workflowStateDefinition, String closeReason, String comments) {
        return closeTask(perfectionTask, workflowStateDefinition, false, closeReason, comments);
    }

    @Override
    public PerfectionTask closeTask(PerfectionTask perfectionTask, boolean andFlush) {
        return closeTask(perfectionTask, null, andFlush, null, null);
    }

    @Override
    public PerfectionTask saveTask(PerfectionTask perfectionTask, boolean andFlush) {
        return saveAndAuditPerfectionTask(perfectionTask, andFlush, null);
    }

    @Override
    public PerfectionTask saveTask(PerfectionTask perfectionTask) {
        return saveAndAuditPerfectionTask(perfectionTask, false, null);
    }

    @Override
    public PerfectionTask closeTask(PerfectionTask perfectionTask, WorkflowStateDefinition workflowStateDefinition, boolean andFlush, String closeReason, String comments) {
        perfectionTask.setCloseReason(closeReason);
        perfectionTask.setCloseReasonComments(comments);
        perfectionTask.setTaskStatus(TaskStatus.CLOSED.name());
        if(workflowStateDefinition != null) {
            perfectionTask.setWorkflowStep(workflowStateDefinition.getName());
        }
        perfectionTask = saveAndAuditPerfectionTask(perfectionTask, andFlush, CollateralEventType.TRANSITIONED);
        return perfectionTask;
    }

    @Override
    public PerfectionTask createTask(TaskStatus taskStatus, WorkItem workItem, TaskState state,
                                     TMTaskType tmTaskType, String insertedBy, boolean andFlush, Map<StateParameterType, Object> inputParameterMap) {
		PerfectionTask perfectionTask = instantiateTask(taskStatus, workItem, state, tmTaskType, insertedBy, inputParameterMap);
        perfectionTask = saveAndAuditPerfectionTask(perfectionTask, andFlush, CollateralEventType.CREATED);
		return perfectionTask;
	}

    PerfectionTask instantiateTask(TaskStatus taskStatus, WorkItem workItem, TaskState state,
                     TMTaskType tmTaskType, String insertedBy, Map<StateParameterType, Object> inputParameterMap){
	    return PerfectionTaskUtil.instantiate(
                taskStatus, workItem, state, tmTaskType, insertedBy, inputParameterMap);
    }

    @Override
    @Transactional
    public List<PerfectionTask> saveTasks(List<PerfectionTask> perfectionTasksToSave) {
        for(PerfectionTask perfectionTask: perfectionTasksToSave){
            publishPerfectionTaskEvent(perfectionTask, null);
        }
        return perfectionTaskRepository.save(perfectionTasksToSave);
    }

    @Transactional
    protected PerfectionTask saveAndAuditPerfectionTask(PerfectionTask perfectionTask, boolean andFlush, CollateralEventType collateralEventType) {
        publishPerfectionTaskEvent(perfectionTask, collateralEventType);
	    if (andFlush) {
            perfectionTask = perfectionTaskRepository.saveAndFlush(perfectionTask);
        } else {
            perfectionTask = perfectionTaskRepository.save(perfectionTask);
        }
        return perfectionTask;
    }

    protected void publishPerfectionTaskEvent(PerfectionTask perfectionTask, CollateralEventType collateralEventType) {
	    if(perfectionTask.hasChanged()) {
            Long collateralRid = null;
            String lineOfBusiness = null;
            Collateral collateral = getCollateralFromPerfectionTask(perfectionTask);
            if (collateral != null) {
                collateralRid = collateral.getRid();
                lineOfBusiness = collateral.getPreferredLoanLOB();
            }
            publishEventService.publishPerfectionTaskEvent(new PerfectionTaskPublishEventRequest(perfectionTask,
                            collateralRid, lineOfBusiness).forCollateralEventType(collateralEventType));
            perfectionTask.resetLoadTimeValues();
        }
    }

    @Override
    public Collateral getCollateralFromPerfectionTask(PerfectionTask perfectionTask) {
        WorkItem workItem = perfectionTask.getWorkItem();
        if (workItem != null) {
            if (!CollectionUtils.isEmpty(workItem.getCollateralWorkItems())) {
                return workItem.getCollateralWorkItems().get(0).getCollateral();
            } else if (!CollectionUtils.isEmpty(workItem.getProofOfCovWorkItems())) {
                return workItem.getProofOfCovWorkItems().get(0).getProofOfCoverage().getProvidedCoverages()
                        .get(0).getInsurableAsset().getBuilding().getCollateral();
            }
        }
        return null;
    }

	@Override
    public List<PerfectionTask> findTasksForWorkItem(WorkItem workItem, List<String> workflowSteps, List<String> taskStatuses) {
        return perfectionTaskRepository.findByWorkItemAndWorkflowStepInAndTaskStatusIn(workItem, workflowSteps, taskStatuses);
    }
}
