package com.jpmorgan.cib.wlt.ctrac.service.event.service;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.EventDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.request.PublishEventRequest;
import com.jpmorgan.cib.wlt.ctrac.service.event.store.client.CollateralEventSection;

import java.util.Date;
import java.util.UUID;

public interface PublishEventService {
    void publishCollateralEvent(CollateralDto collateralDto, CollateralEventType eventType, CollateralEventSection collateralSection);
    void publishLoanBorrowerEvent(LoanData loanData, Long collateralID, CollateralEventType eventType, CollateralEventSection collateralSection);
    void publishBIProofOfCoverageEvent(PublishEventRequest publishRequest);
    void publishLPProofOfCoverageEvent(PublishEventRequest publishRequest);
    void publishSFHDFEvent(String identifier, Long collateralRid, String lineOfBusiness, CollateralEventType eventType, String userName, String dateOfDetermination);
    void publishPerfectionTaskEvent(PublishEventRequest publishRequest);
    void publishRequiredFloodCoverageAmountEvent(String identifier,Long collateralRid, String lineOfBusiness,String description,CollateralEventType eventType);
    void publishEvent(EventDTO eventDTO);
    void republishEvent(UUID eventUuid);
    void republishEvents(Date fromDate, Date toDate);
}
