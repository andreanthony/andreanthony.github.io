package com.jpmorgan.cib.wlt.ctrac.service.helper;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LenderPlaceReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DefaultDateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.FloodInsuranceDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import org.apache.commons.lang.time.DateUtils;
import org.joda.time.DateTime;

import java.math.BigDecimal;
import java.util.*;

public class LPGapAndLapseUtil {

    private static final com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    private static final int CHAINED_POLICIES_LIMIT = 3;

    /*
       Find and return the earlest of all Borrower policies that have
       either effective, or cancellation, or expiration date after given LP policy effective date,
       including Active Applications and Binders that have effective date after given LP policy effective date
    */
    public static ProofOfCoverage populateDateLapse(Collection<ProofOfCoverage> borrowerPolicies, ProofOfCoverageDTO lpPolicy) {
        Map<Date, ProofOfCoverage> lapseDateMap = buildLapseDateMap(borrowerPolicies, lpPolicy.getEffectiveDate_());
        if (!lapseDateMap.keySet().isEmpty()) {
            Date earliestLapseDate = lapseDateMap.keySet().iterator().next();
            if(lpPolicy.getExpirationDate_() == null || earliestLapseDate.before(lpPolicy.getExpirationDate_())) {
                lpPolicy.setExpirationDate(DATE_FORMATTER.print(earliestLapseDate));
                return lapseDateMap.get(earliestLapseDate);
            }
        }
        return null;
    }

    public static Map<Date, ProofOfCoverage> buildLapseDateMap(Collection<ProofOfCoverage> borrowerPolicies, Date lpEffectiveDate) {
        // HashMap will not have duplicate keys
        Map<Date, ProofOfCoverage> lapseDateMap = new HashMap<>();
        for (ProofOfCoverage policy : borrowerPolicies) {
            Date lapseDate = getPolicyLapseDate(policy, lpEffectiveDate);
            if (lapseDate != null) {
                lapseDateMap.put(lapseDate, policy);
            }
        }
        // Sorting the map by date
        return new TreeMap<>(lapseDateMap);
    }

    private static Date getPolicyLapseDate(ProofOfCoverage policy, Date lpEffectiveDate) {
        if (policy.getPolicyType_().isPolicy()) {
            if (policy.getEffectiveDate().after(lpEffectiveDate)) {
                return policy.getEffectiveDate();
            }
            else if (policy.getCancellationEffectiveDate() != null && policy.getCancellationEffectiveDate().after(lpEffectiveDate)) {
                return policy.getCancellationEffectiveDate();
            }
            else if (PolicyStatus.EXPIRED.equals(policy.getPolicyStatus_()) && policy.getExpirationDate().after(lpEffectiveDate)) {
                return policy.getExpirationDate();
            }
        }
        else if (policy.getPolicyType_().isApplicationOrBinder() && policy.getPolicyStatus_().isActive(false) &&
                policy.getEffectiveDate().after(lpEffectiveDate)) {
            return policy.getEffectiveDate();
        }
        return null;
    }
    /*
    if lapse policy continues with another Lp policy the same amount and coverage type (eff date2 = expir date1), they can be combined
     */
    public static void combineChainedLPs(Collection<FloodInsuranceDTO> lpPolicies) {
        List<FloodInsuranceDTO> lpPoliciesSorted = new ArrayList<>(lpPolicies);
        Collections.sort(lpPoliciesSorted, new EffectiveDateComparator());
        Collection<FloodInsuranceDTO> removedLps = new ArrayList<>();
        // all policies sorted by effective date
        for (FloodInsuranceDTO lpPolicy : lpPoliciesSorted) {
            if(!removedLps.contains(lpPolicy)) {
                List<FloodInsuranceDTO> matchingLpPolicies = findMatchingPolicies(lpPolicy, lpPoliciesSorted);
                List<FloodInsuranceDTO> overlappingLps = findOverlappingLps(lpPolicy, matchingLpPolicies);
                matchingLpPolicies.removeAll(overlappingLps);
                removedLps.addAll(overlappingLps);
                FloodInsuranceDTO chainedLp = findChainedLp(lpPolicy, matchingLpPolicies);
                int count = 0;
                while (chainedLp != null && count++ < CHAINED_POLICIES_LIMIT) {
                    combineChainedLp(lpPolicy, chainedLp);
                    removedLps.add(chainedLp);
                    matchingLpPolicies.remove(chainedLp);
                    //now lpPolicy has a different expiration date - find next chained policy
                    chainedLp = findChainedLp(lpPolicy, matchingLpPolicies);
                }
            }
        }
        lpPolicies.removeAll(removedLps);
    }

    private static List<FloodInsuranceDTO> findOverlappingLps(FloodInsuranceDTO lpPolicy, List<FloodInsuranceDTO> lpPolicies) {
        List<FloodInsuranceDTO> overlappingLpPolicies = new ArrayList<>();
        for (FloodInsuranceDTO otherLp : lpPolicies) {
            if(ProofOfCoverage.isEffectiveOn(lpPolicy.getEffectiveDate_(), lpPolicy.getExpirationDate_(), otherLp.getEffectiveDate_())){
                overlappingLpPolicies.add(otherLp);
            }
        }
        return overlappingLpPolicies;
    }

    private static List<FloodInsuranceDTO> findMatchingPolicies(FloodInsuranceDTO lpPolicy, List<FloodInsuranceDTO> lpPolicies) {
        List<FloodInsuranceDTO> matchingLpPolicies = new ArrayList<>();
        BigDecimal lpPolicyAmount = getProvidedCoverageAmount(lpPolicy);
        for (FloodInsuranceDTO otherLp : lpPolicies) {
            if (lpPolicy != otherLp &&
                    lpPolicy.getCoverageType().equals(otherLp.getCoverageType()) &&
                    lpPolicyAmount.equals(getProvidedCoverageAmount(otherLp))) {
                matchingLpPolicies.add(otherLp);
            }
        }
        return matchingLpPolicies;
    }

    /*
    lpPolicy is lapse, chained Lp is either full LP or gap
    Expiration date of lpPolicy is extended to the chained policy expiration date, or 1 year whichever is earlier
    if lpPolicy becomes a year-long, changing it from lapse to gap
     */
    private static void combineChainedLp(FloodInsuranceDTO lpPolicy, FloodInsuranceDTO chainedLp) {
        Date expDate = new DateTime(lpPolicy.getEffectiveDate_()).plusYears(1).toDate();
        if (chainedLp.getExpirationDate_().after(expDate)) {
            //converting lapse lp into gap, and extending to year-long
            lpPolicy.setExpirationDate(DATE_FORMATTER.print(expDate));
            lpPolicy.setLenderPlaceReason(LenderPlaceReason.BORROWER_POLICY_RECEIVED_AMOUNT_GAP);
        }
        else {
            //extending lapse policy to the later expiration date
            lpPolicy.setExpirationDate(DATE_FORMATTER.print(chainedLp.getExpirationDate_()));
        }
    }

    /*
    if lpPolicy is lapse, find "chained" Lp policy (eff date = lapse expir date) with the same amount and coverage type
     */
    private static FloodInsuranceDTO findChainedLp(FloodInsuranceDTO lpPolicy, Collection<FloodInsuranceDTO> lpPolicies) {
        if(LenderPlaceReason.BORROWER_POLICY_RECEIVED_DATE_LAPSE.equals(lpPolicy.getLenderPlaceReason())) {
            for (FloodInsuranceDTO otherLp : lpPolicies) {
                if (DateUtils.isSameDay(lpPolicy.getExpirationDate_(), otherLp.getEffectiveDate_())) {
                    return otherLp;
                }
            }
        }
        return null;
    }

    private static BigDecimal getProvidedCoverageAmount(ProofOfCoverageDTO proofOfCoverageDTO){
        return AmountFormatter.parse(proofOfCoverageDTO.getProvidedCoverageDTOs().get(0).getCoverageDetailsDTO().getCoverageAmount());
    }
    private static class EffectiveDateComparator implements Comparator<ProofOfCoverageDTO> {
        @Override
        public int compare(ProofOfCoverageDTO proofOfCoverage1, ProofOfCoverageDTO proofOfCoverage2) {
            //CancellationEffectiveDate is never null on cancelled policies
            return proofOfCoverage1.getEffectiveDate_().compareTo(proofOfCoverage2.getEffectiveDate_());
        }
    }

}
