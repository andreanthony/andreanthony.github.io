package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.FloodDetermination;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ActiveCollateralWorkflowRelation;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.FloodInsuranceRenewalService;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.ExternallyAgentedWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.ReviewCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMTaskDataParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralWorkflowParam;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.store.client.CollateralEventSection;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskBuilder;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.CollateralCoverageComputationService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TaskUniqueIdGenerator;
import com.jpmorgan.cib.wlt.ctrac.service.workflow.WorkflowRuleEvaluatorFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction.EDIT;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction.VERIFY;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus.*;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.*;

@Service(value = "collateralWorkflowService")
public class CollateralWorkflowServiceImpl implements CollateralWorkflowService {

	private static final Logger logger = Logger.getLogger(CollateralWorkflowServiceImpl.class);
	private static final int REMAP_TASK_UNIQUE_ID_LENGTH = 6;

	static final List<String> BORROWER_RENEWAL_WORKFLOW_STEPS = Arrays.asList(
            CALL_OR_EMAIL_AGENT_1ST_NOTICE.getName(),
            CALL_OR_EMAIL_AGENT_2ND_NOTICE.getName(),
            CALL_OR_EMAIL_AGENT_3RD_NOTICE.getName(),
            SEND_LEAD_BANK_EMAIL_1ST_NOTICE_STATE.getName(),
            SEND_LEAD_BANK_EMAIL_2ND_NOTICE_STATE.getName(),
            SEND_LEAD_BANK_EMAIL_3RD_NOTICE_STATE.getName(),
            SEND_MARKET_RENEWAL_EMAIL.getName());

	@Autowired private ActiveCollateralWorkflowRelationRepository activeCollateralWorkflowRelationRepository;

	@Autowired private ActivePolicyService activePolicyService;

	@Autowired private CollateralRepository collateralRepository;

	@Autowired private CollateralWorkItemRepository collateralWorkItemRepository;

	@Autowired private DateCalculator dateCalculator;

    @Autowired private ExternallyAgentedWorkflowService externallyAgentedWorkflowService;

	@Autowired private FloodDeterminationRepository floodDeterminationRepository;

	@Autowired @Qualifier("floodInsuranceRenewalService")
	private FloodInsuranceRenewalService floodInsuranceRenewalService;

	@Autowired private LoanService loanService;

	@Autowired private OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher;

	@Autowired private TMService tmService;

	@Autowired private PerfectionTaskRepository perfectionTaskRepository;

	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;

	@Autowired private ReviewCollateralService reviewCollateralService;

	@Autowired private TaskService taskService;
	@Autowired private PerfectionTaskService perfectionTaskService;

	@Autowired private WorkItemRepository workItemRepository;

	@Autowired private CollateralCoverageComputationService collateralCoverageComputationService;

	@Autowired private CollateralDetailsStatusService collateralDetailsStatusService;

	@Autowired private LoanManagementService loanManagementService;

	@Autowired private CollateralManagementService collateralManagementService;
	@Autowired private PublishEventService publishEventService;
	@Autowired private ProofOfCovWorkItemRepository proofOfCovWorkItemRepository;
	@Autowired private WorkflowRuleEvaluatorFactory workflowRuleEvaluatorFactory;

	@Override
	@Transactional
	public void initiateVerifyCollateralWorkflow(Long collateralRid, PerfectionItemSubType perfectionItemSubType,TMParams tmParams) {
		logger.debug("initiateVerifyCollateralWorkflow: START");
		try {
		Collateral collateral = collateralRepository.findOne(collateralRid);
		WorkItem workItem = getOrCreatePendingReviewCollateralWorkItem(collateralRid, PerfectionItemSubType.COLLATERAL);
		if (!checkCollateralTaskExists(collateral, VERIFY_COLLATERAL.getName())) {
			tmService.createTask(TMTaskType.FLOOD_INSURANCE, workItem,VERIFY_COLLATERAL.getFloodRemapTaskState());
		}else{
			amendCollateralTaskIfExists(collateral.getRid(), VERIFY_COLLATERAL,tmParams);
		}
		logger.debug("initiateVerifyCollateralWorkflow: END");
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
		}
	}

	@Transactional
	protected void amendCollateralTaskIfExists(Long collateralRid, WorkflowStateDefinition definition, TMParams tmParam) {
		logger.debug("amendCollateralTaskIfExists: START");
		Collateral collateral = collateralRepository.findOne(collateralRid);
		if (checkCollateralTaskExists(collateral, definition.getName())) {
			updateTaskFields(collateral, definition.getName(),tmParam);
		}
		logger.debug("amendCollateralTaskIfExists: END");
	}

	private void updateTaskFields(Collateral collateral, String workflowState,TMParams tmParam) {
		try {
			logger.debug("updateTaskFields: START");
			List<ActiveCollateralWorkflowRelation> activeList = activeCollateralWorkflowRelationRepository
					.findByCollateralAndTaskWorkflowStep(collateral, workflowState);
			
			if (tmParam != null && CollectionUtils.isNotEmpty(activeList) &&activeList.size() == 1 ) {
				PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(activeList.get(0).getTaskId());
				tmService.helperPageAmendTask(perfectionTask,tmParam);
			}else{
				if (CollectionUtils.isNotEmpty(activeList)) {
					for(ActiveCollateralWorkflowRelation activeVerifyRelation:activeList ){
						PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(activeVerifyRelation.getTaskId());
						tmService.amendTask(perfectionTask);
					}
				}
			}
			logger.debug("updateTaskFields: END");
		}catch (Exception ex) {
				//logger.error("Error in creating the task.", ex);
				throw new CTracApplicationException("E0352", CtracErrorSeverity.APPLICATION, ex);
		}
	}

    @Override
	@Transactional
	public void completeVerifyCollateralWorkflow(final CollateralWorkflowParam param) {
		if (param == null || param.getCollateralDto() == null || param.getCollateralDto().getRid() == null) {
			return;
		}
		Collateral collateral = collateralRepository.findOne(param.getCollateralDto().getRid());
		if (collateral == null) {
			logger.debug("No collateral found for RID=" + param);
			return;
		}
		List<ActiveCollateralWorkflowRelation> activeList =
				activeCollateralWorkflowRelationRepository.findByCollateralAndTaskWorkflowStep(collateral, VERIFY_COLLATERAL.getName());
		if (activeList == null) {
			logger.warn("Returned null");
		} else {
			logger.info("Number of tasks=" + activeList.size());
			for (ActiveCollateralWorkflowRelation activeVerifyRelation:activeList) {
				try {
					final PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(activeVerifyRelation.getTaskId());
					taskService.completeWorkFlowStepOperations(new HashMap<StateParameterType, Object>() {
						private static final long serialVersionUID = 3730853052500920723L; {
							put(StateParameterType.PERFECTION_TASK, perfectionTask);
							put(StateParameterType.TM_PARAMS, param.getTmParams());
						}
					});
				} catch (Exception e) {
					// TODO proper handleling of the exception. shouldn't blow everything
					logger.error(e.getMessage(), e);
				}
			}
		}
		adjustWorkflow(param.getCollateralDto().getRid());
	}

	public void adjustWorkflow(Long collateralRid) {
		if (collateralRid == null) return;
		adjustRequestRequiredCoverageWorkflow(collateralRid);
		// add other workflow could be impacted...
	}

	public void adjustRequestRequiredCoverageWorkflow(Long collateralRid) {
		if (collateralRid == null) return;
		boolean isSBAPath = collateralManagementService.isCollateralBusinessAssetSBAOnly(collateralRid);

		if (isSBAPath) {
			Set<PerfectionTask> fiatTasks = getFiatRequestasks(collateralRid);
			if (fiatTasks != null && !fiatTasks.isEmpty()) {
				changeThePathFromFiatToSBA(fiatTasks);
			}
		} else {
			Set<PerfectionTask> sbaTasks = getSBACoverageRequestTasks(collateralRid);
			if (sbaTasks != null && !sbaTasks.isEmpty()) {
				changeThePathFromSBAToFiat(sbaTasks);
			}
		}

	}

	private void changeThePathFromFiatToSBA(Set<PerfectionTask> fiatTasks){
		switchRequestRequiredCoverageTasks(fiatTasks, WorkflowStateDefinition.FIAT_NOT_RECEIVED, WorkflowStateDefinition.FIAT_REQUESTED, WorkflowStateDefinition.SBA_COVERAGE_NOT_RECEIVED, WorkflowStateDefinition.SBA_COVERAGE_REQUESTED);
	}

	private void changeThePathFromSBAToFiat(Set<PerfectionTask> sbaTasks){
		switchRequestRequiredCoverageTasks(sbaTasks, WorkflowStateDefinition.SBA_COVERAGE_NOT_RECEIVED, WorkflowStateDefinition.SBA_COVERAGE_REQUESTED, WorkflowStateDefinition.FIAT_NOT_RECEIVED, WorkflowStateDefinition.FIAT_REQUESTED);
	}

	private void switchRequestRequiredCoverageTasks(Set<PerfectionTask> oldTasks, WorkflowStateDefinition oldNotReceivedWorkflowstep
			, WorkflowStateDefinition oldRequestedWorkflowstep, WorkflowStateDefinition newNotReceivedWorkflowstep, WorkflowStateDefinition newRequestedWorkflowStep) {
		try {
			PerfectionTask newNotReceived = null;
	        PerfectionTask newRequested = null;
			for(PerfectionTask task: oldTasks){
				if(task.getWorkflowStep().equals(oldNotReceivedWorkflowstep.getName())){
					task.setWorkflowStep(newNotReceivedWorkflowstep.getName());
					newNotReceived = task;
				}
				if(task.getWorkflowStep().equals(oldRequestedWorkflowstep.getName())){
					task.setWorkflowStep(newRequestedWorkflowStep.getName());
					newRequested = task;
				}
			}
			perfectionTaskRepository.save(newRequested);
			if(newNotReceived != null){
				perfectionTaskRepository.save(newNotReceived);
				tmService.amendTask(newNotReceived);
			}
		} catch (Exception ex) {
				//logger.error("Error in creating the task.", ex);
				throw new CTracApplicationException("E0352", CtracErrorSeverity.APPLICATION, ex);
			}
	}
	protected void initFiatRequestWorkFlow(WorkItem workItem, Long collateralRid, PerfectionItemSubType perfectionItemSubType, TMTaskType TMTaskType, Date lpDueDate) {
		logger.info("createFiatRequestTask::BEGIN");
		//1.check if there is an active collateral item, if yes reuse the collateral item
		Set<PerfectionTask> fiatRequestTask = getFiatRequestasks(collateralRid);
		if(fiatRequestTask != null && fiatRequestTask.size() > 1){
			checkForDuplicateTasks(fiatRequestTask);
		}
		else if(fiatRequestTask != null && fiatRequestTask.size() == 1){
			PerfectionTask existingTask = fiatRequestTask.iterator().next();
			if(workItem instanceof FloodRemapItem){
				WorkItem collateralItem = existingTask.getWorkItem();
				collateralItem.setPerfectionSubType(perfectionItemSubType.name());
				workItemRepository.save(collateralItem);
			}
			linkCoverageRequestTaskWithWorkItem(existingTask,  workItem);
		}
		else{
		    CollateralItem collateralItem = workItem instanceof CollateralItem?  (CollateralItem) workItem : createCollateralWorkItem(collateralRid,perfectionItemSubType);
			Date fiatRequestTaskDueDate = workflowRuleEvaluatorFactory.createReqCoverageWorkflowEvaluator(FIAT_REQUESTED).getRequestTaskDueDate(lpDueDate);
			collateralItem.setLpDueDate(lpDueDate);
		    PerfectionTask fiatSystemTask = new PerfectionTaskBuilder(collateralItem, FIAT_REQUESTED.getName(),TaskStatus.TRANSIENT, "SYSTEM").executionDate(fiatRequestTaskDueDate).tmTaskType(TMTaskType).build();
            perfectionTaskService.saveTask(fiatSystemTask);
            linkCoverageRequestTaskWithWorkItem(fiatSystemTask, workItem);
            logger.debug("createFiatRequestTask::END New Fiat request task created: " + fiatRequestTaskDueDate);
		}
	}

	protected boolean checkForDuplicateTasks(Set<PerfectionTask> fiatRequestTask) {
		if(fiatRequestTask != null){
			Set<String> steps = new HashSet<String>();
			for (PerfectionTask perfectionTask : fiatRequestTask) {
				if(steps.contains(perfectionTask.getWorkflowStep())){
					logger.error(ErrorCodeToMessageConverter.convertToMessage("E0302", CtracErrorSeverity.CRITICAL));
					return true;
				}
				else {
					steps.add(perfectionTask.getWorkflowStep());
				}
			}
		}
		return false;
	}

	private void linkCoverageRequestTaskWithWorkItem(PerfectionTask fiatSystemTask, WorkItem workItem) {
		if(workItem instanceof FloodRemapItem){
			((FloodRemapItem) workItem).setCoverageRequestTaskRid(fiatSystemTask.getRid());
		}
		else if(workItem instanceof BorrowerCancelItem){
			((BorrowerCancelItem) workItem).setCoverageRequestTaskRid(fiatSystemTask.getRid());
		}
		workItemRepository.save(workItem);
	}

	@Override
	@Transactional
	public void initRequiredCoverageRequestWorkFlow(WorkItem workItem, Long collateralRid, PerfectionItemSubType perfectionItemSubType, TMTaskType TMTaskType, Date lpDueDate) {
		logger.info("initRequiredCoverageRequestWorkFlow::BEGIN");
		if (collateralManagementService.isCollateralBusinessAssetSBAOnly(collateralRid)) {
			initSBACoverageRequestWorkFlow(workItem, collateralRid, perfectionItemSubType, TMTaskType, lpDueDate);
		} else {
			initFiatRequestWorkFlow(workItem, collateralRid, perfectionItemSubType, TMTaskType, lpDueDate);
		}
		logger.info("initRequiredCoverageRequestWorkFlow::END");
	}

	private void initSBACoverageRequestWorkFlow(WorkItem workItem, Long collateralRid, PerfectionItemSubType perfectionItemSubType, TMTaskType TMTaskType, Date lpDueDate) {
		logger.info("initSBACoverageRequestWorkFlow::BEGIN");
		//1.check if there is an active collateral item, if yes reuse the collateral item
		Set<PerfectionTask> sbaCoverageRequestTask = getSBACoverageRequestTasks(collateralRid);
		if(sbaCoverageRequestTask != null && sbaCoverageRequestTask.size() > 1){
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0302", CtracErrorSeverity.CRITICAL));
		}
		else if(sbaCoverageRequestTask != null && sbaCoverageRequestTask.size() == 1){
			PerfectionTask existingTask = sbaCoverageRequestTask.iterator().next();
			if(workItem instanceof FloodRemapItem){
				WorkItem collateralItem = existingTask.getWorkItem();
				collateralItem.setPerfectionSubType(perfectionItemSubType.name());
				workItemRepository.save(collateralItem);
			}
			linkCoverageRequestTaskWithWorkItem(existingTask,  workItem);
		}
		else{
		    CollateralItem collateralItem = workItem instanceof CollateralItem?  (CollateralItem) workItem : createCollateralWorkItem(collateralRid,perfectionItemSubType);
			Date sbaCoverageRequestTaskDueDate = workflowRuleEvaluatorFactory.createReqCoverageWorkflowEvaluator(SBA_COVERAGE_REQUESTED).getRequestTaskDueDate(lpDueDate);
			collateralItem.setLpDueDate(lpDueDate);
		    PerfectionTask sbaCoverageSystemTask = new PerfectionTaskBuilder(collateralItem, SBA_COVERAGE_REQUESTED.getName(),TaskStatus.TRANSIENT, "SYSTEM").executionDate(sbaCoverageRequestTaskDueDate).tmTaskType(TMTaskType).build();
            perfectionTaskService.saveTask(sbaCoverageSystemTask);
            linkCoverageRequestTaskWithWorkItem(sbaCoverageSystemTask, workItem);
            logger.debug("initSBACoverageRequestWorkFlow::END New SBA Coverage request task created: " + sbaCoverageRequestTaskDueDate);
		}
	}

	@Override
	@Transactional
	public void cancelRequiredCoverageRequestWorkflow(Long collateralRid) {
		logger.info("cancelRequiredCoverageRequestWorkflow::BEGIN" + collateralRid);
		cancelSBACoverageRequestWorkflow(collateralRid);
		cancelFiatRequestWorkflow(collateralRid);
		logger.info("cancelRequiredCoverageRequestWorkflow::END");
	}

	private void cancelFiatRequestWorkflow(Long collateralRid) {
		try {
			logger.info("cancelFiatRequestTasks::BEGIN" + collateralRid);
			Set<PerfectionTask> fiatRequestWorkflowTasks = getFiatRequestasks(collateralRid);
			if (fiatRequestWorkflowTasks != null) {
				for (PerfectionTask perfectionTask : fiatRequestWorkflowTasks) {
					tmService.cancelTask(perfectionTask);
				}
			}
			logger.info("cancelFiatRequestTasks::END");
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
		}
	}

	private void cancelSBACoverageRequestWorkflow(Long collateralRid) {
		try {
			logger.info("cancelSBACoverageRequestWorkflow::BEGIN" + collateralRid);
			Set<PerfectionTask> sbaCoverageRequestWorkflowTasks = getSBACoverageRequestTasks(collateralRid);
			if (sbaCoverageRequestWorkflowTasks != null) {
				for (PerfectionTask perfectionTask : sbaCoverageRequestWorkflowTasks) {
					tmService.cancelTask(perfectionTask);
				}
			}
			logger.info("cancelSBACoverageRequestWorkflow::END");
		} catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		} catch (Exception ex) {			
			throw new CTracApplicationException("E0146", CtracErrorSeverity.APPLICATION, ex);
		}
	}

	@Transactional
	public void cancelCollateralWorkflow(Long collateralRid) {

		logger.info("cancelCollateralWorkflow::BEGIN" + collateralRid);

		WorkItem workItem = getVerifyCollateralWorkItem(collateralRid);

		if (workItem != null) {
			Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
			inputParameterMap.put(StateParameterType.WORK_ITEM, workItem);
			taskService.abortWorkflow(inputParameterMap, "Collateral is deleted.");
		}

		logger.info("cancelCollateralWorkflow::END");
	}

	@Override
	public void completeRequiredCoverageRequestWorkflow(Set<PerfectionTask> tasks) {

		logger.info("completeFiatRequestWorkflow::BEGIN: task size " + tasks.size());

		for (final PerfectionTask perfectionTask : tasks) {

			if (!TaskStatus.CLOSED.name().equals(perfectionTask.getTaskStatus())) {

				logger.info("completing task " + perfectionTask.getTmTaskId() + " status "
						+ perfectionTask.getTaskStatus());

				Map<StateParameterType, Object> workflowData = new HashMap<StateParameterType, Object>() {
					{
						put(StateParameterType.WORK_ITEM, perfectionTask.getWorkItem());
						put(StateParameterType.PERFECTION_TASK, perfectionTask);
					}
				};

				taskService.completeWorkFlowStepOperations(workflowData);
			}

		}
		logger.info("completeFiatRequestWorkflow::BEGIN");

	}

	@Transactional
	public CollateralItem getOrCreatePendingReviewCollateralWorkItem(Long collateralRid, PerfectionItemSubType perfectionItemSubType){

	    CollateralItem collateralItem = getActiveCollateralItem(collateralRid, Arrays.asList(WorkflowStateDefinition.REVIEW_COLLATERAL.getName()
	    		,WorkflowStateDefinition.VERIFY_COLLATERAL.getName() ));

		if (collateralItem == null || perfectionItemSubType != collateralItem.getPerfectionSubType_() ) {
			collateralItem = createCollateralWorkItem(collateralRid, perfectionItemSubType);
		}
		return collateralItem;
	}


	@Transactional
	public CollateralItem createCollateralWorkItem(Long collateralID, PerfectionItemSubType perfectionItemSubType) {
		Collateral collateral = collateralRepository.findOne(collateralID);
		CollateralItem workItem = new CollateralItem();
		workItem.setIndHoldWorflow("Y");
		workItem.setWorkFlowID(TaskUniqueIdGenerator.generateAlphaNumericUniqueId(REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher));
		workItem.setInitiationDate(dateCalculator.getCurrentReferenceDate());
		workItem.setPerfectionType(PerfectionItemType.COLLATERAL.name());
		workItem.setPerfectionSubType(perfectionItemSubType.name());
		workItem.setInitialAuditInfo("SYSTEM");
		workItem.addCollateral(collateral);
		workItem = workItemRepository.save(workItem);
		collateral.addWorkItem(workItem);
		collateralRepository.save(collateral);
		return workItem;
	}

	@Transactional
	@Override
	public void triggerCollateralWorkflow(CollateralWorkflowParam param){
    	logger.debug("triggerCollateralWorkflow::BEGIN");
		if (param == null) {
			return;
		}
		CollateralDto collateralDto = param.getCollateralDto();
		CollateralStatus collateralStatus = param.getCollateralDto().getCollateralStatus();
		if (param.getAction() == EDIT && collateralStatus == PLEDGED) {
			initiateVerifyCollateralWorkflow(collateralDto.getRid(), PerfectionItemSubType.COLLATERAL,param.getTmParams());
		} else if (param.getAction() == VERIFY) {

			if (collateralStatus == DRAFT && param.isAllVerified()) {
				moveCollateralToStatus(collateralDto,PLEDGED);
				publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.COLLATERAL_PLEDGED, CollateralEventSection.COLLATERAL);
			}

			if (collateralStatus == PLEDGED && param.isReadyForRelease()) {
				moveCollateralToStatus(collateralDto,RELEASED);
				publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.COLLATERAL_RELEASED, CollateralEventSection.COLLATERAL);
				completeVerifyCollateralWorkflow(param);
			}else if (param.isAllVerified()) {
				completeVerifyCollateralWorkflow(param);
			}else if(collateralStatus == PLEDGED){
				amendCollateralTaskIfExists(collateralDto.getRid(), VERIFY_COLLATERAL, param.getTmParams());
			}

			/**
			 * if we are releasing the collateral anytime in the future, call c3
			 * also isReadyForCoverageComputation is true when zone changed from in to out
			 */
			//Refetch as collateralStatus might have changed
			collateralStatus = param.getCollateralDto().getCollateralStatus();
			if(CollateralStatus.RELEASED == collateralStatus || param.isReadyForCoverageComputation()){
				try{
			    	triggerInsuranceCoverageEvaluation(null, collateralDto);
		    	}catch(Exception e){
		    		 logger.error(e.getMessage(), e);
		    	}
			}

		}
		logger.debug("triggerCollateralWorkflow::END");
	}

	@Transactional
	@Override
	public void triggerInsuranceCoverageEvaluation(Long workItemRid, CollateralDto collateralDto, Long cancelledRorrowerPolicyRid) {
		CoverageActionRequest coverageActionRequest= new CoverageActionRequest(collateralDto.getRid(), workItemRid,  null, cancelledRorrowerPolicyRid);
		CoverageActionResult coverageActionResult= collateralCoverageComputationService.evaluateInsuranceCoverageActions(coverageActionRequest);
		collateralCoverageComputationService.applyInsuranceCoverageActions(coverageActionResult, null);
	}


	@Transactional
	@Override
	public void triggerInsuranceCoverageEvaluation(Long workItemRid, CollateralDto collateralDto) {
		triggerInsuranceCoverageEvaluation(workItemRid, collateralDto, null);
	}

	private boolean checkCollateralTaskExists(Collateral collateral, String workflowState) {
		boolean taskAvailable = false;
		List<ActiveCollateralWorkflowRelation> activeList = activeCollateralWorkflowRelationRepository
				.findByCollateralAndTaskWorkflowStep(collateral, workflowState);

		if (CollectionUtils.isNotEmpty(activeList)) {
			return true;
		}
		return taskAvailable;
	}

	@Transactional
	@Override
	public CollateralItem getActiveCollateralItem(Long collateralRid, List<String> workflowSteps){
		List<ActiveCollateralWorkflowRelation> collateralWorkItems =
				activeCollateralWorkflowRelationRepository.findByCollateralRidAndTaskWorkflowStepIn(collateralRid,workflowSteps);
		return !collateralWorkItems.isEmpty() ? collateralWorkItems.get(0).getCollateralItem() : null;
	}

	private void moveCollateralToStatus(CollateralDto collateralDto,CollateralStatus collateralStatus){
		collateralDto.setCollateralStatus(collateralStatus);
		Collateral collateral = collateralRepository.findOne(collateralDto.getRid());
		collateral.setCollateralStatus(collateralStatus.name());
		collateralRepository.save(collateral);
	}

	@Override
    @Transactional
    public void initiatePolicyRenewalWorkflow(ProofOfCoverage proofOfCoverage, PerfectionItemSubType perfectionItemSubType, WorkflowStateDefinition workFlowStepState, List<WorkflowStateDefinition> avoidIfExistingworkFlowStep) {
		Set<Collateral> collaterals = getQualifiedCollaterals(proofOfCoverage);
		if (CollectionUtils.isEmpty(collaterals)) {
			logger.info("Policy # " + proofOfCoverage.getPolicyNumber() + " id " + proofOfCoverage.getRid() + " cannot be renewed because no qualified collaterals are found");
			return;
		}

        initiateRenewalWorkflows(proofOfCoverage, workFlowStepState, avoidIfExistingworkFlowStep, collaterals);

        updatePolicyAsRenewalStarted(proofOfCoverage, loanService.hasExternallyAgented(collaterals));

		proofOfCoverageRepository.saveAndFlush(proofOfCoverage);
	}

    private void updatePolicyAsRenewalStarted(ProofOfCoverage proofOfCoverage, boolean isExternallyAgented) {
        if (isExternallyAgented) {
	        activePolicyService.setAllPolicyStatuses(proofOfCoverage, PolicyStatus.EXPIRING_EA);
        } else {
	        reviewCollateralService.initiateReadyForLP(proofOfCoverage.getRid());
	        activePolicyService.setAllPolicyStatuses(proofOfCoverage, PolicyStatus.EXPIRING);
        }

        proofOfCoverage.setIndRenewal("Y");
        if (proofOfCoverage.getLpAction_() != LPActions.PENDING_C3) {
            proofOfCoverage.setLpAction(null);
        }
    }

    private Set<Collateral> getQualifiedCollaterals(ProofOfCoverage proofOfCoverage) {
		// is the proof of coverage in a state ready for renewal?
		if(!proofOfCoverage.isReadyForRenewal()){
            logger.info("Policy # "+proofOfCoverage.getPolicyNumber()+" id "+proofOfCoverage.getRid()+" cannot be renewed because is it not active or was already selected for renewal");
			return null;
        }

		// are the collaterals in a state ready for renewal?
		Set<Collateral> collaterals = proofOfCoverage.getInsuredCollaterals();
		if (CollectionUtils.isEmpty(collaterals)) {
            logger.info("Policy # "+proofOfCoverage.getPolicyNumber()+" id "+proofOfCoverage.getRid()+" cannot be renewed because is does not provide any coverage");
			return null;
        }
		if (includesDraftCollateral(collaterals) || includesUnverifiedSections(collaterals)) {
            logger.info("Policy # "+proofOfCoverage.getPolicyNumber()+" id "+proofOfCoverage.getRid()+" cannot be renewed because there is a pending or draft collateral");
			return null;
        }

		// remove unqualified collaterals
		if (loanService.hasExternallyAgented(collaterals)) {
            externallyAgentedWorkflowService.removeExternallyAgentedCollateralsNotReady(collaterals, proofOfCoverage);
        }
		removeCollateralsUnqualifiedForWorkfow(collaterals);
		return collaterals;
	}

	public void createSleepingCollateralTasks(List<TMTaskDataParams> tmTaskDataParams, ProofOfCoverage policy) {
		for (TMTaskDataParams tmTaskDataParam : tmTaskDataParams) {
			Map<StateParameterType, Object> inputParameterMap = new EnumMap<>(StateParameterType.class);
			inputParameterMap.put(StateParameterType.PROOF_OF_COVERAGE, policy);
			perfectionTaskService.createSleepingTask(tmTaskDataParam.getWorkItem(),
					tmTaskDataParam.getFloodRemapItemState().getFloodRemapTaskState(),
					tmTaskDataParam.getTmTaskType(),
					inputParameterMap);
		}
	}

	public void createCollateralTasks(ProofOfCoverage proofOfCoverage, List<TMTaskDataParams> tmTaskDataParams) {
      try {
		Set<WorkItem> triggerItems = new HashSet<>();
		for (TMTaskDataParams tmTaskDataParam : tmTaskDataParams) {
			tmService.createTask(
					tmTaskDataParam.getTmTaskType(), tmTaskDataParam.getWorkItem(),
					tmTaskDataParam.getFloodRemapItemState().getFloodRemapTaskState());
			triggerItems.add(tmTaskDataParam.getWorkItem());
		}
		proofOfCoverage.addAllItems(triggerItems, ProofOfCoverageWorkItemRelationType.COLLATERAL_TO_POLICY);
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
		}
	}



    private void initiateRenewalWorkflows(ProofOfCoverage proofOfCoverage, WorkflowStateDefinition workFlowStepState, List<WorkflowStateDefinition> avoidIfExistingworkFlowStep, Set<Collateral> collaterals) {
        List<TMTaskDataParams> tmTaskDataParams = new ArrayList<>();
        for (Collateral collateral : collaterals) {
            try {
                initiateCollateralWorkflow(collateral, PerfectionItemSubType.FLOOD_RENEWAL, workFlowStepState, tmTaskDataParams, avoidIfExistingworkFlowStep);
                if (proofOfCoverage.getPolicyType_().isLenderPlaced()) {
                    floodInsuranceRenewalService.initSendPreRenewalLetter(proofOfCoverage, collateral);
                }
            } catch (Exception exp) {
                logger.error("\n Error occured while initiatiating Collateral workflow for Collateral.RID=" + collateral.getRid()
                        + " covered by the policy " + proofOfCoverage.getRid());
                logger.error(exp.getMessage(), exp);
                logger.error(ErrorCodeToMessageConverter.convertToMessage("E0153", CtracErrorSeverity.CRITICAL));
                throw new CTracApplicationException("E0189", CtracErrorSeverity.CRITICAL);
            }
        }
        createCollateralTasks(proofOfCoverage, tmTaskDataParams);
        if (proofOfCoverage.getPolicyType_().isBorrowerPolicy()) {
            floodInsuranceRenewalService.initBorrowerRenewalWorkFlow(proofOfCoverage);
        }
    }

    public void initiateCollateralWorkflow(Collateral collateral, PerfectionItemSubType perfectionItemSubType, WorkflowStateDefinition workFlowStepState, List<TMTaskDataParams> tmTaskDataParams, List<WorkflowStateDefinition> avoidIfExistingworkFlowStep) {
        if (checkTaskCreationEligibility(collateral, workFlowStepState, tmTaskDataParams, avoidIfExistingworkFlowStep)) {
            List<CollateralWorkItem> collateralWorkItems = collateralWorkItemRepository.findByCollateral(collateral);

            CollateralItem collateralItem = null;
            for (CollateralWorkItem collateralWorkItem : collateralWorkItems) {
                WorkItem workItem = collateralWorkItem.getWorkItem();
                if (workItem instanceof CollateralItem && (workItem.getPerfectionSubType_() == perfectionItemSubType)) {
                    collateralItem = CtracBaseEntity.deproxy(workItem, CollateralItem.class);
                    break;
                }
            }

            if (collateralItem == null) {
                collateralItem = new CollateralItem();
                collateralItem.setIndHoldWorflow("Y");
                collateralItem.setWorkFlowID(TaskUniqueIdGenerator.generateAlphaNumericUniqueId(REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher));
                collateralItem.setInitiationDate(dateCalculator.getCurrentReferenceDate());
                collateralItem.setPerfectionType(PerfectionItemType.COLLATERAL.name());
                collateralItem.setPerfectionSubType(perfectionItemSubType.name());
                collateralItem.setInitialAuditInfo("SYSTEM");
                collateralItem.addCollateral(collateral);
                collateralItem.setInitialAuditInfo("SYSTEM");
                collateralItem = workItemRepository.save(collateralItem);
            }

            // Check if there is already an open task
            tmTaskDataParams.add(new TMTaskDataParams(TMTaskType.FLOOD_INSURANCE, collateralItem, workFlowStepState, collateral.getRid()));

        }
    }

    @Override
    public boolean isFiatRequested(Long collateralRid){
    	Set<PerfectionTask> tasks = getFiatRequestasks(collateralRid);
    	return  tasks != null && tasks.size() > 0 ;
    }

    @Override
    public boolean isSBACoverageRequested(Long collateralRid){
    	Set<PerfectionTask> tasks = getSBACoverageRequestTasks(collateralRid);
    	return  tasks != null && tasks.size() > 0 ;
    }

    @Override
    public Date getFiatRequestedDate(Long collateralRid){
    	WorkItem collateralItem = getActiveCollateralItem(collateralRid, Arrays.asList(FIAT_REQUESTED.getName()));
    	if(collateralItem == null){
    		return null;
    	}
    	List<PerfectionTask> fiatRequestTasks = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(collateralItem,  FIAT_REQUESTED.getName(), TaskStatus.TRANSIENT.name());
		if(fiatRequestTasks !=null && fiatRequestTasks.size() > 0){
			return fiatRequestTasks.get(0).getInsertedDate();
		}
    	return null;
    }

    @Override
    public Date getSBACoverageRequestedDate(Long collateralRid){
    	WorkItem collateralItem = getActiveCollateralItem(collateralRid, Arrays.asList(SBA_COVERAGE_REQUESTED.getName()));
    	if(collateralItem == null){
    		return null;
    	}
    	List<PerfectionTask> sbaCoverageRequestTasks = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(collateralItem,  SBA_COVERAGE_REQUESTED.getName(), TaskStatus.TRANSIENT.name());
		if(sbaCoverageRequestTasks !=null && sbaCoverageRequestTasks.size() > 0){
			return sbaCoverageRequestTasks.get(0).getInsertedDate();
		}
    	return null;
    }

	private WorkItem getVerifyCollateralWorkItem(Long collateralRid) {
		List<WorkItem> collateralWorItems = workItemRepository.findByCollateralWorkItemsCollateralRid(collateralRid);

		if (collateralWorItems == null || collateralWorItems.isEmpty()) {
			return null;
		}

		// Expecting only one record
		return collateralWorItems.get(0);
	}

	@Override
	public Set<PerfectionTask> getRequiredCoverageRequestTasks(Long collateralRid) {
		Set<PerfectionTask> resultSet = new HashSet<PerfectionTask>();
		Set<PerfectionTask> sBATasks = getSBACoverageRequestTasks(collateralRid);
		Set<PerfectionTask> fiatTasks = getFiatRequestasks(collateralRid);
		if (sBATasks != null)
			resultSet.addAll(sBATasks);
		if (fiatTasks != null)
			resultSet.addAll(fiatTasks);
		return resultSet;
	}



	protected Set<PerfectionTask> getFiatRequestasks(Long collateralRid) {

		Set<PerfectionTask> fiatRequestWorkflowTasks = new HashSet<PerfectionTask>();

		List<WorkItem> collateralWorItems = workItemRepository.findByPerfectionTypeAndCollateralWorkItemsCollateralRid(
				PerfectionItemType.COLLATERAL.name(), collateralRid);

		if (collateralWorItems == null || collateralWorItems.isEmpty()) {
			return null;
		}
		for (WorkItem collateralWorkItem : collateralWorItems) {

			List<PerfectionTask> partialResult = perfectionTaskRepository
					.findByWorkItemAndWorkflowStepInAndTaskStatusIn(collateralWorkItem,
							Arrays.asList(FIAT_REQUESTED.getName(), FIAT_NOT_RECEIVED.getName()),
							Arrays.asList(TaskStatus.OPEN.name(), TaskStatus.SLEEPING.name(),
									TaskStatus.TRANSIENT.name()));

			if (partialResult != null && !partialResult.isEmpty()) {
				fiatRequestWorkflowTasks.addAll(partialResult);
			}

		}
		return fiatRequestWorkflowTasks.isEmpty() ? null : fiatRequestWorkflowTasks;

	}

	private Set<PerfectionTask> getSBACoverageRequestTasks(Long collateralRid) {

		Set<PerfectionTask> sbaCoverageRequestWorkflowTasks = new HashSet<PerfectionTask>();

		List<WorkItem> collateralWorItems = workItemRepository.findByPerfectionTypeAndCollateralWorkItemsCollateralRid(
				PerfectionItemType.COLLATERAL.name(), collateralRid);

		if (collateralWorItems == null || collateralWorItems.isEmpty()) {
			return null;
		}
		for (WorkItem collateralWorkItem : collateralWorItems) {

			List<PerfectionTask> partialResult = perfectionTaskRepository
					.findByWorkItemAndWorkflowStepInAndTaskStatusIn(collateralWorkItem,
							Arrays.asList(SBA_COVERAGE_REQUESTED.getName(), SBA_COVERAGE_NOT_RECEIVED.getName()),
							Arrays.asList(TaskStatus.OPEN.name(), TaskStatus.SLEEPING.name(),
									TaskStatus.TRANSIENT.name()));

			if (partialResult != null && !partialResult.isEmpty()) {
				sbaCoverageRequestWorkflowTasks.addAll(partialResult);
			}

		}
		return sbaCoverageRequestWorkflowTasks.isEmpty() ? null : sbaCoverageRequestWorkflowTasks;

	}

	@Override
	public Set<PerfectionTask> getAgentAndTasks(Long collateralRid) {

		Set<PerfectionTask> agentWorkflowTasks = new HashSet<PerfectionTask>();

		List<WorkItem> workItems = workItemRepository.findByPerfectionTypeAndCollateralWorkItemsCollateralRid(
				PerfectionItemType.FLOOD_POLICY.name(), collateralRid);

		if (workItems == null || workItems.isEmpty()) {
			return null;
		}
		for (WorkItem workItem : workItems) {
			List<PerfectionTask> partialResult = perfectionTaskRepository
					.findByWorkItemAndWorkflowStepInAndTaskStatusIn(workItem,
                            BORROWER_RENEWAL_WORKFLOW_STEPS,
							Arrays.asList(
									TaskStatus.OPEN.name(),
								    TaskStatus.SLEEPING.name(),
									TaskStatus.TRANSIENT.name()));

			if (partialResult != null && !partialResult.isEmpty()) {
				agentWorkflowTasks.addAll(partialResult);
			}
		}
		return agentWorkflowTasks.isEmpty() ? null : agentWorkflowTasks;

	}


    private boolean checkTaskCreationEligibility(Collateral collateral, WorkflowStateDefinition workFlowStepState, List<TMTaskDataParams> tmTaskDataParams, List<WorkflowStateDefinition> avoidIfExistingworkFlowStep) {
        if (collateral != null) {
			//if in this session batch is already creating a review task for this collateral do not create another review task
            for (TMTaskDataParams tmTaskDataParam : tmTaskDataParams) {
                if (collateral.getRid().equals(tmTaskDataParam.getCollateralRid())) {
                    return false;
                }
            }

            //if there is an existing task with workflow steps passed as input parameter {avoidIfExistingworkFlowStep} do not create another review task.
            List<ActiveCollateralWorkflowRelation> allActiveList = new ArrayList<ActiveCollateralWorkflowRelation>();

            for(WorkflowStateDefinition workflowStateDefinition : avoidIfExistingworkFlowStep ){
            	List<ActiveCollateralWorkflowRelation> activeList =
            			activeCollateralWorkflowRelationRepository.findByCollateralAndTaskWorkflowStep(
            					collateral, workflowStateDefinition.getName());
            	allActiveList.addAll(activeList);
            }
            if (CollectionUtils.isNotEmpty(allActiveList)) {
                return false;
            }
            //Create a review Collateral Task.
            return true;
        }
        return false;
    }

    @Override
	public boolean isInValidStateForRenewal(Collateral collateral) {
		// If all the collateral's are not pledged do not create the review task
		if (!CollateralStatus.PLEDGED.name().equals(collateral.getCollateralStatus())) {
		    return false;
		}

		//if the property is not in a flood zone starting with A or V do not create the review task
		FloodDetermination floodDetermination = floodDeterminationRepository.findByCollateralRidAndStatus(collateral.getRid(), VerificationStatus.VERIFIED.name());
		if (floodDetermination != null) {
			String floodZone = floodDetermination.getFloodZone();
			boolean propertyFloodZoneAorVFlag = floodZone.toUpperCase().trim().startsWith("A") || floodZone.toUpperCase().trim().startsWith("V");
			if (!propertyFloodZoneAorVFlag) {
				return false;
			}
		}else{
			return false;
		}

		return true;
	}
    @Override
    public Set<Collateral> removeCollateralsUnqualifiedForWorkfow(Set<Collateral> collaterals){
		removeReleasedCollaterals(collaterals);
		removeZonedOutCollaterals(collaterals);
		removeCollateralsWithNoActiveLoan(collaterals);
		return collaterals;
	}

	@Override
	public Set<PerfectionTask> getPreRenewalLetterTask(Long collateralRid) {
		Set<PerfectionTask> preRenewalLetterWorkflowTasks = new HashSet<>();
		List<WorkItem> collateralWorkItems = workItemRepository.findByPerfectionTypeAndCollateralWorkItemsCollateralRid(
				PerfectionItemType.FLOOD_POLICY.name(), collateralRid);
		if (CollectionUtils.isNotEmpty(collateralWorkItems)) {
			for (WorkItem collateralWorkItem : collateralWorkItems) {
				List<PerfectionTask> partialResult = perfectionTaskRepository
						.findByWorkItemAndWorkflowStepInAndTaskStatusIn(collateralWorkItem,
								Arrays.asList(SEND_PRE_RENEWAL_EXP_LETTER.getName()),
								TaskStatus.getActiveStatus());
				if (CollectionUtils.isNotEmpty(partialResult)) {
					preRenewalLetterWorkflowTasks.addAll(partialResult);
				}
			}
		}

		return preRenewalLetterWorkflowTasks;
	}

	/**
	 * Evaluate for given itemsToRemove list with fiatTask, if both are matching then close otm perfection task
	 * otherwise remove the items that are in the itemstoRemove from proofOfCoverageWorkItem table
	 * @param itemsToRemove - list of ProofOfCovWorkItems
	 * @param fiatTask - Any FIAT  perfection task
	 * @return void
	 */
	@Transactional
	protected void removeFiatWorkItems(final Set<ProofOfCovWorkItem> itemsToRemove, PerfectionTask fiatTask) {
		logger.debug("removeFiatWorkItems::BEGIN");
		// add all inactive items to itemsToRemove
        for (ProofOfCovWorkItem inactiveItem: fiatTask.getWorkItem().getProofOfCovWorkItems()) {
            if(inactiveItem.getProofOfCoverage().getPolicyStatus_().isInactive()) {
                itemsToRemove.add(inactiveItem);
            }
        }
        //delete from fiat list
        if(!itemsToRemove.isEmpty()) {
            fiatTask.getWorkItem().getProofOfCovWorkItems().removeAll(itemsToRemove);
            proofOfCovWorkItemRepository.delete(new ArrayList<>(itemsToRemove));
            proofOfCovWorkItemRepository.flush();
            logger.debug("Fiat task items removed: " + itemsToRemove.size());
        }
		logger.debug("removeFiatWorkItems::END");
	}

	protected boolean includesDraftCollateral(Set<Collateral> collaterals){
    	 for (Collateral collateral : collaterals) {
         	 if (CollateralStatus.DRAFT.name().equals(collateral.getCollateralStatus())) {
         		 return true;
         	 }
         }
    	 return false;
    }

    private boolean includesUnverifiedSections(Set<Collateral> collaterals) {
		for (Collateral collateral : collaterals) {
			if (!collateralDetailsStatusService.areAllSectionsVerified(collateral.getRid())) {
				return true;
			}
		}
		return false;
	}

    private void removeZonedOutCollaterals(Set<Collateral> collaterals) {
         Set<Collateral> collateralZoneOut = new HashSet<Collateral>();
         for(Collateral collateral: collaterals){
         	 if(!isCollateralZoneIn(collateral)){
         		collateralZoneOut.add(collateral);
         	 }
         }
         collaterals.removeAll(collateralZoneOut);
         logger.info("removeZonedOutCollaterals: " + collateralZoneOut.size());

	}

	private void removeCollateralsWithNoActiveLoan(Set<Collateral> collaterals) {
        Set<Collateral> collateralWithoutActiveLoan = new HashSet<Collateral>();
        for(Collateral collateral: collaterals){
        	 if(!loanManagementService.hasAtLeastOneActiveLoan(collateral.getRid())){
        		 collateralWithoutActiveLoan.add(collateral);
        	 }
        }
        collaterals.removeAll(collateralWithoutActiveLoan);
        logger.info("removeCollateralsWithNoActiveLoan: " + collateralWithoutActiveLoan.size());
	}

	private void removeReleasedCollaterals(Set<Collateral> collaterals) {
		Set<Collateral> releasedCollaterals = new HashSet<Collateral>();
		for(Collateral collateral: collaterals){
			if(CollateralStatus.RELEASED.name().equals(collateral.getCollateralStatus())){
				releasedCollaterals.add(collateral);
			}
		}
		collaterals.removeAll(releasedCollaterals);
		logger.info("removeReleasedCollaterals: " + releasedCollaterals.size());
	}

    private boolean isCollateralZoneIn(Collateral collateral){
    	FloodDetermination floodDetermination = floodDeterminationRepository.findByCollateralRidAndStatus(collateral.getRid(), VerificationStatus.VERIFIED.name());
    	if (floodDetermination != null) {
			String floodZone = floodDetermination.getFloodZone();
			if(floodZone.toUpperCase().trim().startsWith("A") || floodZone.toUpperCase().trim().startsWith("V")){
				return true;
			}
    	}
    	return false;
    }

    @Override
    public void removeCoverageRequestToWorkItemLinks(ProofOfCoverageDTO proofOfCoverageData, Long collateralRid) {
        Set<Long> insurableAssets = proofOfCoverageData.getInsurableAssetProvidedCoverageMap().keySet();
        CoverageType coverageType = proofOfCoverageData.getCoverageType();
        Set<PerfectionTask> perfectionTasks = getRequiredCoverageRequestTasks(collateralRid);
        for (PerfectionTask perfectionTask : perfectionTasks) {
            Set<ProofOfCovWorkItem> workItemsToDelete = getProofOfCovWorkItemsToDelete(
                    coverageType, insurableAssets, perfectionTask.getWorkItem().getProofOfCovWorkItems(), collateralRid );
            removeFiatWorkItems(workItemsToDelete, perfectionTask);
        }
    }

    /*
    Find ProofOfCovWorkItems related to insurable assets that have matching coverage provided by an expiring policy
    for which no LP would be needed on the policy expiration date
     */
    protected Set<ProofOfCovWorkItem> getProofOfCovWorkItemsToDelete(
            CoverageType coverageType, Set<Long> insurableAssets, List<ProofOfCovWorkItem> proofOfCovWorkItems, Long collateralRid ) {
        Set<ProofOfCovWorkItem> workItemsToDelete = new HashSet<>();
        for (ProofOfCovWorkItem proofOfCovWorkItem : proofOfCovWorkItems) {
            ProofOfCoverage proofOfCoverage = proofOfCovWorkItem.getProofOfCoverage();
            if (isExpiringPolicyWithMatchingCoverageType(coverageType, proofOfCoverage)) {
                Set<Long> matchingInsurableAssetRids = getMatchingInsurableAssetRids(
                        insurableAssets, proofOfCoverage.getProvidedCoverages());
                if (!isLpPolicyNeededOnDate(
                        collateralRid, matchingInsurableAssetRids, proofOfCoverage.getExpirationDate())) {
                    workItemsToDelete.add(proofOfCovWorkItem);
                }
            }
        }
        return workItemsToDelete;
    }

    /*
    Check is any LP would be needed on the policy expiration date for given insurable Assets
     */
    protected boolean isLpPolicyNeededOnDate(Long collateralRid, Set<Long> insurableAssetRids, Date overrideCoverageDate) {
        logger.debug("Trigger C3-Evaluate for insurable assets =" + insurableAssetRids);
        logger.debug("Override Coverage Date =" + overrideCoverageDate + ", Collateral RID = " + collateralRid);
        CoverageActionResult result = collateralCoverageComputationService.evaluateInsurableAssetCoverageActions(
                collateralRid , insurableAssetRids, overrideCoverageDate);
        logger.debug("No LP policies needed =" + CollectionUtils.isEmpty(result.getLpCoveragesToIssues()));
        return !CollectionUtils.isEmpty(result.getLpCoveragesToIssues());
    }

    /*
    expiring borrower and LP policy (excluding applications and binders) With Matching Coverage Type
    */
    protected boolean isExpiringPolicyWithMatchingCoverageType(CoverageType coverageType, ProofOfCoverage proofOfCoverage) {
        return proofOfCoverage.getPolicyStatus_().isExpiring() &&
                !proofOfCoverage.getPolicyType_().isApplicationOrBinder() &&
                proofOfCoverage.getCoverageType_().isMatching(coverageType);
    }

    protected Set<Long> getMatchingInsurableAssetRids(Set<Long> insurableAssets, List<ProvidedCoverage> providedCoverages) {
        Set<Long> matchingInsurableAssetRids = new HashSet<>();
        for (Long insurableAssetRid : insurableAssets) {
            for (ProvidedCoverage providedCoverage : providedCoverages) {
                if(insurableAssetRid.equals(providedCoverage.getInsurableAsset().getRid())) {
                    matchingInsurableAssetRids.add(insurableAssetRid);
                }
            }
        }
        return matchingInsurableAssetRids;
    }

}
