package com.jpmorgan.cib.wlt.ctrac.service.dto.admin;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.OperationTask;

public class OperationsAdminDTO implements Serializable {

	private static final long serialVersionUID = 4252457557658647559L;
	
	private List<String> actions = new ArrayList<String>();
	
	private String action;

	public OperationsAdminDTO() {
		for (OperationTask operationTask: OperationTask.values()) {
			actions.add(operationTask.getDisplayName());
		}
	}
	
	public List<String> getActions() {		
		return actions;
	}

	public void setActions(List<String> actions) {
		this.actions = actions;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
}
