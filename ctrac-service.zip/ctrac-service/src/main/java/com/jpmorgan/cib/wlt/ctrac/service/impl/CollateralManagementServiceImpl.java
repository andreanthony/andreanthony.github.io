package com.jpmorgan.cib.wlt.ctrac.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.store.client.CollateralEventSection;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPIType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Address;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.BusinessAssets;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CollateralOwner;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Loan;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LoanBorrower;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.RealEstate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.EmailDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BusinessAssetCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.RealEstateCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;

@Service
public class CollateralManagementServiceImpl implements CollateralManagementService {

    @Autowired
    private AddressRepository addressRepository;
    @Autowired
    AddressDataService addressDataService;
    @Autowired
    private CollateralRepository collateralRepository;
    @Autowired
    private CustomerDataService customerDataService;
    @Autowired
    private CtracObjectMapper ctracObjectMapper;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private LoanManagementService loanManagementService;
    @Autowired
    private LoanRepository loanRepository;
    @Autowired
    private PerfectionTaskRepository perfectionTaskRepository;
    @Autowired
    private WorkItemRepository workItemRepository;
    @Autowired
    private CollateralOwnerRepository collateralOwnerRepository;
    @Autowired
    private EmailDetailsRepository emailDetailsRepository;
	@Autowired
	private CollateralInsuranceRepository collateralInsuranceRepository;
	@Autowired
	private LoanBorrowerRepository loanBorrowerRepository;

    @Autowired
    protected TMService tmService;

    @Autowired
    private CollateralWorkflowService collateralWorkflowService;
    @Autowired private PublishEventService publishEventService;


    private static final Logger logger = Logger.getLogger(CollateralManagementServiceImpl.class);

    @Override
    @Transactional
	public boolean isCollateralBusinessAssetSBAOnly(Long collateralRid) {
		boolean retValue = false;

			Collateral collateral = collateralRepository.findOne(collateralRid);

			String collateralType = collateral.getCollateralType();

			if (collateralType.equals(CollateralType.BUSINESS_ASSETS.getCode())) {
				Collection<LoanData> listLoanData= loanManagementService.getLoanByCollateral(collateral.getRid());

				for (LoanData loanData: listLoanData) {
					if (loanData.getStatus().isActive()) {
							if (LPIType.SBA_CONTENTS_ONLY.getShortDescription().equals(loanData.getLoanType())) {
								retValue = true;
							} else {
								retValue = false;
								break;
							}
					}
				}
			}

		return retValue;
    }

    @Override
    @Transactional
    public List<CollateralDto> getCollateralsByTmTask(String tmTaskId, String taskStatus) {
        PerfectionTask task = perfectionTaskRepository.findByTmTaskIdAndTaskStatus(tmTaskId, taskStatus);
        return getUniqueCollaterals(task);
    }

    @Override
    @Transactional
    public List<CollateralDto> getCollateralsByTmTask(String tmTaskId) {
        PerfectionTask task = perfectionTaskRepository.findByTmTaskId(tmTaskId);
        return getUniqueCollaterals(task);
    }

    @Override
    @Transactional
    public List<CollateralDto> getCollateralsByWorkItem(WorkItem workItem) {
        // using workItem.workItem.getCollateralWorkItems() could be a bad idea
        // as the object might be detached or out of a transaction context
        return getCollateralsByWorkItem(workItem.getRid());
    }

    @Override
    @Transactional
    public List<CollateralDto> getCollateralsByWorkItem(Long workItemRid) {
        WorkItem workItem = workItemRepository.findByRid(workItemRid);
        if (workItem != null) {
            return getUniqueCollaterals(workItem.getCollateralWorkItems());
        }
        return null;
    }

    @Override
    @Transactional
    public Set<Collateral> geUniquetCollateralsByTmTaskId(String tmTaskId) {

        PerfectionTask task = perfectionTaskRepository.findByTmTaskId(tmTaskId);
        if (task != null && task.getWorkItem() != null) {
            WorkItem workItem = task.getWorkItem();
            return getUniqueCollateralsModels(workItem.getCollateralWorkItems());
        }
        return null;

    }

    @Override
    @Transactional
    public Collateral getPrimaryCollateralByTmTaskId(String tmTaskId) {

        logger.debug("getPrimaryCollateralByTmTaskId()::Start");

        PerfectionTask task = perfectionTaskRepository.findByTmTaskId(tmTaskId);
        assert (task != null) : "Error; a task with Id" + tmTaskId + " was not found ";
        WorkItem workItem = task.getWorkItem();
        Collateral col = workItem.getPreferredCollateral();

        logger.debug("getPrimaryCollateralByTmTaskId()::Start");

        return col;
    }


	@Override
    @Transactional
	public List<CollateralDto> getCollateralDtosByProofOfCoverage(ProofOfCoverageDTO proofOfCoverageDto){
		List<CollateralInsuranceViewData> collateralsProofOfCoverage = collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverageDto.getRid());
		List<CollateralDto> collateralDtos = new ArrayList<CollateralDto>();
		for(CollateralInsuranceViewData data: collateralsProofOfCoverage){
			CollateralDto collateralDto = getCollateralDto(data.getCollateral().getRid());
			collateralDtos.add(collateralDto);
		}
		return collateralDtos;
	}

	@Override
    @Transactional
    public CollateralDto getCollateralDtoForLPPolicyByProofOfCoverageRid(Long proofOfCoverageRid) {
        List<CollateralInsuranceViewData> collateralsProofOfCoverage = collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverageRid);
        return getCollateralDto(collateralsProofOfCoverage.get(0).getCollateral().getRid());
    }

    @Override
    @Transactional
    public Collection<CollateralDto> saveCollaterals(Collection<CollateralDto> collaterals, String userId) {

        for (CollateralDto oneCollateralDto : collaterals) {
            saveCollateral(oneCollateralDto, userId);
        }

        return collaterals;
    }

    @Override
    public void deleteCollateral(CollateralDto collateralDto) {

        logger.debug("deleteCollateral(" + collateralDto + ")::Start");

        loanManagementService.removeLoanCollateral(collateralDto.getRid(), collateralDto.getLoansData());

        if (collateralDto.getRid() != null) {
        	// Cancel TM task. Do we have to check the workflow state, like 'Verify_Collateral"
            collateralWorkflowService.cancelCollateralWorkflow(collateralDto.getRid());
            collateralRepository.delete(collateralDto.getRid());
            publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.COLLATERAL_DELETED, CollateralEventSection.COLLATERAL);
        }
        try {
            addressDataService.deleteAddress(collateralDto.getAddress());
        } catch (Exception swallow) { // this is an optional operation, remove
                                      // orphan on collateral mapping will take
                                      // care of this already
        }
        logger.debug("deleteCollateral()::END");
    }

    /**
     * Method for saving the market email address off the collateral detail section
     * @param collateralDto
     */
    private void saveMarketEmail(CollateralDto collateralDto) {
        if (collateralDto.getEmailRid() != null) {
            // get the current email record to update
            EmailDetails emailDetails = emailDetailsRepository.findOne(collateralDto.getEmailRid());
            emailDetails.setEmailTo(collateralDto.getMarketEmailAddress());
            emailDetailsRepository.save(emailDetails);
        }
        else {
            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setEmailTo(collateralDto.getMarketEmailAddress());
            emailDetails = emailDetailsRepository.save(emailDetails);
            // how to set the email id in colltable table
            collateralDto.setEmailRid(emailDetails.getRid());
        }
    }

    public boolean hasMarketEmailChanged(CollateralDetailsMainDto collateralDetailsData){
        if (collateralDetailsData.getCollateralDto().getEmailRid() != null) {
            // get the current email record
            EmailDetails emailDetails = emailDetailsRepository.findOne(collateralDetailsData.getCollateralDto().getEmailRid());
            if(emailDetails != null){
                return !StringUtils.equals(collateralDetailsData.getCollateralDto().getMarketEmailAddress(),emailDetails.getEmailTo());
            }
        }
        return StringUtils.isNotEmpty(collateralDetailsData.getCollateralDto().getMarketEmailAddress());
    }

    @Override
    @Transactional
    public CollateralDto saveCollateral(CollateralDto collateralDto, String userId) {

        logger.debug(" saveCollateral() : Start ; coll id is: " + collateralDto.getRid());
        // 1- First save the inner properties recursively
        // the loan service will only save the data that have changed
        if (collateralDto.getOwnerData() != null && !collateralDto.getOwnerData().isEmpty()) {
            customerDataService.saveCustomers(collateralDto.getOwnerData());
        }
        if (collateralDto.getLoansData() != null && !collateralDto.getLoansData().isEmpty()) {
            loanManagementService.saveLoans( collateralDto.getRid(), collateralDto.getLoansData());
        }
        if (collateralDto.getAddress() != null) {
            addressDataService.saveAddress(collateralDto.getAddress());
        }

        // TODO FIXME should we care about updating the workItems and
        // insurableAssets?

        // 2 Create a new Collateral or fetch and existing one that need to be
        // updated
        Collateral collateral = null;
        if (collateralDto.getRid() != null) {
            collateral = collateralRepository.findOne(collateralDto.getRid());
        } else if (collateralDto instanceof RealEstateCollateralDto) {
            collateral = new RealEstate();
        } else if (collateralDto instanceof BusinessAssetCollateralDto) {
            collateral = new BusinessAssets();
        }

        //When no collateral instance has been initialized - invalid data
        if(collateral == null){
            throw new IllegalStateException("No collateral record initialized");
        }

        // 3 create new loanCollaterals relation if needed
        if (collateralDto.getLoansData() != null && !collateralDto.getLoansData().isEmpty()) {
            for (LoanData loanData : collateralDto.getLoansData()) {
                Loan savedLoan = loanRepository.findOne(loanData.getRid());
                if ("Yes".equalsIgnoreCase(loanData.getPrimaryFlag())) {
                    collateral.addPrimaryLoan(savedLoan);
                } else {
                    collateral.addLoan(savedLoan);
                }
                // only new relation will be added as per the {loan.addBorrower}
                // specs
            }
        }

        saveMarketEmail(collateralDto);

        //
        if (collateralDto.getOwnerData() != null && !collateralDto.getOwnerData().isEmpty()) {
            for (CustomerData owner : collateralDto.getOwnerData()) {
                Customer savedOwner = customerRepository.findOne(owner.getRid());
                collateral.addOwner(savedOwner, collateralDto.getBorrowerSameAsOwner(), userId);
                // only new relation will be added as per the
                // {collateral.addOwner} specs
            }
        }
        if (collateralDto.getAddress() != null) {
            Address collateralAddress = addressRepository.findOne(collateralDto.getAddress().getRid());
            collateral.setAddress(collateralAddress);
        }

        // 4- After saving the dependent object and relation, return if the
        // collateral-related-only properties have not changed.
        if (!collateralDto.hasChanged()) {
            return collateralDto;
        }

        // TODO FIXME should we save new collateralWorkItems here?
        // copy outer/top properties of the dto to the top property of loan;
        // the loan inner properties were already copied and persisted on step 1
        // & 3;

        ctracObjectMapper.map(collateralDto, collateral);
        Collateral savedCollateral = collateralRepository.save(collateral);

        collateralDto.setRid(savedCollateral.getRid());
        collateralDto.refreshAuditUpdate(savedCollateral);
        // cache a copy for comparison when saving back the object
        // if the properties values had not changed, skip saving to the DB
        collateralDto.saveACopy();

        logger.debug(" saveCollateral() : end ; coll id is: " + collateralDto.getRid());

        return collateralDto;
    }

    private List<CollateralDto> getUniqueCollaterals(PerfectionTask task) {
        if (task != null && task.getWorkItem() != null) {
            WorkItem workItem = task.getWorkItem();
            return getUniqueCollaterals(workItem.getCollateralWorkItems());
        }
        // TODO FIXME log task not found warning;
        return null;
    }

    private List<CollateralDto> getUniqueCollaterals(List<CollateralWorkItem> collateralWorkItems) {

        // TODO FIXME try to make this generic so as not to update the code when
        // a new type of collateral is defined
        Set<Collateral> realEstate = new HashSet<Collateral>();
        Set<Collateral> businessAssets = new HashSet<Collateral>();

        for (CollateralWorkItem collateralWorkItem : collateralWorkItems) {
            Collateral collateral = collateralWorkItem.getCollateral();
            collateral = CtracBaseEntity.deproxy(collateral, Collateral.class);
            if (collateral instanceof RealEstate) {
                realEstate.add(collateral);
            } else if (collateral instanceof BusinessAssets) {
                businessAssets.add(collateral);
            }
        }
        List<RealEstateCollateralDto> collateralDtos = ctracObjectMapper.mapAsList(realEstate, RealEstateCollateralDto.class);
        List<BusinessAssetCollateralDto> businessAssetDtos = ctracObjectMapper.mapAsList(businessAssets, BusinessAssetCollateralDto.class);

        List<CollateralDto> result = new ArrayList<CollateralDto>();
        result.addAll(collateralDtos);
        result.addAll(businessAssetDtos);

        // cache a copy for comparison when saving back the object
        // if the properties values had not changed, skip saving to the DB
        for (CollateralDto collateralDto : result) {
            collateralDto.saveACopy();
        }

        return result;
    }

    private Set<Collateral> getUniqueCollateralsModels(List<CollateralWorkItem> collateralWorkItems) {
        Set<Collateral> collaterals = new HashSet<Collateral>();
        for (CollateralWorkItem collateralWorkItem : collateralWorkItems) {
            Collateral collateral = collateralWorkItem.getCollateral();
            collaterals.add(collateral);
        }
        return collaterals;
    }

    @Override
    @Transactional
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public CollateralDto getCollateralDto(Long collateralRid) {
    	logger.debug("getCollateralDto::START");
        Collateral collateral = CtracBaseEntity.deproxy(collateralRepository.findOne(collateralRid), Collateral.class);
        CollateralDto collateralDto = null;
        if (collateral != null) {
            Class destinationClass = CtracObjectMapper.entityClassMapping.get(collateral.getClass());
            collateralDto = (CollateralDto) ctracObjectMapper.map(collateral, destinationClass);
            populateCollateralDetailsMarketEmail(collateralDto);
            collateralDto.saveACopy();
        }else{
        	logger.warn("--- getCollateralDto:: connot find a collateral with ID:  "+collateralRid);
        }
        logger.debug("getCollateralDto::END");
        return collateralDto;
    }

    private void populateCollateralDetailsMarketEmail(CollateralDto collateralDto) {
        EmailDetails emailDetails = new EmailDetails();
        if (collateralDto.getEmailRid() != null) {
            emailDetails = emailDetailsRepository.findOne(collateralDto.getEmailRid());
        }
        if (emailDetails != null) {
            collateralDto.setMarketEmailAddress(emailDetails.getEmailTo());
        }
    }

    private Collection<CustomerData> getUniqueCollateralOwner(List<CollateralOwner> collateralOwners) {

        Set<Customer> customerSet = new HashSet<Customer>();
        for (CollateralOwner collateralOwner : collateralOwners) {
            customerSet.add(collateralOwner.getOwner());
        }

        List<CustomerData> customerData = ctracObjectMapper.mapAsList(customerSet, CustomerData.class);
        for (CustomerData aCustomerData : customerData) {
            aCustomerData.saveACopy();
        }

        // TODO Auto-generated method stub
        return customerData;
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService
     * #getCollateralOwners(java.lang.Long)
     */
    @Override
    @Transactional
    public Collection<CustomerData> getCollateralOwners(Long collateralRId) {

        List<CollateralOwner> collateralOwner = collateralOwnerRepository.findByCollateralRid(collateralRId);
        if (collateralOwner != null) {
            return getUniqueCollateralOwner(collateralOwner);
        }
        return null;
    }

    @Override
    @Transactional
    public void removeCollateralOwner(CollateralDto collateralDto) {
        Long collateralRid = collateralDto.getRid();
        List<CustomerData> collateralOwners = collateralDto.getOwnerDataToBeDeleted();
        if (collateralRid == null || collateralOwners == null || collateralOwners.isEmpty()) {
            return;
        }
        Collateral collateral = collateralRepository.findOne(collateralRid);
        if (collateral != null) {
            List<Customer> customerData = ctracObjectMapper.mapAsList(collateralOwners, Customer.class);
            List<CollateralOwner> customerOwners = new ArrayList<>();
            customerOwners.addAll(collateral.getCollateralOwners());
            for (Customer owner : customerData) {
                for (CollateralOwner collateralOwner : customerOwners) {
                    Customer customer = collateralOwner.getOwner();
                    if (customer.equals(owner)) {
                        collateralOwnerRepository.delete(collateralOwner);
                        collateral.getCollateralOwners().remove(collateralOwner);
                        customer.getCollateralOwners().remove(collateralOwner);

                        publishEventService.publishCollateralEvent(collateralDto, CollateralEventType.REMOVED, CollateralEventSection.COLLATERAL_OWNER);
                    }
                }
                delinkWithLoan(owner, collateral);
            }
        }
    }

    @Override
    public void delinkWithLoan(CollateralDto collateralDto){
    	if(collateralDto == null){
    		return;
    	}
    	for(CustomerData ownerData: collateralDto.getOwnerDataToBeDeleted()){
    		for(int i = 0; i < collateralDto.getLoansData().size(); i++){
    			LoanData loanData = collateralDto.getLoansData().get(i);
    			if(loanData.getBorrowersData().contains(ownerData)){
    				loanData.getBorrowersData().remove(ownerData);
    				for(int j = 0; j < loanData.getBorrowersData().size(); j++){
    					if(collateralOwnerRepository.findByOwnerRid(loanData.getBorrowersData().get(j).getRid()).isEmpty()){
    						String borrowerName = loanData.getBorrowersData().get(j).getBorrowerName();
    						loanData.getBorrowersData().get(j).setBorrowerName(StringUtils.isEmpty(borrowerName)?"": borrowerName + " | " + ownerData.getBorrowerName());
    						break;
    					}
    				}
    			}
    		}
    	}
    }

    /**
     * Update the borrower name with the owner name concatenated and
       remove the link between the loan and this owner - we will need to redo this if we have the ability to show multiple borrowers in loan borrower section
     * @param owner
     */
	private void delinkWithLoan(Customer owner, Collateral collateral) {
	    for(int j = 0 ; j < collateral.getLoanCollaterals().size(); j++){
	    	Loan loan = collateral.getLoanCollaterals().get(j).getLoan();
	    	Set<Customer> borrowerSet = new HashSet<Customer>();
	    	for(LoanBorrower lb: loan.getLoanBorrowers()){
	    		borrowerSet.add(lb.getBorrower());
	    	}
	    	//1. find the loan which is linked with the owner
	    	if(borrowerSet.contains(owner)){
	    		loan.removeBorrower(owner);
	    		for(int i = 0; i < loan.getLoanBorrowers().size(); i++){
					if(collateralOwnerRepository.findByOwner(loan.getLoanBorrowers().get(i).getBorrower()).isEmpty()){
					  	//2. append the collateral owners name to the only borrower.
						String borrowerName = loan.getLoanBorrowers().get(i).getBorrower().getName();
						loan.getLoanBorrowers().get(i).getBorrower().setName(StringUtils.isEmpty(borrowerName)?"": borrowerName + " | " + owner.getName());
						break;
					}
				}
	    	}
	    }
	}


    @Override
    public String getCollateralDescription(Long collateralRid) {
        try {
            Collateral collateral = collateralRepository.findOne(collateralRid);
            return collateral.getCollateralDescription();
        } catch (Exception e) {
            logger.debug("Invalid Collateral RID: " + collateralRid);
        }
        return "";
    }

    @Override
	public CollateralStatus getCollateralStatus(Long collateralId) {
		Collateral collateral = collateralRepository.findOne(collateralId);
		try {
			return CollateralStatus.valueOf(collateral.getCollateralStatus());
		} catch (Exception e) {
			logger.debug("Invalid Collateral RID or invalid status: " + collateralId);
		}
		return null;
	}

    @Override
    public void updateCollateralOwnerSameASBorrower(List<CustomerData> ownerDataList){
    	if(ownerDataList == null || ownerDataList.isEmpty()){
    		return;
    	}
    	for(CustomerData ownerData: ownerDataList){
    		ownerData.setSame(loanBorrowerRepository.findByBorrowerRid(ownerData.getRid()).size() > 0);
    	}
    }



}
