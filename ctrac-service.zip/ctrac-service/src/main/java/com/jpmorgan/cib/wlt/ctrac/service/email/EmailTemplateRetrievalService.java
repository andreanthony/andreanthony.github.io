package com.jpmorgan.cib.wlt.ctrac.service.email;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplateRule;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EmailTemplateRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EmailTemplateRuleRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailTemplateRulerequest;
import com.jpmorgan.cib.wlt.ctrac.service.specifications.EmailTemplateRuleSpecs;




/**
 * @author n595724
 *
 */
@Service(value = "emailTemplateRetrievalService")
public class EmailTemplateRetrievalService {

	
	@Autowired
	EmailTemplateRuleRepository emailTemplateRuleRepository;
	
	
	@Autowired
	EmailTemplateRepository emailTemplateRepository;
	
	@Autowired
	EmailTemplateRuleSpecs emailTemplateRuleSpecs;
	
	private static final Logger logger = Logger.getLogger(EmailTemplateRetrievalService.class);
	
	
	public EmailTemplate findEmailTemplate(EmailTemplateRulerequest emailTemplateRulerequest) {
		Specification<EmailTemplateRule> allFilteringCriteria =
				EmailTemplateRuleSpecs.deriveAllSearchCritera(emailTemplateRulerequest);
		List<EmailTemplateRule> oneTemplate = emailTemplateRuleRepository.findAll(allFilteringCriteria);
		if (oneTemplate.size() != 1) {
			String errorMessage = "Error retrieving email template: " + emailTemplateRulerequest.toString();
			logger.error(errorMessage);
			throw new RuntimeException(errorMessage);
		}
		return emailTemplateRepository.findByEmailTemplateId(oneTemplate.get(0).getEmailTemplateId());
		
	}
	

	
}
