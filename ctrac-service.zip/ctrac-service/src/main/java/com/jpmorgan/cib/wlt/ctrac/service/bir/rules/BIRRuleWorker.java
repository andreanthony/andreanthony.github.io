package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public interface BIRRuleWorker {

	void execute(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void populateExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData);
	
	String getKey();

	boolean isCollateralLevel();
	
}
