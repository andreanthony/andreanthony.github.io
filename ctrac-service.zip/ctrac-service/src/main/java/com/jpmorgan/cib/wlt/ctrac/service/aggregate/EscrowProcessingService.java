package com.jpmorgan.cib.wlt.ctrac.service.aggregate;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CombinableLetterParam;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LPPolicyRequestViewData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.escrowbalance.EscrowBalanceData;

import java.util.List;
import java.util.Map;

/**
 * @author Q003321
 *
 */
public interface EscrowProcessingService {
	void createInsuranceEscrowBalanceTask(List <LPPolicyRequestViewData> lpPolicyRequestList);
	void processEscrowBalance(EscrowBalanceData balanceData);
	EscrowBalanceData populateEscrowBalanceData(TMParams tmParams);
	boolean evaluateEscrowCombinableLetterParams(Long lpWorkItemRid, Map<CombinableLetterParam,Object> inputParamMap);
}
