package com.jpmorgan.cib.wlt.ctrac.service.aggregate;

import java.util.List;
import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.StateToBeAggregated;


public interface AggregatedWorkItemService {
	
	public Map<AggregateKey, List<WorkItem>> aggregateWorkItemsByKey(
			List<? extends WorkItem> itemsToBeAggregated, StateToBeAggregated workflowStep);
	
}
