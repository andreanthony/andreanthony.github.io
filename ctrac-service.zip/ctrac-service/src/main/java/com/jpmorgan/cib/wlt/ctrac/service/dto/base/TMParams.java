package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author N664895
 */
public class TMParams implements Serializable {

	public static final String CONST_REQUEST_USER_ID = "userId";
	private static final long serialVersionUID = 825646455638782895L;
	protected  String userId;
	protected  String id_task; 
	protected  String workflowStep; 
	protected  String tmTransactionId;
	protected boolean launchedFromCtrac = false;
	

	
	public TMParams(String userId, String id_task) {
		super();
		this.userId = userId;
		this.id_task = id_task;
	}
	public TMParams() {
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getId_task() {
		return id_task;
	}


	public void setId_task(String id_task) {
		this.id_task = id_task;
	}

	public String getWorkflowStep() {
		return workflowStep;
	}


	public void setWorkflowStep(String workflowStep) {
		this.workflowStep = workflowStep;
	}

	public String getTmTransactionId() {
		return tmTransactionId;
	}
	public void setTmTransactionId(String tmTransactionId) {
		this.tmTransactionId = tmTransactionId;
	}
	@Override
	public String toString() {
		return new StringBuilder("TMParams [").append(CONST_REQUEST_USER_ID).append("=").append(userId).append(", id_task=")
				.append(id_task).append(", workflowStep=").append(workflowStep).append(", tmTransactionId=")
				.append(tmTransactionId).append(", launchedFromCtrac=").append(launchedFromCtrac).append("]").toString();
	}

	public void appendToRequestAttributes(HttpServletRequest request,HttpServletResponse response ){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		appendToRequestAttributes(request);
	}
	
	public void appendToRequestAttributes(HttpServletRequest request){
		request.setAttribute(CONST_REQUEST_USER_ID, getUserId());
		request.setAttribute("id_task", getId_task());
		request.setAttribute("workflowStep", getWorkflowStep());
		request.setAttribute("tmTransactionId", getTmTransactionId());
	}
	
	public String toUrlParams() {
		return new StringBuilder("?").append(CONST_REQUEST_USER_ID).append("=").append(getUserId())
				.append("&id_task=").append(getId_task())
				.append("&workflowStep=").append(getWorkflowStep())
				.append("&tmTransactionId=").append(getTmTransactionId())
				.append("&launchedFromCtrac=").append(isLaunchedFromCtrac()).toString();
	}
	public boolean isLaunchedFromCtrac() {
		return launchedFromCtrac;
	}
	public void setLaunchedFromCtrac(boolean launchedFromCtrac) {
		this.launchedFromCtrac = launchedFromCtrac;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id_task == null) ? 0 : id_task.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TMParams other = (TMParams) obj;
		if (id_task == null) {
			if (other.id_task != null)
				return false;
		} else if (!id_task.equals(other.id_task))
			return false;
		return true;
	}
	
}
