package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;

import java.util.Collection;

public interface CustomerDataService {

    Collection<CustomerData> saveCustomers (Collection<CustomerData> customersData);

    CustomerData saveCustomer(CustomerData customerData);

}
