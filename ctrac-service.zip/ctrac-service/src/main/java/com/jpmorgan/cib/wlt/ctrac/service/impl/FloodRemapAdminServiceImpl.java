package com.jpmorgan.cib.wlt.ctrac.service.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.TMServiceErrorCodeEnum;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CtracReferenceDateRepository;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.impl.AbstractRemapServiceImpl;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapDto;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.ResourceAccessException;

import java.util.UUID;


@Service(value = "floodRemapAdminService")
public class FloodRemapAdminServiceImpl extends AbstractRemapServiceImpl implements FloodRemapAdminService {
	
	private static final Logger logger = Logger.getLogger(FloodRemapAdminServiceImpl.class);

    @Autowired private CollateralDocumentService collateralDocumentService;
    @Autowired private CtracReferenceDateRepository ctracReferenceDateRepository;
    @Autowired private LineOfBusinessService lobService;

    @Transactional
    public FloodRemapDto prepareDisplayCreateNewRemap( ){
        logger.info("Inside displayCreateNewRemap() method");
        FloodRemapDto floodRemapDto = new FloodRemapDto();
        floodRemapDto.setTmTaskId(UUID.randomUUID().toString());
        floodRemapDto.setTaskType(TMTaskType.FLOOD_REMAP.name());
        floodRemapDto.setStateCodes(lookupCodeRepository.findByCodeSet(CtracAppConstants.STATES_CODES));
        floodRemapDto.setLineOfBusinesses(lobService.retrieveLinesOfBusiness(false));
        floodRemapDto.setRemapTypes(lookupCodeRepository.findByCodeSet(CtracAppConstants.CODE_SET_REMAP));
        floodRemapDto.setRevisedFloodZones(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(CtracAppConstants.FLOOD_ZONE_CODE_SET));
        floodRemapDto.setSourceSystemNames(lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(CtracAppConstants.SOURCE_SYSTEM_NAME));
        floodRemapDto.setCurrentReferenceDate(DateFormatter.toJavaScriptDate(dateCalculator.getCurrentReferenceDate()));
        logger.info("Exit displayCreateNewRemap() method");
        return floodRemapDto;
	}
    
	   
    @Transactional   
	public PerfectionTask processCreateNewRemap(FloodRemapDto floodRemapDto){
	    
	    
        logger.info("Inside processCreateNewRecord() method");
        FloodRemap floodRemap = null;
        PerfectionTask perfectionTask = null;
        try {
            
            CollateralDocument floodRemapSFHDF =
                    collateralDocumentService.saveCollateralDocument(floodRemapDto.getSFHDF(), CtracAppConstants.SFHDF_DOCUMENT_IDENTIFIER, floodRemapDto.getDateMapChange(), null);        
            floodRemap = ctracObjectMapper.map(floodRemapDto, FloodRemap.class);                   
            populateUnmappedFields(floodRemap, floodRemapDto, floodRemapSFHDF);
            floodRemap = floodRemapRepository.save(floodRemap);            
            perfectionTask = createNewTaskInTM(floodRemap);
        /*}catch (TMServiceApplicationException ex) {
        	//throw new TMServiceApplicationException(TMServiceErrorCodeEnum.E0005,TMServiceErrorCodeEnum.E0005.getErrorDescription(),tmException);
        	throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);*/
        } catch (Exception ex) {
        	logger.error("createNewTaskInTM failed with error message: " + ex.getMessage(), ex);
        	throw new CTracApplicationException("E0147", CtracErrorSeverity.APPLICATION);
        }
        return perfectionTask;
	}


	protected void populateUnmappedFields(FloodRemap floodRemap, FloodRemapDto floodRemapDto, CollateralDocument floodRemapSFHDF) {
        
		floodRemap.setReqNum(floodRemapSFHDF.getFileName());
		floodRemap.setRemapCreationDate(calendarDayUtil.getCurrentReferenceDate());
		floodRemap.setFloodRemapSFHDF(floodRemapSFHDF);
		floodRemap.setProcessingStatus(CtracAppConstants.DB_FLAG_YES.toString());
		floodRemap.setTmTaskType(TMTaskType.FLOOD_REMAP.name()); 
		floodRemap.setRevisedMapDate(floodRemapDto.getDateMapChange());
		
		if ("OUT".equals(floodRemapDto.getRemapCategory()))             
		{
			 floodRemap.setLomarDate(floodRemapDto.getDateMapChange());
		     
		}
		// The front-end is displaying the description fields for LOB and StatusChange.
		// The DB is expecting the LOB code and status change code
		floodRemap.setDeptCode(floodRemapDto.getLineOfBusinessCodeFromDescr());
		// Description is replaced with code for TM task
		floodRemap.setLineOfBusiness(floodRemap.getDeptCode());
		floodRemap.setStatusChange(floodRemapDto.getStatusChangeCodeFromDescr());
	}
	
	@Override
	public ReferenceDate getAppReferenceDate() {
		logger.info("Inside fetchAppReferenceDate() method");
		ReferenceDate referenceDate = ctracReferenceDateRepository.findByName(CtracAppConstants.REFERENCE_DATE);
		logger.info("Exit fetchAppReferenceDate() method");		
		return referenceDate;
	}

}
