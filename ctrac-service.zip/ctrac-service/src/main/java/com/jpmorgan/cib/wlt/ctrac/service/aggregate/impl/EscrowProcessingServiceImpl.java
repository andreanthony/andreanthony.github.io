package com.jpmorgan.cib.wlt.ctrac.service.aggregate.impl;


import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LPPolicyRequestViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.WorkItemAndRelationsService;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.AggregateKey;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.EscrowProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.escrowbalance.EscrowBalanceData;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;


@Service(value = "escrowProcessingService")
public class EscrowProcessingServiceImpl implements EscrowProcessingService {
    private static final Logger logger = Logger.getLogger(EscrowProcessingServiceImpl.class);

    @Autowired private WorkItemAndRelationsService workItemAndRelationsService;
    @Autowired @Qualifier("TMService") private TMService tmService;
    @Autowired private BusinessDayUtil businessDayUtil;
    @Autowired private WireProcessingService wireProcessingService;
    @Autowired private AggregateItemRepository aggregateItemRepository;
    @Autowired private LenderPlaceItemRepository lenderPlaceItemRepository;
    @Autowired private PerfectionTaskRepository perfectionTaskRepository;
    @Autowired private CtracObjectMapper ctracObjectMapper;
    @Autowired private ViewDataRetrievalService viewDataRetrievalService;
    @Autowired private WorkItemRelationRepository workItemRelationRepository;
    @Autowired private WorkItemRepository workItemRepository;
    @Autowired private TaskService taskService;

    /**
     * 
     * create an aggregrate TM task for NON Escrow Loans
     * 1.Get all the policies that are in Letter Cycel with Loan as CTL and NON-ESCORW
     * 2. Create a relationship with Loan to policy and save the relation
     * 3. Create aggregate task for each loan number with corrosponding policies
     */
    @Override
    @Transactional
    public void createInsuranceEscrowBalanceTask(List<LPPolicyRequestViewData> lpPolicyRequestList) {
        logger.info("Inside createInsuranceEscrowBalanceTask()");
        Map<AggregateKey, List<WorkItem>> inputParameterMap = groupPoliciesPerNonEscrowLoan(lpPolicyRequestList);
        AggregateItem lpItem = null;
        if (inputParameterMap != null) {
            for (AggregateKey key : inputParameterMap.keySet()) {
                List<WorkItem> childrenItems = inputParameterMap.get(key);
                try {
                    lpItem = wireProcessingService.createAggregateItem(WorkflowStateDefinition.INSURANCE_ESCROW_BALANCE.getName(), PerfectionItemSubType.POLICY);
                    if (lpItem != null) {
                       
                            workItemAndRelationsService.createRelations(lpItem, childrenItems, TaskRelationType.LOANTOLPPOLICY, CtracAppConstants.SYSTEM_USER);
                            tmService.createTask(TMTaskType.FLOOD_INSURANCE, lpItem, WorkflowStateDefinition.INSURANCE_ESCROW_BALANCE.getFloodRemapTaskState());
                        } 
                        

                    }
                catch (TMServiceApplicationException ex) {
                    logger.error("Unable to create TM Insurance balance Excrow task.: " + ex.getMessage(), ex);
                    throw new CTracApplicationException("E0344", CtracErrorSeverity.CRITICAL);

                }
                 catch (Exception ex) {
                    logger.error("Error while creating the Insurance balance Excrow task : " + ex.getMessage(), ex);
                    throw new CTracApplicationException("E0344", CtracErrorSeverity.CRITICAL);
                }


            }

            logger.info("End of createInsuranceEscrowBalanceTask()");
        }
    }

    protected Map<AggregateKey, List<WorkItem>> groupPoliciesPerNonEscrowLoan(List<LPPolicyRequestViewData> lpPolicyRequestList) {
        Map<AggregateKey, List<WorkItem>> inputParameterMap = new HashMap<AggregateKey, List<WorkItem>>();
        Set<String> loanNumbers = getLoanNumbersToAggregateNonEscrow(lpPolicyRequestList);
        for (String loanNumber : loanNumbers)
        {
            Iterator<LPPolicyRequestViewData> lpPolicyRequestDataiter = lpPolicyRequestList.iterator();
            List<WorkItem> lenderPlaceItems = new ArrayList<WorkItem>();
            while (lpPolicyRequestDataiter.hasNext()) {
                LPPolicyRequestViewData lpPolicyRequest = lpPolicyRequestDataiter.next();
                if (loanNumber.equalsIgnoreCase(lpPolicyRequest.getLoanNumber())) {
                    lenderPlaceItems.add(lpPolicyRequest.getLenderPlaceItem());
                    lpPolicyRequestDataiter.remove();
                }
            }
            AggregateKey keyForStrategy = new AggregateKey(loanNumber);
            inputParameterMap.put(keyForStrategy, lenderPlaceItems);
        }
        return inputParameterMap;

    }

    protected Set<String> getLoanNumbersToAggregateNonEscrow(List<LPPolicyRequestViewData> lpPolicyRequestList) {
        Set<String> loanNumbers = new HashSet<>();
        for (LPPolicyRequestViewData lpPolicyRequestViewData : lpPolicyRequestList) {
            if (lpPolicyRequestViewData.getLenderPlaceItem().getLpPhase().equalsIgnoreCase(LpPhase.PRE_LETTER_CYCLE.name()) &&
                    lpPolicyRequestViewData.getEscrowType() != null &&
                    lpPolicyRequestViewData.getEscrowType().equalsIgnoreCase(EscrowType.NON_ESCROW.name()) &&
                    lpPolicyRequestViewData.getLineOfBusiness().equals(LineOfBusiness.CTL.getCode())) {
                loanNumbers.add(lpPolicyRequestViewData.getLoanNumber());
            }
        }
        return loanNumbers;
    }


    @Transactional(readOnly = false)
	public void processEscrowBalance(EscrowBalanceData balanceData) {

		logger.info("Inside processEscrowBalance()");
		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(balanceData.getTmParams().getId_task());
		if ("Yes".equals(balanceData.getNegativeEscrowBalance()) && balanceData.getEscrowBalanceAmount() != null) {
			WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);
			if (workItem instanceof AggregateItem) {
				AggregateItem aggrWorkItem = (AggregateItem) workItem;
				aggrWorkItem.setEscrowBalanceAmount(AmountFormatter.parse(balanceData.getEscrowBalanceAmount()));
				workItemRepository.save(aggrWorkItem);
			}
		}

		Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
		balanceData.setWorkflowTransitionProcess(ProcessType.MANUAL_PROCESS.getName());
		inputParameterMap.put(StateParameterType.HELPER_DATA, balanceData);
		inputParameterMap.put(StateParameterType.PERFECTION_TASK, perfectionTask);
		inputParameterMap.put(StateParameterType.WORK_ITEM, perfectionTask.getWorkItem());
		taskService.completeWorkFlowStepOperations(inputParameterMap);

		logger.info("End processEscrowBalance()");

	 }

	 @Transactional(readOnly = true)
	 public EscrowBalanceData populateEscrowBalanceData(TMParams tmParams)
	 {
		 logger.info("Inside populateEscrowBalanceData()");

		 PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmParams.getId_task());
	     TaskRelationType parentToChildRelation = TaskRelationType.LOANTOLPPOLICY;
		 List<WorkItemRelation> workItemRelations = workItemRelationRepository.findByParentWorkItemAndRelationType(perfectionTask.getWorkItem(), parentToChildRelation.name());
		 WorkItem policyWorkItem =  CtracBaseEntity.deproxy(workItemRelations.get(0).getChildWorkItem(), WorkItem.class);


	     EscrowBalanceData escrowData = ctracObjectMapper.map(policyWorkItem, EscrowBalanceData.class);
	     Long collateralRid = policyWorkItem.getCollateralWorkItems().get(0).getCollateral().getRid();

	     //1. pull Primary Borrower
	     escrowData.setPrimaryLoanBorrowerViewDto(viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(collateralRid));

	     //3. Pull Collateral Main Details
	     escrowData.setCollateralMainDetailsViewDto(viewDataRetrievalService.getCollateralMainDetails(collateralRid));

	     escrowData.setScreenTitle("Insurance Escrow Balance");
	     escrowData.setTmParams(tmParams);
	      logger.info("End populateEscrowBalanceData()");
		 return  escrowData ;
	 }

    @Override
    public boolean evaluateEscrowCombinableLetterParams(Long lenderPlaceItemRid, Map<CombinableLetterParam, Object> inputParamMap) {
        logger.debug("EvaluateEscrowCombinableLetterParams: START - WorkItem Rid:"+lenderPlaceItemRid);
        LoanData primaryLoanData = (LoanData) inputParamMap.get(CombinableLetterParam.PRIMARY_LOAN_DATA);
        if(primaryLoanData == null){
            logger.debug("primaryLoanData is null for lenderPlaceItemRid=" + lenderPlaceItemRid);
            return false;
        }
        //When loan is CTL and Non-Escrow look for Escrow balance TM Task
        if(LineOfBusiness.isCTL(primaryLoanData.getLineOfBusiness()) && primaryLoanData.isNonEscrow()){
            LenderPlaceItem lpi = lenderPlaceItemRepository.findOne(lenderPlaceItemRid);
            if(lpi != null){
                //Lookup the aggregate item which will contain the escrow balance for this specific Lender place item
                WorkItem workItem = workItemAndRelationsService.getParentItemByChildAndRelation(lpi,TaskRelationType.LOANTOLPPOLICY);
                if(workItem != null){
                    AggregateItem aggregateItem = CtracBaseEntity.deproxy(workItem, AggregateItem.class);
                    List<PerfectionTask> tasks = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(
                            aggregateItem,WorkflowStateDefinition.INSURANCE_ESCROW_BALANCE.getName(),TaskStatus.OPEN.name());
                    if(CollectionUtils.isEmpty(tasks)){
                        logger.debug("INSURANCE_ESCROW_BALANCE: Task completed for aggregate '" + aggregateItem.getRid()+"'");
                        if(aggregateItem.getEscrowBalanceAmount() != null && aggregateItem.getEscrowBalanceAmount().compareTo(BigDecimal.ZERO)>0) {
                            //Set Escrow balance from Lender Place Item in the Combinable letter Params
                            logger.debug("Setting escrow amount on letter");
                            inputParamMap.put(CombinableLetterParam.ESCROW_AMOUNT, aggregateItem.getEscrowBalanceAmount());
                        }else{
                            logger.debug("No escrow amount captured");
                        }
                    }else{
                        //Escrow TM task has not been completed yet - Skip sending of the letter
                        logger.debug("INSURANCE_ESCROW_BALANCE: Task not yet completed for aggregate '"+aggregateItem.getRid()+
                                "', skip sending letter for policy '"
                                +inputParamMap.get(CombinableLetterParam.PROOF_OF_COVERAGE_RID)+"'");
                        return true;
                    }
                }else{
                    //No Aggregate item found - No escrow balance needed to pass to the letters
                    logger.debug("INSURANCE_ESCROW_BALANCE: No task found for Policy '"
                            +inputParamMap.get(CombinableLetterParam.PROOF_OF_COVERAGE_RID)
                            +"' with LOB '"+primaryLoanData.getLineOfBusiness()+"' and Escrow-Type: '"
                            +primaryLoanData.getEscrowType()+"'");
                }
            }
        }else{
            logger.debug("INSURANCE_ESCROW_BALANCE: Loan not qualified to to check the escrow balance.");
        }
        logger.debug("EvaluateEscrowCombinableLetterParams: END - WorkItem Rid:"+lenderPlaceItemRid);
        return false;
    }

}
