package com.jpmorgan.cib.wlt.ctrac.service.admin.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.admin.RestartLetterCycleService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.RestartLetterCycleDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;

@Service
@Transactional(readOnly=true)
public class RestartLetterCycleServiceImpl implements RestartLetterCycleService {

	@Autowired protected TMService tmService;
	@Autowired private CollateralDetailsService collateralDetailsService;

	@Override
	@Secured({EntitlementRoles.ADMIN_ROLE})
	public RestartLetterCycleDTO prepareRestartLetterCycleData(Long collateralId) {
		RestartLetterCycleDTO restartLetterCycleData = new RestartLetterCycleDTO();

		restartLetterCycleData.setSuccessMsg(null);
		restartLetterCycleData.setErrorMsg(null);
		restartLetterCycleData.setCollateralID(collateralId);
		
		CollateralDetailsMainDto collateralDetailsData =
			collateralDetailsService.populateCollateralDetailsInformation(collateralId);
		
		if (collateralDetailsData == null) {
			restartLetterCycleData.setErrorMsg("Collateral record not found.");
		} else if (collateralDetailsData.getInsuranceSectionData() == null || collateralDetailsData.getInsuranceSectionData().getActivePolicies() == null) {
			restartLetterCycleData.setErrorMsg("Active policy records are not found.");
		} else {
			restartLetterCycleData.setCollateralAddress(collateralDetailsData.getCollateralDto().getCollateralDescription());
			
			for (ProofOfCoverageDTO proofOfCoverageDTO : collateralDetailsData.getInsuranceSectionData().getActivePolicies()) {
				if (proofOfCoverageDTO.getPolicyStatus().getDisplayName().equals(PolicyStatus.LETTER_CYCLE.getDisplayName())) {
					proofOfCoverageDTO.setCanRestartLetterCycle(true);
				}
			}
			
			restartLetterCycleData.setProofOfCoverage(collateralDetailsData.getInsuranceSectionData().getActivePolicies());
			restartLetterCycleData.setDisplayInsuranceSection(true);
			restartLetterCycleData.setSelectedRIDs("");
		}

		return restartLetterCycleData;
	}
		
	@Override
	@Secured({EntitlementRoles.ADMIN_ROLE})
	@Transactional(readOnly=false)
	public void submitRestartLetterCycleData(RestartLetterCycleDTO restartLetterCycleData) {
    }

}
