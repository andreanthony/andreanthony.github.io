package com.jpmorgan.cib.wlt.ctrac.service.batch.remap;

/**
 * Created by E704298 on 8/1/2017.
 */
public interface RemapFileException {

    String getMessage();

}
