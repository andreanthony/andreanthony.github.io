package com.jpmorgan.cib.wlt.ctrac.service.dto.base;
/**
 * @author e078704
 *
 *Wrapper Object used to specify the query criteria needed to load the email template
 *
 *All elements are optional but at least one must be provided depending on the attributes needed to uniquely 
 *identify the email template
 *
 */
public class CollateralDetailsRequest{
	
	/**
	 */
	private String loanNumber;	
	private String name;
	private String propertyAddress;
	private String propertyCity;
	private String propertyState;
	private String propertyZipCode;

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public String getPropertyCity() {
		return propertyCity;
	}

	public void setPropertyCity(String propertyCity) {
		this.propertyCity = propertyCity;
	}

	public String getPropertyState() {
		return propertyState;
	}

	public void setPropertyState(String propertyState) {
		this.propertyState = propertyState;
	}

	public String getPropertyZipCode() {
		return propertyZipCode;
	}

	public void setPropertyZipCode(String propertyZipCode) {
		this.propertyZipCode = propertyZipCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CollateralDetailRequest [loanNumber=");
		builder.append(loanNumber);
		builder.append(", name=");
		builder.append(name);
		builder.append(", propertyAddress=");
		builder.append(propertyAddress);
		builder.append(", propertyCity=");
		builder.append(propertyCity);
		builder.append(", propertyState=");
		builder.append(propertyState);
		builder.append(", propertyZipCode=");
		builder.append(propertyZipCode);
		builder.append("]");
		return builder.toString();
	}
}
