package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;


public class AgentResponseData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Long rid;
	private Long proofOfCoverageRid;	
	private Long collateralRid;	
	private String tmTaskRererenceId;
	public Long getRid() {
		return rid;
	}
	public void setRid(Long rid) {
		this.rid = rid;
	}
	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}
	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}
	public Long getCollateralRid() {
		return collateralRid;
	}
	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}
	public String getTmTaskRererenceId() {
		return tmTaskRererenceId;
	}
	public void setTmTaskRererenceId(String tmTaskRererenceId) {
		this.tmTaskRererenceId = tmTaskRererenceId;
	}
	
	

}
