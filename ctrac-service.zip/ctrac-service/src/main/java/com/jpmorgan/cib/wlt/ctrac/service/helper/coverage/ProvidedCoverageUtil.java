package com.jpmorgan.cib.wlt.ctrac.service.helper.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;


public class ProvidedCoverageUtil {

	public static String getFloodLPCoverageType(String assetType){
		String lpCoverageType=LPConstants.CONTENTS.getDisplayName();
		if(InsurableAssetType.STRUCTURE.name().equals(assetType)){
			lpCoverageType=LPConstants.BUILDING.getDisplayName();
		}
		else if(InsurableAssetType.BUSINESS_INCOME.name().equals(assetType)){
			lpCoverageType=LPConstants.BUSINESS_INCOME.getDisplayName();
		}
		return lpCoverageType;
	}

	public static Collection <ProofOfCoverage> getAllProofOfCovOfType(boolean includePending,Set<PolicyType> types,
			Collection<ProofOfCoverage> allPolicies ){
		Collection<ProofOfCoverage> result = new HashSet<>();
	    for (ProofOfCoverage policy : allPolicies ) {
	    	if (types == null || types.contains(policy.getPolicyType_())) {
	    		 if((includePending || policy.getPolicyStatus_() != PolicyStatus.PENDING_VERIFICATION )){
	    			 result.add(policy);
	 	        }
	    	}
	    }
		return result;
	}

	public static Collection<ProofOfCoverage> getExpiringProofOfCovOfType(
			Set<PolicyType> types, Date refDate, Collection<ProofOfCoverage> allPolicies) {
		Collection<ProofOfCoverage> expiringPolicies = new HashSet<>();
		for (ProofOfCoverage proofOfCoverage : allPolicies) {
			if ((types == null || types.contains(proofOfCoverage.getPolicyType_())) &&
					proofOfCoverage.isExpiring(refDate, false)) {
				expiringPolicies.add(proofOfCoverage);
			}
        }
		return expiringPolicies;
	}

}
