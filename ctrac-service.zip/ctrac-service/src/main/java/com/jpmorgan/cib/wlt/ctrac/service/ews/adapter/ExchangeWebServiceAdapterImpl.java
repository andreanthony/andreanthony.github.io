package com.jpmorgan.cib.wlt.ctrac.service.ews.adapter;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EncryptionUtil;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import microsoft.exchange.webservices.data.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity.APPLICATION;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity.CRITICAL;

@Component(value = "exchangeWebServiceAdapter")
public class ExchangeWebServiceAdapterImpl implements ExchangeWebServiceAdapter {

	@Autowired
	private Environment env;

	private ExchangeService exchangeService;

	private Mailbox mailbox;

	private static final Logger logger = Logger.getLogger(ExchangeWebServiceAdapterImpl.class);
	
	static final String NO_SUBJECT = "No Subject";

	public ExchangeWebServiceAdapterImpl() {

	}

	/**
	 * initialize the exchange web service connection
	 */
	@Override
	public void iniExchangeWebService() {
		try {
			ExchangeService service = createNewExchangeService();
			ExchangeCredentials credentials = getExchangeCredentials();
			service.setCredentials(credentials);

			service.setTraceListener(new ExchangeWebServiceTraceListener());
			service.setTraceEnabled(true);

			service.setUrl(new URI(env.getProperty("ews.server.url")));
			this.mailbox = new Mailbox(env.getProperty("ews.mailbox"));
			this.exchangeService = service;
		}
		catch (URISyntaxException e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0155", CRITICAL));	
		}
	}

	@Override
	public EmailMessage getEmailMessageByBindingServiceWithItem(Item item) {
		EmailMessage emailMessage = null;
		try {
			emailMessage = getEmailMessageFromItem(item);
		}
		catch (Exception e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154", CRITICAL));
		}
		return emailMessage;
	}

	@Override
	public ArrayList<Item> getItemsFromInbox() {
		ArrayList<Item> itemList = null;
		FindItemsResults<Item> findItemResults;
		FolderId inboxFolderId = new FolderId(WellKnownFolderName.Inbox, this.getMailbox());
		try {
			findItemResults = this.exchangeService.findItems(inboxFolderId, new ItemView(50));
			itemList = findItemResults.getItems();
		}
		catch (Exception e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154",CRITICAL));
		}
		return itemList;
	}

	@Override
	public void setEmailMessageIsRead(EmailMessage emailMessage) {
		try {
			emailMessage.setIsRead(true);
			emailMessage.update(ConflictResolutionMode.AlwaysOverwrite);
		}
		catch (Exception e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154", APPLICATION));
		}
	}

	@Override
	public void moveEmailMessageToFolder(EmailMessage emailMessage, String folderName) {
		try {
			emailMessage.move(getFolderIdInMailbox(folderName));
		}
		catch (Exception e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154", CRITICAL));
		}
	}

	@Override
	public ArrayList<FileAttachment> getFileAttachmentListFromAnEmail(EmailMessage emailMessage) {
		ArrayList<FileAttachment> arrFileAttachment = new ArrayList<FileAttachment>();
		try {
			for (Attachment attachment : emailMessage.getAttachments()) {
				logger.debug("Attachment inline: "+attachment.getIsInline());
				if (attachment instanceof FileAttachment && !attachment.getIsInline()) {
					arrFileAttachment.add((FileAttachment) attachment);
				}
			}
		}
		catch (ServiceLocalException e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154", CRITICAL));
		}
		return arrFileAttachment;
	}

	@Override
	public File loadAttachment(FileAttachment fileAttachment, String path) {
		File file = null;
		FileOutputStream stream = null;
		try {
			file = new File(path + CtracAppConstants.PATH_SEPERATOR	+ fileAttachment.getName());
			stream = new FileOutputStream(file);
			fileAttachment.load(stream);
			stream.close();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154", CRITICAL));
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		return file;
	}

	@Override
	public String getNamefromFileAttachment(FileAttachment fileAttachment) {
		return fileAttachment.getName();
	}

	@Override
	public String getEmailAddress(EmailMessage emailMessage) {
		String strEmailAddress = null;
		try {
			strEmailAddress = emailMessage.getFrom().getAddress();
		}
		catch (ServiceLocalException e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154", CRITICAL));
		}
		return strEmailAddress;
	}

	@Override
	public String getSubject(EmailMessage emailMessage) {
		String subject = NO_SUBJECT;
		try {
			if(emailMessage.getSubject()!=null)
			subject = emailMessage.getSubject();
		}
		catch (ServiceLocalException e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154", CRITICAL));
		}
		return subject;
	}
	
	@Override
	public Date getReceivedDateTime(EmailMessage emailMessage){
		Date date = new Date ();
		try {
			date = emailMessage.getDateTimeReceived();
		}
		catch (ServiceLocalException e) {
			logger.error(e.getMessage(), e);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0154", CRITICAL));
		}
		return date;
	}

	/**
	 * 	1. Find the root folder id for this mailbox
		2. Iterate the root folder to find the folder id 
	 * @param folderName
	 * @return folder id
	 * @throws Exception
	 */
	private FolderId getFolderIdInMailbox(String folderName) {
		FolderId folderID = null;
		FolderId folderRootId = new FolderId(WellKnownFolderName.MsgFolderRoot, this.mailbox);
		FindFoldersResults findFolderResults;
		try {
			findFolderResults = exchangeService.findFolders(folderRootId, new FolderView(15));

			for (Folder folder : findFolderResults.getFolders()) {
				if (folder.getDisplayName().equals(folderName)) {
					folderID = folder.getId();
				}
			}
		}
		catch (Exception e) {
			logger.error("Error occurred when email web service tries to find folder:" + folderName + " in mailbox:"
					+ this.mailbox.getSearchString());
			logger.error(e.getMessage(), e);
		}
		return folderID;
	}

	public ExchangeService getExchangeService() {
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}

	public Mailbox getMailbox() {
		return mailbox;
	}

	public void setMailbox(Mailbox mailbox) {
		this.mailbox = mailbox;
	}


	ExchangeService createNewExchangeService(){
		return new ExchangeService(ExchangeVersion.Exchange2010_SP1);
	}

	ExchangeCredentials getExchangeCredentials(){
		return ExchangeCredentials.getExchangeCredentialsFromNetworkCredential(
				env.getProperty("ews.username"), EncryptionUtil.decrypt(env.getProperty("ews.password")), env.getProperty("ews.domain"));
	}

	EmailMessage getEmailMessageFromItem(Item item) throws Exception {
		return EmailMessage.bind(exchangeService, item.getId());
	}

}
