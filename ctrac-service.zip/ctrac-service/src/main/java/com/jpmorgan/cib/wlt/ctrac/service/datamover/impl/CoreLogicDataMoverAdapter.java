package com.jpmorgan.cib.wlt.ctrac.service.datamover.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.CoreLogicFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.FloodRemapRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.external.CoreLogicFloodRemapRepository;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataMoverAdaptor;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataProcessor;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.Seperator;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessCategory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_REMAP_TYPES;

@Component("coreLogicDataMoverAdapter")
public class CoreLogicDataMoverAdapter extends DataMoverAdaptor<CoreLogicFloodRemap, FloodRemap> {
	
	public CoreLogicDataMoverAdapter() {
		super(SchedulerJob.NEW_TASK_JOB_CL, LineOfBusinessCategory.CORE_LOGIC);
	}

	private static final Logger logger = Logger.getLogger(CoreLogicDataMoverAdapter.class);

	@Autowired protected CoreLogicFloodRemapRepository coreLogicFloodRemapRepository;
	@Autowired protected FloodRemapRepository floodRemapRepository;
	
	@Override
	protected List<CoreLogicFloodRemap> fetchSourceData() {
		logger.info("fetchSourceData()::Begin");
		List<CoreLogicFloodRemap> sourceData = coreLogicFloodRemapRepository.findByDataProcessingStatus("N");
		logger.info("fetchSourceData()::End");
		return sourceData;
	}

	@Override
	protected List<DataProcessor> preparePreStepProcessors() {
		logger.info("preparePreStepProcessors()::Begin");
		List<DataProcessor> preStepsProcessors = new ArrayList<DataProcessor>();		
		preStepsProcessors.add(new SetFieldValueUpdateProcessor("dataProcessingStatus","E"));		
		preStepsProcessors.add(new SetFieldValueUpdateProcessor("remapCreationDate",calendarDayUtil.getCurrentReferenceDate()));		
		Set<Object> notificationTypes = new HashSet<Object>();
		notificationTypes.add("L");
		notificationTypes.add("M");
		preStepsProcessors.add(new EqualFilterProcessor("notificationType", notificationTypes));
		preStepsProcessors.add(new NotInFilterProcessor("servicer", retrieveServicerCodesByActive(false)));
		Set<Object> statusChange = new HashSet<Object>(Arrays.asList(FLOOD_REMAP_TYPES));
		preStepsProcessors.add(new EqualFilterProcessor("statusChange", statusChange));
		preStepsProcessors.add(new CombineFieldsUpdateProcessor("borrowerName",Seperator.SPACE,"borrowerFirstName,borrowerLastName",Seperator.COMMA));
		
		logger.info("preparePreStepProcessors()::End");
		return preStepsProcessors;
		
	}
	
	@Override
	protected void executeMove() {
		logger.info("executeMove()::Begin");
		FloodRemap newFloodRemap;
		List<FloodRemap> tempTargetData= new ArrayList<FloodRemap>();
		List<CoreLogicFloodRemap> filteredSourceData =  getFilteredDataToMove();
		for(CoreLogicFloodRemap record : filteredSourceData){
			try {
				newFloodRemap = ctracObjectMapper.map(record, FloodRemap.class);
				tempTargetData.add(newFloodRemap);
				super.successCount++;
			} catch (Exception e) {
				logger.error("executeMove()::Core Logic to FloodRemap data move failed for Core Logic RID:"+ record.getRid(), e);
				super.exceptionRecordsCnt++;
			}
			
		}	
		setTargetData(tempTargetData);
		logger.info("executeMove()::End");
	}


	@Override
	protected List<DataProcessor> preparePostStepProcessors() {
		logger.info("preparePostStepProcessors()::Begin");
		List<DataProcessor> postStepsProcessors = new ArrayList<DataProcessor>();
		postStepsProcessors.add(new SetFieldValueUpdateProcessor("dataProcessingStatus","Y"));
		logger.info("preparePostStepProcessors()::End");
		return postStepsProcessors;			
	}

	@Override
	protected void saveData(List<CoreLogicFloodRemap> sourceData, List<FloodRemap> targetData) {
		floodRemapRepository.save(targetData);
		coreLogicFloodRemapRepository.save(sourceData);
	}
}
