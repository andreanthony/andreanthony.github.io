package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProcessType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;


public class TaskSelectionCriteria {
	private WorkItem workItem;
	private WorkflowStateDefinition workflowState;
	private Integer slaRemaining;
	private Date expExecutionDate;
	private ProcessType process;
	
	public ProcessType getProcess() {
		return process;
	}
	public void setProcess(ProcessType process) {
		this.process = process;
	}
	public Integer getSlaRemaining() {
		return slaRemaining;
	}
	public void setSlaRemaining(Integer slaRemaining) {
		this.slaRemaining = slaRemaining;
	}	
	public Date getExpExecutionDate() {
		return expExecutionDate;
	}
	public void setExpExecutionDate(Date expExecutionDate) {
		this.expExecutionDate = expExecutionDate;
	}
	public WorkflowStateDefinition getWorkflowState() {
		return workflowState;
	}
	public void setWorkflowState(WorkflowStateDefinition workflowState) {
		this.workflowState = workflowState;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
}
