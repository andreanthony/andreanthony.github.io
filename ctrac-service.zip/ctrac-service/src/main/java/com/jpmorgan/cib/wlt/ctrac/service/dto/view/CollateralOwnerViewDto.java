package com.jpmorgan.cib.wlt.ctrac.service.dto.view;

import java.util.Date;

public class CollateralOwnerViewDto {

	private Long collateralRid;
	
	private String borrowerSameAsOwner;

	private String ownerName;
	
	private String uniqueOwnerNumber;
	
	private String ownerMailingAddress;
	
	private String ownerCity;
	
	private String ownerState;

	private String ownerZipCode;
	
	private String ownerUnitBuilding;
	
	private String ownerCreatedBy;
	
	private Date ownerCreatedDate;
	
	private String ownerLastUpdatedBy;
	
	private Date ownerUpdatedDate;

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getBorrowerSameAsOwner() {
		return borrowerSameAsOwner;
	}

	public void setBorrowerSameAsOwner(String borrowerSameAsOwner) {
		this.borrowerSameAsOwner = borrowerSameAsOwner;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getUniqueOwnerNumber() {
		return uniqueOwnerNumber;
	}

	public void setUniqueOwnerNumber(String uniqueOwnerNumber) {
		this.uniqueOwnerNumber = uniqueOwnerNumber;
	}

	public String getOwnerCreatedBy() {
		return ownerCreatedBy;
	}

	public void setOwnerCreatedBy(String ownerCreatedBy) {
		this.ownerCreatedBy = ownerCreatedBy;
	}

	public Date getOwnerCreatedDate() {
		return ownerCreatedDate;
	}

	public void setOwnerCreatedDate(Date ownerCreatedDate) {
		this.ownerCreatedDate = ownerCreatedDate;
	}

	public String getOwnerLastUpdatedBy() {
		return ownerLastUpdatedBy;
	}

	public void setOwnerLastUpdatedBy(String ownerLastUpdatedBy) {
		this.ownerLastUpdatedBy = ownerLastUpdatedBy;
	}

	public String getOwnerMailingAddress() {
		return ownerMailingAddress;
	}

	public void setOwnerMailingAddress(String ownerMailingAddress) {
		this.ownerMailingAddress = ownerMailingAddress;
	}

	public String getOwnerCity() {
		return ownerCity;
	}

	public void setOwnerCity(String ownerCity) {
		this.ownerCity = ownerCity;
	}

	public String getOwnerState() {
		return ownerState;
	}

	public void setOwnerState(String ownerState) {
		this.ownerState = ownerState;
	}

	public String getOwnerZipCode() {
		return ownerZipCode;
	}

	public void setOwnerZipCode(String ownerZipCode) {
		this.ownerZipCode = ownerZipCode;
	}

	public String getOwnerUnitBuilding() {
		return ownerUnitBuilding;
	}

	public void setOwnerUnitBuilding(String ownerUnitBuilding) {
		this.ownerUnitBuilding = ownerUnitBuilding;
	}

	public Date getOwnerUpdatedDate() {
		return ownerUpdatedDate;
	}

	public void setOwnerUpdatedDate(Date ownerUpdatedDate) {
		this.ownerUpdatedDate = ownerUpdatedDate;
	}
	
}
