package com.jpmorgan.cib.wlt.ctrac.service.admin.impl;

import com.jpmorgan.cib.wlt.ctrac.service.admin.USPSClientService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.LoanBorrowerAddressDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.*;

@Service
public class USPSClientServiceImpl implements USPSClientService {
    private static final Logger logger = LoggerFactory.getLogger(USPSClientServiceImpl.class);

    static final String USPS_USER_ID = "usps.userId";
    static final String USPS_WEBSERVICE_URL = "usps.webService.URL";
    static final String JPMC_PROXY_SERVER_URL = "jpmc.proxyServer.URL";
    static final String JPMC_PROXY_SERVER_PORT_NUMBER = "jpmc.proxyServer.portNumber";
    static final String USPS_SLEEP_DURATION = "usps.sleepDuration";

    private static final String USPS_VERIFY_ADDRESS_API = "?API=Verify&XML=";
    private static final String USPS_GET_CITYNAME_API = "?API=CityStateLookup&XML=";

    @Resource
    private Environment env;

    String uspsUserId;
    String uspsWebServiceURL;
    String jpmcProxyServerURL;
    String jpmcProxyServerPortNumber;
    Long uspsSleepDuration;

    @Override
    public AddressValidateResponse getAddressValidate(LoanBorrowerAddressDTO loanBorrowerAddressDTO) throws Exception {
        uspsUserId = env.getProperty(USPS_USER_ID);
        uspsWebServiceURL = env.getProperty(USPS_WEBSERVICE_URL );
        jpmcProxyServerURL = env.getProperty(JPMC_PROXY_SERVER_URL);
        jpmcProxyServerPortNumber = env.getProperty(JPMC_PROXY_SERVER_PORT_NUMBER );
        String uspsSleepDurationStr = env.getProperty(USPS_SLEEP_DURATION);
        uspsSleepDuration = Long.parseLong(uspsSleepDurationStr);

        AddressValidateRequest addressValidatorRequest = createAddressValidateRequestFromDTO(loanBorrowerAddressDTO);

        JAXBContext jaxbContext = JAXBContext.newInstance(AddressValidateRequest.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

        StringWriter sw = new StringWriter();

        jaxbMarshaller.marshal(addressValidatorRequest, sw);

        String queryString= URLEncoder.encode(sw.toString(), "UTF-8");

        String url = uspsWebServiceURL + USPS_VERIFY_ADDRESS_API + queryString;

        logger.debug("Request: {}", url);

        // Create a connection call package scoped and then mock response with a Wilson generated XML. jaxb marshal an object myself
        HttpURLConnection con = getHTTPConnection(url);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }

        in.close();

        String returnedXML = response.toString();
        logger.debug("Response: {}", returnedXML);

        JAXBContext jaxbContextResponse = JAXBContext.newInstance(AddressValidateResponse.class);

        XMLInputFactory xif = XMLInputFactory.newFactory();
        xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(returnedXML));

        Unmarshaller unmarshaller = jaxbContextResponse.createUnmarshaller();
        // Todo: Move all of the request retrieval into another method? Then directly return a AddressValidateResponse
        AddressValidateResponse addressValidateResponse = (AddressValidateResponse) unmarshaller.unmarshal(xsr);
        // add a field 'hasError: boolean' (returnedXML.indexOf("<Error>") == -1) and set here? Or should it be only method
        // TODO: Why are we sleeping here?
        Thread.sleep(uspsSleepDuration);
        return addressValidateResponse;
    }

    // TODO: Create a connection service in the future.
    HttpURLConnection getHTTPConnection(String url) throws Exception {
        URL obj = new URL(url);
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(jpmcProxyServerURL, Integer.parseInt(jpmcProxyServerPortNumber)));
        HttpURLConnection connection = (HttpURLConnection) obj.openConnection(proxy);
        connection.setRequestMethod("GET");
        return connection;
    }

    @Override
    public CityStateLookupResponse getCityFromZip5(String zip5) throws Exception {
        JAXBContext jaxbContext = JAXBContext.newInstance(CityStateLookupRequest.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

        CityStateLookupRequest cityStateLookupRequest = new CityStateLookupRequest();
        cityStateLookupRequest.setUSERID(uspsUserId);

        CityStateLookupRequest.ZipCode zipCode = new CityStateLookupRequest.ZipCode();
        zipCode.setID(0);
        zipCode.setZip5(zip5);

        cityStateLookupRequest.setZipCode(zipCode);

        StringWriter sw = new StringWriter();

        jaxbMarshaller.marshal(cityStateLookupRequest, sw);

        String queryString= URLEncoder.encode(sw.toString(), "UTF-8");

        String url = uspsWebServiceURL + USPS_GET_CITYNAME_API + queryString;
        logger.debug("Request: {}", url);

        HttpURLConnection con = getHTTPConnection(url);

        StringBuilder response = new StringBuilder();
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()))) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
        } catch(Exception e) {
            logger.error("Error reading response from {}", url, e);
            throw e;
        }

        String returnedXML = response.toString();
        logger.debug("Response: {}", returnedXML);

        JAXBContext jaxbContextResponse = JAXBContext.newInstance(CityStateLookupResponse.class);

        XMLInputFactory xif = XMLInputFactory.newFactory();
        xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(returnedXML));

        Unmarshaller unmarshaller = jaxbContextResponse.createUnmarshaller();
        CityStateLookupResponse cityStateLookupResponse = (CityStateLookupResponse) unmarshaller.unmarshal(xsr);

        return cityStateLookupResponse;
    }

    public AddressValidateRequest.Address addressValidateRequestAddressFromDTO(LoanBorrowerAddressDTO loanBorrowerAddressDTO) {
        String streetAddress = loanBorrowerAddressDTO.getStreetAddress();
        String unitBuilding = loanBorrowerAddressDTO.getUnitBuilding();

        int lastComma=-1;
        if (streetAddress != null) {
            lastComma = streetAddress.lastIndexOf(",");
        }

        if (lastComma > -1 && streetAddress != null) {
            unitBuilding = streetAddress.substring(lastComma+1).trim();
            streetAddress = streetAddress.substring(0, lastComma);
        }

        AddressValidateRequest.Address address = new AddressValidateRequest.Address();
        address.setAddress1(streetAddress);
        address.setAddress2(unitBuilding);
        address.setCity(loanBorrowerAddressDTO.getCity());
        address.setState(loanBorrowerAddressDTO.getState());
        address.setZip5(loanBorrowerAddressDTO.getZipCode());
        address.setZip4("");

        return address;
    }

    private AddressValidateRequest createAddressValidateRequestFromDTO(LoanBorrowerAddressDTO loanBorrowerAddressDTO) {
        AddressValidateRequest addressValidatorRequest = new AddressValidateRequest();
        addressValidatorRequest.setUSERID(uspsUserId);
        addressValidatorRequest.setAddress(addressValidateRequestAddressFromDTO(loanBorrowerAddressDTO));
        return addressValidatorRequest;
    }

}
