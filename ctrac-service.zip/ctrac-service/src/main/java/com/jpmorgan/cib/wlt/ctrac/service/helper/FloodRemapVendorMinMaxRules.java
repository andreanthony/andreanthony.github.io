package com.jpmorgan.cib.wlt.ctrac.service.helper;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.CoverageAdjustmentIndicator;

public class FloodRemapVendorMinMaxRules {
	
	public static final String FLOOD_VENDOR_MIN_MAX_RULE_CODESET = "FLOOD_REMAP_VENDOR_MIN_MAX_RULE";
	public static final String FLOOD_VENDOR_BUILDING_COVERAGE_MAX = "BUILDING_MAX";
	public static final String FLOOD_VENDOR_BUILDING_COVERAGE_MIN = "BUILDING_MIN";
	public static final String FLOOD_VENDOR_CONTENTS_COVERAGE_MAX = "CONTENTS_MAX";
	public static final String FLOOD_VENDOR_CONTENTS_COVERAGE_MIN = "CONTENTS_MIN";

	private Map<LPConstants, BigDecimal> lpVendorMinAmounts = new HashMap<LPConstants, BigDecimal>();
	private Map<LPConstants, BigDecimal> lpVendorMaxAmounts = new HashMap<LPConstants, BigDecimal>();

	public FloodRemapVendorMinMaxRules(LookupCodeRepository lookupCodeRepository) {
		lpVendorMinAmounts.put(LPConstants.FLOOD_ZONE_IN_BUILDING, getMinMaxAmountForCode(FLOOD_VENDOR_BUILDING_COVERAGE_MIN, lookupCodeRepository));
		lpVendorMinAmounts.put(LPConstants.FLOOD_ZONE_IN_CONTENT, getMinMaxAmountForCode(FLOOD_VENDOR_CONTENTS_COVERAGE_MIN, lookupCodeRepository));
		lpVendorMinAmounts.put(LPConstants.BUILDING, getMinMaxAmountForCode(FLOOD_VENDOR_BUILDING_COVERAGE_MIN, lookupCodeRepository));
		lpVendorMinAmounts.put(LPConstants.CONTENTS, getMinMaxAmountForCode(FLOOD_VENDOR_CONTENTS_COVERAGE_MIN, lookupCodeRepository));

		lpVendorMaxAmounts.put(LPConstants.FLOOD_ZONE_IN_BUILDING, getMinMaxAmountForCode(FLOOD_VENDOR_BUILDING_COVERAGE_MAX, lookupCodeRepository));
		lpVendorMaxAmounts.put(LPConstants.FLOOD_ZONE_IN_CONTENT, getMinMaxAmountForCode(FLOOD_VENDOR_CONTENTS_COVERAGE_MAX, lookupCodeRepository));
		lpVendorMaxAmounts.put(LPConstants.BUILDING, getMinMaxAmountForCode(FLOOD_VENDOR_BUILDING_COVERAGE_MAX, lookupCodeRepository));
		lpVendorMaxAmounts.put(LPConstants.CONTENTS, getMinMaxAmountForCode(FLOOD_VENDOR_CONTENTS_COVERAGE_MAX, lookupCodeRepository));
	}
	
	/**
	 * 
	 * @param requiredCoverageAmount: the required coverage amount from the FIAT
	 * @param lpCoverageType: "Flood Zone In Building" or "Flood Zone In Commercial Contents"
	 * @return the adjusted coverage amount based on LP vendor limitations	
	 */
	public BigDecimal getLpVendorAdjustedCoverageAmount(BigDecimal requiredCoverageAmount, LPConstants lpCoverageType) {
		BigDecimal lpVendorMin = getLpVendorMin(lpCoverageType);
		BigDecimal lpPolicyAmount = applyMin(requiredCoverageAmount, lpVendorMin);
		
		BigDecimal lpVendorMax = getLpVendorMax(lpCoverageType);
		lpPolicyAmount = applyMax(lpPolicyAmount, lpVendorMax);
		
		return lpPolicyAmount;
	}
	
	public boolean atOrAboveLpVendorMax(BigDecimal coverageAmount, LPConstants coverageType) {
		BigDecimal lpVendorMax = getLpVendorMax(coverageType);
		return coverageAmount.compareTo(lpVendorMax) >= 0;
	}
	
	public boolean atOrBelowLpVendorMin(BigDecimal coverageAmount, LPConstants coverageType) {
		BigDecimal lpVendorMin = getLpVendorMin(coverageType);
		return coverageAmount.compareTo(lpVendorMin) <= 0;
	}
	
	public BigDecimal getLpVendorMin(LPConstants coverageType) {
		return lpVendorMinAmounts.get(coverageType);
	}
	
	public BigDecimal getLpVendorMax(LPConstants coverageType) {
		return lpVendorMaxAmounts.get(coverageType);
	}
	
	private BigDecimal getMinMaxAmountForCode(String code, LookupCodeRepository lookupCodeRepository) {
		LookUpCode minMaxAmountCode = lookupCodeRepository.findByCodeAndCodeSet(code, FLOOD_VENDOR_MIN_MAX_RULE_CODESET);
		return AmountFormatter.parse(minMaxAmountCode.getDescription());
	}
	
	private BigDecimal applyMin(BigDecimal coverageAmount, BigDecimal lpVendorMin) {
		return coverageAmount.max(lpVendorMin);
	}
	
	private BigDecimal applyMax(BigDecimal coverageAmount, BigDecimal lpVendorMax) {
		return coverageAmount.min(lpVendorMax);		
	}
	
	
	public String getCoverageAdjustementIndicator(BigDecimal covegareAmount, LPConstants lpCoverageType){
		//If business income, there is no cap limit to check for
		if(LPConstants.BUSINESS_INCOME == lpCoverageType){
			return CoverageAdjustmentIndicator.LP_ACTION_LP_NEW.getDisplayName();
		}
		if(atOrAboveLpVendorMax(covegareAmount, lpCoverageType)){
			return CoverageAdjustmentIndicator.LP_ACTION_LP_VENDOR_MAX.getDisplayName();
		}
		if(atOrBelowLpVendorMin(covegareAmount, lpCoverageType)){
			return CoverageAdjustmentIndicator.LP_ACTION_LP_NOT_REQUIRED.getDisplayName();
		}
		return CoverageAdjustmentIndicator.LP_ACTION_LP_NEW.getDisplayName();
	}
	
}
