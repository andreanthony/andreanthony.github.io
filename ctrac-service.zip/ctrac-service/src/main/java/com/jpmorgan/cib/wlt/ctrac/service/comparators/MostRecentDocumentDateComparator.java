package com.jpmorgan.cib.wlt.ctrac.service.comparators;

import com.jpmorgan.cib.wlt.ctrac.dao.model.SortableByDocumentDate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.RequiredCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredCoverageViewData;
import org.apache.commons.lang.builder.CompareToBuilder;

import java.util.Comparator;

/**
 * Created by V704662 on 5/16/2017.
 * n657508 updated to more generic comparator
 */
public class MostRecentDocumentDateComparator implements Comparator<SortableByDocumentDate>{

    @Override
    public int compare(SortableByDocumentDate o1, SortableByDocumentDate o2) {
        return new CompareToBuilder().append(o2.getDocumentDate(),
                o1.getDocumentDate()).toComparison();
    }

}
