package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import java.util.ArrayList;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;



public class CancelTMTaskCommand extends AbstractCommand {

	private final List<PerfectionTask> perfectionTasksToCancel;

	public CancelTMTaskCommand(PerfectionTask perfectionTaskToCancel) {
		this(perfectionTaskToCancel, 0);
	}
	
	public CancelTMTaskCommand(PerfectionTask perfectionTaskToCancel, int priority) {
		this.perfectionTasksToCancel = new ArrayList<PerfectionTask>();
		this.perfectionTasksToCancel.add(perfectionTaskToCancel);
		this.priority = priority;
	}
	
	public CancelTMTaskCommand(List<PerfectionTask> perfectionTasksToCancel) {
		this(perfectionTasksToCancel, 0);
	}

	public CancelTMTaskCommand(List<PerfectionTask> perfectionTasksToCancel, int priority) {
		this.perfectionTasksToCancel = perfectionTasksToCancel;
		this.priority = priority;
	}
	
	@Override
	public void execute() {
		//TODO handle bean not found exceptions
		TMService tmService=  (TMService) ApplicationContextProvider.getContext().getBean("TMService");
		
		if (perfectionTasksToCancel != null) {
			try {
				for (PerfectionTask task : perfectionTasksToCancel) {
					tmService.cancelTask(task);
				}
			}
			catch (Exception swallow) {
				// TODO log exceptions
			}
		}
	}

	@Override
	public int hashCode() {
		
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((perfectionTasksToCancel == null) ? 0 : perfectionTasksToCancel.hashCode());
		result = prime * result
				+ ((priority == null) ? 0 : priority.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CancelTMTaskCommand other = (CancelTMTaskCommand) obj;
		if (perfectionTasksToCancel == null) {
			if (other.perfectionTasksToCancel != null)
				return false;
		} else if (!perfectionTasksToCancel.equals(other.perfectionTasksToCancel))
			return false;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		return true;
	}

}