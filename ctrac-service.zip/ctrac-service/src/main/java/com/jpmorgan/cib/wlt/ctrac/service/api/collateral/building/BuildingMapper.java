package com.jpmorgan.cib.wlt.ctrac.service.api.collateral.building;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Building;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;
import org.springframework.stereotype.Component;

@Component
public class BuildingMapper extends ConfigurableMapper {
    @Override
    public void configure(MapperFactory mapperFactory) {
        mapperFactory.registerClassMap(mapperFactory.classMap(
                Building.class, BuildingDTO.class)
                .field("collateralRid", "collateralId")
                .byDefault().toClassMap());
    }
}
