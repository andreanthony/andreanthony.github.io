package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import static org.apache.commons.lang.StringUtils.isNotBlank;

import java.io.Serializable;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.Attributes;


public class CompleteItemData implements Serializable {
	
	private static final long serialVersionUID = 6638100814027274910L;

	private TMParams tmParams;
	
	private String taskType;
	
	private List<LookUpCode> closeReasons;
	
	private Long closeReasonId;
	
	private String comments;
	
	private String closeReason;
	
	private String actionSaveUrl;

	private String janusUserId;
	
	//If this task is launched from CTRAC, we are using this field to hold tm task id value
	//if a task is launched from TM then taskId should be inside TMParams ->taskId
	private String tmTaskId;
	
	private String sourceAction;
	
	private String helperTitle;
	
	private List<CollateralDto> collateralDtoList; 
	
	private List<LoanData> loanDtoList;
	
	public Attributes getTMAttributes(){
		Attributes tmAttributes = new Attributes();
		tmAttributes.getTaskAttributes().put("id_break_reason", this.getCloseReason());
		tmAttributes.getTaskAttributes().put("ctrac_task_type", this.getTaskType());
		if(isNotBlank(this.getComments())) {
			tmAttributes.getTaskAttributes().put("tx_comment", this.getComments());
		}
		return tmAttributes;
	}

	public String getTmTaskId() {
		return tmTaskId;
	}

	public void setTmTaskId(String tmTaskId) {
		this.tmTaskId = tmTaskId;
	}

	public String getJanusUserId() {
		return janusUserId;
	}

	public void setJanusUserId(String janusUserId) {
		this.janusUserId = janusUserId;
	}

	public String getCloseReason() {
		return closeReason;
	}

	public void setCloseReason(String closeReason) {
		this.closeReason = closeReason;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public List<LookUpCode> getCloseReasons() {
		return closeReasons;
	}

	public void setCloseReasons(List<LookUpCode> closeReasons) {
		this.closeReasons = closeReasons;
	}

	public Long getCloseReasonId() {
		return closeReasonId;
	}

	public void setCloseReasonId(Long closeReasonId) {
		this.closeReasonId = closeReasonId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	/**
	 * @return the actionSaveUrl
	 */
	public String getActionSaveUrl() {
		return actionSaveUrl;
	}

	/**
	 * @param actionSaveUrl the actionSaveUrl to set
	 */
	public void setActionSaveUrl(String actionSaveUrl) {
		this.actionSaveUrl = actionSaveUrl;
	}
	
	/**
	 * @return the sourceAction
	 */
	public String getSourceAction() {
		return sourceAction;
	}

	/**
	 * @param sourceAction the sourceAction to set
	 */
	public void setSourceAction(String sourceAction) {
		this.sourceAction = sourceAction;
	}

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	public List<CollateralDto> getCollateralDtoList() {
		return collateralDtoList;
	}

	public void setCollateralDtoList(List<CollateralDto> collateralDtoList) {
		this.collateralDtoList = collateralDtoList;
	}

	public List<LoanData> getLoanDtoList() {
		return loanDtoList;
	}

	public void setLoanDtoList(List<LoanData> loanDtoList) {
		this.loanDtoList = loanDtoList;
	}

	public String getHelperTitle() {
		return helperTitle;
	}

	public void setHelperTitle(String helperTitle) {
		this.helperTitle = helperTitle;
	}
	
}
