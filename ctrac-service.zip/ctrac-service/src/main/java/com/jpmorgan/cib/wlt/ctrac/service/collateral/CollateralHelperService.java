package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CtracBaseHelperData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;

public interface CollateralHelperService {

	void populateCollateralInformation(String tmTaskId, FloodRemapData floodRemapData);

	void populateCollateralInformation(String tmTaskId, CtracBaseHelperData verifyLetterData);
	
	void storeCollateralInformation(List<CollateralDto> collateralDTOs, String userId);
		
}
