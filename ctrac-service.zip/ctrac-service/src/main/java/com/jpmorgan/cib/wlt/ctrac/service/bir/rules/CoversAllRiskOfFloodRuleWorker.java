package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;

public class CoversAllRiskOfFloodRuleWorker extends AbstractBIRRuleWorker {

	public CoversAllRiskOfFloodRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		GenericProofOfCoverageDTO floodInsuranceData = borrowerInsuranceReviewData.getProofOfCoverageData();
		if (floodInsuranceData.getInsuranceType() != InsuranceType.FLOOD) {
			return;
		}
		BIRRuleConclusionDTO coversAllRiskOfFloodConclusion = 
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if (!isPrivatePolicyWithNoFloodZonesListed(floodInsuranceData)) {
			birConclusion = BorrowerInsuranceReviewConclusion.NONE;
		} else if ("Yes".equals(floodInsuranceData.getCoversAllRiskOfFlood())) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
		}
		coversAllRiskOfFloodConclusion.setConclusion(birConclusion.name());
	}
	
	private boolean isPrivatePolicyWithNoFloodZonesListed(GenericProofOfCoverageDTO floodInsuranceData) {
		return floodInsuranceData.getPolicyType() == PolicyType.PRIVATE &&
				"No".equals(floodInsuranceData.getFloodZonesListed());
	}

}
