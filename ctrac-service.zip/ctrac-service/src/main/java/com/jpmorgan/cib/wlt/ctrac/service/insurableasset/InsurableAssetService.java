package com.jpmorgan.cib.wlt.ctrac.service.insurableasset;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;

import java.util.Collection;
import java.util.List;




public interface InsurableAssetService {

    Collection<InsurableAssetDTO> findInsurableAssetByCollateral(Long collateralRid, InsuranceType coverageType);

    void saveInsurableAssetAndCoverages(InsurableAssetDTO insurableAssetDTO, String userId);

    void saveInsurableAssetAndCoverages(List<InsurableAssetDTO> insurableAssetDTOList, String userId);

    void deleteInsurableAsset(Collection<Long> insurableAssetIds);

    void deleteInsurableAssetCoverageRequirement(Collection<Long> insurableAssetIds, CoverageRequirementStatus coverageStatus);

    InsurableAssetDTO mapInsurableAsset(InsurableAsset insurableAsset);

}
