package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

public enum CoverageAdjustmentIndicator {

	LP_ACTION_LP_NOT_REQUIRED ("LP Not Required"),
	LP_ACTION_LP_VENDOR_MAX ("New LP Vendor Max"),
	LP_ACTION_LP_NEW("New LP");
	
	private String displayName;
	private CoverageAdjustmentIndicator(String displayValue){
		this.displayName = displayValue;
	}

	public String getDisplayName() {
		return displayName;
	}
 public CoverageAdjustmentIndicator findBydisplayName(String displayName){
	 
	 for(CoverageAdjustmentIndicator candidate : CoverageAdjustmentIndicator.values()) {
		 if(candidate.getDisplayName().equals(displayName)){
			 return candidate;
		 }
	 }
	 return null;
 }

	
}
