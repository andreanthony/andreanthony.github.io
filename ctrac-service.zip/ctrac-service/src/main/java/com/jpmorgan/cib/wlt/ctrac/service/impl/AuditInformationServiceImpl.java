package com.jpmorgan.cib.wlt.ctrac.service.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.aspect.AuditInformationBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class AuditInformationServiceImpl implements AuditInformationService {

	private static final Logger logger = LoggerFactory.getLogger(AuditInformationServiceImpl.class);

	@Autowired
	private ApplicationContext context;

	@Override
	public String getLoggedInUserSid() {
		AuditInformationBean auditInfo = getAuditInformationBean();
		if (auditInfo != null) {
			try {
				return auditInfo.getUserSid();
			} catch (Exception e) {
				logger.trace("No session, returning SYSTEM: {}", e.getMessage());
			}
		}
		return "SYSTEM";
	}

	@Override
	public void setLoggedInUserSid(String loggedInUserSid) {
		AuditInformationBean auditInfo = getAuditInformationBean();
		if (auditInfo != null) {
			auditInfo.setUserSid(loggedInUserSid);
		} else {
			logger.error("Trying to set logged in user with no session.");
		}
	}

	@Override
	public void updateAuditInfo(CtracBaseEntity entity) {
		String userId = getLoggedInUserSid();
		if (entity.getInsertedBy() == null && entity.getInsertedDate() == null) {
			entity.setInitialAuditInfo(userId);
		} else {
			entity.updateAuditInfo(userId);
		}
	}

	@Override
	public void setAuditInformation(String loggedInUser, String firstName, String LastName) {
		AuditInformationBean auditInfo = getAuditInformationBean();
		if (auditInfo != null) {
			auditInfo.setUserSid(loggedInUser);
			auditInfo.setUserFirstName(firstName);
			auditInfo.setUserLastName(LastName);
		} else {
			logger.error(" setAuditInformation: Trying to set logged in user with no session.");
		}
	}

	@Override
	public AuditInformationBean getAuditInformation() {
		return getAuditInformationBean();
	}

	private AuditInformationBean getAuditInformationBean() {
		try {
			return context.getBean(AuditInformationBean.class);
		} catch (Exception e) {
			logger.trace("No session, returning null: {}", e.getMessage());
			return null;
		}
	}

}
