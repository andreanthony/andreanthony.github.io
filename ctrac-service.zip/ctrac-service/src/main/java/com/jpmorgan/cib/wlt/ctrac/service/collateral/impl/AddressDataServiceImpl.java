package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Address;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AddressRepository;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.AddressDataService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class AddressDataServiceImpl implements AddressDataService {

    @Autowired
    private AddressRepository addressRepository;
    @Autowired
    private CtracObjectMapper ctracObjectMapper;

    private static final Logger logger = Logger.getLogger(AddressDataServiceImpl.class);

    @Override
    @Transactional
    public void deleteAddress(AddressDto addressDto) {

        if (addressDto.getRid() != null) {
            addressRepository.delete(addressDto.getRid());
        }
    }

    @Override
    @Transactional
    public AddressDto saveAddress(AddressDto addressDto) {

        logger.debug("saveAddress(" + addressDto + ")::BEGIN");

        if (!addressDto.hasChanged()) {
            return addressDto;
        }

        Address oldAddress = new Address();
        // is it an old address?
        if (addressDto.getRid() != null) {
            oldAddress = addressRepository.findOne(addressDto.getRid());
        }

        ctracObjectMapper.map(addressDto, oldAddress);
        oldAddress.setVerifiedDate(new Date());
        Address savedAdress = addressRepository.saveAndFlush(oldAddress);
        addressDto.setRid(savedAdress.getRid());
        addressDto.refreshAuditUpdate(savedAdress);
        // cache a copy for comparison when saving back the object
        // if the properties values had not changed, skip saving to the DB
        addressDto.saveACopy();

        logger.debug("saveAddress::BEGIN");

        return addressDto;
    }
}
