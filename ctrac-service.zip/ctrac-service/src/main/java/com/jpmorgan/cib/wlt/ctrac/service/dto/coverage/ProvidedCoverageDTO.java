package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.io.Serializable;

public class ProvidedCoverageDTO extends BaseCoverageDataDTO implements Serializable, Cloneable {

    private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(ProvidedCoverageDTO.class);

    private Long rid;
    
    private String source;
	
	private String coveredByBlanketPolicy;
		
	private ProofOfCoverageDTO proofOfCoverageDto;
	
	private String coverageAdjustementIndicator;

	private ProvidedCoverageDTO loadTimeValue;
	
	private boolean showMismatchAmounts = false;

    //original Required coverage that caused this LPI
	private Long requiredCoverageRid;
	
	@Override
	public boolean hasNonZeroCoverage() {
		return super.hasNonZeroCoverage() || "Y".equals(coveredByBlanketPolicy);
	}
	
	public String getCoveredByBlanketPolicy() {
		return coveredByBlanketPolicy;
	}

	public void setCoveredByBlanketPolicy(String coveredByBlanketPolicy) {
		this.coveredByBlanketPolicy = coveredByBlanketPolicy;
	}
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public ProofOfCoverageDTO getProofOfCoverageDto() {
		return proofOfCoverageDto;
	}

	public void setProofOfCoverageDto(ProofOfCoverageDTO proofOfCoverageDto) {
		this.proofOfCoverageDto = proofOfCoverageDto;
	}

	public String getCoverageAdjustementIndicator() {
		return coverageAdjustementIndicator;
	}

	public void setCoverageAdjustementIndicator(String coverageAdjustementIndicator) {
		this.coverageAdjustementIndicator = coverageAdjustementIndicator;
	}
	
	public static ProvidedCoverageDTO build(InsurableAssetDTO insurableAssetDTO,
                                            CoverageDetailsDTO coverageDetailsDTO) {
		if (coverageDetailsDTO == null) {
			coverageDetailsDTO = new CoverageDetailsDTO();
			coverageDetailsDTO.setCoverageType(InsuranceType.FLOOD.name());
		}
		ProvidedCoverageDTO providedCoverageDTO = new ProvidedCoverageDTO();
		providedCoverageDTO.setInsurableAssetDTO(insurableAssetDTO);
		insurableAssetDTO.addProvidedCoverage(providedCoverageDTO);
		providedCoverageDTO.setCoverageDetailsDTO(coverageDetailsDTO);
		return providedCoverageDTO;
	}

	public ProvidedCoverageDTO getLoadTimeValue() {
		return loadTimeValue;
	}

	public void setLoadTimeValue(ProvidedCoverageDTO loadTimeValue) {
		this.loadTimeValue = loadTimeValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ProvidedCoverageDTO other = (ProvidedCoverageDTO) obj;
		if (rid == null) {
			if (other.rid != null) {
				return false;
			}
		} else if (!rid.equals(other.rid)) {
			return false;
		}
		return true;
	}

	private boolean deepEquals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProvidedCoverageDTO other = (ProvidedCoverageDTO) obj;
		if (!StringUtils.equals(coverageAdjustementIndicator, other.coverageAdjustementIndicator)) {
			return false;
		}
		if (!StringUtils.equals(coveredByBlanketPolicy, other.coveredByBlanketPolicy)) {
			return false;
		}
		if (getCoverageDetailsDTO() == null) {
			if (other.getCoverageDetailsDTO() != null) {
				return false;
			}
		} else if (!getCoverageDetailsDTO().equals(other.getCoverageDetailsDTO())) {
			return false;
		}
		if (getInsurableAssetDTO() == null) {
			if (other.getInsurableAssetDTO() != null) {
				return false;
			}
		} else if (!getInsurableAssetDTO().equals(other.getInsurableAssetDTO())) {
			return false;
		}
		if (proofOfCoverageDto == null) {
			if (other.proofOfCoverageDto != null) {
				return false;
			}
		} else if (!proofOfCoverageDto.equals(other.proofOfCoverageDto)) {
			return false;
		}
		if (rid == null) {
			if (other.rid != null) {
				return false;
			}
		} else if (!rid.equals(other.rid)){
			return false;
		}
		if(!StringUtils.equals(source, other.source)){
			return false;
		}

		return true;
	}
	
	
	public boolean hasChanged() {
		if(this.loadTimeValue ==null || this.getRid()==null){
			return true;
		}

		if(getCoverageDetailsDTO() != null && getCoverageDetailsDTO().hasChanged()){
			return true;
		}

		if(!deepEquals(this.loadTimeValue)){
			return true;
		}

		return super.hasChanged();
	}
	
	public void saveACopy () {
		try {
			getCoverageDetailsDTO().saveACopy();
			super.saveACopy();
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
        }
	}
	
	@Override
	public ProvidedCoverageDTO clone() throws CloneNotSupportedException {
		return (ProvidedCoverageDTO) super.clone();
	}

	public boolean isShowMismatchAmounts() {
		return showMismatchAmounts;
	}

	public void setShowMismatchAmounts(boolean showMismatchAmounts) {
		this.showMismatchAmounts = showMismatchAmounts;
	}

	public Long getRequiredCoverageRid() {
		return requiredCoverageRid;
	}

	public void setRequiredCoverageRid(Long requiredCoverageRid) {
		this.requiredCoverageRid = requiredCoverageRid;
	}
	
}
