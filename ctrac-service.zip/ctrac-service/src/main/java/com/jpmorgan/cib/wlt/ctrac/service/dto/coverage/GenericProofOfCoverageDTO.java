package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class GenericProofOfCoverageDTO extends ProofOfCoverageDTO {

	private static final long serialVersionUID = -849947576435802316L;
	private static final Logger logger = Logger.getLogger(GenericProofOfCoverageDTO.class);

	public GenericProofOfCoverageDTO() {
		super(null, null);
	}

	private String floodCoverageIncluded;
	
	private String coversAllRiskOfFlood;
	
	private String floodZonesListed;
	
	private String piaAssessmentExceptions;
	private GenericProofOfCoverageDTO loadTimeValue;

	public String getFloodCoverageIncluded() {
		return floodCoverageIncluded;
	}

	public void setFloodCoverageIncluded(String floodCoverageIncluded) {
		this.floodCoverageIncluded = floodCoverageIncluded;
	}

	public String getCoversAllRiskOfFlood() {
		return coversAllRiskOfFlood;
	}

	public void setCoversAllRiskOfFlood(String coversAllRiskOfFlood) {
		this.coversAllRiskOfFlood = coversAllRiskOfFlood;
	}

	public String getFloodZonesListed() {
		return floodZonesListed;
	}

	public void setFloodZonesListed(String floodZonesListed) {
		this.floodZonesListed = floodZonesListed;
	}

	public String getPiaAssessmentExceptions() {
		return piaAssessmentExceptions;
	}

	public void setPiaAssessmentExceptions(String piaAssessmentExceptions) {
		this.piaAssessmentExceptions = piaAssessmentExceptions;
	}


	private boolean deepEquals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		GenericProofOfCoverageDTO other = (GenericProofOfCoverageDTO) obj;
		if (!StringUtils.equals(floodCoverageIncluded, other.floodCoverageIncluded)) {
			return false;
		}
		if (!StringUtils.equals(coversAllRiskOfFlood, other.coversAllRiskOfFlood)) {
			return false;
		}
		if (!StringUtils.equals(floodZonesListed, other.floodZonesListed)) {
			return false;
		}
		if (!StringUtils.equals(piaAssessmentExceptions, other.piaAssessmentExceptions)) {
			return false;
		}
		return true;
	}

	@Override
	public void saveACopy() {
		try {
			super.saveACopy();
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	public boolean hasChanged(){
		if (this.loadTimeValue == null || this.getRid() == null) {
			return true;
		}
		if(!deepEquals(this.loadTimeValue)){
			return true;
		}
		return super.hasChanged();
	}

	@Override
	protected GenericProofOfCoverageDTO clone() throws CloneNotSupportedException {
		return (GenericProofOfCoverageDTO) super.clone();
	}

	public void setLoadTimeValue(GenericProofOfCoverageDTO loadTimeValue) {
		this.loadTimeValue = loadTimeValue;
	}

	public GenericProofOfCoverageDTO getLoadTimeValue() {
		return loadTimeValue;
	}
}
