package com.jpmorgan.cib.wlt.ctrac.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredProvidedCoverageGapViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.RequiredProvidedCoverageGapViewRepository;
import com.jpmorgan.cib.wlt.ctrac.service.ReportDataProviderService;

@Component
public class ReportDataProviderServiceImpl implements ReportDataProviderService{
	@Autowired private RequiredProvidedCoverageGapViewRepository requiredProvidedCoverageGapViewRepository;
	
	@Override
	public List<RequiredProvidedCoverageGapViewData> getGapReportData(){
		List<RequiredProvidedCoverageGapViewData> result = requiredProvidedCoverageGapViewRepository.findAll();
		return result;
	}
}
