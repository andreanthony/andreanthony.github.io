package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import java.util.ArrayList;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;


/**
 * 
 * @author n595724
 * This Class scope should stay "prototype";
 * if at some point we decide to make sprint manage it live circle, the scope must stay prototype
 * 
 */
public class SaveWorkflowDataCommand extends AbstractCommand {

	private final List<PerfectionTask> perfectionTasksToSave;

	public SaveWorkflowDataCommand(PerfectionTask perfectionTaskToSave) {
		this(perfectionTaskToSave, 0);
	}
	
	public SaveWorkflowDataCommand(PerfectionTask perfectionTaskToSave, int priority) {
		this.perfectionTasksToSave = new ArrayList<PerfectionTask>();
		this.perfectionTasksToSave.add(perfectionTaskToSave);
		this.priority = priority;
	}
	
	/**
	 *for now we assume that all the workflow data are in the perfectionTask Table 
	 *if this assumption turn out not to be true, the impact still minimal since this isn't and interface and we can always add 
	 *more constructor or fields to accommodate changes
	 */
	public SaveWorkflowDataCommand(List<PerfectionTask> perfectionTasksToSave) {
			this.perfectionTasksToSave = perfectionTasksToSave;
			this.priority =0;
	}

	/**
	 *for now we assume that all the workflow data are in the perfectionTask Table 
	 *if this assumption turn out not to be true, the impact still minimal since this isn't and interface and we can always add 
	 *more constructor or fields to accommodate changes
	 */
	public SaveWorkflowDataCommand(List<PerfectionTask> perfectionTasksToSave, int priotity){
			this.perfectionTasksToSave = perfectionTasksToSave;
			this.priority =priotity;
	}
	
	@Override
	public void execute() {
		PerfectionTaskService perfectionTaskService = ApplicationContextProvider.getContext().getBean(PerfectionTaskService.class);
		if (perfectionTasksToSave != null && !perfectionTasksToSave.isEmpty()) {
			perfectionTaskService.saveTasks(perfectionTasksToSave);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((perfectionTasksToSave == null) ? 0 : perfectionTasksToSave
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SaveWorkflowDataCommand other = (SaveWorkflowDataCommand) obj;
		if (perfectionTasksToSave == null) {
			if (other.perfectionTasksToSave != null)
				return false;
		} else if (!perfectionTasksToSave.equals(other.perfectionTasksToSave))
			return false;
		return true;
	}	

}