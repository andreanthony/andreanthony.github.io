package com.jpmorgan.cib.wlt.ctrac.service.event.service.request;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import org.apache.commons.lang.StringUtils;

public class LPIProofOfCoveragePublishEventRequest extends AbstractPublishEventRequest {

    ProofOfCoverageDTO proofOfCoverageDTO;

    public LPIProofOfCoveragePublishEventRequest(ProofOfCoverageDTO proofOfCoverageDTO, Long collateralRid,
                                                 String lineOfBusiness, boolean isSystemEvent){
        this.collateralRid = collateralRid;
        this.lineOfBusiness = lineOfBusiness;
        this.proofOfCoverageDTO = proofOfCoverageDTO;
        this.isSystemEvent = isSystemEvent;
    }

    public LPIProofOfCoveragePublishEventRequest forCollateralEventType(CollateralEventType collateralEventType){
        this.collateralEventType = collateralEventType;
        return this;
    }

    @Override
    public String getDescription(){
        if(collateralEventType == CollateralEventType.VERIFIED_LP_WITH_WORFLOW &&
                proofOfCoverageDTO.getLetterCycleWorkflowStep() != null) {
            return proofOfCoverageDTO.getLetterCycleWorkflowStep().getName();
        }
        String migrated = proofOfCoverageDTO.getMigrated()? " - Migrated" : "";
        return new StringBuilder("LPI ").append(proofOfCoverageDTO.getPolicyStatus().getDisplayName())
                .append(migrated).toString();
    }

    @Override
    public String getIdentifier(){
        if(this.proofOfCoverageDTO.getRid() != null) {
            return this.proofOfCoverageDTO.getRid().toString();
        }
        return StringUtils.EMPTY;
    }

}
