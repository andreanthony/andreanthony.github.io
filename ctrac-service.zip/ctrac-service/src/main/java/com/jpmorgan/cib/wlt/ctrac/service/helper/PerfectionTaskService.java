package com.jpmorgan.cib.wlt.ctrac.service.helper;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;

import java.util.List;
import java.util.Map;

public interface PerfectionTaskService {
	
	PerfectionTask createOpenTask(WorkItem workItem, TaskState state,
			TMTaskType TMTaskType, Map<StateParameterType, Object> inputParameterMap);

	PerfectionTask createSleepingTask(WorkItem workItem, TaskState state,
			TMTaskType TMTaskType, Map<StateParameterType, Object> inputParameterMap);
	
	PerfectionTask createTransientTask(WorkItem workItem, TaskState state,
			TMTaskType TMTaskType, Map<StateParameterType, Object> inputParameterMap);

    PerfectionTask createTask(TaskStatus taskStatus, WorkItem workItem, TaskState state,
                              TMTaskType TMTaskType, String insertedBy, Map<StateParameterType, Object> inputParameterMap);

    PerfectionTask closeTask(PerfectionTask perfectionTask, WorkflowStateDefinition workflowStateDefinition);

    PerfectionTask closeTask(PerfectionTask perfectionTask, WorkflowStateDefinition workflowStateDefinition, String closeReason, String comments);

    PerfectionTask closeTask(PerfectionTask perfectionTask, boolean andFlush);

    PerfectionTask closeTask(PerfectionTask perfectionTask, WorkflowStateDefinition workflowStateDefinition, boolean andFlush, String closeReason, String comments);

    PerfectionTask createTask(TaskStatus taskStatus, WorkItem workItem, TaskState state,
                              TMTaskType TMTaskType, String insertedBy, boolean andFlush, Map<StateParameterType, Object> inputParameterMap);

    Collateral getCollateralFromPerfectionTask(PerfectionTask perfectionTask);

    List<PerfectionTask> saveTasks(List<PerfectionTask> perfectionTasksToSave);

    PerfectionTask saveTask(PerfectionTask perfectionTask);

    PerfectionTask saveTask(PerfectionTask perfectionTask, boolean andFlush);

    List<PerfectionTask> findTasksForWorkItem(WorkItem workItem, List<String> workflowSteps, List<String> taskStatuses);
}
