package com.jpmorgan.cib.wlt.ctrac.service.email.impl;

import microsoft.exchange.webservices.data.Importance;

import java.io.File;
import java.util.List;

/**
 * Created by E704298 on 10/25/2017.
 */
public interface EmailAlertSender {

    void sendAlertEmail(String toAddress, String ccAddress, String subject, String emailBody,
                        List<File> attachments, Importance importance);

    void sendExceptionEmailToDevTeam(String subject, String emailBody, List<File> attachments);

    void sendAlertEmailToFloodTeam(String subject, String emailBody, Importance importance);

    void sendEmailToFloodTeam(String subject, String emailBody, List<File> attachments);
}
