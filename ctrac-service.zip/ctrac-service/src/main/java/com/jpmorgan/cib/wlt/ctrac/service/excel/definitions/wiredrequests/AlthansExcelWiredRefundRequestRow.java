package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.wiredrequests;

import java.math.BigDecimal;
import java.util.Date;

public class AlthansExcelWiredRefundRequestRow {

	private String methodOfPayment;
	private String loanNumber;
	private String costCenterDisplayValue;
	private String generalLedger;
	private String ddaNumber;
	private String clientName;
	private Date policyCancellationDate;
	private String refundMailingAddress;
	private BigDecimal premiumAmountDouble;
	private String policyRid;
	private BigDecimal refundAmountDouble;
	private String payorDisplayValue;

	private String collateralAddress;
	private String collateralUnit;
	private String collateralCity;
	private String collateralState;
	private String collateralZip;
	private String buildingName;
	private Date policyExpirationDay;
	private Date policyEffectiveDay;
	private String coverageType;

	public Date getPolicyEffectiveDay() {
		return policyEffectiveDay;
	}

	public void setPolicyEffectiveDay(Date policyEffectiveDay) {
		this.policyEffectiveDay = policyEffectiveDay;
	}



	public String getCollateralAddress() {
		return collateralAddress;
	}

	public void setCollateralAddress(String collateralAddress) {
		this.collateralAddress = collateralAddress;
	}

	public String getCollateralUnit() {
		return collateralUnit;
	}

	public void setCollateralUnit(String collateralUnit) {
		this.collateralUnit = collateralUnit;
	}

	public String getCollateralCity() {
		return collateralCity;
	}

	public void setCollateralCity(String collateralCity) {
		this.collateralCity = collateralCity;
	}

	public String getCollateralState() {
		return collateralState;
	}

	public void setCollateralState(String collateralState) {
		this.collateralState = collateralState;
	}

	public String getCollateralZip() {
		return collateralZip;
	}

	public void setCollateralZip(String collateralZip) {
		this.collateralZip = collateralZip;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public Date getPolicyExpirationDay() {
		return policyExpirationDay;
	}

	public void setPolicyExpirationDay(Date policyExpirationDay) {
		this.policyExpirationDay = policyExpirationDay;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getMethodOfPayment() {
		return methodOfPayment;
	}

	public void setMethodOfPayment(String methodOfPayment) {
		this.methodOfPayment = methodOfPayment;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getCostCenterDisplayValue() {
		return costCenterDisplayValue;
	}

	public void setCostCenterDisplayValue(String costCenterDisplayValue) {
		this.costCenterDisplayValue = costCenterDisplayValue;
	}

	public String getGeneralLedger() {
		return generalLedger;
	}

	public void setGeneralLedger(String generalLedger) {
		this.generalLedger = generalLedger;
	}

	public String getDdaNumber() {
		return ddaNumber;
	}

	public void setDdaNumber(String ddaNumber) {
		this.ddaNumber = ddaNumber;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public Date getPolicyCancellationDate() {
		return policyCancellationDate;
	}

	public void setPolicyCancellationDate(Date policyCancellationDate) {
		this.policyCancellationDate = policyCancellationDate;
	}

	public String getRefundMailingAddress() {
		return refundMailingAddress;
	}

	public void setRefundMailingAddress(String refundMailingAddress) {
		this.refundMailingAddress = refundMailingAddress;
	}

	public BigDecimal getRefundAmountDouble() {
		return refundAmountDouble;
	}

	public void setRefundAmountDouble(BigDecimal refundAmountDouble) {
		this.refundAmountDouble = refundAmountDouble;
	}

	public BigDecimal getPremiumAmountDouble() {
		return premiumAmountDouble;
	}

	public void setPremiumAmountDouble(BigDecimal premiumAmountDouble) {
		this.premiumAmountDouble = premiumAmountDouble;
	}

	public String getPolicyRid() {
		return policyRid;
	}

	public void setPolicyRid(String policyRid) {
		this.policyRid = policyRid;
	}

	public String getPayorDisplayValue() {
		return payorDisplayValue;
	}

	public void setPayorDisplayValue(String payorDisplayValue) {
		this.payorDisplayValue = payorDisplayValue;
	}
}
