/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.service.customer.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.dao.config.DataSourceConfig;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CollateralOwner;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Loan;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LoanBorrower;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.EntitySearchViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralOwnerRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CustomerRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EntitySearchCriteria;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EntitySearchViewDataRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.LoanBorrowerRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.LoanRepository;
import com.jpmorgan.cib.wlt.ctrac.service.customer.CustomerService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.DataTablesRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.EntityDataTableDto;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.specifications.EntityDataSpecs;

/**
 * @author n657508
 *
 */
@Service(value = "customerService")
public class CustomerServiceImpl implements CustomerService {
	
	@Resource
	private Environment env;

    @Autowired
    private CustomerRepository customerRepository;
    
    @Autowired
    private CtracObjectMapper mapper;
    
    @Autowired
    private EntitySearchViewDataRepository entitySearchViewDataRepository;
    
    @Autowired
    private LoanBorrowerRepository loanBorrowerRepository;
    
    @Autowired
    private CollateralOwnerRepository collateralOwnerRepository;
    
    @Autowired
    private CollateralRepository collateralRepository;
    
    @Autowired
    private LoanRepository loanRepository;
    
    private static final Logger logger = Logger.getLogger(CustomerServiceImpl.class);

    @Override
    @Transactional
    public List<Customer> findAllByNameSoudexOrLike(String name) {

        logger.debug("findAllByNameSoudex(" + name + " )::BEGIN");
        if(name == null || name.isEmpty()) {
        	return new ArrayList<Customer>();
        }
        List<Customer> customers = customerRepository.findAllByNameSoudexOrLike(name, "%" + name.toUpperCase() + "%");

        logger.debug("findAllByNameSoudex::END");
        return customers;
    }
    
	
	@Override
	@Transactional(readOnly = true)
	public List<EntityDataTableDto> getEntities(DataTablesRequest dataTablesRequest) {
		logger.debug("getEntities:: start");
		Specification<EntitySearchViewData> allSearchCriteria = EntityDataSpecs.deriveAllSearchCritera((EntityDataTableDto)dataTablesRequest.getSearchCriteria());
		List<EntitySearchViewData> customerList = entitySearchViewDataRepository.findAll(allSearchCriteria);
		
		if(customerList == null || customerList.isEmpty()){
			return new ArrayList<EntityDataTableDto>();
		}
		dataTablesRequest.setLength(customerList.size());
		List<EntityDataTableDto> entityDataTableDtoList = mapper.mapAsList(customerList, EntityDataTableDto.class);
		logger.debug("getEntities:: end");
		return entityDataTableDtoList;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<EntityDataTableDto> getEntities(EntitySearchCriteria entitySearchCriteria, DataTablesRequest dataTablesRequest) {
		logger.debug("getEntities:: start");
		List<EntitySearchViewData> customerList = null;
		
		if("LOANSUSR02".equals(env.getRequiredProperty(DataSourceConfig.PROPERTY_NAME_DATABASE_USERNAME))){
			customerList = entitySearchViewDataRepository.getEntityRecordsLOANS02(entitySearchCriteria.getCustomerId(), 
					entitySearchCriteria.getName(), entitySearchCriteria.getAddress(), entitySearchCriteria.getCity(), entitySearchCriteria.getState(),
					entitySearchCriteria.getZip(), entitySearchCriteria.getCollateralRids(), entitySearchCriteria.getCollateralRid(), entitySearchCriteria.getLoanRid());	
		} else { 		
			customerList = entitySearchViewDataRepository.getEntityRecords(entitySearchCriteria.getCustomerId(), 
				entitySearchCriteria.getName(), entitySearchCriteria.getAddress(), entitySearchCriteria.getCity(), entitySearchCriteria.getState(),
				entitySearchCriteria.getZip(), entitySearchCriteria.getCollateralRids(), entitySearchCriteria.getCollateralRid(), entitySearchCriteria.getLoanRid());		
		}
		if(customerList == null || customerList.isEmpty()){
			return new ArrayList<EntityDataTableDto>();
		}
		dataTablesRequest.setLength(customerList.size());
		List<EntityDataTableDto> entityDataTableDtoList = mapper.mapAsList(customerList, EntityDataTableDto.class);
		logger.debug("getEntities:: end");
		return entityDataTableDtoList;
	}


	@Override
	@Transactional
	public void mergeTo(Map<Long, EntityDataTableDto> entities, Long entityRidToKeep) {
		logger.debug("mergeEntitiesTo:: start entity to keep: " + entityRidToKeep + "number of entities to merge" + entities.size());
		Customer customerToKeep = customerRepository.findOne(entityRidToKeep);	
		if(customerToKeep == null || entities.size() <= 1) return;
		List<Customer> customersToPurge = new ArrayList<Customer>();
		for(Long customerRid: entities.keySet()){
			if(!customerRid.equals(entityRidToKeep))
				customersToPurge.add(customerRepository.findOne(customerRid));
		}
	    mergeBorrowers(entities, customerToKeep);
		mergeOwners(entities, customerToKeep);
		customerRepository.delete(customersToPurge);
		logger.debug("getEntities:: end");
	}


	private void mergeOwners(Map<Long, EntityDataTableDto> entities, Customer customerToKeep) {
		Set<Collateral> collaterals = new HashSet<Collateral>();
		for(Long customerRid: entities.keySet()){
			if(!customerRid.equals(customerToKeep.getRid())){
				List<CollateralOwner> coList = collateralOwnerRepository.findByOwnerRid(customerRid);
			    if(coList != null && !coList.isEmpty()){
			    	for(CollateralOwner co: coList){
			    		collaterals.add(co.getCollateral());
			    		removeOwner(co);
			    	}
			    }
			}
		}
		for(Collateral c: collaterals){
			c.addOwner(customerToKeep);
		}
		collateralRepository.save(collaterals);
	}

	private void removeOwner(CollateralOwner co) {
		co.getCollateral().getCollateralOwners().remove(co);
		co.getOwner().getCollateralOwners().remove(co);
		collateralOwnerRepository.delete(co);
	}

	private void mergeBorrowers(Map<Long, EntityDataTableDto> entities, Customer customerToKeep) {
		Set<Loan> loans = new HashSet<Loan>();
		for(Long customerRid: entities.keySet()){
			if(!customerRid.equals(customerToKeep.getRid())){
				List<LoanBorrower> coList = loanBorrowerRepository.findByBorrowerRid(customerRid);
			    if(coList != null && !coList.isEmpty()){
			    	for(LoanBorrower lb: coList){
			    		loans.add(lb.getLoan());
			    		removeBorrower(lb);
			    	}
			    }
			}
		}
		for(Loan l: loans){
			l.addBorrower(customerToKeep);
		}
		loanRepository.save(loans);
	}



	private void removeBorrower(LoanBorrower lb){
		lb.getLoan().getLoanBorrowers().remove(lb);
		lb.getBorrower().getLoanBorrowers().remove(lb);
		loanBorrowerRepository.delete(lb);
	}
	
 
 }
