package com.jpmorgan.cib.wlt.ctrac.service.api.collateral.building;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;

import java.io.Serializable;
import java.util.List;

public class BuildingDTO implements Serializable {
    private static final long serialVersionUID = 1;
    public static final String INITIAL_BUILDING_NAME = "*";

    public BuildingDTO() {
        super();
    }

    public BuildingDTO(Long collateralId) {
        super();
        this.collateralId = collateralId;
        this.buildingName = INITIAL_BUILDING_NAME;
        this.active = true;
        this.sortOrder = 0;
    }

    private Long rid;

    private Long collateralId;

    private List<InsurableAssetDTO> insurableAssets;

    private String buildingName;

    private Boolean active;

    private Integer sortOrder;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public Long getCollateralId() {
        return collateralId;
    }

    public void setCollateralId(Long collateralRid) {
        this.collateralId = collateralRid;
    }

    public List<InsurableAssetDTO> getInsurableAssets() {
        return insurableAssets;
    }

    public void setInsurableAssets(List<InsurableAssetDTO> insurableAssets) {
        this.insurableAssets = insurableAssets;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }
}
