package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;

import javax.validation.Valid;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.DB_FLAG_NO;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.DB_FLAG_YES;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.UI_FLAG_FALSE;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.UI_FLAG_TRUE;

import java.io.Serializable;

public class FloodRemapResearchDto extends FloodRemapDto implements Serializable {
	
	private static final long serialVersionUID = -232021800118654851L;
    private String clientFoundRadio;
	
	private String propertyPledgeRadio;

	private String exposureRadio;	
	
	protected Character clientFound;

	protected Character propertyPledge;

	protected Character exposure;

	@Valid
	private CompleteTaskData completeTaskData = new CompleteTaskData();
	
	private String marketEmailAddress;
	
	private String ccEmailAddress;

	@NoInvalidCharacters
	private String collateralId;
	
	private String collateralPropertyAddress;
	
	private Boolean collateralReviewed;
	
	private String collateralErrorMessage;

	private String collateralDescription;
	
	private TMParams tmParams;
	
    public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	public Character getClientFound() {
		return clientFound;
	}

	public void setClientFound(Character clientFound) {
		this.clientFound = clientFound;
	}

	public Character getPropertyPledge() {
		return propertyPledge;
	}

	public void setPropertyPledge(Character propertyPledge) {
		this.propertyPledge = propertyPledge;
	}

	public Character getExposure() {
		return exposure;
	}

	public void setExposure(Character exposure) {
		this.exposure = exposure;
	}
	
  	public String getMarketEmailAddress() {
		return marketEmailAddress;
	}

	public void setMarketEmailAddress(String marketEmailAddress) {
		this.marketEmailAddress = marketEmailAddress;
	}

	public String getCollateralId() {
		return collateralId;
	}

	public void setCollateralId(String collateralId) {
		this.collateralId = collateralId;
	}

	public String getCollateralPropertyAddress() {
		return collateralPropertyAddress;
	}

	public void setCollateralPropertyAddress(String collateralPropertyAddress) {
		this.collateralPropertyAddress = collateralPropertyAddress;
	}

	public Boolean getCollateralReviewed() {
		return collateralReviewed;
	}

	public void setCollateralReviewed(Boolean collateralReviewed) {
		this.collateralReviewed = collateralReviewed;
	}

	public CompleteTaskData getCompleteTaskData() {
		return completeTaskData;
	}

	public void setCompleteTaskData(CompleteTaskData completeTaskData) {
		this.completeTaskData = completeTaskData;
	}

	public String getClientFoundRadio() {
		return clientFoundRadio;
	}
	
	public void setClientFoundRadio(String clientFoundRadio) {
		this.clientFoundRadio = clientFoundRadio;		
		if (UI_FLAG_TRUE.equalsIgnoreCase(this.clientFoundRadio)) {
			this.clientFound = DB_FLAG_YES;
		} else if (UI_FLAG_FALSE.equalsIgnoreCase(this.clientFoundRadio)) {
			this.clientFound = DB_FLAG_NO;
		}
	}

	public String getPropertyPledgeRadio() {
		return propertyPledgeRadio;
	}

	public String getCcEmailAddress() {
		return ccEmailAddress;
	}

	public void setCcEmailAddress(String ccEmailAddress) {
		this.ccEmailAddress = ccEmailAddress;
	}

	public void setPropertyPledgeRadio(String propertyPledgeRadio) {
		this.propertyPledgeRadio = propertyPledgeRadio;
		if (UI_FLAG_TRUE.equalsIgnoreCase(this.propertyPledgeRadio)) {
			this.propertyPledge = DB_FLAG_YES;
		} else if (UI_FLAG_FALSE.equalsIgnoreCase(this.propertyPledgeRadio)) {
			this.propertyPledge = DB_FLAG_NO;
		}
	}

	public String getExposureRadio() {
		return exposureRadio;
	}

	public void setExposureRadio(String exposureRadio) {
		this.exposureRadio = exposureRadio;
		if (UI_FLAG_TRUE.equalsIgnoreCase(this.exposureRadio)) {
			this.exposure = DB_FLAG_YES;
		} else if (UI_FLAG_FALSE.equalsIgnoreCase(this.exposureRadio)) {
			this.exposure = DB_FLAG_NO;
		}
	}

	public String getCollateralDescription() {
		return collateralDescription;
	}

	public void setCollateralDescription(String collateralDescription) {
		this.collateralDescription = collateralDescription;
	}

	public String getCollateralErrorMessage() {
		return collateralErrorMessage;
	}

	public void setCollateralErrorMessage(String collateralErrorMessage) {
		this.collateralErrorMessage = collateralErrorMessage;
	}
}
