package com.jpmorgan.cib.wlt.ctrac.service.batch;

import java.util.Set;

public interface InsurancePolicyBatchService {

	/**
	 * Process the expiring Borrower and LP policies. Trigger C3 if necessary.
	 * @return Collateral RIDs for which C3 was triggered.
	 */
	Set<Long> processExpiringPolicies();
	
	/**
	 * Process the expiring Borrower and LP policies. Trigger C3 if necessary and if not already processed.
	 * @return Collateral RIDs for which C3 was triggered.
	 */
	Set<Long> processExpiringPolicies(Set<Long> collateralsProcessed);
	
	/**
	 * Process newly effective Borrower policies. Trigger C3 if necessary and if not already processed.
	 * @return Collateral RIDs for which C3 was triggered.
	 */
	Set<Long> processNewlyEffectivePolicies(Set<Long> collateralsProcessed);
	
}
