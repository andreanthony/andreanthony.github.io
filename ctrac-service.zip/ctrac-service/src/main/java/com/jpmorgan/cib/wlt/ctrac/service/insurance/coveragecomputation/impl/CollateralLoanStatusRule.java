package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import java.util.Date;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Loan;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;

public class CollateralLoanStatusRule extends CollateralCoverageRule {
	
	private static final Logger logger = Logger.getLogger(CollateralLoanStatusRule.class);
	
	public CollateralLoanStatusRule(Collateral collateral, WorkItem triggerWorkItem, Date today) {
		super(collateral, triggerWorkItem, today);
	}
	
	/**
	 * We must have at least one active loan attached to the collateral
	 */
	@Override
	public void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult globalResults) {
		init();
		
		/**
		 * if the collateral does not have at least one active loan, we do not need coverage
		 */
		Date latestPaidOffDate = null;
		for (Loan loan : collateral.getAllLoans()) {
			LoanStatus loanStatus = loan.getStatus_();
			if (loanStatus != null && loanStatus.isActive()) {
				logger.debug("Found an active loan");
				return;
			} else if (latestPaidOffDate == null ||
					(loan.getReleasedDate() != null && latestPaidOffDate.before(loan.getReleasedDate()))) {
				latestPaidOffDate = loan.getReleasedDate();
			}
		}
        
		if (latestPaidOffDate == null) {
			// FIXME ask what need to be done
			logger.error("No active loans and no paid off date; using today");
			latestPaidOffDate = today;
		}
		
        /**
         * If all loans are inactive,  we do not need coverage: cancel all LP policies and stop; (there is nothing else to do).
         */
		prepareCancelCollateralLpPolicies(globalResults, latestPaidOffDate, CancellationReason.LOAN_PAID_OFF);
	}

	@Override
	public Integer getPriority() {
		return 1005;
	}

}
