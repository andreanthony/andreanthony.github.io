package com.jpmorgan.cib.wlt.ctrac.service.dto.view;

public class DeterminationDetailsViewDto {
	private Long rid;
	
	private Long collateralRid;
	
	private String floodZone;
	
	private String loanIdentifier;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getLoanIdentifier() {
		return loanIdentifier;
	}

	public void setLoanIdentifier(String loanIdentifier) {
		this.loanIdentifier = loanIdentifier;
	}
	
	
}
