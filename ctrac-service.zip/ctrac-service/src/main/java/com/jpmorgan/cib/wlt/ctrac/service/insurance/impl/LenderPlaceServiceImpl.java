package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.WorkItemAndRelationsService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.impl.AbstractRemapServiceImpl;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralHelperService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.email.EmailDataDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.*;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailTemplateRetrievalService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PDFChecker;
import com.jpmorgan.cib.wlt.ctrac.service.helper.coverage.ProvidedCoverageUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.StateToBeAggregated;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.EMAIL_TEMPLATE_LP_PREMIUM_PAID;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.*;

// FIXME: Remove dependency on AbstractRemapServiceImpl
@Service(value = "lenderPlaceService")
@Transactional(readOnly = true)
public class LenderPlaceServiceImpl extends AbstractRemapServiceImpl implements LenderPlaceService {

	private static final Logger logger = Logger.getLogger(LenderPlaceServiceImpl.class);

	@Autowired private CollateralHelperService collateralHelperService;
	@Autowired private CtracObjectMapper ctracObjectMapper;
	@Autowired private DateCalculator dateCalculator;
	@Autowired private InsuranceMngtService insuranceMngtService;
	@Autowired private LoanManagementService loanManagementService;
	@Autowired private ViewDataRetrievalService viewDataRetrievalService;
	@Autowired private LookupCodeRepository lookupCodeRepository;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	@Autowired private ProvidedCoverageRepository providedCoverageRepository;
	@Autowired private TaskService taskService;
	@Autowired private WorkItemRepository workItemRepository;
	@Autowired private CollateralMainDetailsViewRepository collateralMainDetailsRepository;
	@Autowired private FloodDeterminationRepository floodDeterminationRepository;
	@Autowired private CustomerRepository customerRepository;
	@Autowired private ProofOfCoverageDetailsViewRepository proofOfCoverageDetailsViewRepository;
	@Autowired private ProvidedCoverageViewRepository providedCoverageViewRepository;
	@Autowired private CalendarDayUtil calendarDayUtil;
    @Autowired private EmailTemplateRepository emailTemplateRepository;
    @Autowired private CollateralWorkItemRepository collateralWorkItemRepository;
    @Autowired private WorkItemRelationRepository workItemRelationRepository;
	@Autowired private WorkItemAndRelationsService workItemAndRelationsService;
	@Autowired private AccountWireReferenceRepository accountWireReferenceRepository;
	@Autowired private EmailTemplateRetrievalService emailTemplateRetrievalService;
	@Autowired private CollateralDocumentService collateralDocumentService;
	@Autowired private CollateralDocumentRepository collateralDocumentRepository;
	@Autowired private RequiredCoverageViewRepository requiredCoverageViewRepository;
	@Autowired private Environment env;
	@Autowired private CollateralRepository collateralRepository;

	@Override
	public VerifyLetterData preparePolicyVerifyLetterDates(TMParams tmParams) {
		logger.debug("preparePolicyVerifyLetterDates::BEGIN");

		 PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmParams.getId_task());
	     WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);

	     VerifyLetterData verifyLetterData = ctracObjectMapper.map(workItem, VerifyLetterData.class);
	     Long collateralRid = workItem.getCollateralWorkItems().get(0).getCollateral().getRid();

	     //1. pull Primary Borrower
	     verifyLetterData.setPrimaryLoanBorrowerViewDto(viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(collateralRid));

	     //2. Pull Collateral Owner
	     verifyLetterData.setMortgagorNames(viewDataRetrievalService.getMortgagorNames(collateralRid));

	     //3. Pull Collateral Main Details
	     verifyLetterData.setCollateralMainDetailsViewDto(viewDataRetrievalService.getCollateralMainDetails(collateralRid));

	     //4. Pull flood zone from flood determination section
	     FloodDetermination floodDetermination = floodDeterminationRepository.findByCollateralRidAndStatus(collateralRid, VerificationStatus.VERIFIED.toString());
	     verifyLetterData.setFloodZone(floodDetermination.getFloodZone());

	     //5. Proof of coverage details
	     Long workItemRid = workItem.getRid();
	     ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto = viewDataRetrievalService.getLPProofOfCoverageDetails(workItemRid);
	     verifyLetterData.setProvidedCoverageDetailsViewDto(providedCoverageDetailsViewDto);

	     String lpCoverageType = ProvidedCoverageUtil.getFloodLPCoverageType(providedCoverageDetailsViewDto.getAssetType());
	     verifyLetterData.setLpCoverageType(lpCoverageType);

	     Long proofOfCoverageRid=verifyLetterData.getProvidedCoverageDetailsViewDto().getProofOfCoverageRid();
	     verifyLetterData.setProofOfCoverageDetailsViewDto(viewDataRetrievalService.getProofOfCoverageDetailsByRid(proofOfCoverageRid));

	    //6. Add commnon attributes
	     addCommonLenderPlaceAttributes(verifyLetterData,perfectionTask,tmParams);

		String firstLetterDate = verifyLetterData.getFirstLetterDate();

		if (firstLetterDate != null) {
		    verifyLetterData.setFirstLetterDatePlusOne(getDatePlusOne(firstLetterDate));
		}
		logger.debug("preparePolicyVerifyLetterDates::END");
		return verifyLetterData;
	}


    @Override
    @Transactional(readOnly = false)
	public void processSaveDateOfLetter(final VerifyLetterData verifyLetterData, HttpServletRequest request) {
		logger.debug("processSaveDateOfLetter::BEGIN");
		processLenderPlaceData(verifyLetterData);
		logger.debug("processSaveDateOfLetter::END");
	}

	@Override
	public VendorInvoiceData prepareVendorInvoiceVerificationData(TMParams tmParams) {
		logger.debug("prepareVendorInvoiceVerificationData::BEGIN");
		VendorInvoiceData vendorInvoiceData = prepareLenderPlaceData(tmParams, VendorInvoiceData.class);
		vendorInvoiceData.setStateCodes(getStateCodes());

		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmParams.getId_task());
	    WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);

	    getCLWNumber(vendorInvoiceData, workItem);
	    if(PerfectionItemSubType.FLOOD_RENEWAL.equals(workItem.getPerfectionSubType_())){
	    	vendorInvoiceData.setRenewal(true);
	    }else{
	    	vendorInvoiceData.setRenewal(false);
	    }

	    Long collateralRid = workItem.getCollateralWorkItems().get(0).getCollateral().getRid();
	    PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto = viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(collateralRid);
	    Customer customer = customerRepository.findOne(primaryLoanBorrowerViewDto.getBorrowerRid());
		CustomerData borrowerData = ctracObjectMapper.map(customer, CustomerData.class);
		primaryLoanBorrowerViewDto.setBorrowerData(borrowerData);
		vendorInvoiceData.setPrimaryLoanBorrowerViewDto(primaryLoanBorrowerViewDto);

		CollateralMainDetailsViewData collateralMainDetailsView =
				collateralMainDetailsRepository.findByCollateralRid(collateralRid);
	    CollateralMainDetailsViewDto collateralMainDetailsViewDtoMapData =
	    		ctracObjectMapper.map(collateralMainDetailsView, CollateralMainDetailsViewDto.class);

	    Long proofOfCoverageId = vendorInvoiceData.getProofOfCoverageData().getRid();

	  //  CollateralDocumentService.

	    ProofOfCoverageDetailsViewData collateralProofOfCoverageDetailsView =
	    		proofOfCoverageDetailsViewRepository.findByProofOfCoverageRid(proofOfCoverageId);
	    ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto =
	    		ctracObjectMapper.map(collateralProofOfCoverageDetailsView, ProofOfCoverageDetailsViewDto.class);
	    vendorInvoiceData.setProofOfCoverageDetailsViewDto(proofOfCoverageDetailsViewDto);
	    vendorInvoiceData.setCollateralMainDetailsViewDto(collateralMainDetailsViewDtoMapData);
		vendorInvoiceData.setBranchCode(loanManagementService.getBranchCode(vendorInvoiceData.getPrimaryLoanBorrowerViewDto().getLoanRid()));

		Long insurableAssetId = vendorInvoiceData.getProofOfCoverageData().getProvidedCoverageDTOs().get(0).getInsurableAssetDTO().getRid();
	    ProvidedCoverageViewData collateralProveOfCoverageViewData=providedCoverageViewRepository.findByProofOfCoverageRidAndInsurableAssetRid(proofOfCoverageId, insurableAssetId);
	    ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto=ctracObjectMapper.map(collateralProveOfCoverageViewData, ProvidedCoverageDetailsViewDto.class);
	    vendorInvoiceData.setProvidedCoverageDetailsViewDto(providedCoverageDetailsViewDto);

	    vendorInvoiceData.setVendorCertificates(collateralDocumentService.getPolicyDocs(providedCoverageDetailsViewDto.getProofOfCoverageRid(), CtracAppConstants.PREMIUM_CERTIFICATE));

	    String lpCoverageType = ProvidedCoverageUtil.getFloodLPCoverageType(providedCoverageDetailsViewDto.getAssetType());
	    vendorInvoiceData.setLpCoverageType(lpCoverageType);

	    if(proofOfCoverageDetailsViewDto.getPolicyStatus().equals(PolicyStatus.CANCELLED.name())){
	    	vendorInvoiceData.setIsPolicyCancelled(true);
	    }else{
	    	vendorInvoiceData.setIsPolicyCancelled(false);
	    }

	    vendorInvoiceData.setVendorPaymentMethods(getVendorPaymentMethodList(vendorInvoiceData.getIsPolicyCancelled()));

	    RequiredCoverageViewDto requiredCoverageViewDto=viewDataRetrievalService.getRequiredCoverageViewData(collateralRid, insurableAssetId);
	    vendorInvoiceData.setRequiredCoverageViewDto(requiredCoverageViewDto);
		logger.debug("prepareVendorInvoiceVerificationData::END");
		return vendorInvoiceData;
	}

	@Override
	public LPPolicyCertificateData prepareLPPolicyData(TMParams tmParams) {
		logger.debug("prepareLPPolicyData::BEGIN");
		LPPolicyCertificateData policyData = prepareLenderPlaceData(tmParams, LPPolicyCertificateData.class);

		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmParams.getId_task());
	    WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);
	    Long collateralRid = workItem.getCollateralWorkItems().get(0).getCollateral().getRid();

	    populateLPPolicyCollateralData(policyData, collateralRid, true, true, true, true,true);

		String lpCoverageType = ProvidedCoverageUtil.getFloodLPCoverageType (policyData.getRequiredCoverageViewDto().getAssetType());
	      policyData.setLpCoverageType(lpCoverageType);

	    if(WorkflowStateDefinition.IMAGE_CANCELLATION_CERTIFICATE.getName().equals(perfectionTask.getWorkflowStep())){
	    	policyData.setCancellationWorkflow(true);
	    	policyData.setScreenTitle("Image Cancellation Certificate");
	    	policyData.setRequiredConfirmationMessage("Cancellation Certificate Imaged");
	    	policyData.setCancellationCertificate(collateralDocumentService.getUniquePolicyDoc(policyData.getProofOfCoverageData().getRid(), CtracAppConstants.REFUND_CERTIFICATE));

	    }else if (WorkflowStateDefinition.IMAGE_CERTIFICATE.getName().equals(perfectionTask.getWorkflowStep())){
	    	policyData.setCancellationWorkflow(true);
	    	policyData.setScreenTitle("Image Certificate");
	    	policyData.setRequiredConfirmationMessage("Premium Certificate Imaged");
	    	policyData.setCancellationCertificate(collateralDocumentService.getUniquePolicyDoc(policyData.getProofOfCoverageData().getRid(), CtracAppConstants.PREMIUM_CERTIFICATE));
	    } else{
	    	policyData.setCancellationWorkflow(false);
	    	policyData.setScreenTitle("Verify Certificate");
	    	policyData.setRequiredConfirmationMessage("Policy Information Verified Against Certificate Issued By Vendor");
	    	policyData.setPremiumCertificate(collateralDocumentService.getUniquePolicyDoc(policyData.getProofOfCoverageData().getRid(), CtracAppConstants.PREMIUM_CERTIFICATE));
	    }
	  	logger.debug("prepareLPPolicyData::END");
		return policyData;
	}


	private void populateLPPolicyCollateralData(LPPolicyCollateralData lpPolicyCollateralData, Long collateralRid, boolean collateralMainDetailsViewData, boolean primaryLoanBorrowerViewData, boolean proofOfCoverageDetailsViewData, boolean requiredCoverageViewData, boolean providedCoverageViewData) {
		if(collateralRid != null && collateralMainDetailsViewData){
			 //Fetch the collateral main data
		    CollateralMainDetailsViewData collateralMainDetailsView = collateralMainDetailsRepository.findByCollateralRid(collateralRid);
		    CollateralMainDetailsViewDto collateralMainDetailsViewDtoMapData = ctracObjectMapper.map(collateralMainDetailsView, CollateralMainDetailsViewDto.class);
		    lpPolicyCollateralData.setCollateralMainDetailsViewDto(collateralMainDetailsViewDtoMapData);
		}

		if(collateralRid != null && primaryLoanBorrowerViewData){
			//Fetch the primary loan borrower data
		    PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto = viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(collateralRid);
		    Customer customer = customerRepository.findOne(primaryLoanBorrowerViewDto.getBorrowerRid());
			CustomerData borrowerData = ctracObjectMapper.map(customer, CustomerData.class);
			primaryLoanBorrowerViewDto.setBorrowerData(borrowerData);
			lpPolicyCollateralData.setPrimaryLoanBorrowerViewDto(primaryLoanBorrowerViewDto);
		}
		if(lpPolicyCollateralData.getProofOfCoverageData()!= null && proofOfCoverageDetailsViewData){
			//Fetch the proof of coverage data
		    ProofOfCoverageDetailsViewData collateralProofOfCoverageDetailsView = proofOfCoverageDetailsViewRepository.findByProofOfCoverageRid(lpPolicyCollateralData.getProofOfCoverageData().getRid());
		    ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto = ctracObjectMapper.map(collateralProofOfCoverageDetailsView, ProofOfCoverageDetailsViewDto.class);
		    lpPolicyCollateralData.setProofOfCoverageDetailsViewDto(proofOfCoverageDetailsViewDto);
		}
		if(lpPolicyCollateralData.getProofOfCoverageData()!= null && requiredCoverageViewData){
			 //Fetch the required coverage data
		    Long insurableAssetId = lpPolicyCollateralData.getProofOfCoverageData().getProvidedCoverageDTOs().get(0).getInsurableAssetDTO().getRid();
		    RequiredCoverageViewDto requiredCoverageViewDto=viewDataRetrievalService.getRequiredCoverageViewData(collateralRid, insurableAssetId);
		    lpPolicyCollateralData.setRequiredCoverageViewDto(requiredCoverageViewDto);
		}
		if(lpPolicyCollateralData.getProofOfCoverageData()!= null && providedCoverageViewData){
			 //Fetch the provided coverage data
		    ProvidedCoverageViewData collateralProveOfCoverageViewData=providedCoverageViewRepository.findByProofOfCoverageRidAndInsurableAssetRid(lpPolicyCollateralData.getProofOfCoverageData().getRid(), lpPolicyCollateralData.getProofOfCoverageData().getProvidedCoverageDTOs().get(0).getInsurableAssetDTO().getRid());
		    ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto=ctracObjectMapper.map(collateralProveOfCoverageViewData, ProvidedCoverageDetailsViewDto.class);
		    lpPolicyCollateralData.setProvidedCoverageDetailsViewDto(providedCoverageDetailsViewDto);
		}
	}


	private void getCLWNumber(VendorInvoiceData vendorInvoiceData, WorkItem workItem) {
		WorkItem parentItem = workItemAndRelationsService.getParentItemByChildAndRelation(workItem, TaskRelationType.REFUNDTOPOLICY);
	    if(parentItem != null){
	    	StateToBeAggregated state = (StateToBeAggregated)APPROVED_FOR_REFUND_REQUEST.getFloodRemapTaskState();
	   	    String branchCode = state.getKeyToAggregateBy(workItem).getKey();
	   	    List<AccountWireReference> accountWireReference = accountWireReferenceRepository.findByWorkItemAndAccountingSysRef(parentItem, branchCode);
	   	    String clwRefNumber = accountWireReference.get(0).getRequestNumber();
	   		vendorInvoiceData.setClwRefNumber(clwRefNumber);
	    }
	}

    @Override
	@Transactional(readOnly = false)
	public void processSaveVendorInvoiceVerification(VendorInvoiceData vendorInvoiceData) {
		logger.debug("processSaveVendorInvoiceVerification::BEGIN");
		vendorInvoiceData.getProofOfCoverageData().setPolicyStatus(PolicyStatus.INVOICED);
		insuranceMngtService.saveProofOfCoverage(vendorInvoiceData.getProofOfCoverageData());
		saveLenderPlaceData(vendorInvoiceData);
		logger.debug("processSaveVendorInvoiceVerification::END");
	}

	@Override
	@Transactional(readOnly = false)
	public void processSubmitVendorInvoiceVerification(final VendorInvoiceData vendorInvoiceData) {
		logger.debug("processSubmitVendorInvoiceVerification::BEGIN");
		ProofOfCoverageDTO proofOfCoverageData = vendorInvoiceData.getProofOfCoverageData();
		if(AWAITING_VENDOR_INVOICE.getName().equals(vendorInvoiceData.getCurrentWorkFlowStep())){
			proofOfCoverageData.setPolicyStatus(PolicyStatus.INVOICED);
		}
		insuranceMngtService.saveProofOfCoverage(proofOfCoverageData);
		WorkItem workItem = processLenderPlaceData(vendorInvoiceData);
		String pendingState = WorkflowStateDefinition.PENDING_VENDOR_PAYMENT_METHOD.getName();
		if(WorkflowStateDefinition.VENDOR_REFUND_METHOD.getName().equals(vendorInvoiceData.getCurrentWorkFlowStep())){
			pendingState  = WorkflowStateDefinition.PENDING_VENDOR_REFUND_METHOD.getName();
		}
		List<PerfectionTask> tasks  = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(workItem , pendingState, TaskStatus.TRANSIENT.name());
		if(tasks != null){
			for (final PerfectionTask perfectionTask : tasks) {
				final TMParams  params = new TMParams();
				params.setId_task(perfectionTask.getTmTaskId());
				params.setWorkflowStep(perfectionTask.getWorkflowStep());
				Map<StateParameterType, Object> worflowData = new HashMap<StateParameterType, Object>(){{
					put(StateParameterType.HELPER_DATA, vendorInvoiceData);
					put(StateParameterType.PERFECTION_TASK, perfectionTask);
					put(StateParameterType.TM_PARAMS,params);
				}};

				taskService.completeWorkFlowStepOperations(worflowData);
			}
		}
		logger.debug("processSubmitVendorInvoiceVerification::END");
	}

	@Override
	@Transactional(readOnly = false)
	public void saveVendorCertificate(LPPolicyCertificateData lpPolicyCertificateData) {
		logger.debug("saveVendorCertificate::BEGIN");
		ProofOfCoverageDTO proofOfCoverageData = lpPolicyCertificateData.getProofOfCoverageData();
		Long policyId = proofOfCoverageData.getRid();
    	List<MultipartFile> certificateFile = collateralDocumentService.fetchAttachedDocuments("Certificate_" + policyId);
    	if(!lpPolicyCertificateData.isCancellationWorkflow() && certificateFile != null && !certificateFile.isEmpty()){
    		List<CollateralDocument> collateralDocument = collateralDocumentRepository.findByProofOfCoverageRidAndDocIdentifier(policyId,  CtracAppConstants.PREMIUM_CERTIFICATE);
        	try{
    		if(!PDFChecker.isPDF(certificateFile.get(0))){
    			throw new CTracApplicationException("E0317", CtracErrorSeverity.APPLICATION);
    		}
        	}catch(IOException io){
        	    logger.error(io.getMessage(), io);
        		throw new CTracApplicationException("E0318", CtracErrorSeverity.APPLICATION);
        	}
    		collateralDocumentService.updateCollateralDocument(certificateFile.get(0), ((collateralDocument != null && collateralDocument.size()>0) ? collateralDocument.get(0): null),CtracAppConstants.PREMIUM_CERTIFICATE, null, lpPolicyCertificateData.getPrimaryCollateral().getRid(), policyId);
        }
    	PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(lpPolicyCertificateData.getTmParams().getId_task());
    	WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);
    	if(workItem instanceof LenderPlaceItem){
    		LenderPlaceItem lpWorkItem = (LenderPlaceItem)workItem;
    		if(lpPolicyCertificateData.isCancellationWorkflow()){
    			lpWorkItem.setCancelCertificateVerified("Y");
    		}else{
    			lpWorkItem.setPremiumCertificateVerified("Y");
    		}
    		workItemRepository.save(lpWorkItem);
    	}
    	processLenderPlaceData(lpPolicyCertificateData);
		logger.debug("saveVendorCertificate::END");
	}

	@Override
	public LPPremiumPaidData prepareLpPremiumPaidEmailData(TMParams tmParams) {
		logger.debug("prepareLpPremiumPaidEmailData::BEGIN");
		LPPremiumPaidData lpPremiumPaidData = prepareLenderPlaceData(tmParams, LPPremiumPaidData.class);
		logger.debug("prepareLpPremiumPaidEmailData::END");
		return lpPremiumPaidData;
	}

	@Override
	@Transactional(readOnly = false)
	public void processLpPremiumPaidLOBEmail() {
		// get all perfection tasks which has workflow_step as "Pending_Send_LOB_Email_LP_Premium_Paid"
		List<PerfectionTask> perfectionTasks = perfectionTaskRepository.findByWorkflowStepAndTaskStatus(LOB_EMAIL_LP_PREMUIM_PAID.getName(), TaskStatus.TRANSIENT.name());

		// if any record found, get the email template
		if (perfectionTasks.size() > 0) {

			EmailTemplate emailTemplate = emailTemplateRepository.findByEmailTemplateId(EMAIL_TEMPLATE_LP_PREMIUM_PAID);

			if(emailTemplate == null){
				logger.error("No email template found for LP Premium paid ,Email Template Id." + EMAIL_TEMPLATE_LP_PREMIUM_PAID);
				throw new CTracApplicationException("E0191", CtracErrorSeverity.APPLICATION);
			}

			/*
			 For each perfection task we need to find the collateral ID and for each collateral
			 we need to check the LP Policies
			 If Insurance Agency for the LP Policy is Althans
			 then we will fetch the template for althans
			 Otherwise we will fetch template for Assurant
			 */

			for (PerfectionTask perfectionTask: perfectionTasks) {
				List<CollateralWorkItem> collateralWorkItems = collateralWorkItemRepository.findByWorkItem(perfectionTask.getWorkItem());

				if (collateralWorkItems.size() < 1) {
					logger.error("No Collateral WorkItem Found for the WorkFlow RID: " + perfectionTask.getWorkItem().getRid());
					throw new CTracApplicationException("E0191", CtracErrorSeverity.APPLICATION);
				}

				Collateral collateral = collateralWorkItems.get(0).getCollateral();
				Long collateralID = collateral.getRid();
				TaskRelationType parentToChildRelation = TaskRelationType.PROPERTYTOPOLICY;
				List<WorkItemRelation> workItemRelations = workItemRelationRepository.findByParentWorkItemAndRelationType(perfectionTask.getWorkItem(), parentToChildRelation.name());
				String toAddress = floodEmailService.getMarketEmailToAddress(collateral);
                //market email may not be needed for CTL-no special handling
				if(toAddress != null) {
					// Step 1: Prepare Template with Data
					FloodRemapLPPremiumPaidEmailData lPPremiumPaidEmailData = new FloodRemapLPPremiumPaidEmailData();
					lPPremiumPaidEmailData.setEmailTo(toAddress);
					EmailAttributeHolder emailAttributeHolder = popupateEmailData(collateralID, lPPremiumPaidEmailData, emailTemplate, workItemRelations);
					emailAttributeHolder.getCollateralRids().add(collateralID);
					// Step 2: Send EMail
					sendLPPremiumPaidEmail(lPPremiumPaidEmailData, emailAttributeHolder);
				}
				// Step 3:
				//   Parent: WorkflowState: LOB_Email_LP_Premium_Paid   Status: Transient or Dormant	Next WF State: Complete, Status: Closed (???) - Perfection: PROPERTY
				//   Children: WorkflowState:  Pending_Send_LOB_Email_LP_Premium_Paid  Next Workflow State: Complete_LP_Policy_Review  PERFECTION: POLICY

				// Parent
				processItem(perfectionTask);

				// Children
				for (WorkItemRelation relation : workItemRelations) {
					List<PerfectionTask> perfectionTasksList = perfectionTaskRepository.findByWorkItemAndTaskStatus(relation.getChildWorkItem(),TaskStatus.TRANSIENT.name());
					for (PerfectionTask childPerfectionTask: perfectionTasksList) {
						//check for pending send premium paid then create the item
						if(childPerfectionTask.getWorkflowStep().equalsIgnoreCase(PENDING_SEND_LOB_EMAIL_LP_PREMUIM_PAID.getName()))
						{
							processItem(childPerfectionTask);
						}
					}
				}

				// Do we need to setup TM for children helper??? - see processItem
			}
		}

		logger.debug("processLpPremiumPaidLOBEmail::END");
	}

    private void processItem(PerfectionTask perfectionTask) {
        CtracBaseHelperData ctracBaseHelperData = new CtracBaseHelperData();
		ctracBaseHelperData.setWorkflowTransitionProcess(ProcessType.MANUAL_PROCESS.getName());
		ctracBaseHelperData.setTmParams(null);
		Map<StateParameterType, Object> inputParameterMap = new HashMap<>();
		inputParameterMap.put(StateParameterType.HELPER_DATA, ctracBaseHelperData);
		inputParameterMap.put(StateParameterType.TM_PARAMS, null);
		inputParameterMap.put(StateParameterType.PERFECTION_TASK, perfectionTask);
		inputParameterMap.put(StateParameterType.WORK_ITEM, perfectionTask.getWorkItem());
        taskService.completeWorkFlowStepOperations(inputParameterMap);
    }

	private EmailAttributeHolder popupateEmailData(Long collateralID, FloodRemapLPPremiumPaidEmailData lPPremiumPaidEmailData, EmailTemplate emailTemplate, List<WorkItemRelation> workItemRelations) {


		EmailDataDto emailDataDto = new EmailDataDto();

		PrimaryLoanBorrowerViewDto collateralLoanBorrowerViewDto = viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(collateralID);

		emailDataDto.setBorrowerName(collateralLoanBorrowerViewDto.getBorrowerName());

		CollateralMainDetailsViewDto collateralMainDetailsViewDto = viewDataRetrievalService.getCollateralMainDetails(collateralID);

		emailDataDto.setPropertyAddress(collateralMainDetailsViewDto.getCollateralAddress() + ", " + collateralMainDetailsViewDto.getCollateralCity() + ", "
				+ collateralMainDetailsViewDto.getCollateralState() + " " + collateralMainDetailsViewDto.getCollateralZipCode());

		// Arun TODO: Do we need TaskUUID and Remap Type

		if (collateralLoanBorrowerViewDto.getLoanNumber() != null) {
			emailDataDto.setLoanNumber(collateralLoanBorrowerViewDto.getLoanNumber());
		} else {
			emailDataDto.setLoanNumber(" ");
		}

		emailDataDto.setTaskUniqueID(collateralID.toString());


		List<LPPremiumPolicyData> lpPremiumPolicyDataList = new ArrayList<>();

		/*
		  Creating a list of premium amount provided by Bank
		 */
		List<LPPremiumPolicyData> bankPreiumAmountList = new ArrayList<>();

		for (WorkItemRelation relation : workItemRelations) {
			WorkItem workItem = CtracBaseEntity.deproxy(relation.getChildWorkItem(), WorkItem.class);
			ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto = viewDataRetrievalService.getLPProofOfCoverageDetails(workItem.getRid());
			ProofOfCoverageDetailsViewData proofOfCoverageDetailsViewData = proofOfCoverageDetailsViewRepository.findByProofOfCoverageRid(providedCoverageDetailsViewDto.getProofOfCoverageRid());
			InsurableAssetType insurableAssetType = InsurableAssetType.findByName(providedCoverageDetailsViewDto.getAssetType());
			Long insurableAssetRid = providedCoverageDetailsViewDto.getInsurableAssetRid();
			RequiredCoverageViewData requiredCoverageViewData = requiredCoverageViewRepository.findByCollateralRidAndInsurableAssetRidAndStatus(collateralID, insurableAssetRid, VerificationStatus.VERIFIED.getName());

			LPPremiumPolicyData lpPremiumPolicyData = new LPPremiumPolicyData();
			lpPremiumPolicyData.setBuildingName(providedCoverageDetailsViewDto.getBuildingName());
			lpPremiumPolicyData.setPropertyType(requiredCoverageViewData.getPropertyType());

			if(proofOfCoverageDetailsViewData.getInsuranceAgency().equals("Althans")){
				lpPremiumPolicyData.setCoverageType(proofOfCoverageDetailsViewData.getCoverageTypeDescription());
			}else{
				lpPremiumPolicyData.setCoverageType(providedCoverageDetailsViewDto.getCoverageTypeDisplay());
			}

			LenderPlaceItem lenderPlaceItem = CtracBaseEntity.deproxy(relation.getChildWorkItem(), LenderPlaceItem.class);
			lpPremiumPolicyData.setPremiumAmount(lenderPlaceItem.getPremiumAmount().toString());

			if(proofOfCoverageDetailsViewData.getInvoicePaymentAccount() != null) {
				lpPremiumPolicyData.setPaymentMethod(proofOfCoverageDetailsViewData.getInvoicePaymentMethodDescription() + ": " + proofOfCoverageDetailsViewData.getInvoicePaymentAccount())  ;
			} else {
				lpPremiumPolicyData.setPaymentMethod(proofOfCoverageDetailsViewData.getInvoicePaymentMethodDescription());
			}
			lpPremiumPolicyData.setAssetType(insurableAssetType != null ? insurableAssetType.getDisplayName() : StringUtils.EMPTY);
			lpPremiumPolicyData.setPolicyType(proofOfCoverageDetailsViewData.getPolicyTypeDescription());
			lpPremiumPolicyDataList.add(lpPremiumPolicyData);

			if(lenderPlaceItem.getBankPremiumAmount()!=null && !lenderPlaceItem.getBankPremiumAmount().equals(BigDecimal.ZERO) ){
				lpPremiumPolicyData = new LPPremiumPolicyData();
				lpPremiumPolicyData.setBuildingName(providedCoverageDetailsViewDto.getBuildingName());
				lpPremiumPolicyData.setPropertyType(requiredCoverageViewData.getPropertyType());
				lpPremiumPolicyData.setCoverageType(proofOfCoverageDetailsViewData.getCoverageTypeDescription());
				lpPremiumPolicyData.setPremiumAmount(lenderPlaceItem.getBankPremiumAmount().toString());
				if(proofOfCoverageDetailsViewData.getInvoicePaymentAccount() != null)
					{lpPremiumPolicyData.setPaymentMethod(proofOfCoverageDetailsViewData.getInvoicePaymentMethodDescription() + ": " + proofOfCoverageDetailsViewData.getInvoicePaymentAccount())  ;}
				else
					{lpPremiumPolicyData.setPaymentMethod(proofOfCoverageDetailsViewData.getInvoicePaymentMethodDescription());}
				lpPremiumPolicyData.setAssetType(insurableAssetType != null ? insurableAssetType.getDisplayName() : StringUtils.EMPTY);
				lpPremiumPolicyData.setPolicyType(proofOfCoverageDetailsViewData.getPolicyTypeDescription());
				bankPreiumAmountList.add(lpPremiumPolicyData);
			}

		}

		lPPremiumPaidEmailData.setLpPremiumPolicyDataList(lpPremiumPolicyDataList);

		emailDataDto.setLpPremiumPolicyList(lPPremiumPaidEmailData.getLpPremiumPolicyDataList());

		/*
		  adding the bank portion
		 */
		if(bankPreiumAmountList!=null && !bankPreiumAmountList.isEmpty()){
			emailDataDto.setBankPreiumAmountList(bankPreiumAmountList);
			emailDataDto.setHasBankPortion(true);
		}

		EmailAttributeHolder emailAttributeHolder = CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);

		lPPremiumPaidEmailData.setEmailTemplateName(emailTemplate.getEmailTemplateName());
		lPPremiumPaidEmailData.setEmailTemplateRid(emailTemplate.getRid());
		lPPremiumPaidEmailData.setEmailSubject(emailAttributeHolder.getSubject());
		lPPremiumPaidEmailData.setEmailStaticText(emailAttributeHolder.getEmailTemplate().getEmailStaticText().trim());
		lPPremiumPaidEmailData.setEmailType(CtracAppConstants.EMAIL_TYPE_PREMIUM_PAID_EMAIL);

		emailAttributeHolder.getCollateralRids().add(collateralID);

		return emailAttributeHolder;

	}

	protected void sendLPPremiumPaidEmail(FloodRemapSendEmailData emailPageData, EmailAttributeHolder emailAttributeHolder){
		if (emailPageData.getEmailTo() == null || emailPageData.getEmailTo().isEmpty()) {
			throw new CTracApplicationException("E0114", CtracErrorSeverity.APPLICATION);
		}

		populateEmailAttributeHolder(emailPageData, emailAttributeHolder, CtracErrorSeverity.APPLICATION);
		floodEmailService.sendInternalEmailThroughEWS(emailAttributeHolder);
		logger.debug("sendLOBEmail :: end");
	}

	@Override
	public PolicyReviewData prepareCompleteLPPolicyReviewData(TMParams tmParams) {
		logger.debug("prepareCompleteLPPolicyReviewData::BEGIN");
		PolicyReviewData policyReviewData = prepareLenderPlaceData(tmParams, PolicyReviewData.class);

		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmParams.getId_task());
	    WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);

	    Long collateralRid = workItem.getCollateralWorkItems().get(0).getCollateral().getRid();
	    PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto = viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(collateralRid);
	    Customer customer = customerRepository.findOne(primaryLoanBorrowerViewDto.getBorrowerRid());
		CustomerData borrowerData = ctracObjectMapper.map(customer, CustomerData.class);
		//LCP-3341 :The borrower name is missing from the Complete LP Policy Review screen
		borrowerData.setBorrowerName(primaryLoanBorrowerViewDto.getBorrowerName());
		primaryLoanBorrowerViewDto.setBorrowerData(borrowerData);
		policyReviewData.setPrimaryLoanBorrowerViewDto(primaryLoanBorrowerViewDto);

		Long proofOfCoverageId=policyReviewData.getProofOfCoverageData().getRid();
	    ProofOfCoverageDetailsViewData collateralProofOfCoverageDetailsView=proofOfCoverageDetailsViewRepository.findByProofOfCoverageRid(proofOfCoverageId);
	    ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto=ctracObjectMapper.map(collateralProofOfCoverageDetailsView, ProofOfCoverageDetailsViewDto.class);
	    policyReviewData.setProofOfCoverageDetailsViewDto(proofOfCoverageDetailsViewDto);

	    Long insurableAssetId=policyReviewData.getProofOfCoverageData().getProvidedCoverageDTOs().get(0).getInsurableAssetDTO().getRid();
	    ProvidedCoverageViewData collateralProveOfCoverageViewData=providedCoverageViewRepository.findByProofOfCoverageRidAndInsurableAssetRid(proofOfCoverageId, insurableAssetId);
	    ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto=ctracObjectMapper.map(collateralProveOfCoverageViewData, ProvidedCoverageDetailsViewDto.class);
	    policyReviewData.setProvidedCoverageDetailsViewDto(providedCoverageDetailsViewDto);

	    String lpCoverageType = ProvidedCoverageUtil.getFloodLPCoverageType(providedCoverageDetailsViewDto.getAssetType());
	    policyReviewData.setLpCoverageType(lpCoverageType);

	    List<DeterminationDetailsViewData> determinationDetailsViewData=viewDataRetrievalService.findDeterminationsByCollateralRidAndStatus(collateralRid, VerificationStatus.VERIFIED.getName());
	    DeterminationDetailsViewDto determinationDetailsViewDto=ctracObjectMapper.map(determinationDetailsViewData.get(0),DeterminationDetailsViewDto.class);
	    policyReviewData.setDeterminationDetailsViewDto(determinationDetailsViewDto);

	    Date currentRefDate=calendarDayUtil.getCurrentReferenceDate();
	    policyReviewData.setCurrentDate(DateConverter.convert(currentRefDate));
		logger.debug("prepareCompleteLPPolicyReviewData::END");
		return policyReviewData;
	}

	@Override
	@Transactional(readOnly = false)
	public void processCompleteLPPolicyReview(PolicyReviewData completeLPPolicyReviewData) {
		logger.debug("processCompleteLPPolicyReview::BEGIN");
		//change the staus only when it is active

		if(!completeLPPolicyReviewData.getProofOfCoverageData().getPolicyStatus().isCancelled())
		{
			completeLPPolicyReviewData.getProofOfCoverageData().setPolicyStatus(PolicyStatus.PAID);
		}
		insuranceMngtService.saveProofOfCoverage(completeLPPolicyReviewData.getProofOfCoverageData());
		processLenderPlaceData(completeLPPolicyReviewData);
		logger.debug("processCompleteLPPolicyReview::END");
	}

	@Deprecated
	@Override
	public GenericEmailData prepareSendMarketRefundEmail(TMParams tmParams) {
		logger.debug("prepareSendMarketRefundEmail::BEGIN");
		logger.debug("prepareSendMarketRefundEmail::END");
		return null;
	}

	@Deprecated
	@Override
	@Transactional(readOnly = false)
	public void processSendMarketRefundEmail(final GenericEmailData emailData) {
		logger.debug("processSendMarketRefundEmail::BEGIN");
		logger.debug("processSendMarketRefundEmail::END");
	}

	@Override
    public boolean isPolicyInInsuranceReview(String tmTaskId) {
        PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmTaskId);
        return "Y".equalsIgnoreCase(perfectionTask.getInInsuranceReview());
    }

	/**
	 * Finds the PerfectionTask and maps the workflow attributes into a subclass of LenderPlaceData
	 * (which is abstract). It then adds the common data needed by all workflow steps, including
	 * collateral and policy information.
	 * @param tmParams
	 * @param lpClass
	 * @return a DTO of type "lpClass" populated with all data necessary for the given task
	 */
	private <T extends LenderPlaceData> T prepareLenderPlaceData(TMParams tmParams, Class<T> lpClass) {
        // 1. Validate tmParams
        taskService.validateTMParams(tmParams);

        // 2. Retrieve perfectionTask and workItem
        PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmParams.getId_task());
        WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);

        // 3. Populate lenderPlaceData for this specific class using ctracObjectMapper
        T lenderPlaceData = ctracObjectMapper.map(workItem, lpClass);

        // 4. Add the common data not specific to a given workflow step
        addCommonLenderPlaceAttributes(lenderPlaceData, perfectionTask, workItem, tmParams);
        return lenderPlaceData;
    }

	private void addCommonLenderPlaceAttributes(LenderPlaceData lenderPlaceData, PerfectionTask perfectionTask, WorkItem workItem, TMParams tmParams) {
	    collateralHelperService.populateCollateralInformation(tmParams.getId_task(), lenderPlaceData);
	    lenderPlaceData.setProofOfCoverageData(getProofOfCoverageInformation(workItem));
        lenderPlaceData.setCurrentWorkflowStep(perfectionTask.getWorkflowStep());
        lenderPlaceData.setWorkflowTransitionProcess(ProcessType.MANUAL_PROCESS.getName());
        lenderPlaceData.setTmParams(tmParams);
        lenderPlaceData.setTmTaskType(perfectionTask.getTmTaskType());
        lenderPlaceData.setCurrentReferenceDate(
                DateFormatter.toJavaScriptDate(dateCalculator.getCurrentReferenceDate()));
    }

	private ProofOfCoverageDTO getProofOfCoverageInformation(WorkItem workItem) {

		/*TODO FIXME use insurance mngt ervice to retrieve or expose this as method of insuranceMngtService*/

		ProofOfCoverage proofOfCoverage = workItem.getProofOfCovWorkItems().get(0).getProofOfCoverage();
		proofOfCoverage = CtracBaseEntity.deproxy(proofOfCoverage, ProofOfCoverage.class);
		ProofOfCoverageDTO proofOfCoverageData = ctracObjectMapper.map(proofOfCoverage, ProofOfCoverageDTO.class);
		List<ProvidedCoverage> providedCoverages = providedCoverageRepository.findByProofOfCoverage(proofOfCoverage);
		List<ProvidedCoverageDTO> providedCoverageDTOs = new ArrayList<>();
		for (ProvidedCoverage providedCoverage : providedCoverages) {
		    providedCoverage = CtracBaseEntity.deproxy(providedCoverage, ProvidedCoverage.class);
		    ProvidedCoverageDTO providedCoverageDTO =
		            ctracObjectMapper.map(providedCoverage, ProvidedCoverageDTO.class);
			providedCoverageDTO.setInsurableAssetDTO(
					ctracObjectMapper.map(providedCoverage.getInsurableAsset(), InsurableAssetDTO.class));
		    providedCoverageDTOs.add(providedCoverageDTO);
		}
		proofOfCoverageData.setProvidedCoverageDTOs(providedCoverageDTOs);
		return proofOfCoverageData;
	}

	private String getDatePlusOne(String firstLetterDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(DateConverter.convert(firstLetterDate));
        cal.add(Calendar.DATE, 1);
        return DateFormatter.toJavaScriptDate(cal.getTime());
    }

	/**
	 * Finds the PerfectionTask and maps the workflow attributes into the appropriate WorkItem from
	 * a subclass of LenderPlaceData (which is abstract). It then moves the task to the next
	 * workflow step.
	 * @param verifyLetterData
	 * @return
	 */
	private WorkItem processLenderPlaceData(final LenderPlaceData verifyLetterData) {
	    // 1. Validate tmParams
        final TMParams tmParams = validateLenderPlaceData(verifyLetterData);

        // 2. Retrieve perfectionTask and workItem
        String tmTaskId = tmParams.getId_task();
        final PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmTaskId);
        final WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);

        // 3. Populate workItem (LenderPlaceItem or LenderPlaceCancellationItem) using ctracObjectMapper
        ctracObjectMapper.map(verifyLetterData, workItem);

        // 4. completeWorkflowStepOperations
        completeWorkflowStepOperations(verifyLetterData, perfectionTask, tmParams);

        // 5. Save workItem
        workItemRepository.save(workItem);
        return workItem;
    }




	private void saveLenderPlaceData(final LenderPlaceData verifyLetterData) {
	    // 1. Validate tmParams
        final TMParams tmParams = validateLenderPlaceData(verifyLetterData);

        // 2. Retrieve perfectionTask and workItem
        String tmTaskId = tmParams.getId_task();
        final PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(tmTaskId);
        final WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);

        // 3. Populate workItem (LenderPlaceItem or LenderPlaceCancellationItem) using ctracObjectMapper
        ctracObjectMapper.map(verifyLetterData, workItem);

        // 4. Save workItem
        workItemRepository.save(workItem);
	}

	private TMParams validateLenderPlaceData(final LenderPlaceData lenderPlaceData) {
        if (lenderPlaceData == null ) {
            logger.error("NULL DTO object lenderPlaceData received");
            throw new CTracApplicationException("E0149", CtracErrorSeverity.APPLICATION);
        }
        final TMParams tmParams = lenderPlaceData.getTmParams();
        taskService.validateTMParams(tmParams);
        return tmParams;
    }

	private void completeWorkflowStepOperations(final LenderPlaceData verifyLetterData,
            final PerfectionTask perfectionTask, final TMParams tmParams) {
        Map<StateParameterType, Object> workflowData = new HashMap<StateParameterType, Object>() {
            private static final long serialVersionUID = 3730853052500920723L; {
                put(StateParameterType.HELPER_DATA, verifyLetterData);
                put(StateParameterType.PERFECTION_TASK, perfectionTask);
                put(StateParameterType.TM_PARAMS, tmParams);
            }
        };
        taskService.completeWorkFlowStepOperations(workflowData);
    }

	private List<LookUpCode> getVendorPaymentMethodList(boolean isCancellation) {
		List<LookUpCode> vendorPaymentMethodList=lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(CtracAppConstants.FLOOD_REMAP_ASSURANT_PAYMENT_LIST);
		if(!isCancellation){
			Iterator<LookUpCode> vendorPaymentItr=vendorPaymentMethodList.iterator();
			while(vendorPaymentItr.hasNext()){
				LookUpCode vendorPaymentMethod=vendorPaymentItr.next();
				if(vendorPaymentMethod.getDescription().equals(PaymentType.CASHIERS_CHECK.getName())){
					vendorPaymentItr.remove();
				}
			}
		}
		return vendorPaymentMethodList;
    }

	private List<LookUpCode> getStateCodes() {
	    return lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(CtracAppConstants.STATES_CODES);
    }

	private void addCommonLenderPlaceAttributes(VerifyLetterData verifyLetterData,PerfectionTask perfectionTask, TMParams tmParams) {
	     verifyLetterData.setCurrentWorkflowStep(perfectionTask.getWorkflowStep());
	     verifyLetterData.setWorkflowTransitionProcess(ProcessType.MANUAL_PROCESS.getName());
	     verifyLetterData.setTmParams(tmParams);
	     verifyLetterData.setTmTaskType(perfectionTask.getTmTaskType());
	     verifyLetterData.setCurrentReferenceDate(
	        DateFormatter.toJavaScriptDate(dateCalculator.getCurrentReferenceDate()));
	}

	private GenericEmailData populateMarketRefundEmailData(VendorInvoiceData vendorInvoiceData){
		GenericEmailData marketRefundEmailData=new GenericEmailData();
		marketRefundEmailData.setTmTaskType(vendorInvoiceData.getTmTaskType());
		marketRefundEmailData.setThirtyDayRegulatoryDate(vendorInvoiceData.getProofOfCoverageDetailsViewDto().getCancellationEffectiveDate());

		EmailTemplateRulerequest ruleRequest=new EmailTemplateRulerequest();
		ruleRequest.setWorflowStepId(SEND_MARKET_REFUND_EMAIL.getName());
		EmailTemplate emailTemplate = emailTemplateRetrievalService.findEmailTemplate(ruleRequest);
		EmailDataDto emailDataDto = new EmailDataDto();
		if(vendorInvoiceData.getPrimaryLoanBorrowerViewDto().getLoanNumber()!=null){
			emailDataDto.setLoanNumber(vendorInvoiceData.getPrimaryLoanBorrowerViewDto().getLoanNumber());
		}else{
			emailDataDto.setLoanNumber(" ");
		}

		emailDataDto.setTaskUUId(vendorInvoiceData.getTmParams().getId_task());
		emailDataDto.setTaskUniqueID(vendorInvoiceData.getCollateralMainDetailsViewDto().getCollateralRid().toString());
		emailDataDto.setBorrowerName(vendorInvoiceData.getPrimaryLoanBorrowerViewDto().getBorrowerName());
		emailDataDto.setPropertyAddress(vendorInvoiceData.getCollateralMainDetailsViewDto().getPropertyAddressUnitBuilding());
		emailDataDto.setCityStateZip(vendorInvoiceData.getCollateralMainDetailsViewDto().getCityStateZipCode());
		emailDataDto.setLenderPlacedAmt(vendorInvoiceData.getProvidedCoverageDetailsViewDto().getBuildingName()
				+":"+vendorInvoiceData.getProvidedCoverageDetailsViewDto().getCoverageAmount());
		emailDataDto.setLenderPlacedRefundAmt(vendorInvoiceData.getRefundAmount());
		emailDataDto.setCancelDate(marketRefundEmailData.getCancelledDate());
		emailDataDto.setVendorPaymentMethod(vendorInvoiceData.getProofOfCoverageDetailsViewDto().getRefundPaymentMethodDescription());
		emailDataDto.setThirtyDayRegulatoryDate(vendorInvoiceData.getProofOfCoverageData().getThirtyDayRegulatoryPeriod());

		if(vendorInvoiceData.getProofOfCoverageDetailsViewDto().getRefundPaymentMethodCode().equals(PaymentType.CASHIERS_CHECK.getCode())){
			emailDataDto.setVendorPaymentValue(vendorInvoiceData.getProofOfCoverageDetailsViewDto().getRefundPaymentAddress()
					+","+vendorInvoiceData.getProofOfCoverageDetailsViewDto().getRefundPaymentCity()
					+","+vendorInvoiceData.getProofOfCoverageDetailsViewDto().getRefundPaymentState()
					+","+vendorInvoiceData.getProofOfCoverageDetailsViewDto().getRefundPaymentZipCode());
		}else{
			if(vendorInvoiceData.getProofOfCoverageDetailsViewDto().getRefundPaymentMethodCode().equals(PaymentType.APPLY_TO_LOAN.getCode())){
				emailDataDto.setVendorPaymentValue(" ");
			}else{
				emailDataDto.setVendorPaymentValue(vendorInvoiceData.getProofOfCoverageDetailsViewDto().getRefundPaymentAccount());
			}
		}

		emailDataDto.setCancelDate(vendorInvoiceData.getProofOfCoverageDetailsViewDto().getCancellationEffectiveDate());
		CancellationReason cancellationReason = vendorInvoiceData.getProofOfCoverageData().getCancellationReason();
		emailDataDto.setApplicableReason(cancellationReason != null ? cancellationReason.getText() : "");

		EmailAttributeHolder emailAttributeHolder = CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);
		marketRefundEmailData.setEmailAttributeHolder(emailAttributeHolder);
		marketRefundEmailData.setEmailStaticContent(emailAttributeHolder.getEmailTemplate().getEmailStaticText());
		logger.debug("prepareSendMarketRefundEmail::END");
		return marketRefundEmailData;
	}
	@Override
	public void triggerMarketRefundEmail(VendorInvoiceData vendorInvoiceData) {
		final GenericEmailData emailData=populateMarketRefundEmailData(vendorInvoiceData);
		boolean isAlthansPolicyAndBankShareZero = false;

		Long collateralRid = vendorInvoiceData.getPrimaryCollateral().getRid();
		Collateral collateral = collateralRepository.getOne(collateralRid);
		String toAddress = floodEmailService.getMarketEmailToAddress(collateral);
        //market email may not be needed for CTL-no special handling
		if(toAddress != null) {
			//fixing the null pointer on lender place item
			if (vendorInvoiceData.getProofOfCoverageData().getLenderPlaceItemData() != null && vendorInvoiceData.getProofOfCoverageData().getInsuranceAgency() != null
                    && vendorInvoiceData.getProofOfCoverageData().getLenderPlaceItemData().getBankRefundAmount() != null) {
                isAlthansPolicyAndBankShareZero = isAlthansPolicyAndBankShareZero(vendorInvoiceData.getProofOfCoverageData().getInsuranceAgency(), vendorInvoiceData.getProofOfCoverageData().getLenderPlaceItemData().getBankRefundAmount());
                emailData.setAlthansPolicyAndBankShareZero(isAlthansPolicyAndBankShareZero);
			}
			emailData.setEmailTo(toAddress);
			emailData.setInsuranceAgency(vendorInvoiceData.getProofOfCoverageData().getInsuranceAgency());
			emailData.setAlthansPolicyAndBankShareZero(isAlthansPolicyAndBankShareZero);
			List<CollateralDto> collateralDtoList = vendorInvoiceData.getCollaterals();
			EmailAttributeHolder emailAttributeHolder = emailData.getEmailAttributeHolder();
			populateEmailAttributeHolder(emailData, emailAttributeHolder, CtracErrorSeverity.APPLICATION);
			for (CollateralDto collateralDto : collateralDtoList) {
				emailAttributeHolder.getCollateralRids().add(collateralDto.getRid());
			}

			floodEmailService.sendInternalEmailThroughEWS(emailAttributeHolder);
		}
	}

	protected void populateEmailAttributeHolder(final FloodRemapSendEmailData emailData, EmailAttributeHolder emailAttributeHolder, CtracErrorSeverity ctracErrorSeverity) {
		emailAttributeHolder.setFiles(emailData.getFiles());
		emailAttributeHolder.addToAddress(emailData.getEmailTo());
		emailAttributeHolder.addCcAddress(emailData.getEmailCC());
		emailAttributeHolder.addBccAddress(emailData.getEmailBCC());
		emailAttributeHolder.setCtracErrorSeverity(ctracErrorSeverity);
	}

	private boolean isAlthansPolicyAndBankShareZero(String insuranceAgency, String bankPremiumAmout) {
		logger.debug(" insuranceAgency "+insuranceAgency+ "Refund Amout "+bankPremiumAmout);
		boolean amoutGreaterThanZero = isValueGreaterThanZero(bankPremiumAmout);
		return "Althans".equalsIgnoreCase(insuranceAgency) && amoutGreaterThanZero;
	}

	private boolean isValueGreaterThanZero(String value){
		double amount =0.0;
		if(StringUtils.isEmpty(value)){
			return false;
		}
		try {
			amount = Double.parseDouble(value.replace(",", ""));
		} catch (NumberFormatException e) {
			return false;
		}
		return (amount > 0);
	}

}
