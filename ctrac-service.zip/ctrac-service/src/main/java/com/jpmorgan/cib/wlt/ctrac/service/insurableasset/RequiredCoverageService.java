package com.jpmorgan.cib.wlt.ctrac.service.insurableasset;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.RequiredCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredCoverageViewData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageSourceDto;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collection;
import java.util.List;
import java.util.Set;


public interface RequiredCoverageService {
	
    /**
     * @param insurableAssetRid
     * @param coverageType
     * @return
     */
    Collection<RequiredCoverageDTO> findRequiredCoveragesByInsurableAsset (Long insurableAssetRid, InsuranceType coverageType);


    /**
     * @param collateralRid
     * @param insuranceType
     * @return
     */
    Collection<RequiredCoverageDTO> findRequiredCoverageByCollateral(Long collateralRid,  InsuranceType insuranceType);

    Set<RequiredCoverageViewData> getLatestInactiveRequiredCoverages(Long collateralRid);

    /**
     * @param requiredCoverageDTO
     */
    void saveRequiredCoverage(RequiredCoverageDTO requiredCoverageDTO);
    
    
    /**
     * @param requiredCoverageDTOList
     */
    void saveRequiredCoverage(Collection<RequiredCoverageDTO> requiredCoverageDTOList);


    void deleteRequiredCoverages(Collection<Long> coverageIds);


    void saveRequiredCoverageSource(RequiredCoverageSourceDto requiredCoverageSourceDto, List<MultipartFile> sourceDocu);


    
    	
}
