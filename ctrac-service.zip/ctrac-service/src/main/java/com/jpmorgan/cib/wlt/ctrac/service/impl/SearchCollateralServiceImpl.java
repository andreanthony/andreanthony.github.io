package com.jpmorgan.cib.wlt.ctrac.service.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralSearchViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralSearchViewDataRepository;
import com.jpmorgan.cib.wlt.ctrac.service.SearchCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralSearchResultData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralSearchResultDataTablesRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.SearchCollateralData;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.specifications.CollateralSearchViewDataSpecs;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.CODE_SET_COLLATERAL_STATUSES;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.CODE_SET_COLLATERAL_TYPES;


@Service(value = "searchCollateralService")
public class SearchCollateralServiceImpl extends AbstractSearchCollateralServiceImpl implements SearchCollateralService {

	private static final Logger logger = Logger.getLogger(SearchCollateralServiceImpl.class);
	
	@Autowired
	private CollateralSearchViewDataRepository collateralSearchRepository;
	
	@Autowired 
	private CtracObjectMapper ctracObjectMapper;

	@Autowired
	private LineOfBusinessService lobService;

	@Override
	public SearchCollateralData prepareSearchCollateralRecord() {
		logger.info("Inside prepareSearchCollateralRecord() method");
		SearchCollateralData searchCollateralData = new SearchCollateralData();
		searchCollateralData.setLinesOfBusiness(lobService.retrieveLinesOfBusiness());
		searchCollateralData.setStateCodes(getStateCodes());
		searchCollateralData.setCollateralTypes(lookUpCodeService.findByCodeSetInSortOrder(CODE_SET_COLLATERAL_TYPES));
		searchCollateralData.setCollateralStatuses(lookUpCodeService.findByCodeSetInSortOrder(CODE_SET_COLLATERAL_STATUSES));
		logger.info("Exit prepareSearchCollateralRecord() method");
		return searchCollateralData;
	}

	@Override
	@Transactional(readOnly = true)    
	public List<CollateralSearchResultData> getCollateralSearchResult(CollateralSearchResultDataTablesRequest collateralSearchResultDataTablesRequest) {
		logger.debug("getCollateralSearchResult::  Searching with with search term: " + collateralSearchResultDataTablesRequest.toString());
		List<CollateralSearchResultData> result = new ArrayList<>();
        // if user is not tied to any LOB then no records should be shown on the results
        List<LineOfBusinessDTO> linesOfBusiness = lobService.retrieveLinesOfBusiness();
        if (linesOfBusiness!= null && !linesOfBusiness.isEmpty()) {
	        Specification<CollateralSearchViewData> allSearchCriteria =
                    CollateralSearchViewDataSpecs.deriveAllSearchCriteria(
                            collateralSearchResultDataTablesRequest.getSearchCriteria(), linesOfBusiness);
            Page<CollateralSearchViewData> requestedPage =
                    collateralSearchRepository.findAll(allSearchCriteria,constructPageSpecification(collateralSearchResultDataTablesRequest));
            if (requestedPage.getContent() != null && !requestedPage.getContent().isEmpty()) {
                collateralSearchResultDataTablesRequest.setLength(requestedPage.getTotalElements());
                result = ctracObjectMapper.mapAsList(requestedPage.getContent(), CollateralSearchResultData.class);
			}
		}
		logger.debug("getCollateralSearchResult:: done");
		return result;
	}
	
	private Pageable constructPageSpecification(CollateralSearchResultDataTablesRequest request) {
		return new PageRequest(request.getPageIndex(), request.getLength().intValue(), deriveSortSpec(request));
	}
	
	private Sort deriveSortSpec(CollateralSearchResultDataTablesRequest request) {
		String fieldName = request.getOrderByFieldName();
		if (StringUtils.isBlank(fieldName)) {
			fieldName ="borrowerName";
		}
		String sortDirection = request.getSortDirection();
		if (StringUtils.isBlank(sortDirection) || "asc".equalsIgnoreCase(sortDirection)) {
			Sort.Order order = new Sort.Order(Sort.Direction.ASC, fieldName).ignoreCase();
			return new Sort(order); 
		}
		Sort.Order order = new Sort.Order(Sort.Direction.DESC, fieldName).ignoreCase();
		return new Sort(order);   
	}
	
}
