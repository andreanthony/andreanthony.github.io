package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralHelperService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CtracBaseHelperData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;

@Service
public class CollateralHelperServiceImpl implements CollateralHelperService {

	private static final Logger logger = Logger.getLogger(CollateralHelperServiceImpl.class);	
	
	@Autowired private CollateralManagementService collateralManagementService;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	
	@Override
	public void populateCollateralInformation(String tmTaskId, FloodRemapData floodRemapData) {
		List <CollateralDto> collaterals = collateralManagementService.getCollateralsByTmTask(tmTaskId);
		PerfectionTask task = perfectionTaskRepository.findByTmTaskId(tmTaskId);
		floodRemapData.setCtracId(task.getWorkItem().getWorkFlowID());
		floodRemapData.addAllCollaterals(collaterals);
		floodRemapData.setTmTaskType(task.getTmTaskType());
	}
	
	@Override
	public void populateCollateralInformation(String tmTaskId, CtracBaseHelperData lenderPlaceData) {
		List <CollateralDto> collaterals = collateralManagementService.getCollateralsByTmTask(tmTaskId);
		lenderPlaceData.addAllCollaterals(collaterals);
	}

	@Override
	public void storeCollateralInformation(List<CollateralDto> collateralDTOs, String userId) {
		collateralManagementService.saveCollaterals(collateralDTOs, userId);
	}

}
