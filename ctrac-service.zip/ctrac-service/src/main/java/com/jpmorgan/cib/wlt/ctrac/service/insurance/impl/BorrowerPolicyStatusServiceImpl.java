package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyReasonForVerification;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.BorrowerPolicyStatusService;

@Service
@Transactional
public class BorrowerPolicyStatusServiceImpl implements BorrowerPolicyStatusService {

	@Autowired
	private ActivePolicyService activePolicyService;
	
	@Autowired
	private CollateralDetailsStatusService collateralDetailsStatusService;
	
	@Autowired
	private CollateralInsuranceRepository collateralInsuranceRepository;
	
	@Autowired
	private CollateralManagementService collateralManagementService;
	
	@Autowired
	private ProofOfCoverageRepository proofOfCoverageRepository;
	
	/**
	 * CREATE NEW OR RENEWAL
	 *     -> overall policy initialized to PENDING VERIFICATION
	 *     -> all links initialized to PENDING VERIFICATION
	 */
	@Override
	public void initialize(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		ProofOfCoverageDTO proofOfCoverageDTO = borrowerInsuranceReviewData.getProofOfCoverageData();
		ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(proofOfCoverageDTO.getRid());
		updateAllStatuses(proofOfCoverage, PolicyStatus.PENDING_VERIFICATION, PolicyReasonForVerification.OTHER, CollateralScreenAction.EDIT);
		proofOfCoverageDTO.refreshAuditUpdate(proofOfCoverage);
	}

	/** 
	 * EDIT WITH CANCELLATION DATE
	 *     -> overall policy moves to PENDING VERIFICATION
	 *     -> all links move to PENDING VERIFICATION 
	 * EDIT WITHOUT CANCELLATION DATE
	 *     -> do nothing (PENDING VERIFICATION should stay, ACCEPTED should stay)
	 *     -> initialize any new collateral policy status links to PENDING VERIFICATION
	 */
	@Override
	public void edit(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		ProofOfCoverageDTO proofOfCoverageDTO = borrowerInsuranceReviewData.getProofOfCoverageData();
		Long proofOfCoverageRid = proofOfCoverageDTO.getRid();
		ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(proofOfCoverageRid);
		if (proofOfCoverageDTO.hasCancellationDate()) {
			updateAllStatuses(proofOfCoverage, PolicyStatus.PENDING_VERIFICATION, PolicyReasonForVerification.CANCELATION_DATE_ENTERED , CollateralScreenAction.EDIT);
		} else {
			List<CollateralInsuranceViewData> collateralInsuranceViewData =
					collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverageRid);
			for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceViewData) {
				Long collateralRid = collateralInsurance.getCollateral().getRid();
				if (activePolicyService.getPolicyStatus(proofOfCoverageDTO, collateralRid) == null
						|| activePolicyService.getPolicyStatus(proofOfCoverage, collateralRid) == PolicyStatus.PENDING_VERIFICATION) {
					updateBorrowerPolicyStatusForCollateral(proofOfCoverage, collateralRid,
							PolicyStatus.PENDING_VERIFICATION, CollateralScreenAction.EDIT,borrowerInsuranceReviewData.getTmParams());
				}
			}
		}
		proofOfCoverageDTO.refreshAuditUpdate(proofOfCoverage);
	}

	/**
	 * VERIFY WITH CANCELLATION DATE
	 *     -> overall policy moves to CANCELLED
	 *     -> all links move to CANCELLED
	 * VERIFY WITHOUT CANCELLATION DATE
	 *     -> overall policy moves to ACCEPTED or REJECTED if not already
	 *     -> link for this collateral moves to ACCEPTED or REJECTED
	 */
	@Override
	public void verify(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		ProofOfCoverageDTO proofOfCoverageDTO = borrowerInsuranceReviewData.getProofOfCoverageData();
		ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(proofOfCoverageDTO.getRid());
		if (proofOfCoverageDTO.hasCancellationDate()) {
			updateAllStatuses(proofOfCoverage, PolicyStatus.CANCELLED, PolicyReasonForVerification.OTHER, CollateralScreenAction.VERIFY);
			proofOfCoverageDTO.setPolicyStatus(PolicyStatus.CANCELLED);

		} else {
			// only set status if pending verification
			PolicyStatus currentPolicyStatus = activePolicyService.getPolicyStatus(proofOfCoverageDTO, null);
			BorrowerInsuranceReviewConclusion birConclusion = borrowerInsuranceReviewData.getPolicyConclusion();
			PolicyStatus policyStatus = birConclusion == BorrowerInsuranceReviewConclusion.ACCEPTABLE ?
					PolicyStatus.ACCEPTED : PolicyStatus.REJECTED;
			if (currentPolicyStatus == PolicyStatus.PENDING_VERIFICATION) {
				currentPolicyStatus = policyStatus;
				activePolicyService.setPolicyStatus(proofOfCoverage, null, currentPolicyStatus,null);
				proofOfCoverageDTO.setPolicyStatus(currentPolicyStatus);
			}

			// only update status if verifying the collateral
			for (BIRCollateralDetailsDTO collateralDetailsData : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
				if (collateralDetailsData.isWantToVerify()) {
					Long collateralRid = collateralDetailsData.getCollateralRid();
					updateBorrowerPolicyStatusForCollateral(proofOfCoverage, collateralRid, currentPolicyStatus, CollateralScreenAction.VERIFY,borrowerInsuranceReviewData.getTmParams());
					collateralDetailsData.setPolicyStatus(currentPolicyStatus);
				}
			}
		}
		//on verification update to NULL
		proofOfCoverageDTO.setReasonForVerification(null);
		proofOfCoverageDTO.refreshAuditUpdate(proofOfCoverage);
	}
	
	private void updateAllStatuses(ProofOfCoverage proofOfCoverage, PolicyStatus policyStatus, PolicyReasonForVerification reasonForVerification, CollateralScreenAction action) {
		activePolicyService.setPolicyStatus(proofOfCoverage, null, policyStatus,reasonForVerification);
		List<CollateralInsuranceViewData> collateralInsuranceViewData =
				collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverage.getRid());
		for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceViewData) {
			updateBorrowerPolicyStatusForCollateral(proofOfCoverage,
					collateralInsurance.getCollateral().getRid(), policyStatus, action,null);
		}
	}
	
	private void updateBorrowerPolicyStatusForCollateral(ProofOfCoverage proofOfCoverage, Long collateralRid,
			PolicyStatus policyStatus, CollateralScreenAction action, TMParams tmParams) {
		activePolicyService.setPolicyStatus(proofOfCoverage, collateralRid, policyStatus,null);
		collateralDetailsStatusService.updateInsurancePoliciesSection(
				collateralManagementService.getCollateralDto(collateralRid), action,tmParams);
	}

}
