package com.jpmorgan.cib.wlt.ctrac.service.dto.builder;

import java.util.Collection;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsuranceCoverageMap;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;



public interface InsuranceCoverageMapFactory {
    
    InsuranceCoverageMap<ProvidedCoverageDTO> getProvidedInsuranceCoverageMap(
            Collection<ProvidedCoverageDTO> providedCoverageDTOs);
    
}
