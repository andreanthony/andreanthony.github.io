package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationType;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;
import org.apache.log4j.Logger;

import java.util.Map;


/**
 *
 * @author n595724
 * This Class scope should stay "prototype";
 * if at some point we decide to make sprint manage it live circle, the scope must stay prototype
 *
 */
public class EmailNotificationCommand extends AbstractCommand {

    private final Map<StateParameterType, Object> inputParameterMap;
    private final EmailNotificationType emailType;

	private static final Logger logger = Logger.getLogger(EmailNotificationCommand.class);

	public EmailNotificationCommand(EmailNotificationType emailType,
			Map<StateParameterType, Object> inputParameterMap) {
		this(emailType, inputParameterMap, 0);
	}

	public EmailNotificationCommand(EmailNotificationType emailType,
			Map<StateParameterType, Object> inputParameterMap, int priority) {
		this.inputParameterMap = inputParameterMap;
		this.priority = priority;
		this.emailType = emailType;
	}

	public EmailNotificationType getEmailType() {
		return emailType;
	}

	@Override
	public void execute() {
		try {
		    EmailNotificationService emailNotificationService =
		    		(EmailNotificationService) ApplicationContextProvider.getContext().getBean("emailNotificationService");
		    WorkItem workItem = null;
		    PerfectionTask perfectionTask = null;
		    TaskState currentTaskState = null;
		    BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = null;
		    switch (emailType) {
		    case PRE_LP_ZONE_CHANGE_EMAIL:
		    	workItem = (WorkItem) inputParameterMap.get(StateParameterType.WORK_ITEM);
		        emailNotificationService.releasePreLpMarketEmail(workItem.getRid());
		        break;
		    case LP_INITIATED_MARKET:
		    	emailNotificationService.releaseLpInitiatedMarketEmail(null, null);
		    	break;
		    case INSURANCE_EXCEPTION_EMAIL:
		    	perfectionTask = (PerfectionTask) inputParameterMap.get(StateParameterType.PERFECTION_TASK);
		    	currentTaskState = (TaskState) inputParameterMap.get(StateParameterType.CURRENT_TASK_STATE);
		    	borrowerInsuranceReviewData = (BorrowerInsuranceReviewDTO)
		    			inputParameterMap.get(StateParameterType.BORROWER_INSURANCE_REVIEW_DATA);
		    	emailNotificationService.sendBIRExceptionEmails(perfectionTask, currentTaskState, borrowerInsuranceReviewData);
		    	break;
		    case INSURANCE_NO_EXCEPTION_EMAIL:
		    	borrowerInsuranceReviewData = (BorrowerInsuranceReviewDTO)
		    			inputParameterMap.get(StateParameterType.BORROWER_INSURANCE_REVIEW_DATA);
		    	emailNotificationService.sendBIRPolicyAcceptedWithNoExceptionEmails(borrowerInsuranceReviewData);
		    	break;
			case MARKET_HOLD_EMAIL:
				perfectionTask = (PerfectionTask) inputParameterMap.get(StateParameterType.PERFECTION_TASK);
				emailNotificationService.sendMarketHoldEmail(perfectionTask);
				break;
			case LEAD_AGENT_EMAIL:
				perfectionTask = (PerfectionTask) inputParameterMap.get(StateParameterType.PERFECTION_TASK);
				currentTaskState = (TaskState) inputParameterMap.get(StateParameterType.CURRENT_TASK_STATE);
				emailNotificationService.sendLeadbankEmails(perfectionTask, currentTaskState);
				break;
		    default:
		    	//TODO FIXME Exception if type not listed?
		    	break;
		    }
		} catch (Exception fatal) {
		    String message = "Error releasing an email :  " +emailType.getDisplayName() +" " +fatal.getMessage();
			logger.error(message);
			throw fatal;
		}
	}



}
