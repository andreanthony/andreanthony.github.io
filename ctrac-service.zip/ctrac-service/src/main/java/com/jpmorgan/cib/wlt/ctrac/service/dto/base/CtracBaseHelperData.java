package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.validator.FloodRemapValidator;


public class CtracBaseHelperData extends BaseDto implements Serializable {

	private static final long serialVersionUID = 6488484112441638242L;
	
	private TMParams tmParams;
	
	private String tmTaskType = "NA";
	
	private Long workItemRid;
	
	private String currentWorkFlowStep;
	
	private String nextWorkFlowStep;
	
	// Variable holding WF transition process(whether manual or Batch)
    private String workflowTransitionProcess;
	
	private String screenId;
	
	private String screenTitle;
	
	// formatted in valid JavaScript format
	private String currentReferenceDate;
	
	private final List<CollateralDto> collaterals = new ArrayList<CollateralDto>();
	
	/*
	 * Must not have  a setter and the getter of this object should ensure that this is just a
	 *  pointer to and element of the {List<CollateralDto> collaterals } 
	 *  this object will not make it to the service layer. 
	 *  any update made to it properties immediately update the corresponding {CollateralDto} in collaterals
	 */
	private CollateralDto primaryCollateral = null;
	
	private LoanData primaryLoan = null;
	
	private CustomerData primaryBorrower = null;
	
	private CustomerData primaryOwner = null;

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	public String getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}

	public Long getWorkItemRid() {
		return workItemRid;
	}

	public void setWorkItemRid(Long workItemRid) {
		this.workItemRid = workItemRid;
	}
	
	public String getCurrentWorkFlowStep() {
        return currentWorkFlowStep;
    }

    public void setCurrentWorkflowStep(String currentWorkFlowStep) {
        this.currentWorkFlowStep = currentWorkFlowStep;
    }

    public String getNextWorkFlowStep() {
        return nextWorkFlowStep;
    }

    public void setNextWorkFlowStep(String nextWorkFlowStep) {
        this.nextWorkFlowStep = nextWorkFlowStep;
    }
    
    public String getWorkflowTransitionProcess() {
        return workflowTransitionProcess;
    }

    public void setWorkflowTransitionProcess(String workFlowTransitionProcess) {
        this.workflowTransitionProcess = workFlowTransitionProcess;
    }

    public String getScreenId() {
		return screenId;
	}

	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}

	public String getScreenTitle() {
        return screenTitle;
    }

    public void setScreenTitle(String screenTitle) {
        this.screenTitle = screenTitle;
    }

    public String getCurrentReferenceDate() {
        return currentReferenceDate;
    }

    public void setCurrentReferenceDate(String currentReferenceDate) {
        this.currentReferenceDate = currentReferenceDate;
    }

    public List<CollateralDto> getCollaterals() {
		return collaterals;
	}

	public void addAllCollaterals(List<CollateralDto> collaterals) {
		this.collaterals.addAll(collaterals);
		getPrimaryCollateral();
	}
	
	public CollateralDto getPrimaryCollateral() {
		if (primaryCollateral != null) {
			return primaryCollateral;
		}
		if (collaterals.isEmpty()) {
			collaterals.add(new RealEstateCollateralDto());
		}
		primaryCollateral = collaterals.get(0);
		for (CollateralDto aCollateral : collaterals) {
			if (aCollateral.getRid() != null && aCollateral.getRid() < primaryCollateral.getRid()) {
				primaryCollateral = aCollateral;
			}
		}
		return primaryCollateral;
	}
	
	public LoanData getPrimaryLoan() {
		if (primaryLoan != null) {
			return primaryLoan;
		}
		primaryLoan = getPrimaryCollateral().getPrimaryLoan();
		return primaryLoan;
	}
	
	public CustomerData getPrimaryBorrower() {
		if (primaryBorrower != null) {
			return primaryBorrower;
		}
		primaryBorrower = getPrimaryLoan().getPrimaryBorrower();
		return primaryBorrower;
	}
	
	public CustomerData getPrimaryOwner() {
        if (primaryOwner != null) {
            return primaryOwner;
        }
        primaryOwner = getPrimaryCollateral().getPrimaryOwner();
        return primaryOwner;
    }
	
	public int getColumnSize(String columnName) {
        return FloodRemapValidator.getColumnSize(columnName);
    }
	
	protected void setPrimaryAttributesCrossCollaterals() {
		AddressDto address = null;
		if (getPrimaryCollateral() != null) {
			address = getPrimaryCollateral().getAddress();
			for (CollateralDto collateralDto : getCollaterals()) {
				collateralDto.setAddress(address);
			}
		}
	}

}
