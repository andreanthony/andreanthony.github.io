package com.jpmorgan.cib.wlt.ctrac.service.insurance;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyReasonForVerification;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

public interface ActivePolicyService {

	/**
	 * @param insurableAssetRid: RID of InsurableAsset for which to find coverages; required
	 * @param policyTypes: PolicyTypes to find; can be null to include all
	 * @param date: Date that policy must be active on; can be null to include all
	 * @param includePendingVerification: whether or not to include Pending Verification as active
	 */
	List<ProofOfCoverage> findActivePoliciesByInsurableAssetRid(Long insurableAssetRid,
			Set<PolicyType> policyTypes, Date date, boolean includePendingVerification);

	/**
	 * @param insurableAssetRid: RID of InsurableAsset for which to find coverages; required
	 * @param policyTypes: PolicyTypes to find; can be null to include all
	 * @param date: Date that policy must be active on; can be null to include all
	 * @param includePendingVerification: whether or not to include Pending Verification as active
	 */
	List<ProvidedCoverage> findActiveCoverages(Long insurableAssetRid, Set<PolicyType> policyTypes,
			Date date, boolean includePendingVerification);

	/**
	 * @param proofOfCoverage: Policy to test whether or not it is active
	 * @param collateralRid: RID of Collateral to determine whether or not policy is active;
	 *                       required for Borrower policies, N/A for Lender Placed policies
	 * @param date: Date that policy must be active on; can be null to include all
	 * @param includePendingVerification: whether or not to include Pending Verification as active
	 */
	boolean isPolicyActiveForCollateralOnDate(ProofOfCoverage proofOfCoverage, Long collateralRid,
			Date date, boolean includePendingVerification);

	boolean insurableAssetHasActiveCoverage(Long insurableAssetRid,
			Date date, boolean includePendingVerification);

	PolicyStatus getPolicyStatus(ProofOfCoverage proofOfCoverage, Long collateralRid);

	PolicyStatus getPolicyStatus(ProofOfCoverageDTO proofOfCoverageDTO, Long collateralRid);

	void setPolicyStatus(ProofOfCoverage proofOfCoverage, Long collateralRid, PolicyStatus policyStatus,PolicyReasonForVerification reasonForVerification);

	void setAllPolicyStatuses(ProofOfCoverage proofOfCoverage, PolicyStatus policyStatus);

}
