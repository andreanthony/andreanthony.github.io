package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyReasonForVerification;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRCollateralDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.bir.BIRCollateralDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.bir.BIRViewDataRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.InsurableAssetRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.PolicyStatusConverter;

@Service
@Transactional(readOnly=true)
public class ActivePolicyServiceImpl implements ActivePolicyService {

	private static final Logger logger = Logger.getLogger(ActivePolicyServiceImpl.class);

	@Autowired
	private BIRCollateralDetailsRepository birCollateralDetailsRepository;

	@Autowired
	private BIRViewDataRepository birViewDataRepository;

	@Autowired
	private CollateralInsuranceRepository collateralInsuranceRepository;

	@Autowired
	private InsurableAssetRepository insurableAssetRepository;

	@Autowired
	private ProofOfCoverageRepository proofOfCoverageRepository;

	@Override
	public List<ProofOfCoverage> findActivePoliciesByInsurableAssetRid(Long insurableAssetRid,
			Set<PolicyType> policyTypes, Date date, boolean includePendingVerification) {
		//TODO Review and optimize
		List<ProofOfCoverage> activePolicies = new ArrayList<ProofOfCoverage>();
		if (insurableAssetRid == null) {
			return activePolicies;
		}
		InsurableAsset insurableAsset = insurableAssetRepository.findOne(insurableAssetRid);
		if (insurableAsset == null) {
			return activePolicies;
		}
		Collateral collateral = insurableAsset.getBuilding().getCollateral();
		List<ProvidedCoverage> providedCoverages = insurableAsset.getProvidedCoverages();
		for (ProvidedCoverage providedCoverage : providedCoverages ) {
			ProofOfCoverage proofOfCoverage = providedCoverage.getProofOfCoverage();
			PolicyType policyType = proofOfCoverage.getPolicyType_();
			if ((policyTypes == null || policyTypes.contains(policyType)) && isPolicyActiveForCollateralOnDate(
					proofOfCoverage, collateral.getRid(), date, includePendingVerification)) {
				activePolicies.add(proofOfCoverage);
			}
		}
		return activePolicies;
	}

	@Override
	public List<ProvidedCoverage> findActiveCoverages(Long insurableAssetRid,
			Set<PolicyType> policyTypes, Date date, boolean includePendingVerification) {
		List<ProvidedCoverage> activeCoverages = new ArrayList<ProvidedCoverage>();
		List<ProofOfCoverage> activePolicies = findActivePoliciesByInsurableAssetRid(
				insurableAssetRid, policyTypes, date, includePendingVerification);
		for (ProofOfCoverage policy : activePolicies) {
			for (ProvidedCoverage providedCoverage : policy.getProvidedCoverages()) {
				if (insurableAssetRid.equals(providedCoverage.getInsurableAsset().getRid())) {
					activeCoverages.add(providedCoverage);
				}
			}
		}
		return activeCoverages;
	}

	@Override
	public boolean isPolicyActiveForCollateralOnDate(ProofOfCoverage proofOfCoverage, Long collateralRid,
			Date date, boolean includePendingVerification) {
		if (!proofOfCoverage.isEffectiveOn(date)) {
			return false;
		}
		PolicyStatus policyStatus = getPolicyStatus(proofOfCoverage, collateralRid);
		return policyStatus != null && policyStatus.isActive(includePendingVerification);
	}

	@Override
	public boolean insurableAssetHasActiveCoverage(Long insurableAssetRid,
			Date date, boolean includePendingVerification) {
		return !findActivePoliciesByInsurableAssetRid(
				insurableAssetRid, null, date, includePendingVerification).isEmpty();
	}

	@Override
	public PolicyStatus getPolicyStatus(ProofOfCoverage proofOfCoverage, Long collateralRid) {
		if (proofOfCoverage == null) {
			return null;
		}
		PolicyType policyType = proofOfCoverage.getPolicyType_();
		if (policyType == null) {
			return null;
		} else if (policyType.isBorrowerPolicy() && collateralRid != null) {
			BIRCollateralDetails birCollateralDetails =
					getBIRCollateralDetails(proofOfCoverage.getRid(), collateralRid);
			return birCollateralDetails != null ?
					PolicyStatusConverter.convert(birCollateralDetails.getPolicyStatus()) :
					PolicyStatus.PENDING_VERIFICATION;
		} else {
			return proofOfCoverage.getPolicyStatus_();
		}
	}

	@Override
	public PolicyStatus getPolicyStatus(ProofOfCoverageDTO proofOfCoverageDTO, Long collateralRid) {
		if (proofOfCoverageDTO == null) {
			return null;
		}
		PolicyType policyType = proofOfCoverageDTO.getPolicyType();
		if (policyType == null) {
			return null;
		} else if (policyType.isBorrowerPolicy() && collateralRid != null) {
			BIRCollateralDetails birCollateralDetails =
					getBIRCollateralDetails(proofOfCoverageDTO.getRid(), collateralRid);
			return birCollateralDetails != null ? PolicyStatusConverter.convert(birCollateralDetails.getPolicyStatus()): null;
		} else {
			return proofOfCoverageDTO.getPolicyStatus();
		}
	}

	@Override
	@Transactional(readOnly=false)
	public void setPolicyStatus(ProofOfCoverage proofOfCoverage, Long collateralRid, PolicyStatus policyStatus,PolicyReasonForVerification reasonForVerification) {
		if (proofOfCoverage == null) {
			logger.error("proofOfCoverage=null");
			return;
		}
		PolicyType policyType = proofOfCoverage.getPolicyType_();
		if (policyType == null) {
			logger.error("policyType=null");
			return;
		}

		if (policyType.isBorrowerPolicy() && collateralRid != null) {
			logger.debug("updating policy status for policy=" + proofOfCoverage.getRid() +
					", collateral=" + collateralRid + " to " + policyStatus.name());
			BIRCollateralDetails birCollateralDetails =
					getBIRCollateralDetails(proofOfCoverage.getRid(), collateralRid);
			if(birCollateralDetails != null){
				birCollateralDetails.setPolicyStatus(policyStatus.name());
				birCollateralDetailsRepository.saveAndFlush(birCollateralDetails);
			}
		} else {
			String reasonDescription = reasonForVerification ==null ? null : reasonForVerification.name();
			logger.debug("updating overall status for policy=" + proofOfCoverage.getRid() +
					" to " + policyStatus.name() + " and ReasonForVerification to " + reasonDescription);
			if(reasonDescription != null){
				proofOfCoverage.setReasonForVerification(reasonDescription);
			}
			proofOfCoverage.setPolicyStatus(policyStatus.name());
			proofOfCoverageRepository.saveAndFlush(proofOfCoverage);
		}
	}

	private BIRCollateralDetails getBIRCollateralDetails(Long proofOfCoverageRid, Long collateralRid) {
		if (proofOfCoverageRid == null || collateralRid == null) {
			logger.error("Invalid arguments passed to getBIRCollateralDetails");
		}
		BIRViewData birViewData = birViewDataRepository.findTopByPolicyRidAndCollateralRid(
				proofOfCoverageRid, collateralRid);
		if (birViewData == null || birViewData.getBirCollateralDetailsRid() == null) {
			logger.error("No BIRViewData for ProofOfCoverage=" + proofOfCoverageRid +
					", Collateral=" + collateralRid + ".");
			return null;
		}
		return birCollateralDetailsRepository.findOne(birViewData.getBirCollateralDetailsRid());
	}

	@Override
	@Transactional(readOnly=false)
	public void setAllPolicyStatuses(ProofOfCoverage proofOfCoverage, PolicyStatus policyStatus) {
		setPolicyStatus(proofOfCoverage, null, policyStatus,null);
		List<CollateralInsuranceViewData> collateralInsuranceViewData =
				collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverage.getRid());
		for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceViewData) {
			setPolicyStatus(proofOfCoverage, collateralInsurance.getCollateral().getRid(), policyStatus,null);
		}
	}

}
