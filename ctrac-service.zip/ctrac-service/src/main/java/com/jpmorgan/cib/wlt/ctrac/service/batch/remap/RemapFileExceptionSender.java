package com.jpmorgan.cib.wlt.ctrac.service.batch.remap;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;

import java.util.List;

/**
 * Created by E704298 on 8/2/2017.
 */
public interface RemapFileExceptionSender {

    void sendExceptions(RemapVendor remapVendor, List<RemapFileException> remapFileExceptions);

}
