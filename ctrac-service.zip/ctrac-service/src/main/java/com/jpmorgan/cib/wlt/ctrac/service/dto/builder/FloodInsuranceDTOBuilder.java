package com.jpmorgan.cib.wlt.ctrac.service.dto.builder;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DefaultDateFormatter;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.FloodInsuranceDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;
import org.joda.time.DateTime;

import java.util.Date;

public class FloodInsuranceDTOBuilder {
	private final FloodInsuranceDTO floodInsuranceDTO;
	
	public FloodInsuranceDTO build(){
		return floodInsuranceDTO;
	}

    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

	public FloodInsuranceDTOBuilder(Date effectiveDate, PolicyType policyType, PolicyStatus policyStatus){
		floodInsuranceDTO = new FloodInsuranceDTO();
		floodInsuranceDTO.setPolicyType(policyType);
		floodInsuranceDTO.setPolicyStatus(policyStatus);
        setEffectiveDate(effectiveDate);
	}
	
	public FloodInsuranceDTOBuilder effectiveDate(Date effectiveDate) {
        setEffectiveDate(effectiveDate);
		return this;
	}

	private void setEffectiveDate(Date effectiveDate) {
        if (effectiveDate != null) {
            floodInsuranceDTO.setEffectiveDate(DATE_FORMATTER.print(effectiveDate));
            if (floodInsuranceDTO.getPolicyType().isLenderPlaced()) {
                Date expDate = new DateTime(effectiveDate).plusYears(1).toDate();
                floodInsuranceDTO.setExpirationDate(DATE_FORMATTER.print(expDate));
            }
        }
    }
	
	public FloodInsuranceDTOBuilder coverageType(CoverageType coverageType) {
		floodInsuranceDTO.setCoverageType(coverageType);
		return this;
	}
	
	public FloodInsuranceDTOBuilder policyType(PolicyType policyType) {
		floodInsuranceDTO.setPolicyType(policyType);
		return this;
	}
	
	public FloodInsuranceDTOBuilder policyStatus(PolicyStatus policyStatus) {
		floodInsuranceDTO.setPolicyStatus(policyStatus);
		return this;
	}
	
	public FloodInsuranceDTOBuilder expirationDate(Date expDate){
		floodInsuranceDTO.setExpirationDate(DATE_FORMATTER.print(expDate));
		return this;
	}
	
	public FloodInsuranceDTOBuilder providedCoverageDTO(ProvidedCoverageDTO providedCoverageDTO){
		floodInsuranceDTO.addProvidedCoverageDTO(providedCoverageDTO);
		return this;
	}
	
	public FloodInsuranceDTOBuilder insuredName(String insuredName){
		floodInsuranceDTO.setInsuredName(insuredName);
		return this;
	}
	
	public FloodInsuranceDTOBuilder floodZone(String floodZone){
		floodInsuranceDTO.setFloodZone(floodZone);
		return this;
	}
    
}
