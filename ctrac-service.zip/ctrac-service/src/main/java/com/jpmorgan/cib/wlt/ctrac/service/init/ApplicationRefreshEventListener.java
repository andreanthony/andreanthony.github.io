package com.jpmorgan.cib.wlt.ctrac.service.init;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;

@Component
public class ApplicationRefreshEventListener implements ApplicationListener<ApplicationEvent> {

	
	private static final Logger logger = Logger.getLogger(ApplicationRefreshEventListener.class);
	
	@Override
	public void onApplicationEvent(ApplicationEvent event) 
	{
		if(event instanceof ContextRefreshedEvent)
		{
			logger.info("Application Context was initialized/refreshed.. :"+event);
			//Appl initializing can be done here every time the app context is refreshed.
			
			EntityManagerFactory emf= (EntityManagerFactory) ApplicationContextProvider.getContext().getBean("entityManagerFactory");
			EntityManager em = emf.createEntityManager();
			if(em != null && em.isOpen())
			{
				logger.info("Datasource initialized successfully.. Entity Manager available to execute queries");
				em.close();
			}
		}
		
	}
	
	

}
