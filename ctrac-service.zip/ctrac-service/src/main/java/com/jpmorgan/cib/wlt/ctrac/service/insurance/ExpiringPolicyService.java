package com.jpmorgan.cib.wlt.ctrac.service.insurance;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

public interface ExpiringPolicyService {

    /**
     *
     * @param proofOfCoverage
     * @return true if this policy moved to expired, false otherwise
     */
    boolean updateExpiringPolicyStatus(ProofOfCoverage proofOfCoverage);

}
