package com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;


public class CollectWireConfirmationData implements Serializable {
	private static final long serialVersionUID = 5653169618149388120L;
	protected TMParams tmParams;
	protected String notificationMessage;
	protected String screenId;
	
	public String getScreenId() {
		return screenId;
	}

	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}

	public String getNotificationMessage() {
		return notificationMessage;
	}

	public void setNotificationMessage(String notificationMessage) {
		this.notificationMessage = notificationMessage;
	}

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	
}
