package com.jpmorgan.cib.wlt.ctrac.service.bir;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public interface BIRManagementService {

	BorrowerInsuranceReviewDTO prepareNewBIRWithCollateralRid(Long collateralRid);
	
	BorrowerInsuranceReviewDTO getBorrowerInsuranceReviewData(Long proofOfCoverageRid, Long collateralRid);
	
	void addCollateralDetails(Long collateralId, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void saveBorrowerInsuranceReview(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);

	boolean isAllCollateralsVerified(Long borrowerInsuranceReviewDetailsRid, Long currentCollateralRid);
	
	void deleteBorrowerInsuranceReview(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);

	void performBIProofOfCoveragePublishEvent(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, CollateralEventType overrideCollateralEventType,
											  boolean proofOfCoverageChangeDuringVerification);

}
