package com.jpmorgan.cib.wlt.ctrac.service.externallyAgented.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCovWorkItemRepository;
import com.jpmorgan.cib.wlt.ctrac.service.FloodInsuranceRenewalService;
import com.jpmorgan.cib.wlt.ctrac.service.externallyAgented.ExternallyAgentedService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.*;

@Service(value = "externallyAgentedService")
public class ExternallyAgentedServiceImpl implements ExternallyAgentedService {
    private static final Logger logger = LoggerFactory.getLogger(ExternallyAgentedServiceImpl.class);

    @Autowired
    private LoanService loanService;
    @Autowired
    private ProofOfCovWorkItemRepository proofOfCovWorkItemRepository;
    @Autowired
    private CollateralInsuranceRepository collateralInsuranceRepository;
    @Autowired
    private PerfectionTaskService perfectionTaskService;
    @Autowired
    private FloodInsuranceRenewalService floodInsuranceRenewalService;

    @Override
    public void createLeadBankEmailNoticeTask(Long collateralRid) {
        if (loanService.hasExternallyAgented(collateralRid)) {
            logger.debug("createLeadBankEmailNoticeTask::START ,CollateralRid: {}", collateralRid);
            List<CollateralInsuranceViewData> collateralInsuranceList =
                    collateralInsuranceRepository.findByCollateralRid(collateralRid);
            if (CollectionUtils.isEmpty(collateralInsuranceList)) {
                logger.error("No policies found for collateral found to initiate send lead agent market email.");
                throw new RuntimeException("No policies found for collateral found to initiate send lead agent market email");
            }

            for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceList) {
                ProofOfCoverage proofOfCoverage = CtracBaseEntity.deproxy(collateralInsurance.getProofOfCoverage(), ProofOfCoverage.class);
                boolean isRenewalPolicyAccepted = floodInsuranceRenewalService.isRenewalPolicyAccepted(proofOfCoverage);
                if (PolicyStatus.EXPIRING_EA.equals(proofOfCoverage.getPolicyStatus_()) && !isRenewalPolicyAccepted) {
                    List<ProofOfCovWorkItem> listProofOfCovWorkItem = proofOfCovWorkItemRepository.findByProofOfCoverageRidAndItemType(collateralInsurance.getProofOfCoverage().getRid(), ProofOfCoverageWorkItemRelationType.RENEWAL_TO_POLICY.getName());
                    if (CollectionUtils.isNotEmpty(listProofOfCovWorkItem)) {
                        createLeadBankEmailNoticeTask(listProofOfCovWorkItem.get(0).getWorkItem());
                    } else {
                        throw new RuntimeException("No proof of coverage work items found to create lead bank email task for collateralRid="
                                + collateralRid + " proofOfCoverageRid=" + proofOfCoverage.getRid());
                    }
                }
            }
            logger.debug("createLeadBankEmailNoticeTask::END ,CollateralRid: {}", collateralRid);
        }
    }

    private void createLeadBankEmailNoticeTask(WorkItem workItem) {
        logger.debug("createSendMarketHoldEmailTask::begin");
        try {
            List<PerfectionTask> existingTasks = perfectionTaskService.findTasksForWorkItem(
                    workItem, getLeadBankSteps(), Collections.singletonList(TaskStatus.TRANSIENT.name()));
            if (CollectionUtils.isNotEmpty(existingTasks)) {
                logger.debug("Notice task for work item rid {} already exists - taskId: {}", workItem.getRid(),
                        StringUtils.join(existingTasks.stream().map(PerfectionTask::getTmTaskId).collect(Collectors.toList()), ','));
                return;
            }

            Map<StateParameterType, Object> inputParameterMap = new HashMap<>();
            inputParameterMap.put(StateParameterType.WORK_ITEM, workItem);
            PerfectionTask perfectionTask = perfectionTaskService.createTransientTask(
                    workItem, SEND_LEAD_BANK_EMAIL_1ST_NOTICE_STATE.getFloodRemapTaskState(),
                    TMTaskType.FLOOD_INSURANCE, inputParameterMap);
            logger.debug("createSendMarketHoldEmailTask::end perfection task created rid: {} TM task id: {}",
                    perfectionTask.getRid(), perfectionTask.getTmTaskId());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new CTracApplicationException("E0258", CtracErrorSeverity.APPLICATION);
        }
    }

    private List<String> getLeadBankSteps() {
        return Arrays.asList(
                SEND_LEAD_BANK_EMAIL_1ST_NOTICE_STATE.getName(),
                SEND_LEAD_BANK_EMAIL_2ND_NOTICE_STATE.getName(),
                SEND_LEAD_BANK_EMAIL_3RD_NOTICE_STATE.getName());
    }
}
