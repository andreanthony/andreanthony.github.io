package com.jpmorgan.cib.wlt.ctrac.service.ews.adapter;

import microsoft.exchange.webservices.data.ITraceListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExchangeWebServiceTraceListener implements ITraceListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExchangeWebServiceTraceListener.class);

    @Override
    public void trace(String traceType, String traceMessage) {
        LOGGER.trace("Trace type: {} Message: {}", traceType, traceMessage);
    }
}
