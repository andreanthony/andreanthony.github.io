package com.jpmorgan.cib.wlt.ctrac.service.config;
import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.Environment;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.hierarchicalroles.RoleHierarchyImpl;
import org.springframework.security.acls.AclPermissionEvaluator;
import org.springframework.security.acls.domain.AclAuthorizationStrategyImpl;
import org.springframework.security.acls.domain.ConsoleAuditLogger;
import org.springframework.security.acls.domain.DefaultPermissionGrantingStrategy;
import org.springframework.security.acls.domain.EhCacheBasedAclCache;
import org.springframework.security.acls.jdbc.BasicLookupStrategy;
import org.springframework.security.acls.jdbc.JdbcMutableAclService;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

/**
 * 
 * @author
 *
 */
@Configuration
@Import({ CachingConfig.class})
public class ACLConfig{

	@Autowired 
	private DataSource ctracDataSource;

	@Autowired
	private EhCacheManagerFactoryBean ehCacheManagerFactoryBean;

	private static final Logger logger = Logger.getLogger(ACLConfig.class);
	
	@Resource
	private Environment env;
	

	@Bean 
	public DefaultMethodSecurityExpressionHandler expressionHandler(){
		DefaultMethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler() ;
		expressionHandler.setPermissionEvaluator(permissionEvaluator());
		expressionHandler.setRoleHierarchy(roleHierarchy());
		return expressionHandler;
	}
    
	@Bean 
	public RoleHierarchyImpl roleHierarchy(){
		RoleHierarchyImpl roleHierarchy = new RoleHierarchyImpl();
		roleHierarchy.setHierarchy("ROLE_ADMIN > ROLE_USER");//TODO double chek
		return roleHierarchy;
	}

	
	@Bean 
	public EhCacheBasedAclCache aclCache(){
		net.sf.ehcache.CacheManager cacheManager = ehCacheManagerFactoryBean.getObject();
		EhCacheBasedAclCache aclCache = new EhCacheBasedAclCache(cacheManager.getEhcache("aclEhCache"), permissionGrantingStrategy(), authorizationStrategy()); 
		return aclCache;
	}
	
	/*@Bean 
	public EhCacheFactoryBean aclEhCache(){
		EhCacheFactoryBean aclEhCache = new EhCacheFactoryBean();
		aclEhCache.setCacheManager(ehCacheManagerFactoryBean.getObject());
		return aclEhCache;
	}*/
	
	@Bean 
	public BasicLookupStrategy lookupStrategy(){
		BasicLookupStrategy lookupStrategy = new BasicLookupStrategy(ctracDataSource, aclCache(), authorizationStrategy(), permissionGrantingStrategy());
		return lookupStrategy;
	}
	
	@Bean 
	public AclAuthorizationStrategyImpl authorizationStrategy(){
		
		//TODO FIXME redefine 
		SimpleGrantedAuthority role1 = new SimpleGrantedAuthority("ROLE_ADMIN");
		SimpleGrantedAuthority role2 = new SimpleGrantedAuthority("ROLE_USER");
		SimpleGrantedAuthority role3 = new SimpleGrantedAuthority("ROLE_PROCESSOR");
		/*SimpleGrantedAuthority role4 = new SimpleGrantedAuthority("GUESS");*/
		
		 AclAuthorizationStrategyImpl authorizationStrategy =  new AclAuthorizationStrategyImpl(role1,role2, role3);
		return authorizationStrategy;
	}
	
	@Bean 
	public DefaultPermissionGrantingStrategy permissionGrantingStrategy(){
		DefaultPermissionGrantingStrategy permissionGrantingStrategy = new DefaultPermissionGrantingStrategy(new ConsoleAuditLogger());
		return permissionGrantingStrategy;
	}
	
	@Bean 
	public AclPermissionEvaluator permissionEvaluator(){
		AclPermissionEvaluator permissionEvaluator = new AclPermissionEvaluator( aclService());
		return permissionEvaluator;
	}
	
	@Bean 
	public JdbcMutableAclService aclService(){
		JdbcMutableAclService aclService = new JdbcMutableAclService(ctracDataSource, lookupStrategy(), aclCache());
		//TODO FIXME finalize
		aclService.setSidIdentityQuery("SELECT ACL_SID_SEQUENCE.NEXTVAL FROM DUAL");
		aclService.setClassIdentityQuery("SELECT ACL_CLASS_SEQUENCE.NEXTVAL FROM DUAL");
		return aclService;
	}

}
