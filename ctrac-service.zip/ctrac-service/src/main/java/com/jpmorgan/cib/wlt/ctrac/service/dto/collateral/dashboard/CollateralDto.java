package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.api.collateral.building.BuildingDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.letters.impl.LoanLoadedDateComparator;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NotEmptyIfAnotherFieldHasValue;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.util.*;

@NotEmptyIfAnotherFieldHasValue.List({
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "BUS", dependFieldName = "legalDescription", message = "{invalid.collateralDto.legalDescription}"),
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "REL", dependFieldName = "address.streetAddress", message = "{invalid.addressDto.streetAddress}"),
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "REL", dependFieldName = "address.city", message = "{invalid.addressDto.city}"),
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "REL", dependFieldName = "address.zipCode", message = "{invalid.addressDto.zipCode}"),
		@NotEmptyIfAnotherFieldHasValue(fieldName = "collateralType", fieldValue = "REL", dependFieldName = "address.state", message = "{invalid.addressDto.state}")
})

//Must remain abstract
public abstract class CollateralDto extends BaseDto implements Cloneable {

	private static final long serialVersionUID = 1L;

    private static final Logger logger = Logger.getLogger(CollateralDto.class);

	private Long rid;

	private String collateralType;

	private Collection<LookUpCode> collateralTypes;

	private Collection<LookUpCode> collateralStatuses;

	private String collateralTypeDescription;

	private Long emailRid;

	@NotEmpty(message="{invalid.collateralDto.collateralSubType}")
	@Size(max=255, message="{invalid.collateralDto.collateralSubType}")
	private String collateralSubType;

	private String collateralSubTypeDescription;

	private CollateralStatus collateralStatus;

	@NoInvalidCharacters
	@Size(max=255, message="{invalid.collateralDto.legalDescription}")
	private String legalDescription;

	private String adminComments;

	@Valid
	private AddressDto address;

	private final List<LoanData> loansData = new ArrayList<>();

	@Valid
	private final List<CustomerData> ownerData = new ArrayList<>();

	private Character borrowerSameAsOwner;

    private List<BuildingDTO> buildings = new ArrayList<>();

	private List<FloodDeterminationDto> floodDeterminations;

	private List<CustomerData> ownerDataToBeDeleted = new ArrayList<>();
	/*
	 * Must not have a setter and the getter of this property must insure that it is just a pointer to an element inside
	 * the loansData array; updates to this element are immediately reflected inside the array
	 */
	private LoanData primaryLoan = null;

	private CustomerData primaryOwner = null;

	private CollateralDto loadTimeValue;

	private Boolean showVerify = false;

	@NoInvalidCharacters
	private String marketEmailAddress;

	@NoInvalidCharacters
	private String releaseComment;

	private String releaseDate;

	//TODO think about a DTO for collateralWorkItems
	//private List<CollateralWorkItem> collateralWorkItems
	public CollateralDto() {}

	/**
	 * For each scenario, a separate letter must go out to all UNIQUE Borrowers and Owners.
	 * e.g. 2 Borrowers and 3 Owners = 5 separate letters
	 *
	 * First, send to all borrowers (including borrowers same as owners). If a borrower
	 * is an owner, use the mailing address from the owner and they should still only
	 * receive 1 letter.
	 *
	 * Second, send to all owners that are not borrowers.
	 *
	 * Example:
	 * 1 Owner = Qile, 1 Loan with Borrower as Qile
	 * Separate letters go to:
	 * 		Qile with her Owner Mailing Address
	 *
	 * Example:
	 * 1 Owner = Qile, 1 Loan with Borrowers as Collin & Qile
	 * Separate letters go to:
	 * 		Collin with his Borrower Mailing Address
	 * 		Qile with her Owner Mailing Address
	 *
	 * Example:
	 * 1 Owner = Qile, 1 Loan with Borrower as Collin & Amit
	 * Separate letters go to:
	 * 		Collin & Amit with their Borrower Mailing Address
	 * 		Qile her with Owner Mailing Address
	 *
	 * Example:
	 * 1 Owner = Qile, 2 Loans, 1 with Borrower as Collin, 1 with Borrower as Amit
	 * Separate letters go to:
	 * 		Collin with his Borrower Mailing Address
	 * 		Amit with his Borrower Mailing Address
	 * 		Qile with her Owner Mailing Address
	 */

	public Set<Long> getAllBorrowers() {
		Set<Long> borrowers = new HashSet<Long>();
		for (LoanData loanData : getLoansData()) {
			for (CustomerData borrower : loanData.getBorrowersData()) {
				borrowers.add(borrower.getRid());
			}
		}
		return borrowers;
	}

	public String getBorrowerNames() {
        Collections.sort(getLoansData(), new LoanLoadedDateComparator());
        StringBuilder sb = new StringBuilder();
        Set<CustomerData> borrowers = new HashSet<CustomerData>();
        for (LoanData loanData : getLoansData()) {
            for (CustomerData borrower : loanData.getBorrowersData()) {
                borrowers.add(borrower);
            }
        }
        for(CustomerData customerData: borrowers){
            String name = CtracStringUtil.simplify(customerData.getBorrowerName());
            if(!StringUtils.isBlank(name))
                sb.append((sb.length() == 0? "":" | ") + name);
        }
        return sb.toString();
	}

	public boolean hasMultipleOwners() {
		return getOwnerData().size() > 1 ? true : false;
	}


	public String getCommaSeparatedCollateralOwners() {
		StringBuilder sb = new StringBuilder("");
		for (int i = 0; i < ownerData.size(); i++) {
			CustomerData owner = ownerData.get(i);
			if (StringUtils.isBlank(owner.getBorrowerName())) {
				continue;
			}
			if (sb.length() != 0) {
				sb.append(", ");
			}
			sb.append(owner.getBorrowerName());
		}
		return sb.toString();
	}

	public String getPipeSeparatedPrimaryLoanBorrowerNames() {
		if (getPrimaryLoan() == null) {
			return "";
		}
		StringBuilder sb = new StringBuilder("");
		for (int i = 0; i < getPrimaryLoan().getBorrowersData().size(); i++) {
			CustomerData borrower = getPrimaryLoan().getBorrowersData().get(i);
			if (StringUtils.isBlank(borrower.getBorrowerName())) {
				continue;
			}
			if (sb.length() != 0) {
				sb.append(" | ");
			}
			sb.append(borrower.getBorrowerName());
		}
		return sb.toString();
	}

	public String getCollateralDescription() {
        if (CollateralType.REAL_ESTATE.getCode().equals(this.getCollateralType())) {
            return getAddress() != null ? getAddress().getFormattedFullAddress() : "";
        } else {
        	return StringUtils.isNotBlank(collateralSubTypeDescription) ?
        			collateralSubTypeDescription : collateralTypeDescription;
        }
	}

	public void removeOwnerData(Integer index){
		if (index != null && index >= 0 && index < ownerData.size()) {
			ownerData.remove(index.intValue());
		}
	}

	public void addOwnerDataToBeDeleted(CustomerData customerData){
		ownerDataToBeDeleted.add(customerData);
	}

    public List<BuildingDTO> getBuildings() {
        return buildings;
    }

    public void setBuildings(List<BuildingDTO> buildings) {
        this.buildings = buildings;
    }

    public List<InsurableAssetDTO> getInsurableAssets() {
	    List<InsurableAssetDTO> insurableAssets = new ArrayList<>();
	    for (BuildingDTO building : buildings) {
	        if (building.getInsurableAssets() != null) {
                insurableAssets.addAll(building.getInsurableAssets());
            }
        }
		return insurableAssets;
	}

	public String getLegalDescription() {
		return legalDescription;
	}

	public void setLegalDescription(String legalDescription) {
		this.legalDescription = legalDescription;
	}

	public void setPrimaryOwner(CustomerData primaryOwner) {
		this.primaryOwner = primaryOwner;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public CollateralStatus getCollateralStatus() {
		return collateralStatus;
	}

	public void setCollateralStatus(CollateralStatus collateralStatus) {
		this.collateralStatus = collateralStatus;
	}

	public List<LoanData> getLoansData() {
		return loansData;
	}

	public List<CustomerData> getOwnerData() {
		return ownerData;
	}

	public void addAllLoansData(List<LoanData> loansData) {
		this.loansData.addAll(loansData);
	}

	public abstract String getPropertyTypeDisplayValue();

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto physicalAddress) {
		this.address = physicalAddress;
	}

    public String getAdminComments() {
        return adminComments;
    }

    public void setAdminComments(String adminComments) {
        this.adminComments = adminComments;
    }

    public CollateralDto address(AddressDto physicalAddress) {
		this.address = physicalAddress;
		return this;
	}


	public void mergeLoansUpdate(Collection<LoanData> updatedLoans){

	    if(updatedLoans!=null && !updatedLoans.isEmpty()){
		for(LoanData aloan: updatedLoans){
		    if(aloan.getRid() == null && aloan.getLoanNumber() !=null ){
				//brand new add
				loansData.add(aloan);
		    }else if(aloan.getRid() != null){
				//replace existing reference with new one
				loansData.remove(aloan);
				loansData.add(aloan);
		    }

		}
	    }
	}

	public void removeLoans(Collection<LoanData> deletedLoans){

	    if(deletedLoans!=null && !deletedLoans.isEmpty()){
		for(LoanData aloan: deletedLoans){
			loansData.remove(aloan);
		    }
	    }
	}



	/**
	 * Use some criteria to identify and return the loan marked as primary;
	 * We temporarily will assume the primary loan to be the one with the lowest rid
	 * We should NOT have a setter for this property
	 * @return the primaryLoan
	 */
	public LoanData getPrimaryLoan() {

		if(primaryLoan != null){
			return primaryLoan;
		}

        //should never happen as the list will be initialized from the db when loading the dto
		if(this.loansData.isEmpty()){
			loansData.add(new LoanData());
		}

		primaryLoan = loansData.get(0);
		for(LoanData aloan: loansData){
			if (aloan.getPrimaryFlag() != null && aloan.getPrimaryFlag().equalsIgnoreCase("Yes")){
				primaryLoan = aloan;
				break;
			}
		}
		return primaryLoan;
	}

	public CustomerData getPrimaryOwner() {
		if (primaryOwner != null) {
			return primaryOwner;
		}
		if(this.ownerData.isEmpty()){
			ownerData.add(new CustomerData());
		}
		//for now, assume the primary owner is the one with the lowest rid
		primaryOwner = ownerData.get(0);
		for (CustomerData owner : ownerData) {
			if (owner.getRid() != null && (owner.getRid() < primaryOwner.getRid())) {
				primaryOwner = owner;
			}
		}
		return primaryOwner;
	}

	public void addAllOwners(List<CustomerData> savedOwners) {
		this.ownerData.addAll(savedOwners);
	}

	public Character getBorrowerSameAsOwner() {
		return borrowerSameAsOwner;
	}

	public void setBorrowerSameAsOwner(Character borrowerSameAsOwner) {
		this.borrowerSameAsOwner = borrowerSameAsOwner;
	}

	public Boolean getShowVerify() {
		return showVerify;
	}

	public void setShowVerify(Boolean showVerify) {
		this.showVerify = showVerify;
	}

	public List<CustomerData> getOwnerDataToBeDeleted() {
		return ownerDataToBeDeleted;
	}

	public void setOwnerDataToBeDeleted(List<CustomerData> ownerDataToBeDeleted) {
		this.ownerDataToBeDeleted = ownerDataToBeDeleted;
	}

	public String getCollateralSubType() {
		return collateralSubType;
	}

	public void setCollateralSubType(String collateralSubType) {
		this.collateralSubType = collateralSubType;
	}

	public boolean hasChanged(){
		if (this.loadTimeValue == null || this.getRid() == null) {
			return true;
		}
		return !deepEquals(this.loadTimeValue);
	}

	public void saveACopy() {
        if (this.address != null) {
            this.address.saveACopy();
        }
        if (this.loansData != null && !this.loansData.isEmpty()) {
            for (LoanData elem : this.loansData) {
                elem.saveACopy();
            }
        }
        if (this.ownerData != null && !this.ownerData.isEmpty()) {
            for (CustomerData elem : this.ownerData) {
                elem.saveACopy();
            }
        }

        if (this.floodDeterminations != null && !this.floodDeterminations.isEmpty()) {
            for (FloodDeterminationDto elem : this.floodDeterminations) {
                elem.saveACopy();
            }
        }

        try {
            this.loadTimeValue = this.clone();
        } catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollateralDto other = (CollateralDto) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

	public boolean deepEquals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollateralDto other = (CollateralDto) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (borrowerSameAsOwner == null) {
			if (other.borrowerSameAsOwner != null)
				return false;
		} else if (!borrowerSameAsOwner.equals(other.borrowerSameAsOwner))
			return false;
		if (collateralStatus == null) {
			if (other.collateralStatus != null)
				return false;
		} else if (!collateralStatus.equals(other.collateralStatus))
			return false;
		if (collateralType == null) {
			if (other.collateralType != null)
				return false;
		} else if (!collateralType.equals(other.collateralType))
			return false;
		if (loansData == null) {
			if (other.loansData != null)
				return false;
		} else if (!loansData.equals(other.loansData))
			return false;
		if (ownerData == null) {
			if (other.ownerData != null)
				return false;
		} else if (!ownerData.equals(other.ownerData))
			return false;
		if (legalDescription == null) {
			if (other.legalDescription != null)
				return false;
		} else if (!legalDescription.equals(other.legalDescription))
			return false;
		if (collateralSubType == null) {
			if (other.collateralSubType != null)
				return false;
		} else if (!collateralSubType.equals(other.collateralSubType))
			return false;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		if (emailRid == null) {
			if (other.emailRid != null)
				return false;
		} else if (!emailRid.equals(other.emailRid))
			return false;
		if (releaseDate == null) {
			if (other.releaseDate != null)
				return false;
		} else if (!releaseDate.equals(other.releaseDate))
			return false;
		if (releaseComment == null) {
			if (other.releaseComment != null)
				return false;
		} else if (!releaseComment.equals(other.releaseComment))
			return false;
		return true;
	}

	@Override
	protected CollateralDto clone() throws CloneNotSupportedException {
		return (CollateralDto) super.clone();
	}

	public String getCollateralTypeDescription() {
		return collateralTypeDescription;
	}

	public void setCollateralTypeDescription(String collateralTypeDescription) {
		this.collateralTypeDescription = collateralTypeDescription;
	}

	public String getCollateralSubTypeDescription() {
		return collateralSubTypeDescription;
	}

	public void setCollateralSubTypeDescription(String collateralSubTypeDescription) {
		this.collateralSubTypeDescription = collateralSubTypeDescription;
	}

	public Long getEmailRid() {
		return emailRid;
	}

	public void setEmailRid(Long emailRid) {
		this.emailRid = emailRid;
	}

	public Collection<LookUpCode> getCollateralTypes() {
		return collateralTypes;
	}

	public void setCollateralTypes(Collection<LookUpCode> collateralTypes) {
		this.collateralTypes = collateralTypes;
	}

	public List<FloodDeterminationDto> getFloodDeterminations() {
		return floodDeterminations;
	}

	public void setFloodDeterminations(List<FloodDeterminationDto> floodDeterminations) {
		this.floodDeterminations = floodDeterminations;
	}

	public String getMarketEmailAddress() {
		return StringUtils.trimToNull(marketEmailAddress);
	}

	public void setMarketEmailAddress(String marketEmailAddress) {
		this.marketEmailAddress = marketEmailAddress;
	}

	public String getReleaseComment() {
		return releaseComment;
	}

	public void setReleaseComment(String releaseComment) {
		this.releaseComment = releaseComment;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Collection<LookUpCode> getCollateralStatuses() {
		return collateralStatuses;
	}

	public void setCollateralStatuses(Collection<LookUpCode> collateralStatuses) {
		this.collateralStatuses = collateralStatuses;
	}
}
