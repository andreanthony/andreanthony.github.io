package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CtracBaseHelperData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

import javax.validation.Valid;

public class LenderPlaceData extends CtracBaseHelperData {

	private static final long serialVersionUID = 6431889296466206640L;

	@Valid
	private ProofOfCoverageDTO proofOfCoverageData;
	
	public ProofOfCoverageDTO getProofOfCoverageData() {
		return proofOfCoverageData;
	}
	
	public void setProofOfCoverageData(ProofOfCoverageDTO floodInsuranceData) {
		this.proofOfCoverageData = floodInsuranceData;
	}
	
}
