package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

public class CollateralDoc implements Serializable {
	
	private static final long serialVersionUID = 6279933226124182700L;

	
	private String fileName;
	private byte[] fileContent;
	private Long docRid;
	private Long collateralRid;
	
	public CollateralDoc(Long rid, String fileName, byte[] fileContent){
		this.docRid = rid;
		this.fileContent = fileContent;
		this.fileName = fileName;
	}
	
	public CollateralDoc() {}
	
	public String getFileName() {
		return fileName;
	}
	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public byte[] getFileContent() {
		return fileContent;
	}
	
	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}
	
	public Long getDocRid() {
		return docRid;
	}
	
	public void setDocRid(Long docRid) {
		this.docRid = docRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}
	
	
}
