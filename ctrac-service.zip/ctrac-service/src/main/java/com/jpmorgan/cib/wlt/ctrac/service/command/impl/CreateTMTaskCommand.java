package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;



/**
 * @author n595724
 * This Class scope should stay "prototype";
 * if at some point we decide to make sprint manage it live circle, the scope must stay prototype
 */
public class CreateTMTaskCommand extends AbstractCommand{

	private final List<PerfectionTask> perfectionTasksList;
	
	private static final Logger logger = Logger.getLogger(CreateTMTaskCommand.class);

	public CreateTMTaskCommand(PerfectionTask perfectionTask) {
		this(perfectionTask, 0);
	}
	
	public CreateTMTaskCommand(PerfectionTask perfectionTask, int priority) {
		this.perfectionTasksList = new ArrayList<PerfectionTask>();
		this.perfectionTasksList.add(perfectionTask);
		this.priority = priority;
	}
	
	public CreateTMTaskCommand(List<PerfectionTask> perfectionTasksList) {
		this(perfectionTasksList, 0);
	}

	public CreateTMTaskCommand(List<PerfectionTask> perfectionTasksList, int priority) {
		this.perfectionTasksList = perfectionTasksList;
		this.priority = priority;
	}

	@Override
	public void execute() {
		//TODO handle bean not found exceptions
		TMService tmService=  (TMService) ApplicationContextProvider.getContext().getBean("TMService");
		for (PerfectionTask perfectionTask : perfectionTasksList) {
			try {
				tmService.createTask(perfectionTask);
			} catch (Exception swallow) {
				logger.error("Error creating TM task: " + perfectionTask.getTmTaskId());
			}
		}	
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((perfectionTasksList == null) ? 0 : perfectionTasksList.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreateTMTaskCommand other = (CreateTMTaskCommand) obj;
		if (perfectionTasksList == null) {
			if (other.perfectionTasksList != null)
				return false;
		}
		else if (!perfectionTasksList.equals(other.perfectionTasksList))
			return false;
		return true;
	}
	
}
