package com.jpmorgan.cib.wlt.ctrac.service.dto.view;

public class ProofOfCoverageDetailsViewDto {		
	
	private Long proofOfCoverageRid;
	
	private String insuranceType;
	
	private String effectiveDate;
	
	private String expirationDate;
	
	private String cancellationEffectiveDate;
	
	private String policyNumber;
	
	private String floodZone;
	
	private String insuredName;
	
	private String policyTypeCode;
	
	private String policyTypeDescription;
	
	private String coverageTypeCode;
	
	private String coverageTypeDescription;
	
	private String insuranceAgency;
	
	private String buildingDeductible;
	
	private String contentsDeductible;
	
	private String agentEmailAddress;
	
	private String agentPhoneNumber;
	
	private String invoicePaymentMethodCode;
	
	private String invoicePaymentMethodDescription;
	
	private String invoicePaymentAccount;
	
	private String invoicePaymentAddress;
	
	private String invoicePaymentCity;
	
	private String invoicePaymentState;
	
	private String invoicePaymentZipCode;
	
	private String invoicePaymentUnitBuilding;
	
	private String refundPaymentMethodCode;
	
	private String refundPaymentMethodDescription;
	
	private String refundPaymentAccount;
	
	private String refundPaymentAddress;
	
	private String refundPaymentCity;
	
	private String refundPaymentState;
	
	private String refundPaymentZipCode;
	
	private String refundPaymentUnitBuilding;	
	
	private String policyStatus;

	private String invalid;
	
	public String getInvalid() {
		return invalid;
	}

	public void setInvalid(String invalid) {
		this.invalid = invalid;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public String getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getPolicyTypeCode() {
		return policyTypeCode;
	}

	public void setPolicyTypeCode(String policyTypeCode) {
		this.policyTypeCode = policyTypeCode;
	}

	public String getPolicyTypeDescription() {
		return policyTypeDescription;
	}

	public void setPolicyTypeDescription(String policyTypeDescription) {
		this.policyTypeDescription = policyTypeDescription;
	}

	public String getCoverageTypeCode() {
		return coverageTypeCode;
	}

	public void setCoverageTypeCode(String coverageTypeCode) {
		this.coverageTypeCode = coverageTypeCode;
	}

	public String getCoverageTypeDescription() {
		return coverageTypeDescription;
	}

	public void setCoverageTypeDescription(String coverageTypeDescription) {
		this.coverageTypeDescription = coverageTypeDescription;
	}

	public String getInsuranceAgency() {
		return insuranceAgency;
	}

	public void setInsuranceAgency(String insuranceAgency) {
		this.insuranceAgency = insuranceAgency;
	}

	public String getBuildingDeductible() {
		return buildingDeductible;
	}

	public void setBuildingDeductible(String buildingDeductible) {
		this.buildingDeductible = buildingDeductible;
	}

	public String getContentsDeductible() {
		return contentsDeductible;
	}

	public void setContentsDeductible(String contentsDeductible) {
		this.contentsDeductible = contentsDeductible;
	}

	public String getAgentEmailAddress() {
		return agentEmailAddress;
	}

	public void setAgentEmailAddress(String agentEmailAddress) {
		this.agentEmailAddress = agentEmailAddress;
	}

	public String getAgentPhoneNumber() {
		return agentPhoneNumber;
	}

	public void setAgentPhoneNumber(String agentPhoneNumber) {
		this.agentPhoneNumber = agentPhoneNumber;
	}

	public String getInvoicePaymentMethodCode() {
		return invoicePaymentMethodCode;
	}

	public void setInvoicePaymentMethodCode(String invoicePaymentMethodCode) {
		this.invoicePaymentMethodCode = invoicePaymentMethodCode;
	}

	public String getInvoicePaymentMethodDescription() {
		return invoicePaymentMethodDescription;
	}

	public void setInvoicePaymentMethodDescription(
			String invoicePaymentMethodDescription) {
		this.invoicePaymentMethodDescription = invoicePaymentMethodDescription;
	}

	public String getInvoicePaymentAccount() {
		return invoicePaymentAccount;
	}

	public void setInvoicePaymentAccount(String invoicePaymentAccount) {
		this.invoicePaymentAccount = invoicePaymentAccount;
	}

	public String getInvoicePaymentAddress() {
		return invoicePaymentAddress;
	}

	public void setInvoicePaymentAddress(String invoicePaymentAddress) {
		this.invoicePaymentAddress = invoicePaymentAddress;
	}

	public String getInvoicePaymentCity() {
		return invoicePaymentCity;
	}

	public void setInvoicePaymentCity(String invoicePaymentCity) {
		this.invoicePaymentCity = invoicePaymentCity;
	}

	public String getInvoicePaymentState() {
		return invoicePaymentState;
	}

	public void setInvoicePaymentState(String invoicePaymentState) {
		this.invoicePaymentState = invoicePaymentState;
	}

	public String getInvoicePaymentZipCode() {
		return invoicePaymentZipCode;
	}

	public void setInvoicePaymentZipCode(String invoicePaymentZipCode) {
		this.invoicePaymentZipCode = invoicePaymentZipCode;
	}

	public String getInvoicePaymentUnitBuilding() {
		return invoicePaymentUnitBuilding;
	}

	public void setInvoicePaymentUnitBuilding(String invoicePaymentUnitBuilding) {
		this.invoicePaymentUnitBuilding = invoicePaymentUnitBuilding;
	}

	public String getRefundPaymentMethodCode() {
		return refundPaymentMethodCode;
	}

	public void setRefundPaymentMethodCode(String refundPaymentMethodCode) {
		this.refundPaymentMethodCode = refundPaymentMethodCode;
	}

	public String getRefundPaymentMethodDescription() {
		return refundPaymentMethodDescription;
	}

	public void setRefundPaymentMethodDescription(
			String refundPaymentMethodDescription) {
		this.refundPaymentMethodDescription = refundPaymentMethodDescription;
	}

	public String getRefundPaymentAccount() {
		return refundPaymentAccount;
	}

	public void setRefundPaymentAccount(String refundPaymentAccount) {
		this.refundPaymentAccount = refundPaymentAccount;
	}

	public String getRefundPaymentAddress() {
		return refundPaymentAddress;
	}

	public void setRefundPaymentAddress(String refundPaymentAddress) {
		this.refundPaymentAddress = refundPaymentAddress;
	}

	public String getRefundPaymentCity() {
		return refundPaymentCity;
	}

	public void setRefundPaymentCity(String refundPaymentCity) {
		this.refundPaymentCity = refundPaymentCity;
	}

	public String getRefundPaymentState() {
		return refundPaymentState;
	}

	public void setRefundPaymentState(String refundPaymentState) {
		this.refundPaymentState = refundPaymentState;
	}

	public String getRefundPaymentZipCode() {
		return refundPaymentZipCode;
	}

	public void setRefundPaymentZipCode(String refundPaymentZipCode) {
		this.refundPaymentZipCode = refundPaymentZipCode;
	}

	public String getRefundPaymentUnitBuilding() {
		return refundPaymentUnitBuilding;
	}

	public void setRefundPaymentUnitBuilding(String refundPaymentUnitBuilding) {
		this.refundPaymentUnitBuilding = refundPaymentUnitBuilding;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}

	public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}

	
}
