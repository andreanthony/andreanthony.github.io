package com.jpmorgan.cib.wlt.ctrac.service.datamover.impl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataProcessor;


/**
 * NotEqualFilterProcessor will return subset of records that are passing the NotEqual check for the field represented by 
 * sourceFieldName by comparing it against the targetValue.
 * @author n446693
 *
 */
public class NotEqualFilterProcessor implements DataProcessor {
	String sourceFieldName;
	Object targetValue;
	/**
	 * NotEqualFilterProcessor will return subset of records that are passing the NotEqual check for the field represented by 
	 * sourceFieldName by comparing it against the targetValue.
	 * @author n446693
	 *
	 */
	public NotEqualFilterProcessor(String sourceFieldName, Object targetValue) {
		super();
		this.sourceFieldName = sourceFieldName;
		this.targetValue = targetValue;
	}
	

	@Override
	public<Source> List<Source> apply(List<Source> sourceDataList)
	{
		List<Source> sourceDataToMove = new ArrayList<Source>();
		for(Source sourceData : sourceDataList){
			applyNotEqualFilter(sourceDataToMove,sourceData);
		}
		return sourceDataToMove;
	}

	private <Source> void applyNotEqualFilter(List<Source> sourceDataToMove, Source sourceData) {			
		try {
			Field sourceField = sourceData.getClass().getDeclaredField(sourceFieldName);
			sourceField.setAccessible(true);
			Object sourceFieldValue = sourceField.get(sourceData);
			if(!targetValue.equals(sourceFieldValue)){
				sourceDataToMove.add(sourceData);
			}		
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
