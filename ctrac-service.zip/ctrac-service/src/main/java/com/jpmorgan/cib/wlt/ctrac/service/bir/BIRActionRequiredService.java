package com.jpmorgan.cib.wlt.ctrac.service.bir;

import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public interface BIRActionRequiredService {

	void triggerPIAWorkflow(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void triggerInsuranceExceptionEmailWorkflow(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void triggerPolicyAcceptedWithNoExceptionEmails(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void triggerRejectionExceptionEmails(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void triggerZoneVarianceWorkflow(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, Long collateralRid);
	
}
