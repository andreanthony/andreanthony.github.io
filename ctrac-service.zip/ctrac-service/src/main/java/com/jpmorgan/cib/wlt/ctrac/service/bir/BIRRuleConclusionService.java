package com.jpmorgan.cib.wlt.ctrac.service.bir;

import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public interface BIRRuleConclusionService {

	boolean hasException(Long proofOfCoverageRid);
	
	void loadBIRFieldConclusions(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	boolean saveBIRFieldConclusions(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void createOrUpdateException(Long proofOfCoverageRid, Long collateralRid,
			BorrowerInsuranceReviewRule birRule, BorrowerInsuranceReviewConclusion birConclusion);
	
	BIRRuleConclusionDTO saveBIRRuleConclusion(BIRRuleConclusionDTO birRuleConclusionData);
	
}
