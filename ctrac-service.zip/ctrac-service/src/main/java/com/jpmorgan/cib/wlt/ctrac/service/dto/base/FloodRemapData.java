package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.REMINDER_TYPES;

import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.springframework.web.multipart.MultipartFile;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;



//TODO rename to something like CollateralInfoData
public class FloodRemapData extends CtracBaseHelperData {

    private static final long serialVersionUID = -1845212704565632733L;
	
	protected FloodRenewalData renewalData;

	/*
	 * TODO FIXME review all; everything below this line need to be reviews and deleted if needed;
	 */
	protected long perfectionTaskId;
	
	@Deprecated //get from specific collaterals
	protected String borrowerName;

	@Deprecated //get from specific collaterals
	protected String propertyAddress;
	@Deprecated //get from specific collaterals
	private String loanNumber;

	@Deprecated //get from specific collaterals
	private String cityStateZipcode;

	@Deprecated //get from specific collaterals
	protected String city;
	
	@Deprecated //get from specific collaterals
	private String stateCode;
	
	@Deprecated //get from specific collaterals
	protected String county;
	
	@Deprecated //get from specific collaterals
	protected String state;

	@Deprecated //get from specific collaterals
	protected String zipcode;

	protected Character clientFound;

	protected Character propertyPledge;

	protected Character exposure;
	
	//protected Character loanActive;
	
	protected String lpiType;

	protected String eventType;

	protected String eventTaskType;

	protected String escalationEmailFlag;

	protected String remapType;

	protected String remapTypeCode;

	protected String completionFlag;
	
	private boolean taskComplete = false;

	private String emailStaticText;

	private String emailSubject;

	private String emailTemplateName;

	protected List<LookUpCode> stateCodes;

	private boolean sendAndContinueStatus;

	private String lobEmailSendFlag;	
	
	private  int slaTimer;
	
	private  int slaDaysRemaining;
	
	private String floodZoneStatus;
	
	private MultipartFile SFHDF;
	
	private String ctracId;

	private Date sourceCreationDate;
	
	private String pageTitle;
	
	private String actionUrlType;
	
    //private String reminderType;
    
    private String floodZone;

    public FloodRenewalData getRenewalData() {
    	if (renewalData == null) {
    		renewalData = new FloodRenewalData();
    	}
        return renewalData;
    }

    public void setRenewalData(FloodRenewalData renewalData) {
        this.renewalData = renewalData;
    }
    
	public String getActionUrlType() {
		return actionUrlType;
	}

	public void setActionUrlType(String actionUrlType) {
		this.actionUrlType = actionUrlType;
	}

	public Date getSourceCreationDate() {
		return sourceCreationDate;
	}

	public void setSourceCreationDate(Date sourceCreationDate) {
		this.sourceCreationDate = sourceCreationDate;
	}

	@Deprecated  //explicitely use  getPrimaryCityStateZipcode()
	public String getCityStateZipcode() {
	    String commaPlaceHolder = (StringUtils.isBlank(city) || StringUtils.isBlank(state))?"":", ";
	    String spacePlaceHolder = (StringUtils.isBlank(city) && StringUtils.isBlank(state))?"":" ";
		return (StringUtils.isBlank(city)?"":city) + commaPlaceHolder + (StringUtils.isBlank(state)?"":state) +spacePlaceHolder+(StringUtils.isBlank(zipcode)?"":zipcode);
	}

	@Deprecated  //getPrimaryCityStatecodeZipcode() 
	public String getCityStatecodeZipcode() {
		  String commaPlaceHolder = (StringUtils.isBlank(city) || StringUtils.isBlank(stateCode))?"":", ";
		  String spacePlaceHolder = (StringUtils.isBlank(city) && StringUtils.isBlank(stateCode))?"":" ";
		  return (StringUtils.isBlank(city)?"":city) + commaPlaceHolder + (StringUtils.isBlank(stateCode)?"":stateCode) +spacePlaceHolder+(StringUtils.isBlank(zipcode)?"":zipcode);
	}
	
	
	public String getPrimaryCityStateZipCode() {
		
		String city= getPrimaryCollateral().getAddress().getCity();
		String state =getPrimaryCollateral().getAddress().getState();
		String zipcode=getPrimaryCollateral().getAddress().getZipCode();
		
	    String commaPlaceHolder = (StringUtils.isBlank(city) || StringUtils.isBlank(state))?"":", ";
	    String spacePlaceHolder = (StringUtils.isBlank(city) && StringUtils.isBlank(state))?"":" ";
		return (StringUtils.isBlank(city)?"":city) + commaPlaceHolder + (StringUtils.isBlank(state)?"":state) +spacePlaceHolder+(StringUtils.isBlank(zipcode)?"":zipcode);
	}

	public String getPrimaryCityStatecodeZipcode() {
		
		String city= getPrimaryCollateral().getAddress().getCity();
		String state =getPrimaryCollateral().getAddress().getState();
		String zipcode=getPrimaryCollateral().getAddress().getZipCode();
		
		String commaPlaceHolder = (StringUtils.isBlank(city) || StringUtils.isBlank(state))?"":", ";
		String spacePlaceHolder = (StringUtils.isBlank(city) && StringUtils.isBlank(state))?"":" ";
		return (StringUtils.isBlank(city)?"":city) + commaPlaceHolder + (StringUtils.isBlank(state)?"":state) +spacePlaceHolder+(StringUtils.isBlank(zipcode)?"":zipcode);
	}
	
	
	
	
	public void setCityStateZipcode(String cityStateZipcode) {
		this.cityStateZipcode = cityStateZipcode;
	}

	public long getPerfectionTaskId() {
		return perfectionTaskId;
	}

	public void setPerfectionTaskId(long perfectionTaskId) {
		this.perfectionTaskId = perfectionTaskId;
	}

	public String getPrimaryBorrowerName() {
		return getPrimaryCollateral().getPrimaryLoan().getPrimaryBorrower().getBorrowerName();
	}

	public void setPrimaryBorrowerName(String borrowerName) {
		getPrimaryCollateral().getPrimaryLoan().getPrimaryBorrower().setBorrowerName(borrowerName);
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getPrimaryPropertyAddress() {
		return getPrimaryCollateral().getAddress().getStreetAddress();
	}

	public void setPrimaryPropertyAddress(String propertyAddress) {
		getPrimaryCollateral().getAddress().setStreetAddress(propertyAddress);
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public Character getClientFound() {
		return clientFound;
	}

	public void setClientFound(Character clientFound) {
		this.clientFound = clientFound;
	}

	public Character getPropertyPledge() {
		return propertyPledge;
	}

	public void setPropertyPledge(Character propertyPledge) {
		this.propertyPledge = propertyPledge;
	}

	public Character getExposure() {
		return exposure;
	}

	public void setExposure(Character exposure) {
		this.exposure = exposure;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEventTaskType() {
		return eventTaskType;
	}

	public void setEventTaskType(String eventTaskType) {
		this.eventTaskType = eventTaskType;
	}

	public String getEscalationEmailFlag() {
		return escalationEmailFlag;
	}

	public boolean hasValidEscalationEmailFlag() {
		String flagValue =  getEscalationEmailFlag();
		if("N".equals(flagValue) || "Y".equals(flagValue))
		{
			return true;
		}
		return false;
	}

	public void setEscalationEmailFlag(String escalationEmailFlag) {
		this.escalationEmailFlag = escalationEmailFlag;
	}

	public String getRemapType() {
		return remapType;
	}

	public void setRemapType(String remapType) {
		this.remapType = remapType;
	}

	public String getRemapTypeCode() {
		return remapTypeCode;
	}

	public void setRemapTypeCode(String remapTypeCode) {
		this.remapTypeCode = remapTypeCode;
	}

	public boolean isTaskComplete() {
		return taskComplete;
	}

	public String getCtracId() {
		return ctracId;
	}

	public void setCtracId(String ctracId) {
		this.ctracId = ctracId;
	}

	public void setTaskComplete(boolean taskComplete) {
		this.taskComplete = taskComplete;
	}

	public String getEmailStaticText() {
		return emailStaticText;
	}

	public void setEmailStaticText(String emailStaticText) {
		this.emailStaticText = emailStaticText;
	}

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	public String getEmailTemplateName() {
		return emailTemplateName;
	}

	public void setEmailTemplateName(String emailTemplateName) {
		this.emailTemplateName = emailTemplateName;
	}

	public List<LookUpCode> getStateCodes() {
		return stateCodes;
	}

	public void setStateCodes(List<LookUpCode> stateCodes) {
		this.stateCodes = stateCodes;
	}

	public String getPrimaryStateCode() {
		return getPrimaryCollateral().getAddress().getState();
	}

	public void setPrimaryStateCode(String stateCode) {
		getPrimaryCollateral().getAddress().setState(stateCode);
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public boolean isSendAndContinueStatus() {
		return sendAndContinueStatus;
	}

	public void setSendAndContinueStatus(boolean sendAndContinueStatus) {
		this.sendAndContinueStatus = sendAndContinueStatus;
	}
	public String getLobEmailSendFlag() {
		return lobEmailSendFlag;
	}

	public void setLobEmailSendFlag(String lobEmailSendFlag) {
		this.lobEmailSendFlag = lobEmailSendFlag;
	}

	public String getPrimaryLoanNumber() {
		return getPrimaryCollateral().getPrimaryLoan().getLoanNumber();
	}

	public void setPrimaryLoanNumber(String loanNumber) {
		getPrimaryCollateral().getPrimaryLoan().setLoanNumber(loanNumber);
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getPrimaryCity() {
		return getPrimaryCollateral().getAddress().getCity();
	}

	public void setPrimaryCity(String city) {
		getPrimaryCollateral().getAddress().setCity(city);
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPrimaryState() {
		return getPrimaryCollateral().getAddress().getState();
	}

	public void setPrimaryState(String state) {
		getPrimaryCollateral().getAddress().setState(state);
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public String getPrimaryZipcode() {
		return getPrimaryCollateral().getAddress().getZipCode();
	}

	public void setPrimaryZipcode(String zipcode) {
		getPrimaryCollateral().getAddress().setZipCode(zipcode);
	}

	public int getSlaTimer() {
		return slaTimer;
	}

	public void setSlaTimer(int slaTimer) {
		this.slaTimer = slaTimer;
	}

	public int getSlaDaysRemaining() {
		return slaDaysRemaining;
	}

	public void setSlaDaysRemaining(int slaDaysRemaining) {
		this.slaDaysRemaining = slaDaysRemaining;
	}
	
	public String getCompletionFlag() {
		return completionFlag;
	}

	public void setCompletionFlag(String completionFlag) {
		this.completionFlag = completionFlag;
	}

	public MultipartFile getSFHDF() {
		return SFHDF;
	}

	public void setSFHDF(MultipartFile sFHDF) {
		SFHDF = sFHDF;
	}
	
	
	public String getFloodZoneStatus() {
		return floodZoneStatus;
	}

	public void setFloodZoneStatus(String floodZoneStatus) {
		this.floodZoneStatus = floodZoneStatus;
	}

	public String getSFHDFDisplayName(){
		
		if(this.SFHDF!=null && !this.SFHDF.isEmpty()){
			return this.SFHDF.getOriginalFilename();
		}
		return "The SFHDF is missing";
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}
	
	protected Set <String> getAllOptionsAsSetFromList( List<LookUpCode> input, String accessKeyType ){
		SortedSet <String> response = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		if(input!=null){
			for(LookUpCode entry :input ){
				if("description".equalsIgnoreCase(accessKeyType)){
					response.add(entry.getDescription());
				}
				if("code".equalsIgnoreCase(accessKeyType)){
					response.add(entry.getCode());
				}
				//TODO need more?
			}
		}
		return response;
	}
	
	protected Set <String> getAllOptionsAsLinkedHashSetFromList( List<LookUpCode> input, String accessKeyType ){
		Set <String> response = new LinkedHashSet<String>();
		if(input!=null){
			for(LookUpCode entry :input ){
				if("description".equalsIgnoreCase(accessKeyType)){
					response.add(entry.getDescription());
				}
				if("code".equalsIgnoreCase(accessKeyType)){
					response.add(entry.getCode());
				}
				//TODO need more?
			}
		}
		return response;
	}
	protected LookUpCode getFieldEntryFormSet(List<LookUpCode> input, String accessKeyType, String keyValue){
		
		if(input!=null && !StringUtils.isBlank(keyValue)){
			for(LookUpCode entry :input ){
				if("description".equalsIgnoreCase(accessKeyType)){
					if(keyValue.equals(entry.getDescription()) )
						return entry;
				}
				if("code".equalsIgnoreCase(accessKeyType)){
					if(keyValue.equals(entry.getCode()) )
						return entry;
				}
				//TODO need more?
			}
		}
		return null;
	}
	
	
	
	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public String getLpiType() {
		return lpiType;
	}

	public void setLpiType(String lpiType) {
		this.lpiType = lpiType;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}
	
	public String getReminderTypeDesc() {
	    if (renewalData != null) {
	    	LookupCodeRepository lookupCodeRepository = ApplicationContextProvider.getContext().getBean(LookupCodeRepository.class);
	        List<LookUpCode> reminderTypes = lookupCodeRepository.findByCodeSet(REMINDER_TYPES);
	        for (LookUpCode rt : reminderTypes) {
	            if (rt.getCode().equals(renewalData.getReminderType())) {
	                return rt.getDescription();
	            }
	        }
	    }
		return null;
	}
	
    public String getReminderType() {
        if (renewalData != null) {
            return renewalData.getReminderType();
        }
        return null;
    }
    
    public void setReminderType(String reminderType) {
        if (renewalData == null) {
        	renewalData = new FloodRenewalData();
        }
        renewalData.setReminderType(reminderType);
    }
	
    @Override
	public String toString() {
	    return ReflectionToStringBuilder.toString(this);
	}
}
