package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.BatchExitStatus.RECON_ALL_SUCCESSFUL;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.BatchExitStatus.RECON_FAILLED_TO_RECONCILE;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.BatchExitStatus.RECON_NO_ACTION_TAKEN;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.BatchExitStatus.RECON_PARTIALLY_FAIL;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracReconcilable;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReconciliationLog;
import com.jpmorgan.cib.wlt.ctrac.dao.tm.model.TMReconciliationView;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ReconcilationResult;

@Component
public class ReconcilationUtil {
	
	private static final Logger logger = Logger.getLogger(ReconcilationUtil.class);
	private static Format formatter_timesatamp = new SimpleDateFormat("yyyy-MM-dd HH24:mm:ss");
	private static Format formatter_date = new SimpleDateFormat("yyyy-MM-dd");
	private int inputCount = 0;
	private int rejectedCount= 0;
	private int processedCount= 0;
	private int exceptionCount= 0;
		
	/**
	 * Creates the list of all mismatches between the source and target list
	 * objects based on the metadata parameter.
	 * 
	 * @param sourceList
	 * @param targetList
	 * @param targetList 
	 * @param fieldMetadata
	 * @return
	 */
	public List<ReconcilationResult> getReconcilationResult(
			List<? extends CtracReconcilable> sourceList,
			List<? extends CtracReconcilable> combinedSourceTaskList, List<TMReconciliationView> targetList, String[][] fieldMetadata) {		
		logger.debug("getReconcilationResult::START");
		CtracReconcilable sourceDto;
		CtracReconcilable targetDto;
		List<ReconcilationResult> listOutput= new ArrayList<>();
		Iterator<? extends CtracReconcilable> itrSource = sourceList.iterator();
		inputCount += sourceList.size();
		rejectedCount = 0;
		while(itrSource.hasNext())
		{
			sourceDto = itrSource.next();
			targetDto = getTargetElemById(sourceDto.getGenericId(), targetList);		
			List<ReconcilationResult> listDifferences = getReconcilationDetails(sourceDto,targetDto,fieldMetadata);
			listOutput.addAll(listDifferences);		
			processedCount += 1;
		}
		Iterator<? extends CtracReconcilable> itrTarget = targetList.iterator();
		while(itrTarget.hasNext())
		{
			targetDto = itrTarget.next();
			sourceDto = getTargetElemById(targetDto.getGenericId(), combinedSourceTaskList);		
			List<ReconcilationResult> listDifferences = checkForAvailableInTarget(targetDto, sourceDto,fieldMetadata);
			listOutput.addAll(listDifferences);					
		}
		logger.debug("getReconcilationResult::END");
		return listOutput;		
	}
	
	/**
	 * Creates a list of mismatches between source and target object based on
	 * the fields present in metadata.
	 * 
	 * @param targetObj
	 * @param sourceObj
	 * @param fieldMetadata
	 * @return
	 */
	private List<ReconcilationResult> checkForAvailableInTarget(
			CtracReconcilable targetObj, CtracReconcilable sourceObj,
			String[][] fieldMetadata) {
		logger.debug("getReconcilationDetails::START");
		Field targetField;
		List<ReconcilationResult> listOut =  new ArrayList<ReconcilationResult>();
		int length =  fieldMetadata.length;
		try {
			for (int i = 0; i < length; i++) {
				if (targetObj == null) {
					logger.info("Source object has no value. Process of matching with target will be skipped.");
					continue;
				}
				targetField = targetObj.getClass().getDeclaredField(
						fieldMetadata[i][2]);
				targetField.setAccessible(true);
				if (i == 0 && sourceObj == null) {
					// Special handling for the ID field for no source
					listOut.add(new ReconcilationResult(targetObj
							.getGenericId(), fieldMetadata[i][0], "No Matching Record Found" , targetObj
							.getGenericId()));
					break;
				}			
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0151", CtracErrorSeverity.CRITICAL));
		}
		logger.debug("getReconcilationDetails::END");
		if(!CollectionUtils.isEmpty(listOut)){
			exceptionCount += 1;
		}
		return listOut;
	}

	/**
	 * Creates a list of mismatches between source and target object based on
	 * the fields present in metadata.
	 * 
	 * @param sourceObj
	 * @param targetObj
	 * @param fieldMetadata
	 * @return
	 */
	private List<ReconcilationResult> getReconcilationDetails(
			CtracReconcilable sourceObj, CtracReconcilable targetObj,
			String[][] fieldMetadata) {
		logger.debug("getReconcilationDetails::START");
		Field sourceField;
		Field targetField = null;		
		List<ReconcilationResult> listOut =  new ArrayList<ReconcilationResult>();
		int length =  fieldMetadata.length;
		try {
			for (int i = 0; i < length; i++) {
				if (sourceObj == null) {
					logger.info("Source object has no value. Process of matching with target will be skipped.");
					continue;
				}
				sourceField = sourceObj.getClass().getDeclaredField(
						fieldMetadata[i][1]);
				sourceField.setAccessible(true);
				if (i == 0 && targetObj == null) {
					// Special handling for the ID field for no target
					listOut.add(new ReconcilationResult(sourceObj
							.getGenericId(), fieldMetadata[i][0], sourceObj
							.getGenericId(), "No Matching Record Found"));
					break;
				}				
				sourceObj.fillTransientVariables();
				targetObj.fillTransientVariables();
				targetField = targetObj.getClass().getDeclaredField(
						fieldMetadata[i][2]);
				targetField.setAccessible(true);
				if ("STRING".equals(fieldMetadata[i][3])) {
					reconcileStringData(sourceObj, targetObj, fieldMetadata,sourceField, targetField, listOut, i);
				} else if ("TIMESTAMP".equals(fieldMetadata[i][3])) {
					reconcileTimestampData(sourceObj, targetObj, fieldMetadata,sourceField, targetField, listOut, i);
				} else if ("DATE".equals(fieldMetadata[i][3])) {
					reconcileDateData(sourceObj, targetObj, fieldMetadata,sourceField, targetField, listOut, i);
				}
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0151", CtracErrorSeverity.CRITICAL));
		}
		logger.debug("getReconcilationDetails::END");
		if(!CollectionUtils.isEmpty(listOut)){
			exceptionCount += 1;
		}
		return listOut;
	}

	private void reconcileDateData(CtracReconcilable sourceObj,
			CtracReconcilable targetObj, String[][] fieldMetadata,
			Field sourceField, Field targetField,
			List<ReconcilationResult> listOut, int i)
			throws IllegalAccessException {
		String strSourceValue;
		String strTargetValue;
		Date dteSourceValue;
		Date dteTargetValue;
		dteSourceValue = (Date) sourceField.get(sourceObj);
		strSourceValue = formatter_date.format(dteSourceValue); 
		if (targetField == null) {
			listOut.add(new ReconcilationResult(sourceObj
					.getGenericId(), fieldMetadata[i][0],
					strSourceValue, ""));

		} else {					
				dteTargetValue = (Date) targetField.get(targetObj);		
				strTargetValue = formatter_date.format(dteTargetValue);
				if (!strSourceValue.equals(strTargetValue) ) {
				listOut.add(new ReconcilationResult(sourceObj.getGenericId(), fieldMetadata[i][0],  strSourceValue, strTargetValue ));
			}
		}
	}

	private void reconcileTimestampData(CtracReconcilable sourceObj,
			CtracReconcilable targetObj, String[][] fieldMetadata,
			Field sourceField, Field targetField,
			List<ReconcilationResult> listOut, int i)
			throws IllegalAccessException {
		String strSourceValue;
		String strTargetValue;
		Date dteSourceValue;
		Date dteTargetValue;
		dteSourceValue = (Date) sourceField.get(sourceObj);
		strSourceValue = formatter_timesatamp.format(dteSourceValue);
		if (targetField == null) {
			listOut.add(new ReconcilationResult(sourceObj.getGenericId(),
					fieldMetadata[i][0], strSourceValue, ""));

		} else {
			dteTargetValue = (Date) targetField.get(targetObj);
			strTargetValue = formatter_timesatamp.format(dteTargetValue);
			if (!strSourceValue.equals(strTargetValue)) {
				listOut.add(new ReconcilationResult(sourceObj.getGenericId(),fieldMetadata[i][0], strSourceValue, strTargetValue));
			}
		}
	}

	private void reconcileStringData(CtracReconcilable sourceObj,
			CtracReconcilable targetObj, String[][] fieldMetadata,
			Field sourceField, Field targetField,
			List<ReconcilationResult> listOut, int fieldNamePosition)
			throws IllegalAccessException {
		String strSourceValue;
		String strTargetValue;
		strSourceValue = (String) sourceField.get(sourceObj);		
		if (strSourceValue == null) {
			strSourceValue = "";
		}
		strSourceValue = convertMultiLine(strSourceValue);		
		strTargetValue = (String) targetField.get(targetObj);		
		if (strTargetValue == null) {
			strTargetValue = "";
		}
		strTargetValue = convertMultiLine(strTargetValue);
		if (!strSourceValue.trim().equals(strTargetValue.trim())) {
			listOut.add(new ReconcilationResult(sourceObj.getGenericId(),fieldMetadata[fieldNamePosition][0], strSourceValue, strTargetValue));
		}
	}
	
	private String convertMultiLine(String multiLine){
		String returnStr =  multiLine.replaceAll(CtracAppConstants.LINE_SEPERATOR_WINDOWS, "");
		returnStr = returnStr.replaceAll(CtracAppConstants.LINE_SEPERATOR_UNIX, "");		
		return returnStr;
	}

	/**
	 * Finds the first element in the target list with matching sourceId 
	 * @param genericSourceId
	 * @param tmNewItemList
	 * @return
	 */
	private CtracReconcilable getTargetElemById(String genericSourceId,
			List<? extends CtracReconcilable> tmNewItemList) {
		Iterator<? extends CtracReconcilable> itrTarget = tmNewItemList.iterator();
		CtracReconcilable targetDto = null;
		while(itrTarget.hasNext())
		{
			targetDto = itrTarget.next();
			if(targetDto.getGenericId().equals(genericSourceId)){
				return targetDto;
			}
			targetDto = null;
		}
		logger.debug("getTargetElemById::END");
		return targetDto;
	}
	
	
	/**
     * Prepares the Reconcilation Report xlsx file with reconcilation difference data.
     * @param reconciliationResults
     * @param headerValues
     * @param reportName
     * @param tabName
     * @return
     */
    public File prepareReconciliationReport(List<ReconcilationResult> reconciliationResults, String[] headerValues, String reportName, String tabName) {
    	logger.debug("prepareReconciliationReport::START");
    	if(reconciliationResults == null || reconciliationResults.isEmpty()) {
    		logger.debug("prepareReconciliationReport::END");
    		return null;
    	}
		File reconFile = new File(reportName);
		try(FileOutputStream fos = new FileOutputStream(reconFile);
			XSSFWorkbook errorWorkbook = new XSSFWorkbook()){
			Sheet sheet = errorWorkbook.createSheet(tabName);
			ReconcilationResult reconciliationResult;
			Row row;
			Cell cell;
			createErrorFileHeader(sheet,errorWorkbook, headerValues);
			int rowIndex = 1;
			Iterator<ReconcilationResult> rowIterator = reconciliationResults.iterator();
			while(rowIterator.hasNext()){
				reconciliationResult = rowIterator.next();
				row = sheet.createRow(rowIndex++);
				cell = row.createCell(0);
				cell.setCellValue(reconciliationResult.getId());
				cell = row.createCell(1);
				cell.setCellValue(reconciliationResult.getFieldName());
				cell = row.createCell(2);
				cell.setCellValue(reconciliationResult.getSourceValue());
				cell = row.createCell(3);
				cell.setCellValue(reconciliationResult.getTargetValue());
			}
			errorWorkbook.write(fos);
			logger.debug("prepareReconciliationReport::END");
			return reconFile;
		}catch(Exception ex) {
			logger.error(ex.getMessage(), ex);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0139", CtracErrorSeverity.APPLICATION));
		}
    	logger.debug("prepareReconciliationReport::END");
		return null;	
	}
    
    
	/**
	 * Creates the HEADER row for report xlsx file,this file will
     * be sent to AD/PO as an attachment with reconcilation Mismatch records found 
     * while reconciling any two systems.
	 * @param sheet
	 * @param workbook
	 * @param headerValues
	 */
	private void createErrorFileHeader(Sheet sheet, Workbook workbook, String[] headerValues) {
		logger.debug("createErrorFileHeader::START");
		XSSFFont font = (XSSFFont)workbook.createFont();
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		XSSFCellStyle style = (XSSFCellStyle)workbook.createCellStyle();
		style.setFont(font);		
		//create the xlsx file HEADER row
		Row row = sheet.createRow(0);
		for(int i=0;i<headerValues.length;i++){
			Cell cell = row.createCell(i);
	        cell.setCellValue(headerValues[i]);
	        cell.setCellStyle(style);
		}
		logger.debug("createErrorFileHeader::END");
	}
	
	public ReconciliationLog getReconciliationLog (){
		ReconciliationLog reconciliationLog =  new ReconciliationLog();		
		reconciliationLog.setProcessedTimestamp(new Date());
		reconciliationLog.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);
		reconciliationLog.setInputCount(getInputCount());
		reconciliationLog.setProcessedCount(getProcessedCount());
		reconciliationLog.setRejectedCount(getRejectedCount());
		
		if( ((getProcessedCount() < getInputCount() )) ){
			reconciliationLog.setExitLog(RECON_FAILLED_TO_RECONCILE.getStatusDescription() +"Exception record count: "+getExceptionCount());
			reconciliationLog.setGlobalExitStatus(RECON_FAILLED_TO_RECONCILE.name());
		}
		else{
			//Since we are validating, we expect exceptionRecordsCnt to be zero unless something weird happened
			if(getExceptionCount() > 0 ){
				reconciliationLog.setExitLog(RECON_PARTIALLY_FAIL.getStatusDescription() +"Exception record count: "+getExceptionCount());
				reconciliationLog.setGlobalExitStatus(RECON_PARTIALLY_FAIL.name());
			}else if(reconciliationLog.getInputCount() == 0){
				reconciliationLog.setExitLog(RECON_NO_ACTION_TAKEN.getStatusDescription());
				reconciliationLog.setGlobalExitStatus(RECON_NO_ACTION_TAKEN.name());
			}else{
				reconciliationLog.setExitLog(RECON_ALL_SUCCESSFUL.getStatusDescription());
				reconciliationLog.setGlobalExitStatus(RECON_ALL_SUCCESSFUL.name());
			}
		}			
		return reconciliationLog;
	}
	
	private int getInputCount() {
		return inputCount;
	}

	private int getProcessedCount() {
		return processedCount;
	}

	public int getExceptionCount() {
		return exceptionCount;
	}
	public int getRejectedCount() {
		return rejectedCount;
	}

}
