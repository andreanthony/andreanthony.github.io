package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.ReminderType;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

import javax.validation.Valid;

public class ContactAgentDto extends CtracBaseHelperData {

	private static final long serialVersionUID = 1L;

	private EmailAttributeHolder emailAttributeHolder;
	
	private String emailStaticContent;

	private String isCallPlacedForAgent;
	
	private String callPlacedDate;

	private String pageTitle;
	
	private List<LoanData> loanDtoList;

	@Valid
	private ProofOfCoverageDTO proofOfCoverageDto;
	
	private List<CollateralDto> collateralDtoList; 
	
	private ReminderType reminderType;
	 
	public String getIsCallPlacedForAgent() {
		return isCallPlacedForAgent;
	}

	public void setIsCallPlacedForAgent(String isCallPlacedForAgent) {
		this.isCallPlacedForAgent = isCallPlacedForAgent;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	public String getEmailStaticContent() {
		return emailStaticContent;
	}

	public void setEmailStaticContent(String emailStaticContent) {
		this.emailStaticContent = emailStaticContent;
	}

	public String getCallPlacedDate() {
		return callPlacedDate;
	}

	public void setCallPlacedDate(String callPlacedDate) {
		this.callPlacedDate = callPlacedDate;
	}


	public EmailAttributeHolder getEmailAttributeHolder() {
		return emailAttributeHolder;
	}

	public void setEmailAttributeHolder(EmailAttributeHolder emailAttributeHolder) {
		this.emailAttributeHolder = emailAttributeHolder;
	}

	public List<LoanData> getLoanDtoList() {
		return loanDtoList;
	}

	public void setLoanDtoList(List<LoanData> loanDtoList) {
		this.loanDtoList = loanDtoList;
	}

	public ProofOfCoverageDTO getProofOfCoverageDto() {
		return proofOfCoverageDto;
	}

	public void setProofOfCoverageDto(ProofOfCoverageDTO proofOfCoverageDto) {
		this.proofOfCoverageDto = proofOfCoverageDto;
	}

	public List<CollateralDto> getCollateralDtoList() {
		return collateralDtoList;
	}

	public void setCollateralDtoList(List<CollateralDto> collateralDtoList) {
		this.collateralDtoList = collateralDtoList;
	}

	public ReminderType getReminderType() {
		return reminderType;
	}

	public void setReminderType(ReminderType reminderType) {
		this.reminderType = reminderType;
	}

}
