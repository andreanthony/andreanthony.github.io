package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import java.util.Date;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

public class CoverageActionRequest {

    private InsuranceType insuranceType = InsuranceType.FLOOD;
    private final Long collateralId;
    private final Long triggerWorkItemId; 
    private final List<ProofOfCoverageDTO> proofOfCoveragePendingReviews;
    private final Long cancelledRorrowerProofOfCoverageRid;
    private final ProofOfCoverage triggerProofOfCoverage;
    private final Date overrideCalculatedDate;

	public CoverageActionRequest (Long collateralId,Long triggerWorkItemId, List<ProofOfCoverageDTO> proofOfCoveragePendingReviews){
        this.collateralId        = collateralId;
        this.triggerWorkItemId   = triggerWorkItemId;
        this.proofOfCoveragePendingReviews = proofOfCoveragePendingReviews;
        this.cancelledRorrowerProofOfCoverageRid = null;
        this.triggerProofOfCoverage = null;
        this.overrideCalculatedDate = null;
    }

    public CoverageActionRequest (Long collateralId,Long triggerWorkItemId, List<ProofOfCoverageDTO> proofOfCoveragePendingReviews, Long cancelledRorrowerProofOfCoverageRid){
        this.collateralId        = collateralId;
        this.triggerWorkItemId   = triggerWorkItemId;
        this.proofOfCoveragePendingReviews = proofOfCoveragePendingReviews;
        this.cancelledRorrowerProofOfCoverageRid = cancelledRorrowerProofOfCoverageRid;
        this.triggerProofOfCoverage = null;
        this.overrideCalculatedDate = null;
    }

    public CoverageActionRequest (Long collateralId,Long triggerWorkItemId, List<ProofOfCoverageDTO> proofOfCoveragePendingReviews, ProofOfCoverage triggerProofOfCoverage){
        this.collateralId        = collateralId;
        this.triggerWorkItemId   = triggerWorkItemId;
        this.proofOfCoveragePendingReviews = proofOfCoveragePendingReviews;
        this.cancelledRorrowerProofOfCoverageRid = null;
        this.triggerProofOfCoverage = triggerProofOfCoverage;
        this.overrideCalculatedDate = null;
    }

    public CoverageActionRequest(Long collateralId, Date overrideCalculatedDate) {
        this.collateralId        = collateralId;
        this.triggerWorkItemId   = null;
        this.proofOfCoveragePendingReviews = null;
        this.cancelledRorrowerProofOfCoverageRid = null;
        this.triggerProofOfCoverage = null;
        this.overrideCalculatedDate = overrideCalculatedDate;
    }

    /**
     * @return the insuranceType
     */
    public InsuranceType getInsuranceType() {
        return insuranceType;
    }


    /**
     * @param insuranceType the insuranceType to set
     */
    public void setInsuranceType(InsuranceType insuranceType) {
        this.insuranceType = insuranceType;
    }



    /**
	 * @return the collateralId
	 */
	public Long getCollateralId() {
		return collateralId;
	}


	/**
     * @return the triggerWorkItemId
     */
    public Long getTriggerWorkItemId() {
        return triggerWorkItemId;
    }
    
    /**
     * @return the proofOfCoveragePendingReviews
     */
    public List<ProofOfCoverageDTO> getProofOfCoveragePendingReviews() {
        return proofOfCoveragePendingReviews;
    }
    /**
     * @return the cancelledRorrowerProofOfCoverageRid
     */
    public Long getCancelledRorrowerProofOfCoverageRid() {
		return cancelledRorrowerProofOfCoverageRid;
	}

	public ProofOfCoverage getTriggerProofOfCoverage() {
		return triggerProofOfCoverage;
	}

    public Date getOverrideCalculatedDate() {
        return overrideCalculatedDate;
    }

    /* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CoverageActionRequest [insuranceType=");
		builder.append(insuranceType);
		builder.append(", collateralId=");
		builder.append(collateralId);
		builder.append(", triggerWorkItemId=");
		builder.append(triggerWorkItemId);
		builder.append(", proofOfCoveragePendingReviews=");
		builder.append(proofOfCoveragePendingReviews);
		builder.append(", cancelledRorrowerProofOfCoverageRid=");
		builder.append(cancelledRorrowerProofOfCoverageRid);
        builder.append(", overrideCalculatedDate=");
        builder.append(overrideCalculatedDate);
		builder.append("]");
		return builder.toString();
	}
    
    

}
