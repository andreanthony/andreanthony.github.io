package com.jpmorgan.cib.wlt.ctrac.service.batch;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Set;

public abstract class ExcelFileUtil {
    private static final String DOLLAR_SYMBOL = "$";
    private static final int MAX_COLUMN_SIZE = 20;
    private static final byte[] GREY = {(byte) 217, (byte) 217, (byte) 217};
    @Resource
    protected Environment env;
    @Autowired
    protected CtracObjectMapper ctracObjectMapper;

    protected void setDefaultUnlock(Sheet sheet, int columnCount) {
        CellStyle editableStyle = sheet.getWorkbook().createCellStyle();
        editableStyle.setLocked(false);
        for (int i = 0; i < columnCount; i++) {
            sheet.setDefaultColumnStyle(i, editableStyle);
        }
    }

    protected CellStyle getLockedCellStyle(XSSFWorkbook lpWorkbook) {
        CellStyle cellStyle = lpWorkbook.createCellStyle();
        setThreeThinBorder(cellStyle);
        cellStyle.setLocked(true);
        return cellStyle;
    }

    protected XSSFCellStyle getHeaderCellStyle(XSSFWorkbook workbook) {
        XSSFCellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        cellStyle.setLocked(false);
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        cellStyle.setFont(font);
        return cellStyle;
    }

    protected CellStyle getDateCellStyle(XSSFWorkbook workbook) {
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setLocked(false);
        CreationHelper createHelper = workbook.getCreationHelper();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
        setThreeThinBorder(dateCellStyle);
        return dateCellStyle;
    }

    private void setThreeThinBorder(CellStyle dateCellStyle) {
        dateCellStyle.setBorderLeft(BorderStyle.THIN);
        dateCellStyle.setBorderRight(BorderStyle.THIN);
        dateCellStyle.setBorderBottom(BorderStyle.THIN);
    }

    protected CellStyle getStringCellStyle(XSSFWorkbook workbook) {
        CellStyle stringCellStyle = workbook.createCellStyle();
        stringCellStyle.setLocked(false);
        setThreeThinBorder(stringCellStyle);
        return stringCellStyle;
    }

    protected CellStyle getAutoWrapCellStyle(XSSFWorkbook workbook) {
        CellStyle autoWrapCellStyle = workbook.createCellStyle();
        autoWrapCellStyle.setLocked(false);
        autoWrapCellStyle.setWrapText(true);
        setThreeThinBorder(autoWrapCellStyle);
        return autoWrapCellStyle;
    }

    protected CellStyle getAmountCellStyle(XSSFWorkbook workbook) {
        CellStyle amountCellStyle = workbook.createCellStyle();
        amountCellStyle.setAlignment(HorizontalAlignment.RIGHT);
        amountCellStyle.setVerticalAlignment(VerticalAlignment.BOTTOM);
        amountCellStyle.setDataFormat(workbook.createDataFormat().getFormat("#,##0.00"));
        amountCellStyle.setLocked(false);
        setThreeThinBorder(amountCellStyle);
        return amountCellStyle;
    }

    /**
     * 	Auto size the columns except for column G and L which I would set to 75.
        Set columns G and L to wrap the data.  These columns could contain long string of data and could wrap several rows.
        Auto size the rows to allow for cases where the data wrap in column G and L.
     * @param sheet
     * @param columnsNotAutoSize
     */

    protected void adjustColumn(XSSFSheet sheet, int columnCount, Set<Integer> columnsNotAutoSize){
        for(int i = 0; i < columnCount; i++){
            if(columnsNotAutoSize.contains(i)){
                sheet.setColumnWidth(i, 75 * 256);
            }
            else{
                sheet.autoSizeColumn(i);
            }
        }
    }

    protected void setAutoSizeColumn(XSSFWorkbook workbook, Sheet sheet) {
        XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
        for (int i = 0; i < MAX_COLUMN_SIZE; i++) {
            // sheet.autoSizeColumn((short)i);
        }
    }

    protected String isValidString(String lpRequestAttr) {
        if(lpRequestAttr == null){
            lpRequestAttr = "";
        }
        return lpRequestAttr;
    }

    protected String isValidAmountString(String lpRequestAttr) {
        if(lpRequestAttr == null || lpRequestAttr.isEmpty()){
            return DOLLAR_SYMBOL + CtracAppConstants.DEFAULT_AMOUNT;
        }
        BigDecimal amount = new BigDecimal(lpRequestAttr.replaceAll(",", ""));
        lpRequestAttr = DOLLAR_SYMBOL + AmountFormatter.format(amount);
        return lpRequestAttr;
    }

    protected XSSFCellStyle createTableHeaader(XSSFWorkbook lpWorkbook) {
		XSSFCellStyle headerCellStyle = getHeaderCellStyle(lpWorkbook);
		headerCellStyle.setBorderTop(BorderStyle.MEDIUM);
		headerCellStyle.setBorderBottom(BorderStyle.MEDIUM);
		headerCellStyle.setFillForegroundColor(new XSSFColor(GREY));
		headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
		headerCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
		return headerCellStyle;
	}
}
