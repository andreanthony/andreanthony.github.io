package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;

public class ExpirationDateRuleWorker extends AbstractBIRRuleWorker {

	public ExpirationDateRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRRuleConclusionDTO expirationDateConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get(key);
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if (expirationDateIsTodayOrInFuture(borrowerInsuranceReviewData)) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
		}
		expirationDateConclusion.setConclusion(birConclusion.name());
	}
	
	private boolean expirationDateIsTodayOrInFuture(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		try {
			String expirationDateString = borrowerInsuranceReviewData.getProofOfCoverageData().getExpirationDate();
			if (StringUtils.isBlank(expirationDateString)) {
				return false;
			}
			CalendarDayUtil calendarDayUtil = ApplicationContextProvider.getContext().getBean(CalendarDayUtil.class);
			DateTime currentReferenceDate = new DateTime(calendarDayUtil.getCurrentReferenceDate());
			DateTime expirationDate = new DateTime(DateConverter.convert(expirationDateString));
			return !expirationDate.withTimeAtStartOfDay().isBefore(currentReferenceDate.withTimeAtStartOfDay());
		} catch (Exception e) {
			return false;
		}
	}

}
