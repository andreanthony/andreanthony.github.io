package com.jpmorgan.cib.wlt.ctrac.service.insurableasset;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.HoldDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.HoldStatusDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.HoldHistoryViewDto;

import java.util.Collection;
import java.util.Date;
import java.util.List;


public interface HoldService {
	Collateral processHold(Collection<RequiredCoverageDTO> requiredCoverageDtos, Long collateralRid) throws Exception;

	HoldStatusDto prepareHoldHelperData(TMParams tmParams, String janusUserId);

	void processUpdateHoldStatus(HoldStatusDto holdStatusDto);

    Collection<HoldHistoryViewDto> getHoldHistory(Long collateralRid);

    Date getHoldPeriodExpirationDate(String startDate, String holdPeriod);

    List<HoldDetailsViewDto> getHoldDetailsViewDtos(WorkItem triggerworkItem);
}
