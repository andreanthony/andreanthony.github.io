package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;


public class AmendTMTaskCommand extends AbstractCommand {
	
	private final PerfectionTask perfectionTask;
	private static final Logger logger = Logger.getLogger(AmendTMTaskCommand.class);
	
	/**
	 * 
	 */
	public AmendTMTaskCommand(PerfectionTask perfectionTask){
			this.perfectionTask = perfectionTask;
			this.priority=0;
	}
	
	/**
	 * 
	 */
	public AmendTMTaskCommand(PerfectionTask perfectionTask, int priotity){
			this.perfectionTask = perfectionTask;
			this.priority = priotity;
	}
	
	
	@Override
	public void execute() {
		//TODO handle bean not found exceptions
		TMService tmService=  (TMService) ApplicationContextProvider.getContext().getBean("TMService");
		if (perfectionTask != null) {
			try {
				tmService.amendTask(perfectionTask);
			} catch (Exception swallow) {
				logger.error("Error amending TM task: " + perfectionTask.getTmTaskId());
			}
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((perfectionTask == null) ? 0 : perfectionTask.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmendTMTaskCommand other = (AmendTMTaskCommand) obj;
		if (perfectionTask == null) {
			if (other.perfectionTask != null)
				return false;
		}
		else if (!perfectionTask.equals(other.perfectionTask))
			return false;
		return true;
	}




}
