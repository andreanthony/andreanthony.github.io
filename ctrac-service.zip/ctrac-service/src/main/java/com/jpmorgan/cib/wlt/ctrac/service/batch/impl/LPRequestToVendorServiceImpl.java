package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.file.FileWriterUtility;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LPPolicyRequestViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.QueuedForAlthansViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AlthansBatchItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LPPolicyRequestRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LPPolicyRequestViewDataRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.QueuedForAlthansViewDataRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AlthansBatchItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.LenderPlaceItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.EscrowProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.*;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.File;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.*;




@Service(value = "lPRequestToVendorService")
public class LPRequestToVendorServiceImpl implements LPRequestToVendorService {

	private static final Logger logger = LoggerFactory.getLogger(LPRequestToVendorServiceImpl.class);

	public static final Set<String> WORKFLOW_STEPS = new HashSet<>();
	static {
		WORKFLOW_STEPS.add(WorkflowStateDefinition.QUEUE_FOR_ALTHANS.getName());
	}
	
	@Autowired protected TaskService taskService;
	@Autowired private AlthansBatchItemRepository althansBatchItemRepository;
	@Autowired private PerfectionTaskService perfectionTaskService;
	@Autowired private LPPolicyRequestViewDataRepository lpPolicyRequestViewDataRepository;
	@Autowired private LPPolicyRequestRepository lPPolicyRequestRepository;
	@Autowired private CtracObjectMapper ctracObjectMapper;
	@Autowired private BusinessDayUtil businessDayUtil;
	@Autowired private LPInsuranceRequestUtil lpInsuranceRequestUtil;
	@Resource  private Environment env;	
	@Autowired private LookupCodeRepository lookupCodeRepository;
	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;
	@Autowired private EmailNotificationService emailNotificationService;
	@Autowired private ActivePolicyService activePolicyService;
	@Autowired private FileWriterUtility fileUtility;
	@Autowired private LenderPlaceItemRepository lenderPlaceItemRepository;
	@Autowired private LPVendorFileGeneratorFactory lpVendorFileGeneratorFactory;
	@Autowired private QueuedForAlthansViewDataRepository queuedForAlthansViewDataRepository;
	@Autowired private CLSEmailService clsEmailService;
	@Autowired private ReconEmailService reconEmailService;
	@Autowired private LineOfBusinessService lobService;
	@Autowired private LoanManagementService loanManagementService;
    @Autowired private EscrowProcessingService escrowProcessingService;
	
	@Autowired 
	private FloodEmailService floodEmailService;
	
	 /* (non-Javadoc)
	 * @see com.jpmorgan.cib.wlt.ctrac.service.batch.impl.LPRequestToVendorService#sendRequestToInsuranceVendor()
	 */
	
	@Override
	@Transactional
	public void sendRequestToInsuranceVendorAlthans() {
		try {
			logger.info("BEGIN::sendRequestToInsuranceVendorAlthans()");
			
			/**
			 *  1 - 
			 *  Load all policies with should be send to the insurance vendor Today
			 */
			Date refDate = businessDayUtil.getCurrentReferenceDate();
			List<QueuedForAlthansViewData> queuedForAlthans = queuedForAlthansViewDataRepository.findAll();

			List<LPPolicyRequest> lPPolicyRequestFile = new ArrayList<LPPolicyRequest>();
			Map<Long,String> requestTypeMap = new HashMap<Long,String>();
			
			if (queuedForAlthans == null || queuedForAlthans.isEmpty()) {
				logger.info("sendRequestToInsuranceVendorAlthans(): no policy found");
				clsEmailService.createAndSendNoTransactionEmail();
				reconEmailService.createAndSendNoTransactionEmail();
				queuedForAlthans = new ArrayList<QueuedForAlthansViewData>();
			} else {
				/**
				 * 2 -
				 * prepare & send the LP Insurance Request file to the vendor.
				 */
				populateLPPolicyRequestAlthans(lPPolicyRequestFile, queuedForAlthans);
				
				/**
				 * 3. transition tasks
				 * create a map from proofOfCoverageRid to requestType (by using lpPolicyRequestFile)
				 * loop through queuedForAlthans and call method to transition task
				 */
				for (LPPolicyRequest lpPolicyRequest : lPPolicyRequestFile) {
					requestTypeMap.put(lpPolicyRequest.getProofOfCoverage().getRid(), lpPolicyRequest.getTransCode());
				}
				for (QueuedForAlthansViewData queueForAlthansData : queuedForAlthans) {
					String requestType = requestTypeMap.get(queueForAlthansData.getProofOfCoverage().getRid());
					advanceAlthansWorkflow(queueForAlthansData, requestType, refDate);
				}
			}
			/**
			 * At last, send the file to the vendor; doing this last minimize the risk of rollback after file is sent to vendor
			 */
			sendLPEmailToAlthans(lPPolicyRequestFile);
			logger.debug("END::sendRequestToInsuranceVendorAlthans()");
		} catch(Exception e) {
			//Prepare and send an alert email in case of any failure while sending jason email.
			logger.error(e.getMessage(), e);
			sendInsuranceReqAlertEmail(e);
			throw new CTracApplicationException("E0170", CtracErrorSeverity.CRITICAL);
		}
	}
	
	void advanceAlthansWorkflow(QueuedForAlthansViewData queForAlthans, String requestType, Date sendDate) {
		LPVendorFileGenerator lpVendorFileGenerator =
				lpVendorFileGeneratorFactory.getLPVendorFileGeneratorFactory(LpInsuranceVendor.ALTHANS);
		ProofOfCoverage proofOfCoverage = queForAlthans.getProofOfCoverage();
		LenderPlaceItem lenderPlaceItem = proofOfCoverage.findLenderPlaceItem();
		if (lpVendorFileGenerator.isNewOrRenewalPolicyRequest(requestType)) {
			proofOfCoverage.setPolicyStatus(PolicyStatus.INVOICED.name());
			lenderPlaceItem.setLpSendDate(sendDate);
		} else if (lpVendorFileGenerator.getLpCancellationCode().equals(requestType)) {
			lenderPlaceItem.setCancellationRequestDate(sendDate);
		}
		proofOfCoverage = proofOfCoverageRepository.save(proofOfCoverage);
		lenderPlaceItem = lenderPlaceItemRepository.save(lenderPlaceItem);
		transitionToNextWorkFlow(queForAlthans.getPerfectionTask(), requestType);
	}

	void transitionToNextWorkFlow(final PerfectionTask perfectionTask, final String requestType) {
		Map<StateParameterType, Object> worflowData = new HashMap<StateParameterType, Object>() {
			private static final long serialVersionUID = 1L; {
				put(StateParameterType.WORKFLOW_STATE_ATTRIBUTES, requestType);
				put(StateParameterType.PERFECTION_TASK, perfectionTask);
		}};
		taskService.completeWorkFlowStepOperations(worflowData);
	}

	@Override
	@Transactional
	public void sendRequestToInsuranceVendor() {		
		try {
			logger.info("BEGIN::sendRequestToInsuranceVendor()");
			
			/**
			 *  1 - 
			 *  Load all policies with should be send to the insurance vendor Today
			 */
			List<ProofOfCoverage> proofOfCoverageList = proofOfCoverageRepository.findAllProofOfCoverageReadyForLpToday();
			
			List<LPPolicyRequest> lPPolicyRequestFile = new ArrayList<LPPolicyRequest>();

			if(proofOfCoverageList==null || proofOfCoverageList.isEmpty()){
				logger.info("sendRequestToInsuranceVendor(): no policy found");
				proofOfCoverageList = new ArrayList<ProofOfCoverage>();
			}
			else {
				/**
				 * 2 -
				 * prepare & send the LP Insurance Request file to the vendor.
				 */
				populateLPPolicyRequest(lPPolicyRequestFile, proofOfCoverageList) ;	
				
				
				/**
				 * 3
				 * transition the LP workflow tasks and mark the proof of coverage as processed
				 */
				for (ProofOfCoverage proofOfCoverage : proofOfCoverageList) {								
					LPActions lpAction = proofOfCoverage.getLpAction_();			
						/**
						 * if we are issuing a cancellation,  update the pending LP actions
						 */
						if(LPActions.CANCEL_LP == lpAction || proofOfCoverage.getCancellationEffectiveDate()!=null ){
							proofOfCoverage.setPolicyStatus(PolicyStatus.CANCELLED.name());
							activePolicyService.setAllPolicyStatuses(proofOfCoverage, PolicyStatus.CANCELLED);
						}
						 // TODO Remove: ----> should never happen; this is not needed and is  just to clean test data
						if(lpAction==null){
							proofOfCoverage.setLpTargetDate(null);
						}
						proofOfCoverage.setCancellationTargetDate(null);
						proofOfCoverage.setLpAction(LPActions.NO_ACTION.name());
						proofOfCoverageRepository.save(proofOfCoverage);
				
	
				}

			}
			/**
			 * At last, send the file to the vendor; doing this last minimize the risk of rollback after file is sent to vendor
			 */
			
			sendLPEmailToAssurant(lPPolicyRequestFile);
			logger.debug("END::sendRequestToInsuranceVendor()");
			
		} catch(Exception ex) {
			//Prepare and send an alert email in case of any failure while sending jason email.
			logger.error(ex.getMessage(), ex);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0170", CtracErrorSeverity.CRITICAL));
			sendInsuranceReqAlertEmail(ex); 
		}
		
	}


	void removeLpIssueWithCancellation(Collection<LPPolicyRequestViewData> lpPolicyViewDataList, List<ProofOfCoverage> proofOfCoverageList) {

		List<LPPolicyRequestViewData> viewDataIssuedWithCancellation = new ArrayList<LPPolicyRequestViewData>();
		List<ProofOfCoverage> proofOfCoverageIssuedWithCancellation = new ArrayList<ProofOfCoverage>();

		//find InsurableAssetRIDs for all LP_CANCEL requests in this file
		Collection<Long> cancellationRequests = getInsurableAssetsWithCancelation(lpPolicyViewDataList);

		List<Long> postponeIssueProofOfCoverageRids = new ArrayList<Long>();
		for (LPPolicyRequestViewData lpPolicyRequestViewData : lpPolicyViewDataList) {
			if(LPActions.CANCEL_LP != lpPolicyRequestViewData.getProofOfCoverage().getLpAction_() && 
					cancellationRequests.contains(lpPolicyRequestViewData.getInsurableAssetRid())) {
				//found LP policy to issue after another one is cancelled for the same  InsurableAssetRID in the same file
				viewDataIssuedWithCancellation.add(lpPolicyRequestViewData);
				postponeIssueProofOfCoverageRids.add(lpPolicyRequestViewData.getProofOfCoverage().getRid());
			}			
		}
		lpPolicyViewDataList.removeAll(viewDataIssuedWithCancellation);		
		
		// repeat for proofOfCoverageList		
		for (ProofOfCoverage proofOfCoverage : proofOfCoverageList) {
			if(postponeIssueProofOfCoverageRids.contains(proofOfCoverage.getRid())) {
				
				proofOfCoverageIssuedWithCancellation.add(proofOfCoverage);
			}			
		}
		proofOfCoverageList.removeAll(proofOfCoverageIssuedWithCancellation);
		
	}
	
	private void populateLPPolicyRequest(List<LPPolicyRequest> lpPolicyRequestList, List<ProofOfCoverage> proofOfCoverageList) {

		if((proofOfCoverageList!=null) &&(!proofOfCoverageList.isEmpty())){
			
			logger.debug("\n BEGIN::populateLPPolicyRequest() : proof of coverage size => "+proofOfCoverageList.size());
			
			/**
			 * 1 -
			 * for each proof of coverage, load the extra data needed to LP the Proof of coverage (borrower/loand/flood... info)
			 */
			Collection<LPPolicyRequestViewData> lpPolicyViewDataList = lpPolicyRequestViewDataRepository
					.findByProofOfCoverageIn(proofOfCoverageList);

			removeLpIssueWithCancellation(lpPolicyViewDataList, proofOfCoverageList);
			/**
			 *2 -
			 * LPPolicyRequest is a staging table where we store LP coverage issue (or to be issued)
			 */
			generateLpPolicyRequest(lpPolicyRequestList, lpPolicyViewDataList,"Assurant");
			
			if(lpPolicyRequestList!=null && !lpPolicyRequestList.isEmpty()){
				lPPolicyRequestRepository.save(lpPolicyRequestList);
			}
			
			logger.debug("END::populateLPPolicyRequest()");
		}

	}
	
	void populateLPPolicyRequestAlthans(List<LPPolicyRequest> lpPolicyRequestList, List<QueuedForAlthansViewData> queuedForAlthans) {
		if (queuedForAlthans != null && !queuedForAlthans.isEmpty()) {
			logger.debug("\n BEGIN::populateLPPolicyRequest() : proof of coverage size => "+queuedForAlthans.size());
			
			/**
			 * 1 -
			 * for each proof of coverage, load the extra data needed to LP the Proof of coverage (borrower/loand/flood... info)
			 */
			Collection<Long> proofOfCoverageRids = new HashSet<Long>();
			for (QueuedForAlthansViewData queued : queuedForAlthans) {
				proofOfCoverageRids.add(queued.getProofOfCoverage().getRid());
			}
			Collection<LPPolicyRequestViewData> lpPolicyViewDataList =
					lpPolicyRequestViewDataRepository.findByProofOfCoverageRidIn(proofOfCoverageRids);

			/**
			 *2 -
			 * LPPolicyRequest is a staging table where we store LP coverage issue (or to be issue)
			 */
			LPVendorFileGenerator lpVendorFileGenerator =
					lpVendorFileGeneratorFactory.getLPVendorFileGeneratorFactory(LpInsuranceVendor.ALTHANS);
			lpPolicyRequestList.addAll(lpVendorFileGenerator.generateLpPolicyRequest(lpPolicyViewDataList));
			if (lpPolicyRequestList != null && !lpPolicyRequestList.isEmpty()) {
				lPPolicyRequestRepository.save(lpPolicyRequestList);
			}
			//create TM task if the policy has lob as CTL and Non Escroww
			if (lpPolicyViewDataList != null && !lpPolicyViewDataList.isEmpty()) {
				List<LPPolicyRequestViewData> list = new ArrayList(lpPolicyViewDataList);
				escrowProcessingService.createInsuranceEscrowBalanceTask(list);
			}
		logger.debug("END::populateLPPolicyRequest()");
		}

	}
	
	/**
	 * Prepare the Flood Supporting Documentation xls file and send to jason for initiating LP.
	 * 1.Prepare the Flood Supporting Documentation xls file with eligible policies
	 * 2.Send email with LP details attached to assurant.
	 */
	private void sendLPEmailToAssurant( List<LPPolicyRequest> lpPolicyRequestList) {	
		
		logger.debug("BEGIN::sendLPEmailToAssurant()");
		/**
		 * 1-
		 * Prepare the Flood Supporting Documentation xls file with eligible policies
		 */
		File insuranceReqFile = lpInsuranceRequestUtil.prepareInsuranceRequestFile(lpPolicyRequestList);

		/**
		 * 2-
		 * Send the LP request to the insurance vendor
		 */
		emailNotificationService.requestLPInitiationVendorEmail(insuranceReqFile, LpInsuranceVendor.ASSURANT);
		
		/**
		 * 3-
		 * Update the state of the row so that we don't pick it up next time...
		 */
		Date currentDate = businessDayUtil.getCurrentReferenceDate();	
		for (LPPolicyRequest lpPolicyRequest : lpPolicyRequestList) {
			lpPolicyRequest.setItemSentDate(currentDate);
		}
		
		lPPolicyRequestRepository.save(lpPolicyRequestList);

		logger.debug("END::sendLPEmailToAssurant()");
	}	
	
	/**
	 * Prepare the Flood Supporting Documentation xls file and send to jason for initiating LP.
	 * 1.Prepare the Flood Supporting Documentation xls file with eligible policies
	 * 2.Send email with LP details attached to assurant.
	 */
	void sendLPEmailToAlthans( List<LPPolicyRequest> lpPolicyRequestList) {
		
		logger.debug("BEGIN::sendLPEmailToAlthans()");
		
		Date currentDate = businessDayUtil.getCurrentReferenceDate();
		AlthansBatchItem althansBatchItem = null;
		if (!lpPolicyRequestList.isEmpty()) {
			althansBatchItem = createAlthansBatchItem(currentDate);
		}
		
		/**
		 * 1-
		 * Prepare the Flood Supporting Documentation xls file with eligible policies
		 */
		File insuranceReqFile = lpInsuranceRequestUtil.prepareInsuranceRequestFileAlthans(althansBatchItem != null ?
				althansBatchItem.getFileName() : generateWeeklyRequestFileName(currentDate, null), lpPolicyRequestList, currentDate);
		insuranceReqFile = fileUtility.write(env.getRequiredProperty("althans.landing.outbound.directory"), insuranceReqFile);
		
		/**
		 * 2-
		 * Send the LP request to the insurance vendor
		 */
		emailNotificationService.requestLPInitiationVendorEmail(insuranceReqFile, LpInsuranceVendor.ALTHANS);

		/**
		 * 3-
		 * Update the state of the row so that we don't pick it up next time...
		 */
		if (althansBatchItem != null) {
			for (LPPolicyRequest lpPolicyRequest : lpPolicyRequestList) {
				lpPolicyRequest.setAlthansBatchItem(althansBatchItem);
				lpPolicyRequest.setItemSentDate(currentDate);
			}
			lPPolicyRequestRepository.save(lpPolicyRequestList);
			
			perfectionTaskService.createTransientTask(althansBatchItem,
					WorkflowStateDefinition.PROCESS_VENDOR_FILE.getFloodRemapTaskState(), TMTaskType.FLOOD_INSURANCE, null);
			perfectionTaskService.createTransientTask(althansBatchItem,
					WorkflowStateDefinition.PROCESS_VENDOR_CERTIFICATES.getFloodRemapTaskState(), TMTaskType.FLOOD_INSURANCE, null);
		}

		logger.debug("END::sendLPEmailToAlthans()");
	}

	private AlthansBatchItem createAlthansBatchItem(Date requestSentDate) {
		AlthansBatchItem althansBatchItem = new AlthansBatchItem();
		althansBatchItem.setRequestSentDate(requestSentDate);
		althansBatchItem = althansBatchItemRepository.save(althansBatchItem);
		althansBatchItem.setFileName(generateWeeklyRequestFileName(requestSentDate, althansBatchItem.getRid()));
		althansBatchItem = althansBatchItemRepository.save(althansBatchItem);
		return althansBatchItem;
	}
	
	private String generateWeeklyRequestFileName(Date requestSentDate, Long rid) {
		StringBuilder fileName = new StringBuilder("weekly_request-").append(DateFormatter.toSortableDate(requestSentDate));
		if (rid != null) {
			fileName.append("-").append(rid);
		}
		fileName.append(".xlsx");
		return fileName.toString();
	}

	public void generateLpPolicyRequest(List<LPPolicyRequest> lpPolicyRequestList, Collection<LPPolicyRequestViewData> lpPolicyViewDataList, String vendor)

	{
		
		if(lpPolicyViewDataList==null || lpPolicyViewDataList.isEmpty()){
			return;
		}
		
		for (LPPolicyRequestViewData lpPolicyRequestViewData : lpPolicyViewDataList) {
			
			if(LPActions.CANCEL_LP.name().equals(lpPolicyRequestViewData.getProofOfCoverage().getLpAction()))
			{

				LPPolicyRequest lpPolicyRequest = ctracObjectMapper.map(lpPolicyRequestViewData, LPPolicyRequest.class);
				lpPolicyRequest.setLenderPlaceItem(lpPolicyRequestViewData.getLenderPlaceItem());
				lpPolicyRequest.setProofOfCoverage(lpPolicyRequestViewData.getProofOfCoverage());
				if (lpPolicyRequestViewData.getProofOfCoverage() != null) {
					PolicyType policyType = lpPolicyRequestViewData.getProofOfCoverage().getPolicyType_();
					if (policyType != null && policyType == PolicyType.LP) {
						lpPolicyRequest.setCoverageType("Flood");
					} else if (policyType != null && policyType == PolicyType.LP_GAP) {
						lpPolicyRequest.setCoverageType("Flood Gap");
					}
				}
	
				if("Assurant".equals(vendor)){
					populateGenericDataLpVendorData(lpPolicyRequestViewData, lpPolicyRequest);
				}

			    lpPolicyRequestList.add(lpPolicyRequest);		
			}
		}
	}
	
	private Collection<Long> getInsurableAssetsWithCancelation(Collection<LPPolicyRequestViewData> lpPolicyViewDataList) {
		Collection<Long> result = new HashSet<Long>();
		for (LPPolicyRequestViewData lpPolicyRequestViewData : lpPolicyViewDataList) {
		    ProofOfCoverage poc = lpPolicyRequestViewData.getProofOfCoverage();
			if (poc != null && LPActions.CANCEL_LP == poc.getLpAction_()) {
				result.add(lpPolicyRequestViewData.getInsurableAssetRid());
			}
		}
		return result;
	}


	private void populateGenericDataLpVendorData(LPPolicyRequestViewData lpPolicyRequestViewData, LPPolicyRequest lpPolicyRequest) {		
        lpPolicyRequest.setStatusId(LP_REQUEST_STATUS_ID);
        //CTL from email address logic not needed here as this is the assurant flow
        lpPolicyRequest.setRequestorEmailAddress(env.getRequiredProperty("from.email.address.flood.service"));
        lpPolicyRequest.setPropertyAddress(lpPolicyRequestViewData.getPropertyAddress() + ", " +lpPolicyRequestViewData.getPropertyCity() + ", " +  lpPolicyRequestViewData.getPropertyState() + " " +  lpPolicyRequestViewData.getPropertyZipCode());
        lpPolicyRequest.setMailingAddress(lpPolicyRequestViewData.getMortgagorAddress() + ", " +lpPolicyRequestViewData.getMortgagorCity() + ", " +  lpPolicyRequestViewData.getMortgagorState() + " " +  lpPolicyRequestViewData.getMortgagorZipCode());
        LookUpCode branchCode = getBranchCodeForLOB(CODE_SET_LOB_ASSURANT_BRANCH_CODE, lpPolicyRequestViewData.getLineOfBusiness());
        if (branchCode != null) {
            lpPolicyRequest.setLenderBranchCode(branchCode.getDescription() + " - " + lpPolicyRequestViewData.getLineOfBusiness() + "(" + branchCode.getCode() + ")");
        }
        lpPolicyRequest.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);
        lpPolicyRequest.setBuildingContentsCoverage(lpPolicyRequestViewData.getBuildingContentsCov());

        lpPolicyRequest.setRequestorName(CtracAppConstants.SYSTEM_USER);
        lpPolicyRequest.setReportDate(businessDayUtil.getCurrentReferenceDate());
        lpPolicyRequest.setEffectiveDate(lpPolicyRequestViewData.getProofOfCoverage().getCancellationEffectiveDate());
        lpPolicyRequest.setTransCode(CANCEL_COVERAGE_TRANS_CODE);
        lpPolicyRequest.setSpecialProcessing("NA");
        lpPolicyRequest.getLenderPlaceItem().setCancellationRequestDate(lpPolicyRequest.getReportDate());
	}

	private LookUpCode getBranchCodeForLOB(String vendorCodeset, String lineOfBusiness) {
		LineOfBusinessDTO lob = lobService.findByCode(lineOfBusiness);
        if (lob != null) {
            return lookupCodeRepository.findByCodeAndCodeSet(lob.getBranchCode(), vendorCodeset);
        }
        return null;
	}

	/**
	 * Prepare and send an alert email in case of any failure while sending jason email.
	 */
	protected void sendInsuranceReqAlertEmail(Exception ex) {
		logger.debug("BEGIN::sendInsuranceReqAlertEmail()");		
		EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();		
		emailAttributeHolder.setSubject(env.getRequiredProperty(POLICY_INSURANCE_REQ_EMAIL_ALERTSUBJECT));			
		emailAttributeHolder.setEmailBody(env.getRequiredProperty(POLICY_INSURANCE_REQ_ALERTEMAILBODY) +"  /n "+ex.getMessage());
		String operationTeamEmail = env.getRequiredProperty(POLICY_INSURANCE_REQ_TOALERTEMAIL);
		emailAttributeHolder.addToAddress(operationTeamEmail);
		String fromAddress =  env.getRequiredProperty(POLICY_INSURANCE_REQ_FROMEMAIL);
		emailAttributeHolder.setFromAddress(fromAddress);
		floodEmailService.sendEmail(emailAttributeHolder);
		logger.debug("END::sendInsuranceReqAlertEmail()");
		throw new RuntimeException(ex);
	}


	
}
