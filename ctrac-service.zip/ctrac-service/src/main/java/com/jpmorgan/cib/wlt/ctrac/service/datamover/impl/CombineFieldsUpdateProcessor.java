package com.jpmorgan.cib.wlt.ctrac.service.datamover.impl;

import java.lang.reflect.Field;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataProcessor;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.Seperator;

/**
 * CombineFieldsUpdateProcessor will combine the fieldsToCombine and set it in the field represented by targetFieldName. 
 * @author n446693
 *
 */
public class CombineFieldsUpdateProcessor implements DataProcessor {
	String targetFieldName;
	Seperator targetFieldSeperator;
	String fieldsToCombine;
	Seperator fieldsToCombineSeperator;
	/**
	 * CombineFieldsUpdateProcessor will combine the fieldsToCombine and set it in the field represented by targetFieldName. 
	 * @author n446693
	 *
	 */
	public CombineFieldsUpdateProcessor(String targetFieldName,
			Seperator targetFieldSeperator, String fieldsToCombine,
			Seperator fieldsToCombineSeperator) {
		super();
		this.targetFieldName = targetFieldName;
		this.targetFieldSeperator = targetFieldSeperator;
		this.fieldsToCombine = fieldsToCombine;
		this.fieldsToCombineSeperator = fieldsToCombineSeperator;
	}
	
	@Override
	public<Source> List<Source> apply(List<Source> sourceData)
	{
		for(Source current : sourceData){
			applyCombine(current);
		}
		return sourceData;
	}

	private <Source> void applyCombine(Source record) {
		
		Field sourceField;
		StringBuffer combinedValueBuffer = new StringBuffer();		
		try {
			String[] sourceFieldNames = fieldsToCombine
					.split(fieldsToCombineSeperator.getCode());
			for (String sourceFieldName : sourceFieldNames) {
				sourceField = record.getClass()
						.getDeclaredField(sourceFieldName);
				sourceField.setAccessible(true);
				combinedValueBuffer.append(sourceField.get(record));
				combinedValueBuffer.append(targetFieldSeperator.getCode());
			}
			String combinedValue = combinedValueBuffer.toString().trim();
			Field targetField = record.getClass().getDeclaredField(targetFieldName);
			targetField.setAccessible(true);
			targetField.set(record, combinedValue);
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
