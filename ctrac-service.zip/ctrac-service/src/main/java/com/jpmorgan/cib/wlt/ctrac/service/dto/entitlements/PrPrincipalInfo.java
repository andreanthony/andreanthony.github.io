package com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang.StringUtils;

/**
 * Created by i569445 on 6/7/2016.
 */
public class PrPrincipalInfo {

    private String id;
    private String name;
    private String sid;
    private String loginName;

    @XmlTransient
    private String firstName;
    @XmlTransient
    private String lastName;

    @XmlElement(name = "id")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @XmlElement(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @XmlElement(name = "sid")
    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    @XmlElement(name = "loginName")
    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getFirstName() {
        if(name != null) {
            return name.split(" ")[0];
        }
        return name;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        if(name != null) {
            return name.split(" ")[1];
        }
        return name;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public boolean isLicenseKeyEntry() {
        if(this.sid != null && StringUtils.isNotEmpty(this.sid) && StringUtils.isNotBlank(this.sid)) {
            return false;
        }
        return true;
    }
}
