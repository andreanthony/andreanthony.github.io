package com.jpmorgan.cib.wlt.ctrac.service.dto.base;


public class CollateralSearchResultData implements Collateraldata {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -232021800118654853L;

	protected String loanNumber;
	
	protected String borrowerName;

	protected String collateralId;

	protected String ctracID;

	protected String name;

	protected String ownerName;

	protected String collateralType;

	protected String lineOfBusiness;
	protected String lobCode;
	
	
	protected String propertyAddress;	

	protected String propertyCity;

	protected String propertyState;

	protected String propertyZipCode;
	
	protected String propertyFullAddress;

	protected String collateralStatus;
	
	protected String policyNumber;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	
	protected String unitBuilding;
	
	public String getUnitBuilding() {
		return unitBuilding;
	}

	public void setUnitBuilding(String unitBuilding) {
		this.unitBuilding = unitBuilding;
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPropertyCity() {
		return propertyCity;
	}

	public void setPropertyCity(String propertyCity) {
		this.propertyCity = propertyCity;
	}

	public String getPropertyState() {
		return propertyState;
	}

	public void setPropertyState(String propertyState) {
		this.propertyState = propertyState;
	}

	public String getPropertyZipCode() {
		return propertyZipCode;
	}

	public void setPropertyZipCode(String propertyZipCode) {
		this.propertyZipCode = propertyZipCode;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public String getCollateralId() {
		return collateralId;
	}

	public void setCollateralId(String collateralId) {
		this.collateralId = collateralId;
	}

	public String getCtracID() {
		return ctracID;
	}

	public void setCtracID(String ctracID) {
		this.ctracID = ctracID;
	}

	public String getPropertyFullAddress() {
		return propertyFullAddress;
	}

	public void setPropertyFullAddress(String propertyFullAddress) {
		this.propertyFullAddress = propertyFullAddress;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getCollateralStatus() {
		return collateralStatus;
	}

	public void setCollateralStatus(String collateralStatus) {
		this.collateralStatus = collateralStatus;
	}
	
	public String getLobCode() {
		return lobCode;
	}

	public void setLobCode(String lobCode) {
		this.lobCode = lobCode;
	}
}
