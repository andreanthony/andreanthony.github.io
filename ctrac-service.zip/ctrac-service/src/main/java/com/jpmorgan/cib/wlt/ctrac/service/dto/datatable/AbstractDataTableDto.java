package com.jpmorgan.cib.wlt.ctrac.service.dto.datatable;

import java.io.Serializable;
import java.lang.reflect.Field;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

public class AbstractDataTableDto implements DataTableDto, Serializable{

	private static final long serialVersionUID = -1267138691904396605L;

	/*
	 * This value will be automatically assigned as the table row ID
	 */
	private String DT_RowId;

	/*
	 * This value will be automatically assigned as the table row class TODO use
	 * this to customize click event on rows
	 **/
	private String DT_RowClass = "test";

	/*
	 * This value will be automatically available to as the table row in case of
	 * click even TODO use this to customize click event on rows
	 */

	private String DT_RowData;
	
	@Override
	public void parseRequestAttributes(HttpServletRequest httpReq) {
		int totalNumberOfSearhField = 0;
		String  totalSearchField = httpReq.getParameter("totalSearchField"); 
		if(!StringUtils.isBlank(totalSearchField)){
			totalNumberOfSearhField = Integer.parseInt(totalSearchField);
		}
		for(int index = 1; index <= totalNumberOfSearhField; index++){
			
			try {
				String fieldName = httpReq.getParameter("columns["+index+"][data]");
				String fieldValue = httpReq.getParameter("columns["+index+"][search][value]"); 
				if(!StringUtils.isBlank(fieldValue)){
					fieldValue = StringUtils.trim(fieldValue);
				}
				Field field = getClass().getDeclaredField(fieldName);
				field.set(this, fieldValue);
			} catch (Exception swallow ) {
				// TODO log warning
			} 
		}
	}


	public String getDT_RowId() {
		return DT_RowId;
	}

	public void setDT_RowId(String dT_RowId) {
		DT_RowId = dT_RowId;
	}

	public String getDT_RowClass() {
		return DT_RowClass;
	}

	public void setDT_RowClass(String dT_RowClass) {
		DT_RowClass = dT_RowClass;
	}

	public String getDT_RowData() {
		return DT_RowData;
	}

	public void setDT_RowData(String dT_RowData) {
		DT_RowData = dT_RowData;
	}

}
