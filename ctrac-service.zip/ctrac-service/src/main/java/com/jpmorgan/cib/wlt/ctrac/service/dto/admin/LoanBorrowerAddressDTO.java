package com.jpmorgan.cib.wlt.ctrac.service.dto.admin;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

public class LoanBorrowerAddressDTO implements Serializable {

	private static final long serialVersionUID = 5252457557658647560L;

	private Long addressRid;
	private String collateralRids;
	private String borrowerName;
	private String streetAddress;
	private String unitBuilding;
	private String city;
	private String state;
	private String zipCode;

	private String verifiedStreetAddress;
	private String verifiedUnitBuilding;
	private String verifiedCity;
	private String verifiedState;
	private String verifiedZipCode;
	
	private Boolean verifiedAddress;
	
	private String errorMessage;

	public String getErrorMessage() {
		return((errorMessage == null)?"":errorMessage);
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Long getAddressRid() {
		return addressRid;
	}

	public void setAddressRid(Long addressRid) {
		this.addressRid = addressRid;
	}

	public String getCollateralRids() {
		return collateralRids;
	}

	public void setCollateralRids(String collateralRids) {
		this.collateralRids = collateralRids;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getStreetAddress() {
		return (streetAddress == null) ?  "":  streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getUnitBuilding() {
		return (unitBuilding == null) ?  "":  unitBuilding;
	}

	public void setUnitBuilding(String unitBuilding) {
		this.unitBuilding = unitBuilding;
	}

	public String getCity() {
		return (city == null) ?  "":  city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return (state == null) ?  "":  state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return (zipCode == null) ?  "":  zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getVerifiedStreetAddress() {
		return (verifiedStreetAddress == null) ?  "":  verifiedStreetAddress;
	}

	public void setVerifiedStreetAddress(String verifiedStreetAddress) {
		this.verifiedStreetAddress = verifiedStreetAddress;
	}

	public String getVerifiedUnitBuilding() {
		return (verifiedUnitBuilding == null) ?  "":  verifiedUnitBuilding;
	}

	public void setVerifiedUnitBuilding(String verifiedUnitBuilding) {
		this.verifiedUnitBuilding = verifiedUnitBuilding;
	}

	public String getVerifiedCity() {
		return (verifiedCity == null) ?  "":  verifiedCity;
	}

	public void setVerifiedCity(String verifiedCity) {
		this.verifiedCity = verifiedCity;
	}

	public String getVerifiedState() {
		return (verifiedState == null) ?  "":  verifiedState;
	}

	public void setVerifiedState(String verifiedState) {
		this.verifiedState = verifiedState;
	}

	public String getVerifiedZipCode() {
		return (verifiedZipCode == null) ?  "":  verifiedZipCode;
	}

	public void setVerifiedZipCode(String verifiedZipCode) {
		this.verifiedZipCode = verifiedZipCode;
	}

	public Boolean getVerifiedAddress() {
		return((verifiedAddress == null)?false:verifiedAddress);

	}

	public void setVerifiedAddress(Boolean verifiedAddress) {
		this.verifiedAddress = verifiedAddress;
	}
	
}
