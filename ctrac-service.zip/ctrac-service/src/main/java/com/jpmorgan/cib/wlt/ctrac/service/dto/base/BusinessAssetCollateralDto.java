package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;



public  class BusinessAssetCollateralDto extends CollateralDto {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BusinessAssetCollateralDto(){
		
	}

	@Override
	public String getPropertyTypeDisplayValue() {
		return "Contents Only";
	}

	@Override
	protected CollateralDto clone() throws CloneNotSupportedException {
		return (CollateralDto) super.clone();
	}

}
