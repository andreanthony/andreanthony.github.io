package com.jpmorgan.cib.wlt.ctrac.service.filebucket;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FileItem;

/**
 * 
 *
 */

@Component("emailAttachmentsBucket")
/*@Scope(value = "session", proxyMode = ScopedProxyMode.INTERFACES)*/
public class EmailAttachmentsBucketImpl implements EmailAttachmentsBucket {

	private static final Logger logger = Logger.getLogger(EmailAttachmentsBucketImpl.class);
	
	/**
	 */
	private final Map<String, EmailAttachments> emailAttachmentEntries;    

	public  EmailAttachmentsBucketImpl (){
		
		logger.debug(" EmailAttachmentsBucketImpl ():  initializind the bucket entry ");
		emailAttachmentEntries= new HashMap<String, EmailAttachments>();
	}
	
	/* (non-Javadoc)
	 * @see com.jpmorgan.cib.wlt.ctrac.utils.EmailAttachmentsBucket#pushEmailAttachments(com.jpmorgan.cib.wlt.ctrac.dto.EmailAttachments)
	 */
	@Override
	public void pushEmailAttachments(EmailAttachments attachment) {
		if ( attachment!=null && !StringUtils.isBlank(attachment.getTaskUUId())&&!attachment.getFiles().isEmpty()) {
			if (!emailAttachmentEntries.isEmpty()) {
				EmailAttachments oldAttachments = emailAttachmentEntries.get(attachment.getTaskUUId());
				if(oldAttachments!=null){
					oldAttachments.pushAllFiles(attachment.getFiles());
					logger.debug("pushEmailAttachments(): adding attachment to bucket: "+attachment.getTaskUUId()+ "curent bucket is "+toString());
					
					return;
				}
			}
			if(!StringUtils.isBlank(attachment.getTaskUUId())){
			    emailAttachmentEntries.put(attachment.getTaskUUId(), attachment);
			}
			
			logger.debug("pushEmailAttachments(): first adding attachment to bucket: "+attachment.getTaskUUId()+ "curent bucket is "+toString());
			
		}
	}

	/* (non-Javadoc)
	 * @see com.jpmorgan.cib.wlt.ctrac.utils.EmailAttachmentsBucket#popEmailAttachments(java.lang.String)
	 */
	@Override
	public EmailAttachments popEmailAttachments(String taskUUId) {
		logger.debug("popEmailAttachments : gettind attachment for:"+taskUUId+":curent bucket is "+toString());
		
		EmailAttachments result = emailAttachmentEntries.remove(taskUUId);
		
		//also cleanup any old or garbage file in the bucket
		Iterator<Entry<String, EmailAttachments>> bkIterator = emailAttachmentEntries.entrySet().iterator();
		while(bkIterator.hasNext()){
		    Entry<String, EmailAttachments> entry = bkIterator.next();
		    Date insertTime = entry.getValue().getInsetedDate();
		    Date oneHrAgo = new DateTime().minusHours(1).toDate();
		    if( insertTime.before(oneHrAgo) ){
		        bkIterator.remove();
		    }
		}

		return result;
	}

	/* (non-Javadoc)
	 * @see com.jpmorgan.cib.wlt.ctrac.utils.EmailAttachmentsBucket#clear()
	 */
	@Override
	public void clear(String taskUUId) {
		logger.debug(" clear(): removing all entries form"+taskUUId+".  curent bucket is "+toString() );
		
		EmailAttachments removed = emailAttachmentEntries.remove(taskUUId);
		if(removed!=null){
			logger.debug(" removed of size " +removed.getFiles().size() );
			
		}
	}
	
	/* (non-Javadoc)
	 * @see com.jpmorgan.cib.wlt.ctrac.utils.EmailAttachmentsBucket#removeFile(java.lang.String,java.lang.String)
	 */	
	public FileItem removeFile(String taskUUId, String fileName ){
		
		FileItem result = new  FileItem(null,fileName,taskUUId);
		EmailAttachments bucket = emailAttachmentEntries.get(taskUUId);
		if(bucket!=null){
			logger.debug("removeFile : deleting  FileName .."+fileName+" curent bucket is "+toString());
			
			return bucket.popFile(result);
		}
		logger.debug( "the bucket was emty any way ..." );
		
		return null;
	}
	
	@Override
	public String toString(){
		
		StringBuilder response = new StringBuilder();
		for( Entry<String, EmailAttachments> entry:emailAttachmentEntries.entrySet() ){
			response.append("\n -key-"+entry.getKey()+":[{ "+entry.getValue().toString()+" }] \n");
		}
		return response.toString();
		
	}

}
