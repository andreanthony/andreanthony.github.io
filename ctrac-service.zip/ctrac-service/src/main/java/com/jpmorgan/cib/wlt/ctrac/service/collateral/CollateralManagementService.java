package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;


/**
 * @author n595724
 *
 */
public interface CollateralManagementService {

	/**
	 * @param collateralRid
	 * @return
	 */
	boolean isCollateralBusinessAssetSBAOnly(Long collateralRid);
	
	/**
	 * @param tmTaskId
	 * @return
	 */
	List<CollateralDto> getCollateralsByTmTask(String tmTaskId);
	
	
	/**
	 * @param tmTaskId
	 * @param taskStatus
	 * @return
	 */
	List<CollateralDto> getCollateralsByTmTask(String tmTaskId, String taskStatus);
	
	
	/**
	 * @param workItem
	 * @return
	 */
	List<CollateralDto> getCollateralsByWorkItem(WorkItem workItem);


	/**
	 * @param workItemRid
	 * @return
	 */
	List<CollateralDto> getCollateralsByWorkItem(Long workItemRid);

	
	/**
	 * @param collateralDto
	 * @return
	 */
	CollateralDto saveCollateral(CollateralDto collateralDto, String userId);

	boolean hasMarketEmailChanged(CollateralDetailsMainDto collateralDetailsData);

	CollateralDto getCollateralDtoForLPPolicyByProofOfCoverageRid(Long proofOfCoverageRid);

	/**
	 * @param collaterals
	 * @return
	 */
	Collection<CollateralDto> saveCollaterals(Collection<CollateralDto> collaterals, String userId);
	
	Set<Collateral> geUniquetCollateralsByTmTaskId(String tmTaskId);

	public CollateralDto getCollateralDto(Long collateralRid);

	Collection<CustomerData> getCollateralOwners(Long collateralRId);

    void removeCollateralOwner(CollateralDto collateralDto);

    Collateral getPrimaryCollateralByTmTaskId(String tmTaskId);

    void deleteCollateral(CollateralDto collateralDto);

    String getCollateralDescription(Long collateralRid);
    
    CollateralStatus getCollateralStatus(Long collateralId);

	List<CollateralDto> getCollateralDtosByProofOfCoverage(ProofOfCoverageDTO proofOfCoverageDto);

    void updateCollateralOwnerSameASBorrower(List<CustomerData> ownerData);

    void delinkWithLoan(CollateralDto collateralDto);
}
