package com.jpmorgan.cib.wlt.ctrac.service.entitlements;


import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.core.env.Environment;

import net.jpmchase.cbhub.rsam.UserInventoryResult;
import net.jpmchase.cbhub.rsam.data.ioconsole.IOConsoleUserInventoryRequestData;
import net.jpmchase.cbhub.rsam.handlers.UserInventoryHandler;

/**
 * Created by I569445 on 2/18/2016.
 */
public class CtracUserInventoryHandler implements UserInventoryHandler {


    private static final Logger logger = Logger.getLogger(CtracUserInventoryHandler.class);

    private List<IOConsoleUserInventoryRequestData.UserRecord> rsamUserDetails;
    private String apiKey;
    private String apiUser;
    private String assetId;


    @Resource
    private Environment env;

    public CtracUserInventoryHandler(String apiKey, String apiUser, String assetId, List<IOConsoleUserInventoryRequestData.UserRecord> rsamUserDetails) {
        this.rsamUserDetails = rsamUserDetails;
        this.apiKey = apiKey;
        this.apiUser = apiUser;
        this.assetId = assetId;
    }

    @Override
    public String getCronSchedule() {
        return null;
    }

    @Override
    public boolean getWaitOnShutdown() {
        return false;
    }

    @Override
    public String getAssetID() {
        return this.assetId;
    }

    @Override
    public String getAPIKey() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.apiUser).append(":").append(this.apiKey);
        return sb.toString();
    }

    @Override
    public boolean canContinue() {
        return true;
    }

    @Override
    public List<IOConsoleUserInventoryRequestData.UserRecord> getUserRecords() throws IOException {
       return this.rsamUserDetails;
    }

    @Override
    public void handleUserInventoryResponse(UserInventoryResult userInventoryResult) {
        if(userInventoryResult != null) {
            logger.info(userInventoryResult.getMessage() + " Response Status: " + userInventoryResult.isSuccess());
            if(userInventoryResult.getErrors() != null && userInventoryResult.hasErrors()) {
                for(String error : userInventoryResult.getErrors()) {
                    logger.error("RSAM Response Error: " + error);
                }
            }
        }
    }
}
