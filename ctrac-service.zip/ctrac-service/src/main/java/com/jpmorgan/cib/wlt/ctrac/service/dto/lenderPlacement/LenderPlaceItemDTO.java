package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

public class LenderPlaceItemDTO implements Serializable {

	private static final long serialVersionUID = -8742616651829855127L;

	private String lpPhase;

	private String lpSendDate;

	private String firstLetterDate;

	private String secondLetterDate;

	private String premiumAmount;
	
	private String bankPremiumAmount;
	
	private int borrowerPremiumDays;
	
	private int bankPremiumDays;
	
	private int totalPremiumDays;
	
	private String totalPremiumAmount;
	
	private boolean isCancelledNoRefund;

	private String billingDate;

	private String fedReferenceNumber;

	private String policyInfoVerified;

	private String specialProcessing;

	private String vendorDocsImaged;

	private String policyInImageSystem;
	
	private String wireSentDate;

	private String cancellationRequestDate;

	private String cancellationLetterDate;

	private String refundAmount;
	
	private String bankRefundAmount;
	
	private String totalRefundAmount;
	
	private String clwRefNumber;

	private String refundCompletionDate;

	private String confirmImgLetter;
	
	private Long rid;
	
	public boolean premiumAmountRecorded() {
		return StringUtils.isNotBlank(premiumAmount) || StringUtils.isNotBlank(bankPremiumAmount);
	}
	
	public boolean refundAmountRecorded(){
		return StringUtils.isNotBlank(refundAmount) || StringUtils.isNotBlank(bankRefundAmount);
	}
	
	public String getLpPhase() {
		return lpPhase;
	}

	public void setLpPhase(String lpPhase) {
		this.lpPhase = lpPhase;
	}

	public String getLpSendDate() {
		return lpSendDate;
	}

	public void setLpSendDate(String lpSendDate) {
		this.lpSendDate = lpSendDate;
	}

	public String getFirstLetterDate() {
		return firstLetterDate;
	}

	public void setFirstLetterDate(String firstLetterDate) {
		this.firstLetterDate = firstLetterDate;
	}

	public String getSecondLetterDate() {
		return secondLetterDate;
	}

	public void setSecondLetterDate(String secondLetterDate) {
		this.secondLetterDate = secondLetterDate;
	}

	public String getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}

	public String getFedReferenceNumber() {
		return fedReferenceNumber;
	}

	public void setFedReferenceNumber(String fedReferenceNumber) {
		this.fedReferenceNumber = fedReferenceNumber;
	}

	public String getPolicyInfoVerified() {
		return policyInfoVerified;
	}

	public void setPolicyInfoVerified(String policyInfoVerified) {
		this.policyInfoVerified = policyInfoVerified;
	}

	public String getSpecialProcessing() {
		return specialProcessing;
	}

	public void setSpecialProcessing(String specialProcessing) {
		this.specialProcessing = specialProcessing;
	}

	public String getVendorDocsImaged() {
		return vendorDocsImaged;
	}

	public void setVendorDocsImaged(String vendorDocsImaged) {
		this.vendorDocsImaged = vendorDocsImaged;
	}

	public String getPolicyInImageSystem() {
		return policyInImageSystem;
	}

	public void setPolicyInImageSystem(String policyInImageSystem) {
		this.policyInImageSystem = policyInImageSystem;
	}

	public String getWireSentDate() {
		return wireSentDate;
	}

	public void setWireSentDate(String wireSentDate) {
		this.wireSentDate = wireSentDate;
	}

	public String getCancellationRequestDate() {
		return cancellationRequestDate;
	}

	public void setCancellationRequestDate(String cancellationRequestDate) {
		this.cancellationRequestDate = cancellationRequestDate;
	}

	public String getCancellationLetterDate() {
		return cancellationLetterDate;
	}

	public void setCancellationLetterDate(String cancellationLetterDate) {
		this.cancellationLetterDate = cancellationLetterDate;
	}
	
	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getClwRefNumber() {
		return clwRefNumber;
	}

	public void setClwRefNumber(String clwRefNumber) {
		this.clwRefNumber = clwRefNumber;
	}

	public String getRefundCompletionDate() {
		return refundCompletionDate;
	}

	public void setRefundCompletionDate(String refundCompletionDate) {
		this.refundCompletionDate = refundCompletionDate;
	}

	public String getConfirmImgLetter() {
		return confirmImgLetter;
	}

	public void setConfirmImgLetter(String confirmImgLetter) {
		this.confirmImgLetter = confirmImgLetter;
	}

	public boolean getIsCancelledNoRefund() {
		return isCancelledNoRefund;
	}

	public void setIsCancelledNoRefund(boolean isCancelledNoRefund) {
		this.isCancelledNoRefund = isCancelledNoRefund;
	}

	public String getBankPremiumAmount() {
		return bankPremiumAmount;
	}

	public void setBankPremiumAmount(String bankPremiumAmount) {
		this.bankPremiumAmount = bankPremiumAmount;
	}

	public int getBorrowerPremiumDays() {
		return borrowerPremiumDays;
	}

	public void setBorrowerPremiumDays(int borrowerPremiumDays) {
		this.borrowerPremiumDays = borrowerPremiumDays;
	}

	public int getBankPremiumDays() {
		return bankPremiumDays;
	}

	public void setBankPremiumDays(int bankPremiumDays) {
		this.bankPremiumDays = bankPremiumDays;
	}

	public String getBankRefundAmount() {
		return bankRefundAmount;
	}

	public void setBankRefundAmount(String bankRefundAmount) {
		this.bankRefundAmount = bankRefundAmount;
	}

	public int getTotalPremiumDays() {
		return totalPremiumDays;
	}

	public void setTotalPremiumDays(int totalPremiumDays) {
		this.totalPremiumDays = totalPremiumDays;
	}

	public String getTotalPremiumAmount() {
		return totalPremiumAmount;
	}

	public void setTotalPremiumAmount(String totalPremiumAmount) {
		this.totalPremiumAmount = totalPremiumAmount;
	}

	public String getTotalRefundAmount() {
		return totalRefundAmount;
	}

	public void setTotalRefundAmount(String totalRefundAmount) {
		this.totalRefundAmount = totalRefundAmount;
	}
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}
	
}
