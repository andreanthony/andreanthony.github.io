package com.jpmorgan.cib.wlt.ctrac.service.datamover;

import java.util.List;

public interface DataProcessor {
	public<Source> List<Source> apply(List<Source> sourceData);	
}
