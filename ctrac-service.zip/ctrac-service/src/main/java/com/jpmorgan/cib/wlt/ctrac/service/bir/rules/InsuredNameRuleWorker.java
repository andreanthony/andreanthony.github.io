package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailRuleDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class InsuredNameRuleWorker extends AbstractBIRRuleWorker {
	
	public InsuredNameRuleWorker(String key){
		super(key, false);
	}
	
	@Override
	public void populateExceptionEmailData(
			BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData) {
		BIRExceptionEmailRuleDTO birExceptionEmailRuleDTO=new BIRExceptionEmailRuleDTO();
		birExceptionEmailRuleDTO.setCurrentPolicyValue(borrowerInsuranceReviewData.getProofOfCoverageData().getInsuredName());
		birExceptionEmailRuleDTO.setRequiredValue(populateRequiredValue(borrowerInsuranceReviewData.getCollateralDetailsMap()));
		exceptionEmailData.getPolicyExceptions().put(key, birExceptionEmailRuleDTO);
	}
	
	private String populateRequiredValue(Map<Long, BIRCollateralDetailsDTO> collateralDetailsMap){
		StringBuilder sb = new StringBuilder("");
		Iterator<BIRCollateralDetailsDTO> collateralDetailsIter = collateralDetailsMap.values().iterator();
		while (collateralDetailsIter.hasNext()) {
			BIRCollateralDetailsDTO collateralDetails = collateralDetailsIter.next();
			if (StringUtils.isBlank(collateralDetails.getOwnerName())) {
				continue;
			}
			sb.append(collateralDetails.getOwnerName());
			if (collateralDetailsIter.hasNext()) {
				sb.append(", ");
			}
		}
		return sb.toString();
	}

}
