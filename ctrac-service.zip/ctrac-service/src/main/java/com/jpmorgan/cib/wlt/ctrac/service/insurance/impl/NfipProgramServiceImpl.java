package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ACTIVE_FLAG_Y;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ACTIVE_FLAG_N;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.CODE_NFIP_PROGRAM;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.CODE_SET_APPLICATION_VARIABLE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.NfipProgramService;

@Service
@Transactional
public class NfipProgramServiceImpl implements NfipProgramService {
    
    @Autowired
    private LookupCodeRepository lookupCodeRepository;

	@Override
	public boolean isNfipProgramActive() {
		LookUpCode lookUpCode = findNfipProgramCode(); 
		return lookUpCode == null? true : lookUpCode.getActive().equals(ACTIVE_FLAG_Y);
	}

	@Override
	public void setNfipProgramActive(boolean activeFlag) {
		LookUpCode lookUpCode = findNfipProgramCode(); 
		String active = activeFlag? ACTIVE_FLAG_Y : ACTIVE_FLAG_N;
		if(!active.equals(lookUpCode.getActive())) {
			lookUpCode.setActive(active);
			lookupCodeRepository.saveAndFlush(lookUpCode);
		}
	}

	protected LookUpCode findNfipProgramCode() {
		return lookupCodeRepository.findByCodeAndCodeSet(CODE_NFIP_PROGRAM, CODE_SET_APPLICATION_VARIABLE); 
	}

	@Override
	public boolean isRequiredCoverageWorkflowAllowed(FloodRemapItem workItem) {
		// if NFIP program is not active when Fiat is verified for Zone In, do not continue remap workflow until the program is renewed
		return workItem == null || !"IN".equals(workItem.getRemapCategory()) || isNfipProgramActive();
	}

	@Override
	public boolean isPolicyExpirationWorkflowAllowed(PolicyType policyType) {
		// if NFIP program is not active when Application/POP expires, do not continue renewal workflow until the program is renewed
		return !PolicyType.APPLICATION.equals(policyType) || isNfipProgramActive();
	}

}
