package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon;

import com.jpmorgan.cib.wlt.ctrac.service.excel.ColumnDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;

public class ReconRefundsTableDefinition {

	public static final ColumnDefinition[] DEFINITION = {
		new ColumnDefinition("Policy Number", "policyNumber", FieldType.STRING),
		new ColumnDefinition("Loan System", "loanSystem", FieldType.STRING),
		new ColumnDefinition("Isured Name", "insuredName", FieldType.STRING),
		new ColumnDefinition("Policy Cancellation Date", "policyCancellationDate", FieldType.DATE),
		new ColumnDefinition("Refund Amount", "refundAmount", FieldType.AMOUNT),	
	};
	
}
