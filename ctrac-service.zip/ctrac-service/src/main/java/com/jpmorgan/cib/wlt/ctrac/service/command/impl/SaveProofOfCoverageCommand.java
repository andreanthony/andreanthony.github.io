package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import java.util.ArrayList;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.command.Command;

public class SaveProofOfCoverageCommand extends AbstractCommand implements Command {

	private final List<ProofOfCoverage> proofsOfCoverage;

	public SaveProofOfCoverageCommand(ProofOfCoverage proofOfCoverageToSave) {
		this(proofOfCoverageToSave, 0);
	}

	public SaveProofOfCoverageCommand(ProofOfCoverage proofOfCoverageToSave, int priority) {
		this.proofsOfCoverage = new ArrayList<ProofOfCoverage>();
		this.proofsOfCoverage.add(proofOfCoverageToSave);
		this.priority = priority;
	}

	public SaveProofOfCoverageCommand(List<ProofOfCoverage> proofsOfCoverage) {
		this(proofsOfCoverage, 0);
	}
	
	public SaveProofOfCoverageCommand(List<ProofOfCoverage> proofsOfCoverage, int priority) {
		this.proofsOfCoverage = proofsOfCoverage;
		this.priority = priority;
	}
	
	
	@Override
	public void execute() {
		ProofOfCoverageRepository proofOfCoverageRepository = ApplicationContextProvider.getContext().getBean(ProofOfCoverageRepository.class);
		if (proofsOfCoverage != null && !proofsOfCoverage.isEmpty()) {
			proofOfCoverageRepository.save(proofsOfCoverage);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((proofsOfCoverage == null) ? 0 : proofsOfCoverage.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SaveProofOfCoverageCommand other = (SaveProofOfCoverageCommand) obj;
		if (proofsOfCoverage == null) {
			if (other.proofsOfCoverage != null)
				return false;
		} else if (!proofsOfCoverage.equals(other.proofsOfCoverage))
			return false;
		return true;
	}

}
