package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LPPolicyRequestRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EmailTemplateRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.ReconEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon.ReconExcelFile;
import com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon.ReconPremiumsRow;
import com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.recon.ReconRefundsRow;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.math.BigDecimal;
import java.util.*;

@Component
public class ReconEmailServiceImpl implements ReconEmailService {

    @Autowired
    private FloodEmailService floodEmailService;

    @Autowired
    private EmailTemplateRepository emailTemplateRepository;

    @Autowired
    private LPPolicyRequestRepository lpPolicyRequestRepository;

    @Autowired
    private PerfectionTaskRepository perfectionTaskRepository;

    @Autowired
    private DateCalculator dateCalculator;

    @Autowired
    private LoanManagementService loanManagementService;

    @Autowired
    private InsuranceMngtService insuranceMngtService;

    @Autowired
    private Environment env;

    private static final Logger logger = Logger.getLogger(ReconEmailServiceImpl.class);

    @Override
    @Transactional
    public void createAndSendEmail(Long taskId) {
        logger.debug("createAndSendEmail: start");
        if (taskId == null) {
            logger.error("Task ID is null.");
            return;
        }
        Map<LoanSystem, List<ReconPremiumsRow>> premiums = new HashMap<LoanSystem, List<ReconPremiumsRow>>();
        Map<LoanSystem, List<ReconRefundsRow>> refunds = new HashMap<LoanSystem, List<ReconRefundsRow>>();
        PerfectionTask task = perfectionTaskRepository.findOne(taskId);
        List<LPPolicyRequest> policies = lpPolicyRequestRepository.findByAlthansBatchItemRid(task.getWorkItem().getRid());
        AlthansLPFileGenerator generator = new AlthansLPFileGenerator();
        for (LPPolicyRequest policy : policies) {
            LoanSystem loanSystem = loanManagementService.getLoanSystem(policy.getProofOfCoverage().getRid());
            LenderPlaceItem lpItem = policy.getLenderPlaceItem();
            if (generator.isNewOrRenewalPolicyRequest(policy.getTransCode())) {
                addPremiumRowToMap(premiums, policy, loanSystem, lpItem.getPremiumAmount());
                addPremiumRowToMap(premiums, policy, loanSystem, lpItem.getBankPremiumAmount());
            } else if (generator.getLpCancellationCode().equals(policy.getTransCode())) {
                addRefundRowToMap(refunds, policy, loanSystem, lpItem, lpItem.getRefundAmount());
                addRefundRowToMap(refunds, policy, loanSystem, lpItem, lpItem.getBankRefundAmount());
            }
        }
        Date reportDate = dateCalculator.getCurrentReferenceDate();
        Date forActivityDate = dateCalculator.addBusinessDays(2, reportDate);
        File attachment = createAttachment(task.getWorkItem().getRid(), premiums, refunds, reportDate, forActivityDate);
        EmailTemplate template = emailTemplateRepository.findByEmailTemplateId("RECONTRANSFERS");
        EmailAttributeHolder emailAttributeHolder = getEmailContentFromTemplate(template);
        emailAttributeHolder.setSingleFileAttachment(attachment);
        setEmailAddresses(emailAttributeHolder);
        floodEmailService.sendEmail(emailAttributeHolder);
        attachment.delete();
        logger.debug("createAndSendEmail: end");
    }

    EmailAttributeHolder getEmailContentFromTemplate(EmailTemplate template){
        return CtracEmailSender.createEmailContent(null, template);
    }


    private void addRefundRowToMap(Map<LoanSystem, List<ReconRefundsRow>> refunds, LPPolicyRequest policy,
                                   LoanSystem loanSystem, LenderPlaceItem lpItem, BigDecimal refundAmount) {
        if (refundAmount != null && refundAmount.compareTo(BigDecimal.ZERO) != 0 && insuranceMngtService.isWireRefundNeeded(lpItem)) {
            if (!refunds.containsKey(loanSystem)) {
                refunds.put(loanSystem, new ArrayList<ReconRefundsRow>());
            }
            ReconRefundsRow reconRefundsRow = new ReconRefundsRow(
                    policy.getProofOfCoverage().getRid().toString(), loanSystem.name(), policy.getProofOfCoverage().getInsuredName(),
                    policy.getEffectiveDate(), refundAmount);
            refunds.get(loanSystem).add(reconRefundsRow);
        }
    }


    private void addPremiumRowToMap(Map<LoanSystem, List<ReconPremiumsRow>> premiums, LPPolicyRequest policy,
                                    LoanSystem loanSystem, BigDecimal premiumAmount) {
        if (premiumAmount != null && premiumAmount.compareTo(BigDecimal.ZERO) != 0) {
            if (!premiums.containsKey(loanSystem)) {
                premiums.put(loanSystem, new ArrayList<ReconPremiumsRow>());
            }
            ReconPremiumsRow reconPremiumsRow = new ReconPremiumsRow(
                    policy.getProofOfCoverage().getRid().toString(), loanSystem.name(), policy.getProofOfCoverage().getInsuredName(),
                    policy.getEffectiveDate(), premiumAmount);
            premiums.get(loanSystem).add(reconPremiumsRow);
        }
    }


    @Override
    @Transactional
    public void createAndSendNoTransactionEmail() {
        logger.debug("createAndSendNoTransactionEmail: start");
        EmailTemplate template = emailTemplateRepository.findByEmailTemplateId("RECONNOTRANSFERS");
        EmailAttributeHolder emailAttributeHolder = getEmailContentFromTemplate(template);
        setEmailAddresses(emailAttributeHolder);
        floodEmailService.sendEmail(emailAttributeHolder);
        logger.debug("createAndSendNoTransactionEmail: end");
    }


    private File createAttachment(Long fileId, Map<LoanSystem, List<ReconPremiumsRow>> premiums,
                                  Map<LoanSystem, List<ReconRefundsRow>> refunds, Date reportDate, Date forActivityDate) {
        logger.debug("createAttachment: start");
        ReconExcelFile reconExcelFile = new ReconExcelFile("", reportDate, forActivityDate);
        logger.debug("createAttachment: end");
        return reconExcelFile.generate(premiums, refunds);
    }

    private void setEmailAddresses(EmailAttributeHolder email) {
        email.addToAddress(env.getRequiredProperty("cls.proof.and.control.email.address"));
        email.addCcAddress(env.getRequiredProperty("autocopy.email.address.flood.service"));
        email.addCcAddress(env.getRequiredProperty("autocopy.email.address.ctl.flood.service"));
        email.setFromAddress(env.getRequiredProperty("from.email.address.flood.service"));
    }
}
