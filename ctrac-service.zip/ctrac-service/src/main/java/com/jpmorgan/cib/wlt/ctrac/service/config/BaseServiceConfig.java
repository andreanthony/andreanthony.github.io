package com.jpmorgan.cib.wlt.ctrac.service.config;

import com.jpmorgan.cib.wlt.ctrac.dao.config.DataSourceConfig;
import com.jpmorgan.cib.wlt.ctrac.dao.config.TMDataSourceConfig;
import org.springframework.context.annotation.*;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.ui.velocity.VelocityEngineFactoryBean;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import javax.annotation.Resource;


@Configuration
@ComponentScan(basePackages = {"com.jpmorgan.cib.wlt.ctrac.service"}, excludeFilters = { @ComponentScan.Filter(Configuration.class) })
@Import({JmsConfig.class,CachingConfig.class,  ACLConfig.class, DataSourceConfig.class, TMDataSourceConfig.class})
@EnableAspectJAutoProxy
public class BaseServiceConfig {

	private static final String PROPERTY_NAME_EMAIL_SMTP_HOST = "email.host.SMTP";
	private static final int    PROPERTY_NAME_EMAIL_SMTP_PORT = 25;
	private static final String PROPERTY_NAME_KEY_EMAIL_DEBUG = "email.key.debug";
	private static final String PROPERTY_NAME_KEY_EMAIL_SMTP_HOST = "email.key.smtp.host";
	private static final String PROPERTY_NAME_KEY_EMAIL_SMTP_SENDPARTIAL = "email.key.stmp.sendpartial";

	@Resource
	private Environment env;

	@Bean
	public VelocityEngineFactoryBean velocityEngineFactory() {
		VelocityEngineFactoryBean velocityEngineFactory = new VelocityEngineFactoryBean();
		velocityEngineFactory.setResourceLoaderPath("classpath:task-templates/,classpath:email-templates/");
		return velocityEngineFactory;
	}

	@Bean
	public JavaMailSender emailSender() {
		 JavaMailSenderImpl sender = new JavaMailSenderImpl();
		 sender.setHost(env.getRequiredProperty(PROPERTY_NAME_EMAIL_SMTP_HOST));
		 sender.setPort(PROPERTY_NAME_EMAIL_SMTP_PORT);
		 sender.getJavaMailProperties().setProperty(env.getRequiredProperty(PROPERTY_NAME_KEY_EMAIL_DEBUG),"TRUE");
		 sender.getJavaMailProperties().setProperty(env.getRequiredProperty(PROPERTY_NAME_KEY_EMAIL_SMTP_HOST),env.getRequiredProperty(PROPERTY_NAME_EMAIL_SMTP_HOST));
		 sender.getJavaMailProperties().setProperty(env.getRequiredProperty(PROPERTY_NAME_KEY_EMAIL_SMTP_SENDPARTIAL),"TRUE");
		 return sender;
	}


	@Bean(name="messageSource")
	public ResourceBundleMessageSource messageSource() {

		ResourceBundleMessageSource source = new ResourceBundleMessageSource();
		source.setBasename(env.getRequiredProperty("message.source.basename"));
		source.setUseCodeAsDefaultMessage(true);
		return source;
	}

	@Bean
	@Primary
	public LocalValidatorFactoryBean localValidatorFactoryBean() {
		LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
		validator.setValidationMessageSource(messageSource());
		return validator;
	}
}
