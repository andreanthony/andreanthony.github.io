package com.jpmorgan.cib.wlt.ctrac.service.backdate;

import java.math.BigDecimal;
import java.util.Date;

public interface BankPortionRule {

	/**
	 * @return the portion of the premium that the bank shall pay
	 */
	BigDecimal calculateBankPremiumAmount(Date effectiveDate, Date expirationDate, BigDecimal totalPremiumAmount, Date disbursementDate);
	
	/**
	 * @return the number of days for which total premium is being paid
	 */
	int calculateTotalPremiumPeriod(Date effectiveDate, Date expirationDate);
	
	/**
	 * @return the number of days of premium that the bank shall pay
	 */
	int calculateBankPremiumDays(Date effectiveDate, Date expirationDate, Date disbursementDate);
	
	/**
	 * @return the portion of the refund that will be refunded to the bank
	 */
	BigDecimal calculateBankRefundAmount(BigDecimal borrowerPremiumAmount, BigDecimal totalRefundAmount);

	
}
