package com.jpmorgan.cib.wlt.ctrac.service.insurableasset.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.FloodDetermination;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.FloodDeterminationRepository;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralWorkflowParam;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.FloodDeterminationDto;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.FloodDeterminationService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collection;
import java.util.Date;
import java.util.List;

@Service
public class FloodDeterminationServiceImpl implements FloodDeterminationService {

	@Autowired
    private CalendarDayUtil calendarDayUtil;

	@Autowired
	private CollateralDocumentRepository collateralDocumentRepository;

    @Autowired
    private CtracObjectMapper ctracObjectMapper;

    @Autowired
    private FloodDeterminationRepository floodDeterminationRepository;

    @Autowired
    private CollateralDocumentService collateralDocumentService;

    @Autowired
    private CollateralDetailsStatusService collateralDetailsStatusService;

	@Autowired
	private CollateralWorkflowService collateralWorkflowService;

	@Autowired
	private PublishEventService publishEventService;

    private static final Logger logger = Logger.getLogger(FloodDeterminationServiceImpl.class);

	@Override
	@Transactional
	public FloodDeterminationDto saveFloodDetermination(
			FloodDeterminationDto floodDeterminationDto, String lineOfBusiness, CollateralEventType eventType, String userName) {
		if (!floodDeterminationDto.hasChanged()) {
		    return floodDeterminationDto;
		}
		if (floodDeterminationDto.getCollateralRid() == null) {
		    logger.error(" The floodDeterminationDto collateral ID was null or invalid");
		    throw new RuntimeException(" Invalid state exception: cannot floodDetermination without a valid collateral id");
		}
		FloodDetermination floodDeterminationToUpdate = new FloodDetermination();

		if (floodDeterminationDto.getFloodDeterminationId() != null) {
			floodDeterminationToUpdate = floodDeterminationRepository.findOne(floodDeterminationDto.getFloodDeterminationId());
		}
		floodDeterminationToUpdate.setCollateralRid(floodDeterminationDto.getCollateralRid());
		floodDeterminationToUpdate = CtracBaseEntity.deproxy(floodDeterminationToUpdate, FloodDetermination.class);
		ctracObjectMapper.map(floodDeterminationDto, floodDeterminationToUpdate);
		FloodDetermination savedDetermination = floodDeterminationRepository.saveAndFlush(floodDeterminationToUpdate);

		floodDeterminationDto.setFloodDeterminationId(savedDetermination.getRid());
		floodDeterminationDto.refreshAuditUpdate(savedDetermination);
		floodDeterminationDto.saveACopy();
		if (eventType != null) {
			publishEventService.publishSFHDFEvent(floodDeterminationDto.getOrderNumber(), floodDeterminationDto.getCollateralRid(),
					lineOfBusiness, eventType, userName, floodDeterminationDto.getDateOfDetermination());
		}

        logger.debug(" save saveFloodDetermination end : determination id is : " + floodDeterminationDto.getRid());
		return floodDeterminationDto;
	}

	@Override
	public void deleteFloodDeterminations(
			Collection<FloodDeterminationDto> floodDeterminations) {
		if (floodDeterminations == null || floodDeterminations.isEmpty()) {
			return;
		}

		for (FloodDeterminationDto floodDetermination : floodDeterminations) {
			try {
				floodDeterminationRepository.delete(floodDetermination.getFloodDeterminationId());
			} catch (Exception e) {
                logger.error(e.getMessage(), e);
			}
		}

	}

	@Override
	@Transactional
	public void deleteFloodDetermination(FloodDeterminationDto floodDetermination) {
		Long determinationId = floodDetermination.getFloodDeterminationId();
		floodDeterminationRepository.delete(determinationId);
		collateralDetailsStatusService.saveSectionStatus(floodDetermination.getCollateralRid());
	}

	@Override
	public void deleteFloodDeterminationsByIds(
			Collection<Long> floodDeterminationIds) {
		if (floodDeterminationIds == null || floodDeterminationIds.isEmpty()) {
			return;
		}

		for (Long Id : floodDeterminationIds) {
			try {
				floodDeterminationRepository.delete(Id);
			} catch (Exception e) {
                logger.error(e.getMessage(), e);
			}
		}

	}

	@Override
	public Collection<FloodDeterminationDto> findFloodDeterminationByCollateral(Long collateralRid) {
		return null;
	}

	@Override
	@Transactional
	public void persistFloodDeterminationSection(CollateralDetailsMainDto collateralDetailsMainDto,
			FloodDeterminationDto floodDeterminationDto, String action) {
		if("delete".equals(action)){
			deleteFloodDetermination(floodDeterminationDto);
			publishEventService.publishSFHDFEvent(floodDeterminationDto.getOrderNumber(), collateralDetailsMainDto.getCollateralDto().getRid(),
					collateralDetailsMainDto.getCollateralDto().getPrimaryLoan().getLineOfBusiness(),
					CollateralEventType.DELETED, null, floodDeterminationDto.getDateOfDetermination());

			collateralDetailsMainDto.getFloodDeterminationSectionDto().setPendingVerificationFloodDetermination(new FloodDeterminationDto());
		} else {
			CollateralDto collateralDto = collateralDetailsMainDto.getCollateralDto();
			Long collateralId = collateralDto.getRid();
	    	List<MultipartFile> floodDeterminationFile = collateralDocumentService.fetchAttachedDocuments("Fiat_" + collateralId.toString());

	    	CollateralDocument collateralDocument = null;
	    	if (floodDeterminationDto.getDeterminationDocument() == null) {
	    		floodDeterminationDto.setDeterminationDocument(new CollateralDoc());
	    	}
	    	if (floodDeterminationDto.getDeterminationDocument().getDocRid() != null) {
	    		Long docRid = floodDeterminationDto.getDeterminationDocument().getDocRid();
	    		collateralDocument = collateralDocumentRepository.findOne(docRid);
	    	}

	    	Date documentDate = null;
	    	if (!StringUtils.isBlank(floodDeterminationDto.getDateOfDetermination())) {
	    	    try {
	    	    	documentDate = DateConverter.convert(floodDeterminationDto.getDateOfDetermination());
	    	    } catch (Exception e) {
	    	    	logger.error(e.getMessage(), e);
				}
	    	}

	    	if (floodDeterminationFile != null && !floodDeterminationFile.isEmpty()) {
    			 collateralDocument = collateralDocumentService.updateCollateralDocument(floodDeterminationFile.get(0), collateralDocument,
    		     		    CtracAppConstants.SFHDF_DOCUMENT_IDENTIFIER, documentDate, collateralId);
    			 floodDeterminationDto.getDeterminationDocument().setDocRid(collateralDocument.getRid());
    			 floodDeterminationDto.getDeterminationDocument().setFileName(collateralDocument.getFileNameWithExt());
	    	}

	    	floodDeterminationDto.setVerificationDate(DateConverter.convert(new Date()));
            CollateralEventType collateralEventType = floodDeterminationDto.getRid() != null
                    ? CollateralEventType.EDITED
                    : CollateralEventType.ADDED;
            saveFloodDetermination(floodDeterminationDto, collateralDetailsMainDto.getCollateralDto().getPrimaryLoan().getLineOfBusiness(),
                        collateralEventType, null);
			CollateralWorkflowParam result = collateralDetailsStatusService.advanceSection(
	    			collateralDto, collateralDetailsMainDto.getTmParams(),
	    			collateralDetailsMainDto.getFloodDeterminationSectionDto().getSectionStatusDto(),
	    			CollateralScreenAction.EDIT);
	    	collateralWorkflowService.triggerCollateralWorkflow(result);
		}
	}

	@Override
	@Transactional
	public void verifyFloodDeterminationSection(CollateralDetailsMainDto collateralDetailsMainDto) {
		// Get the pending and verified FloodDeterminationDtos
		FloodDeterminationDto pendingDto = collateralDetailsMainDto.getFloodDeterminationSectionDto().getPendingVerificationFloodDetermination();
		boolean pendingDtoHasChanged= pendingDto.hasChanged();
		// Nothing to be verified
		if (pendingDto == null) {
			return;
		}
		FloodDeterminationDto verifiedDto = collateralDetailsMainDto.getFloodDeterminationSectionDto().getActiveFloodDetermination();

		// Update the FloodDeterminations and persist changes
		pendingDto.setVerificationDate(DateConverter.convert(new Date()));
		if (verifiedDto != null && verifiedDto.getDateOfDetermination() != null) {
			Date verifiedDate = DateConverter.convert(verifiedDto.getDateOfDetermination());
			Date pendingDate = DateConverter.convert(pendingDto.getDateOfDetermination());
			if (verifiedDate.before(pendingDate)) {
				pendingDto.setStatus(CoverageRequirementStatus.VERIFIED.name());
				verifiedDto.setStatus(CoverageRequirementStatus.INACTIVE.name());
				collateralDetailsMainDto.getFloodDeterminationSectionDto().setActiveFloodDetermination(pendingDto);
				collateralDetailsMainDto.getFloodDeterminationSectionDto().getInactiveFloodDetermination().add(verifiedDto);
			} else {
				pendingDto.setStatus(CoverageRequirementStatus.INACTIVE.name());
				collateralDetailsMainDto.getFloodDeterminationSectionDto().getInactiveFloodDetermination().add(pendingDto);
			}
			saveFloodDetermination(verifiedDto,collateralDetailsMainDto.getCollateralDto().getPrimaryLoan().getLineOfBusiness(),
					null,null);
		} else {
			pendingDto.setStatus(CoverageRequirementStatus.VERIFIED.name());
			collateralDetailsMainDto.getFloodDeterminationSectionDto().setActiveFloodDetermination(pendingDto);
		}
		//Pending is not pending anymore
		collateralDetailsMainDto.getFloodDeterminationSectionDto().setPendingVerificationFloodDetermination(new FloodDeterminationDto());

		//LCP-3313
		pendingDto.setDeterminationDocument(null);
		if(pendingDtoHasChanged) {
			publishEventService.publishSFHDFEvent(pendingDto.getOrderNumber(), collateralDetailsMainDto.getCollateralDto().getRid(),
					collateralDetailsMainDto.getCollateralDto().getPrimaryLoan().getLineOfBusiness(),
					CollateralEventType.EDITED, null, pendingDto.getDateOfDetermination());
		}
		saveFloodDetermination(pendingDto,collateralDetailsMainDto.getCollateralDto().getPrimaryLoan().getLineOfBusiness(),
				CollateralEventType.VERIFIED,null);

		// Advance collateral section statuses
		CollateralWorkflowParam result  = collateralDetailsStatusService.advanceSection(
				collateralDetailsMainDto.getCollateralDto(), collateralDetailsMainDto.getTmParams(),
				collateralDetailsMainDto.getFloodDeterminationSectionDto().getSectionStatusDto(),
				CollateralScreenAction.VERIFY);

		boolean isZoneOut = !pendingDto.isInFloodZone() && verifiedDto != null && verifiedDto.isInFloodZone();
		result.setReadyForCoverageComputation(isZoneOut);

		collateralWorkflowService.triggerCollateralWorkflow(result);
	}

	@Override
	@Transactional
	public FloodDeterminationDto createFloodDetermination(FloodRemapItem floodRemapItem) {
		FloodDeterminationDto newFloodDeterminationDto = new FloodDeterminationDto();
		newFloodDeterminationDto.setCollateralRid(floodRemapItem.getCollateral().getRid());
		CollateralDoc collateralDoc =
				collateralDocumentService.getCollateralDocByRid(floodRemapItem.getFloodDetermination().getRid());
		newFloodDeterminationDto.setDeterminationDocument(collateralDoc);
		newFloodDeterminationDto.setStatus(CoverageRequirementStatus.VERIFIED.name());
		newFloodDeterminationDto.setVerificationDate(DateConverter.convert(calendarDayUtil.getCurrentReferenceDate()));

		FloodRemap floodRemap = floodRemapItem.getFloodRemap();

		floodRemap = CtracBaseEntity.deproxy(floodRemap, FloodRemap.class);
		//user flood determination date for corelogic and service link . For manual leave it as system date
		if(null !=floodRemap.getDeterminationDate())
		{
			newFloodDeterminationDto.setDateOfDetermination(DateConverter.convert(floodRemap.getDeterminationDate()));
		}
		else
		{
			newFloodDeterminationDto.setDateOfDetermination(DateConverter.convert(calendarDayUtil.getCurrentReferenceDate()));

		}

		//change for corelogic lomar fix
		if (("OUT".equals(floodRemapItem.getRemapCategory()) && (null !=(floodRemap.getLomarDate()))))
		{
			newFloodDeterminationDto.setDateOfMapChange(DateConverter.convert(floodRemap.getLomarDate()));
		}
		else
		{
			newFloodDeterminationDto.setDateOfMapChange(DateConverter.convert(floodRemap.getRevisedMapDate()));
		}
		newFloodDeterminationDto.setFloodZone(floodRemap.getRevisedFloodZone());
		newFloodDeterminationDto.setLoanIdentifier(floodRemap.getLoanNumber());
		newFloodDeterminationDto.setOrderNumber(floodRemap.getReqNum());
		newFloodDeterminationDto.setVendor(floodRemap.getSourceSystem());

		checkForVerifiedFloodDetermination(newFloodDeterminationDto);
		return  saveFloodDetermination(newFloodDeterminationDto,floodRemap.getLineOfBusiness(),CollateralEventType.ADDED, "System");
	}

	private void checkForVerifiedFloodDetermination(FloodDeterminationDto newFloodDeterminationDto) {
		FloodDetermination verifiedFloodDetermination = floodDeterminationRepository.findByCollateralRidAndStatus(
				newFloodDeterminationDto.getCollateralRid(), CoverageRequirementStatus.VERIFIED.name());
		if (verifiedFloodDetermination != null) {
			DateTime verifiedDate =new DateTime(verifiedFloodDetermination.getDateOfDetermination()).withTimeAtStartOfDay();
			DateTime pendingDate = new DateTime(DateConverter.convert(newFloodDeterminationDto.getDateOfDetermination())).withTimeAtStartOfDay();
			if (pendingDate.isBefore(verifiedDate)) {
				newFloodDeterminationDto.setStatus(CoverageRequirementStatus.INACTIVE.name());
			} else {
				newFloodDeterminationDto.setStatus(CoverageRequirementStatus.VERIFIED.name());
				verifiedFloodDetermination.setStatus(CoverageRequirementStatus.INACTIVE.name());
			}
			floodDeterminationRepository.save(verifiedFloodDetermination);
		}
	}

}
