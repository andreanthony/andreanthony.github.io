package com.jpmorgan.cib.wlt.ctrac.service.impl;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProofOfCoverageWorkItemRelationType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.BorrowerCancelItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BorrowerCancelItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.FloodRemapItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCovWorkItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.CancelWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
@Service
public class CancelWorkflowServiceImpl implements CancelWorkflowService {
	private static final Logger logger = Logger.getLogger(CancelWorkflowServiceImpl.class);
	@Autowired InsuranceMngtService insuranceMngtService;
	@Autowired ProofOfCovWorkItemRepository ProofOfCovWorkItemRepository;
	@Autowired ProofOfCoverageRepository proofOfCoverageRepository;
	@Autowired PerfectionTaskRepository perfectionTaskRepository;
	@Autowired TMService tmService;
	@Autowired CollateralManagementService collateralManagementService;
	@Autowired FloodRemapItemRepository floodRemapItemRepository;
	@Autowired CollateralInsuranceRepository collateralInsuranceRepository;
	@Autowired CollateralItemRepository collateralItemRepository;
	@Autowired CollateralWorkflowService collateralWorkflowService;
	@Autowired DateCalculator dateCalculator;
	@Autowired BorrowerCancelItemRepository borrowerCancelItemRepository;
	
	
	@Override 
	@Transactional
	public void cancelRequestingCoverageWorkflow(Long collateralRid, Long existingPolicyRid) {
		logger.info("cancelRequestingCoverageWorkflow collateralRid:" + collateralRid + "policyRid:" + existingPolicyRid);
		Set<PerfectionTask> tasks = collateralWorkflowService.getRequiredCoverageRequestTasks(collateralRid);
		if(tasks == null || tasks.isEmpty()){
			return;
		}
		PerfectionTask requestCoverageTask = tasks.iterator().next();
		if(hasPendingBorrowerCancelWorkflow(requestCoverageTask) || hasPendingRemapWorkflow(requestCoverageTask) || haveOtherPoliciesExpiringWithoutRenewal(collateralRid, existingPolicyRid)){
			logger.info("There are other worklow pending for request coverage task:" + requestCoverageTask.getRid() +"collateralRid:" + collateralRid + "policyRid:" + existingPolicyRid);
			return;
		}
		collateralWorkflowService.cancelRequiredCoverageRequestWorkflow(collateralRid);
		logger.info("cancelRequestingCoverageWorkflow:: END");
	}

	/**
	 * 1. Cancel all active tasks in the renewal workflow including: Call Agent 1st, 2nd, 3rd tasks 
	 * 
	 * 2. Cancel any related pending tasks in task queue
	 */
	
	@Override
	@Transactional
	public void cancelRenewalOrReplacementWorkflow(Long proofOfCoverageRid) {
		try {
			if(proofOfCoverageRid == null){
				return;
			}
			List<ProofOfCovWorkItem> proofOfCovWorkItemList = ProofOfCovWorkItemRepository.findByProofOfCoverageRidAndItemType(proofOfCoverageRid, ProofOfCoverageWorkItemRelationType.RENEWAL_TO_POLICY.toString());
			if(proofOfCovWorkItemList == null ||  proofOfCovWorkItemList.size() == 0){
				return;
			}
			for(ProofOfCovWorkItem proofOfCovWorkItem: proofOfCovWorkItemList){
				WorkItem renewalItem = proofOfCovWorkItem.getWorkItem();
				//1. Cancel all active tasks that are related with the renewal item
				List<PerfectionTask> perfectionTaskList = perfectionTaskRepository.findByWorkItemAndTaskStatusIn(renewalItem, TaskStatus.getActiveStatus());
				for(PerfectionTask perfectionTask : perfectionTaskList){
					tmService.cancelTask(perfectionTask);
				}
			}
		} catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		} catch (Exception ex) {			
			throw new CTracApplicationException("E0146", CtracErrorSeverity.APPLICATION, ex);
		}
	}
	@Override
	public boolean hasPendingBorrowerCancelWorkflow(PerfectionTask requestCoverageTask) {
		List<BorrowerCancelItem> cancelBorrowerItemList = borrowerCancelItemRepository.findByCoverageRequestTaskRid(requestCoverageTask.getRid());
		logger.debug("hasPendingBorrowerCancelWorkflow size:" + cancelBorrowerItemList.size());
		return cancelBorrowerItemList != null && cancelBorrowerItemList.size() > 0;
	}
	
	private boolean hasPendingRemapWorkflow(PerfectionTask requestCoverageTask) {
		List<FloodRemapItem> floodRemapItems = floodRemapItemRepository.findByCoverageRequestTaskRid(requestCoverageTask.getRid());
		logger.debug("hasPendingRemapWorkflow size:" + floodRemapItems.size());
		return floodRemapItems != null && floodRemapItems.size() > 0;
	}


	private boolean haveOtherPoliciesExpiringWithoutRenewal(Long collateralRid, Long proofOfCoverageRid) {
		List<CollateralInsuranceViewData> collateralInsuranceViewData = collateralInsuranceRepository.findByCollateralRid(collateralRid);
		for(CollateralInsuranceViewData collateralInsuranceData: collateralInsuranceViewData){
			Long otherPolicyRid = collateralInsuranceData.getProofOfCoverage().getRid();
			if(!otherPolicyRid.equals(proofOfCoverageRid) && collateralInsuranceData.getProofOfCoverage().getPolicyStatus_().isExpiring()){
				//Check if this policy has a renewal new policy 
				if(proofOfCoverageRepository.findByParentPolicyRid(otherPolicyRid).isEmpty()){
					logger.debug("haveOtherPoliciesExpiringWithoutRenewal: true other policy rid: " + otherPolicyRid);
					return true;
				}
			}
		}
		logger.debug("haveOtherPoliciesExpiringWithoutRenewal: false");
		return false;
	}
	
	/*
	 * List<String> workflowSteps =  Arrays.asList(FIAT_REQUESTED.getName(), FIAT_NOT_RECEIVED.getName());
		CollateralItem collateralItem = collateralWorkflowService.getActiveCollateralItem(collateralRid, workflowSteps);
		//remap requested required coverage document before expiring policy workflow does
		if(PerfectionItemSubType.REMAP == collateralItem.getPerfectionSubType_()){
			return true;
		}
		List<FloodRemapItem> remapItems = floodRemapItemRepository.findByCollateralRid(collateralRid);
		if(remapItems == null || remapItems.size() == 0){
			return false;
		}
		for(FloodRemapItem floodRemapItem: remapItems){
			if(remapWorkflowRequestedAfterRenewal(floodRemapItem, proofOfCoverageRid)){
				return true;
			}
		}
		return false;
	 */
	

}
