package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.util.ArrayList;
import java.util.Collection;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;

public class FloodDeterminationSectionDto extends SectionDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private FloodDeterminationDto activeFloodDetermination = new FloodDeterminationDto();
	private FloodDeterminationDto pendingVerificationFloodDetermination = new FloodDeterminationDto();
	private Collection<FloodDeterminationDto> inactiveFloodDetermination = new ArrayList<FloodDeterminationDto>();
	
	private Collection<LookUpCode> vendors;
	private Boolean hasFloodZone = false;

	public FloodDeterminationSectionDto(){
		this.sectionStatusDto = new SectionStatusDto();
		sectionStatusDto.setSectionId(CollateralDetailsSection.FLOOD_HAZARD_DETERMINATION_FORM);
	}
	
	public FloodDeterminationDto getActiveFloodDetermination() {
		return activeFloodDetermination;
	}

	public void setActiveFloodDetermination(
			FloodDeterminationDto activeFloodDetermination) {
		this.activeFloodDetermination = activeFloodDetermination;
	}

	public FloodDeterminationDto getPendingVerificationFloodDetermination() {
		return pendingVerificationFloodDetermination;
	}

	public void setPendingVerificationFloodDetermination(
			FloodDeterminationDto pendingVerificationFloodDetermination) {
		this.pendingVerificationFloodDetermination = pendingVerificationFloodDetermination;
	}

	public Collection<FloodDeterminationDto> getInactiveFloodDetermination() {
		return inactiveFloodDetermination;
	}

	public void setInactiveFloodDetermination(
			Collection<FloodDeterminationDto> inactiveFloodDetermination) {
		this.inactiveFloodDetermination = inactiveFloodDetermination;
	}

	public Collection<LookUpCode> getVendors() {
		return vendors;
	}

	public void setVendors(Collection<LookUpCode> vendors) {
		this.vendors = vendors;
	}


	public Boolean getHasFloodZone() {
		return hasFloodZone;
	}

	public void setHasFloodZone(Boolean hasFloodZone) {
		this.hasFloodZone = hasFloodZone;
	}
}