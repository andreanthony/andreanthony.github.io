package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;


public class WorkflowDetailsDTO extends BaseDto implements Serializable {

	private static final long serialVersionUID = 859294593233416626L;

	private Long rid;

	private Long taskRid;
	private String taskId;
	private String taskType;
	private String taskStatus;
	private String workflowStep;
	private String wakeUpDate;
	private Long workItemRid;
	private String perfectionType;
	private String perfectionSubType;
	private String initiationDate;
	private String workflowId;
	private String itemCollateralRelation;
	private Long collateralRid;
	private Long proofOfCoverageRid;
	
//    private TaskType taskType;     
//    private TaskStatus taskStatus;
//    private WorkflowStateDefinition workflowStep;
//    private PerfectionItemType perfectionType;
//    private PerfectionItemSubType perfectionSubType;
//    private String initiationDate;

	private WorkflowDetailsDTO loadTimeValue;

	public WorkflowDetailsDTO() {
        super();
    }
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WorkflowDetailsDTO other = (WorkflowDetailsDTO) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}
	
	public boolean hasChanged(){
		if (this.loadTimeValue == null || this.getRid() == null) {
			return true;
		}
		return !deepEquals(this.loadTimeValue);
	}

	public void saveACopy() {
        try {
            this.loadTimeValue = this.clone();
        } catch (CloneNotSupportedException swallow) {}
	}

	private boolean deepEquals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WorkflowDetailsDTO other = (WorkflowDetailsDTO) obj;
		if (taskId == null) {
			if (other.taskId != null)
				return false;
		} else if (!taskId.equals(other.taskId))
			return false;
		if (taskType == null) {
			if (other.taskType != null)
				return false;
		} else if (!taskType.equals(other.taskType))
			return false;
		if (taskStatus == null) {
			if (other.taskStatus != null)
				return false;
		} else if (!taskStatus.equals(other.taskStatus))
			return false;
		if (workflowStep == null) {
			if (other.workflowStep != null)
				return false;
		} else if (!workflowStep.equals(other.workflowStep))
			return false;
		if (wakeUpDate == null) {
			if (other.wakeUpDate != null)
				return false;
		} else if (!wakeUpDate.equals(other.wakeUpDate))
			return false;
		if (perfectionType == null) {
			if (other.perfectionType != null)
				return false;
		} else if (!perfectionType.equals(other.perfectionType))
			return false;
		if (perfectionSubType == null) {
			if (other.perfectionSubType != null)
				return false;
		} else if (!perfectionSubType.equals(other.perfectionSubType))
			return false;
		if (initiationDate == null) {
			if (other.initiationDate != null)
				return false;
		} else if (!initiationDate.equals(other.initiationDate))
			return false;
		if (collateralRid == null) {
			if (other.collateralRid != null)
				return false;
		} else if (!collateralRid.equals(other.collateralRid))
			return false;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}
	
	@Override
	protected WorkflowDetailsDTO clone() throws CloneNotSupportedException {
		return (WorkflowDetailsDTO) super.clone();
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getWakeUpDate() {
		return wakeUpDate;
	}

	public void setWakeUpDate(String wakeUpDate) {
		this.wakeUpDate = wakeUpDate;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public Long getTaskRid() {
		return taskRid;
	}

	public void setTaskRid(Long taskRid) {
		this.taskRid = taskRid;
	}

	public Long getWorkItemRid() {
		return workItemRid;
	}

	public void setWorkItemRid(Long workItemRid) {
		this.workItemRid = workItemRid;
	}


	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getTaskType() {
		return taskType;
	}

	public String getInitiationDate() {
		return initiationDate;
	}

	public void setInitiationDate(String initiationDate) {
		this.initiationDate = initiationDate;
	}

	public String getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(String workflowId) {
		this.workflowId = workflowId;
	}

	public String getItemCollateralRelation() {
		return itemCollateralRelation;
	}

	public void setItemCollateralRelation(String itemCollateralRelation) {
		this.itemCollateralRelation = itemCollateralRelation;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getWorkflowStep() {
		return workflowStep;
	}

	public void setWorkflowStep(String workflowStep) {
		this.workflowStep = workflowStep;
	}

	public String getPerfectionType() {
		return perfectionType;
	}

	public void setPerfectionType(String perfectionType) {
		this.perfectionType = perfectionType;
	}

	public String getPerfectionSubType() {
		return perfectionSubType;
	}

	public void setPerfectionSubType(String perfectionSubType) {
		this.perfectionSubType = perfectionSubType;
	}

	public WorkflowDetailsDTO getLoadTimeValue() {
		return loadTimeValue;
	}

	public void setLoadTimeValue(WorkflowDetailsDTO loadTimeValue) {
		this.loadTimeValue = loadTimeValue;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

}
