package com.jpmorgan.cib.wlt.ctrac.service.helper;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRAcceptedPolicyEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.email.EmailDataDto;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.email.impl.EmailAlertSender;
import com.jpmorgan.cib.wlt.ctrac.service.ews.adapter.ExchangeWebServiceAdapterImpl;
import com.jpmorgan.cib.wlt.ctrac.service.validator.EmailAddressValidator;
import microsoft.exchange.webservices.data.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.file.Files;
import java.util.*;

import static org.apache.commons.lang.StringUtils.isNotBlank;


@Component
public class CtracEmailSender implements EmailAlertSender, EmailSender {

	@Autowired
	JavaMailSender emailSender;

	@Resource
	private Environment env;
	
	@Autowired
	private EmailAddressValidator emailAddressValidator;
	
	@Autowired
	public ExchangeWebServiceAdapterImpl exchangeWebServiceAdapter;
	
	private static final Logger logger = LoggerFactory.getLogger(CtracEmailSender.class);

	@Override
	public void sendAlertEmail(String toAddress, String ccAddress, String subject, String emailBody,
			List<File> attachments, Importance importance) {
		EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
		emailAttributeHolder.setSubject(subject);
		emailAttributeHolder.setFromAddress(env.getRequiredProperty("from.email.address.ctrac.system"));
		emailAttributeHolder.addToAddress(toAddress);
		emailAttributeHolder.addCcAddress(ccAddress);
		emailAttributeHolder.setEmailBody(emailBody);
		emailAttributeHolder.setAttachments(attachments);
		sendInternalEmailThroughEWS(emailAttributeHolder, importance);
	}
	
	/**
	 * sends exception email to FT and PO team
	 * @param subject
	 * @param emailBody
	 * @param attachments
	 */
	@Override
	public void sendExceptionEmailToDevTeam(String subject, String emailBody, List<File> attachments) {
		sendAlertEmail(env.getRequiredProperty("policy.insurance.request.toalertemail"),
				env.getRequiredProperty("product.owner.team.email"), subject, emailBody, attachments, Importance.Normal);
	}

	@Override
	public void sendAlertEmailToFloodTeam(String subject, String emailBody, Importance importance) {
		sendAlertEmail(env.getRequiredProperty("autocopy.email.address.flood.service"),
				env.getRequiredProperty("product.owner.team.email")+";"+env.getRequiredProperty("autocopy.email.address.ctl.flood.service"), 
				subject, emailBody, null, importance);
	}

	@Override
	public void sendEmailToFloodTeam(String subject, String emailBody, List<File> attachments) {
		sendAlertEmail(env.getRequiredProperty("autocopy.email.address.flood.service"),
				env.getRequiredProperty("product.owner.team.email")+";"+env.getRequiredProperty("autocopy.email.address.ctl.flood.service"),
				subject, emailBody, attachments, null);
	}

	@Override
	public void sendEmail(final EmailAttributeHolder emailAttributeHolder) {
		sendEmail(emailAttributeHolder, false);
	}
	
	private void sendEmail(final EmailAttributeHolder emailAttributeHolder, boolean isRetry) {

		MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				String serverEnv = env.getActiveProfiles()[0];
				logger.debug("Server env is: " + serverEnv);
				mimeMessage.setHeader("X-App-Volt", getVoltageFlag(emailAttributeHolder));
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, "UTF-8");

				if (isNotBlank(emailAttributeHolder.getFromAddress())) {
					message.setFrom(emailAttributeHolder.getFromAddress());
				} else {
					throw new CTracApplicationException("E0142", CtracErrorSeverity.CRITICAL);
				}

				removeFaxAddresses(emailAttributeHolder);

				Set<String> toAddresses = emailAttributeHolder.getToAddresses();
				if (CollectionUtils.isNotEmpty(toAddresses)) {
					message.setTo(toAddresses.toArray(new String[toAddresses.size()]));
				}

                Set<String> ccAddresses = emailAttributeHolder.getCcAddresses();
                if (CollectionUtils.isNotEmpty(ccAddresses)) {
                    message.setCc(ccAddresses.toArray(new String[ccAddresses.size()]));
                }

				Set<String> bccAddresses = emailAttributeHolder.getBccAddresses();
				if (CollectionUtils.isNotEmpty(bccAddresses)) {
					message.setBcc(bccAddresses.toArray(new String[bccAddresses.size()]));
				}

				if (serverEnv != null && !serverEnv.equalsIgnoreCase("PROD")) {
					message.setSubject("TEST EMAIL (" + serverEnv.toUpperCase() + ").  PLEASE IGNORE. " + emailAttributeHolder.getSubject());
					message.setText("This is a test email.  PLEASE IGNORE. <br></br>" + emailAttributeHolder.getEmailBody(), true);
				} else {
					message.setSubject(emailAttributeHolder.getSubject());
					message.setText(emailAttributeHolder.getEmailBody(), true);
				}

				if (emailAttributeHolder.getFiles() != null) {
					for (final MultipartFile multipartFile : emailAttributeHolder.getFiles()) {
						// determines if there is an attached file, attach it to
						// the e-mail
						String attachName = multipartFile.getOriginalFilename();
						if (!attachName.equals("")) {
							message.addAttachment(attachName, new InputStreamSource() {
								@Override
								public InputStream getInputStream() throws IOException {
									return multipartFile.getInputStream();
								}
							});
						}
					}
				}
				
				if (emailAttributeHolder.getSingleFileAttachment() != null) {
					final File singleFileAttachment = emailAttributeHolder.getSingleFileAttachment();
					attach(message, singleFileAttachment);
				}
				
				if(emailAttributeHolder.getAttachments() != null){
					for(File file: emailAttributeHolder.getAttachments()){
						attach(message, file);
					}
				}
			}

			private void attach(MimeMessageHelper message, final File singleFileAttachment) throws MessagingException {
				String attachName = singleFileAttachment.getName();
				if (StringUtils.isNotBlank(attachName)) {
					message.addAttachment(attachName, singleFileAttachment);
				}
			}
		};

		try {
			emailSender.send(mimeMessagePreparator);
			logger.info("Email \"{}\" sent successfully to {}", emailAttributeHolder.getSubject(),
					StringUtils.join(emailAttributeHolder.getToAddresses(),';'));
		} catch (Exception e) {
			if (isRetry) {
				logger.error("CRITICAL_CTRAC_ERROR: Can't send email after retry");
				if (emailAttributeHolder.getEmailTemplate() != null) {
					logger.error("emailTemplateRid=" + emailAttributeHolder.getEmailTemplate().getRid());
				} else {
					logger.error("No email template provided");
				}
			} else {
				logger.error("Unable to send email \"{}\" to {}", emailAttributeHolder.getSubject(),
						StringUtils.join(emailAttributeHolder.getToAddresses(),';'),
						e);
				emailAttributeHolder.getToAddresses().clear();
				emailAttributeHolder.getCcAddresses().clear();
				emailAttributeHolder.getBccAddresses().clear();
                emailAttributeHolder.setFromAddress(env.getRequiredProperty("from.email.address.ctrac.system"));
                // FIXME: should be based on collateral rids; what if none?
				emailAttributeHolder.addToAddress(env.getRequiredProperty("from.email.address.flood.service"));
				String newSubject = "UNDELIVERABLE - " + emailAttributeHolder.getSubject();
				emailAttributeHolder.setSubject(newSubject);
				sendEmail(emailAttributeHolder, true);
			}
		}
	}

	   public static EmailAttributeHolder createEmailContent(EmailDataDto emailTemplateData, EmailTemplate emailTemplate) {
	       
		   logger.debug("createEmailContent: Begin () "); 
		   String emailVmTemplate = emailTemplate.getEmailVmTemplate();
	        HashMap<String, Object> velocityContextMap = new HashMap<String, Object>();
	        velocityContextMap.put("emailData", emailTemplateData);
	        VelocityContext velocityContext = new VelocityContext(velocityContextMap);
	        // Writer object to be populated by velocity template
	        StringWriter emailBody = new StringWriter();
	        //String object to hold the error information produced while evaluating velocity template 
	        String logTag = "";
	        // Populate the email body using the template read from database
	        boolean emilDataGenSuccess = Velocity.evaluate(velocityContext, emailBody, logTag, emailVmTemplate);

	        if (emilDataGenSuccess == false || !logTag.equals("")) {
	            logger.error(ErrorCodeToMessageConverter.convertToMessage("E0115", CtracErrorSeverity.CRITICAL) + ": "+ logTag);
	            throw new CTracApplicationException("E0115", CtracErrorSeverity.CRITICAL);
	        }
	        EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
	        String subject = (String) velocityContext.get("subject");
	        
	        // FIXME: this is a short-term fix for zone out, property pledged with no exposure
	        if ("ZIONORISK".equals(emailTemplate.getEmailTemplateId()) &&
	        		CtracAppConstants.I2O.equalsIgnoreCase(emailTemplateData.getRemapType()) &&
	        		subject.contains("Property Re-Mapped Into a Flood Zone")) {
	        	subject = subject.replace("Into", "Out of");
	        }
	        
	        emailAttributeHolder.setSubject(subject);
	        emailAttributeHolder.setEmailBody(emailBody.toString());
	        emailAttributeHolder.setEmailTemplate(emailTemplate);
	        
	        logger.debug("createEmailContent: Success: End () "); 
	        return emailAttributeHolder;
	    }

	/**
	 * if external email address exists in any to, cc, bcc fields, return "Yes" as the flag
	 * 
	 * else return "No"
	 * 
	 * @param emailAttributeHolder
	 * @return
	 */
	protected String getVoltageFlag(EmailAttributeHolder emailAttributeHolder) {
		boolean areAllInternalToEmailAddresses = true;
		boolean areAllInternalCcEmailAddresses = true;
		boolean areAllInternalBccEmailAddresses = true;

		if (CollectionUtils.isNotEmpty(emailAttributeHolder.getToAddresses())) {
			areAllInternalToEmailAddresses = emailAddressValidator.doesNotContainExternalDomain(emailAttributeHolder.getToAddresses());
		}
		if (CollectionUtils.isNotEmpty(emailAttributeHolder.getCcAddresses())) {
			areAllInternalCcEmailAddresses = emailAddressValidator.doesNotContainExternalDomain(emailAttributeHolder.getCcAddresses());
		}
		if (CollectionUtils.isNotEmpty(emailAttributeHolder.getBccAddresses())) {
			areAllInternalBccEmailAddresses = emailAddressValidator.doesNotContainExternalDomain(emailAttributeHolder.getBccAddresses());
		}

		if (areAllInternalToEmailAddresses && areAllInternalCcEmailAddresses && areAllInternalBccEmailAddresses) {
			return "No";
		} else {
			return "Yes";
		}
	}
	
	//added this method - for exceptionEmails
	public static EmailAttributeHolder createEmailContentForExceptionEmails(BIRExceptionEmailDTO birExceptionEmailDTO,EmailTemplate emailTemplate){
		String emailVmTemplate = emailTemplate.getEmailVmTemplate();
		HashMap<String, Object> velocityContextMap = new HashMap<String, Object>();
		velocityContextMap.put("birExceptionEmailDTO", birExceptionEmailDTO);
        VelocityContext velocityContext = new VelocityContext(velocityContextMap);
        
        StringWriter emailBody = new StringWriter();
        String logTag = "";
        boolean emilDataGenSuccess = Velocity.evaluate(velocityContext, emailBody, logTag, emailVmTemplate);
        if (emilDataGenSuccess == false || !logTag.equals("")) {
            logger.error(ErrorCodeToMessageConverter.convertToMessage("E0115", CtracErrorSeverity.CRITICAL) + ": "+ logTag);
            throw new CTracApplicationException("E0115", CtracErrorSeverity.CRITICAL);
        }      
		EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
		emailAttributeHolder.setSubject((String) velocityContext.get("subject"));
        emailAttributeHolder.setEmailBody(emailBody.toString());
        emailAttributeHolder.setEmailTemplate(emailTemplate);
		return emailAttributeHolder;
	}

	public static EmailAttributeHolder createEmailContentForNoExceptionEmails(BIRAcceptedPolicyEmailDTO birAcceptedPolicyEmailDTO,EmailTemplate emailTemplate){
		String emailVmTemplate = emailTemplate.getEmailVmTemplate();
		HashMap<String, Object> velocityContextMap = new HashMap<String, Object>();
		velocityContextMap.put("birAcceptedPolicyEmailDTO", birAcceptedPolicyEmailDTO);
        VelocityContext velocityContext = new VelocityContext(velocityContextMap);
        
        StringWriter emailBody = new StringWriter();
        String logTag = "";
        boolean emilDataGenSuccess = Velocity.evaluate(velocityContext, emailBody, logTag, emailVmTemplate);
        if (emilDataGenSuccess == false || !logTag.equals("")) {
            logger.error(ErrorCodeToMessageConverter.convertToMessage("E0115", CtracErrorSeverity.CRITICAL) + ": "+ logTag);
            throw new CTracApplicationException("E0115", CtracErrorSeverity.CRITICAL);
        }      
		EmailAttributeHolder emailAttributeHolder = new EmailAttributeHolder();
		emailAttributeHolder.setSubject((String) velocityContext.get("subject"));
        emailAttributeHolder.setEmailBody(emailBody.toString());
        emailAttributeHolder.setEmailTemplate(emailTemplate);
		return emailAttributeHolder;
	}

	@Override
	public void sendInternalEmailThroughEWS(final EmailAttributeHolder emailAttributeHolder, Importance importance) {
		logger.trace("Inside sendInternalEmailThroughEWS");
		String serverEnv = env.getActiveProfiles()[0];
		exchangeWebServiceAdapter.iniExchangeWebService();
		ExchangeService exchangeService = exchangeWebServiceAdapter.getExchangeService();
        EmailMessage message = buildInternalEmail(emailAttributeHolder, importance, exchangeService, serverEnv);
		try {
            message.send();
			logger.info("Email \"{}\" sent successfully to {}", emailAttributeHolder.getSubject(),
					StringUtils.join(emailAttributeHolder.getToAddresses(),';'));
		} catch (Exception e) {
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0327", emailAttributeHolder.getCtracErrorSeverity()));
			logger.error("Unable to send email \"{}\" to {} through EWS.  Attempting to resend with javamail", emailAttributeHolder.getSubject(),
					StringUtils.join(emailAttributeHolder.getToAddresses(),';'),
					e);
			sendEmail(emailAttributeHolder);
		}
	}

	protected EmailMessage buildInternalEmail(final EmailAttributeHolder emailAttributeHolder, Importance importance, ExchangeService service, String serverEnv) {
        EmailMessage message = null;
	    try {
            message = new EmailMessage(service);
			if (importance != null) {
				message.setImportance(importance);
			}
			if (isNotBlank(emailAttributeHolder.getFromAddress())) {
				message.setFrom(EmailAddress.getEmailAddressFromString(emailAttributeHolder.getFromAddress()));
				logger.debug("From email address:" + emailAttributeHolder.getFromAddress());
			} else {
				throw new CTracApplicationException("E0142", CtracErrorSeverity.TRIVIAL);
			}

			removeFaxAddresses(emailAttributeHolder);

			addEmailAddresses(message.getToRecipients(), emailAttributeHolder.getToAddresses());
			addEmailAddresses(message.getCcRecipients(), emailAttributeHolder.getCcAddresses());
			addEmailAddresses(message.getBccRecipients(), emailAttributeHolder.getBccAddresses());

			if (serverEnv != null && !serverEnv.equalsIgnoreCase("PROD")) {
				message.setSubject("TEST EMAIL (" + serverEnv.toUpperCase() + ").  PLEASE IGNORE. " + emailAttributeHolder.getSubject());
				message.setBody(MessageBody.getMessageBodyFromText("This is a test email.  PLEASE IGNORE. <br></br>" + emailAttributeHolder.getEmailBody()));
				logger.debug("Email subject and email body set for test env");
			} else {
				message.setSubject(emailAttributeHolder.getSubject());
				message.setBody(MessageBody.getMessageBodyFromText(emailAttributeHolder.getEmailBody()));
				logger.debug("Email subject and email body set for PROD env");
			}

			if (emailAttributeHolder.getFiles() != null) {
				logger.debug("multiple attachments");
				for (final MultipartFile multipartFile : emailAttributeHolder.getFiles()) {
					// determines if there is an attached file, attach it to the e-mail
					String attachName = multipartFile.getOriginalFilename();
					if (!attachName.equals("")) {

						//message.getAttachments().addFileAttachment(attachName, multipartFile.getInputStream());
						//fix for LCP-3235 // attachment not opening
						message.getAttachments().addFileAttachment(attachName, multipartFile.getBytes());

					}
				}
			}
			if (emailAttributeHolder.getSingleFileAttachment() != null) {
				logger.debug("single attachment");
				final File singleFileAttachment = emailAttributeHolder.getSingleFileAttachment();
				attachFile(message, singleFileAttachment);
			}
			if (emailAttributeHolder.getAttachments() != null) {
				for (File file : emailAttributeHolder.getAttachments()) {
					attachFile(message, file);
				}
			}
		} catch (Exception e) {
            throw new CTracApplicationException("E0351",CtracErrorSeverity.APPLICATION);
		}
		return message;
	}

    void attachFile(EmailMessage message, File file) throws IOException, ServiceLocalException {
        byte[] data = Files.readAllBytes(file.toPath());
        String attachName = file.getName();
        if (StringUtils.isNotBlank(attachName)) {
            message.getAttachments().addFileAttachment(attachName, data);
        }
    }

     void addEmailAddresses(EmailAddressCollection emailAddressCollection, Set<String> emailAddresses) {
        if (emailAddresses != null  && !emailAddresses.isEmpty()) {
            for (String ccAddress : emailAddresses) {
                emailAddressCollection.add(ccAddress);
            }
        }
    }
	
	/*
	 * This method utilized Exchange Web Service to Send Email. This can be only utilized to send internal email only, as it doesn't support Voltage encryption
	 * through this API. This method utilize functional account to send email and that functional account should have permission on SharedMailBox to send email.
	 * SharedMailBox owner can assign permission to this functional account.
	 * This method should be utilized to send INTERNAL EMAIL ONLY.  
	 */
	public void sendInternalEmailThroughEWS(final EmailAttributeHolder emailAttributeHolder) {
		sendInternalEmailThroughEWS(emailAttributeHolder, Importance.Normal);
	}

	void removeFaxAddresses(EmailAttributeHolder emailAttributeHolder) {
		if(!"PROD".equalsIgnoreCase(env.getActiveProfiles()[0])) {
			removeFaxAddresses(emailAttributeHolder.getToAddresses());
			removeFaxAddresses(emailAttributeHolder.getCcAddresses());
			removeFaxAddresses(emailAttributeHolder.getBccAddresses());
		}
	}

	private void removeFaxAddresses(Collection<String> addresses) {
		if(CollectionUtils.isNotEmpty(addresses)) {
			String address = null;
			Iterator<String> iter = addresses.iterator();
			while(iter.hasNext()) {
				address = iter.next();
				if (address.endsWith(env.getRequiredProperty("eFax.domain"))) {
					logger.debug("Removing fax address not allowed in {} environment: {}",
							env.getActiveProfiles()[0], address);
					iter.remove();
				}
			}
		}
	}
}
