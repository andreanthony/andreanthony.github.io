package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FileContent;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.FileContentRepository;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;

@Service
public class CollateralDocumentServiceImpl implements CollateralDocumentService {

	@Autowired private CollateralDocumentRepository collateralDocumentRepository;
	@Autowired private CtracObjectMapper ctracObjectMapper;
	@Autowired private FileContentRepository fileContentRepository;
	
	@Autowired
	@Qualifier("emailAttachmentsBucket")
	private EmailAttachmentsBucket emailAttachmentsBucket;

	private static final Logger logger = Logger.getLogger(CollateralDocumentServiceImpl.class);

	@Override
	public CollateralDoc getCollateralDocByRid(Long collateralDocumentRid) {
		// FIXME: Why do we even have CollateralDoc class......???
		CollateralDocument collateralDocument = collateralDocumentRepository.findOne(collateralDocumentRid);
		CollateralDoc collateralDoc = ctracObjectMapper.map(collateralDocument, CollateralDoc.class);
		return collateralDoc;
	}
	
	@Override
	public List<CollateralDoc> getCollateralDocs(Long collateralId) {
		List<CollateralDocument> collateralDocs = collateralDocumentRepository.findByCollateralRid(collateralId);
		List<CollateralDoc> collateralDocDtos = (List<CollateralDoc>) ctracObjectMapper.mapAsList(collateralDocs, CollateralDoc.class);
		return collateralDocDtos;
	}
	
	@Override
	public List<CollateralDoc> getCollateralDocs(Long collateralId, String docType) {
		List<CollateralDocument> collateralDocs = collateralDocumentRepository.findByCollateralRidAndDocIdentifier(collateralId, docType);
		List<CollateralDoc> collateralDocDtos = (List<CollateralDoc>) ctracObjectMapper.mapAsList(collateralDocs, CollateralDoc.class);
		return collateralDocDtos;
	}

	@Override
	@Transactional
	@Deprecated  //replaced with saveDocument
	public void removeCollateralDoc(List<CollateralDoc> files) {
		logger.debug("removeCollateralDoc::BEGIN");
		if (files == null || files.isEmpty()) {
			return;
		}
		for (CollateralDoc doc : files) {
			CollateralDocument collateralDoc = collateralDocumentRepository.findOne(doc.getDocRid());
			if (collateralDoc != null) {
				collateralDocumentRepository.delete(collateralDoc);
			}
		}
		logger.debug("removeCollateralDoc::END");
	}

    @Override
    @Transactional
    public CollateralDocument saveCollateralDocument(MultipartFile multipartFile, String documentIdentifier, Date documentDate, Long collateralRid) {
    	logger.debug("saveCollateralDocument::BEGIN");
    	CollateralDocument collateraldoc = saveCollateralDocument(null, multipartFile, documentIdentifier, collateralRid, documentDate, null);
		logger.debug("saveCollateralDocument::BEGIN");
		return collateraldoc;
    }
    
    @Override
	public CollateralDocument saveCollateralDocument(File file, String documentIdentifier, Date documentDate, Long collateralRid) {
    	logger.debug("saveCollateralDocument::BEGIN");
    	CollateralDocument collateraldoc = saveCollateralDocument(null, file, documentIdentifier, collateralRid, documentDate, null);
		logger.debug("saveCollateralDocument::BEGIN");
		return collateraldoc;
	}

    @Override
    @Transactional
    public Collection<CollateralDocument> saveCollateralDocuments(Collection<MultipartFile> multiPartFiles,
    		String documentIdentifier,Date documentDate,  Long collateralRid) {
		if (multiPartFiles == null) {
		    return null;
		}
		Collection<CollateralDocument> result = new HashSet<CollateralDocument>();
		for (MultipartFile multiPartFile : multiPartFiles) {
		    result.add(saveCollateralDocument(multiPartFile, documentIdentifier,documentDate, collateralRid) );
		}
		return result;
    }
    
    @Override
	@Transactional
	public CollateralDocument savePolicyDocument(MultipartFile multipartFile, Long proofOfCoverageRid) {
    	logger.debug("savePolicyDocument::START");
    	CollateralDocument policyDocument = saveCollateralDocument(null, multipartFile, CtracAppConstants.POLICY_DOCUMENT_IDENTIFIER, null, null, proofOfCoverageRid);
    	logger.debug("savePolicyDocument::END");
		return collateralDocumentRepository.save(policyDocument);
	}

	@Override
	@Transactional
	public Collection<CollateralDocument> savePolicyDocuments(Collection<MultipartFile> multipartFiles, Long proofOfCoverageRid) {
		Collection<CollateralDocument> policyDocuments = new HashSet<CollateralDocument>();
		for (MultipartFile multipartFile : multipartFiles) {
			policyDocuments.add(savePolicyDocument(multipartFile, proofOfCoverageRid));
		}
		return policyDocuments;
	}

    @Override
    @Transactional
    public List<MultipartFile> fetchAttachedDocuments(String BucketKey) {
		EmailAttachments emailAttachments = emailAttachmentsBucket.popEmailAttachments(BucketKey);
		if (emailAttachments == null) {
		    logger.debug("attachment is null, no file found");
		    return null;
		}
		return emailAttachments.getAllFilesAsList();
    }
    
    @Override
    @Transactional
    public CollateralDocument updateCollateralDocument(MultipartFile multipartFile, CollateralDocument collateralDocument, String documentIdentifier,Date documentDate, Long collateralRid) {
    	logger.debug("saveDocument::BEGIN");
    	collateralDocument =  saveCollateralDocument(collateralDocument, multipartFile, documentIdentifier, collateralRid, documentDate, null);
		logger.debug("saveDocument::END");
		return collateralDocument;
    }
    
    @Override
    @Transactional
    public CollateralDocument updateCollateralDocument(MultipartFile multipartFile, CollateralDocument collateralDocument, String documentIdentifier,Date documentDate, Long collateralRid, Long proofOfCoverageRid) {
    	logger.debug("saveDocument::BEGIN");
    	collateralDocument =  saveCollateralDocument(collateralDocument, multipartFile, documentIdentifier, collateralRid, documentDate, proofOfCoverageRid);
		logger.debug("saveDocument::END");
		return collateralDocument;
    }
    
	@Override
	public CollateralDocument saveCollateralDocument(File file, String documentIdentifier, Long proofOfCoverageRid) {
		logger.debug("saveCollateralDocument::BEGIN");
    	CollateralDocument collateraldoc = saveCollateralDocument(null, file, documentIdentifier, null, null, proofOfCoverageRid);
		logger.debug("saveCollateralDocument::BEGIN");
		return collateraldoc;
	}
    
    private CollateralDocument saveCollateralDocument(CollateralDocument collateralDocument, File file, String documentIdentifier, Long collateralRid, Date documentDate, Long proofOfCoverageRid) {
    	try {
    		byte[] fileBytes = FileUtils.readFileToByteArray(file);
    		collateralDocument = saveCollateralDocument(collateralDocument, file.getName(), fileBytes, documentIdentifier, collateralRid, documentDate, proofOfCoverageRid);
    	} catch (Exception e) {
    		logger.error(e.getMessage(), e);
    		throw new CTracApplicationException("E0135", CtracErrorSeverity.CRITICAL);
    	}
    	return collateralDocument;
    }
    
    private CollateralDocument saveCollateralDocument(CollateralDocument collateralDocument, MultipartFile multipartFile, String documentIdentifier, Long collateralRid, Date documentDate, Long proofOfCoverageRid) {
    	try {
    		collateralDocument = saveCollateralDocument(collateralDocument, multipartFile.getOriginalFilename(), multipartFile.getBytes(), documentIdentifier, collateralRid, documentDate, proofOfCoverageRid);
    	} catch (Exception e) {
    		logger.error(e.getMessage(), e);
    		throw new CTracApplicationException("E0135", CtracErrorSeverity.CRITICAL);
    	}
    	return collateralDocument;
    }

    private CollateralDocument saveCollateralDocument(CollateralDocument collateralDocument, String fileName, byte[] fileBytes, String documentIdentifier, Long collateralRid, Date documentDate, Long proofOfCoverageRid) {
    	logger.debug("saveCollateralDocument::START");
    	if (fileBytes == null || fileBytes.length == 0) {
		    return null;
		}
    	if (collateralDocument == null) {
    		collateralDocument = new CollateralDocument();
    	}
    	FileContent fileContent = saveFileContent(collateralDocument, fileBytes);
    	collateralDocument.setFileNameWithExt(fileName);
    	collateralDocument.setFileName(FilenameUtils.removeExtension(fileName));
    	collateralDocument.setCollateralRid(collateralRid);
		collateralDocument.setDocIdentifier(documentIdentifier);
		collateralDocument.setDocumentDate(documentDate);
		collateralDocument.setProofOfCoverageRid(proofOfCoverageRid);
		collateralDocument.setFileContent(fileContent);
		collateralDocument.setDocumentDate(new Date());
		collateralDocument = collateralDocumentRepository.save(collateralDocument);
		logger.debug("saveCollateralDocument::END");
		return collateralDocument;
    }

	private FileContent saveFileContent(CollateralDocument collateralDocument, byte[] fileBytes) {
		logger.debug("saveFileContent::START");
		FileContent fileContent = collateralDocument.getFileContent();
		if (fileContent == null) {
			fileContent = new FileContent();
		}
		fileContent.setFileContent(fileBytes);
		fileContent = fileContentRepository.save(fileContent);
		logger.debug("saveFileContent::END");
		return fileContent;
	}
    
    @Override
    @Transactional
    public void removeCollateralDocument(Long collateralId, String docType){
    	List<CollateralDocument> collateralDocs = collateralDocumentRepository.findByCollateralRidAndDocIdentifier(collateralId, docType);
    	collateralDocumentRepository.delete(collateralDocs);
    }
    
	@Override
	public void removeCollateralDocument(Long documentRid) {
		collateralDocumentRepository.delete(documentRid);		
	}

	@Override
	public void removeCollateralDocuments(List<CollateralDocument> collateralDocs) {
		collateralDocumentRepository.delete(collateralDocs);
	}

	@Override
	public List<CollateralDocument> getCollateralDocument(List<MultipartFile> multipartFiles, Long collateralRid, Long proofOfCoverageRid, Date documentDate, String documentIdentifier) {
		logger.debug("saveCollateralDocument::START");
		List<CollateralDocument> collateralDocuments = new ArrayList<CollateralDocument>();
		try{
	    	if (multipartFiles == null || multipartFiles.size() == 0) {
			    return null;
			}
	    	for(MultipartFile file: multipartFiles){
	    		CollateralDocument collateralDocument = new CollateralDocument();
	        	FileContent fileContent = new FileContent();
	            fileContent.setFileContent(file.getBytes());
	            collateralDocument.setFileContent(fileContent);
	        	collateralDocument.setFileNameWithExt(file.getOriginalFilename());
	        	collateralDocument.setFileName(FilenameUtils.removeExtension(file.getOriginalFilename()));
	        	collateralDocument.setCollateralRid(collateralRid);
	    		collateralDocument.setDocIdentifier(documentIdentifier);
	    		collateralDocument.setDocumentDate(documentDate);
	    		collateralDocument.setProofOfCoverageRid(proofOfCoverageRid);
	    		collateralDocument.setFileContent(fileContent);
	    		collateralDocuments.add(collateralDocument);
	    	}
		}
		catch(Exception e){
			logger.error(e.getMessage());
		}
		return collateralDocuments;
	}
	
	@Override
	public void saveCollateralDocuments(List<CollateralDocument> collateralDocs){
		collateralDocumentRepository.save(collateralDocs);
	}

	@Override
	public List<CollateralDoc> getPolicyDocs(Long proofOfCoverageRid, String docType) {
		List<CollateralDocument> collateralDocs = collateralDocumentRepository.findByProofOfCoverageRidAndDocIdentifier(proofOfCoverageRid, docType);
		List<CollateralDoc> collateralDocDtos = (List<CollateralDoc>) ctracObjectMapper.mapAsList(collateralDocs, CollateralDoc.class);
		return collateralDocDtos;
	}
	
	@Override
	public CollateralDoc getUniquePolicyDoc(Long proofOfCoverageRid, String docType) {
		List<CollateralDocument> collateralDocs = collateralDocumentRepository.findByProofOfCoverageRidAndDocIdentifier(proofOfCoverageRid, docType);
		List<CollateralDoc> collateralDocDtos = ctracObjectMapper.mapAsList(collateralDocs, CollateralDoc.class);
		return (collateralDocDtos != null && collateralDocDtos.size()> 0)?collateralDocDtos.get(0):null;
	}
	
}
