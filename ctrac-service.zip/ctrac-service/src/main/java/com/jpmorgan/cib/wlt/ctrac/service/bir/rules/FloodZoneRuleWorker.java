package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import static com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion.ACCEPTABLE;
import static com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion.ACTION_REQUIRED;
import static com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion.NONE;

import java.util.Iterator;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;

public class FloodZoneRuleWorker extends AbstractBIRRuleWorker {

	public FloodZoneRuleWorker(String key) {
		super(key, true, true);
	}
	
	protected boolean ruleShouldRun(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		return true;	
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		GenericProofOfCoverageDTO floodInsuranceData = borrowerInsuranceReviewData.getProofOfCoverageData();
		if (floodInsuranceData.getInsuranceType() != InsuranceType.FLOOD) {
			return;
		}
		for (BIRCollateralDetailsDTO birCollateralDetails :
				borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
			if (borrowerInsuranceReviewData.isDisabled(key, birCollateralDetails.getCollateralRid(), null)) {
				continue;
			}
			BIRRuleConclusionDTO floodZoneConclusion = birCollateralDetails.getBirRuleConclusions().get(key);
			if ("No".equals(floodInsuranceData.getFloodZonesListed())) {
				floodZoneConclusion.setConclusion(NONE.name());
			} else if (inHighRiskFloodZoneOrGrandfathered(birCollateralDetails)) {
				floodZoneConclusion.setConclusion(ACCEPTABLE.name());
			} else {
				floodZoneConclusion.setConclusion(ACTION_REQUIRED.name());
			}
		}
	}

	private boolean inHighRiskFloodZoneOrGrandfathered(BIRCollateralDetailsDTO birCollateralDetails) {
		return FloodZoneRuleWorker.isHighRiskFloodZone(birCollateralDetails.getPolicyFloodZone()) ||
				"Grandfathered".equals(birCollateralDetails.getGrandfathered());
	}
	
	public static boolean isHighRiskFloodZone(String floodZone) {
		if (floodZone != null && floodZone.length() > 0) {
			floodZone = 
					floodZone.trim().toUpperCase().substring(0, 1);
		}
		return "A".equals(floodZone) || "V".equals(floodZone);
	}

	@Override
	public void populateExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData) {
		Iterator<BIRCollateralDetailsDTO> collateralDetailsIter = 
				borrowerInsuranceReviewData.getCollateralDetailsMap().values().iterator();
		while (collateralDetailsIter.hasNext()) {
			BIRCollateralDetailsDTO collateralDetails = collateralDetailsIter.next();
			populateCollateralExceptionData(exceptionEmailData, collateralDetails,
					collateralDetails.getPolicyFloodZone(), collateralDetails.getCollateralFloodZone());
		}
	}

}
