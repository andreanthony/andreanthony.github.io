package com.jpmorgan.cib.wlt.ctrac.service.dto.builder;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.InsurableAssetRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.HoldDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.email.EmailDataDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.FloodInsurancePolicyDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.helper.FloodRemapVendorMinMaxRules;
import com.jpmorgan.cib.wlt.ctrac.service.helper.coverage.RequiredCoverageUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class EmailDataDtoBuilder {

    private final EmailDataDto instance;

    private InsurableAssetRepository insurableAssetRepository;
    
    private LookupCodeRepository lookupCodeRepository;
    
    private FloodRemapVendorMinMaxRules floodRemapVendorMinMaxRules = null;
    
    private LineOfBusinessService lobService = null;

    private HoldService holdService;

    private final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");

    public EmailDataDtoBuilder() {
        instance = new EmailDataDto();
        insurableAssetRepository = ApplicationContextProvider.getContext().getBean(InsurableAssetRepository.class);
        lookupCodeRepository = ApplicationContextProvider.getContext().getBean(LookupCodeRepository.class);
        floodRemapVendorMinMaxRules = new FloodRemapVendorMinMaxRules(lookupCodeRepository);
        lobService = ApplicationContextProvider.getContext().getBean(LineOfBusinessService.class);
        holdService = ApplicationContextProvider.getContext().getBean(HoldService.class);
    }

    public EmailDataDto buildLpEmailDto(Collateral collateral, WorkItem triggerworkItem, List<? extends ProofOfCoverageDTO> lpCoveragesToIssues) {

        setCollateralLoanAndBorrowerInfo(triggerworkItem, collateral);
        
        populateLpCoverageDetails(lpCoveragesToIssues);

        return instance;
    }

    /**
     * use updated/verified vendor data to populate the email properties
     * 
     * @param triggerworkItem
     * @return
     */
    public EmailDataDto buildNoRiskPreLpMarketEmailDTO(FloodRemapItem triggerworkItem) {

        String cursur = triggerworkItem.getFloodRemap().getRevisedFloodZone();
        instance.setFloodZone(cursur);
        
        cursur = triggerworkItem.getFloodRemap().getStatusChange();
        instance.setRemapType(cursur);

        cursur = triggerworkItem.getWorkFlowID();
        instance.setTaskUniqueID(cursur); 

        cursur = triggerworkItem.getFloodRemap().getBorrowerName();
        instance.setBorrowerName(cursur);

        cursur = triggerworkItem.getFloodRemap().getAddress();
        instance.setPropertyAddress(cursur);

        cursur = triggerworkItem.getFloodRemap().getCityStateZip(", ");
        instance.setCityStateZip(cursur);

        return instance;
    }

    public EmailDataDto buildAtRiskPreLpMarketEmailDTO(WorkItem triggerworkItem, Collateral collateral) {

        setCollateralLoanAndBorrowerInfo(triggerworkItem, collateral);
        
        // for now this is only applicable to remap Item ...
        if (triggerworkItem instanceof FloodRemapItem) {
            FloodRemapItem remap = (FloodRemapItem) triggerworkItem;
            boolean exposureExist = remap.getPreLenderPlaceDetails().doesExposureExists();
            instance.setExposureExist(exposureExist);
        }
        return instance;
    }
  
    //for comibine LP email notification for cancellation and initation
    public EmailDataDto buildLpMarketCancellationEmailDto(Collateral collateral, List<? extends ProofOfCoverageDTO> lpPoliciesToCancel, List<? extends ProofOfCoverageDTO> lpPoliciesToIssue ) {
        
        setCollateralLoanAndBorrowerInfo(null, collateral);
        instance.setTaskUniqueID(collateral.getRid().toString());
        String cursur = collateral.getAddress().getStreetAddressAndUnit();
        if (!StringUtils.isBlank(cursur)) {
            instance.setPropertyAddress(cursur);
        }

        cursur = collateral.getAddress().getCityStateZipCode();
        if (!StringUtils.isBlank(cursur)) {
            instance.setCityStateZip(cursur);
        }

        CancellationReason cancellationReason = lpPoliciesToCancel.get(0).getCancellationReason();
        if (cancellationReason != null) {
            instance.setCancellationReason(cancellationReason.getText());
        }
      //Changes for LCP -3697
        
        //changes for gap
		if (null != lpPoliciesToCancel.get(0).getGapBorrowerPolicyRid()) {
			ProofOfCoverageRepository proofOfCoverageRepository = ApplicationContextProvider.getContext()
					.getBean(ProofOfCoverageRepository.class);

			ViewDataRetrievalService viewDataRetrievalService = ApplicationContextProvider.getContext()
					.getBean(ViewDataRetrievalService.class);
			ProofOfCoverage BIRProofOfCoverage = proofOfCoverageRepository
					.findOne(lpPoliciesToCancel.get(0).getGapBorrowerPolicyRid());
			List<RequiredCoverageViewDto> requiredCoverages = viewDataRetrievalService
					.getRequiredCoverageByStatus(collateral.getRid(), VerificationStatus.VERIFIED.getName());
			StringBuffer requiredLPCoverageDetails = new StringBuffer();
			StringBuffer borrowerCoveragedetails = new StringBuffer();

			if (lpPoliciesToCancel.get(0).getCancellationReason()
					.equals(CancellationReason.BORROWER_POLICY_RECEIVED_AMOUNT_GAP))
			{
				instance.setGapInCoverageAmounts(true);
				for (ProvidedCoverage borrowerProvidedCoverages : BIRProofOfCoverage.getProvidedCoverages())
				{
				String buildingName = getBuildingName(requiredCoverages,
							borrowerProvidedCoverages.getInsurableAsset().getRid());
					CtracStringUtil.addValueWithSeparator(borrowerCoveragedetails, buildingName, ", ");
					CtracStringUtil
							.addValueWithSeparator(borrowerCoveragedetails,
									"$" + AmountFormatter
											.format(borrowerProvidedCoverages.getCoverageDetails().getCoverageAmount()),
									":  ");
					requiredLPCoverageDetails = setCombinedRequiredCoverageForGap(BIRProofOfCoverage, requiredCoverages,
							requiredLPCoverageDetails, borrowerProvidedCoverages);
					
					
				}
				instance.setRequiredLPCoverageGapDetails(requiredLPCoverageDetails.toString());
				instance.setBorrowerCoverageGapDetails(borrowerCoveragedetails.toString());
			} else if (lpPoliciesToCancel.get(0).getLenderPlaceReason() == LenderPlaceReason.BORROWER_POLICY_RECEIVED_DATE_LAPSE) {
				if(lpPoliciesToIssue!=null && !lpPoliciesToIssue.isEmpty())
				{	
					instance.setGapInCoverageEffectiveDates(true);
					instance.setEffectiveDateForBir(BIRProofOfCoverage.getEffectiveDate().toString());
					//combine list of effective dates from new LP policies			
					instance.setCombinedLPEffectiveDates(setCombinedLPEffectiveDates(lpPoliciesToIssue, requiredCoverages).toString()) ; 
				}
				
			}
		}
		// end changes for LCP -3697

        cursur = lpPoliciesToCancel.get(0).getCancellationEffectiveDate();
        if (!StringUtils.isBlank(cursur)) {
            instance.setCancelDate(cursur);
        }
        
        StringBuffer lpAmountsSb = new StringBuffer();
        for(ProofOfCoverageDTO lpPolicy : lpPoliciesToCancel)
        {
        	//need to add logic for the gap
            for (ProvidedCoverageDTO providedCoverageDto :lpPolicy.getProvidedCoverageDTOs()) {
            	CtracStringUtil.addValueWithSeparator(lpAmountsSb, providedCoverageDto.getDescription(), ", ");
            	CtracStringUtil.addValueWithSeparator(lpAmountsSb, providedCoverageDto.getCoverageAmount(), ":  ");
            }           
        }        
        String combinedLpPolicyAmounts = lpAmountsSb.toString();
        if (!StringUtils.isBlank(combinedLpPolicyAmounts)) {
            instance.setCombinedLpPolicyAmounts(combinedLpPolicyAmounts);
        }
        return instance;
    }
    
	private StringBuffer setCombinedRequiredCoverageForGap(ProofOfCoverage BIRProofOfCoverage,
			List<RequiredCoverageViewDto> requiredCoverages, StringBuffer requiredLPCoverageDetails,
			ProvidedCoverage borrowerProvidedCoverages) {

		for (RequiredCoverageViewDto requiredCoverageViewDto : requiredCoverages) {
			if (borrowerProvidedCoverages.getInsurableAsset().getRid()
					.equals(requiredCoverageViewDto.getInsurableAssetRid())) {
				String buildingName = requiredCoverageViewDto.getBuildingName();
				CtracStringUtil.addValueWithSeparator(requiredLPCoverageDetails, buildingName, ", ");
				if (BIRProofOfCoverage.getCoverageType_() == CoverageType.PRIMARY) {
					CtracStringUtil.addValueWithSeparator(requiredLPCoverageDetails,
							requiredCoverageViewDto.getPrimaryCoverageAmount(), ":  ");

				} else if (BIRProofOfCoverage.getCoverageType_() == CoverageType.EXCESS) {
					CtracStringUtil.addValueWithSeparator(requiredLPCoverageDetails,
							requiredCoverageViewDto.getExcessCoverageAmount(), ":  ");

				} else if (BIRProofOfCoverage.getCoverageType_() == CoverageType.PRIMARY_AND_EXCESS) {					
					BigDecimal primaryAndExcess = AmountFormatter.parse(requiredCoverageViewDto.getExcessCoverageAmount())
							.add(AmountFormatter.parse(requiredCoverageViewDto.getPrimaryCoverageAmount()));
					CtracStringUtil.addValueWithSeparator(requiredLPCoverageDetails,
							"$" + AmountFormatter.format(primaryAndExcess), ":  ");

				}
			}
		}
		return requiredLPCoverageDetails;
	}

	private String getBuildingName(List<RequiredCoverageViewDto> requiredCoverages, Long insAssetRid) {
		String buildingName = null;
		// get building name
		for (RequiredCoverageViewDto requiredCoverageViewDto : requiredCoverages) 
		{
			if (requiredCoverageViewDto.getInsurableAssetRid().equals(insAssetRid))
			{
				buildingName = requiredCoverageViewDto.getBuildingName();
			}

		}
		return buildingName;
	}

    public EmailDataDto buildLpMarketIssueWithCancellationEmailDto(Collateral collateral, List<? extends ProofOfCoverageDTO> lpPoliciesToIssueWithCancel) {
        
        setCollateralLoanAndBorrowerInfo(null, collateral);
        instance.setTaskUniqueID(collateral.getRid().toString());
        String cursor = collateral.getAddress().getStreetAddressAndUnit();
        if (!StringUtils.isBlank(cursor)) {
            instance.setPropertyAddress(cursor);
        }
        cursor = collateral.getAddress().getCityStateZipCode();
        if (!StringUtils.isBlank(cursor)) {
            instance.setCityStateZip(cursor);
        }
        populateLpCoverageDetails(lpPoliciesToIssueWithCancel);

        // there's one and only one LP policy in the list       
        ProofOfCoverageDTO lpPolicy = lpPoliciesToIssueWithCancel.get(0);
        
        if(lpPolicy.getPreviousExpiredAmount() != null) {
        	cursor = AmountFormatter.format(lpPolicy.getPreviousExpiredAmount());
            if (!StringUtils.isBlank(cursor)) {
                instance.setCombinedAmount(cursor);
            }
    	}
        // effective date of the policy to issue is the same as cancellation date
        cursor = lpPolicy.getEffectiveDate();
        if (!StringUtils.isBlank(cursor)) {
            instance.setPolicyExpirationDate(cursor);
        }      
        return instance;
    }

    void setCollateralLoanAndBorrowerInfo(WorkItem triggerworkItem, Collateral collateral) {

        Long collateralId = collateral.getRid();
        instance.setCtracCorrID(collateralId.toString());
        instance.setTaskUniqueID(collateralId.toString());

        // LCP 3139 - Collateral - Collateral Screen - Loan/Borrower - Appearance in screens
        String cursur = getPipeSeparatedPrimaryLoanBorrowerNames(collateral.getPreferredLoan());

        if (!StringUtils.isBlank(cursur)) {
            instance.setBorrowerName(cursur);
        }

        cursur = collateral.getAddress().getFormattedFullAddress();
        if (!StringUtils.isBlank(cursur)) {
            instance.setPropertyAddress(cursur);
        }

        cursur = collateral.getPreferredLoan().getLoanNumber();
        if (!StringUtils.isBlank(cursur)) {
            instance.setLoanNumber(cursur);
        }
        
        cursur = collateral.getPreferredLoan().getLineOfBusiness();
        if (!StringUtils.isBlank(cursur)) {
            instance.setLineOfBusiness(cursur);
            
            LineOfBusinessDTO lob = lobService.findByCode(cursur);
            if (lob != null) {
            	cursur = lob.getCodeConst();
            }
            instance.setLineOfBusinessCodeConst(cursur);
        }
        
        if (triggerworkItem!=null && triggerworkItem instanceof FloodRemapItem) {
            FloodRemapItem remap = (FloodRemapItem) triggerworkItem;
            cursur = remap.getFloodRemap().getStatusChange();
            if (!StringUtils.isBlank(cursur)) {
                instance.setRemapType(cursur);
            }
        }
    }

	private String getPipeSeparatedPrimaryLoanBorrowerNames(Loan loan) {
		if (loan == null) {
			return "";
		}
		StringBuilder sb = new StringBuilder("");
		 
	    for (LoanBorrower borrower:loan.getLoanBorrowers()) {
			if (StringUtils.isBlank(borrower.getBorrower().getName())) {
				continue;
			}
			if (sb.length() != 0) {
				sb.append(" | ");
			}
			sb.append(borrower.getBorrower().getName());
		}
		return sb.toString();
	}

	private void populateLpCoverageDetails(List<? extends ProofOfCoverageDTO> lpCoveragesToIssues) {

        List<FloodInsurancePolicyDto> floodInsurancePolicyDtoList = new ArrayList<FloodInsurancePolicyDto>();
        
        for (ProofOfCoverageDTO lpPolicyToIssue: lpCoveragesToIssues) {
            FloodInsurancePolicyDto floodInsurancePolicyDto = new FloodInsurancePolicyDto();
            
            String cursor =lpPolicyToIssue.getEffectiveDate().toString();
            floodInsurancePolicyDto.setEffectiveDate(cursor);

            //Assuming there is always only one LP policy per building or per structure ...,
            ProvidedCoverageDTO coverageToProvide = lpPolicyToIssue.getProvidedCoverageDTOs().get(0);
			cursor = coverageToProvide.getInsurableAssetDTO().getDescription();
            floodInsurancePolicyDto.setBuildingName(cursor);

            InsurableAsset insurableAsset = insurableAssetRepository.findOne(coverageToProvide.getInsurableAssetDTO().getRid());
            insurableAsset = CtracBaseEntity.deproxy(insurableAsset, InsurableAsset.class);
            floodInsurancePolicyDto.setTotalCoverageAmount(getRequiredCoverageAmound(insurableAsset));

            String covAmount = coverageToProvide.getCoverageAmount();
            floodInsurancePolicyDto.setCoverageAmount(covAmount);

            LPConstants coverageType = LPConstants.findByInsurableAssetType(insurableAsset.getAssetType());
            floodInsurancePolicyDto.setCoverageType(coverageType.getDisplayName()); // Building||Contents
            
            floodInsurancePolicyDto.setLpCoverageType(lpPolicyToIssue.getCoverageType().getDisplayValue()); // Building||Contents
            
            BigDecimal coverageAmount = AmountFormatter.parse(covAmount);
            String covAdjustmentInd =  floodRemapVendorMinMaxRules.getCoverageAdjustementIndicator(coverageAmount, coverageType);
            floodInsurancePolicyDto.setAction(covAdjustmentInd);   //lpPolicyToIssue.getPendingLpAction();
            
            floodInsurancePolicyDto.setInputSourceType(getCoverageInputSource(insurableAsset)); // we
                                                                                                // only
            floodInsurancePolicyDto.setPropertyType(getPropertyType(insurableAsset));
            floodInsurancePolicyDto.setAssetType(insurableAsset.getAssetType_() != null ? insurableAsset.getAssetType_().getDisplayName():StringUtils.EMPTY);
            floodInsurancePolicyDto.setPolicyType(lpPolicyToIssue.getPolicyTypeDisplayName());
            floodInsurancePolicyDtoList.add(floodInsurancePolicyDto);                              
        }
        
        this.instance.setPropertyList(floodInsurancePolicyDtoList);
    }

    private String getRequiredCoverageAmound(InsurableAsset asset) {
    	BigDecimal reqCov = RequiredCoverageUtil.getValidCoverageRequirementAmount(asset, InsuranceType.FLOOD);
    	return AmountFormatter.format(reqCov);
    }
    
    //TODO: add InsuranceType as a parameter
    private String getCoverageInputSource(InsurableAsset insurableAsset) {
        String result = "";
        // we only lenderplace with fiat if we have it
        // TODO: query Required Coverage view and get the most recent verified document
        Date mostFutureDate = null;
        for (RequiredCoverage cov : insurableAsset.getRequiredCoverages()) {
            /*result = cov.getRequiredCoverageSource().getSource();
            if (CoverageInputSource.FIAT.name().equals(result)) {
                break;
            }*/
            RequiredCoverageSource reqCovSource = cov.getRequiredCoverageSource();
            Date thisDate = reqCovSource.getDocumentDate();
            if (mostFutureDate == null || (thisDate != null && thisDate.after(mostFutureDate))) {
            	mostFutureDate = thisDate;
            	String thisSource = reqCovSource.getSource();
            	if (StringUtils.isNotBlank(thisSource)) {
            		result = reqCovSource.getSource();
            	}
            }
        }
        return result;
    }
    
  //TODO: add InsuranceType as a parameter
    private String getPropertyType(InsurableAsset insurableAsset) {
        String result = "";
        // we only lenderplace with fiat if we have it
        // TODO: query Required Coverage view and get the most recent verified document
        Date mostFutureDate = null;
        for (RequiredCoverage cov : insurableAsset.getRequiredCoverages()) {
            /*result = cov.getRequiredCoverageSource().getSource();
            if (CoverageInputSource.FIAT.name().equals(result)) {
                break;
            }*/
            RequiredCoverageSource reqCovSource = cov.getRequiredCoverageSource();
            Date thisDate = reqCovSource.getDocumentDate();
            if (mostFutureDate == null || (thisDate != null && thisDate.after(mostFutureDate))) {
            	mostFutureDate = thisDate;
            	String thisSource = reqCovSource.getSource();
            	if (StringUtils.isNotBlank(thisSource)) {
            		result = cov.getPropertyType();
            	}
            }
        }
        return result;
    }
    
    //for LCP - 3697 combined email for LP cancellation and initiation
    public EmailDataDto buildLpMarketCancellationWithIssueEmailDto(Collateral collateral, List<? extends ProofOfCoverageDTO> lpPoliciesToIssueWithCancel,BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
        
        setCollateralLoanAndBorrowerInfo(null, collateral);

        String cursor = collateral.getAddress().getStreetAddressAndUnit();
        if (!StringUtils.isBlank(cursor)) {
            instance.setPropertyAddress(cursor);
        }
        cursor = collateral.getAddress().getCityStateZipCode();
        if (!StringUtils.isBlank(cursor)) {
            instance.setCityStateZip(cursor);
        }
        populateLpCoverageDetails(lpPoliciesToIssueWithCancel);

        CancellationReason cancellationReason = lpPoliciesToIssueWithCancel.get(0).getCancellationReason();
        if (cancellationReason != null) {
            instance.setCancellationReason(cancellationReason.getText());
        }
        
        cursor = lpPoliciesToIssueWithCancel.get(0).getCancellationEffectiveDate();
        if (!StringUtils.isBlank(cursor)) {
            instance.setCancelDate(cursor);
        }
        
        StringBuffer lpAmountsSb = new StringBuffer();
        for(ProofOfCoverageDTO lpPolicy : lpPoliciesToIssueWithCancel){
            for (ProvidedCoverageDTO providedCoverageDto :lpPolicy.getProvidedCoverageDTOs()) {
            	CtracStringUtil.addValueWithSeparator(lpAmountsSb, providedCoverageDto.getDescription(), ", ");
            	CtracStringUtil.addValueWithSeparator(lpAmountsSb, providedCoverageDto.getCoverageAmount(), ":  ");
            }
        }
        
        String combinedLpPolicyAmounts = lpAmountsSb.toString();
        if (!StringUtils.isBlank(combinedLpPolicyAmounts)) {
            instance.setCombinedLpPolicyAmounts(combinedLpPolicyAmounts);
        }    
        return instance;
    }

    private StringBuffer setCombinedLPEffectiveDates(List<? extends ProofOfCoverageDTO> lpPoliciesToIssue,
            List<RequiredCoverageViewDto> requiredCoverages) {
        StringBuffer conbinedLPEfffectiveDates = new StringBuffer();
        for (ProofOfCoverageDTO lpPolicyIssue : lpPoliciesToIssue) {
            for (RequiredCoverageViewDto requiredCoverageViewDto : requiredCoverages) {
                Map<Long, ProvidedCoverageDTO> lpPolicyIssueCoverageMap = lpPolicyIssue
                        .getInsurableAssetProvidedCoverageMap();
                for (Map.Entry<Long, ProvidedCoverageDTO> lpPolicyIssueCoverageEntry : lpPolicyIssueCoverageMap
                        .entrySet()) {

                    if (requiredCoverageViewDto.getInsurableAssetRid()
                            .equals(lpPolicyIssueCoverageEntry.getValue().getInsurableAssetDTO().getRid())) {
                        CtracStringUtil.addValueWithSeparator(conbinedLPEfffectiveDates,
                                lpPolicyIssueCoverageEntry.getValue().getDescription(), ", ");
                        CtracStringUtil.addValueWithSeparator(conbinedLPEfffectiveDates,
                                lpPolicyIssue.getEffectiveDate(), ":  ");

                    }
                }
            }
        }
        return conbinedLPEfffectiveDates;
    }

    public EmailDataDto buildMarketHoldEmailDto(List<HoldDetailsViewDto> holdDetailsViewDtos, WorkItem triggerworkItem, Collateral collateral) {

        setCollateralLoanAndBorrowerInfo(triggerworkItem, collateral);
        setTwoLinesAddress(collateral, instance);
        instance.setTaskUniqueID(Long.valueOf(collateral.getRid()).toString());
        for(HoldDetailsViewDto holdDetailsViewDto : holdDetailsViewDtos) {
            setHoldAssetCoverageTypeByInsurableAssetType(holdDetailsViewDto);
            Date holdPeriodExpirationDate =
                 holdService.getHoldPeriodExpirationDate(holdDetailsViewDto.getStartDate(), holdDetailsViewDto.getHoldPeriod());
            if(holdPeriodExpirationDate != null) {
                holdDetailsViewDto.setHoldPeriodExpirationDate(simpleDateFormat.format(holdPeriodExpirationDate));
            }
          }
        instance.setHoldList(holdDetailsViewDtos);
        return instance;
    }

     public void setTwoLinesAddress(Collateral collateral, EmailDataDto emailDataDto) {
        String cursor = collateral.getAddress().getStreetAddressAndUnit();
        if (!StringUtils.isBlank(cursor)) {
            emailDataDto.setPropertyAddress(cursor);
        }
        cursor = collateral.getAddress().getCityStateZipCode();
        if (!StringUtils.isBlank(cursor)) {
            emailDataDto.setCityStateZip(cursor);
        }
    }

    private void setHoldAssetCoverageTypeByInsurableAssetType(HoldDetailsViewDto holdDetailsViewDto) {
        String assetType = holdDetailsViewDto.getInsurableAssetType();
        InsurableAssetType insurableAssetType = EnumUtils.getEnum(InsurableAssetType.class,assetType);
        holdDetailsViewDto.setInsurableAssetType(insurableAssetType.getDisplayName());
        if(insurableAssetType == InsurableAssetType.BUSINESS_INCOME){
            holdDetailsViewDto.setHoldType("Waiver");
            holdDetailsViewDto.setCoverageType("Flood");
        }
    }
}
