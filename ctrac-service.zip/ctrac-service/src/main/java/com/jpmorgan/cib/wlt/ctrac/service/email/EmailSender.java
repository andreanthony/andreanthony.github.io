package com.jpmorgan.cib.wlt.ctrac.service.email;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import microsoft.exchange.webservices.data.Importance;

/**
 * Created by e704298 on 11/3/2017.
 */
public interface EmailSender {

    void sendEmail(final EmailAttributeHolder emailAttributeHolder);

    void sendInternalEmailThroughEWS(EmailAttributeHolder emailAttributeHolder, Importance importance);

}
