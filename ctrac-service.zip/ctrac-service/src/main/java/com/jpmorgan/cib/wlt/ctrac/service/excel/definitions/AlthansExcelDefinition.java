package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions;

import java.util.HashSet;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.service.excel.ColumnDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;

public class AlthansExcelDefinition {

	public static final ColumnDefinition[] ALTHANS_EXCEL_DEFINITION = {
		new ColumnDefinition("Servicing Team", "servicingTeam", FieldType.STRING),
		new ColumnDefinition("CTRAC Unique ID", "proofOfCoverageRid", FieldType.LOCK),
		new ColumnDefinition("Loan Number", "loanNumber", FieldType.STRING),
		new ColumnDefinition("Request Type", "requestType", FieldType.STRING),
		new ColumnDefinition("Policy Type", "policyType", FieldType.STRING),
		new ColumnDefinition("Property Type", "propertyType", FieldType.STRING),
		new ColumnDefinition("Borrower Name", "borrowerName", FieldType.AUTOWRAP),
		new ColumnDefinition("Borrower Mailing Address Street", "borrowerMailingAddressStreet", FieldType.STRING),
		new ColumnDefinition("Borrower Mailing Address City", "borrowerMailingAddressCity", FieldType.STRING),
		new ColumnDefinition("Borrower Mailing Address State", "borrowerMailingAddressState", FieldType.STRING),
		new ColumnDefinition("Borrower Mailing Address Zip", "borrowerMailingAddressZip", FieldType.STRING),
		new ColumnDefinition("Add'l Borrower Name(s) and Collateral Owner Name(s)", "addlBorrowersAndOwners", FieldType.AUTOWRAP),
		new ColumnDefinition("Property Street Address", "propertyAddress", FieldType.STRING),
		new ColumnDefinition("Building Name", "buildingName", FieldType.STRING),
		new ColumnDefinition("Prop Unit No.", "propertyUnitBldg", FieldType.STRING),
		new ColumnDefinition("Property City", "propertyCity", FieldType.STRING),
		new ColumnDefinition("Prop State", "propertyState", FieldType.STRING),
		new ColumnDefinition("Prop Zip", "propertyZipCode", FieldType.STRING),
		new ColumnDefinition("Flood Zone", "floodZone", FieldType.STRING),
		new ColumnDefinition("LPI Policy Eff. Date", "effectiveDate", FieldType.DATE),
		new ColumnDefinition("LPI Policy Exp. Date", "expirationDate", FieldType.DATE),
		new ColumnDefinition("Cancellation Date", "cancellationEffectiveDate", FieldType.DATE),
		new ColumnDefinition("Coverage Basis: RCV or ACV", "valueBasedOn", FieldType.STRING),
		new ColumnDefinition("Building Coverage Amount", "buildingCoverageAmount", FieldType.AMOUNT),
		new ColumnDefinition("Content Coverage Amount", "contentsCoverageAmount", FieldType.AMOUNT),
		new ColumnDefinition("Business Income Coverage Amount", "businessCoverageAmount", FieldType.AMOUNT),
		new ColumnDefinition("Comments", "comments", FieldType.STRING),
		new ColumnDefinition("Premium Amount", "premiumAmount", FieldType.AMOUNT),
		new ColumnDefinition("Refund Amount", "refundAmount", FieldType.AMOUNT)			
	};
	
	//borrower name, borrower street address
	public static final Set<Integer> COLUMNS_NOT_AUTO_SIZE = new HashSet<Integer>();
	static{
		COLUMNS_NOT_AUTO_SIZE.add(6);
		COLUMNS_NOT_AUTO_SIZE.add(11);
	}
	
}
