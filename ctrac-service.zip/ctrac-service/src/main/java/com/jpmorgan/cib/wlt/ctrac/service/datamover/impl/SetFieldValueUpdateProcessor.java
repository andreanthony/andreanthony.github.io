package com.jpmorgan.cib.wlt.ctrac.service.datamover.impl;

import java.lang.reflect.Field;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataProcessor;



/**
 * SetFieldValueUpdateProcessor will set the field's value in the target field represented by targetFieldName to targetNewValue.
 * @author n446693
 *
 */
public class SetFieldValueUpdateProcessor implements DataProcessor {
	String targetFieldName;
	Object targetNewValue;	
	/**
	 * SetFieldValueUpdateProcessor will set the field's value in the target field represented by targetFieldName to targetNewValue.
	 * @author n446693
	 *
	 */
	public SetFieldValueUpdateProcessor(String targetFieldName, Object targetNewValue) {
		super();
		this.targetFieldName = targetFieldName;
		this.targetNewValue = targetNewValue;
	}
	

	@Override
	public<Source> List<Source> apply(List<Source> sourceData)
	{
		for(Source current : sourceData){
			applySet(current);
		}
		return sourceData;
	}

	private <Source> void applySet(Source record) {			
		try {
			Field targetField = record.getClass().getDeclaredField(targetFieldName);
			targetField.setAccessible(true);
			targetField.set(record, targetNewValue);
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
