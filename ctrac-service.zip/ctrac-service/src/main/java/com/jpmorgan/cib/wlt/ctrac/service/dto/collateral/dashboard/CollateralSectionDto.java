package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;



public class CollateralSectionDto extends SectionDto{

	private static final long serialVersionUID = -8673492331661323479L;

	private List<CollateralDoc> mortgageDocs;
	
	private List<MultipartFile> newFiles;
	
	private List<CollateralDoc> mortgageDocsToBeDeleted = new ArrayList<CollateralDoc>();
	
	private Collection<LookUpCode> collateralSubTypes;

	private Boolean verificationStarted = false;
 
	public Boolean getVerificationStarted() {
		return verificationStarted;
	}
	public void setVerificationStarted(Boolean verificationStarted) {
		this.verificationStarted = verificationStarted;
	}
	public CollateralSectionDto(){
		this.sectionStatusDto = new SectionStatusDto();
		sectionStatusDto.setSectionId(CollateralDetailsSection.COLLATERAL_BASIC_DETAILS);
	}
	public List<CollateralDoc> getMortgageDocsToBeDeleted() {
		return mortgageDocsToBeDeleted;
	}

	public void setMortgageDocsToBeDeleted(List<CollateralDoc> mortgageDocsToBeDeleted) {
		this.mortgageDocsToBeDeleted = mortgageDocsToBeDeleted;
	}

	public List<CollateralDoc> getMortgageDocs() {
		return mortgageDocs;
	}

	public void setMortgageDocs(List<CollateralDoc> mortgageDocs) {
		this.mortgageDocs = mortgageDocs;
	}
	
	public Collection<LookUpCode> getCollateralSubTypes() {
		return collateralSubTypes;
	}

	public void setCollateralSubTypes(Collection<LookUpCode> collateralSubTypes) {
		this.collateralSubTypes = collateralSubTypes;
	}

	public List<MultipartFile> getNewFiles() {
		return newFiles;
	}

	public void setNewFiles(List<MultipartFile> files) {
		this.newFiles = files;
	}
	
	

}
