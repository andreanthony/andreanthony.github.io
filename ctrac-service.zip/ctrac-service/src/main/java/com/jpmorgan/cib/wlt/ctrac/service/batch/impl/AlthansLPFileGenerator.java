package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.service.helper.vendor.LPAlthansFilePropertyTypeConverter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.propertytype.AlthansPropertyType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CustomerIdentificationViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LPPolicyRequestViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CustomerIdentificationRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.LPVendorFileGenerator;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;

@Service("althansLPFileGenerator")
public class AlthansLPFileGenerator implements LPVendorFileGenerator {

	private static final Logger logger = Logger.getLogger(AlthansLPFileGenerator.class);

	@Autowired
	private CtracObjectMapper ctracObjectMapper;
	
	@Autowired
	private CustomerIdentificationRepository customerIdentificationRepository;
	
	@Autowired
	private LoanManagementService loanManagementService;

	@Autowired
	private LPAlthansFilePropertyTypeConverter lpAlthansFilePropertyTypeConverter;
	
	@Override
	@Transactional
	public Collection<LPPolicyRequest> generateLpPolicyRequest(Collection<LPPolicyRequestViewData> lpPolicyViewData) {
		Collection<LPPolicyRequest> lpPolicyRequestList = new ArrayList<LPPolicyRequest>();
		if (lpPolicyViewData == null || lpPolicyViewData.isEmpty()) {
			return lpPolicyRequestList;
		}
		
		for (LPPolicyRequestViewData lpPolicyRequestViewData : lpPolicyViewData) {
			LPPolicyRequest lpPolicyRequest = ctracObjectMapper.map(lpPolicyRequestViewData, LPPolicyRequest.class);
			lpPolicyRequest.setLenderPlaceItem(lpPolicyRequestViewData.getLenderPlaceItem());
			
			ProofOfCoverage proofOfCoverage = lpPolicyRequestViewData.getProofOfCoverage();
			lpPolicyRequest.setProofOfCoverage(proofOfCoverage);
			if (proofOfCoverage.getPolicyType_() == PolicyType.LP_GAP) {
                if(StringUtils.isNotBlank(proofOfCoverage.getLenderPlaceReason())) {
                    LenderPlaceReason lpReason = LenderPlaceReason.valueOf(proofOfCoverage.getLenderPlaceReason());
                    lpPolicyRequest.setComments(lpReason.getComment());
                }
                else {
                    // LP_GAP policy for date lapse caused by other reasons or after the policy was created
                    lpPolicyRequest.setComments(LenderPlaceReason.DATE_LAPSE.getComment());
                }
			}
			
			populateUnmappableFields(lpPolicyRequestViewData, lpPolicyRequest);
			lpPolicyRequestList.add(lpPolicyRequest);
		}
		
		return lpPolicyRequestList;
	}
	
	protected void populateUnmappableFields(LPPolicyRequestViewData lpPolicyRequestViewData, LPPolicyRequest lpPolicyRequest) {
		
		lpPolicyRequest.setRequestorName("WLS");
		
		ProofOfCoverage proofOfCoverage = lpPolicyRequestViewData.getProofOfCoverage();
		if (lpPolicyRequest.getCancellationEffectiveDate() != null) { //must be LPActions.CANCEL_LP
			lpPolicyRequest.setTransCode(getLpCancellationCode());
		} else if(LPActions.RENEW_LP == proofOfCoverage.getLpAction_()) {
			lpPolicyRequest.setTransCode(getLpRenewalCode());
		}
		else {//must be LPActions.NEW_LP
			lpPolicyRequest.setTransCode(getLpRequestCode());
		}
		
		PolicyType policyType = proofOfCoverage.getPolicyType_();
		if (policyType != null) {
			lpPolicyRequest.setCoverageType(policyType.getDisplayName());
		} else {
			lpPolicyRequest.setCoverageType(proofOfCoverage.getPolicyType());
		}

		AlthansPropertyType althansPropertyType = lpAlthansFilePropertyTypeConverter.
				convertPropertyTypeDescriptionToAlthans(lpPolicyRequest.getPropertyType());
		lpPolicyRequest.setPropertyType(althansPropertyType != null ? althansPropertyType.getDesc() : lpPolicyRequest.getPropertyType());
        
		CustomerData primaryBorrower = getPrimaryBorrower(lpPolicyRequestViewData.getLoanRid());
		if (primaryBorrower == null) {
			logger.error("No primaryBorrower found for loan: " + lpPolicyRequestViewData.getLoanRid());
			throw new CTracApplicationException("E0170", CtracErrorSeverity.CRITICAL);
		}
		lpPolicyRequest.setMortgagorAndBorrowerName(primaryBorrower.getBorrowerName()); // Borrower Name from Primary Loan (pick first non-blank one)
		AddressDto borrowerAddress = primaryBorrower.getContactDetailDto().getAddress();
		lpPolicyRequest.setMailingAddress(borrowerAddress.getFormattedAddressLine1()); // use both address and unit/building
		lpPolicyRequest.setMailingCity(borrowerAddress.getCity());
		lpPolicyRequest.setMailingState(borrowerAddress.getState());
		lpPolicyRequest.setMailingZipCode(borrowerAddress.getZipCode());
		//Remaining non-blank Borrowers and all Collateral Owners - with Pipe Separation From Borrower and Collateral Owner
		String addlBorrowersAndOwners = getAddlBorrowersAndOwners(lpPolicyRequestViewData, primaryBorrower);
		lpPolicyRequest.setAddlBorrowersAndOwners(addlBorrowersAndOwners);
		lpPolicyRequest.setPropertyAddress(lpPolicyRequestViewData.getPropertyStreet());
	}

	private String getAddlBorrowersAndOwners(LPPolicyRequestViewData lpPolicyRequestViewData,
			CustomerData primaryBorrower) {
		List<CustomerIdentificationViewData> relatedCustomers =
				customerIdentificationRepository.findByCollateralRid(lpPolicyRequestViewData.getCollateralRid());
		// TODO: sort customers for consistent ordering
		StringBuffer addlBorrowersAndOwners = new StringBuffer();
		for (CustomerIdentificationViewData customerIdentity : relatedCustomers) {
			Customer customer = customerIdentity.getCustomer();
			if (!customer.getRid().equals(primaryBorrower.getRid())) {
				CtracStringUtil.addValueWithSeparator(addlBorrowersAndOwners, customer.getName(), " | ");
			}
		}
		return addlBorrowersAndOwners.toString();
	}

	private CustomerData getPrimaryBorrower(Long loanRid) {
		Collection<CustomerData> borrowers = loanManagementService.getBorrowersByLoan(loanRid);
		if (borrowers.isEmpty()) {
			return null;
		}
		
		CustomerData primaryBorrower = null;
		for (CustomerData borrower : borrowers) {
			if (StringUtils.isNotBlank(borrower.getBorrowerName()) &&
					(primaryBorrower == null || borrower.getRid().compareTo(primaryBorrower.getRid()) < 0)) {
				primaryBorrower = borrower;
			}
		}
		if (primaryBorrower == null) {
			return borrowers.iterator().next();
		}
		return primaryBorrower;
	}

	@Override
	public String getLpRenewalCode() {
		return AlthansRequestType.RENEWAL.getDesc();
	}
	@Override
	public String getLpRequestCode() {
		return AlthansRequestType.NEW_ISSUE.getDesc();
	}

	@Override
	public String getLpCancellationCode() {
		return AlthansRequestType.CANCELLATION.getDesc();
	}

	@Override
	public boolean isNewOrRenewalPolicyRequest(String transCode) {
		return getLpRequestCode().equals(transCode) || getLpRenewalCode().equals(transCode);
	}

}
