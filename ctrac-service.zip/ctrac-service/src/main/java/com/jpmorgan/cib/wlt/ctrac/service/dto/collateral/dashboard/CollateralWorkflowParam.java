package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;


public class CollateralWorkflowParam {
	
	private CollateralDto collateralDto;

	private Long workItemRid;

	private CollateralScreenAction action;

	private boolean allVerified;
	
	private TMParams tmParams;
	
	private boolean readyForRelease;
	
	private boolean isReadyForCoverageComputation;

	public boolean isReadyForRelease() {
		return readyForRelease;
	}

	public void setReadyForRelease(boolean readyForRelease) {
		this.readyForRelease = readyForRelease;
	}

	public CollateralDto getCollateralDto() {
		return collateralDto;
	}

	public void setCollateralDto(CollateralDto collateralDto) {
		this.collateralDto = collateralDto;
	}

	public Long getWorkItemRid() {
		return workItemRid;
	}

	public void setWorkItemRid(Long workItemRid) {
		this.workItemRid = workItemRid;
	}

	public CollateralScreenAction getAction() {
		return action;
	}

	public void setAction(CollateralScreenAction action) {
		this.action = action;
	}

	public boolean isAllVerified() {
		return allVerified;
	}

	public void setAllVerified(boolean allVerified) {
		this.allVerified = allVerified;
	}

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	public boolean isReadyForCoverageComputation() {
		return isReadyForCoverageComputation;
	}

	public void setReadyForCoverageComputation(boolean isReadyForCoverageComputation) {
		this.isReadyForCoverageComputation = isReadyForCoverageComputation;
	}

}
