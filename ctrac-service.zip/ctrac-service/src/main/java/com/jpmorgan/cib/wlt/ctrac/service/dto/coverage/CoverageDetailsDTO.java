package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import java.io.Serializable;
import java.math.BigDecimal;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class CoverageDetailsDTO extends BaseDto  implements Serializable,  Cloneable {

    private static final long serialVersionUID = -4880918423120574971L;
	private static final Logger logger = Logger.getLogger(CoverageDetailsDTO.class);

    private Long rid;
    private String coverageType;     //primary//excess//gap//
    private String coverageAmount;   //this is always the edible and persisted values
    private String coverageValue;   //this is always the edible and persisted values
    private String balanceType;		// ACV, RCV
	private String valueBalanceType; // ACV, RCV

 	/**
     * this two fields(missMatchInput,missMatchVerify) are used only if the input and verify amount doesn't match
     */
    private String orginalCoverageAmount;   //on the miss-match page this hold the original input prior verify
    private String orginalCoverageValue;   //on the miss-match page this hold the original input prior verify
    private String verifyCovAmountPriorMissMatch;  //on the miss-match page this hold the value entered by the verifier
    private String verifyCovValuePriorMissMatch;  //on the miss-match page this hold the value entered by the verifier

    private String orginalBalanceType;   //on the miss-match page this hold the original input prior verify
    private String verifyBalanceTypePriorMissMatch;  //on the miss-match page this hold the value entered by the verifier
	private String orginalValueBalanceType;   //on the miss-match page this hold the original input prior verify
	private String verifyValueBalanceTypePriorMissMatch;  //on the miss-match page this hold the value entered by the verifier

    private boolean verificationCoverageAmountMissMatch = false;
    private boolean verificationCoverageValueMissMatch = false;
    private boolean verificationBalanceTypeMissMatch = false;
    private boolean verificationValueBalanceTypeMissMatch = false;

    private boolean display = true;

    private HoldDTO holdDTO;

	public HoldDTO getHoldDTO() {
		return holdDTO;
	}

	public void setHoldDTO(HoldDTO holdDTO) {
		this.holdDTO = holdDTO;
	}

	private CoverageDetailsDTO loadTimeValue;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public String getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(String coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public String getCoverageValue() {
        return coverageValue;
    }

    public void setCoverageValue(String coverageValue) {
        this.coverageValue = coverageValue;
    }


	public void setVerificationCoverageAmountMissMatch(boolean verificationCoverageAmountMissMatch) {
		this.verificationCoverageAmountMissMatch = verificationCoverageAmountMissMatch;
	}

	public void setVerificationCoverageValueMissMatch(boolean verificationCoverageValueMissMatch) {
		this.verificationCoverageValueMissMatch = verificationCoverageValueMissMatch;
	}

	public void setVerificationBalanceTypeMissMatch(boolean verificationBalanceTypeMissMatch) {
		this.verificationBalanceTypeMissMatch = verificationBalanceTypeMissMatch;
	}

	public void setVerificationValueBalanceTypeMissMatch(boolean verificationValueBalanceTypeMissMatch) {
		this.verificationValueBalanceTypeMissMatch = verificationValueBalanceTypeMissMatch;
	}

	public void setDisplay(boolean display) {
		this.display = display;
	}

	/**
     * @return the orginalCoverageAmount
     */
    public String getOrginalCoverageAmount() {
        return orginalCoverageAmount;
    }

    /**
     * @param orginalCoverageAmount the orginalCoverageAmount to set
     */
    public void setOrginalCoverageAmount(String orginalCoverageAmount) {
        this.orginalCoverageAmount = orginalCoverageAmount;
    }

    /**
     * @return the verifyCovAmountPriorMissMatch
     */
    public String getVerifyCovAmountPriorMissMatch() {
        return verifyCovAmountPriorMissMatch;
    }

    /**
     * @param verifyAmountPriorMissMatch the verifyCovAmountPriorMissMatch to set
     */
    public void setVerifyCovAmountPriorMissMatch(String verifyAmountPriorMissMatch) {
        this.verifyCovAmountPriorMissMatch = verifyAmountPriorMissMatch;
    }

    public boolean isVerificationCoverageAmountMissMatch() {
        return verificationCoverageAmountMissMatch;
    }


/**
 * @return the orginalCoverageValue
 */
public String getOrginalCoverageValue() {
    return orginalCoverageValue;
}

/**
 * @param orginalCoverageValue the orginalCoverageValue to set
 */
public void setOrginalCoverageValue(String orginalCoverageValue) {
    this.orginalCoverageValue = orginalCoverageValue;
}

/**
 * @return the verifyCovValuePriorMissMatch
 */
public String getVerifyCovValuePriorMissMatch() {
    return verifyCovValuePriorMissMatch;
}

/**
 * @param verifyValuePriorMissMatch the verifyCovValuePriorMissMatch to set
 */
public void setVerifyCovValuePriorMissMatch(String verifyValuePriorMissMatch) {
    this.verifyCovValuePriorMissMatch = verifyValuePriorMissMatch;
}

public boolean isVerificationCoverageValueMissMatch() {
    return verificationCoverageValueMissMatch;
}

    public boolean isVerificationBalanceTypeMissMatch() {
        return verificationBalanceTypeMissMatch;
    }

	public boolean isVerificationValueBalanceTypeMissMatch() {
		return verificationValueBalanceTypeMissMatch;
	}

    public boolean isDisplay() {
        return display;
    }


    public void prepareForVerify() {
    	//Only save a copy when load time value hasn't been set yet
    	if(getLoadTimeValue() == null) {
			saveACopy();
		}
		//Set the original values (Bind to separate Fields) on object from the Load time Object
        setOrginalCoverageAmount(getLoadTimeValue().getCoverageAmount());
        setOrginalCoverageValue(getLoadTimeValue().getCoverageValue());
        setOrginalBalanceType(getLoadTimeValue().getBalanceType());
        setOriginalValueBalanceType(getLoadTimeValue().getBuildingContentBalanceType());

        //Blank out the coverage amount and balance type fields for the verifier
        this.coverageAmount = null;
        this.coverageValue = null;
        this.balanceType = null;
        this.valueBalanceType = null;
    }

    public void prepareForEdit() {
    	if( this.coverageAmount==null &&  this.orginalCoverageAmount!=null){
    	     this.orginalCoverageAmount = null;
    	}

    	if( this.coverageValue==null &&  this.orginalCoverageValue!=null){
   	     	this.orginalCoverageValue = null;
   		}

    	if( this.balanceType==null &&  this.orginalBalanceType!=null){
   	     	this.balanceType = this.orginalBalanceType;
   	     	this.orginalBalanceType = null;
    	}

		if( this.valueBalanceType==null &&  this.orginalValueBalanceType!=null){
			this.valueBalanceType = this.orginalValueBalanceType;
			this.orginalValueBalanceType = null;
		}
    }


    /* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
            return true;
        }
		if (obj == null) {
            return false;
        }
		if (getClass() != obj.getClass()) {
            return false;
        }
		CoverageDetailsDTO other = (CoverageDetailsDTO) obj;
		if (rid == null) {
			if (other.rid != null) {
                return false;
            }
		} else if (!rid.equals(other.rid)) {
            return false;
        }
		return true;
	}

	public boolean hasChanged(){

		if(this.loadTimeValue ==null || this.getRid()==null){
			return true;
		}
		return !deepEquals(this.loadTimeValue);
	}

	private boolean deepEquals(Object obj) {
		if (this == obj) {
            return true;
        }
		if (obj == null) {
            return false;
        }
		if (getClass() != obj.getClass()) {
            return false;
        }
		CoverageDetailsDTO other = (CoverageDetailsDTO) obj;
		if (StringUtils.isEmpty(coverageAmount)|| coverageAmount.equals(CtracAppConstants.DEFAULT_AMOUNT)) {
			if (!StringUtils.isEmpty(other.coverageAmount) && !other.coverageAmount.equals(CtracAppConstants.DEFAULT_AMOUNT))
				return false;
		} else if (!coverageAmount.equals(other.coverageAmount))
			return false;

		if (StringUtils.isEmpty(coverageValue) || coverageValue.equals(CtracAppConstants.DEFAULT_VALUE)) {
			if (!StringUtils.isEmpty(other.coverageValue)  && !other.coverageValue.equals(CtracAppConstants.DEFAULT_VALUE))
				return false;
		} else if (!coverageValue.equals(other.coverageValue)) {
            return false;
        }

		if(!StringUtils.equals(coverageType, other.coverageType)) {
            return false;
        }
		if(!isEqual(rid,other.rid)) {
            return false;
        }
		if (this.getHoldDTO() != null && this.getHoldDTO().hasChanged()) {
			return false;
		}
		return true;
	}

	private boolean isEqual(Object object1, Object object2){
		if (object1 == null) {
			if (object2 != null) {
                return false;
            }
		} else if (!object1.equals(object2)) {
			return false;
		}
		return true;
	}

	public void saveACopy () {
		try {
			if(this.getHoldDTO()!=null)
				this.getHoldDTO().saveACopy();
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException e) {
			logger.error(e.getMessage(), e);
		}
	}


	public CoverageDetailsDTO getLoadTimeValue() {
		return loadTimeValue;
	}

	public void setLoadTimeValue(CoverageDetailsDTO loadTimeValue) {
		this.loadTimeValue = loadTimeValue;
	}

	@Override
	public CoverageDetailsDTO clone() throws CloneNotSupportedException {
		return (CoverageDetailsDTO) super.clone();
	}

	public String getBalanceType() {
		return balanceType;
	}

	public void setBalanceType(String balanceType) {
		this.balanceType = balanceType;
	}

	public String getOrginalBalanceType() {
		return orginalBalanceType;
	}

	public void setOrginalBalanceType(String orginalBalanceType) {
		this.orginalBalanceType = orginalBalanceType;
	}

	public void setOriginalValueBalanceType(String orginalValueBalanceType) {
		this.orginalValueBalanceType = orginalValueBalanceType;
	}

	public String getVerifyBalanceTypePriorMissMatch() {
		return verifyBalanceTypePriorMissMatch;
	}

	public void setVerifyBalanceTypePriorMissMatch(String verifyBalanceTypePriorMissMatch) {
		this.verifyBalanceTypePriorMissMatch = verifyBalanceTypePriorMissMatch;
	}

	public void setVerifyValueBalanceTypePriorMissMatch(String verifyValueBalanceTypePriorMissMatch) {
		this.verifyValueBalanceTypePriorMissMatch = verifyValueBalanceTypePriorMissMatch;
	}

	public boolean hasCoverageAmount(){
		return StringUtils.isNotEmpty(coverageAmount) &&
				BigDecimal.ZERO.compareTo(AmountFormatter.parse(coverageAmount)) != 0;
	}

	public boolean hasCoverageValue(){
		return StringUtils.isNotEmpty(coverageValue) &&
				BigDecimal.ZERO.compareTo(AmountFormatter.parse(coverageValue)) != 0;
	}


	public boolean hasBalanceType() {
		return StringUtils.isNotEmpty(balanceType);
	}

	public boolean hasValueBalanceType() {
		return StringUtils.isNotEmpty(valueBalanceType);
	}

	public String getBuildingContentBalanceType() {
		return valueBalanceType;
	}

	public void setBuildingContentBalanceType(String valueBalanceType) {
		this.valueBalanceType = valueBalanceType;
	}


	public String getOrginalValueBalanceType() {
		return orginalValueBalanceType;
	}

	public void setOrginalValueBalanceType(String orginalValueBalanceType) {
		this.orginalValueBalanceType = orginalValueBalanceType;
	}

	public String getVerifyValueBalanceTypePriorMissMatch() {
		return verifyValueBalanceTypePriorMissMatch;
	}
}
