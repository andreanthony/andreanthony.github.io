package com.jpmorgan.cib.wlt.ctrac.service.dto.datatable;



import java.io.IOException;
import java.lang.reflect.Constructor;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.domain.Sort;

public class DataTablesRequest {

	
	/*
	 * Integer used by the framework to count the number of request and process request in sequence
	 */
	private Integer draw; 
	
	
	/*
	 * Paging first record indicator. This is the start point in the current data set 
	 * (0 index based - i.e. 0 is the first record).
	 */
	private Integer start;
	
	
	/* 	Number of records that the table can display in the current draw. 
	 * It is expected that the number of records returned will be equal to this number, 
	 * unless the server has fewer records to return. Note that this can be -1 to indicate 
	 * that all records should be returned (although that negates any benefits of server-side processing!)
	 * 
	 */
	private long length;
	
	
	/*Global order by column name;
	 * 
	 */
	private String orderByFieldName;
	
	/*
	 * Sort direction asc/desc automatically populated by the framework
	 */
	private String sortDirection ;
	
	/*
	 * hold the search criteria for the fields used to search; search criteria are fields not null
	 */
	private  DataTableDto searchCriteria ;
	
	
	private final Constructor<? extends DataTableDto> DTConstructor;
	
	
	public DataTablesRequest(Class<? extends DataTableDto> impl, HttpServletRequest httpReq) throws Exception{
		
		this.DTConstructor = impl.getConstructor();
		this.searchCriteria = DTConstructor.newInstance();
		populate(httpReq);
	}
	
	public Integer getDraw() {
		return draw;
	}
	public Integer getStart() {
		return start;
	}
	
	public Long getLength() {
		return length;
	}

	public  DataTableDto getSearchCriteria() {
		return searchCriteria;
	}
	
	public String getOrderByFieldName() {
		return orderByFieldName;
	}
	public String getSortDirection() {
		return sortDirection;
	}
	public void setLength(String length) {
		this.length = parseIntNoException(length);
	}
	public void setLength(long length) {
		this.length = length;
	}
	
	private void setDraw(String draw) {
		this.draw = parseIntNoException(draw);
	}
	private void setStart(String start) {
		this.start = parseIntNoException(start);
	}
	private void setSortDirection(String sortDirection) {
		this.sortDirection = sortDirection;
	}
	private void setOrderByFieldName(String orderByFieldName) {
		this.orderByFieldName = orderByFieldName;
	}
	
	/**
	 * @param param
	 */
	private Integer parseIntNoException(String param) {
		try {
			return Integer.parseInt(param);
		} catch (NumberFormatException swallow) {// this is a warming no need to log it
		}
		return 0;
	}
	
	private void populate(HttpServletRequest httpReq) throws IOException,
			ClassNotFoundException, InstantiationException,
			IllegalAccessException {

		if (httpReq == null) {
			throw new IllegalArgumentException(
					"Parmeters request and response must not be null.");
		}
		getSearchCriteria().parseRequestAttributes(httpReq);

		String cursor = httpReq.getParameter("draw");
		if (!StringUtils.isBlank(cursor)) {
			setDraw( StringUtils.trim(cursor) );
		}
		cursor = httpReq.getParameter("start");
		if (!StringUtils.isBlank(cursor)) {
			setStart( StringUtils.trim(cursor));
		}
		cursor = httpReq.getParameter("length");
		if (!StringUtils.isBlank(cursor)) {
			setLength( StringUtils.trim(cursor));
		}
		// get the orderby column index;
		cursor = httpReq.getParameter("order[0][column]");
		String columnName = httpReq.getParameter("columns[" + cursor+ "][data]");
		if(!StringUtils.isBlank(columnName)){
		  setOrderByFieldName( StringUtils.trim(columnName));	
		}
		// get the orderby direction index;
		cursor = httpReq.getParameter("order[0][dir]");
		if(!StringUtils.isBlank(cursor)){
			setSortDirection (StringUtils.trim(cursor));	
		}
		
	}
	
	
	@Override
	public String toString() {

		StringBuilder bl = new StringBuilder();

		bl.append("DataTablesRequest [ draw=").append(draw).append(", start=")
				.append(start).append(", length=").append(length)
				.append(", orderByFieldName=").append(orderByFieldName)
				.append(", searchCriteria=[ ").append(searchCriteria.toString()).append("] ]");
		return bl.toString();
	}
	
	public int getPageIndex(){
		Long result = start/length;
		return result.intValue();
	}
	
	
	 public Sort getSortSpec() { 
		String fieldName = this.getOrderByFieldName();
		if(StringUtils.isBlank(fieldName)){
			return null;
		}	
		String sortDirection = this.getSortDirection();
		if(StringUtils.isBlank(sortDirection) ||"asc".equalsIgnoreCase(sortDirection)){
			Sort.Order order = new Sort.Order(Sort.Direction.ASC, fieldName).ignoreCase();
			return new Sort(order); 
		}
		Sort.Order order = new Sort.Order(Sort.Direction.DESC, fieldName).ignoreCase();
		return new Sort(order);   
	}

}
