package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import java.io.Serializable;

public class BlanketCoverageDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5456865849822969026L;

	private Long rid;
	
	private String blanketCoverageType;

	private String blanketCombinedAmount;
	
	private String blanketBuildingAmount;
	
	private String blanketContentAmount;
	
	private BlanketCoverageDTO loadTimeValue;
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getBlanketCoverageType() {
		return blanketCoverageType;
	}

	public void setBlanketCoverageType(String blanketCoverageType) {
		this.blanketCoverageType = blanketCoverageType;
	}

	public String getBlanketCombinedAmount() {
		return blanketCombinedAmount;
	}

	public void setBlanketCombinedAmount(String blanketCombinedAmount) {
		this.blanketCombinedAmount = blanketCombinedAmount;
	}

	public String getBlanketBuildingAmount() {
		return blanketBuildingAmount;
	}

	public void setBlanketBuildingAmount(String blanketBuildingAmount) {
		this.blanketBuildingAmount = blanketBuildingAmount;
	}

	public String getBlanketContentAmount() {
		return blanketContentAmount;
	}

	public void setBlanketContentAmount(String blanketContentAmount) {
		this.blanketContentAmount = blanketContentAmount;
	}
	
    public boolean hasChanged() {
        if (this.loadTimeValue == null || this.getRid() == null) {
            return true;
        }
        return !deepEquals(this.loadTimeValue);
    }

	private boolean deepEquals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		BlanketCoverageDTO other = (BlanketCoverageDTO) obj;
		
		if (blanketBuildingAmount == null) {
			if (other.blanketBuildingAmount != null) {
				return false;
			}
		} else if (!blanketBuildingAmount.equals(other.blanketBuildingAmount)) {
			return false;
		}
		
		if (blanketCombinedAmount == null) {
			if (other.blanketCombinedAmount != null) {
				return false;
			}
		} else if (!blanketCombinedAmount.equals(other.blanketCombinedAmount)) {
			return false;
		}
		
		if (blanketContentAmount == null) {
			if (other.blanketContentAmount != null) {
				return false;
			}
		} else if (!blanketContentAmount.equals(other.blanketContentAmount)) {
			return false;
		}

		if (blanketCoverageType == null) {
			if (other.blanketCoverageType != null) {
				return false;
			}
		} else if (!blanketCoverageType.equals(other.blanketCoverageType)) {
			return false;
		}
		
		if (rid == null) {
			if (other.rid != null) {
				return false;
			}
		} else if (!rid.equals(other.rid)) {
			return false;
		}
		
		return true;
	}
	
    public void saveACopy() { 
        try {
            this.loadTimeValue = (BlanketCoverageDTO) this.clone();
        } catch (CloneNotSupportedException swallow) {} 
	}
	
}
