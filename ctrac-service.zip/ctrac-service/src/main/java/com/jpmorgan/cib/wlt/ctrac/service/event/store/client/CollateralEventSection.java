package com.jpmorgan.cib.wlt.ctrac.service.event.store.client;

public enum CollateralEventSection {
    COLLATERAL("Collateral"),
    COLLATERAL_DETAILS("Collateral Details"),
    COLLATERAL_OWNER("Collateral Owner"),
    LOAN("Loan"),
    BORROWER("Borrower"),
    SFHDF("SFHDF"),
    FLOOD_REQUIRED_COVERAGE("Flood Ins Req Cov"),
    GENERAL_REQUIRED_COVERAGE("General Ins Req Cov"),
    FLOOD_INSURANCE_BORROWER_POLICY("Flood Ins Borrower Policy"),
    GENERAL_INSURANCE_BORROWER_POLICY("General Ins Borrower Policy"),
    FLOOD_INSURANCE_LPI_POLICY("Flood Ins LPI Policy"),
    GENERAL_INSURANCE_LPI_POLICY("General Ins LPI Policy"),
    WORKFLOW_TASK("Workflow Task");

    private final String displayValue;

    CollateralEventSection(String displayValue) {
        this.displayValue = displayValue;
    }

    @Override
    public String toString() {
        return displayValue;
    }
}
