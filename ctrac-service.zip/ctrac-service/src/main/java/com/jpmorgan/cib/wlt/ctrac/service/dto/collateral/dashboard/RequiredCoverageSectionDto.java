package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;


public class RequiredCoverageSectionDto extends SectionDto {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private InsurancePolicyRequirementDto  activeCoverageRequirement = new InsurancePolicyRequirementDto();
	
	private InsurancePolicyRequirementDto  pendingVerificationCoverageRequirement= new InsurancePolicyRequirementDto();
	
	private Collection<InsurancePolicyRequirementDto> inactiveCoverageRequirement= new ArrayList<InsurancePolicyRequirementDto>();
	
	private final Collection<Long> deletedCoverageIds = new HashSet<Long>();
	
	private Collection<LookUpCode> balanceTypes;
	
	private boolean fiatRequested;
	
	private String fiatRequestedDate;
	
	private boolean sbaCoverageRequested;
	
	private String sbaCoverageRequestedDate;
    //normally it's true unless NFIP program expires and is not yet re-established
	private boolean workflowAllowed = true;

	private boolean displayHoldHistory ;

	public RequiredCoverageSectionDto(){
		this.sectionStatusDto = new SectionStatusDto();
		this.sectionStatusDto.setSectionId(CollateralDetailsSection.REQUIRED_INSURANCE_COVERAGE);
	}
	
	public boolean isSbaCoverageRequested() {
		return sbaCoverageRequested;
	}
	public void setSbaCoverageRequested(boolean sbaCoverageRequested) {
		this.sbaCoverageRequested = sbaCoverageRequested;
	}
	public String getSbaCoverageRequestedDate() {
		return sbaCoverageRequestedDate;
	}
	public void setSbaCoverageRequestedDate(String sbaCoverageRequestedDate) {
		this.sbaCoverageRequestedDate = sbaCoverageRequestedDate;
	}
	
	/**/
	/**
	 * @return the activeCoverageRequirement
	 */
	public InsurancePolicyRequirementDto getActiveCoverageRequirement() {
		return activeCoverageRequirement;
	}
	/**
	 * @return the pendingVerificationCoverageRequirement
	 */
	public InsurancePolicyRequirementDto getPendingVerificationCoverageRequirement() {
		return pendingVerificationCoverageRequirement;
	}
	/**
	 * @return the inactiveCoverageRequirement
	 */
	public Collection<InsurancePolicyRequirementDto> getInactiveCoverageRequirement() {
		return inactiveCoverageRequirement;
	}

	/**
	 * @param activeCoverageRequirement the activeCoverageRequirement to set
	 */
	public void setActiveCoverageRequirement(
			InsurancePolicyRequirementDto activeCoverageRequirement) {
		this.activeCoverageRequirement = activeCoverageRequirement;
	}
	/**
	 * @param pendingVerificationCoverageRequirement the pendingVerificationCoverageRequirement to set
	 */
	public void setPendingVerificationCoverageRequirement(
			InsurancePolicyRequirementDto pendingVerificationCoverageRequirement) {
		this.pendingVerificationCoverageRequirement = pendingVerificationCoverageRequirement;
	}
	/**
	 * @param inactiveCoverageRequirement the inactiveCoverageRequirement to set
	 */
	public void setInactiveCoverageRequirement(
			Collection<InsurancePolicyRequirementDto> inactiveCoverageRequirement) {
		this.inactiveCoverageRequirement = inactiveCoverageRequirement;
	}

	public void addInsuableAssetToDelete(Long insurableAssetId ){
	    deletedCoverageIds.add(insurableAssetId);
	    
	}
	
	public Collection<Long> getDeletedCoverageIds() {
	    return deletedCoverageIds;
	}
	public boolean isFiatRequested() {
		return fiatRequested;
	}
	public void setFiatRequested(boolean fiatRequested) {
		this.fiatRequested = fiatRequested;
	}
	public String getFiatRequestedDate() {
		return fiatRequestedDate;
	}
	public void setFiatRequestedDate(String fiatRequestedDate) {
		this.fiatRequestedDate = fiatRequestedDate;
	}

	public Collection<LookUpCode> getBalanceTypes() {
		return balanceTypes;
	}

	public void setBalanceTypes(Collection<LookUpCode> balanceTypes) {
		this.balanceTypes = balanceTypes;
	}

	public boolean isWorkflowAllowed() {
		return workflowAllowed;
	}

	public void setWorkflowAllowed(boolean workflowAllowed) {
		this.workflowAllowed = workflowAllowed;
	}

	public boolean isDisplayHoldHistory() {
		int holdHistoryCount = 0;
		for(RequiredCoverageDTO reqCovDto : activeCoverageRequirement.getRequiredCoverages())
		{
			if(reqCovDto.getPrimaryHold() !=null || reqCovDto.getExcessHold()!=null )
				holdHistoryCount++;

		}

		for(InsurancePolicyRequirementDto insPolicyReqDto : inactiveCoverageRequirement)
		{
			for (RequiredCoverageDTO reqCovDto : insPolicyReqDto.getRequiredCoverages()) {
				if(reqCovDto.getPrimaryHold() !=null || reqCovDto.getExcessHold()!=null )
					holdHistoryCount++;
			}
		}
		return holdHistoryCount > 0 ? true : false;

	}

	public void setDisplayHoldHistory(boolean displayHoldHistory) {
		this.displayHoldHistory = displayHoldHistory;
	}


}