package com.jpmorgan.cib.wlt.ctrac.service.command;

public abstract class AbstractCommand implements Command{

	protected Integer priority;
	
	@Override
	public int compareTo(Command command) {
		if (this == command) {
			return 0;
		}
		if (command == null) {
			return -1;
		}
		if (this.priority.compareTo(command.getPriority()) != 0) {
			return this.priority.compareTo(command.getPriority());
		}
		if (this.equals(command)) {
			return 0;
		}
		return 1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((priority == null) ? 0 : priority.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractCommand other = (AbstractCommand) obj;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		return true;
	}

	@Override
	public Integer getPriority() {
		return priority;
	}


}
