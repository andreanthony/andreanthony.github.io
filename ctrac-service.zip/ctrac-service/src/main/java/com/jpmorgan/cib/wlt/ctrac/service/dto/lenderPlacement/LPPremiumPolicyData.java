package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;

public class LPPremiumPolicyData implements Serializable {

	private static final long serialVersionUID = 86942599596161994L;
	
	private String buildingName;
	
	private String coverageType;
	
	private String premiumAmount;
	
	private String paymentMethod;
	
	private String propertyType;

	private String policyType;

	private String assetType;

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(String premiumAmount) {
		if(premiumAmount!=null)
			this.premiumAmount = AmountFormatter.format(AmountFormatter.parse(premiumAmount));
		else
			this.premiumAmount=premiumAmount ;
		
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
}
