package com.jpmorgan.cib.wlt.ctrac.service.bir;

public enum BIRMode {
	
	NEW(0),
	EDIT(1),
	VERIFY(2),
	RENEWAL(3),
	REPLACE(4);
	
	public final Integer mode;
	
	private BIRMode(Integer mode) {
		this.mode = mode;
	}
	
	public static BIRMode find(Integer mode) {
		for (BIRMode birMode : BIRMode.values()) {
			if (mode == birMode.mode) {
				return birMode;
			}
		}
		return null;
	}

	public boolean isNewRenewalReplaceMode() {
		return this == NEW || this == RENEWAL || this == REPLACE;

	}
}
