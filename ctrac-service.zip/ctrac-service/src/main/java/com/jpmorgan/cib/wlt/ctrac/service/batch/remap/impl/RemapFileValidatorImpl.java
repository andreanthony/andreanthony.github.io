package com.jpmorgan.cib.wlt.ctrac.service.batch.remap.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileException;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileValidator;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by E704298 on 8/1/2017.
 */
@Service
public class RemapFileValidatorImpl implements RemapFileValidator {

    @Autowired
    private DateCalculator dateCalculator;

    @Override
    public List<RemapFileException> validateRemapFile(RemapVendor remapVendor, String fileName) {
        List<RemapFileException> exceptions = new ArrayList<>();
        Date fileDate = remapVendor.parseDateFromFileName(fileName);
        DateTime currentReferenceDate = new DateTime(dateCalculator.getCurrentReferenceDate());
        if (!currentReferenceDate.withTimeAtStartOfDay().toDate().equals(fileDate)) {
            exceptions.add(new InvalidDateException(remapVendor, fileDate));
        }
        return exceptions;
    }
}
