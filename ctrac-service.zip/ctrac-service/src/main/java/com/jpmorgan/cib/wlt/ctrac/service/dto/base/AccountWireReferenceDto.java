package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;


public class AccountWireReferenceDto implements Serializable{
	private static final long serialVersionUID = 6299894328235979770L;
	
	private static Format formatter_date_filename = new SimpleDateFormat(CtracAppConstants.DATE_FORMAT_FILENAME);
	
	private long accountWireReferenceId;
	private String filename;
	private String accountingSystem;

	@NoInvalidCharacters
	private String requestNumber;
	private Date createdDate;
	
	public long getAccountWireReferenceId() {
		return accountWireReferenceId;
	}
	public void setAccountWireReferenceId(long accountWireReferenceId) {
		this.accountWireReferenceId = accountWireReferenceId;
	}
	public String getFilename() {
		return getAccountingSystem() + "_" + formatter_date_filename.format(getCreatedDate())+".xlsx";
	}
	public void setFilename(String filename) {
		this.filename = getAccountingSystem() + "_" + formatter_date_filename.format(getCreatedDate())+".xlsx";
	}
	public String getAccountingSystem() {
		return accountingSystem;
	}
	public void setAccountingSystem(String accountingSystem) {
		this.accountingSystem = accountingSystem;
	}
	public String getRequestNumber() {
		return requestNumber;
	}
	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
}
