package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRMode;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewRule;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CtracBaseHelperData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import static com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewRule.EVIDENCE_OF_INSURANCE_RULE;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class BorrowerInsuranceReviewDTO extends CtracBaseHelperData implements Cloneable {

	private static final Logger logger = Logger.getLogger(BorrowerInsuranceReviewDTO.class);
	private static final long serialVersionUID = -142678297368276892L;
	
	private Long rid;
	
	private BIRMode birMode;
	
	private Long collateralRid;

	@Valid
	private GenericProofOfCoverageDTO proofOfCoverageData;

	@Valid
	private Map<Long, BIRCollateralDetailsDTO> collateralDetailsMap = new TreeMap<Long, BIRCollateralDetailsDTO>();
		
	private Map<String, BIRRuleConclusionDTO> birRuleConclusions = new BIRRuleConclusionMap();
	
	private String eoiReceivedDate;
	
	private String eoiType;
	
	private String proofOfPayment;
	
	private String proofOfPaymentDescription;
	
	private String condoAssociationPolicy;
	
	private Long totalNumberOfCondoUnits;

	@NoInvalidCharacters
	private String individualCondoUnitNumbers;

	private String jpmListedAsMortgageePayee;
	
	private String jpmListedAsLenderLossPayee;
	
	private String jpmLienPosition;
	
	private BorrowerInsuranceReviewConclusion policyConclusion;
	
	private boolean disableSubmit = false;
	
	private boolean readOnlyUserRole = false;
	
	private String signedByAgent;

	private BorrowerInsuranceReviewDTO loadTimeValue;

	public boolean isAdminOverride() {
		return isAdminOverride;
	}

	public void setAdminOverride(boolean adminOverride) {
		isAdminOverride = adminOverride;
	}

	private boolean isAdminOverride=false;



	public boolean isDisabled(String key, Long collateralRid, Long insurableAssetSortOrder) {
	    if (collateralRid != null) {
			BIRCollateralDetailsDTO collateralDetailsData = collateralDetailsMap.get(collateralRid);
			return collateralDetailsData == null || collateralDetailsData.isDisabled(key, insurableAssetSortOrder);
		}
		if(EVIDENCE_OF_INSURANCE_RULE.getKey().equals(key) && eoiType != null && proofOfCoverageData.getParentPolicyRid() != null) {
			return true; // cannot change eoiType on renewal
		}
		return BIRDisabledFieldHelper.isDisabled(birRuleConclusions, key, proofOfCoverageData.getPolicyStatus(), proofOfCoverageData.getReasonForVerification());
	}
	
	public List<BIRRuleConclusionDTO> getAllBIRRuleConclusions() {
		List<BIRRuleConclusionDTO> allBIRRuleConclusions = new ArrayList<BIRRuleConclusionDTO>();
		Long proofOfCoverageRid = proofOfCoverageData.getRid();
		for (Entry<String, BIRRuleConclusionDTO> policyEntry : birRuleConclusions.entrySet()) {
			BIRRuleConclusionDTO birRuleConclusion = policyEntry.getValue();
			birRuleConclusion.populateValues(proofOfCoverageRid, null, null,
					policyEntry.getKey(), birRuleConclusion.getConclusion());
			allBIRRuleConclusions.add(birRuleConclusion);
		}
		for (Entry<Long, BIRCollateralDetailsDTO> collateralEntry : collateralDetailsMap.entrySet()) {
			allBIRRuleConclusions.addAll(collateralEntry.getValue().getAllBIRRuleConclusions(proofOfCoverageRid));
		}
		return allBIRRuleConclusions;
	}
	
	public boolean hasCancellationDate() {
		return proofOfCoverageData != null && proofOfCoverageData.hasCancellationDate();
	}
	
	public boolean requiresPIAWorkflow() {
		return birRuleConclusions.get(EVIDENCE_OF_INSURANCE_RULE.getKey()).hasException();
	}
	
	public boolean requiresInsuranceExceptionEmails() {
		List<BIRRuleConclusionDTO> allBIRRuleConclusions = getAllBIRRuleConclusions();
		for (BIRRuleConclusionDTO ruleConclusion : allBIRRuleConclusions) {
			BorrowerInsuranceReviewRule thisRule =
					BorrowerInsuranceReviewRule.findByKey(ruleConclusion.getFieldName());
			if (BorrowerInsuranceReviewRule.INSURANCE_EXCEPTION_RULES.contains(thisRule) &&
					ruleConclusion.hasException()) {
				return true;
			}
		}
		return false;
	}
	
	public boolean requiresRejectionEmails() {
		if (BorrowerInsuranceReviewConclusion.REJECTED.equals(this.getPolicyConclusion())) {
			return true;
		}
		return false;		
	}
	
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public BIRMode getBirMode() {
		return birMode;
	}

	public void setBirMode(BIRMode birMode) {
		this.birMode = birMode;
	}
	
	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public GenericProofOfCoverageDTO getProofOfCoverageData() {
		return proofOfCoverageData;
	}

	public void setProofOfCoverageData(GenericProofOfCoverageDTO proofOfCoverageData) {
		this.proofOfCoverageData = proofOfCoverageData;
	}

	public Map<Long, BIRCollateralDetailsDTO> getCollateralDetailsMap() {
		return collateralDetailsMap;
	}

	public void setCollateralDetailsMap(Map<Long, BIRCollateralDetailsDTO> collateralDetailsMap) {
		this.collateralDetailsMap = collateralDetailsMap;
	}

	public Map<String, BIRRuleConclusionDTO> getBirRuleConclusions() {
		return birRuleConclusions;
	}

	public void setBirRuleConclusions(Map<String, BIRRuleConclusionDTO> birRuleConclusions) {
		this.birRuleConclusions = birRuleConclusions;
	}

	public String getEoiReceivedDate() {
		return eoiReceivedDate;
	}

	public void setEoiReceivedDate(String eoiReceivedDate) {
		this.eoiReceivedDate = eoiReceivedDate;
	}

	public String getEoiType() {
		return eoiType;
	}

	public void setEoiType(String eoiType) {
		this.eoiType = eoiType;
	}

	public String getProofOfPayment() {
		return proofOfPayment;
	}

	public void setProofOfPayment(String proofOfPayment) {
		this.proofOfPayment = proofOfPayment;
	}
	
	public String getProofOfPaymentDescription() {
		return proofOfPaymentDescription;
	}

	public void setProofOfPaymentDescription(String proofOfPaymentDescription) {
		this.proofOfPaymentDescription = proofOfPaymentDescription;
	}

	public String getCondoAssociationPolicy() {
		return condoAssociationPolicy;
	}

	public void setCondoAssociationPolicy(String condoAssociationPolicy) {
		this.condoAssociationPolicy = condoAssociationPolicy;
	}

	public Long getTotalNumberOfCondoUnits() {
		return totalNumberOfCondoUnits;
	}

	public void setTotalNumberOfCondoUnits(Long totalNumberOfCondoUnits) {
		this.totalNumberOfCondoUnits = totalNumberOfCondoUnits;
	}
	
	public String getIndividualCondoUnitNumbers() {
		return individualCondoUnitNumbers;
	}

	public boolean getDisableSubmit() {
		return disableSubmit;
	}

	public void setDisableSubmit(boolean disableSubmitAndVerify) {
		this.disableSubmit = disableSubmitAndVerify;
	}

	public void setIndividualCondoUnitNumbers(String individualCondoUnitNumbers) {
		this.individualCondoUnitNumbers = individualCondoUnitNumbers;
	}

	public String getJpmListedAsMortgageePayee() {
		return jpmListedAsMortgageePayee;
	}

	public void setJpmListedAsMortgageePayee(String jpmListedAsMortgageePayee) {
		this.jpmListedAsMortgageePayee = jpmListedAsMortgageePayee;
	}

	public String getJpmListedAsLenderLossPayee() {
		return jpmListedAsLenderLossPayee;
	}

	public void setJpmListedAsLenderLossPayee(String jpmListedAsLenderLossPayee) {
		this.jpmListedAsLenderLossPayee = jpmListedAsLenderLossPayee;
	}

	public String getJpmLienPosition() {
		return jpmLienPosition;
	}

	public void setJpmLienPosition(String jpmLienPosition) {
		this.jpmLienPosition = jpmLienPosition;
	}

	public BorrowerInsuranceReviewConclusion getPolicyConclusion() {
		return policyConclusion;
	}

	public void setPolicyConclusion(BorrowerInsuranceReviewConclusion policyConclusion) {
		this.policyConclusion = policyConclusion;
	}
	
	public boolean isReadOnlyUserRole() {
		return readOnlyUserRole;
	}

	public void setReadOnlyUserRole(boolean readOnlyUserRole) {
		this.readOnlyUserRole = readOnlyUserRole;
	}

	public boolean isInitiateRenewalVisible() {
		//show the initiate renewal button when not replaceable AND it is renewable
		return !isInitiateReplacementVisible() && this.getProofOfCoverageData().isRenewable();
	}

	public boolean isInitiateReplacementVisible() {
		//When in verification mode - policy is not replaceable
		return BIRMode.VERIFY != getBirMode() && this.getProofOfCoverageData().isPolicyReplaceable();
	}

	public String getSignedByAgent() {
		return signedByAgent;
	}

	public void setSignedByAgent(String signedByAgent) {
		this.signedByAgent = signedByAgent;
	}

	public boolean showSignByAgent() {
		return StringUtils.isNotEmpty(signedByAgent) || BIRMode.NEW.equals(this.birMode) || policyInVerifyPendingVerification();
	}

		private boolean policyInVerifyPendingVerification(){
		return BIRMode.VERIFY.equals(this.birMode) && this.getProofOfCoverageData().getPolicyStatus().isPendingVerification();
	}
	
	public boolean isAllCollateralsVerified() {
        for (BIRCollateralDetailsDTO birCollateralDetailsDTO : getCollateralDetailsMap().values()) {
            if (birCollateralDetailsDTO.getPolicyStatus().isPendingVerification()) {
                return false;
            }
        }
        return true;
    }

    public boolean isCollateralIdDisabled() {
        return getProofOfCoverageData().hasCancellationDate() || getProofOfCoverageData().getPolicyStatus().isInactive() || policyInVerifyPendingVerification();
    }

    //  cancellation date also is disabled after collaterals added to BIR
    public boolean isBirCancellationDateDisabled() {
        return !(getProofOfCoverageData().isDisplayCancellationDate() || isAllCollateralsVerified());
    }

	public boolean isDeleteButtonVisible() {
		return  !getBirMode().isNewRenewalReplaceMode()
				&& PolicyStatus.PENDING_VERIFICATION == getProofOfCoverageData().getPolicyStatus()
				&& getProofOfCoverageData().getCancellationEffectiveDate()==null;
	}

	public boolean hasChanged() {
		return this.loadTimeValue == null || this.getRid() == null || !deepEquals(this.loadTimeValue);
	}

	private boolean deepEquals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		BorrowerInsuranceReviewDTO other = (BorrowerInsuranceReviewDTO) obj;
		if (!StringUtils.equals(eoiReceivedDate, other.eoiReceivedDate)) {
			return false;
		}
		if (!StringUtils.equals(eoiType, other.eoiType)) {
			return false;
		}
		if (!StringUtils.equals(proofOfPayment, other.proofOfPayment)) {
			return false;
		}if (!StringUtils.equals(proofOfPaymentDescription, other.proofOfPaymentDescription)) {
			return false;
		}
		if (!StringUtils.equals(condoAssociationPolicy, other.condoAssociationPolicy)) {
			return false;
		}
		if (totalNumberOfCondoUnits == null) {
			if (other.totalNumberOfCondoUnits != null) {
				return false;
			}
		} else if (!totalNumberOfCondoUnits.equals(other.totalNumberOfCondoUnits)) {
			return false;
		}
		if (!StringUtils.equals(individualCondoUnitNumbers, other.individualCondoUnitNumbers)) {
			return false;
		}
		if (!StringUtils.equals(jpmListedAsMortgageePayee, other.jpmListedAsMortgageePayee)) {
			return false;
		}
		if (!StringUtils.equals(jpmListedAsLenderLossPayee, other.jpmListedAsLenderLossPayee)) {
			return false;
		}
		if (!StringUtils.equals(jpmLienPosition, other.jpmLienPosition)) {
			return false;
		}
		if (!StringUtils.equals(signedByAgent, other.signedByAgent)) {
			return false;
		}

		if (collateralDetailsMap == null) {
			if (other.collateralDetailsMap != null) {
				return false;
			}
		} else{
			for(Long key: collateralDetailsMap.keySet()){
				BIRCollateralDetailsDTO birCollateralDetailsDTO = collateralDetailsMap.get(key);
				if(birCollateralDetailsDTO.hasChanged()){
					return false;
				}
			}
		}
		return true;
	}

	public BorrowerInsuranceReviewDTO getLoadTimeValue() {
		return loadTimeValue;
	}

	public void saveACopy() {
		try {
			for(Long key: collateralDetailsMap.keySet()){
				BIRCollateralDetailsDTO birCollateralDetailsDTO = collateralDetailsMap.get(key);
				birCollateralDetailsDTO.saveACopy();
			}
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	protected BorrowerInsuranceReviewDTO clone() throws CloneNotSupportedException {
		return (BorrowerInsuranceReviewDTO) super.clone();
	}
}
