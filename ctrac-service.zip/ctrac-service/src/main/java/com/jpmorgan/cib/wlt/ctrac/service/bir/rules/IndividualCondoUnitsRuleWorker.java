package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class IndividualCondoUnitsRuleWorker extends AbstractBIRRuleWorker {

	public IndividualCondoUnitsRuleWorker(String key) {
		super(key, true);
	}

	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRRuleConclusionDTO individualCondoUnitCoveredRule = borrowerInsuranceReviewData.getBirRuleConclusions().get(key);

		BorrowerInsuranceReviewConclusion birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		List<BIRRuleConclusionDTO> birRuleConclusions = borrowerInsuranceReviewData.getAllBIRRuleConclusions();
		for (BIRRuleConclusionDTO birRuleConclusion : birRuleConclusions) {
			if (BorrowerInsuranceReviewConclusion.REJECTED.name().equals(birRuleConclusion.getConclusion()) && "unitOrBuilding".equals(birRuleConclusion.getFieldName())) {
				birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
			}
		}	
		
		if (!BIRRuleHelper.isCondoAssociationPolicy(borrowerInsuranceReviewData)) {
			birConclusion = BorrowerInsuranceReviewConclusion.NONE;
		} 
		individualCondoUnitCoveredRule.setConclusion(birConclusion.name());
	}
}
