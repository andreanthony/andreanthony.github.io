package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import com.jpmorgan.cib.wlt.ctrac.service.dto.view.CollateralMainDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.CollateralOwnerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.PrimaryLoanBorrowerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProofOfCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProvidedCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;

public class LPPolicyCollateralData extends LenderPlaceData {

	private static final long serialVersionUID = -263922775156363191L;
	
	private PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto;
    
    private CollateralMainDetailsViewDto collateralMainDetailsViewDto;
    
    private CollateralOwnerViewDto collateralOwnerViewDto;
    
    private ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto;
    
    private ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto;
    
    private RequiredCoverageViewDto requiredCoverageViewDto;


	public PrimaryLoanBorrowerViewDto getPrimaryLoanBorrowerViewDto() {
		return primaryLoanBorrowerViewDto;
	}

	public void setPrimaryLoanBorrowerViewDto(PrimaryLoanBorrowerViewDto primaryLoanBorrowerViewDto) {
		this.primaryLoanBorrowerViewDto = primaryLoanBorrowerViewDto;
	}

	public CollateralMainDetailsViewDto getCollateralMainDetailsViewDto() {
		return collateralMainDetailsViewDto;
	}

	public void setCollateralMainDetailsViewDto(CollateralMainDetailsViewDto collateralMainDetailsViewDto) {
		this.collateralMainDetailsViewDto = collateralMainDetailsViewDto;
	}

	public CollateralOwnerViewDto getCollateralOwnerViewDto() {
		return collateralOwnerViewDto;
	}

	public void setCollateralOwnerViewDto(CollateralOwnerViewDto collateralOwnerViewDto) {
		this.collateralOwnerViewDto = collateralOwnerViewDto;
	}

	public ProofOfCoverageDetailsViewDto getProofOfCoverageDetailsViewDto() {
		return proofOfCoverageDetailsViewDto;
	}

	public void setProofOfCoverageDetailsViewDto(ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto) {
		this.proofOfCoverageDetailsViewDto = proofOfCoverageDetailsViewDto;
	}

	public ProvidedCoverageDetailsViewDto getProvidedCoverageDetailsViewDto() {
		return providedCoverageDetailsViewDto;
	}

	public void setProvidedCoverageDetailsViewDto(ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto) {
		this.providedCoverageDetailsViewDto = providedCoverageDetailsViewDto;
	}

	public RequiredCoverageViewDto getRequiredCoverageViewDto() {
		return requiredCoverageViewDto;
	}

	public void setRequiredCoverageViewDto(RequiredCoverageViewDto requiredCoverageViewDto) {
		this.requiredCoverageViewDto = requiredCoverageViewDto;
	}	
}
