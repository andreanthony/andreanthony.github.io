package com.jpmorgan.cib.wlt.ctrac.service.insurableasset;

import java.util.List;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;



public interface ProvidedCoverageService {

    //==============     Provided Coverages

    ProvidedCoverageDTO saveProvidedCoverage(ProvidedCoverageDTO providedCoverageDTO);
    List<ProvidedCoverageDTO> saveProvidedCoverage(List<ProvidedCoverageDTO> providedCoverageDTOList);  

}
