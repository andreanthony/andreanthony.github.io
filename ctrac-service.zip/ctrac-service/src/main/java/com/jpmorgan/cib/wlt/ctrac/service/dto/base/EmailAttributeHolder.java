package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;


public class EmailAttributeHolder  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<Long> collateralRids = new ArrayList<>();
	
	private String subject;

	private String emailBody;

	private Set<String> toAddresses = new HashSet<>();

    private Set<String> ccAddresses = new HashSet<>();

    private Set<String> bccAddresses = new HashSet<>();
	
	private String fromAddress;

	private EmailTemplate emailTemplate;
	
	private String emailType;
	
	private List<MultipartFile> files;
	
	private File singleFileAttachment;
	
	private List<File> attachments;

	private CtracErrorSeverity ctracErrorSeverity = CtracErrorSeverity.APPLICATION;

	public List<Long> getCollateralRids() {
		return collateralRids;
	}

	public void setCollateralRids(List<Long> collateralRids) {
		this.collateralRids = collateralRids;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEmailBody() {
		return emailBody;
	}

	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}

    public void addToAddress(String toAddress) {
        toAddresses.add(toAddress);
    }

    public void addCcAddress(String ccAddress) {
        ccAddresses.add(ccAddress);
    }

    public void addBccAddress(String bccAddress) {
        bccAddresses.add(bccAddress);
    }

    public Set<String> getToAddresses() {
        return formatAddresses(toAddresses);
    }

	public String workItemLob;

    public void setToAddresses(Set<String> toAddresses) {
	    if (toAddresses == null) {
	        throw new NullPointerException("toAddresses cannot be null");
        }
        this.toAddresses = toAddresses;
    }

    public Set<String> getCcAddresses() {
        return formatAddresses(ccAddresses);
    }

    public void setCcAddresses(Set<String> ccAddresses) {
        if (ccAddresses == null) {
            throw new NullPointerException("ccAddresses cannot be null");
        }
        this.ccAddresses = ccAddresses;
    }

    public Set<String> getBccAddresses() {
        return formatAddresses(bccAddresses);
    }

    public void setBccAddresses(Set<String> bccAddresses) {
        if (bccAddresses == null) {
            throw new NullPointerException("bccAddresses cannot be null");
        }
        this.bccAddresses = bccAddresses;
    }

    private Set<String> formatAddresses(Set<String> addresses) {
	    Set<String> formattedAddresses = new HashSet<>();
	    for (String address : addresses) {
            addAddress(address, formattedAddresses);
        }
        addresses.clear();
	    addresses.addAll(formattedAddresses);
        return addresses;
    }

    private void addAddress(String delimitedAddress, Set<String> addresses) {
		if (delimitedAddress != null) {
			delimitedAddress = delimitedAddress.replaceAll(",", CtracAppConstants.EMAIL_ADDR_SEPERATOR);
			String[] toAddresses = delimitedAddress.split(CtracAppConstants.EMAIL_ADDR_SEPERATOR);
			for (String individualAddress : toAddresses) {
			    if (StringUtils.isNotBlank(individualAddress)) {
                    addresses.add(individualAddress.trim());
                }
			}
		}
    }

	public String getFromAddress() {
	    if (fromAddress != null) {
	        fromAddress = fromAddress.trim();
        }
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public EmailTemplate getEmailTemplate() {
		return emailTemplate;
	}

	public void setEmailTemplate(EmailTemplate emailTemplate) {
		this.emailTemplate = emailTemplate;
	}

	public String getEmailType() {
		return emailType;
	}

	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}

	public List<MultipartFile> getFiles() {
		return files;
	}

	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}

	public File getSingleFileAttachment() {
		return singleFileAttachment;
	}

	public void setSingleFileAttachment(File singleFileAttachment) {
		this.singleFileAttachment = singleFileAttachment;
	}

    public List<File> getAttachments() {
			return attachments;
	}

    public void setAttachments(List<File> attachments) {
			this.attachments = attachments;
	}

	public CtracErrorSeverity getCtracErrorSeverity() {
		return ctracErrorSeverity;
	}

	public void setCtracErrorSeverity(CtracErrorSeverity ctracErrorSeverity) {
		this.ctracErrorSeverity = ctracErrorSeverity;
	}
	public String getWorkItemLob() {
		return workItemLob;
	}

	public void setWorkItemLob(String workItemLob) {
		this.workItemLob = workItemLob;
	}


}
