package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.Comparator;

public class ReleaseDateComparator implements Comparator<LoanData> {

	@Override
	public int compare(LoanData loanData1, LoanData loanData2) {
		if(loanData1.getReleasedDt()==null && loanData2.getReleasedDt()==null){
			return 0;
		}else if(loanData1.getReleasedDt()==null && loanData2.getReleasedDt()!=null){
			return 1;
		}else if(loanData1.getReleasedDt()!=null && loanData2.getReleasedDt()==null){
			return -1;
		}else{
			return loanData2.getReleasedDt().compareTo(loanData1.getReleasedDt());
		}
	}

}
