package com.jpmorgan.cib.wlt.ctrac.service.batch;

import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

/**
 * used as a shared service across the 3-part Althans batch process
 *
 */
public interface AlthansBatchItemService {

	/**
	 * @param perfectionTaskRid rid of PerfectionTask related to the AlthansBatchItem
	 *        e.g. Process_Vendor_File, Process_Vendor_Certificates
	 * @return set of ProofOfCoverage rids that were included on the weekly request file
	 */
	Set<Long> getRelatedPolicyRids(Long perfectionTaskRid);

	boolean isNewIssuePolicy(Long batchTaskRid, ProofOfCoverage policy);
	
}
