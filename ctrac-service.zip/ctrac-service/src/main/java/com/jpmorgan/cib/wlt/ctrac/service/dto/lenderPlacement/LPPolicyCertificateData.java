package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;

public class LPPolicyCertificateData extends LPPolicyCollateralData {
	private static final long serialVersionUID = -801112734963896567L;

	private CollateralDoc premiumCertificate;
	
    private CollateralDoc cancellationCertificate;      
    
    private String lpCoverageType;
    
    private String screenTitle;
    
	private String requiredConfirmationMessage;
    
    private boolean cancellationWorkflow;
    
    public String getScreenTitle() {
		return screenTitle;
	}

	public void setScreenTitle(String screenTitle) {
		this.screenTitle = screenTitle;
	}

	public String getRequiredConfirmationMessage() {
		return requiredConfirmationMessage;
	}

	public void setRequiredConfirmationMessage(String requiredConfirmationMessage) {
		this.requiredConfirmationMessage = requiredConfirmationMessage;
	}

	public CollateralDoc getPremiumCertificate() {
		return premiumCertificate;
	}

	public void setPremiumCertificate(CollateralDoc premiumCertificate) {
		this.premiumCertificate = premiumCertificate;
	}

	public CollateralDoc getCancellationCertificate() {
		return cancellationCertificate;
	}

	public void setCancellationCertificate(CollateralDoc cancellationCertificate) {
		this.cancellationCertificate = cancellationCertificate;
	}

	public String getLpCoverageType() {
		return lpCoverageType;
	}

	public void setLpCoverageType(String lpCoverageType) {
		this.lpCoverageType = lpCoverageType;
	}

	public boolean isCancellationWorkflow() {
		return cancellationWorkflow;
	}

	public void setCancellationWorkflow(boolean cancellationWorkflow) {
		this.cancellationWorkflow = cancellationWorkflow;
	}

	
}
