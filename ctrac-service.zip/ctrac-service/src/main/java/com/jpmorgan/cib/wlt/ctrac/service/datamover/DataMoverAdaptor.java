package com.jpmorgan.cib.wlt.ctrac.service.datamover;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracBaseException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReconciliationLog;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.LobAvailabilityRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapBatchService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessCategory;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public abstract class DataMoverAdaptor<Source, Target> {
	private static final Logger logger = Logger.getLogger(DataMoverAdaptor.class);
	
	public int totalInputRecords = 0;
	public int successCount = 0;
	int invalidCount = 0;
	public int exceptionRecordsCnt = 0;
	List<Source> unprocessedSourceData;
	List<Source> sourceDataToMove;
	List<Target> targetData;
	protected final LineOfBusinessCategory lobCategory;

	private final SchedulerJob job;

    //default value if not set.
	private String filename = "New SFHDF PDFs";

	@Autowired protected FloodRemapBatchService floodRemapBatchService;
    @Autowired protected CtracObjectMapper ctracObjectMapper;
	@Autowired protected CalendarDayUtil calendarDayUtil;
    @Autowired protected LobAvailabilityRepository lobAvailabilityRepository;

	public DataMoverAdaptor(SchedulerJob job, LineOfBusinessCategory lobCategory) {
		this.job = job;
		this.lobCategory = lobCategory;
	}
	
	/*
	 * This method is the only exposed method to be called and the DataMoverAdaptor and the subclass involved will 
	 * perform the task of moving data form source to target. 
	 * 
	 * */
	@Transactional
	public void runDataMover() {
		try{
			init();
			executePreSteps();
			executeMove();
			executePostSteps();
			saveData(unprocessedSourceData, targetData);			
		}catch (CTracBaseException e) {
		    logger.error(e.getMessage(), e);
			throw new CTracBaseException("E0214", CtracErrorSeverity.APPLICATION);
		}finally{
			saveReconciliationLog();
		}
	}

	/*
	 * This method will populate List<Source> unprocessedSourceData and totalInputRecords. 
	 * 
	 * */
	private void init() throws CTracBaseException{
		logger.info("init()::Begin");
		totalInputRecords = 0;
		successCount = 0;
		invalidCount = 0;
		exceptionRecordsCnt = 0;
		unprocessedSourceData = fetchSourceData();
		if(CollectionUtils.isEmpty(unprocessedSourceData)){
			logger.debug("No input records found for moving.");
			unprocessedSourceData = new ArrayList<Source>();
		}
		totalInputRecords = unprocessedSourceData.size();
		logger.info("init()::End");
	}
	
	/*
	 * This method will apply DataProcessor(s) to the unprocessedSourceData and will filter/polish data.
	 * List<Source> sourceDataToMove will have subset of unprocessedSourceData eligible and ready to be moved to List<Target> targetData
	 * */
	private void executePreSteps() {
		sourceDataToMove = new ArrayList<Source>();
		List<DataProcessor> preStepsProcessors =  preparePreStepProcessors();
		sourceDataToMove.addAll(unprocessedSourceData);
		for (DataProcessor visitor : preStepsProcessors) {
			sourceDataToMove = visitor.apply(sourceDataToMove);
		}
		invalidCount = totalInputRecords - sourceDataToMove.size();
	}
	
	/*
	 * This method will apply DataProcessor(s) to the sourceDataToMove and will polish data.
	 * */
	private void executePostSteps() {
		List<DataProcessor> postStepsProcessors = preparePostStepProcessors();
		for (DataProcessor visitor : postStepsProcessors) {
			visitor.apply(sourceDataToMove);
		}
	}
	
	/*
	 * This method returns the sourceDataToMove.
	 * */
	protected List<Source> getFilteredDataToMove(){
		return sourceDataToMove;
	}
	
	/*
	 * This method will save the recon log.
	 * */
	private void saveReconciliationLog(){
		logger.info("saveReconciliationLog()::Begin");
		ReconciliationLog reconciliationLog = new ReconciliationLog();
		reconciliationLog.batchName(job.getName())
				.inputCount(totalInputRecords).processedCount(successCount)
				.rejectedCount(invalidCount).fileName(filename);
		floodRemapBatchService.logReconciliationAndExitInfoToDatabase(reconciliationLog, exceptionRecordsCnt);
		logger.info("saveReconciliationLog()::End");
	}

	protected Set<Object> retrieveServicerCodesByActive(boolean active) {
        Set<Object> servicerCodes = new HashSet<>();
        List<String> inactiveServicerCodes =
                lobAvailabilityRepository.findServicerCodesByCategoryAndActive(lobCategory.name(), active);
        servicerCodes.addAll(inactiveServicerCodes);
        return servicerCodes;
    }

	/*
	 * The implementing subclasses will call there respective repositories and implement this method to return that data.
	 * What they return will be assigned to List<Source> unprocessedSourceData.
	 * */
	protected abstract List<Source> fetchSourceData();
	/*
	 * This method will return list of DataProcessor(s) that will be applied to List<Source> unprocessedSourceData.
	 * */
	protected abstract List<DataProcessor> preparePreStepProcessors();
	/*
	 * This method will return list of DataProcessor(s) that will be applied to List<Source> sourceDataToMove.
	 * No DataProcessor that are supposed to filter data should be added to the list
	 * as the data eligible for move is already moved to the target list. 
	 * */
	protected abstract List<DataProcessor> preparePostStepProcessors();
	
	/*
	 * The implementing subclasses will use this method to populate List<Target> targetData and to perform any other required step.
	 * */
	protected abstract void executeMove();	
	/*
	 * The implementing subclasses will use this method to save any changes made to source and target list.
	 * */
	protected abstract void saveData(List<Source> listSource, List<Target> listTarget);
	
	/*
	 * The implementing subclasses should call this method to pass the List<Target> targetData to the DataMoverAdaptor.
	 * Unless this method is called from the subclasses List<Target> targetData in DataMoverAdaptor will remain null.
	 * */
	public void setTargetData(List<Target> targetData) {
		this.targetData = targetData;
	}
	
	public SchedulerJob getJob() {
		return job;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public void setCalendarDayUtil(CalendarDayUtil calendarDayUtil) {
		this.calendarDayUtil = calendarDayUtil;
	}

	public void setFloodRemapBatchService(FloodRemapBatchService floodRemapBatchService) {
		this.floodRemapBatchService = floodRemapBatchService;
	}
	
	public List<Target> getTargetData() {
		return targetData;
	}

	public List<Source> getSourceDataToMove() {
		return sourceDataToMove;
	}

}
