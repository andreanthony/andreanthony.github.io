package com.jpmorgan.cib.wlt.ctrac.service.bir.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRRuleConclusion;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.bir.BIRRuleConclusionRepository;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRRuleConclusionService;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewRule;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRInsurableAssetDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.request.BIProofOfCoveragePublishEventRequest;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional(readOnly=true)
public class BIRRuleConclusionServiceImpl implements BIRRuleConclusionService {

	@Autowired private BIRRuleConclusionRepository birRuleConclusionRepository;
	@Autowired private CollateralManagementService collateralManagementService;
	@Autowired private PublishEventService publishEventService;

	@Autowired private CtracObjectMapper ctracObjectMapper;
	
	private static final Logger logger = LoggerFactory.getLogger(BIRRuleConclusionServiceImpl.class);
	
	
	@Override
	public boolean hasException(Long proofOfCoverageRid) {
		if (proofOfCoverageRid == null) {
			return false;
		}
		Long countOfActionRequired = birRuleConclusionRepository.countByProofOfCoverageRidAndConclusion(
				proofOfCoverageRid, BorrowerInsuranceReviewConclusion.ACTION_REQUIRED.name());
		return countOfActionRequired != null && countOfActionRequired > 0;
	}
	
	@Override
	public void loadBIRFieldConclusions(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		if (borrowerInsuranceReviewData == null || borrowerInsuranceReviewData.getProofOfCoverageData() == null) {
			logger.debug("No BIRFieldConclusions for null argument.");
			return;
		}
		
		List<BIRRuleConclusion> birFieldConclusions = birRuleConclusionRepository.findByProofOfCoverageRid(
				borrowerInsuranceReviewData.getProofOfCoverageData().getRid());
		for (BIRRuleConclusion birFieldConclusion : birFieldConclusions) {

			// Get keys
			Long proofOfCoverageRid = birFieldConclusion.getProofOfCoverageRid();
			Long collateralRid = birFieldConclusion.getCollateralRid();
			Long insurableAssetSortOrder = birFieldConclusion.getInsurableAssetSortOrder();
			String fieldName = birFieldConclusion.getFieldName();
			String conclusion = birFieldConclusion.getConclusion();
			
			BIRRuleConclusionDTO birRuleConclusionData = new BIRRuleConclusionDTO();
			birRuleConclusionData.setRid(birFieldConclusion.getRid());
			Map<String, BIRRuleConclusionDTO> birRuleConclusions = null;
			if (collateralRid != null && insurableAssetSortOrder != null &&
					borrowerInsuranceReviewData.getCollateralDetailsMap().get(collateralRid) != null) { // Building level
				BIRInsurableAssetDetailsDTO birInsurableAssetDetails =
						borrowerInsuranceReviewData.getCollateralDetailsMap().get(collateralRid).
						getInsurableAssetDetailsMap().get(insurableAssetSortOrder);
				if (birInsurableAssetDetails == null) {
					continue;
				}
				birRuleConclusions = birInsurableAssetDetails.getBirRuleConclusions();
			} else if (collateralRid != null) { // Collateral level
				BIRCollateralDetailsDTO birCollateralDetails =
						borrowerInsuranceReviewData.getCollateralDetailsMap().get(collateralRid);
				if (birCollateralDetails == null) {
					continue;
				}
				birRuleConclusions = birCollateralDetails.getBirRuleConclusions();
			} else { // Policy level
				birRuleConclusions = borrowerInsuranceReviewData.getBirRuleConclusions();
			}

			birRuleConclusionData.populateValues(proofOfCoverageRid, collateralRid,
					insurableAssetSortOrder, fieldName, conclusion);
			birRuleConclusionData.saveACopy();
			birRuleConclusions.put(fieldName, birRuleConclusionData);
		}
	}

	@Override
	@Transactional(readOnly=false)
	public boolean saveBIRFieldConclusions(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		List<BIRRuleConclusionDTO> allBIRRuleConclusions = borrowerInsuranceReviewData.getAllBIRRuleConclusions();
		boolean exceptionChangedIndicator = false;
		for (BIRRuleConclusionDTO birRuleConclusionDTO : allBIRRuleConclusions) {
			if (birRuleConclusionDTO.getConclusion() == null) {
				continue;
			}
			BIRRuleConclusion birRuleConclusion = new BIRRuleConclusion();
			if (birRuleConclusionDTO.getRid() != null) {
				birRuleConclusion = birRuleConclusionRepository.findOne(birRuleConclusionDTO.getRid());
			}
			ctracObjectMapper.map(birRuleConclusionDTO, birRuleConclusion);

            exceptionChangedIndicator = exceptionChangedIndicator ||
                    ((birRuleConclusionDTO.getLoadTimeValue() != null && birRuleConclusionDTO.getLoadTimeValue().hasException()) != birRuleConclusionDTO.hasException());

			birRuleConclusion = birRuleConclusionRepository.saveAndFlush(birRuleConclusion);
			birRuleConclusionDTO.setRid(birRuleConclusion.getRid());
			birRuleConclusionDTO.saveACopy();
		}

		if(exceptionChangedIndicator){
			Map<Long,BIRCollateralDetailsDTO> collateralListOnPolicy = borrowerInsuranceReviewData.getCollateralDetailsMap();
			for(Long collateralRid : collateralListOnPolicy.keySet()){
				CollateralDto collateralDto = collateralManagementService.getCollateralDto(collateralRid);
				if(collateralDto != null) {
					publishEventService.publishBIProofOfCoverageEvent(new BIProofOfCoveragePublishEventRequest(
							borrowerInsuranceReviewData,collateralDto.getPrimaryLoan(),collateralDto.getRid()).
							forCollateralEventType(CollateralEventType.EXCEPTION_CHANGED));
				}
			}
		}

		return exceptionChangedIndicator;
	}
	
	@Override
	@Transactional(readOnly=false)
	public BIRRuleConclusionDTO saveBIRRuleConclusion(BIRRuleConclusionDTO birRuleConclusionData) {
		if (birRuleConclusionData.getConclusion() == null) {
			return birRuleConclusionData;
		}
		BIRRuleConclusion birRuleConclusion = new BIRRuleConclusion();
		if (birRuleConclusionData.getRid() != null) {
			birRuleConclusion = birRuleConclusionRepository.findOne(birRuleConclusionData.getRid());
		}
		ctracObjectMapper.map(birRuleConclusionData, birRuleConclusion);
		birRuleConclusion = birRuleConclusionRepository.saveAndFlush(birRuleConclusion);
		birRuleConclusionData.setRid(birRuleConclusion.getRid());
		birRuleConclusionData.saveACopy();
		return birRuleConclusionData;
	}

	@Override
	@Transactional(readOnly=false)
	public void createOrUpdateException(Long proofOfCoverageRid, Long collateralRid, BorrowerInsuranceReviewRule birRule,
			BorrowerInsuranceReviewConclusion birConclusion) {
		List<BIRRuleConclusion> ruleConclusions =
				birRuleConclusionRepository.findByProofOfCoverageRidAndCollateralRidAndFieldName(
						proofOfCoverageRid, collateralRid, birRule.getKey());
		
		BIRRuleConclusion birRuleConclusion = null;
		if (ruleConclusions != null && !ruleConclusions.isEmpty()) {
			if (ruleConclusions.size() > 1) {
				logger.error("Found more than 1 BIR Rule conclusion for policy {}, birRule {}", proofOfCoverageRid, birRule.getKey());
			}
			birRuleConclusion = ruleConclusions.get(0);
		} else {
			birRuleConclusion = new BIRRuleConclusion();
			birRuleConclusion.setProofOfCoverageRid(proofOfCoverageRid);
			birRuleConclusion.setCollateralRid(collateralRid);
			birRuleConclusion.setFieldName(birRule.getKey());
		}
		birRuleConclusion.setConclusion(birConclusion.name());
		birRuleConclusionRepository.saveAndFlush(birRuleConclusion);
	}
}
