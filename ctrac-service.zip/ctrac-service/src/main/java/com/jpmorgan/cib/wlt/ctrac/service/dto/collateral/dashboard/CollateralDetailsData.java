package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.InsuranceData;




public class CollateralDetailsData {
	private String collateralAddress;
	private String collateralCity;
	private String collateralState;
	private String collateralZipCode;
	private CollateralStatus collateralStatus;
	
	
	// Arun - Instead of using CustomerData and InsuranceData classes, see if any existing class can be used.
	private CustomerData borrowerData;
	
	private InsuranceData[] activeInsuranceData;
	private InsuranceData[] inactiveInsuranceData;
	
	public Set <String> getActions(){
		SortedSet <String> response = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		
		response.add("Review Borrower Insurance");
				
		return response;
	}
	
	public void mockData() {
		collateralAddress = "123 Main Street";
		collateralCity = "Chicago";
		collateralState = "IL";
		collateralZipCode = "60604";
		collateralStatus = CollateralStatus.PLEDGED;
		
		borrowerData = new CustomerData();
		borrowerData.setBorrowerName("John Smith");

		
		// Active Insurance
		ArrayList<InsuranceData> list = new ArrayList<InsuranceData>();
		
		
		// Record 1
		InsuranceData insuranceData1 = new InsuranceData();
		insuranceData1.setInsuranceType("Flood");
		insuranceData1.setStatus("Accepted");
		insuranceData1.setPolicyNumber("123 A1");
		insuranceData1.setPolicyType("Borrower");
		insuranceData1.setCoverageType("Building");
		insuranceData1.setCoverageAmount(400000D);
		
		Calendar effectiveDateCalendar1 = new GregorianCalendar(2015,1,15);		
		insuranceData1.setEffectiveDate(effectiveDateCalendar1.getTime());
		
		Calendar expiryDateCalendar1 = new GregorianCalendar(2016,1,15);		
		insuranceData1.setExpiryDate(expiryDateCalendar1.getTime());
		
		list.add(insuranceData1);

		// Record 2
		InsuranceData insuranceData2 = new InsuranceData();
		insuranceData2.setInsuranceType("Flood");
		insuranceData2.setStatus("Letter Cycle");
		insuranceData2.setPolicyNumber("NA");
		insuranceData2.setPolicyType("LP Gap");
		insuranceData2.setCoverageType("Building");
		insuranceData2.setCoverageAmount(100000D);
		
		Calendar effectiveDateCalendar2 = new GregorianCalendar(2015,1,25);		
		insuranceData2.setEffectiveDate(effectiveDateCalendar2.getTime());
		
		Calendar expiryDateCalendar2 = new GregorianCalendar(2016,1,25);		
		insuranceData2.setExpiryDate(expiryDateCalendar2.getTime());
		
		list.add(insuranceData2);
		
		Collections.sort(list, new InsuranceData());
		activeInsuranceData = new InsuranceData[list.size()];
		activeInsuranceData =  list.toArray(activeInsuranceData);
		
		// Inactive Insurance
		ArrayList<InsuranceData> inactiveList = new ArrayList<InsuranceData>();
		
		
		// Record 1
		InsuranceData insuranceData3 = new InsuranceData();
		insuranceData3.setInsuranceType("Flood");
		insuranceData3.setStatus("Accepted");
		insuranceData3.setPolicyNumber("456 B1");
		insuranceData3.setPolicyType("Borrower");
		insuranceData3.setCoverageType("Building");
		insuranceData3.setCoverageAmount(400000D);
		
		Calendar effectiveDateCalendar3 = new GregorianCalendar(2014,1,15);		
		insuranceData3.setEffectiveDate(effectiveDateCalendar3.getTime());
		
		Calendar expiryDateCalendar3 = new GregorianCalendar(2015,1,15);		
		insuranceData3.setExpiryDate(expiryDateCalendar3.getTime());
		
		inactiveList.add(insuranceData3);

		// Record 2
		InsuranceData insuranceData4 = new InsuranceData();
		insuranceData4.setInsuranceType("Flood");
		insuranceData4.setStatus("Letter Cycle");
		insuranceData4.setPolicyNumber("NA");
		insuranceData4.setPolicyType("LP Gap");
		insuranceData4.setCoverageType("Building");
		insuranceData4.setCoverageAmount(100000D);
		
		Calendar effectiveDateCalendar4 = new GregorianCalendar(2014,1,25);		
		insuranceData4.setEffectiveDate(effectiveDateCalendar4.getTime());
		
		Calendar expiryDateCalendar4 = new GregorianCalendar(2015,1,25);		
		insuranceData4.setExpiryDate(expiryDateCalendar4.getTime());
		
		inactiveList.add(insuranceData4);
		
		// Record 3
		InsuranceData insuranceData5 = new InsuranceData();
		insuranceData5.setInsuranceType("Flood");
		insuranceData5.setStatus("Accepted");
		insuranceData5.setPolicyNumber("789 C1");
		insuranceData5.setPolicyType("Borrower");
		insuranceData5.setCoverageType("Building");
		insuranceData5.setCoverageAmount(400000D);
		
		Calendar effectiveDateCalendar5 = new GregorianCalendar(2013,1,15);		
		insuranceData5.setEffectiveDate(effectiveDateCalendar5.getTime());
		
		Calendar expiryDateCalendar5 = new GregorianCalendar(2014,1,15);		
		insuranceData5.setExpiryDate(expiryDateCalendar5.getTime());
		
		inactiveList.add(insuranceData5);

		// Record 4
		InsuranceData insuranceData6 = new InsuranceData();
		insuranceData6.setInsuranceType("Flood");
		insuranceData6.setStatus("Letter Cycle");
		insuranceData6.setPolicyNumber("NA");
		insuranceData6.setPolicyType("LP Gap");
		insuranceData6.setCoverageType("Building");
		insuranceData6.setCoverageAmount(100000D);
		
		Calendar effectiveDateCalendar6 = new GregorianCalendar(2013,1,25);		
		insuranceData6.setEffectiveDate(effectiveDateCalendar6.getTime());
		
		Calendar expiryDateCalendar6 = new GregorianCalendar(2014,1,25);		
		insuranceData6.setExpiryDate(expiryDateCalendar6.getTime());
		
		inactiveList.add(insuranceData6);
		
		// Record 5
		InsuranceData insuranceData7 = new InsuranceData();
		insuranceData7.setInsuranceType("Flood");
		insuranceData7.setStatus("Cancelled");
		insuranceData7.setPolicyNumber("NA");
		insuranceData7.setPolicyType("LP Gap");
		insuranceData7.setCoverageType("Building");
		insuranceData7.setCoverageAmount(100000D);
		
		Calendar effectiveDateCalendar7 = new GregorianCalendar(2013,1,25);		
		insuranceData7.setEffectiveDate(effectiveDateCalendar7.getTime());
		
		Calendar expiryDateCalendar7 = new GregorianCalendar(2014,1,25);		
		insuranceData7.setExpiryDate(expiryDateCalendar7.getTime());
		
		inactiveList.add(insuranceData7);

		Collections.sort(inactiveList, new InsuranceData());
		Collections.reverse(inactiveList);
		
		inactiveInsuranceData = new InsuranceData[inactiveList.size()];
		inactiveInsuranceData =  inactiveList.toArray(inactiveInsuranceData);
		
		
	}
	
	public String getCollateralAddress() {
		return collateralAddress;
	}
	public void setCollateralAddress(String collateralAddress) {
		this.collateralAddress = collateralAddress;
	}
	public String getCollateralCity() {
		return collateralCity;
	}
	public void setCollateralCity(String collateralCity) {
		this.collateralCity = collateralCity;
	}
	public String getCollateralState() {
		return collateralState;
	}
	public void setCollateralState(String collateralState) {
		this.collateralState = collateralState;
	}
	public String getCollateralZipCode() {
		return collateralZipCode;
	}
	public void setCollateralZipCode(String collateralZipCode) {
		this.collateralZipCode = collateralZipCode;
	}
	public CollateralStatus getCollateralStatus() {
		return collateralStatus;
	}
	public void setCollateralStatus(CollateralStatus collateralStatus) {
		this.collateralStatus = collateralStatus;
	}
	public CustomerData getBorrowerData() {
		return borrowerData;
	}
	public void setBorrowerData(CustomerData borrowerData) {
		this.borrowerData = borrowerData;
	}
	public InsuranceData[] getActiveInsuranceData() {
		return activeInsuranceData;
	}
	public void setActiveInsuranceData(InsuranceData[] activeInsuranceData) {
		this.activeInsuranceData = activeInsuranceData;
	}
	public InsuranceData[] getInactiveInsuranceData() {
		return inactiveInsuranceData;
	}
	public void setInactiveInsuranceData(InsuranceData[] inactiveInsuranceData) {
		this.inactiveInsuranceData = inactiveInsuranceData;
	}
	
}
