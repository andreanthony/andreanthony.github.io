package com.jpmorgan.cib.wlt.ctrac.service.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.LookUpCodeService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class AbstractSearchCollateralServiceImpl {

	@Autowired
    protected LookUpCodeService lookUpCodeService;
	
	protected List<LookUpCode> getStateCodes() {
		return lookUpCodeService.findByCodeSetInSortOrder(CtracAppConstants.STATES_CODES);
	}

}
