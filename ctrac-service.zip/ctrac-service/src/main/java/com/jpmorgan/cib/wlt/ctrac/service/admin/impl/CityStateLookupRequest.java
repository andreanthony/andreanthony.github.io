package com.jpmorgan.cib.wlt.ctrac.service.admin.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "zipCode"
})
@XmlRootElement(name = "CityStateLookupRequest")
public class CityStateLookupRequest {

    @XmlElement(name = "ZipCode", required = true)
    protected CityStateLookupRequest.ZipCode zipCode;
    @XmlAttribute(name = "USERID")
    protected String userid;

    /**
     * Gets the value of the zipCode property.
     * 
     * @return
     *     possible object is
     *     {@link CityStateLookupRequest.ZipCode }
     *     
     */
    public CityStateLookupRequest.ZipCode getZipCode() {
        return zipCode;
    }

    /**
     * Sets the value of the zipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link CityStateLookupRequest.ZipCode }
     *     
     */
    public void setZipCode(CityStateLookupRequest.ZipCode value) {
        this.zipCode = value;
    }

    /**
     * Gets the value of the userid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERID() {
        return userid;
    }

    /**
     * Sets the value of the userid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERID(String value) {
        this.userid = value;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "zip5"
    })
    public static class ZipCode {

        @XmlElement(name = "Zip5")
        protected String zip5;
        @XmlAttribute(name = "ID")
        protected Integer id;

        /**
         * Gets the value of the zip5 property.
         * 
         */
        public String getZip5() {
            return zip5;
        }

        /**
         * Sets the value of the zip5 property.
         * 
         */
        public void setZip5(String value) {
            this.zip5 = value;
        }

        /**
         * Gets the value of the id property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getID() {
            return id;
        }

        /**
         * Sets the value of the id property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setID(Integer value) {
            this.id = value;
        }

    }

}

