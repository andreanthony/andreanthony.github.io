package com.jpmorgan.cib.wlt.ctrac.service.dto.base;


import com.jpmorgan.cib.wlt.ctrac.service.statemachine.NewItemState;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;


public class FloodRemapTaskStateContext {
	
	private TaskState currentTaskState;
	//TODO:
//	i)Add DTO to hold TM information that is required for transition
	//Return the boolean value depending on the success/failure status

	private FloodRemapData floodRemapData;
	
	public FloodRemapTaskStateContext()
	{
		currentTaskState = new NewItemState();
	}

	public FloodRemapTaskStateContext(TaskState newTaskState)
	{
		this.currentTaskState = newTaskState;
	}
	
	public TaskState getCurrentTaskState() {
		return currentTaskState;
	}

	public void setCurrentState(TaskState currentTaskState) {
		this.currentTaskState = currentTaskState;
	}

	public FloodRemapData getFloodRemapData() {
		return floodRemapData;
	}

	public void setFloodRemapData(FloodRemapData floodRemapData) {
		this.floodRemapData = floodRemapData;
	}	
	
}
