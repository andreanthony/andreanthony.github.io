/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.service.batch;

/**
 * @author Q003321
 *
 */
public interface PolicyRenewalBatchService {
	
	void initiatePolicyRenewalReviewProcess();

}
