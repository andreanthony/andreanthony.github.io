package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class EvidenceOfInsuranceRuleWorker extends AbstractBIRRuleWorker {
	
	public EvidenceOfInsuranceRuleWorker(String key) {
		super(key, true);
	}

	public static final Set<String> ACCEPTABLE_EOI_TYPE_CODES = new HashSet<String>(
			Arrays.asList("ANCAPYFPOF","PPTCSBAC","PPTCEA","AWP","BWP","NP"));
	
	public static final Set<String> ACTION_REQUIRED_EOI_TYPE_CODES = new HashSet<String>(
			Arrays.asList("PPTCRAEA","PPTCRA")); // obsolete
	
	public static final Set<CoverageType> ACTION_REQUIRED_COVERAGE_TYPES = new HashSet<CoverageType>(
			Arrays.asList(CoverageType.PRIMARY,CoverageType.PRIMARY_AND_EXCESS));
	
	public static final Set<String> PRIVATE_POLICY_EOI_TYPE_CODES = new HashSet<String>(
			Arrays.asList("PP","PPTCSBAC")); 
	
	@Override
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		BIRRuleConclusionDTO eoiTypeConclusion =
				borrowerInsuranceReviewData.getBirRuleConclusions().get("eoiType");
		BorrowerInsuranceReviewConclusion birConclusion = null;
		if (ACCEPTABLE_EOI_TYPE_CODES.contains(borrowerInsuranceReviewData.getEoiType())) {
			birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
		} else if (ACTION_REQUIRED_EOI_TYPE_CODES.contains(borrowerInsuranceReviewData.getEoiType())) { // obsolete
			birConclusion = BorrowerInsuranceReviewConclusion.ACTION_REQUIRED;
		} else if (PRIVATE_POLICY_EOI_TYPE_CODES.contains(borrowerInsuranceReviewData.getEoiType())) {
			if (ACTION_REQUIRED_COVERAGE_TYPES.contains(borrowerInsuranceReviewData.getProofOfCoverageData().getCoverageType())) {
				birConclusion = BorrowerInsuranceReviewConclusion.ACTION_REQUIRED;
			} else {
				birConclusion = BorrowerInsuranceReviewConclusion.ACCEPTABLE;
			}				
		} else {
			birConclusion = BorrowerInsuranceReviewConclusion.REJECTED;
		}
		eoiTypeConclusion.setConclusion(birConclusion.name());
	}

}
