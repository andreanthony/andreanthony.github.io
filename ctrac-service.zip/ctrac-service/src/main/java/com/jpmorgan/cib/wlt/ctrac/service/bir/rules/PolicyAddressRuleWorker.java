package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;

public class PolicyAddressRuleWorker extends AbstractBIRRuleWorker {
	
	public PolicyAddressRuleWorker(String key) {
		super(key, false, true);
	}

	@Override
	public void populateExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData) {
		Iterator<BIRCollateralDetailsDTO> collateralDetailsIter = 
				borrowerInsuranceReviewData.getCollateralDetailsMap().values().iterator();
		while (collateralDetailsIter.hasNext()) {
			BIRCollateralDetailsDTO collateralDetails = collateralDetailsIter.next();
			
			StringBuffer fullRequiredAddress = new StringBuffer(collateralDetails.getCollateralAddressData().getFormattedFullAddress()); 
			Iterator<ProvidedCoverageDTO> providedCoverageIter =
					borrowerInsuranceReviewData.getProofOfCoverageData().getInsurableAssetProvidedCoverageMap().values().iterator();
			Set<Integer> sortOrders = new HashSet<Integer>();
			while (providedCoverageIter.hasNext()) {
				ProvidedCoverageDTO providedCoverage = providedCoverageIter.next();
				InsurableAssetDTO insurableAsset = providedCoverage.getInsurableAssetDTO();
				if (!sortOrders.contains(insurableAsset.getSortOrder()) && providedCoverage.hasNonZeroCoverage()) {
					CtracStringUtil.addValueWithSeparator(fullRequiredAddress, insurableAsset.getDescription(), "<br/>  - ");
					sortOrders.add(insurableAsset.getSortOrder());
				}
			}
			
			/* 
			 * 1. Find all buildings on this collateral for which this policy is providing coverage
			 * 2. Append the building names with HTML to to the full address
			 * */ 
			populateCollateralExceptionData(exceptionEmailData, collateralDetails,
					collateralDetails.getPolicyAddressData().getFormattedFullAddress(),
					fullRequiredAddress.toString());
		}
	}

}
