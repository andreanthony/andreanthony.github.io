package com.jpmorgan.cib.wlt.ctrac.service.aspect;

import java.io.Serializable;

public class AuditInformationBean implements Serializable {

	private static final long serialVersionUID = -8753311192753311462L;
	
	private String userId;
	
	private String userSid;

	private String userFirstName;
	private String userLastName;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserSid() {
		return userSid;
	}

	public void setUserSid(String userSid) {
		this.userSid = userSid;
	}
	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;}

	public String getUserFullName() {
		return  userFirstName+ " "+ userLastName;
	}


		
}
