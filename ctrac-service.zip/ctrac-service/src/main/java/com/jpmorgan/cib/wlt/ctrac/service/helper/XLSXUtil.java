package com.jpmorgan.cib.wlt.ctrac.service.helper;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CREATE_REFUND_REQUEST;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CREATE_WIRE_REQUEST;
import static org.apache.commons.lang.StringUtils.isNotBlank;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.InboundDataFile;

@Component
public class XLSXUtil {

	private static final Logger logger = Logger.getLogger(XLSXUtil.class);
	
	public static Iterator<Row> getExcelRowIterator(InboundDataFile inboundDataFile){
		InputStream inboundInputStream;
		byte[] fileContents = inboundDataFile.getFileContent();
		inboundInputStream = new ByteArrayInputStream(fileContents);
		return getExcelRowIterator(inboundInputStream);		
	}
	
	public static Iterator<Row> getExcelRowIterator(File inboundDataFile){
		InputStream inboundInputStream;
		try {
			inboundInputStream = new FileInputStream(inboundDataFile);
			return getExcelRowIterator(inboundInputStream);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(), e);
			throw new CTracApplicationException("E0135", CtracErrorSeverity.CRITICAL);
		}	
	}
	
	public static Iterator<Row> getExcelRowIterator(InputStream inboundInputStream){
		OPCPackage pkg = null;
		XSSFWorkbook workbook = null; 
		try {
			// Check whether input file is xlsx.
			pkg = OPCPackage.open(inboundInputStream);
			workbook = new XSSFWorkbook(pkg); 
			Sheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rowIterator = sheet.iterator();
			workbook.close();
			pkg.close();
			return rowIterator;
		}catch (InvalidFormatException e) {
			logger.error(e.getMessage(), e);
			throw new CTracApplicationException("E0135", CtracErrorSeverity.CRITICAL);
		}
		catch (IOException e) {
			logger.error(e.getMessage(), e);
			throw new CTracApplicationException("E0135", CtracErrorSeverity.CRITICAL);
		}finally{
			try{
				if(workbook != null){
					workbook.close();
				}
				if(pkg != null){
					pkg.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}	
	}
	
	public static boolean isEmptyRow(Row row){
		boolean isEmptyRow = true;
		for(int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++){
			Cell cell = row.getCell(cellNum);
			if(cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK && isNotBlank(cell.toString())){
				isEmptyRow = false;
			}    
		}
		return isEmptyRow;
	}
}
