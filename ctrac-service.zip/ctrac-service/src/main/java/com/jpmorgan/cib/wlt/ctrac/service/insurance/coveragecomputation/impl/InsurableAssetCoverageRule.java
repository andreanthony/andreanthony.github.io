package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BorrowerInsuranceReviewDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.bir.BorrowerInsuranceReviewDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.helper.coverage.ProvidedCoverageUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.InsurableAssetService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public abstract class InsurableAssetCoverageRule extends C3Rule {

	protected final InsurableAsset insurableAsset;
	protected final CoverageActionData coverageActionData;
	protected InsurableAssetService insurableAssetService;

	private static final Logger logger = Logger.getLogger(InsurableAssetCoverageRule.class);

	protected InsurableAssetCoverageRule(Collateral collateral, WorkItem triggerWorkItem, InsurableAsset insurableAsset,
			CoverageActionData coverageActionData) {
		super(collateral, triggerWorkItem);
		this.insurableAsset = insurableAsset;
		this.coverageActionData = coverageActionData;
		init();
	}

	/**
	 * Cancel the single activeLpCoverage.
	 */
	protected void cancelLpPolicy(CoverageActionResult globalResults, Date cancellationEffectiveDate, ProofOfCoverage lpPolicy) {
		CancellationReason cancellationReason = getCancellationReason(cancellationEffectiveDate, lpPolicy);
		Date thirtyDayRegPeriod = getThirtyDayRegulatoryPeriod(cancellationReason);

		/**
		 * cancel this LP policy
		 */
		ProofOfCoverageDTO lpPolicyToCancel = getProofOfCoverageData(lpPolicy);
		prepareCancelTheProofOfCoverage(globalResults, lpPolicyToCancel, coverageActionData.getToday(),
				DateFormatter.toString(cancellationEffectiveDate), DateFormatter.toString(thirtyDayRegPeriod),
				cancellationReason);

	}

	protected ProofOfCoverageDTO getProofOfCoverageData(ProofOfCoverage proofOfCoverage) {
		Collateral collateral = insurableAsset.getBuilding().getCollateral();
		return insuranceMngtService.mapProofsOfCoverage(proofOfCoverage, collateral != null ? collateral.getRid() : null);
	}

	/**
	 * Figure out the CancellationReason based on the borrower policies becoming effective.
	 * @param cancellationEffectiveDate
	 * @param lpPolicy
	 * @return
	 */
	protected CancellationReason getCancellationReason(Date cancellationEffectiveDate, ProofOfCoverage lpPolicy) {
		CancellationReason cancellationReason = CancellationReason.INSURANCE_NOT_NEEDED;
		if(lpPolicy.getGapBorrowerPolicyRid() != null) {//TODO check for date lapse when implemented
			cancellationReason = CancellationReason.BORROWER_POLICY_RECEIVED_AMOUNT_GAP;
		}
		else {
			ProofOfCoverage  borrowerPolicyRecieved = getBorrowerPolicyRecieved(
					lpPolicy.getCoverageType_(), cancellationEffectiveDate);

			if(borrowerPolicyRecieved != null) {
				cancellationReason = CancellationReason.BORROWER_POLICY_RECEIVED;
			}
		}
		return cancellationReason;
	}

	public ProofOfCoverage getBorrowerPolicyRecieved(CoverageType coverageType, Date effectiveOn) {
		Collection<CoverageType> coverageTypes = CoverageType.getRelatedTypes(coverageType);
		for (ProofOfCoverage activePolicy : coverageActionData.getAllActivePolicies()) {
			if ((activePolicy.getLpAction_() == LPActions.NEW_BP || activePolicy.getLpAction_() == LPActions.PENDING_C3) &&
					activePolicy.getPolicyType_().isBorrowerPolicy() && activePolicy.isEffectiveOn(effectiveOn)
					&& coverageTypes.contains(activePolicy.getCoverageType_())) {
				return activePolicy;
			}
		}
		return null;
	}

	/**
	 * Cancel all Lender placed policies with the proper cancellation date
	 *
	 * @param insurableAsset
	 * @param result
	 */
	protected List<ProofOfCoverageDTO>  prepareCanceltheInsurableAssetLpPolicies(InsurableAsset insurableAsset, CoverageActionResult result,
			WorkItem triggerWorkItem, CancellationReason cancellationReason) {
		Collection<ProofOfCoverage> lpCoverages = ProvidedCoverageUtil.getAllProofOfCovOfType(true, PolicyType.lpPolicyTypes(), coverageActionData.getAllActivePolicies());

		// FIXME: do not cancel prior to the LP effective date
		Date cancellationEffDate = result.getCoverageDate();
		String cancelattionEffData = DateFormatter.toString(cancellationEffDate);

		Date thirtyDayRegPeriod = getThirtyDayRegulatoryPeriod(cancellationReason);
		String thirtyDayRegData = DateFormatter.toString(thirtyDayRegPeriod);

		Long collateralRid = insurableAsset.getBuilding().getCollateral() != null ?
				insurableAsset.getBuilding().getCollateral().getRid() : null;
		List<ProofOfCoverageDTO> proofOfCoverageDtoToCancel = prepareCancelTheProofOfCoverages(result, cancellationReason, lpCoverages, cancelattionEffData,thirtyDayRegData,collateralRid);
		return proofOfCoverageDtoToCancel;
	}

	protected List<ProofOfCoverageDTO> prepareCancelTheProofOfCoverages(CoverageActionResult result, CancellationReason cancellationReason,
			Collection<ProofOfCoverage> lpCoverages, String cancelattionEffData, String thirtyDayRegData,Long collateralRid) {
		List<ProofOfCoverageDTO> cancelledProofOfCoverageDTO = new ArrayList<ProofOfCoverageDTO>();
		for (ProofOfCoverage lpCoverage : lpCoverages) {

			ProofOfCoverageDTO lpToCancel = insuranceMngtService.mapProofsOfCoverage(lpCoverage, collateralRid);

			String cancellationEffectiveDate = cancelattionEffData;
			try {
				if(lpCoverage.getEffectiveDate().after(DateFormatter.parseDate(cancelattionEffData))) {
					cancellationEffectiveDate = DateFormatter.toString(lpCoverage.getEffectiveDate());
				}
			} catch(Exception e) {
				logger.debug("swallowing: " + e.getMessage());
			}

			ProofOfCoverageDTO dto = prepareCancelTheProofOfCoverage(result, lpToCancel, coverageActionData.getToday(), cancellationEffectiveDate, thirtyDayRegData,cancellationReason);
			cancelledProofOfCoverageDTO.add(dto);
		}
		return cancelledProofOfCoverageDTO;
	}

	@Override
	public Integer getPriority() {
		return 10;
	}

	@Override
	protected void init() {
		insurableAssetService = ApplicationContextProvider.getContext().getBean(InsurableAssetService.class);
		super.init();
	}

	protected Date getThirtyDayRegulatoryPeriod(CancellationReason cancellationReason) {
		logger.debug("getThirtyDayRegulatoryPeriod::BEGIN");
		Date eoiReceivedDate = null;
		if (cancellationReason != null && cancellationReason.isBorrowerPolicyRecieved()) {
			for (ProvidedCoverage providedCoverage : insurableAsset.getProvidedCoverages()) {
				ProofOfCoverage proofOfCoverage = providedCoverage.getProofOfCoverage();
				if ((proofOfCoverage.getLpAction_() == LPActions.NEW_BP)
						&& (proofOfCoverage.getPolicyType_().isBorrowerPolicy())) {
					BorrowerInsuranceReviewDetailsRepository borrowerInsuranceReviewDetailsRepository =
							ApplicationContextProvider.getContext().getBean(BorrowerInsuranceReviewDetailsRepository.class);
					BorrowerInsuranceReviewDetails borrowerInsuranceReviewDetails =
							borrowerInsuranceReviewDetailsRepository.findByProofOfCoverageRid(proofOfCoverage.getRid());
					eoiReceivedDate = borrowerInsuranceReviewDetails.getEoiReceivedDate();
					break;
				}
			}
		}

		if (eoiReceivedDate == null) {
			logger.error("No eoiReceivedDate found for insurableAsset=" + insurableAsset.getRid() + ", using today");
			eoiReceivedDate = coverageActionData.getToday();
		}
		Date thirtyDateRegPeriod = CalendarDayUtil.addCalendarDays(30, eoiReceivedDate);
		logger.debug("thirtyDateRegPeriod=" + thirtyDateRegPeriod);
		logger.debug("getThirtyDayRegulatoryPeriod::END");
		return thirtyDateRegPeriod;
	}

}
