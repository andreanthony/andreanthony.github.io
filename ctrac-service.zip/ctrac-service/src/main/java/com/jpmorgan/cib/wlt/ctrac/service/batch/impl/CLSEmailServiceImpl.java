package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LPPolicyRequestRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EmailTemplateRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.CLSEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.cls.CLSExcelFile;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class CLSEmailServiceImpl implements CLSEmailService{

	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Autowired
	private LPPolicyRequestRepository lpPolicyRequestRepository;

	@Autowired
	private PerfectionTaskRepository perfectionTaskRepository;

	@Autowired
	private DateCalculator dateCalculator;

	@Autowired
	private LoanManagementService loanManagementService;

	@Autowired
	private InsuranceMngtService insuranceMngtService;

	@Autowired
	private Environment env;

	@Autowired
	private FloodEmailService floodEmailService;

	private static final Logger logger = Logger.getLogger(CLSEmailServiceImpl.class);

	@Override
	@Transactional
	public void createAndSendEmail(Long taskId) {
		logger.debug("createAndSendEmail: start");
		if(taskId == null){
			logger.error("Task ID is null.");
			return;
		}
		Map<LoanSystem, BigDecimal> premiumDebits = new HashMap<LoanSystem, BigDecimal>();
	    Map<LoanSystem, BigDecimal> refundDebits = new HashMap<LoanSystem, BigDecimal>();
		PerfectionTask task = perfectionTaskRepository.findOne(taskId);
		List<LPPolicyRequest> policies = lpPolicyRequestRepository.findByAlthansBatchItemRid(task.getWorkItem().getRid());
		AlthansLPFileGenerator generator = new AlthansLPFileGenerator();
		for(LPPolicyRequest policy: policies){
			LoanSystem loanSystem = loanManagementService.getLoanSystem(policy.getProofOfCoverage().getRid());
			LenderPlaceItem lpItem = policy.getLenderPlaceItem();
			if(generator.isNewOrRenewalPolicyRequest(policy.getTransCode())){
				//get the total premium amount
				BigDecimal premiumAmount = getTotalPremiumAmount(lpItem);
				if(premiumAmount.compareTo(BigDecimal.ZERO) != 0){
					addToMap(loanSystem, premiumAmount, premiumDebits);
				}
			} else if(generator.getLpCancellationCode().equals(policy.getTransCode())){
				//get the total refund amount
				BigDecimal refundAmount = getTotalRefundAmount(lpItem);
				if(refundAmount.compareTo(BigDecimal.ZERO) != 0 && insuranceMngtService.isWireRefundNeeded(lpItem)){
					addToMap(loanSystem, refundAmount, refundDebits);
				}
			}
		}
		Date effectiveDate = dateCalculator.addBusinessDays(2, dateCalculator.getCurrentReferenceDate());
		File attachment = createAttachment(task.getWorkItem().getRid(), premiumDebits, refundDebits, effectiveDate);
		EmailTemplate template = emailTemplateRepository.findByEmailTemplateId("CLSHASPREMIUM");
		EmailAttributeHolder emailAttributeHolder = createEmailContentForTemplate(template);
		emailAttributeHolder.setSingleFileAttachment(attachment);
		setEmailAddresses(emailAttributeHolder);
		floodEmailService.sendEmail(emailAttributeHolder);
		attachment.delete();
		logger.debug("createAndSendEmail: end");
	}

	@Override
	@Transactional
	public void createAndSendNoTransactionEmail() {
		logger.debug("createAndSendNoTransactionEmail: start");
		EmailTemplate template = emailTemplateRepository.findByEmailTemplateId("CLSNOPREMIUM");
		EmailAttributeHolder emailAttributeHolder = createEmailContentForTemplate(template);
		setEmailAddresses(emailAttributeHolder);
		floodEmailService.sendEmail(emailAttributeHolder);
		logger.debug("createAndSendNoTransactionEmail: end");
	}

	EmailAttributeHolder createEmailContentForTemplate(EmailTemplate template){
		return CtracEmailSender.createEmailContent(null, template);
	}

	private File createAttachment(Long fileId, Map<LoanSystem, BigDecimal> premiumDebits,  Map<LoanSystem, BigDecimal> refundDebits, Date effectiveDate) {
		logger.debug("createAttachment: start");
        FileOutputStream fos = null;
        XSSFWorkbook workbook = null;
        try {
            File attachment = new File("Althans Weekly Posting " + fileId + " " + new LocalDate().toString() + ".xlsx");
			fos = new FileOutputStream(attachment);
			logger.debug(attachment.getAbsolutePath());
			workbook = new XSSFWorkbook();
			CLSExcelFile excelFile = new CLSExcelFile();
			excelFile.setPremiumDebits(premiumDebits);
			excelFile.setRefundDebits(refundDebits);
			excelFile.insertInto(workbook, effectiveDate);
			workbook.write(fos);
			workbook.close();
            logger.debug("createAttachment: end");
			return attachment;
		} catch (Exception e) {
			logger.error(e.getMessage());
            logger.error("no attachment created for workItem: " + fileId);
            throw new CTracApplicationException("E0182", CtracErrorSeverity.CRITICAL);
		} finally {
		    if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    logger.error(e.getMessage());
                }
            }
            if (workbook != null) {
                try {
                    workbook.close();
                } catch (IOException e) {
                    logger.error(e.getMessage());
                }
            }
        }
	}

	private void addToMap(LoanSystem loanSystem, BigDecimal amount, Map<LoanSystem, BigDecimal> loanSysMap) {
		logger.debug("addToMap: start");
		if(loanSysMap.containsKey(loanSystem)){
			loanSysMap.put(loanSystem, amount.add(loanSysMap.get(loanSystem)));
		}
		else{
			loanSysMap.put(loanSystem, amount);
		}
		logger.debug("addToMap: end");
	}

	private void setEmailAddresses(EmailAttributeHolder email){
		email.addToAddress(env.getRequiredProperty("cls.money.transfer.email.address"));
		email.addCcAddress(env.getRequiredProperty("autocopy.email.address.flood.service"));
		email.addCcAddress(env.getRequiredProperty("autocopy.email.address.ctl.flood.service"));
		email.addCcAddress(env.getRequiredProperty("cls.proof.and.control.email.address"));
		email.setFromAddress(env.getRequiredProperty("autocopy.email.address.flood.service"));
	}

	private BigDecimal getTotalPremiumAmount(LenderPlaceItem lpItem){
		BigDecimal totalPremiumAmount = lpItem.getPremiumAmount() == null? BigDecimal.ZERO : lpItem.getPremiumAmount();
		totalPremiumAmount = totalPremiumAmount.add(lpItem.getBankPremiumAmount() == null? BigDecimal.ZERO : lpItem.getBankPremiumAmount());
		return totalPremiumAmount;
	}

	private BigDecimal getTotalRefundAmount(LenderPlaceItem lpItem){
		BigDecimal totalRefundAmount = lpItem.getRefundAmount() == null? BigDecimal.ZERO : lpItem.getRefundAmount();
		totalRefundAmount = totalRefundAmount.add(lpItem.getBankRefundAmount() == null? BigDecimal.ZERO : lpItem.getBankRefundAmount());
		return totalRefundAmount;
	}
}
