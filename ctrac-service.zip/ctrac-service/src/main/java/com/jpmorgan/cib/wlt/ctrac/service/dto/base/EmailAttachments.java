package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

public class EmailAttachments {

	private String taskUUId;
	private Set<FileItem> files;
	
   /**
   * used for cleanup purposes, all file older than 1hr will be cleanup automatically
   */
   private final Date insetedDate;
	
	
	public EmailAttachments(String taskUUId){
		this.taskUUId = taskUUId;
		this.files = new HashSet<FileItem>();
		insetedDate= new Date();
	}
	
	public Set<FileItem> getFiles(){
		return this.files;
	}
	
	public String getTaskUUId(){
		return this.taskUUId;
	}
	
	public void pushFile(FileItem file){
		//optionally remove the entry if any
		if(this.files.size()>0){
			this.files.remove(file);
		}
		
		if (null != file) this.files.add(file);
	}
	
	//optionally remove and return the entry if any
	public FileItem popFile(FileItem file){
		
		FileItem result =null;
		for(FileItem candidate:  this.files)
			if(candidate.equals(file))
				result=candidate;
		
		this.files.remove(result);		
		return result;
	}
		
	public void pushAllFiles(Set<FileItem> file) {
		if (null != file && !file.isEmpty()) {
			this.files.removeAll(file);
			this.files.addAll(file);
		}
	}
	
	public String toString ( ){
		StringBuilder response = new StringBuilder();
		for (FileItem file : this.files ){
			response.append(" "+file.getName()+":"+file.getTaskUUId()+" ");
		}
		return response.toString();
	}
	
	
   public List<MultipartFile> getAllFilesAsList() {
	   List<MultipartFile> result = new ArrayList<MultipartFile>();
	   for (FileItem candidate:  this.files) {
		   result.add(candidate.getFileItem());
	   }
	   return result;
   }

   public Date getInsetedDate() {
        return insetedDate;
   }
	
}
