package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

/**
 * Created by E704298 on 7/11/2017.
 */
public class SelectOption implements Serializable {
	private static final long serialVersionUID = 3953244370852597679L;
	
    private String code;
    private String description;

    public SelectOption() {}

    public SelectOption(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
