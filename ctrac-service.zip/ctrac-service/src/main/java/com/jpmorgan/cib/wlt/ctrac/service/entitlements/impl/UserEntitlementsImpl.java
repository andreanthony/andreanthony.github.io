package com.jpmorgan.cib.wlt.ctrac.service.entitlements.impl;


import java.text.SimpleDateFormat;
import java.util.*;
import javax.annotation.Resource;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.UserEntitlementAction;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements.GroupIdentifier;
import com.jpmorgan.cib.wlt.ctrac.service.security.CtracGrantedAuthority;
import com.jpmorgan.cib.wlt.ctrac.service.security.CtracUserDetailsService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EncryptionUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupMembers;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Groups;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.GroupMembersRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.GroupsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.UsersRepository;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.CtracUserInventoryHandler;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;

import net.jpmchase.cbhub.rsam.RSAMEnvironment;
import net.jpmchase.cbhub.rsam.UserInventoryReporter;
import net.jpmchase.cbhub.rsam.data.ioconsole.IOConsoleUserInventoryRequestData;


/**
 * @author Q003321
 *
 */
@Service
public class UserEntitlementsImpl implements UserEntitlementService {

	private static final Logger logger = Logger.getLogger(UserEntitlementsImpl.class);
	private static final String PROPERTY_NAME_RSAM_API_KEY = "rsam.api.key";
	private static final String PROPERTY_NAME_RSAM_USER = "rsam.api.user";
	private static final String PROPERTY_NAME_ASSET_ID = "rsam.asset.id";
	private static final String PROPERTY_DEFAULT_PROFILE_CATEGORY = "ctrac.default.entitlement.category";
	private static final String PROPERTY_DEFAULT_PROFILE_GROUP = "ctrac.default.entitlement.group";
	private static final String PROPERTY_JANUS_URL = "janus.api.url";
	private static final String PROPERTY_JANUS_KEY = "janus.api.key";
	private static final String PROPERTY_JANUS_ENTITLEMENT_NAME = "janus.api.entitlement.name";
	private static final String CONST_RSAM_USER = "RSAM_AUTO_PROVISION";
	private static final String CONST_ADMIN_USER = "ADMIN";

	@Autowired protected LookupCodeRepository lookupCodeRepository;
	@Autowired protected UsersRepository usersRepository;
	@Autowired protected GroupsRepository groupsRepository;
	@Autowired protected GroupMembersRepository groupMembersRepository;
	@Autowired private CtracUserDetailsService ctracUserDetailsService;
	@Autowired private CtracObjectMapper ctracObjectMapper;

	@Resource
	private Environment env;

	@Transactional(readOnly = true)
	public List<IOConsoleUserInventoryRequestData.UserRecord> getUserCertificationDetails() {
		List<IOConsoleUserInventoryRequestData.UserRecord> rsamUsers = new ArrayList<IOConsoleUserInventoryRequestData.UserRecord>();
		List<Users> ctracUsers = usersRepository.findAll();
		for(Users user: ctracUsers) {
			user = CtracBaseEntity.deproxy(user, Users.class);
			IOConsoleUserInventoryRequestData.UserRecord rsamUser = new IOConsoleUserInventoryRequestData.UserRecord();
			rsamUser.setActive(user.getEnabled());
			rsamUser.setLastActivityDate(user.getLastLoginDate() == null?user.getInsertedDate():user.getLastLoginDate());
			rsamUser.setSID(user.getSid());
			rsamUser.setUsername(user.getUsername());
			rsamUser.setUserCreatedDate(user.getInsertedDate());
			for(GroupMembers group : user.getGroupMembers()) {
				rsamUser.addProfile(group.getRSAMProfileName());
			}
			rsamUsers.add(rsamUser);
		}
		return rsamUsers;
	}

	@Transactional(readOnly = true)
	public UsersDto getUserDetails(String sid) {
		Users user = usersRepository.findBySidIgnoreCase(sid);
		user = CtracBaseEntity.deproxy(user, Users.class);
		UsersDto dto = ctracObjectMapper.map(user, UsersDto.class);
		if(user != null) {
			for (GroupMembers group : user.getGroupMembers()) {
				dto.getGroups().add(new GroupDto(group.getGroups().getCategoryName(), group.getGroups().getGroupName()));
			}
		}
		return dto;
	}

	@Transactional(readOnly = true)
	public UsersDto getUserDetailsbyUserName(String userName) {
		Users user = usersRepository.findByUsernameIgnoreCase(userName);
		user = CtracBaseEntity.deproxy(user, Users.class);
		UsersDto dto = ctracObjectMapper.map(user, UsersDto.class);
		if(user != null) {
			for (GroupMembers group : user.getGroupMembers()) {
				dto.getGroups().add(new GroupDto(group.getGroups().getCategoryName(), group.getGroups().getGroupName()));
			}
		}
		return dto;
	}

	@Override
	@Transactional(readOnly = true)
	public UserEntitlementsDTO getByJanusUsername(String janusUsername) {
		try {
			Users user = usersRepository.findByUsernameIgnoreCaseAndEnabled(janusUsername, true);
			if (user == null) {
				throw new CtracAjaxException("Invalid Janus username.");
			}
			UserEntitlementsDTO userEntitlementsDTO = new UserEntitlementsDTO();
			userEntitlementsDTO.setFirstName(user.getFirstName());
			userEntitlementsDTO.setLastName(user.getLastName());
			userEntitlementsDTO.setJanusUsername(user.getUsername());
			userEntitlementsDTO.setSid(user.getSid());
			List<GrantedAuthority> authorities = ctracUserDetailsService.loadMyUserAuthorities(janusUsername);
			for (GrantedAuthority authority : authorities) {
				if (authority instanceof CtracGrantedAuthority) {
					userEntitlementsDTO.addAuthority(authority.getAuthority(), ((CtracGrantedAuthority) authority).getLineOfBusinesses());
				}
			}
			return userEntitlementsDTO;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new CtracAjaxException("Something went wrong.");
		}
	}

	@Override
	@Transactional(readOnly = true)
	public void processWeeklyCertification() throws Exception {
		String apiKey = EncryptionUtil.decrypt(env.getRequiredProperty(PROPERTY_NAME_RSAM_API_KEY));
		String apiUser = env.getRequiredProperty(PROPERTY_NAME_RSAM_USER);
		String assetId = env.getRequiredProperty(PROPERTY_NAME_ASSET_ID);
		CtracUserInventoryHandler handler = new CtracUserInventoryHandler(apiKey, apiUser, assetId, getUserCertificationDetails());
		UserInventoryReporter reporter = new UserInventoryReporter(getRSAMEnvironment(), handler);
		reporter.runNow();
	}

	/**
	 * CTRAC is onboarded in UAT for testing and PROD only.  So any lower
	 * environment communication is pointed at RSAM UAT.
	 * @return
	 */
	private RSAMEnvironment getRSAMEnvironment() {
		String serverEnv = env.getActiveProfiles()[0];
		if(serverEnv != null && (serverEnv.equalsIgnoreCase("PROD") || serverEnv.equalsIgnoreCase("UAT"))) {
			//UAT and PROD point to RSAM prod
			return RSAMEnvironment.PROD;
		} else {
			//local,dev,sit point to RSAM-UAT environment
			return RSAMEnvironment.UAT;
		}
	}

	@Transactional(noRollbackFor = {CTracApplicationException.class, IllegalArgumentException.class})
	public UsersDto processAutoProvisioning(UsersDto request) throws Exception {
		Users user = null;
		switch (request.getAction()) {
			case ADD:
				user = usersRepository.findBySidIgnoreCase(request.getSid());
				if (user != null) {
					user = CtracBaseEntity.deproxy(user, Users.class);
				} else {
					request.setEnabled(false);
					user = ctracObjectMapper.map(request, Users.class);
					if(user.getFirstName() == null || user.getLastName() == null) {
						throw new IllegalArgumentException("Failed to create new user due to missing first and last name values.");
					}
					//setting the default values
					populateUserDefaultValues(user, CONST_RSAM_USER);
				}
				user.setEnabled(true);
				addGroup(user, request.getGroups());
				usersRepository.save(user);
				break;
			case DELETE:
				user = usersRepository.findBySidIgnoreCase(request.getSid());
				removeGroups(user,request);
				usersRepository.save(user);
				break;
			case REMOVE:
				deleteUser(request);
				break;
			default:
				logger.error("Not a valid RSAM provisioning request: action= " + request.getAction().getCode());
				throw new IllegalArgumentException("Not a valid RSAM provisioning request: action= " + request.getAction().getCode());
		}
		return request;
	}

	/**
	 * Creates a new Users record with default values populated
	 * @return Users instance
	 */
	private Users createUserRecord(String insertUser){
		Users user = new Users();
		//setting the default values
		populateUserDefaultValues(user, insertUser);
		return user;
	}

	/**
	 * populates a Users record with default values
	 */
	private void populateUserDefaultValues(Users user, String insertUser){
		//setting the default values
		user.setInsertedBy(insertUser);
		user.setInsertedDate(new Date());
		user.setEnabled(true);
	}

	/**
	 * Load the user object and de-proxy the user for a given sid
	 * @param sid - user sid
	 * @return Users
	 */
	private Users loadUserBySid(String sid){
		Users user = usersRepository.findBySidIgnoreCase(sid);
		user = user != null ? CtracBaseEntity.deproxy(user, Users.class):null;
		return user;
	}

	/**
	 * Process a User Entitlement change request where it is possible to:
	 * 		- Add a new user
	 * 		- Update an existing user record and assign / unAssign new groups to the user
	 * 		- Disable a user record - setting the enabled flag to false
	 * 		- Delete a user with its group member records from CTRAC DB
	 * @param request
	 * @param action
	 * @throws Exception
	 */
	@Override
	@Transactional
	public void processUserEntitlementRequest(ManageUserEntitlementRequest request,
											  UserEntitlementAction action) throws Exception {
		Users user;
		switch (action) {
			case ADD:
				user = createUserRecord(CONST_ADMIN_USER);
				ctracObjectMapper.map(request, user);
				performUserGroupManagementActions(user,request.getGroups());
				usersRepository.save(user);
				break;
			case UPDATE:
				user = loadUserBySid(request.getSid());
				if(user != null){
					ctracObjectMapper.map(request, user);
					performUserGroupManagementActions(user,request.getGroups());
					user.setEnabled(true);
					usersRepository.save(user);
				}
				break;
			case DISABLE:
				user = loadUserBySid(request.getSid());
				disableUser(user);
				break;
			case DELETE:
				user = loadUserBySid(request.getSid());
				deleteUser(user);
				break;
			default:
				break;
		}
	}

	/**
	 * Given a user and a list of group ID's to assign to the user, group ID's will get validated and assigned to the user if valid
	 * groups that were assigned to the user but are not included in the list will get unAssigned for the user
	 * @param user - User
	 * @param groupRids - List of group id's to assign
	 */
	void performUserGroupManagementActions(Users user, List<Long> groupRids){
		logger.debug("performUserGroupManagementActions:::START User:" + user.getSid() +
				(CollectionUtils.isNotEmpty(groupRids) ? ", groups:"+groupRids.toString() : StringUtils.EMPTY));
		//List down all the groups that are already assigned to the user
		List<Groups> alreadyAssignedGroups = new ArrayList<>();
		for (GroupMembers gm : user.getGroupMembers()) {
			alreadyAssignedGroups.add(gm.getGroups());
		}
		//Lookup the groups to assign based of the RID given in request
		List<Groups> groupsToAssignList = new ArrayList<>();
		if(CollectionUtils.isNotEmpty(groupRids)){
			for(Long rid: groupRids){
				Groups groupsRecord = groupsRepository.findOne(rid);
				if(groupsRecord != null){
					groupsToAssignList.add(groupsRecord);
				}
			}
		}
		//When groups to assign is empty - invalid request - User always need to have a group assigned to it
		if(groupsToAssignList.isEmpty()){
			throw new CTracApplicationException("admin.user.entitlement.no.group.assigned"
					,CtracErrorSeverity.TRIVIAL);
		}
		//Remove the groups from the user that are not part of the request
		Collection toRemoveList = CollectionUtils.subtract(alreadyAssignedGroups,groupsToAssignList);
		for(Object object: toRemoveList){
			Groups toRemove = (Groups) object;
			unAssignUserGroup(user, toRemove, StringUtils.EMPTY);
		}
		//Add all the groups to assign to the user instance
		for (Groups groupToAssign : groupsToAssignList) {
			user.addGroups(groupToAssign);
		}
		logger.debug("performUserGroupManagementActions:::END");
	}

	/**
	 * Fetch all the available groups that a user can belong to and return the
	 * list back as a GroupIdentifier object that will contain the group id with the name
	 * @return list of GroupIdentifier
	 */
	@Override
	public List<GroupIdentifier> getAllAvailableUserGroups(){
		List<Groups> groupList = groupsRepository.findAll();
		List<GroupIdentifier> groupsWithIdentifierList = new ArrayList<>();
		if(CollectionUtils.isNotEmpty(groupList)){
			for(Groups group: groupList){
				groupsWithIdentifierList.add(new GroupIdentifier(group));
			}
		}
		return groupsWithIdentifierList;
	}

	/**
	 * Method for adding groups
	 * @param user
	 * @param groupsToAdd
	 */
	private void addGroup(Users user, List<GroupDto> groupsToAdd) {
		for(GroupDto groupDto : groupsToAdd) {
			Groups group = groupsRepository.findByGroupNameAndCategoryName(groupDto.getGroupName(), groupDto.getCategoryName());
			if (group == null) {
				//Invalid request group doesn't exist let RSAM know
				throw new IllegalArgumentException("Profile: " + groupDto.getRSAMProfileName() + " is invalid");
			}
			for (GroupMembers gm : user.getGroupMembers()) {
				if (gm.getGroups().equals(group)) {
					//Invalid request user already has this profile so NO Action taken
					logger.info("User : " + user.getSid() + " already has Profile: " + groupDto.getRSAMProfileName() + " not action taken.");
					throw new CTracApplicationException("User : " + user.getSid() + " already has Profile: " + groupDto.getRSAMProfileName() + " not action taken.", CtracErrorSeverity.TRIVIAL);
				}
			}
			if (group != null) {
				//User needs role added
				user.addGroups(group);
			}
		}
	}

	private void addGroup(Users user, GroupDto groupToAdd) {
		List<GroupDto> groups = new ArrayList<GroupDto> ();
		groups.add(groupToAdd);
		addGroup(user, groups);
	}


	private void removeGroups(Users user, UsersDto request) {
		if(user == null) {
			throw new CTracApplicationException("User : " + request.getSid() + " Does not exist no groups to remove no action taken.", CtracErrorSeverity.TRIVIAL);
		}
		user = CtracBaseEntity.deproxy(user, Users.class);
		for(GroupDto groupDto : request.getGroups()) {
			Groups group = groupsRepository.findByGroupNameAndCategoryName(groupDto.getGroupName(), groupDto.getCategoryName());
			if (group == null) {
				throw new IllegalArgumentException("Profile: " + groupDto.getRSAMProfileName() + " is invalid");
			}
			if(!unAssignUserGroup(user,group,groupDto.getRSAMProfileName())){
				//If nothing was removed this is an invalid request let RSAM know it.
				throw new CTracApplicationException("Request User : " + request.getSid() + " to remove a profile " + groupDto.getRSAMProfileName() + " which they do not have, not action taken. ", CtracErrorSeverity.TRIVIAL);
			}
		}
	}

	private boolean unAssignUserGroup(Users user, Groups groupToUnAssign, String profileName){
		if(user.getGroupMembers() != null && !user.getGroupMembers().isEmpty()) {
			Iterator iter = user.getGroupMembers().iterator();
			while (iter.hasNext()) {
				GroupMembers gm = ((GroupMembers) iter.next());
				if (gm.getGroups().equals(groupToUnAssign)) {
					logger.info("Requested User : " + user.getSid() +
							" removing profile: " + profileName);
					groupMembersRepository.delete(gm);
					iter.remove();
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Disable User
	 * 90 days without user activity is the threshold to disable user.
	 * @param users
	 * @return
	 * @throws Exception
	 */
	private UsersDto disableUser(UsersDto users) throws Exception {
		Users existingUser = usersRepository.findBySidIgnoreCase(users.getSid());
		if(existingUser == null) {
			logger.info("Requested User : " + users.getSid() + " to be disabled does not exist no action taken. ");
			throw new CTracApplicationException("Requested User : " + users.getSid() + " to be disabled does not exist no action taken. ", CtracErrorSeverity.TRIVIAL);
		} else {
			existingUser = CtracBaseEntity.deproxy(existingUser, Users.class);
			disableUser(existingUser);
		}
		return users;
	}

	private void disableUser(Users existingUser) throws Exception {
		if(existingUser == null) {
			logger.info("Failed to disabled user as it does not exist no action taken. ");
			throw new CTracApplicationException("Failed to disabled user as it does not exist no action taken. ", CtracErrorSeverity.TRIVIAL);
		} else {
			removeAllGroupsFromUser(existingUser);
			existingUser.setEnabled(false);
			usersRepository.save(existingUser);
			logger.info("Requested User : " + existingUser.getSid() + " has been disabled. ");
		}
	}

	private void removeAllGroupsFromUser(Users user) {
		Iterator<GroupMembers> gmIterator = user.getGroupMembers().iterator();
		while(gmIterator.hasNext()) {
			GroupMembers gmForDelete = gmIterator.next();
			groupMembersRepository.delete(gmForDelete);
			gmIterator.remove();
		}
	}

	/**
	 * Disable User
	 * 90 days without user activity is the threshold to disable user.
	 * @param users
	 * @return
	 * @throws Exception
	 */
	public UsersDto deleteUser(UsersDto users) throws Exception {
		Users existingUser = usersRepository.findBySidIgnoreCase(users.getSid());
		if(existingUser == null) {
			logger.info("Requested User : " + users.getSid() + " to be removed does not exist no action taken. ");
			throw new CTracApplicationException("Requested User : " + users.getSid() + " to be removed does not exist no action taken. ", CtracErrorSeverity.TRIVIAL);
		} else {
			existingUser = CtracBaseEntity.deproxy(existingUser, Users.class);
			deleteUser(existingUser);
		}
		return users;
	}

	private void deleteUser(Users existingUser) {
		if(existingUser == null) {
			logger.info("Failed to remove user as they do not exist no action taken. ");
			throw new CTracApplicationException("Failed to remove user as they do not exist no action taken. ", CtracErrorSeverity.TRIVIAL);
		} else {
			removeAllGroupsFromUser(existingUser);
			usersRepository.delete(existingUser);
			logger.info("Requested User : " + existingUser.getSid() + " has been deleted. ");
		}
	}

	@Transactional
	public void performUserInactivityActions() throws Exception {
		logger.info("Begin User Inactivity Actions");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		List<Users> usersToBeDisabledDueToInactivity = usersRepository.findUsersToBeDisabled();
		if(!usersToBeDisabledDueToInactivity.isEmpty()) {
			logger.info(usersToBeDisabledDueToInactivity.size() + " Users found with inactivity greater than 90 days.");
			for (Users user : usersToBeDisabledDueToInactivity) {
				logger.info(" Disabling user due to inactivity for at least 90 days: " + user.getSid());
			  disableUser(user);
			}
		}

		List<Users> usersToBeDeletedDueToInactivity = usersRepository.findUsersToBeDeleted();
		if(!usersToBeDeletedDueToInactivity.isEmpty()) {
			logger.info(usersToBeDeletedDueToInactivity.size() + " Users found with inactivity greater than 180 days.");
			for(Users user : usersToBeDeletedDueToInactivity) {
				logger.info("Removing user due to inactivity for at least 180 days: " + user.getSid());
				deleteUser(user);
			}
		}
		logger.info("Finished User Inactivity Actions");
	}

	/**
	 * @throws Exception
	 */

	@Transactional
	public void performSyncOfUsersBetweenJanusAndCtrac(List<Users> janusUserList, List<Users> ctracUserList) throws Exception {
		logger.info("Begin syncJanusUsersWithCTRAC");
		if(janusUserList == null || janusUserList.isEmpty()) {
			logger.info("Attempting to perform sync of entitlements but Janus User List is empty.");
			return;
		}
		if(ctracUserList == null || ctracUserList.isEmpty()) {
			logger.info("Attempting to perform sync of entitlements but CTRAC User List is empty.");
			return;
		}

		logger.info("A total of " + janusUserList.size() + " users found in JANUS.");
		logger.info("A total of " + ctracUserList.size() + " users found in CTRAC.");

		//check for janus users in ctrac list
		for(Users janusUser : janusUserList) {
			if(!ctracUserList.isEmpty() && !ctracUserList.contains(janusUser)) {
				//janus user not found in CTRAC so lets add them
				logger.info("Janus User SID: " + janusUser.getSid() +  " is missing from CTRAC therefore adding them.");
				janusUser.setEnabled(true);
				addGroup(janusUser, new GroupDto(env.getRequiredProperty(PROPERTY_DEFAULT_PROFILE_CATEGORY), env.getRequiredProperty(PROPERTY_DEFAULT_PROFILE_GROUP)));
				usersRepository.save(janusUser);
			}
		}

		//check for ctrac users in janus list
		for(Users ctracUser : ctracUserList) {
			if(!janusUserList.isEmpty() && !janusUserList.contains(ctracUser)) {
				logger.info("CTRAC User SID: " + ctracUser.getSid() +  " is not in JANUS therefore removing them.");
				//load the user record and remove them from CTRAC since these should always be in sync
				Users loadedCTRACUser = usersRepository.findBySidIgnoreCase(ctracUser.getSid());
				deleteUser(loadedCTRACUser);
			}
		}
		logger.info("End syncJanusUsersWithCTRAC");
	}

	/**
	 * Method to communicate with Janus and get the current user entitlements list.
	 *
	 * **NOTE** The list that is returned includes users, and different janus
	 * licenses assigned and those licenses need no be included in the sync
	 * @return
	 */
	public List<Users> getJanusUserList() {
		RestTemplate restTemplate = new RestTemplate();
		StringBuilder URL = new StringBuilder();
		String janusURL = env.getRequiredProperty(PROPERTY_JANUS_URL);
		URL.append(janusURL);
		URL.append("getEntitledPrincipals?");
		URL.append("key={key}");
		URL.append("&ent={ent}");
		String janusKey = EncryptionUtil.decrypt(env.getRequiredProperty(PROPERTY_JANUS_KEY));
		String janusEntitlement = env.getRequiredProperty(PROPERTY_JANUS_ENTITLEMENT_NAME);
		logger.info("Attempting to get Janus User Entitlement List at URL: " + URL.toString());
		Map<String, String> params = new HashMap<String, String>();
		params.put("ent", janusEntitlement);
		params.put("key", janusKey);
		List<Users> janusUserList = new ArrayList<>();
		GetEntitledPrincipalsResponse response = null;
		try {
			response = restTemplate.getForObject(URL.toString(), GetEntitledPrincipalsResponse.class, params);
		} catch (Exception e) {
			logger.error("Failed to get entitlement list from JANUS", e);
			throw new CTracApplicationException("Failed to get entitlement list from JANUS.", CtracErrorSeverity.TRIVIAL);
		}
		if(response != null) {
			List<PrPrincipalInfo> principals = response.getEntitledPrincipals();
			logger.info("For entitlement " + janusEntitlement + " a total of " + principals.size() + " users were returned.");
			for(PrPrincipalInfo janusPrincipal: principals) {
				//build list for comparision purposes, skipping license entries, we only want to sync users
				if(!janusPrincipal.isLicenseKeyEntry()) {
					janusUserList.add(new Users(janusPrincipal.getLoginName(), janusPrincipal.getSid(), janusPrincipal.getFirstName(), janusPrincipal.getLastName()));
				} else {
					logger.info("Skipping adding Janus License : " + janusPrincipal.getName());
				}
			}
		}
		return janusUserList;
	}

	public List<Users> getCTRACUserList() {
		return usersRepository.findAll();
	}

}
