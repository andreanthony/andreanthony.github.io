package com.jpmorgan.cib.wlt.ctrac.service.excel;


public class FieldExpression {

	private String valueExpected;
	private ExpressionOperator operator;

	public FieldExpression(String valueExpected, ExpressionOperator operator) {
		this.valueExpected = valueExpected;
		this.operator = operator;
	}

    public boolean evaluateStringFieldExpression(String actualValue){
        return ExpressionOperator.EQUALS.equals(operator) && valueExpected.equals(actualValue);
    }
	
}
