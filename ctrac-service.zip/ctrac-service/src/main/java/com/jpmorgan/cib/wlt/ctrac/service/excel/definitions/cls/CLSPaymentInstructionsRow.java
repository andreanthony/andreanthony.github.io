package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.cls;

import java.util.HashMap;
import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;

public class CLSPaymentInstructionsRow implements Cloneable {

	public static final String PREMIUM_CODE = "1111111111";
	public static final String REFUND_CODE = "2222222222";
	protected static final Map<LoanSystem, CLSPaymentInstructionsRow> PREMIUM_DEBIT_ROW_TEMPLATE = new HashMap<LoanSystem, CLSPaymentInstructionsRow>();
	protected static final CLSPaymentInstructionsRow PREMIUM_CREDIT_ROW_TEMPLATE;
	protected static final Map<LoanSystem, CLSPaymentInstructionsRow> REFUND_DEBIT_ROW_TEMPLATE = new HashMap<LoanSystem, CLSPaymentInstructionsRow>();
	protected static final Map<LoanSystem, CLSPaymentInstructionsRow> REFUND_CREDIT_ROW_TEMPLATE = new HashMap<LoanSystem, CLSPaymentInstructionsRow>();
	
	static {
		PREMIUM_DEBIT_ROW_TEMPLATE.put(LoanSystem.VLS, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280820", PREMIUM_CODE));
		PREMIUM_DEBIT_ROW_TEMPLATE.put(LoanSystem.ACBS, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280821", PREMIUM_CODE));
		PREMIUM_DEBIT_ROW_TEMPLATE.put(LoanSystem.LIQ, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280822", PREMIUM_CODE));
		PREMIUM_DEBIT_ROW_TEMPLATE.put(LoanSystem.ABLE, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280823", PREMIUM_CODE));
		PREMIUM_DEBIT_ROW_TEMPLATE.put(LoanSystem.STRATEGY, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280824", PREMIUM_CODE));
		
		PREMIUM_CREDIT_ROW_TEMPLATE = new CLSPaymentInstructionsRow("DDA 867199296", "0001", "", PREMIUM_CODE);
		PREMIUM_CREDIT_ROW_TEMPLATE.setDescription("JPM WLS Premium Payment");
		
		REFUND_DEBIT_ROW_TEMPLATE.put(LoanSystem.VLS, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280820", REFUND_CODE));
		REFUND_DEBIT_ROW_TEMPLATE.put(LoanSystem.ACBS, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280821", REFUND_CODE));
		REFUND_DEBIT_ROW_TEMPLATE.put(LoanSystem.LIQ, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280822", REFUND_CODE));
		REFUND_DEBIT_ROW_TEMPLATE.put(LoanSystem.ABLE, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280823", REFUND_CODE));
		REFUND_DEBIT_ROW_TEMPLATE.put(LoanSystem.STRATEGY, new CLSPaymentInstructionsRow("GL 2071020041", "0001", "280824", REFUND_CODE));
			
		REFUND_CREDIT_ROW_TEMPLATE.put(LoanSystem.VLS, new CLSPaymentInstructionsRow("DDA 17908221954", "201", "", REFUND_CODE));
		REFUND_CREDIT_ROW_TEMPLATE.put(LoanSystem.ACBS, new CLSPaymentInstructionsRow("GL 2071020077", "802", "7315", REFUND_CODE));
		REFUND_CREDIT_ROW_TEMPLATE.put(LoanSystem.LIQ, new CLSPaymentInstructionsRow("GL 2855000005", "802", "7315", REFUND_CODE));
		REFUND_CREDIT_ROW_TEMPLATE.put(LoanSystem.ABLE, new CLSPaymentInstructionsRow("DDA 400999773", "802", "", REFUND_CODE));
		REFUND_CREDIT_ROW_TEMPLATE.put(LoanSystem.STRATEGY, new CLSPaymentInstructionsRow("GL 1311036043", "802", "476294", REFUND_CODE));

	}
	
	public CLSPaymentInstructionsRow() {}
	
	public CLSPaymentInstructionsRow(String account, String companyCode, String costCenter, String serialField ) {
		this.account = account;
		this.companyCode = companyCode;
		this.costCenter = costCenter;
		this.serialField = serialField;
	}
	
	private String amount;
	private String account;
	private String companyCode;
	private String costCenter;
	private String description;
	private String serialField;
	
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSerialField() {
		return serialField;
	}
	public void setSerialField(String serialField) {
		this.serialField = serialField;
	}

	@Override
	public CLSPaymentInstructionsRow clone() {
		CLSPaymentInstructionsRow clone = new CLSPaymentInstructionsRow(this.account, this.companyCode, this.costCenter, this.serialField);
		clone.setAmount(this.amount);
		clone.setDescription(this.getDescription());
		return clone;
	}
	
}
