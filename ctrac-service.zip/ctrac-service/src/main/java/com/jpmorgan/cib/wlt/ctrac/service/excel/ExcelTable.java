package com.jpmorgan.cib.wlt.ctrac.service.excel;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;

public class ExcelTable {
	
	private static final Logger logger = Logger.getLogger(ExcelTable.class);
	
	private final ColumnDefinition[] columnDefinitions;
	private Map<FieldType, CellStyle> customStyles = new HashMap<FieldType, CellStyle>();
	private Collection<? extends Object> rows = null;
	private Map<ColumnDefinition, CellStyle> columnDefStyles = new HashMap<ColumnDefinition, CellStyle>();
	
	public ExcelTable(ColumnDefinition[] columnDefinitions) {
		this(columnDefinitions, null);
	}
	
	public ExcelTable(ColumnDefinition[] columnDefinitions, Collection<? extends Object> rows) {
		this.columnDefinitions = columnDefinitions;
		this.rows = rows;
	}

	public ExcelTable headerStyle(CellStyle headerStyle) {
		this.customStyles.put(FieldType.HEADER, headerStyle);
		return this;
	}

	public ExcelTable columnDefStyle(ColumnDefinition columnDefinition, CellStyle columnStyle) {
		this.columnDefStyles.put(columnDefinition, columnStyle);
		return this;
	}
	
	public ExcelTable customStyle(FieldType fieldType, CellStyle cellStyle) {
		this.customStyles.put(fieldType, cellStyle);
		return this;
	}
	
	public void insertInto(Sheet sheet) {
		insertInto(sheet, 0, 0);
	}
	
	public void insertInto(Sheet sheet, int startRow, int startColumn) {
		insertHeader(sheet, startRow, startColumn);
		insertRows(sheet, startRow + 1, startColumn);
	}
	
	public int insertBodyInto(Sheet sheet, int startRow, int startColumn){
		return insertRows(sheet, startRow, startColumn);
	}

	private void insertHeader(Sheet sheet, int startRow, int startColumn) {
		Row row = sheet.createRow(startRow);
		for (int i = 0; i < columnDefinitions.length; i++) {
			insertCell(row, startColumn + i, columnDefinitions[i].getColumnLabel(), FieldType.HEADER, columnDefinitions[i]);
		}
	}

	private int insertRows(Sheet sheet, int startRow, int startColumn) {
		if(rows == null){
			return startRow;
		}
		for (Object o : rows) {
			Row row = sheet.createRow(startRow++);
			insertRow(row, startColumn, o);
		}
		return startRow;
	}
	
	private void insertRow(Row row, int startColumn, Object o) {
		for (int i = 0; i < columnDefinitions.length; i++) {
			ColumnDefinition columnDefinition = columnDefinitions[i];
			Object val = getFieldValue(o, columnDefinition.getFieldName());
			insertCell(row, startColumn + i, val, columnDefinitions[i].getFieldType(), columnDefinitions[i]);
		}
	}
	
	private void insertCell(Row row, int col, Object val, FieldType fieldType, ColumnDefinition columnDefinition) {
		Cell cell = row.createCell(col);
		if (val == null) {
			val = "";
		}
		setCellValue(cell, fieldType, val);
		if (fieldType == FieldType.GRAYABLE && val instanceof String && StringUtils.isNotBlank((String) val)) {
			fieldType = FieldType.STRING;
		}
		CellStyle cellStyle = customStyles.get(fieldType);
		if (cellStyle != null) {
			cell.setCellStyle(cellStyle);
		}

		if(columnDefStyles.containsKey(columnDefinition) && FieldType.STRING.equals(fieldType)){
			if(columnDefinition.getFieldExpression().evaluateStringFieldExpression((String)val)){
				cell.setCellStyle(columnDefStyles.get(columnDefinition));
			}
		}
	}
	
	private void setCellValue(Cell cell, FieldType fieldType, Object val) {
		if (val instanceof String) {
			if (fieldType.getApachePoiCellType() == Cell.CELL_TYPE_NUMERIC) {
				if (fieldType == FieldType.AMOUNT) {
					cell.setCellValue(AmountFormatter.parse((String) val).doubleValue());
				} else {
					cell.setCellValue(Double.valueOf((String) val));
				}
			} else {
				cell.setCellValue((String) val);
			}
		} else if (val instanceof Date) {
			cell.setCellValue((Date) val);
		}
		else if(val instanceof BigDecimal){
			cell.setCellValue(((BigDecimal) val).doubleValue());
		}
		else if(val instanceof Long) {
			cell.setCellValue(((Long) val).doubleValue());
		}
		else{
			logger.error("Cell value type not defined.");
		}
	}
	
	private Object getFieldValue(Object o, String fieldName) {
		try {
			Field targetField = o.getClass().getDeclaredField(fieldName);
			targetField.setAccessible(true);
			return targetField.get(o);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return "";
		}
	}
	
	public ColumnDefinition[] getColumnDefinitions() {
		return columnDefinitions;
	}
	
	public Collection<? extends Object> getRows() {
		return rows;
	}

	public void setRows(Collection<? extends Object> rows) {
		this.rows = rows;
	}
	
}
