package com.jpmorgan.cib.wlt.ctrac.service.aggregate.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProofOfCoverageWorkItemRelationType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.AggregateKey;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.AggregatedWorkItemService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.StateToBeAggregated;


@Service
public class AggregatedWorkItemServiceImpl implements AggregatedWorkItemService {

	private static final Logger logger = Logger.getLogger(AggregatedWorkItemServiceImpl.class);
	
	@Override
	public Map<AggregateKey, List<WorkItem>> aggregateWorkItemsByKey(
			List<? extends WorkItem> itemsToBeAggregated, StateToBeAggregated workflowStep) {
		logger.debug("aggregating perfection items");
		if (itemsToBeAggregated == null) {
			logger.debug("itemsToBeAggregated is null; returning null");
			return null;
		}
		
		Map<AggregateKey, List<WorkItem>> aggregatedWorkItems = new HashMap<AggregateKey, List<WorkItem>>();
		for (WorkItem workItem : itemsToBeAggregated) {
			AggregateKey key = workflowStep.getKeyToAggregateBy(workItem);
			List<WorkItem> refArray = aggregatedWorkItems.get(key);
			if (refArray == null) {
				refArray = new ArrayList<WorkItem>();
				aggregatedWorkItems.put(key, refArray);
			}
			refArray.add(workItem);
		}
		
		logger.debug("aggregation complete; aggregated " + itemsToBeAggregated.size() +
				     " items into " + aggregatedWorkItems.keySet().size() + " groups");
		return aggregatedWorkItems;
	}
	
}
