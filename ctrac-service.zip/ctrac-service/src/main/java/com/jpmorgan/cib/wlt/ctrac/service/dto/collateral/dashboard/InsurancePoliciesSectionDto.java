package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.FloodInsuranceDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;

public class InsurancePoliciesSectionDto extends SectionDto {

	private static final long serialVersionUID = 671925902960729444L;
	private static final Long NEW_POLICY_RID = -1L;
	
	private List<ProofOfCoverageDTO> activePolicies;
    private List<ProofOfCoverageDTO> inactivePolicies;
    private FloodInsuranceDTO newFloodPolicy;
    
    private boolean verifyMode = false;

    public InsurancePoliciesSectionDto(){
		this.sectionStatusDto = new SectionStatusDto();
		sectionStatusDto.setSectionId(CollateralDetailsSection.INSURANCE_POLICIES);
    }
    
    public ProofOfCoverageDTO getFloodPolicy(Long policyRid, Long collateralId) {
        if (NEW_POLICY_RID.equals(policyRid)) {
            InsuranceMngtService insuranceMngtService =
                    ApplicationContextProvider.getContext().getBean(InsuranceMngtService.class);
            newFloodPolicy = insuranceMngtService.createNewInsuranceForCollateral(collateralId);
            return newFloodPolicy;
        }
        ProofOfCoverageDTO floodPolicy = getFloodPolicy(policyRid, activePolicies);
        if (floodPolicy != null) {
            return floodPolicy;
        }
        floodPolicy = getFloodPolicy(policyRid, inactivePolicies);
        if (floodPolicy != null) {
            return floodPolicy;
        }
        throw new CtracAjaxException("Invalid request.");
    }
    
    private ProofOfCoverageDTO getFloodPolicy(Long rid, List<ProofOfCoverageDTO> policies) {
        for (ProofOfCoverageDTO proofOfCoverageDTO : policies) {
            if (proofOfCoverageDTO.getRid() != null && proofOfCoverageDTO.getRid().equals(rid)) {
                for (Long collateralRid : proofOfCoverageDTO.getProvidedCoverageMap().getInsurableAssetCoverageData().keySet()) {
                    proofOfCoverageDTO.getProvidedCoverageMap().addCollateral(collateralRid);
                }
                proofOfCoverageDTO.saveACopy();
                return proofOfCoverageDTO;
            }
        }
        return null;
    }
    
    public List<ProofOfCoverageDTO> getActivePolicies() {
        return activePolicies;
    }
    
    public void setActivePolicies(List<ProofOfCoverageDTO> activePolicies) {
        this.activePolicies = activePolicies;
    }
    
    public List<ProofOfCoverageDTO> getInactivePolicies() {
        return inactivePolicies;
    }
    
    public void setInactivePolicies(List<ProofOfCoverageDTO> inactivePolicies) {
        this.inactivePolicies = inactivePolicies;
    }
    
    public FloodInsuranceDTO getNewFloodPolicy() {
        return newFloodPolicy;
    }

    public void setNewFloodPolicy(FloodInsuranceDTO newFloodPolicy) {
        this.newFloodPolicy = newFloodPolicy;
    }

	public boolean isReviewCollateral() {
		for (ProofOfCoverageDTO activePolicy : activePolicies) {
			if (PolicyStatus.EXPIRING.getDisplayName().equals(activePolicy.getPolicyStatus().getDisplayName())) {
				return true;
			}
		}
		return false;
	}
	
	public boolean isActiveLPPolicyExpering() {
		for (ProofOfCoverageDTO activePolicy : activePolicies) {
			if (activePolicy.getPolicyType().isLenderPlaced() && PolicyStatus.EXPIRING.getDisplayName().equals(activePolicy.getPolicyStatus().getDisplayName())) {
				return true;
			}
		}
		return false;
	}

	public boolean isVerifyMode() {
		return verifyMode;
	}

	public void setVerifyMode(boolean verifyMode) {
		this.verifyMode = verifyMode;
	}

}
