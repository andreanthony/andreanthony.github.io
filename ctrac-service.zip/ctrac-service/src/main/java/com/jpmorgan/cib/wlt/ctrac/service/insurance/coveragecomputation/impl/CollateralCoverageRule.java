package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Loan;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LoanCollateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;

public abstract class CollateralCoverageRule extends C3Rule {

	protected final Date today;
	
	protected CollateralCoverageRule(Collateral collateral, WorkItem triggerWorkItem, Date today) {
		super(collateral, triggerWorkItem);
		this.today = today;
	}
	
	/**
	 * When the system decide that we do not need coverage, we need to cancel all lender 
	 * placed insurance associated to the insurable asset
	 * @param globalResults
	 */
	protected void prepareCancelCollateralLpPolicies(final CoverageActionResult globalResults, Date releaseDate,
			CancellationReason cancellationReason) {
    	List<ProofOfCoverageDTO> activeLpPolicies =
    			insuranceMngtService.findActiveByCollateralAndType(collateral.getRid(), PolicyType.lpPolicyTypes());
    	String thirtyDayRegDate = DateFormatter.toString(getThirtyDayRegulatoryPeriod(cancellationReason));
    	
    	/** 
    	 * Cancel all LP associated with the collateral
    	 */
		for (ProofOfCoverageDTO proofOfCoverage : activeLpPolicies) {
			String releaseDateStr = DateFormatter.toString(releaseDate);
			prepareCancelTheProofOfCoverage(
					globalResults, proofOfCoverage, releaseDate, releaseDateStr, thirtyDayRegDate, cancellationReason);
		}
    	
    	prepareAbortEligibleCollateralWorkflows(globalResults);
    	
    	//we can stop and return without evaluating follow-up actions in the chains
    	globalResults.setMoreActionsNeeded(false);
	}

	@Override
	public Integer getPriority() {
		return 1000;
	}
	
	protected void prepareAbortEligibleCollateralWorkflows(final CoverageActionResult globalResults) {
		/** 
    	 * Cancel all FIAT request task if any
    	 */
		Set<PerfectionTask> fiatTasks = collateralWorkflowService.getRequiredCoverageRequestTasks(collateral.getRid());
		if (fiatTasks != null) {
			for (PerfectionTask perfectionTask : fiatTasks) {
				globalResults.getWorkFlowToCancel().add(perfectionTask.getWorkItem().getRid());
			}
		}
    	
    	/**
    	 * Cancel all eligible agent;
    	 */
		Set<PerfectionTask> agentTask = collateralWorkflowService.getAgentAndTasks(collateral.getRid());
		if (agentTask != null) {
			for (PerfectionTask perfectionTask : agentTask) {
				globalResults.getWorkFlowToCancel().add(perfectionTask.getWorkItem().getRid());
			}
		}

		//cancel pre renewal letter
		Set<PerfectionTask> preRenewalLetterTask = collateralWorkflowService.getPreRenewalLetterTask(collateral.getRid());
		for (PerfectionTask perfectionTask : preRenewalLetterTask) {
			globalResults.getWorkFlowToCancel().add(perfectionTask.getWorkItem().getRid());
		}
	}

	protected Date getThirtyDayRegulatoryPeriod(CancellationReason cancellationReason) {
		Date thirtyDayRegPeriod = null;
		if (collateral != null) {
			if (collateral.getCollateralStatus().equals(CollateralStatus.RELEASED.name())) {
				thirtyDayRegPeriod = collateral.getReleaseDate();
			} else if (cancellationReason != null && cancellationReason.equals(CancellationReason.LOAN_PAID_OFF)) {
				for (LoanCollateral loanCollateral : collateral.getLoanCollaterals()) {
					Loan loan = loanCollateral.getLoan();
					if (thirtyDayRegPeriod == null || thirtyDayRegPeriod.before(loan.getReleasedDate())) {
						thirtyDayRegPeriod = loan.getReleasedDate();
					}
				}
			}
		}

		if (thirtyDayRegPeriod == null) {
			// FIXME: add logger and maybe throw exception?
			thirtyDayRegPeriod = today;
		}
		thirtyDayRegPeriod = CalendarDayUtil.addCalendarDays(30, thirtyDayRegPeriod);
		return thirtyDayRegPeriod;
	}

}
