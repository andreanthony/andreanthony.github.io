package com.jpmorgan.cib.wlt.ctrac.service.dto.base.letterImage;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;

public class ImageFileData extends BaseDto implements Serializable {

	private static final long serialVersionUID = -7880634528683161963L;
	//@NotEmpty(message="{invalid.image.letter.confirmation}")
	private String confirmImageFile;
	protected TMParams tmParams;	
	private String excelFileName;
	private String imageFileName;
	protected long perfectionTaskId;	

	public String getConfirmImageFile() {
		return confirmImageFile;
	}
	public void setConfirmImageFile(String confirmImageFile) {
		this.confirmImageFile = confirmImageFile;
	}
	
	public TMParams getTmParams() {
		return tmParams;
	}
	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}
	public String getExcelFileName() {
		return excelFileName;
	}
	public void setExcelFileName(String excelFileName) {
		this.excelFileName = excelFileName;
	}
	public String getImageFileName() {
		return imageFileName;
	}
	public void setImageFileName(String imageFileName) {
		this.imageFileName = imageFileName;
	}
	public long getPerfectionTaskId() {
		return perfectionTaskId;
	}
	public void setPerfectionTaskId(long perfectionTaskId) {
		this.perfectionTaskId = perfectionTaskId;
	}

}
