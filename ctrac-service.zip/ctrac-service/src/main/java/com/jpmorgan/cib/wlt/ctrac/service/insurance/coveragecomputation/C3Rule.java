package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation;

import java.util.Date;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LpInsuranceVendor;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.util.CoverageLapseDetector;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;


public abstract class C3Rule implements Comparable<C3Rule> {

	protected BusinessDayUtil businessDayUtil;
	protected InsuranceMngtService insuranceMngtService;
	protected CollateralWorkflowService collateralWorkflowService;

	protected final Collateral collateral;
	protected final WorkItem triggerWorkItem;
	protected boolean initialized = false;

	protected C3Rule(Collateral collateral, WorkItem triggerWorkItem) {
		this.collateral = collateral;
		this.triggerWorkItem = triggerWorkItem;
		init();
	}

	protected void init() {
		if (!initialized) {
			businessDayUtil = ApplicationContextProvider.getContext().getBean(BusinessDayUtil.class);
			insuranceMngtService = ApplicationContextProvider.getContext().getBean(InsuranceMngtService.class);
			collateralWorkflowService = ApplicationContextProvider.getContext().getBean(CollateralWorkflowService.class);
			initialized = true;
		}
	}

	protected void prepareAbortLenderPlacedWorkflow(ProofOfCoverageDTO proofOfCoverageDTO, final CoverageActionResult globalResults) {
		List<Long> lpWorkItemRids = insuranceMngtService.getLenderPlaceWorkItem(proofOfCoverageDTO.getRid());
		if (lpWorkItemRids != null && !lpWorkItemRids.isEmpty()) {
			globalResults.getWorkFlowToCancel().addAll(lpWorkItemRids);
		}


	}

	public ProofOfCoverageDTO prepareCancelTheProofOfCoverage(final CoverageActionResult globalResults,
															  ProofOfCoverageDTO proofOfCoverageDTO, Date cancelationTargetDate, String cancelationEffDate,
															  String thirtyDayRegData, CancellationReason cancellationReason) {

		PolicyStatus policyStatus = proofOfCoverageDTO.getPolicyStatus();
		boolean hasLapseInCoverageDates = true;
		if(LpInsuranceVendor.ALTHANS.getDisplayName().equals(proofOfCoverageDTO.getInsuranceAgency())) {
			if(policyStatus.isBeforeLpRequestSent()) {
				// set policy to expire rather than cancel
				String expirationDate = proofOfCoverageDTO.getExpirationDate();
				proofOfCoverageDTO.setExpirationDate(cancelationEffDate);
				hasLapseInCoverageDates = CoverageLapseDetector.hasLapseInCoverageDates(proofOfCoverageDTO);
				if(hasLapseInCoverageDates) {
					// queue lapse policy
					proofOfCoverageDTO.setPolicyType(PolicyType.LP_GAP); // Date Lapse
					proofOfCoverageDTO.setIndRenewal("Y"); // so renewal workflow should not start
					globalResults.addProofOfCoverageToUpdate(proofOfCoverageDTO);
				} else {
					// flat cancelled before issued, delete policy, will not issue the policy
					proofOfCoverageDTO.setLpTargetDate(null);
					proofOfCoverageDTO.setPendingLpAction(LPActions.NO_ACTION);
					prepareAbortLenderPlacedWorkflow(proofOfCoverageDTO, globalResults);
					if (policyStatus == PolicyStatus.PENDING_LETTER_CYCLE) {
						// flat cancel - delete the policy
						globalResults.getPolicyToDelete().add(proofOfCoverageDTO.getRid());
					} else if (PolicyStatus.LETTER_CYCLE == policyStatus || PolicyStatus.PRE_INVOICED == policyStatus) {// flat cancel, after letter was sent
						proofOfCoverageDTO.setCancelledInLetterCycle(true);
						proofOfCoverageDTO.setExpirationDate(expirationDate);
						populatePolicyToCancel(proofOfCoverageDTO, cancelationTargetDate, cancelationEffDate, thirtyDayRegData, cancellationReason);
						globalResults.addProofOfCoverageToCancel(proofOfCoverageDTO);

					}
				}
			} else {
				// after policy request sent
				populatePolicyToCancel(proofOfCoverageDTO, cancelationTargetDate, cancelationEffDate, thirtyDayRegData, cancellationReason);
				hasLapseInCoverageDates = CoverageLapseDetector.hasLapseInCoverageDates(proofOfCoverageDTO);
				if(!hasLapseInCoverageDates && proofOfCoverageDTO.getLenderPlaceItemData() != null &&
						proofOfCoverageDTO.getLenderPlaceItemData().getPremiumAmount() == null) {
					// do not invoice the borrower
					prepareAbortLenderPlacedWorkflow(proofOfCoverageDTO, globalResults);
				}
				globalResults.addProofOfCoverageToCancel(proofOfCoverageDTO);
			}
		} else {
			//ASSURANT
			populatePolicyToCancel(proofOfCoverageDTO, cancelationTargetDate, cancelationEffDate, thirtyDayRegData, cancellationReason);
			globalResults.addProofOfCoverageToCancel(proofOfCoverageDTO);
		}
		return proofOfCoverageDTO;
	}

	private void populatePolicyToCancel(ProofOfCoverageDTO proofOfCoverageDTO, Date cancelationTargetDate, String cancelationEffDate,
										String thirtyDayRegData, CancellationReason cancellationReason) {
		proofOfCoverageDTO.setCancellationEffectiveDate(cancelationEffDate);
		proofOfCoverageDTO.setCancellationReason(cancellationReason);
		proofOfCoverageDTO.setThirtyDayRegulatoryPeriod(thirtyDayRegData);
		proofOfCoverageDTO.setCancellationTargetDate(cancelationTargetDate);
		if(cancelationTargetDate.before(businessDayUtil.getCurrentBusinessDate())) {
			proofOfCoverageDTO.setCancellationTargetDate(businessDayUtil.getCurrentBusinessDate());
		}
		proofOfCoverageDTO.setPendingLpAction(LPActions.CANCEL_LP);
		proofOfCoverageDTO.setPolicyStatus(PolicyStatus.CANCELLED);
		return;
	}

	public abstract void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult partialResult);

	public Integer getPriority() {
		return 0;
	}

	@Override
	public int compareTo(C3Rule other) {
		return this.getPriority().compareTo(other.getPriority());
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getSimpleName() + " [getPriority()=");
		builder.append(getPriority());
		builder.append("]");
		return builder.toString();
	}

}