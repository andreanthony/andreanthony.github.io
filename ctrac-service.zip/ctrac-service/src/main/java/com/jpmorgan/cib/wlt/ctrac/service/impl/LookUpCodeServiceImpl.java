package com.jpmorgan.cib.wlt.ctrac.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.service.LookUpCodeService;

@Service
@Transactional(readOnly=true)
public class LookUpCodeServiceImpl implements LookUpCodeService {
    
    @Autowired
    private LookupCodeRepository lookupCodeRepository;

    @Override
    public List<LookUpCode> findByCodeSetInSortOrder(String codeSet) {
        if (codeSet != null) {
            return lookupCodeRepository.findByCodeSetOrderBySortOrderAsc(codeSet);
        }
        return null;
    }

	@Override
	public LookUpCode findByCodeSetAndCode(String codeSet, String code) {
		return lookupCodeRepository.findByCodeAndCodeSet(code, codeSet);
	}

}
