package com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate;

import java.io.Serializable;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AccountWireReferenceDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.validator.FloodRemapValidator;

import javax.validation.Valid;


public class WireRequestData implements Serializable {
	private static final long serialVersionUID = 5653169618149388820L;
	

	protected TMParams tmParams;
	protected long perfectionTaskId;
	private String nextWorkFlowStep;
	private String workFlowStep;
	private String screenId;

	@Valid
	private List<AccountWireReferenceDto> accountWireReferences;
	private String eventType;
	private String pageTitle;
	
	public List<AccountWireReferenceDto> getAccountWireReferences() {
		return accountWireReferences;
	}

	public void setAccountWireReferences(
			List<AccountWireReferenceDto> accountWireReferences) {
		this.accountWireReferences = accountWireReferences;
	}

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	public String getNextWorkFlowStep() {
		return nextWorkFlowStep;
	}

	public void setNextWorkFlowStep(String nextWorkFlowStep) {
		this.nextWorkFlowStep = nextWorkFlowStep;
	}

	public String getScreenId() {
		return screenId;
	}

	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}
	public long getPerfectionTaskId() {
		return perfectionTaskId;
	}

	public void setPerfectionTaskId(long perfectionTaskId) {
		this.perfectionTaskId = perfectionTaskId;
	}
	public int getColumnSize(String columnName) {
		return FloodRemapValidator.getColumnSize(columnName);
	}	
	
	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public String getWorkFlowStep() {
		return workFlowStep;
	}

	public void setWorkFlowStep(String workFlowStep) {
		this.workFlowStep = workFlowStep;
	}
}
