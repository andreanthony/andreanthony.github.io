package com.jpmorgan.cib.wlt.ctrac.service.excel;


public enum ExpressionOperator {

	EQUALS("EQUALS");

	private String operator;

	private ExpressionOperator(String operator) {
		this.operator = operator;
	}

    public String getOperator() {
        return operator;
    }
}
