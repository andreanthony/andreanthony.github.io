package com.jpmorgan.cib.wlt.ctrac.service.batch;

import java.util.Collection;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

public interface MultiplePrimaryPoliciesService {
	
	public void processMultiplePrimaryPolicies(Collection<ProofOfCoverage> policies);

}
