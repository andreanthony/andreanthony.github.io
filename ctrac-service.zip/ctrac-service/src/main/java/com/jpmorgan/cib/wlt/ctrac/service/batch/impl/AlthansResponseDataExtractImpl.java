package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;


import static com.jpmorgan.cib.wlt.ctrac.commons.enums.AlthansLPFileFieldPositions.BLND_COVERAGE_AMT;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.AlthansLPFileFieldPositions.CNT_COVERAGE_AMT;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.AlthansLPFileFieldPositions.BI_COVERAGE_AMT;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.AlthansLPFileFieldPositions.POLICY_RID;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.AlthansLPFileFieldPositions.PRIMIUM_AMOUNT;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.AlthansLPFileFieldPositions.REFUND_AMOUNT;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.AlthansLPFileFieldPositions.REQUEST_TYPE;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.PROCESS_VENDOR_FILE;

import java.io.File;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.AlthansDataException;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.AlthansRequestType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FileProcessingUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.LenderPlaceItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.backdate.impl.SixtyDayBackdateRule;
import com.jpmorgan.cib.wlt.ctrac.service.batch.AlthansBatchItemService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.CLSEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapBatchService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapDataExtract;
import com.jpmorgan.cib.wlt.ctrac.service.batch.ReconEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.AlthansExcelDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.helper.XLSXUtil;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;


@Service(value = "althansResponseDataExtract")
public class AlthansResponseDataExtractImpl extends AbstractFloodRemapDataExtractImpl implements FloodRemapDataExtract {

	public static final int DAYS_UNTIL_DISBURSEMENT = 2;
	private static final int START_ROW_IDX = 4;
	private static final Logger logger = Logger.getLogger(AlthansResponseDataExtractImpl.class);	

	private static final String ALTHANS_INBOUND_LANDING_XLSX_DIR = "althans.landing.inbound.xlsx.directory";
	private static final String ALTHANS_INBOUND_ARCHIVE_XLSX_DIR ="althans.archive.inbound.xlsx.directory";	
	private static final String EMAIL_SUBJECT = "althans.response.invalid.subject";
	private static final String DUP_POL_RIDS = "Duplicated policy rids found.";
	private static final String NO_MATCH_POL ="No matching policy found.";
	private static final String INCORRECT_PREMIUM = "Incorrect premium amount: ";
	private static final String INCORRECT_REFUND = "Incorrect refund amount: ";
	private static final String INCORRECT_ROW_COUNT = "Incorrect row count.";
	private static final String INCORRECT_COL_COUNT = "Incorrect column count.";
	private static final String NO_FILE_FOUND = "No corresponding file has been found for task id: ";

	@Autowired private AlthansBatchItemService althansBatchItemService;
	@Autowired private DateCalculator dateCalculator;
	@Autowired private LenderPlaceItemRepository lenderPlaceItemRepository;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;
	@Autowired private SixtyDayBackdateRule sixtyDayBackdateRule;
	@Autowired private CLSEmailService clsEmailService;
	@Autowired private ReconEmailService reconEmailService;
	@Autowired private TaskService taskService;
	@Autowired private FloodRemapBatchService floodRemapBatchService;
	
	@Override
	protected File[] getAllFiles() {
		File[] files = getAllFiles(ALTHANS_INBOUND_LANDING_XLSX_DIR);
		return  files != null? files: new File[0]; 
	}

	@Override
	protected boolean isValidFileName(File file) {
		return true;
	}

	@Override
	protected boolean areValidContents() {
		return true;
	}
	
	@Override
	protected void archiveFile(File file) {
		if(file == null) return;
		FileProcessingUtil.archiveSingleFile(file, env.getRequiredProperty(ALTHANS_INBOUND_ARCHIVE_XLSX_DIR));
	}

	@Override
	protected void updateLastFileReceivedDate() {
		//updateLastFileReceivedDate(CtracAppConstants.LIQ_LAST_RENEWAL_FILE_RECEIVED_DATE);
	}
	
	@Override
	protected void processContents(File file) {
		processResponseFile(file);

		// Run Create Wire/Refund Request job
		floodRemapBatchService.processWiredPolicy();
	}
	
	@Override
	protected boolean isValidZipFile(File file) {
		return true;
	}
	
	@Override
	protected void extractContents(File file) {
		//Implementation not required
	}
	
	@Override
	protected void archiveContents() {
		//Implementation not required
	}

	@Override
	protected void processContents() {
		//Implementation not required
	}	
	
	
	@Override
	protected void processBatchTask(PerfectionTask task){
		clsEmailService.createAndSendEmail(task.getRid());
		reconEmailService.createAndSendEmail(task.getRid());
		super.processBatchTask(task);
	}
	
	/**
	 * This method parses excel data and save it to the database.
	 * For now it only deals with the happy path, 
	 * no exception handling or no value checking.
	 */
	@Transactional
	protected void processResponseFile(File inboundDataFile) {
		logger.debug("BEGIN::processResponseFile()");
		Iterator<Row> rowIterator = XLSXUtil.getExcelRowIterator(inboundDataFile); 
		int recordsRead = 0;
		int validRecordsRead = 0;
		while (rowIterator.hasNext()) {
			recordsRead++;
			Row row = rowIterator.next();	
			ProofOfCoverage proof = getProofOfCoverageForRow(row);
			LenderPlaceItem lenderPlaceItem = null;
			if (proof != null) {
				lenderPlaceItem = proof.findLenderPlaceItem();
			}
			String premiumAmount = null;
			String refundAmount = null;
			WorkflowStateDefinition workflowToAdvance = null;
			if (lenderPlaceItem != null) {
				validRecordsRead++;
				premiumAmount = row.getCell(PRIMIUM_AMOUNT.getColumn(), MissingCellPolicy.CREATE_NULL_AS_BLANK).toString();
				refundAmount = row.getCell(REFUND_AMOUNT.getColumn(), MissingCellPolicy.CREATE_NULL_AS_BLANK).toString();
				logger.debug("Updating policy " + lenderPlaceItem.getRid() + " PremiumAmount:" + premiumAmount + " RefundAmount:" + refundAmount);
				Date disbursementDate = dateCalculator.addBusinessDays(DAYS_UNTIL_DISBURSEMENT, calendarDayUtil.getCurrentReferenceDate());
				if (!isAmountEmptyOrZero(refundAmount)) {
					BigDecimal totalRefundAmount =  AmountFormatter.parse(refundAmount);
					BigDecimal bankRefundAmount = sixtyDayBackdateRule.calculateBankRefundAmount(lenderPlaceItem.getPremiumAmount(), totalRefundAmount);
					lenderPlaceItem.setRefundAmount(totalRefundAmount.subtract(bankRefundAmount));
					lenderPlaceItem.setBankRefundAmount(bankRefundAmount);					
					lenderPlaceItem.setRefundCompletionDate(disbursementDate);
					workflowToAdvance = WorkflowStateDefinition.AWAITING_VENDOR_FILE_CANCELLATION;
				} else if (!isAmountEmptyOrZero(premiumAmount)) {
					BigDecimal totalPremiumAmount =  AmountFormatter.parse(premiumAmount);					
					BigDecimal bankPremiumAmount = sixtyDayBackdateRule.calculateBankPremiumAmount(
							proof.getEffectiveDate(), proof.getExpirationDate(), totalPremiumAmount, disbursementDate);
					lenderPlaceItem.setPremiumAmount(totalPremiumAmount.subtract(bankPremiumAmount));
					lenderPlaceItem.setBankPremiumAmount(bankPremiumAmount);
					lenderPlaceItem.setBillingDate(disbursementDate);
					lenderPlaceItem.setWireSentDate(disbursementDate);
					workflowToAdvance = WorkflowStateDefinition.AWAITING_VENDOR_FILE_NEW;
				}
			 	lenderPlaceItem = lenderPlaceItemRepository.save(lenderPlaceItem);
			}
		 	
		 	if (workflowToAdvance != null) {
		 		List<PerfectionTask> tasksToAdvance = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(
		 				lenderPlaceItem, workflowToAdvance.getName(), TaskStatus.TRANSIENT.name());
		 		for (PerfectionTask task : tasksToAdvance) {
		 			Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
		 			inputParameterMap.put(StateParameterType.PERFECTION_TASK, task);
		 			taskService.completeEODBatchOperations(inputParameterMap);
		 		}
		 	}
		}
		logger.debug("END::processResponseFile() Valid records " + validRecordsRead + " of " + recordsRead + " records read." );	
	}

	private boolean isAmountEmptyOrZero(String value) {		
    	if (StringUtils.isEmpty(value) || value.equals("0.00") || value.equals("0.0") || value.equals("0")) {
    		return true;
    	} else {
    		return false;
    	}
    }
	

	public ProofOfCoverage getProofOfCoverageForRow(Row row){
		ProofOfCoverage proof = null;
		try {
		    // 1. Is excelRid on the excel file?
		    String excelRid = String.valueOf(row.getCell(POLICY_RID.getColumn(), MissingCellPolicy.RETURN_BLANK_AS_NULL));
		    if (excelRid == null) {
		        return null;
		    }
		    
		    // 2. Is excelRid numeric?
		    Long proofRid = Long.valueOf(excelRid);
		    if (proofRid == null || proofRid.compareTo(0L) <= 0) {
		        return null;
		    }
		    
		    // 3. Is lpItemRid a valid LenderPlaceItem RID?
		    proof = proofOfCoverageRepository.findOne(proofRid);
		} catch (Exception e) {				
			return null;
		}
		return proof;
	}
		
	
	@Override 
	protected List<PerfectionTask> getTasks(){
		List<PerfectionTask> tasks = perfectionTaskRepository.findTransientTasksWakeUpDateBeforeToday(PROCESS_VENDOR_FILE.getName());
		return tasks;
	}
	
	/**
	 * 	-- no rows were added or removed
	 * -- no columns were added removed even if hidden
	 *
	 *Below is validatoin per row
	
	 * 
	 */
	@Override
	public boolean isValidFile(File file, Long taskRid){
		if(file == null){
			sendNotificationEmailAttachmentMessage(NO_FILE_FOUND + taskRid, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT, file);
			return false;
		}
		try {
			int rowCount = 0;
			Iterator<Row> rowIterator = XLSXUtil.getExcelRowIterator(file);
			Set<Long> policyRids = new HashSet<Long>();
			Set<Long> sourcePolicyRids = althansBatchItemService.getRelatedPolicyRids(taskRid);
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				if(row.getRowNum() >= START_ROW_IDX){
					if(isEmpty(row)) break;
					isValid(row, policyRids, sourcePolicyRids);
					rowCount++;
				}
			}
			isRowCountValid(rowCount, sourcePolicyRids.size());
		} catch (Exception e) {
			logger.error(e.getMessage());
			sendNotificationEmailAttachment(e.getMessage(), arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT, file);
			return false;
		}
		return true;
	}

	private boolean isValid(Row row, Set<Long> policyRids, Set<Long> sourcePolicyRids) {
		if(row.getRowNum() == START_ROW_IDX){
			return hasValidColumnCountHeader(row);
		}
		else{
			return hasValidColumnCount(row) && hasValidContent(row, policyRids, sourcePolicyRids);
		}
	}

	private boolean hasValidColumnCountHeader(Row row) {
		if(row.getPhysicalNumberOfCells() != AlthansExcelDefinition.ALTHANS_EXCEL_DEFINITION.length){
			throw new AlthansDataException(INCORRECT_COL_COUNT);
		}
		return true;
	}

	private boolean hasValidColumnCount(Row row) {
		if(row.getPhysicalNumberOfCells() > AlthansExcelDefinition.ALTHANS_EXCEL_DEFINITION.length){
			throw new AlthansDataException(INCORRECT_COL_COUNT);
		}
		return true;
	}

	/**
	 * 	-- amounts have no more than 2 decimals no negative amounts or zeros 
		-- policy rid match with the original request and are valid in CTRAC
		-- every new issue has a positive premium amount less than 50% of the coverage amount and no refund amount
		-- every cancellation as a positive refund amount less than or equal to the original total premium amount and no premium amount
	 * 
	 * @param row
	 * @param policyRids
	 * @param sourcePolicyRids 
	 * @return
	 * @throws Exception 
	 */
	private boolean hasValidContent(Row row, Set<Long> policyRids, Set<Long> sourcePolicyRids) {
		Long policyRid = Long.parseLong(row.getCell(POLICY_RID.getColumn(), MissingCellPolicy.RETURN_BLANK_AS_NULL).toString());
		StringBuilder sb = new StringBuilder("Row number ").append(row.getRowNum()).append(' ');
		if (!policyRids.add(policyRid)) {
			sb.append(DUP_POL_RIDS);
			throw new AlthansDataException(sb.toString());
		}
		if (!sourcePolicyRids.contains(policyRid)) {
			sb.append(NO_MATCH_POL);
			throw new AlthansDataException(sb.toString());
		}
		BigDecimal premiumAmount = AmountFormatter.parse(row.getCell(PRIMIUM_AMOUNT.getColumn(), MissingCellPolicy.CREATE_NULL_AS_BLANK).toString());
		BigDecimal refundAmount = AmountFormatter.parse(row.getCell(REFUND_AMOUNT.getColumn(), MissingCellPolicy.CREATE_NULL_AS_BLANK).toString());
		BigDecimal blndCovAmount = AmountFormatter.parse(row.getCell(BLND_COVERAGE_AMT.getColumn(), MissingCellPolicy.CREATE_NULL_AS_BLANK).toString());
		BigDecimal cntCovAmount = AmountFormatter.parse(row.getCell(CNT_COVERAGE_AMT.getColumn(), MissingCellPolicy.CREATE_NULL_AS_BLANK).toString());
		BigDecimal businessIncomeCovAmount = AmountFormatter.parse(row.getCell(BI_COVERAGE_AMT.getColumn(), MissingCellPolicy.CREATE_NULL_AS_BLANK).toString());
		BigDecimal coverageAmount = businessIncomeCovAmount.compareTo(BigDecimal.ZERO) == 0 ? blndCovAmount.compareTo(BigDecimal.ZERO) == 0 ? cntCovAmount : blndCovAmount : businessIncomeCovAmount;
		AlthansRequestType type = AlthansRequestType.fromString(String.valueOf(row.getCell(REQUEST_TYPE.getColumn(), MissingCellPolicy.RETURN_BLANK_AS_NULL)));
		if (type == AlthansRequestType.NEW_ISSUE) {
			if (premiumAmount.compareTo(coverageAmount.divide(new BigDecimal(2))) > 0) {
				sb.append(INCORRECT_PREMIUM).append(premiumAmount).append(" is more than 50% of the coverage amount.");
				throw new AlthansDataException(sb.toString());
			} else if (premiumAmount.compareTo(BigDecimal.ZERO) <= 0) {
				sb.append(INCORRECT_PREMIUM).append(premiumAmount).append(" is less than or equal to zero.");
				throw new AlthansDataException(sb.toString());
			} else if (refundAmount.compareTo(BigDecimal.ZERO) != 0) {
				sb.append(INCORRECT_REFUND).append(refundAmount).append(" is not zero.");
				throw new AlthansDataException(sb.toString());
			}
		} else if (type == AlthansRequestType.CANCELLATION) {
			if (refundAmount.compareTo(coverageAmount) > 0) {
				sb.append(INCORRECT_REFUND).append(refundAmount).append(" is greater than the coverage amount.");
				throw new AlthansDataException(sb.toString());
			} else if (refundAmount.compareTo(BigDecimal.ZERO) <= 0) {
				sb.append(INCORRECT_REFUND).append(refundAmount).append(" is less than or equal to zero.");
				throw new AlthansDataException(sb.toString());
			} else if (premiumAmount.compareTo(BigDecimal.ZERO) != 0) {
				sb.append(INCORRECT_PREMIUM).append(premiumAmount).append(" is not zero.");
				throw new AlthansDataException(sb.toString());
			}
		}

		return true;
	}

	private boolean isRowCountValid(int rowCount, int sourceRowCount) {
		if(sourceRowCount != rowCount - 1){
			throw new AlthansDataException(INCORRECT_ROW_COUNT);
		}
		return true;
	}
	
	
	
	
	
	public static boolean isEmpty(Row row) {
	    for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
	        Cell cell = row.getCell(c);
	        if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK)
	            return false;
	    }
	    return true;
	}
	
	protected Long getFileId(File file) {
		Long fileId = null;
		try {
			String[] filename = FilenameUtils.removeExtension(file.getName()).split("-");
			if (filename == null || filename.length < 3) {
				throw new AlthansDataException("Not enough parts to filename: " + file.getName());
			}
			if (!filename[0].equalsIgnoreCase("weekly_request")) {
				throw new AlthansDataException("Unexpected file description: " + file.getName());
			}
			fileId = Long.parseLong(filename[2]);
		} catch (Exception e) {
			logger.error("Invalid file name - " + e.getMessage());
		}
		return fileId;
	}
}
