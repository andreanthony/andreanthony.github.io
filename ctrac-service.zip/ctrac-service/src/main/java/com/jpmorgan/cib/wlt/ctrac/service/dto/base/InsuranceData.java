package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

public class InsuranceData implements Comparator<InsuranceData> {
	String insuranceType;
	String status;
	String policyNumber;
	String policyType;
	String coverageType;
	Double coverageAmount;
	String formattedCoverageAmount;
	Date   effectiveDate;
	String formattedEffectiveDate;
	Date   expiryDate;
	String formattedExpiryDate;
	
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	DecimalFormat df =   new DecimalFormat("'$'#,###,###");
	
	 @Override
	 public int compare(InsuranceData insuranceData1, InsuranceData insuranceData2) {
		 return insuranceData1.expiryDate.compareTo(insuranceData2.expiryDate);
	 }
	 
	public String getInsuranceType() {
		return insuranceType;
	}
	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getCoverageType() {
		return coverageType;
	}
	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}
	public Double getCoverageAmount() {
		return coverageAmount;
	}
	public void setCoverageAmount(Double coverageAmount) {
		this.coverageAmount = coverageAmount;
		this.formattedCoverageAmount = df.format(coverageAmount);
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
		this.formattedEffectiveDate = sdf.format(effectiveDate);
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;		
		this.formattedExpiryDate = sdf.format(expiryDate);
	}

	public String getFormattedCoverageAmount() {
		return formattedCoverageAmount;
	}

	public void setFormattedCoverageAmount(String formattedCoverageAmount) {
		this.formattedCoverageAmount = formattedCoverageAmount;
	}

	public String getFormattedEffectiveDate() {
		return formattedEffectiveDate;
	}

	public void setFormattedEffectiveDate(String formattedEffectiveDate) {
		this.formattedEffectiveDate = formattedEffectiveDate;
	}

	public String getFormattedExpiryDate() {
		return formattedExpiryDate;
	}

	public void setFormattedExpiryDate(String formattedExpiryDate) {
		this.formattedExpiryDate = formattedExpiryDate;
	}
	
}
