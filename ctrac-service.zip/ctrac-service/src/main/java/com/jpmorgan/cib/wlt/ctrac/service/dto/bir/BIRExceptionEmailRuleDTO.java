package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import java.io.Serializable;

public class BIRExceptionEmailRuleDTO implements Serializable {

	private static final long serialVersionUID = 4914742786439788758L;

	private String rowLabel;
	
	private String currentPolicyValue;
	
	private String requiredValue;

	public String getRowLabel() {
		return rowLabel;
	}

	public void setRowLabel(String rowLabel) {
		this.rowLabel = rowLabel;
	}

	public String getCurrentPolicyValue() {
		return currentPolicyValue;
	}

	public void setCurrentPolicyValue(String currentPolicyValue) {
		this.currentPolicyValue = currentPolicyValue;
	}

	public String getRequiredValue() {
		return requiredValue;
	}

	public void setRequiredValue(String requiredValue) {
		this.requiredValue = requiredValue;
	}
	
}
