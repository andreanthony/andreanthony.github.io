package com.jpmorgan.cib.wlt.ctrac.service.dto.base;


import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.*;

public class SearchCollateralData extends FloodRemapData implements Serializable  {
	
	private static final long serialVersionUID = -232021800118654853L;
	
	private static final Logger logger = Logger.getLogger(SearchCollateralData.class);
	
	protected String name;
	protected String insuredName;
	protected String borrowerName;
	protected String ownerName;
	protected String propertyAddress;
	protected String propertyCity;
	protected String propertyState;
	protected String propertyZipCode;
	protected String collateralId;
	protected List<LookUpCode> collateralTypes;
	protected String collateralType;
	protected List<LookUpCode> collateralStatuses;
	protected String collateralStatus;
	protected String collateralDescription;
	protected List<LineOfBusinessDTO> linesOfBusiness;
	protected String lineOfBusiness;
	protected LinkedHashMap<String, String> searchCriteria = new LinkedHashMap<String, String>();
	protected String propertyFullAddress;
	protected String loanNumber;
	protected String policyNumber;
	protected String unitBuilding;

	public String getUnitBuilding() {
		return unitBuilding;
	}

	public void setUnitBuilding(String unitBuilding) {
		this.unitBuilding = unitBuilding;
	}
	
	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getCollateralId() {
		return collateralId;
	}

	public void setCollateralId(String collateralId) {
		this.collateralId = collateralId;
	}

	public List<LookUpCode> getCollateralTypes() {
		return collateralTypes;
	}

	public void setCollateralTypes(List<LookUpCode> collateralTypes) {
		this.collateralTypes = collateralTypes;
	}

	public List<LineOfBusinessDTO> getLinesOfBusiness() {
		return linesOfBusiness;
	}

	public void setLinesOfBusiness(List<LineOfBusinessDTO> linesOfBusiness) {
		this.linesOfBusiness = linesOfBusiness;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public String getCollateralStatus() {
		return collateralStatus;
	}

	public void setCollateralStatus(String collateralStatus) {
		this.collateralStatus = collateralStatus;
	}

	public String getCollateralDescription() {
		return collateralDescription;
	}

	public void setCollateralDescription(String collateralDescription) {
		this.collateralDescription = collateralDescription;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPropertyCity() {
		return propertyCity;
	}

	public void setPropertyCity(String propertyCity) {
		this.propertyCity = propertyCity;
	}

	public String getPropertyState() {
		return propertyState;
	}

	public void setPropertyState(String propertyState) {
		this.propertyState = propertyState;
	}

	public String getPropertyZipCode() {
		return propertyZipCode;
	}

	public void setPropertyZipCode(String propertyZipCode) {
		this.propertyZipCode = propertyZipCode;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	/**
	 * Set used on the front end as  "select options " to display to the user.
	 * it either  LookUpCode.description, or LookUpCode.code
	 * @return Set <LookUpCode.code>
	 */
	public Set<String> getStateOptions() {
		return getAllOptionsAsSetFromList(stateCodes, "code");
	}

	//TODO move this into an abstract class as an abstract method with class name passed as parameter... remove getClass()
	//@Override
	public void parseRequestAttributes(HttpServletRequest httpReq) {

		int totalNumberOfSearhField = 0;
		String totalSearchField = httpReq.getParameter("totalSearchField");
		if (!StringUtils.isBlank(totalSearchField)) {
			totalNumberOfSearhField = Integer.parseInt(totalSearchField);
		}
		
		// Search Criteria Level 1
		String fieldNames[] = {"collateralId", "loanNumber", "name", "collateralType", "collateralStatus", "collateralDescription", 
				"propertyAddress", "propertyCity", "propertyState", "propertyZipCode", "lineOfBusiness", "policyNumber", "unitBuilding"};
		
		logger.debug("Search Criteria Level 1");
		for (int index = 0; index < fieldNames.length; index++) {
			try {
				String fieldName = fieldNames[index];
				String fieldValue = httpReq.getParameter(fieldName);
				if (!StringUtils.isBlank(fieldValue)) {
					fieldValue = StringUtils.trim(fieldValue);
					Field aField = getClass().getDeclaredField(fieldName);
					aField.set(this, fieldValue);
				}

				logger.debug("#### fieldName: " + fieldName + " fieldValue: " + fieldValue);	
			}
			catch (Exception e) {
			    logger.error(e.getMessage(), e);
			}
		}

		// Search Criteria Level 2. Some of the Search Criteria Level 1 may be overwritten
		logger.debug("Search Criteria Level 2");
		for (int index = 0; index <= totalNumberOfSearhField; index++) {

			try {
				String fieldName = httpReq.getParameter("columns[" + index + "][data]");
				String fieldValue = httpReq.getParameter("columns[" + index + "][search][value]");
				if (!StringUtils.isBlank(fieldValue)) {
					fieldValue = StringUtils.trim(fieldValue);
					Field aField = getClass().getDeclaredField(fieldName);
					aField.set(this, fieldValue);
				}

				logger.debug("#### fieldName: " + fieldName + " fieldValue: " + fieldValue);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}
	
	/**
	 * Set used on the front end as  "select options " to display to the user.
	 * it either  LookUpCode.description, or LookUpCode.code
	 * @return 
	 */
	public Set <String> getLineOfBusinessOptions(){
        SortedSet<String> response = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        if (linesOfBusiness != null) {
            for (LineOfBusinessDTO entry : linesOfBusiness) {
                response.add(entry.getDescription());
            }
        }
        return response;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getPropertyFullAddress() {
		return propertyFullAddress;
	}

	public void setPropertyFullAddress(String propertyFullAddress) {
		this.propertyFullAddress = propertyFullAddress;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}
	
	public String toString() {
		return("name: " + name + " insuredName: "  + insuredName + " borrowerName:"  + borrowerName + " ownerName: "  + ownerName + 
				" propertyCity: "  + propertyCity + " propertyState: "  + propertyState + " propertyZipCode: "  + propertyZipCode + 
				" collateralId: "  + collateralId + " collateralType: "  + collateralType + " collateralStatus: "  + collateralStatus + 
				" collateralDescription: "  + collateralDescription + " lineOfBusiness: "  + lineOfBusiness + 
				" propertyFullAddress: "  + propertyFullAddress + " loanNumber: " + loanNumber + " policyNumber: " + policyNumber + " unitBuilding: " + unitBuilding);
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public List<LookUpCode> getCollateralStatuses() {
		return collateralStatuses;
	}

	public void setCollateralStatuses(List<LookUpCode> collateralStatuses) {
		this.collateralStatuses = collateralStatuses;
	}

}
