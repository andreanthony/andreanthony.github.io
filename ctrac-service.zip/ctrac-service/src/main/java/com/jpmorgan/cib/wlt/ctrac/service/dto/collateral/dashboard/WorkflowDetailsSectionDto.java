package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.WorkflowDetailsDTO;

public class WorkflowDetailsSectionDto extends SectionDto {

	private static final long serialVersionUID = -7441524920671851388L;
	
	private List<WorkflowDetailsDTO> workflowDetails;
    
    private boolean verifyMode = false;

    public WorkflowDetailsSectionDto(){
		this.sectionStatusDto = new SectionStatusDto();
		sectionStatusDto.setSectionId(CollateralDetailsSection.WORKFLOW_DETAILS);
    }
    
    public WorkflowDetailsDTO getWorkflowDetails(Long rid) {

        WorkflowDetailsDTO workflowDetailsDTO = getWorkflowDetailsDTO(rid, workflowDetails);
        if (workflowDetailsDTO != null) {
            return workflowDetailsDTO;
        }
        workflowDetailsDTO = getWorkflowDetailsDTO(rid, workflowDetails);
        if (workflowDetailsDTO != null) {
            return workflowDetailsDTO;
        }
        throw new CtracAjaxException("Invalid request.");
    }
    
    private WorkflowDetailsDTO getWorkflowDetailsDTO(Long rid, List<WorkflowDetailsDTO> workflowDetailsDTOs) {
        for (WorkflowDetailsDTO workflowDetailsDTO : workflowDetailsDTOs) {
            if (workflowDetailsDTO.getRid() != null && workflowDetailsDTO.getRid().equals(rid)) {
                return workflowDetailsDTO;
            }
        }
        return null;
    }
        	
	public List<WorkflowDetailsDTO> getWorkflowDetails() {
		return workflowDetails;
	}

	public void setWorkflowDetails(List<WorkflowDetailsDTO> workflowDetails) {
		this.workflowDetails = workflowDetails;
	}

	public boolean isVerifyMode() {
		return verifyMode;
	}

	public void setVerifyMode(boolean verifyMode) {
		this.verifyMode = verifyMode;
	}

}
