package com.jpmorgan.cib.wlt.ctrac.service.dto.admin;

import java.io.File;
import java.io.Serializable;
import java.util.Date;

import org.apache.commons.io.FilenameUtils;

public class FileDTO implements Serializable {

	private static final long serialVersionUID = -8832213374680970036L;
	
	private File file;
	
	public FileDTO(File file) {
		this.file = file;
	}
	
	public String getFileName() {
		return file != null ? FilenameUtils.removeExtension(file.getName()) : "";
	}
	
	public String getExtension() {
		return file != null ? FilenameUtils.getExtension(file.getName()).toLowerCase() : "";
	}
	
	public String getLastModified() {
		return file != null ? new Date(file.lastModified()).toString() : "";
	}
	
	public File getFile() {
		return file;
	}

}
