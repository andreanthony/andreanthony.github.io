package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;



public class DateBuilder {

	private Date date;
	private final DateCalculator dateCalculator;
	
	public DateBuilder() {
		dateCalculator = ApplicationContextProvider.getContext().getBean(DateCalculator.class);
		this.date = dateCalculator.getCurrentReferenceDate();
	}
	
	public DateBuilder(Date date) {
		dateCalculator = ApplicationContextProvider.getContext().getBean(DateCalculator.class);
		this.date = date;
	}
	
	public DateBuilder addBusinessDays(int numDays) {
		date = dateCalculator.addBusinessDays(numDays, date);
		return this;
	}
	
	public DateBuilder addCalendarDays(int numDays) {
		date = dateCalculator.addCalendarDays(numDays, date, true);
		return this;
	}
	
	public DateBuilder addCalendarDays(int numDays, Boolean endOnBusinessDay) {
		date = dateCalculator.addCalendarDays(numDays, date, endOnBusinessDay);
		return this;
	}
	
	public DateBuilder subtractBusinessDays(int numDays) {
		date = dateCalculator.subtractBusinessDaysExclusive(numDays, date);
		return this;
	}
	
	public DateBuilder subtractCalendarDays(int numDays) {
		date = dateCalculator.subtractCalendarDays(numDays, date, true);
		return this;
	}
	
	public boolean isWorkingDay(){
		return dateCalculator.isBusinessDay(date);
	}
	
	public Date build() {
		return date;
	}
	
}
