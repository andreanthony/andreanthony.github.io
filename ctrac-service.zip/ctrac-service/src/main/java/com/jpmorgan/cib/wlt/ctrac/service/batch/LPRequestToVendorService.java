package com.jpmorgan.cib.wlt.ctrac.service.batch;

public interface LPRequestToVendorService {

	void sendRequestToInsuranceVendor();
	void sendRequestToInsuranceVendorAlthans();

}