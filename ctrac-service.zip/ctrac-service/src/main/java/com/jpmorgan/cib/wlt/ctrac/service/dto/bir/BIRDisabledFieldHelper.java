package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyReasonForVerification;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import org.apache.commons.lang.StringUtils;

import java.util.Map;

/**
 * Created by E704298 on 7/3/2017.
 */
public class BIRDisabledFieldHelper {

    public static boolean isDisabled(Map<String, BIRRuleConclusionDTO> birRuleConclusions, String key,
                                     PolicyStatus policyStatus, String reasonForVerification) {
        return policyStatus != null && (
        		
        		//Disable if policy is inactive        		
        		!policyStatus.isActive(true)
        		//Disable if policy is pending verification and cancelation date is entered
        		//enable only action required fields and cancellation date
        		|| (isResponseAcceptable(birRuleConclusions, key) && policyStatus.isPendingVerification() && PolicyReasonForVerification.CANCELATION_DATE_ENTERED.name().equals(reasonForVerification))
        		//Disable if policy is pending verification and cancelation date is entered//policy is pending verification
        		//enable only action required fields//policy is not pending verification
        		|| (isResponseAcceptable(birRuleConclusions, key) && policyStatus.isActive(false)));
    }

    private static boolean isResponseAcceptable(Map<String, BIRRuleConclusionDTO> birRuleConclusions, String key) {
        BIRRuleConclusionDTO ruleConclusion = birRuleConclusions.get(key);
        return ruleConclusion == null || ruleConclusion.getLoadTimeValue() == null ||
                !BorrowerInsuranceReviewConclusion.ACTION_REQUIRED.name().equals(
                        ruleConclusion.getLoadTimeValue().getConclusion());
    }

}
