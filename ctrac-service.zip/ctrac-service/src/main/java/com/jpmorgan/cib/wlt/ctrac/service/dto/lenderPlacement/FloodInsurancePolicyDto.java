package com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.validator.FloodRemapValidator;



        /**
         * This class should be used only for populating legacy emailTemplate dto from 5.xx.
         * 6.xx code should be referencing com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.FloodInsuranceDTO
         *When time permit, this should be deleted and replaced with  com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.FloodInsuranceDTO
         *
         */
         

@Deprecated
public class FloodInsurancePolicyDto implements Serializable {
	
	private static final long serialVersionUID = 4092237779810221937L;
	public static Format formatter_date_us = new SimpleDateFormat(CtracAppConstants.DATE_FORMAT_US);

	//private String perfectionTaskId;
	
	protected TMParams tmParams;
	protected Long perfectionRid;
	
	// TODO: Should get from database using tmParams
	private Long buildingRid;
	
	/**
	 * this is in fact the property type from the Fiat 
	 */
	private String coverageType;
	
	private String propertyType;
	
	/**
	 * this will represent the amount of coverage to provide 
	 */
	private String coverageAmount;
	private String effectiveDate;
	private String policyNumber;
	
	private String lpCoverageType;
	
	public String getLpCoverageType() {
		return lpCoverageType;
	}

	public void setLpCoverageType(String lpCoverageType) {
		this.lpCoverageType = lpCoverageType;
	}

	/**
	 * this represent the required coverage amount
	 */
	private String totalCoverageAmount;
	
	private Date dateOfFirstLetter;
	private String strDateOfFirstLetter;
	private String strDateOfFirstLetterPlus1;

	private Date dateOfSecondLetter;
	private String strDateOfSecondLetter;
	
	private Date lpSendDate;
	private String strLpSendDate;
	
	private Date currentBusinessDate;
	private String strCurrentBusinessDate;
	
	private  String billingDate;
	private  String paymentReferenceNumber;
	private  String costCenterNumber;

	private String action;
	private String premiumAmount = CtracAppConstants.DEFAULT_AMOUNT;
	private String vendorPaymentMethod;
	private List<LookUpCode> vendorPaymentMethodList;
	private String buildingName;
	private String nextWorkFlowStep;
	private String screenId;
	private static int dateLength = 10;
	
	private String requestor;
	
	protected String city;

	protected String state;

	protected String zipcode;
	
	private String inputSourceType;
	private String tmTaskType = "NA";
	private String policyType;
	private String assetType;

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}
	
	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	
	public Long getPerfectionRid() {
		return perfectionRid;
	}

	public void setPerfectionRid(Long perfectionRid) {
		this.perfectionRid = perfectionRid;
	}
	
	public Long getBuildingRid() {
		return buildingRid;
	}

	public void setBuildingRid(Long buildingRid) {
		this.buildingRid = buildingRid;
	}
	
	public Date getDateOfFirstLetter() {
		return dateOfFirstLetter;
	}
	@Deprecated
	public void setDateOfFirstLetter(Date dateOfFirstLetter) {
		this.dateOfFirstLetter = dateOfFirstLetter;
		if (dateOfFirstLetter != null) {
			setStrDateOfFirstLetter(formatter_date_us.format(dateOfFirstLetter));
			// Now set date of first letter plus one day
			Calendar cal = Calendar.getInstance();  
		    cal.setTime(dateOfFirstLetter);  
		    // Add one day to it  
		    cal.add(Calendar.DATE,+1);  
			setDateOfFirstLetterPlus1(formatter_date_us.format(cal.getTime()));
		}
	}
	
	public String getStrDateOfFirstLetter() {
		return strDateOfFirstLetter;
	}

	public void setStrDateOfFirstLetter(String strDateOfFirstLetter) {
		this.strDateOfFirstLetter = strDateOfFirstLetter;
	}

	public String getStrDateOfFirstLetterPlus1() {
		return strDateOfFirstLetterPlus1;
	}

	public void setDateOfFirstLetterPlus1(String strDateOfFirstLetterPlus1) {
		this.strDateOfFirstLetterPlus1 = strDateOfFirstLetterPlus1;
	}
	
	public Date getDateOfSecondLetter() {
		return dateOfSecondLetter;
	}

	public void setDateOfSecondLetter(Date dateOfSecondLetter) {
		this.dateOfSecondLetter = dateOfSecondLetter;
		if (dateOfSecondLetter != null) {
			setStrDateOfSecondLetter(formatter_date_us.format(dateOfSecondLetter));
		}
	}
	
	public String getStrDateOfSecondLetter() {
		return strDateOfSecondLetter;
	}

	public void setStrDateOfSecondLetter(String strDateOfSecondLetter) {
		this.strDateOfSecondLetter = strDateOfSecondLetter;
	}

	public Date getCurrentBusinessDate() {
		return currentBusinessDate;
	}

	public void setCurrentBusinessDate(Date currentBusinessDate) {
		this.currentBusinessDate = currentBusinessDate;
	}

	public String getStrCurrentBusinessDate() {
		return formatter_date_us.format(getCurrentBusinessDate());
	}

	public String getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}

	public String getPaymentReferenceNumber() {
		return paymentReferenceNumber;
	}

	public void setPaymentReferenceNumber(String paymentReferenceNumber) {
		this.paymentReferenceNumber = paymentReferenceNumber;
	}

	public String getCostCenterNumber() {
		return costCenterNumber;
	}

	public void setCostCenterNumber(String costCenterNumber) {
		this.costCenterNumber = costCenterNumber;
	}

	public void setStrCurrentBusinessDate(String strCurrentBusinessDate) {
		this.strCurrentBusinessDate = strCurrentBusinessDate;
	}

	public String getVendorPaymentMethod() {
		return vendorPaymentMethod;
	}

	public void setVendorPaymentMethod(String vendorPaymentMethod) {
		this.vendorPaymentMethod = vendorPaymentMethod;
	}
	
	public List<LookUpCode> getVendorPaymentMethodList() {
		return vendorPaymentMethodList;
	}

	public void setVendorPaymentMethodList(List<LookUpCode> vendorPaymentMethodList) {
		this.vendorPaymentMethodList = vendorPaymentMethodList;
	}

	public String getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getEffectiveDate() {
		return StringUtils.substring(effectiveDate, 0, dateLength);
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(String coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}
	
	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getNextWorkFlowStep() {
		return nextWorkFlowStep;
	}

	public void setNextWorkFlowStep(String nextWorkFlowStep) {
		this.nextWorkFlowStep = nextWorkFlowStep;
	}

	public String getScreenId() {
		return screenId;
	}

	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}
	
	public BigDecimal getPremiumAmountNumber() {
		return AmountFormatter.parse(premiumAmount);
	}
	
	public void setPremiumAmountNumber(BigDecimal premiumAmount) {
		this.premiumAmount = AmountFormatter.format(premiumAmount);
	}
	
	public void setNullDateOfSecondLetter(){
        this.dateOfSecondLetter = null;
        this.strDateOfSecondLetter = null;
    }
	public String getTotalCoverageAmount() {
		return totalCoverageAmount;
	}

	public void setTotalCoverageAmount(String totalCoverageAmount) {
		this.totalCoverageAmount = totalCoverageAmount;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	public int getColumnSize(String columnName) {
		return FloodRemapValidator.getColumnSize(columnName);
	}

	/**
	 * @return the inputSourceType
	 */
	public String getInputSourceType() {
		return inputSourceType;
	}

	/**
	 * @param inputSourceType the inputSourceType to set
	 */
	public void setInputSourceType(String inputSourceType) {
		this.inputSourceType = inputSourceType;
	}

	public Date getLpSendDate() {
		return lpSendDate;
	}

	public void setLpSendDate(Date lpSendDate) {
		this.lpSendDate = lpSendDate;
	}

	public String getStrLpSendDate() {
		return strLpSendDate;
	}

	public void setStrLpSendDate(String strLpSendDate) {
		this.strLpSendDate = strLpSendDate;
	}
	
	public String getCityStateZipcode() {
		return city + ", " + state + " " + zipcode;
	}

	/**
	 * @return the tmTaskType
	 */
	public String getTmTaskType() {
		return tmTaskType;
	}

	/**
	 * @param tmTaskType the tmTaskType to set
	 */
	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}


	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
}
