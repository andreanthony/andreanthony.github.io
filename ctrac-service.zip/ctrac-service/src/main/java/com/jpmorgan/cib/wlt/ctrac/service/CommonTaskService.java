package com.jpmorgan.cib.wlt.ctrac.service;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CompleteItemData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;

public interface CommonTaskService {
	
	CompleteItemData prepareCompleteItem(TMParams tmParams);

	void processCompleteItem(CompleteItemData completeItemData);
}
