/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;


import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FileProcessingUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.ServiceLinkFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.external.ServiceLinkFloodRemapRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapDataExtract;
import com.jpmorgan.cib.wlt.ctrac.service.dto.servicelink.FloodRemaps;
import com.jpmorgan.cib.wlt.ctrac.service.dto.servicelink.FloodRemaps.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.service.helper.XMLUtil;
import com.jpmorgan.cib.wlt.ctrac.service.helper.vendor.ServiceLinkReconReport;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import org.apache.commons.beanutils.BeanToPropertyValueTransformer;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * @author Q003321
 *
 */
@Service(value = "serviceLinkDataExtract")
public class ServiceLinkDataExtractImpl extends AbstractFloodRemapDataExtractImpl implements FloodRemapDataExtract {

	private static final Logger logger = Logger.getLogger(ServiceLinkDataExtractImpl.class);	

	private static final String SERVICELINK_LANDING_ZIP_DIR = "servicelink.zipfile.landing.directory";
	private static final String SERVICELINK_LANDING_XML_DIR = "servicelink.remap.landing.directory";
	private static final String SERVICELINK_LANDING_PDF_DIR ="servicelink.sfhdf.landing.directory";
	private static final String SERVICELINK_LANDING_ZIP_CONTENTS_DIR = "servicelink.contents.landing.directory";
	
	private static final String SERVICELINK_ARCHIVE_ZIP_DIR = "servicelink.zipfile.archive.directory";	
	private static final String SERVICELINK_ARCHIVE_XML_DIR ="servicelink.remap.archive.directory";
	private static final String SERVICELINK_ARCHIVE_PDF_DIR ="servicelink.sfhdf.archive.directory";
	private static final String SERVICELINK_ARCHIVE_ZIP_CONTENTS_DIR = "servicelink.contents.archive.directory";	
	
	private static final String SERVICELINK_VALID_FILE_NAME_PREFIX = "LOL_SL_";

    private static final String INVALID_FILE = "serviceLink.email.notification.invalidFile";
	private static final String ZIPFILE_CONTENT_INVALID = "serviceLink.email.notification.zipFileContentInvalid";
	private static final String EMAIL_SUBJECT = "serviceLink.email.notification.subject.invalidFile";
	private static final String SERVICELINK_COUNT_NOT_MATCH = "serviceLink.email.notification.countNotMatch";
	private static final String SERVICELINK_REMAP_FILE_MISMATCH = "serviceLink.email.notification.misMatchRemapFile";
	private static final String INVALID_REMAP_FILE = "serviceLink.email.notification.invalidRemap";
    private static final String INVALID_SERVICELINK_RECORDS_FOUND = "serviceLink.email.notification.invalidRecords";
	
    @Autowired private CtracObjectMapper ctracObjectMapper;
	@Autowired private ServiceLinkFloodRemapRepository serviceLinkFloodRemapRepository;
	@Autowired private ServiceLinkReconReport serviceLinkReconReport;

	public ServiceLinkDataExtractImpl() {
		super();
		this.remapVendor = RemapVendor.SERVICE_LINK;
	}

	@Override
	protected File[] getAllFiles() {
		return  getAllFiles(SERVICELINK_LANDING_ZIP_DIR); 
	}

	@Override
	protected boolean isValidFileName(File file) {
		return isValidFileName(file, SERVICELINK_VALID_FILE_NAME_PREFIX);
	}
	
	@Override
	protected boolean isValidZipFile(File file) {
		return isValidZipFile(file, EMAIL_SUBJECT, INVALID_FILE);
	}

	@Override
	protected void extractContents(File file) {
		extractContents(file, SERVICELINK_LANDING_ZIP_CONTENTS_DIR);
	}
	
	
    /**
     * This method is used to check the /contents dir to see 
     * if the content of the zip file is valid or not
     * 
     * Valid file: at least 1 xml file with 0 or more pdf files
     * Email notification will be sent if content is not valid
     */
	@Override
	protected boolean areValidContents() {
		File contentsDirectory = new File(env.getRequiredProperty(SERVICELINK_LANDING_ZIP_CONTENTS_DIR));
		File[] contents = contentsDirectory.listFiles();
		int numxmlFiles = 0;
		int numExtraFiles = 0;
		for (File file : contents) {
			String extension = FilenameUtils.getExtension(file.getName());
			if ("xml".equalsIgnoreCase(extension)) {
				moveFileToFolder(file, env.getRequiredProperty(SERVICELINK_LANDING_XML_DIR));
				numxmlFiles++;
			} else if ("pdf".equalsIgnoreCase(extension)) {
				moveFileToFolder(file, env.getRequiredProperty(SERVICELINK_LANDING_PDF_DIR));
			} else {
				logger.debug("Invalid ServiceLink file type: " + extension);
				numExtraFiles++;
			}
		}
		if (numxmlFiles == 1 && numExtraFiles == 0) {
			return true;
		} else {
			sendNotificationEmail(ZIPFILE_CONTENT_INVALID, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
			return false;
		}
	}

	void moveFileToFolder(File file, String directory){
		FileProcessingUtil.moveAndOverwrite(file, directory);
	}

	@Override
	protected void processContents() {
		Map<String, CollateralDocument> floodDeterminationsByFileName = savePDFFiles(SERVICELINK_LANDING_PDF_DIR);
		processXmlFile(floodDeterminationsByFileName); 
	}

	@Override
	protected void archiveContents() {
		FileProcessingUtil.archiveEntireDirectory(
				env.getRequiredProperty(SERVICELINK_LANDING_ZIP_CONTENTS_DIR),
				env.getRequiredProperty(SERVICELINK_ARCHIVE_ZIP_CONTENTS_DIR));
		FileProcessingUtil.archiveEntireDirectory(
				env.getRequiredProperty(SERVICELINK_LANDING_XML_DIR),
				env.getRequiredProperty(SERVICELINK_ARCHIVE_XML_DIR));
		FileProcessingUtil.archiveEntireDirectory(
				env.getRequiredProperty(SERVICELINK_LANDING_PDF_DIR),
				env.getRequiredProperty(SERVICELINK_ARCHIVE_PDF_DIR));
	}

	@Override
	protected void archiveFile(File file) {
		FileProcessingUtil.archiveSingleFile(
				file, env.getRequiredProperty(SERVICELINK_ARCHIVE_ZIP_DIR));
	}

	@Override
	protected void updateLastFileReceivedDate() {
		updateLastFileReceivedDate(CtracAppConstants.SL_LAST_REMAP_FILE_RECEIVED_DATE);
	}
	
	/**
	 * This method is used to process xml file it will:
	 * 1. check xml schema validation
	 * 2. check if the count value matches the records number
	 * 3. save the flood remap to sl_flood_remap staging table
	 * @param floodDeterminationsByFileName 
	 * 
	 * @return true
	 *   when process is successful
	 */
	@Transactional 
	void processXmlFile(Map<String, CollateralDocument> floodDeterminationsByFileName){
	  try{
		    logger.debug("Start processing xml file:");
			File[] fList = new File(env.getRequiredProperty(SERVICELINK_LANDING_XML_DIR)).listFiles();
			File file = fList[0];
			if(validateFloodRemapFile(file)){
				logger.debug("Xml schema is valid.");
				FloodRemaps floodRemaps = getFloodRemapsFromXml(file);
				int recordsReturned = floodRemaps.getFloodRemap().size();
				//If the number of records in the total count does not match the number of records actually sent, we reject the file. 
				if(BigInteger.valueOf(recordsReturned).compareTo(floodRemaps.getTotalCount()) != 0){
					logger.debug("Count value in xml file does not match the number of records.");
					sendNotificationEmail(SERVICELINK_COUNT_NOT_MATCH, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
					return;
				}
				logger.info("Service Link file  : Total Number of records :"+ floodRemaps.getTotalCount());
				List<String> floodRemapRequestNumbers = (List<String>) CollectionUtils.collect(floodRemaps.getFloodRemap(),
						new BeanToPropertyValueTransformer("requestNum"));
				//Validate pdf files with flood remap records
				if(remapRecordsHaveCorrespondingFiles(floodRemapRequestNumbers, floodDeterminationsByFileName)){
					saveServiceLinkFloodRemap(floodRemaps, floodDeterminationsByFileName);
				}else{
					logger.debug("Not a valid ServiceLink Flood Remap Record File: Corresponding PDF file not found");
					sendNotificationEmail(SERVICELINK_REMAP_FILE_MISMATCH, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
				}

			}
			else{
				logger.debug("Xml schema is invalid.");
				sendNotificationEmail(INVALID_REMAP_FILE, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
				return;
			}
	  }
	  catch(Exception e){
		  sendNotificationEmail(INVALID_REMAP_FILE, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT);
	  }
	}

	boolean validateFloodRemapFile(File file) {
		return XMLUtil.validateXML(CtracAppConstants.SL_XML_SCHEMA, new StreamSource(file));
	}

	FloodRemaps getFloodRemapsFromXml(File file) throws Exception {
		return XMLUtil.convertXmlFileToRemaps(file);
	}
	
	/**
	 * Save all the floodremaps to staging table
	 * Also will send email notification with spreadsheet attached for invalid records(StatusChange invalid)
	 * 
	 * @param floodRemaps
	 * @param floodDeterminationsByFileName 
	 * @throws Exception
	 */
	@Transactional
	protected void saveServiceLinkFloodRemap(FloodRemaps floodRemaps, Map<String, CollateralDocument> floodDeterminationsByFileName) throws Exception{
		logger.debug("saveServiceLinkFloodRemap:");
		List<ServiceLinkFloodRemap> invalidfloodRemapRecords = new ArrayList<ServiceLinkFloodRemap>();
		for(FloodRemap floodRemap: floodRemaps.getFloodRemap()){
			ServiceLinkFloodRemap serviceLinkFloodRemap = getServiceLinkFloodRemapFrom(floodRemap);
			serviceLinkFloodRemap.setFloodRemapSFHDF(floodDeterminationsByFileName.get(serviceLinkFloodRemap.getRequestNum()));
			serviceLinkFloodRemap = serviceLinkFloodRemapRepository.save(serviceLinkFloodRemap);
			if(!isValidRemapData(serviceLinkFloodRemap.getStatusChange())){
				invalidfloodRemapRecords.add(serviceLinkFloodRemap);
			}
		}
		if(!invalidfloodRemapRecords.isEmpty()){
			logger.debug("There are invalid records found in ServiceLink file.");
			logger.info("Service Link file  : Number of invalid records :"+ invalidfloodRemapRecords.size());
			File errorReportFile = serviceLinkReconReport.getReconReportFile(invalidfloodRemapRecords);
			sendNotificationEmailAttachment(INVALID_SERVICELINK_RECORDS_FOUND, arrPoEmailAddress, arrCtracEmailAddress, EMAIL_SUBJECT,errorReportFile);
		} else {
			logger.debug("There are no invalid records in ServiceLink file.");
		}
	}

	/**
	 * Method to copy date from the xml java object to Model object
	 * @param  floodRemap
	 * @return List of ServiceLinkFloodRemap
	 */
	private ServiceLinkFloodRemap getServiceLinkFloodRemapFrom(FloodRemap floodRemap) throws Exception{
			//ServiceLinkFloodRemap serviceLinkFloodRemap = floodRemapDozerMapper.getServiceLinkRemapFileFromFloodRemap(floodRemap, ServiceLinkFloodRemap.class);
			ServiceLinkFloodRemap serviceLinkFloodRemap = ctracObjectMapper.map(floodRemap, ServiceLinkFloodRemap.class);
   
			serviceLinkFloodRemap.setCbraDate(XMLUtil.convertXMLDatetoJavaDate(floodRemap.getCbraDate()));
			serviceLinkFloodRemap.setDeterminationDate(XMLUtil.convertXMLDatetoJavaDate(floodRemap.getDeterminationDate()));
			serviceLinkFloodRemap.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);
			serviceLinkFloodRemap.setLomaRDate(XMLUtil.convertXMLDatetoJavaDate(floodRemap.getLomaRDate()));
			serviceLinkFloodRemap.setOrderDate(XMLUtil.convertXMLDatetoJavaDate(floodRemap.getOrderDate()));
			serviceLinkFloodRemap.setRevisedMapDate(XMLUtil.convertXMLDatetoJavaDate(floodRemap.getRevisedMapDate()));
			return serviceLinkFloodRemap;
	}

	@Override
	protected void processContents(File file) {
		//Implementation not required
	}

}
