package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.wiredrequests;

/**
 * Created by V704662 on 5/16/2017.
 */
public interface AlthansWiredRequestsConstants {

    public static final String LABEL_WIRE_REQUEST_COST_CENTER = "Cost Center # ";
    public static final String LABEL_WIRE_REQUEST_COMPANY = "Company # ";
    public static final String LABEL_WIRE_REQUEST_GL_ACCOUNTNUMBER = "GL Account # ";
    public static final String LABEL_WIRE_REQUEST_GL_ACCOUNTNAME = "GL Account Name : ";
    public static final String LABEL_WIRE_REQUEST_DDA_ACCOUNTNUMBER = "DDA Account # ";

    public static final String CONST_TRANSFER_REQUEST_COUNT_LABEL_KEY = "transferRequestCount";
    public static final String CONST_TRANSFER_FUNDS_LABEL_KEY = "transferFundsCount";
    public static final String CONST_LOAN_SYSTEM_LABEL_KEY = "loanSystem";
    public static final String CONST_VENDOR_TO_LABEL_KEY = "vendor";
    public static final String CONST_EFFECTIVE_DATE_LABEL_KEY = "effectiveDate";
    public static final String CONST_WORKSHEET_TITLE = "title";

    public static final String CONST_DELIMITER = "_";
    public static final String CONST_LOOK_UP_PLACEHOLDER = "Look up #";

    public static final String CONST_FUND_TO_ACCOUNT_NUMBER_KEY = "FUND_TO_ACCOUNT_NUMBER";
    public static final String CONST_FUND_TO_ACCOUNT_NAME_KEY = "FUND_TO_ACCOUNT_NAME";
    public static final String CONST_FUND_TO_COMPANY_NUMBER_KEY = "FUND_TO_COMPANY_NUMBER";
    public static final String CONST_FUND_TO_COST_CENTER_NUMBER_KEY = "FUND_TO_COST_CENTER_NUMBER";
}
