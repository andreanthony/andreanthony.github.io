package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CoverageGapReportViewData;
import com.jpmorgan.cib.wlt.ctrac.service.batch.ExcelFileUtil;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ExcelTable;
import com.jpmorgan.cib.wlt.ctrac.service.excel.FieldType;
import com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.coverageGapReport.CoverageGapReportDefinition;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

@Component
public class CoverageGapReportUtil extends ExcelFileUtil {
    private static final Logger logger = Logger.getLogger(CoverageGapReportUtil.class);

    public File createCoverageGapReportAttachment(List<CoverageGapReportViewData> coverageGapReportViewData) {
        logger.debug("BEGIN::createCoverageGapReportAttachment()");
        if (coverageGapReportViewData != null) {
            FileOutputStream fos = null;
            XSSFWorkbook workbook = null;
            try {
                File file = new File("RequiredFloodCoverageGapReport_" +  new LocalDate().toString() + ".xlsx");
                fos = new FileOutputStream(file);
                logger.debug("CoverageGapReport file absolute path: " + file.getAbsolutePath());
                workbook = new XSSFWorkbook();
                XSSFSheet sheet = workbook.createSheet("CoverageGapReport");
                sheet.lockFormatColumns(false);
                sheet.lockFormatRows(false);
                sheet.lockSort(false);
                sheet.lockSelectLockedCells(false);
                sheet.lockSelectUnlockedCells(false);

                setDefaultUnlock(sheet, CoverageGapReportDefinition.COLUMN_DEFINITIONS.length);

                CellStyle dateCellStyle = getDateCellStyle(workbook);
                CellStyle amountCellStyle = getAmountCellStyle(workbook);
                CellStyle stringCellStyle = getStringCellStyle(workbook);
                CellStyle autoWrapCellStyle = getAutoWrapCellStyle(workbook);
                CellStyle lockedCellStyle = getLockedCellStyle(workbook);
                XSSFCellStyle headerCellStyle = createTableHeaader(workbook);

                // Insert headers and rows
                ExcelTable excelTable = new ExcelTable(CoverageGapReportDefinition.COLUMN_DEFINITIONS, coverageGapReportViewData)
                        .headerStyle(headerCellStyle)
                        .customStyle(FieldType.DATE, dateCellStyle)
                        .customStyle(FieldType.AMOUNT, amountCellStyle)
                        .customStyle(FieldType.STRING, stringCellStyle)
                        .customStyle(FieldType.LOCK, lockedCellStyle)
                        .customStyle(FieldType.AUTOWRAP, autoWrapCellStyle);
                excelTable.insertInto(sheet, 0, 0);

                adjustColumn(sheet, CoverageGapReportDefinition.COLUMN_DEFINITIONS.length, CoverageGapReportDefinition.COLUMNS_NOT_AUTO_SIZE);
                workbook.write(fos);
                logger.debug("Coverage Gap Report xlsx file created successfully.");
                return file;
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
                logger.error("Error while creating Coverage Gap Report xlsx file.");
                throw new CTracApplicationException("E0349", CtracErrorSeverity.APPLICATION);
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException e) {
                        logger.error(e.getMessage());
                    }
                }
                if (workbook != null) {
                    try {
                        workbook.close();
                    } catch (IOException e) {
                        logger.error(e.getMessage());
                    }
                }
            }

        } else {
            logger.debug("No Coverage Gap Report data found");
        }
        logger.debug("END::createCoverageGapReportAttachment()");
        return null;
    }

}
