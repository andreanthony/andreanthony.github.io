package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

public class AdminAjaxDTO implements Serializable {

    private static final long serialVersionUID = 5523311344013824135L;
    
    public String referenceDate;
    public String isWorkingDay;
    
    public String getReferenceDate() {
        return referenceDate;
    }
    public void setReferenceDate(String referenceDate) {
        this.referenceDate = referenceDate;
    }
    public String getIsWorkingDay() {
        return isWorkingDay;
    }
    public void setIsWorkingDay(String isWorkingDay) {
        this.isWorkingDay = isWorkingDay;
    }
    
}
