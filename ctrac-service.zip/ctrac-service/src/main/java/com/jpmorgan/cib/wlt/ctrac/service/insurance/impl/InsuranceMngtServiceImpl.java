package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ParentPolicyDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.PrimaryLoanBorrowerViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.WiredPolicyRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.FloodInsuranceRenewalService;
import com.jpmorgan.cib.wlt.ctrac.service.backdate.BankPortionRule;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRRuleConclusionService;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewRule;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.*;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AgentData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.builder.InsuranceCoverageMapFactory;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.LenderPlaceItemDTO;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.request.LPIProofOfCoveragePublishEventRequest;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.ProvidedCoverageService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ReadyForLenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.VendorPaymentMethodService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.util.CoverageLapseDetector;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.SleepingTaskState;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TaskUniqueIdGenerator;
import com.jpmorgan.cib.wlt.ctrac.service.workflow.WorkflowRuleEvaluatorFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.DAYS_FOR_BORROWER_POLICY_RENEWAL;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.DAYS_FOR_LENDER_PLACED_POLICY_RENEWAL;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.*;

/**
 * @author N595724
 *
 */
@Service("insuranceMngtService")
public class InsuranceMngtServiceImpl implements InsuranceMngtService {

    public static final String SYSTEM = "SYSTEM";
    @Autowired private ActivePolicyService activePolicyService;

	@Autowired private AddressRepository addressRepository;

	@Autowired private AddressDataService addressDataService;

	@Autowired private AgentRepository agentRepository;

	@Autowired private BankPortionRule bankPortionRule;

	@Autowired private BIRRuleConclusionService birRuleConclusionService;

	@Autowired private BlanketCoverageRepository blanketCoverageRepository;

	@Autowired private BusinessDayUtil businessDayUtil;
	@Autowired private CalendarDayUtil calendarDayUtil;

	@Autowired private CollateralInsuranceRepository collateralInsuranceRepository;

	@Autowired private CollateralRepository collateralRepository;

	@Autowired private CollateralWorkflowService collateralWorkflowService;

	@Autowired private ContactDetailDataService contactDetailDataService;

	@Autowired private ContactDetailsRepository contactDetailsRepository;

	@Autowired private CtracObjectMapper ctracObjectMapper;

	@Autowired private EmailNotificationService  emailNotificationService;

	@Autowired private InsuranceCoverageMapFactory insuranceCoverageMapFactory;

	@Autowired private InsurableAssetRepository insurableAssetRepository;

	@Autowired private LoanManagementService loanManagementService;

	@Autowired private OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher;

	@Autowired private TMService otmService;

	@Autowired private PaymentMethodRepository paymentMethodRepository;

	@Autowired private PerfectionTaskRepository perfectionTaskRepository;

    @Autowired private PerfectionTaskService perfectionTaskService;

	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;

	@Autowired private PrimaryLoanBorrowerViewRepository primaryLoanRepository;

	@Autowired private ProvidedCoverageRepository providedCoverageRepository;

	@Autowired private ProvidedCoverageService providedCoverageService;

	@Autowired private WorkItemRepository workItemRepository;

	@Autowired private ProofOfCovWorkItemRepository proofOfCovWorkItemRepository;

	@Autowired private CollateralWorkItemRepository collateralWorkItemRepository;

	@Autowired private ParentPolicyDetailsRepository parentPolicyDetailsRepository;

	@Autowired private VendorPaymentMethodService vendorPaymentMethodService;

	@Autowired private WiredPolicyRepository wiredPolicyRepository;

	@Autowired private ReadyForLenderPlaceService readyForLenderPlaceService;

	@Autowired private WorkflowRuleEvaluatorFactory workflowRuleEvaluatorFactory;

	@Autowired private FloodInsuranceRenewalService floodInsuranceRenewalService;

	@Autowired private PublishEventService publishEventService;

	@Autowired CollateralManagementService collateralManagementService;

	private static final Logger logger = Logger.getLogger(InsuranceMngtServiceImpl.class);

	private static final int REMAP_TASK_UNIQUE_ID_LENGTH = 6;
	@Autowired 	private AuditInformationService auditInformationService;


	@Override
	public ProofOfCoverageDTO getProofOfCoverageData(Long proofOfCoverageRid, Long collateralRid) {
		if (proofOfCoverageRid == null) {
			logger.debug("Passed null proofOfCoverageRid to getProofOfCoverageData()");
			return null;
		}
		ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(proofOfCoverageRid);
		if (proofOfCoverage == null) {
			throw new RuntimeException("Could not find ProofOfCoverage for RID=" + proofOfCoverageRid);
		}
		return mapProofsOfCoverage(proofOfCoverage, collateralRid);
	}

	@Override
	@Transactional
	public void initiateRenewalWorkflow() {
		// 75 days before LP policy expiration
		List<ProofOfCoverage> listProofOfCoverage = getPoliciesExpiringWithinDays(DAYS_FOR_LENDER_PLACED_POLICY_RENEWAL, PolicyType.lpPolicyTypes());
		// 50 days before borrower policy expiration
		List<ProofOfCoverage> expiringBorrowerPolicies = getPoliciesExpiringWithinDays(DAYS_FOR_BORROWER_POLICY_RENEWAL, PolicyType.borrowerPolicyTypes());
		listProofOfCoverage.addAll(expiringBorrowerPolicies);

		List<WorkflowStateDefinition> avoidIfExistingworkFlowStep = new ArrayList<>();
		avoidIfExistingworkFlowStep.add(REVIEW_COLLATERAL);
		avoidIfExistingworkFlowStep.add(PENDING_VERIFY_COLLATERAL);
		for (ProofOfCoverage proofOfCoverage : listProofOfCoverage) {
			try {
				collateralWorkflowService.initiatePolicyRenewalWorkflow(proofOfCoverage,
						PerfectionItemSubType.FLOOD_RENEWAL, REVIEW_COLLATERAL, avoidIfExistingworkFlowStep);
			} catch (Exception exp) {
				logger.error("Error occured while initiatiating Collateral workflow for ProofOfCoverage.RID="
							+ proofOfCoverage.getRid());
				logger.error(exp.getMessage(), exp);
				logger.error(ErrorCodeToMessageConverter.convertToMessage("E0153", CtracErrorSeverity.CRITICAL));
				logger.error("Critical Error logged : Continuing with next ProofOfCoverage.");
			}
		}
	}

	protected List<ProofOfCoverage> getPoliciesExpiringWithinDays(Integer daysBeforeExpiration, Set<PolicyType> policyTypes) {
		List<ProofOfCoverage> listProofOfCoverage = proofOfCoverageRepository.findAllProofOfCoverageForRenewal(daysBeforeExpiration.doubleValue());
		List<ProofOfCoverage> result = new ArrayList<>();
		for (ProofOfCoverage proofOfCoverage : listProofOfCoverage) {
			if(policyTypes.contains(proofOfCoverage.getPolicyType_())){
				result.add(proofOfCoverage);
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean isPolicyCoversBusinessAssetSBAOnly(ProofOfCoverage policy) {
			boolean retValue = false;

	    	// From Policy, get Collateral and Loan Information
	    	List<ProofOfCovWorkItem> listProofOfCovWorkItem = proofOfCovWorkItemRepository.findByProofOfCoverageRidAndItemType(policy.getRid(), ProofOfCoverageWorkItemRelationType.COLLATERAL_TO_POLICY.getName());

	    	for (ProofOfCovWorkItem proofOfCovWorkItem: listProofOfCovWorkItem) {

	    		List<CollateralWorkItem> listCollateralWorkItem = collateralWorkItemRepository.findByWorkItem(proofOfCovWorkItem.getWorkItem());
	    		for (CollateralWorkItem collateralWorkItem: listCollateralWorkItem)  {
	    			Collateral collateral = collateralWorkItem.getCollateral();

	    			String collateralType = collateral.getCollateralType();

	    			if (collateralType.equals(CollateralType.BUSINESS_ASSETS.getCode())) {
	    				Collection<LoanData> listLoanData= loanManagementService.getLoanByCollateral(collateral.getRid());
	    				for (LoanData loanData: listLoanData) {
	    					if (loanData.getStatus().isActive() &&
	    							LPIType.SBA_CONTENTS_ONLY.getShortDescription().equals(loanData.getLoanType())) {
	    						retValue = true;
	    						break;
	    					}
	    				}
	    			}
	    		}
	    	}

	    	return retValue;
	}

	/**
	 * returns true if there is an outstand FIAT or SBA Coverage Request
	 */
	@Override
	@Transactional(readOnly = true)
	public boolean hasOutstandingCoverageRequest(Long proofOfCoverageRid) {
		List<CollateralInsuranceViewData> collateralInsuranceRelations =
				collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverageRid);
		for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceRelations) {
			Long collateralRid = collateralInsurance.getCollateral().getRid();
			if (collateralWorkflowService.isFiatRequested(collateralRid) ||
					collateralWorkflowService.isSBACoverageRequested(collateralRid)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<ProofOfCoverageDTO> saveProofOfCoverage(List<ProofOfCoverageDTO> proofOfCoverageDTOList) {
		List<ProofOfCoverageDTO> upProofOfCoverageDTO = new ArrayList<>();
		for (ProofOfCoverageDTO proofOfCoverageDTO : proofOfCoverageDTOList) {
			upProofOfCoverageDTO.add(saveProofOfCoverage(proofOfCoverageDTO));
		}
		return upProofOfCoverageDTO;
	}

	@Override
	@Transactional
	public ProofOfCoverageDTO saveProofOfCoverage(ProofOfCoverageDTO proofOfCoverageDTO) {
		if (proofOfCoverageDTO.getAgentData() != null) {
			saveAgent(proofOfCoverageDTO.getAgentData());
		}

		if (proofOfCoverageDTO.getInvoicePaymentMethod() != null && StringUtils.isNotBlank(proofOfCoverageDTO.getInvoicePaymentMethod().getPaymentMethod())) {
			savePaymentMethod(proofOfCoverageDTO.getInvoicePaymentMethod());
		}

		if (proofOfCoverageDTO.getRefundPaymentMethod() != null && StringUtils.isNotBlank(proofOfCoverageDTO.getRefundPaymentMethod().getPaymentMethod())) {
			savePaymentMethod(proofOfCoverageDTO.getRefundPaymentMethod());
		}

		if (proofOfCoverageDTO.getPreRenewalPaymentMethod() != null && StringUtils.isNotBlank(proofOfCoverageDTO.getPreRenewalPaymentMethod().getPaymentMethod())) {
			savePaymentMethod(proofOfCoverageDTO.getPreRenewalPaymentMethod());
		}

		BlanketCoverageDTO blanketCoverageData = proofOfCoverageDTO.getBlanketCoverageData();

		// if blanketCoverageData is saved, but the type is now blank, i.e. inputter changes from private blanket policy to NFIP
		if (getBlanketCoverageType(proofOfCoverageDTO) == null) {
			// unlink the blanketCoverageData from the proofOfCoverage
			blanketCoverageData = null;
			proofOfCoverageDTO.setBlanketCoverageData(blanketCoverageData);
		}

		if(blanketCoverageData != null) {
			saveBlanketCoverage(blanketCoverageData);
		}

		ProofOfCoverage proofOfCoverageToUpdate = null;
		if (proofOfCoverageDTO.getRid() != null) {
			proofOfCoverageToUpdate = proofOfCoverageRepository.findOne(proofOfCoverageDTO.getRid());
		}
		else {
			if (proofOfCoverageDTO instanceof FloodInsuranceDTO) {
				proofOfCoverageToUpdate = new FloodInsurance();
			}
		}

		proofOfCoverageToUpdate.setPolicyStatus(proofOfCoverageDTO.getPolicyStatus().name());

		if (proofOfCoverageDTO.getAgentData() != null) {
			Agent agent = agentRepository.findOne(proofOfCoverageDTO.getAgentData().getRid());
			proofOfCoverageToUpdate.setAgent(agent);
		}

		if (proofOfCoverageDTO.getInvoicePaymentMethod() != null && StringUtils.isNotBlank(proofOfCoverageDTO.getInvoicePaymentMethod().getPaymentMethod())) {
			PaymentMethod invoicePaymentMethod = paymentMethodRepository.findOne(
					proofOfCoverageDTO.getInvoicePaymentMethod().getRid());
			proofOfCoverageToUpdate.setInvoicePaymentMethod(invoicePaymentMethod);
		}

		if (proofOfCoverageDTO.getRefundPaymentMethod() != null && StringUtils.isNotBlank(proofOfCoverageDTO.getRefundPaymentMethod().getPaymentMethod())) {
			PaymentMethod refundPaymentMethod = paymentMethodRepository.findOne(
					proofOfCoverageDTO.getRefundPaymentMethod().getRid());
			proofOfCoverageToUpdate.setRefundPaymentMethod(refundPaymentMethod);
		}

		if (proofOfCoverageDTO.getPreRenewalPaymentMethod() != null && StringUtils.isNotBlank(proofOfCoverageDTO.getPreRenewalPaymentMethod().getPaymentMethod())) {
			PaymentMethod preRenewalPaymentMethod = paymentMethodRepository.findOne(
					proofOfCoverageDTO.getPreRenewalPaymentMethod().getRid());
			proofOfCoverageToUpdate.setPreRenewalPaymentMethod(preRenewalPaymentMethod);
		}

		if (proofOfCoverageDTO.getBlanketCoverageData() != null) {
			BlanketCoverage blanketCoverage = blanketCoverageRepository.findOne(
					proofOfCoverageDTO.getBlanketCoverageData().getRid());
			proofOfCoverageToUpdate.setBlanketCoverage(blanketCoverage);
		} else {
			proofOfCoverageToUpdate.setBlanketCoverage(null);
		}

		if (proofOfCoverageDTO instanceof FloodInsuranceDTO && proofOfCoverageToUpdate instanceof FloodInsurance) {
			ctracObjectMapper.map((FloodInsuranceDTO) proofOfCoverageDTO, (FloodInsurance) proofOfCoverageToUpdate);

			if (proofOfCoverageDTO.getInvalid()) {
				proofOfCoverageToUpdate.setPolicyStatus("INVALID_" + proofOfCoverageDTO.getPolicyStatus().name());
			}
		} else {
			ctracObjectMapper.map(proofOfCoverageDTO, proofOfCoverageToUpdate);
		}

		//Remove policy doc from proof of coverage
		if(proofOfCoverageDTO.getPolicyDocuments() == null || proofOfCoverageDTO.getPolicyDocuments().isEmpty()){
			proofOfCoverageToUpdate.getPolicyDocuments().clear();
		}

		if (!proofOfCoverageDTO.hasChanged()) {
			saveProvidedCoverageMap(proofOfCoverageDTO, proofOfCoverageToUpdate.getProvidedCoverages());
			return proofOfCoverageDTO;
		}

		// CHECK FOR DELETE
		proofOfCoverageToUpdate = proofOfCoverageRepository.saveAndFlush(proofOfCoverageToUpdate);
		proofOfCoverageDTO.refreshAuditUpdate(proofOfCoverageToUpdate);
		setPolicyNumberForAlthans(proofOfCoverageToUpdate);
		proofOfCoverageDTO.setRid(proofOfCoverageToUpdate.getRid());
		proofOfCoverageDTO.setPolicyNumber(proofOfCoverageToUpdate.getPolicyNumber());
		saveProvidedCoverageMap(proofOfCoverageDTO, proofOfCoverageToUpdate.getProvidedCoverages());
		if(proofOfCoverageDTO.getProvidedCoverageDTOs()!=null && !proofOfCoverageDTO.getProvidedCoverageDTOs().isEmpty()){
		    providedCoverageService.saveProvidedCoverage(proofOfCoverageDTO.getProvidedCoverageDTOs());
		}
		updateLoadTimeValues(Collections.singletonList(proofOfCoverageDTO));

		return proofOfCoverageDTO;
	}

	private void setPolicyNumberForAlthans(ProofOfCoverage proofOfCoverageToUpdate) {
		if( LpInsuranceVendor.ALTHANS.getDisplayName().equals(proofOfCoverageToUpdate.getInsuranceAgency()) && proofOfCoverageToUpdate.getPolicyNumber()==null){
			proofOfCoverageToUpdate.setPolicyNumber(proofOfCoverageToUpdate.getRid().toString());
			proofOfCoverageRepository.saveAndFlush(proofOfCoverageToUpdate);
		}

	}

	private String getBlanketCoverageType(ProofOfCoverageDTO proofOfCoverageDTO) {
		BlanketCoverageDTO blanketCoverageData = proofOfCoverageDTO.getBlanketCoverageData();
		if (blanketCoverageData != null && StringUtils.isNotBlank(blanketCoverageData.getBlanketCoverageType())) {
			return blanketCoverageData.getBlanketCoverageType();
		}
		return null;
	}

	private BlanketCoverageDTO saveBlanketCoverage(BlanketCoverageDTO blanketCoverageData) {
		BlanketCoverage blanketCoverage = null;
		if (blanketCoverageData.getRid() != null) {
			blanketCoverage = blanketCoverageRepository.findOne(blanketCoverageData.getRid());
		} else {
			blanketCoverage = new BlanketCoverage();
		}

		if (!blanketCoverageData.hasChanged()) {
			return blanketCoverageData;
		}
		setBlanketCoverageAmounts(blanketCoverageData);
		ctracObjectMapper.map(blanketCoverageData, blanketCoverage);
		blanketCoverage = blanketCoverageRepository.save(blanketCoverage);

		blanketCoverageData.setRid(blanketCoverage.getRid());
		blanketCoverageData.saveACopy();
		return blanketCoverageData;
	}

	private PaymentMethodDTO savePaymentMethod(PaymentMethodDTO paymentMethodData) {

		if (paymentMethodData.getAddress() != null) {
			addressDataService.saveAddress(paymentMethodData.getAddress());
		}

		PaymentMethod paymentMethod = null;
		if (paymentMethodData.getRid() != null) {
			paymentMethod = paymentMethodRepository.findOne(paymentMethodData.getRid());
		} else {
			paymentMethod = new PaymentMethod();
		}

		if (paymentMethodData.getAddress() != null) {
			Address address = addressRepository.findOne(paymentMethodData.getAddress().getRid());
			paymentMethod.setAddress(address);
		}

		if (!paymentMethodData.hasChanged()) {
			return paymentMethodData;
		}

		ctracObjectMapper.map(paymentMethodData, paymentMethod);
		paymentMethod = paymentMethodRepository.save(paymentMethod);

		paymentMethodData.setRid(paymentMethod.getRid());
		paymentMethodData.saveACopy();
		return paymentMethodData;
	}

	private void saveProvidedCoverageMap(ProofOfCoverageDTO proofOfCoverageDTO, List<ProvidedCoverage> providedCoverages) {
		if (proofOfCoverageDTO.getProvidedCoverageMap() == null) {
			logger.debug("Provided Coverage not modified. As of Release 6.1, the only place to modify is on the collateral screen.");
			return;
		}

		proofOfCoverageDTO.getProvidedCoverageMap().purgeUnneededCoverage();

		// make proofOfCoverage RID = null
		for (ProvidedCoverageDTO providedCoverageDTO : proofOfCoverageDTO.getProvidedCoverageDTOs()) {
			providedCoverageDTO.setProofOfCoverageDto(null);
		}

		// add proofOfCoverage RID
		String blanketCoverageType = getBlanketCoverageType(proofOfCoverageDTO);
		List<ProvidedCoverageDTO> newProvidedCoverageDTOs = proofOfCoverageDTO.getProvidedCoverageMap().getAllCoverages(false, blanketCoverageType);
		for (ProvidedCoverageDTO providedCoverageDTO : newProvidedCoverageDTOs) {
			providedCoverageDTO.setProofOfCoverageDto(proofOfCoverageDTO);
		}
		newProvidedCoverageDTOs = providedCoverageService.saveProvidedCoverage(newProvidedCoverageDTOs);
		Collection<Long> savedRids = new HashSet<>();
		for (ProvidedCoverageDTO providedCoverageDTO : newProvidedCoverageDTOs) {
			savedRids.add(providedCoverageDTO.getRid());
		}

		// delete unused providedCoverages
		Collection<Long> providedCoverageRidsToDelete = new HashSet<>();
		for (ProvidedCoverageDTO providedCoverageDTO : proofOfCoverageDTO.getProvidedCoverageDTOs()) {
			if (providedCoverageDTO.getProofOfCoverageDto() == null) {
				providedCoverageRidsToDelete.add(providedCoverageDTO.getRid());
			}
		}

		Collection<ProvidedCoverage> providedCoveragesToDelete = new HashSet<>();
		for (ProvidedCoverage providedCoverage : providedCoverages) {
			if (!savedRids.contains(providedCoverage.getRid()) ||
					providedCoverageRidsToDelete.contains(providedCoverage.getRid())) {
				providedCoveragesToDelete.add(providedCoverage);
			}
		}

		providedCoverages.removeAll(providedCoveragesToDelete);
		providedCoverageRepository.delete(providedCoveragesToDelete);
		providedCoverageRepository.flush();
		proofOfCoverageDTO.setProvidedCoverageDTOs(newProvidedCoverageDTOs);
	}

	@Override
	@Transactional
	public void initiateLenderPlaceWorkflow(CoverageActionResult result, WorkItem triggerWorkItem) {
		Collateral collateral = collateralRepository.findOne(result.getCollateralId());
		logger.info("Begin : initiateLenderPlaceWorkflow() : Number of LP: "+result.getLpCoveragesToIssues().size() + "LP renewal with no change: "+ result.getLpToRenewalNoChange().size());

		ProofOfCoverageAttributes proofOfCoverageAttributes = new ProofOfCoverageAttributes(triggerWorkItem);

		// If we are renewing existing LP we need to start the workflow at awaiting vendor invoice
		for (ProofOfCoverageDTO proofOfCoverageDTO : result.getLpToRenewalNoChange()) {
			logger.debug("start the workflow at awaiting vendor invoice");
			String insuranceVendorName = proofOfCoverageDTO.getInsuranceAgency();
			if(LpInsuranceVendor.ALTHANS.getDisplayName().equals(insuranceVendorName)){
				logger.debug("Start LP renewal no change workflow for Althans" + proofOfCoverageDTO.getRid());
				proofOfCoverageDTO = startLpRenewalWorkflow(collateral, proofOfCoverageAttributes, proofOfCoverageDTO, TaskStatus.TRANSIENT, PENDING_FOR_ALTHANS);
			}
			else{
				logger.debug("Start LP renewal no change workflow for Assurant at Awaiting Vendor Invoice" + proofOfCoverageDTO.getRid());
				proofOfCoverageDTO = startLpWorkflow(collateral, proofOfCoverageAttributes,	proofOfCoverageDTO, TaskStatus.OPEN, WorkflowStateDefinition.AWAITING_VENDOR_INVOICE);
			}
            publishLPIEvent(collateral, proofOfCoverageDTO, CollateralEventType.ADDED, true);
         }

		// instantiate the dormant pending verify first vendor letter perfection task
		for (ProofOfCoverageDTO proofOfCoverageDTO : result.getLpCoveragesToIssues()) {
			logger.debug("start the workflow at verify first vendor letter");
			proofOfCoverageDTO = startLpWorkflow(collateral, proofOfCoverageAttributes, proofOfCoverageDTO, TaskStatus.TRANSIENT, WorkflowStateDefinition.SEND_FIRST_LP_LETTER);
            publishLPIEvent(collateral, proofOfCoverageDTO, CollateralEventType.ADDED, true);
		}

		// exclude the policies which is also associated with cancellation
		emailNotificationService.releaseLpInitiatedMarketEmail(result.getLpPoliciesToIssueOnly(), collateral);

		// Send the combined email
		emailNotificationService.releaseCombinedIssueAndCancelLPEmail(result.getLpCoveragesToIssuesWithCancellation(), collateral);
		logger.info("END : initiateLenderPlaceWorkflow() =>  All actions successfully appplied ");
	}

    protected void publishLPIEvent(Collateral collateral, ProofOfCoverageDTO proofOfCoverageDTO,
                                   CollateralEventType collateralEventType, boolean isSystemEvent) {
        publishEventService.publishLPProofOfCoverageEvent(new LPIProofOfCoveragePublishEventRequest(
                proofOfCoverageDTO, collateral.getRid(), collateral.getPreferredLoan().getLineOfBusiness(), isSystemEvent)
                .forCollateralEventType(collateralEventType));
    }

    @Override
	public ProofOfCoverageDTO startLpLetterCycleWorkflowManually(Long collateralRid, ProofOfCoverageDTO proofOfCoverageDTO) {
		if(proofOfCoverageDTO.getLetterCycleWorkflowStep() != null){
			boolean isZoneIn = LenderPlaceReason.ZONE_IN.equals(proofOfCoverageDTO.getLenderPlaceReason());
			ProofOfCoverageAttributes proofOfCoverageAttributes = new ProofOfCoverageAttributes(isZoneIn);
			Collateral collateral = collateralRepository.findOne(collateralRid);
			proofOfCoverageDTO = startLpWorkflow(
					collateral, proofOfCoverageAttributes, proofOfCoverageDTO, TaskStatus.TRANSIENT, proofOfCoverageDTO.getLetterCycleWorkflowStep());
			if(WorkflowStateDefinition.SEND_FIRST_LP_LETTER == proofOfCoverageDTO.getLetterCycleWorkflowStep()){
				proofOfCoverageDTO.setPolicyStatus(PolicyStatus.PENDING_LETTER_CYCLE);
			}
			else{
				proofOfCoverageDTO.setPolicyStatus(PolicyStatus.LETTER_CYCLE);
			}
			if(PolicyType.LP_GAP.equals(proofOfCoverageDTO.getPolicyType())) {
				//Rid of borrower policy that initiated the gap
				proofOfCoverageDTO.setGapBorrowerPolicyRid(proofOfCoverageDTO.getParentPolicyRid());
			}
			if(proofOfCoverageDTO.getManualLetterCycle().isMarketEmailNeeded()) {
			    List<ProofOfCoverageDTO> policiesToIssue = new ArrayList<>();
                policiesToIssue.add(proofOfCoverageDTO);
                emailNotificationService.releaseLpInitiatedMarketEmail(policiesToIssue, collateral);
            }
		}
		return proofOfCoverageDTO;
	}

	@Override
	public boolean hasLivingRequiredCoverageDocument(Long collateralRid, ProofOfCoverage proofOfCoverage) {
		boolean coverageRequestStillNeeded = false;
		Set<PerfectionTask> perfectionTaskSet = collateralWorkflowService.getRequiredCoverageRequestTasks(collateralRid);
		for (PerfectionTask perfectionTask : perfectionTaskSet) {
			coverageRequestStillNeeded = true;
			WorkflowStateDefinition workflowStateDefinition = WorkflowStateDefinition.findByWorkflowStep(perfectionTask.getWorkflowStep());
			if (workflowRuleEvaluatorFactory.createReqCoverageWorkflowEvaluator(workflowStateDefinition).hasLivingRequiredCoverageOnExpiration(collateralRid, proofOfCoverage)) {
				return true;
			}
		}
		return !coverageRequestStillNeeded;
	}

	protected class ProofOfCoverageAttributes {

		private final String parentPerfectionSubType;
		private final String workflowId;
		private final String specialProcessing;

		public ProofOfCoverageAttributes(WorkItem triggerWorkItem) {
			if (triggerWorkItem != null) {
				parentPerfectionSubType = triggerWorkItem.getPerfectionSubType();
				workflowId = triggerWorkItem.getWorkFlowID();
			} else {
				parentPerfectionSubType = PerfectionItemSubType.POLICY.name();
				workflowId = TaskUniqueIdGenerator.generateAlphaNumericUniqueId(
						REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher);
			}
			specialProcessing = (PerfectionItemSubType.REMAP.name().equals(parentPerfectionSubType)) ?
					LPConstants.SPECIAL_PROCESSING_ZONE_IN.getDisplayName() : LPConstants.SPECIAL_PROCESSING_DEFAULT.getDisplayName();
		}

		public ProofOfCoverageAttributes(boolean isZoneIn) {
			if(isZoneIn){
				parentPerfectionSubType = PerfectionItemSubType.REMAP.name();
				specialProcessing = LPConstants.SPECIAL_PROCESSING_ZONE_IN.getDisplayName();
			}
			else{
				parentPerfectionSubType = PerfectionItemSubType.POLICY.name();
				specialProcessing = LPConstants.SPECIAL_PROCESSING_DEFAULT.getDisplayName();
			}
			workflowId = TaskUniqueIdGenerator.generateAlphaNumericUniqueId(
						REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher);
		}

		public String getParentPerfectionSubType() {
			return parentPerfectionSubType;
		}

		public String getWorkflowId() {
			return workflowId;
		}

		public String getSpecialProcessing() {
			return specialProcessing;
		}

	}

	protected ProofOfCoverageDTO startLpWorkflow(Collateral collateral, ProofOfCoverageAttributes proofOfCoverageAttributes,
			ProofOfCoverageDTO proofOfCoverageDTO, TaskStatus taskStatus, WorkflowStateDefinition workflowStep) {
		proofOfCoverageDTO = saveProofOfCoverage(proofOfCoverageDTO);

		if (proofOfCoverageDTO.getParentPolicyRid() != null) {
			ProofOfCoverage parentPolicy = proofOfCoverageRepository.findOne(proofOfCoverageDTO.getParentPolicyRid());
			if (parentPolicy != null && parentPolicy.getPolicyType_() != null && parentPolicy.getPolicyType_().isBorrowerPolicy()) {
				birRuleConclusionService.createOrUpdateException(proofOfCoverageDTO.getParentPolicyRid(), collateral.getRid(),
						BorrowerInsuranceReviewRule.GAP_IN_COVERAGE_RULE, BorrowerInsuranceReviewConclusion.ACTION_REQUIRED);
			}
		}
		LenderPlaceItem lenderPlaceWorkItem = saveLenderPlaceWorkItem(collateral, proofOfCoverageAttributes.getWorkflowId(),
				proofOfCoverageAttributes.getSpecialProcessing(), proofOfCoverageDTO);
		perfectionTaskService.createTask(taskStatus, lenderPlaceWorkItem, workflowStep.getFloodRemapTaskState(),
                getTMTaskType(proofOfCoverageAttributes.getParentPerfectionSubType()), null, null);
		createAndStoreProofCoverageWorkItem(proofOfCoverageDTO, lenderPlaceWorkItem);
		return proofOfCoverageDTO;
	}

	protected ProofOfCoverageDTO startLpRenewalWorkflow(Collateral collateral, ProofOfCoverageAttributes proofOfCoverageAttributes,
			ProofOfCoverageDTO proofOfCoverageDTO, TaskStatus taskStatus, WorkflowStateDefinition workflowStep) {
		proofOfCoverageDTO = saveProofOfCoverage(proofOfCoverageDTO);

		LenderPlaceItem lenderPlaceWorkItem = saveLenderPlaceWorkItem(collateral, proofOfCoverageAttributes.getWorkflowId(),
				proofOfCoverageAttributes.getSpecialProcessing(), proofOfCoverageDTO);

		List<ProofOfCovWorkItem> list = proofOfCovWorkItemRepository.findByProofOfCoverageRidAndItemType(proofOfCoverageDTO.getParentPolicyRid(), ProofOfCoverageWorkItemRelationType.RENEWAL_TO_POLICY.getName());
		for (ProofOfCovWorkItem listItem : list){
			List<PerfectionTask> tasks = perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(listItem.getWorkItem(), WorkflowStateDefinition.VERIFY_PAYMENT_METHOD.getName(), TaskStatus.OPEN.name());
			for(PerfectionTask task : tasks){
				task.setWorkItem(lenderPlaceWorkItem);
				perfectionTaskService.saveTask(task);
			}
		}
		Map<StateParameterType, Object> inputParameterMap = new HashMap<>();
		inputParameterMap.put(StateParameterType.WORK_ITEM, lenderPlaceWorkItem);
		String userId = StringUtils.isBlank(auditInformationService.getLoggedInUserSid()) ?
				auditInformationService.getLoggedInUserSid() : SYSTEM;
        perfectionTaskService.createTask(taskStatus, lenderPlaceWorkItem, workflowStep.getFloodRemapTaskState(),
                getTMTaskType(proofOfCoverageAttributes.getParentPerfectionSubType()), userId, inputParameterMap);
		createAndStoreProofCoverageWorkItem(proofOfCoverageDTO, lenderPlaceWorkItem);
		return proofOfCoverageDTO;
	}


	@Transactional
	public int restartLpCycleWorkflow(Long[] proofOfCoverageRids) {

		int restartLpCycleWorkflowCount = 0;

		if (proofOfCoverageRids != null) {
			for (Long proofOfCoverageRid : proofOfCoverageRids) {
				List<ProofOfCovWorkItem> items = proofOfCovWorkItemRepository.findByProofOfCoverageRidAndItemType(proofOfCoverageRid,  ProofOfCoverageWorkItemRelationType.LENDERPLACEMENT_TO_POLICY.getName());
					for (ProofOfCovWorkItem item : items){
						Boolean perfectionTaskChanged = false;
						LenderPlaceItem lenderPlaceWorkItem  = (LenderPlaceItem)item.getWorkItem();

						List<PerfectionTask> tasks  = perfectionTaskRepository.findByWorkItemAndTaskStatus(lenderPlaceWorkItem, TaskStatus.TRANSIENT.name());

						for (PerfectionTask task : tasks){
								if(WorkflowStateDefinition.SEND_SECOND_LP_LETTER.getName().equals(task.getWorkflowStep())
										|| WorkflowStateDefinition.QUEUE_FOR_ALTHANS.getName().equals(task.getWorkflowStep())
										|| WorkflowStateDefinition.PENDING_FOR_ALTHANS.getName().equals(task.getWorkflowStep())
										|| WorkflowStateDefinition.SEND_FINAL_LP_LETTER.getName().equals(task.getWorkflowStep())){
									task.setWorkflowStep(WorkflowStateDefinition.SEND_FIRST_LP_LETTER.getName());
									task.setWakeUpDate(((SleepingTaskState) WorkflowStateDefinition.SEND_FIRST_LP_LETTER.getFloodRemapTaskState()).getWakeupDate(null));
									perfectionTaskChanged = true;
									perfectionTaskService.saveTask(task);
								}
						}

						if (perfectionTaskChanged) {
							restartLpCycleWorkflowCount++;
							lenderPlaceWorkItem.setFirstLetterDate(null);
							lenderPlaceWorkItem.setSecondLetterDate(null);

							workItemRepository.save(lenderPlaceWorkItem);

							ProofOfCoverage proofOfCoverage = item.getProofOfCoverage();

							final Date today = businessDayUtil.getCurrentReferenceDateAtStartOfDay();
							proofOfCoverage.setLpLetterCycleRestartedDate(today);
							proofOfCoverage.setPolicyStatus(PolicyStatus.PENDING_LETTER_CYCLE.name());
							proofOfCoverageRepository.save(item.getProofOfCoverage());
						}
					}
			}
		}

		return (restartLpCycleWorkflowCount);
	}

	@Override
	@Transactional
	public void removeInsurancePolicyFromCollateral(long collateralRid, ProofOfCoverageDTO proofOfCoverageDTO) {
		List<InsurableAsset> insurableAssets = insurableAssetRepository.findByBuildingCollateralRid(collateralRid);
        Collateral collateral = collateralRepository.findOne(collateralRid);
		if (!insurableAssets.isEmpty()) {
			Set<Long> insurableAssetRids = new HashSet<>();
			for (InsurableAsset collInsurableAsset : insurableAssets) {
				insurableAssetRids.add(collInsurableAsset.getRid());
			}

			Iterator<ProvidedCoverageDTO> providedCoverageIter = proofOfCoverageDTO.getProvidedCoverageDTOs().iterator();
			while(providedCoverageIter.hasNext()) {
				ProvidedCoverageDTO providedCoverageDTO = providedCoverageIter.next();
				if (insurableAssetRids.contains(providedCoverageDTO.getInsurableAssetDTO().getRid())) {
					providedCoverageRepository.delete(providedCoverageDTO.getRid());
				}
			}
			providedCoverageRepository.flush();
			publishLPIEvent(collateral, proofOfCoverageDTO, CollateralEventType.DELETED, false);
		}
	}

	@Override
	@Transactional
	public void initiateLPCancellationWorkflow(CoverageActionResult result, WorkItem triggerWorkItem) {
		
		try {
		Collateral collateral = collateralRepository.findOne(result.getCollateralId());
		logger.info("\n Begin : initiateCancellationWorkflow() : Number of LP to cancel: "+result.getLpCoveragesToCancels().size() );
		if(result==null || result.getLpCoveragesToCancels().isEmpty()){
			logger.info("End : initiateCancellationWorkflow() : => no action needed " );
		}
		Iterator<ProofOfCoverageDTO>  proofOfCovDtoItr = result.getLpCoveragesToCancels().iterator();

		while( proofOfCovDtoItr.hasNext() ){
			ProofOfCoverageDTO proofOfCovDto =  proofOfCovDtoItr.next();
			if(proofOfCovDto instanceof FloodInsuranceDTO){
				/// 100% always true now
				FloodInsuranceDTO lpPolicy = (FloodInsuranceDTO) proofOfCovDto;

				// 1 - Store Changes made on the proof of coverage
				/*
				  The coverage computation engine should have setup all the
				  attributes of this object
				 */
				saveProofOfCoverage(lpPolicy);
                publishLPIEvent(collateral, lpPolicy, CollateralEventType.EDITED, true);
				readyForLenderPlaceService.updateForPolicyCancelled(lpPolicy.getRid());
				// if the cancellation request should not be sent to the vendor
				// (it happen when we never ask to issue the policy to begin
				// with, we are done)
				if (lpPolicy.getCancellationTargetDate() == null) {
					proofOfCovDtoItr.remove();
					continue;
				}
				// 2- Initiate a task AwaitingVendorCancellationLetterState and
				// link it to the existing work Item
				/*
				  We decided that LP and Cancellation were part of the same
				  workflow, so the same workItem will be used to track
				  cancellation and lender placements
				 */
				ProofOfCoverage floodInsurance = proofOfCoverageRepository.findOne(lpPolicy.getRid());

				////Aruna and Ying think this section below that creates another workitem for the same policy is not correct. as we only allow
				////1 work item per policy
				boolean isVendorRefundNeeded = false;
				LenderPlaceItem lenderPlaceItem = floodInsurance.findLenderPlaceItem();
				if (lenderPlaceItem == null) {
					lenderPlaceItem = getNewLPItem();
					lenderPlaceItem.addCollateral(collateral);
					lenderPlaceItem.setLpPhase(LpPhase.LP_CANCELLATION.name());
					lenderPlaceItem = workItemRepository.save(lenderPlaceItem);
					ProofOfCoverageWorkItemRelationType relType = ProofOfCoverageWorkItemRelationType.LENDERPLACEMENT_TO_POLICY;
					floodInsurance.addWorkItem(lenderPlaceItem, relType);
					floodInsurance = proofOfCoverageRepository.saveAndFlush(floodInsurance);
					List<ProofOfCovWorkItem> proofOfCovWorkItems = floodInsurance.getProofOfCovWorkItem();
					for (ProofOfCovWorkItem proofOfCovWorkItem : proofOfCovWorkItems) {
						if (proofOfCovWorkItem.getItemType().equals(relType.name())) {
							lenderPlaceItem.getProofOfCovWorkItems().add(proofOfCovWorkItem);
						}
					}
				} else {
					lenderPlaceItem.setLpPhase(LpPhase.LP_CANCELLATION.name());
					lenderPlaceItem = workItemRepository.save(lenderPlaceItem);
					isVendorRefundNeeded = lenderPlaceItem.getPremiumAmount() != null
							|| (floodInsurance.getCancellationEffectiveDate() != null
								&& floodInsurance.getCancellationEffectiveDate().after(floodInsurance.getEffectiveDate()));
				}

				if(proofOfCovDto.getInsuranceAgency().equals(LpInsuranceVendor.ALTHANS.getDisplayName())){
					createCancellationLetterTask(lenderPlaceItem);

					// LCP-2984: if Policy is sent, create Queue_For_Althans
					if (isAlthansCancellationNeeded(proofOfCovDto)) {
						createQueueForAlthansTask(lenderPlaceItem);

						//LCP-3687: After starting the cancellation process on an Althans LPI policy where I have sent a request
						//to Althans for a new issue I want CTRAC to set the default values for all LOBs and create an TM task "Vendor Refund Method"
						//for non Business Banking LOB so that I have settlement instructions in all cases and a task to verify the non-business banking cases
						if (isVendorRefundNeeded) {
							vendorPaymentMethodService.setDefaultRefundPaymentMethod(floodInsurance, lenderPlaceItem);
						}
					}
				}else{
					otmService.createTask(TMTaskType.FLOOD_INSURANCE, lenderPlaceItem,
							WorkflowStateDefinition.AWAITING_VENDOR_CANCELLATION_LETTER.getFloodRemapTaskState());
				}
			}
		}

        /*
          3 send the Lp_cancellation letter.
         */
		emailNotificationService.releaseLpMarketCancellationEmail(result.getLpPoliciesToCancelOnly(), collateral.getRid(),result.getLpCoveragesToIssues() );
		logger.info("\n End : initiateCancellationWorkflow() : All actions successfully applied  ");
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
		}
	}

    protected boolean isAlthansCancellationNeeded(ProofOfCoverageDTO proofOfCovDto) {
        return proofOfCovDto.getMigrated() && !proofOfCovDto.isCancelledInLetterCycle() ||
                (proofOfCovDto.getLenderPlaceItemData().getLpSendDate() != null &&
                    !proofOfCovDto.getLenderPlaceItemData().getLpSendDate().equals(""));
    }

    @Override
	public void initiateLPUpdateWorkflow(CoverageActionResult result, WorkItem triggerWorkItem) {
		logger.info("\n Begin : initiateLPUpdateWorkflow() : Number of LP to update: "+result.getLpCoveragesToUpdate().size() );
		if(result==null || result.getLpCoveragesToUpdate().isEmpty()){
			logger.info("End : initiateLPUpdateWorkflow() : => no action needed " );
		}
		Iterator<ProofOfCoverageDTO>  proofOfCovDtoItr = result.getLpCoveragesToUpdate().iterator();

		while( proofOfCovDtoItr.hasNext() )
		{
			ProofOfCoverageDTO proofOfCovDto =  proofOfCovDtoItr.next();
			if(proofOfCovDto instanceof FloodInsuranceDTO)
			{
				/// 100% always true now
				FloodInsuranceDTO lpPolicy = (FloodInsuranceDTO) proofOfCovDto;

				// 1 - Store Changes made on the proof of coverage
				/*
				  The coverage computation engine should have setup all the
				  attributes of this object
				 */
				saveProofOfCoverage(lpPolicy);
                Collateral collateral = collateralRepository.findOne(result.getCollateralId());
                publishLPIEvent(collateral, lpPolicy, CollateralEventType.EDITED, true);
				/*
				  no other actions required unless 2nd letter is already sent
				 */
				//checking current letter cycle step is after 2nd letter sent: createTask to send 2nd GAP letter
				List<ProofOfCovWorkItem> items = proofOfCovWorkItemRepository.findByProofOfCoverageRidAndItemType(
						proofOfCovDto.getRid(),
						ProofOfCoverageWorkItemRelationType.LENDERPLACEMENT_TO_POLICY.getName());
				for (ProofOfCovWorkItem item : items) {
					LenderPlaceItem lenderPlaceWorkItem = (LenderPlaceItem) item.getWorkItem();
					List<PerfectionTask> tasks = perfectionTaskRepository
							.findByWorkItemAndTaskStatus(lenderPlaceWorkItem, TaskStatus.TRANSIENT.name());
					for (PerfectionTask task : tasks) {
						if (WorkflowStateDefinition.PENDING_FOR_ALTHANS.getName().equals(task.getWorkflowStep())) {
                            perfectionTaskService.createTransientTask(
                                    lenderPlaceWorkItem, SEND_SECOND_LP_LAPSE_LETTER.getFloodRemapTaskState(), TMTaskType.FLOOD_INSURANCE, null);
						}
					}
				}
				//end of create 2nd gap exception letter
			}
		}
		logger.info("\n End : initiateLPUpdateWorkflow() : All actions successfully applied  ");
	}

	@Override
	@Transactional
	public List<ProofOfCoverageDTO> findActiveByCollateral(Long collateralId) {
		List<CollateralInsuranceViewData> collateralInsuranceData =
				collateralInsuranceRepository.findByCollateralRidOrderByProofOfCoverageExpirationDateAsc(collateralId);
		List<ProofOfCoverage> activePolicies = filterPoliciesByActive(collateralInsuranceData, true);
		List<ProofOfCoverageDTO> activePolicyDTOs = mapProofsOfCoverage(activePolicies, collateralId);
		updateLoadTimeValues(activePolicyDTOs);
		return activePolicyDTOs;
	}

	@Override
	@Transactional
	public List<Long> getLenderPlaceWorkItem(Long proofOfCovId){

		 List<Long> result = new ArrayList<>();
		ProofOfCoverage proofOfCoverage  = proofOfCoverageRepository.findOne(proofOfCovId);
		if(proofOfCoverage == null || proofOfCoverage.getProofOfCovWorkItem() == null ){
			return result;
		}
		for (ProofOfCovWorkItem proofWorkItem : proofOfCoverage.getProofOfCovWorkItem()) {
			WorkItem workItem = CtracBaseEntity.deproxy(proofWorkItem.getWorkItem(), WorkItem.class);
			if (workItem instanceof LenderPlaceItem) {
				result.add(workItem.getRid());
			}
		}
		return result;
	}


	@Override
	@Transactional
	public List<ProofOfCoverageDTO> findActiveByCollateralAndType(Long collateralId, Set<PolicyType> policyTypes ) {

		List<ProofOfCoverageDTO> proofOfCoverages = findActiveByCollateral(collateralId);
    	if(proofOfCoverages!=null && !proofOfCoverages.isEmpty() ){
    	   Iterator<ProofOfCoverageDTO> iterator = proofOfCoverages.iterator();
    		while(iterator.hasNext()){
    			ProofOfCoverageDTO proofOfCoverageDTO = iterator.next();
    			if( (policyTypes!=null) && !policyTypes.contains(proofOfCoverageDTO.getPolicyType())  ){
    				iterator.remove();
    			}
    		}
    	}
		return proofOfCoverages;
	}

	private void updateLoadTimeValues(List<ProofOfCoverageDTO> policyDTOs) {
		for (ProofOfCoverageDTO policyDTO : policyDTOs) {
			policyDTO.saveACopy();
		}
	}

	@Override
	@Transactional
	public List<ProofOfCoverageDTO> findInactiveByCollateral(Long collateralId) {
		List<CollateralInsuranceViewData> collateralInsuranceData =
				collateralInsuranceRepository.findByCollateralRidOrderByProofOfCoverageExpirationDateAsc(collateralId);
		List<ProofOfCoverage> inactivePolicies = filterPoliciesByActive(collateralInsuranceData, false);
		return mapProofsOfCoverage(inactivePolicies, collateralId);
	}

	private List<ProofOfCoverage> filterPoliciesByActive(List<CollateralInsuranceViewData> collateralInsuranceData, boolean wantActive) {
		List<ProofOfCoverage> policies = new ArrayList<>();
		for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceData) {
			ProofOfCoverage proofOfCoverage = collateralInsurance.getProofOfCoverage();
			PolicyStatus collateralPolicyStatus =
					activePolicyService.getPolicyStatus(proofOfCoverage, collateralInsurance.getCollateral().getRid());
			boolean isActive = collateralPolicyStatus.isActive(true);
			if(collateralPolicyStatus == PolicyStatus.CANCELLED && proofOfCoverage.getCancellationEffectiveDate()!= null){
				isActive = !(calendarDayUtil.isReferenceDateAfterDate(proofOfCoverage.getCancellationEffectiveDate()));
			}

			if ((wantActive && isActive) || (!wantActive && !isActive)) {
				proofOfCoverage.setCollateralPolicyStatus(collateralPolicyStatus);
				policies.add(proofOfCoverage);
			}
		}
		return policies;
	}

	@Override
	@Transactional
	public FloodInsuranceDTO createNewInsuranceForCollateral(Long collateralId) {
		return createFloodInsuranceDTO(collateralId);
	}

	@Override
	public GenericProofOfCoverageDTO createGenericInsuranceForCollateral(Long collateralId) {
		GenericProofOfCoverageDTO genericInsuranceData = new GenericProofOfCoverageDTO();
		genericInsuranceData.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
		initializeCoverageMap(collateralId, genericInsuranceData);
		return genericInsuranceData;
	}

	@Override
	@Transactional
	public void addCollateralToPolicy(ProofOfCoverageDTO proofOfCoverageData, Long proposedCollateralId) {
        List<PrimaryLoanBorrowerViewData> proposedPrimaryLoan =
                primaryLoanRepository.findByCollateralRid(proposedCollateralId);
        if (proposedPrimaryLoan.size() == 0) {
            throw new CTracApplicationException("E0249", CtracErrorSeverity.TRIVIAL);
        }

        //When there are existing collaterals on the BIR, compare for valid loan type
        if(proofOfCoverageData.getProvidedCoverageMap().getInsurableAssetCoverageData().keySet().size() > 0){
			List<PrimaryLoanBorrowerViewData> existingPrimaryLoan = primaryLoanRepository.findByCollateralRid(
					proofOfCoverageData.getProvidedCoverageMap().getInsurableAssetCoverageData().keySet().iterator().next());
			LoanType existingLoanType = LoanType.findByDisplayName(existingPrimaryLoan.get(0).getLoanType());
			LoanType proposedLoanType = LoanType.findByDisplayName(proposedPrimaryLoan.get(0).getLoanType());
			if (existingLoanType == LoanType.EXTERNALLY_AGENTED && proposedLoanType != LoanType.EXTERNALLY_AGENTED ||
					existingLoanType != LoanType.EXTERNALLY_AGENTED && proposedLoanType == LoanType.EXTERNALLY_AGENTED) {
				throw new CTracApplicationException("E0249C", CtracErrorSeverity.TRIVIAL);
			}
			if (proofOfCoverageData.getProvidedCoverageMap().containsCollateral(proposedCollateralId)) {
				throw new CTracApplicationException("E0249B", CtracErrorSeverity.TRIVIAL);
			}
		}
		proofOfCoverageData.getProvidedCoverageMap().addCollateral(proposedCollateralId);
	}

	private FloodInsuranceDTO createFloodInsuranceDTO(Long collateralId) {
		FloodInsuranceDTO floodPolicy = new FloodInsuranceDTO();
		floodPolicy.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
		initializeCoverageMap(collateralId, floodPolicy);
		return floodPolicy;
	}

	private void initializeCoverageMap(Long collateralRid, ProofOfCoverageDTO floodPolicy) {
		if (floodPolicy.getProvidedCoverageMap() == null) {
			floodPolicy
					.setProvidedCoverageMap(new InsuranceCoverageMap<>(ProvidedCoverageDTO.class));
		}
		if (collateralRid != null) {
			floodPolicy.getProvidedCoverageMap().addCollateral(collateralRid);
		}
	}

	private AgentData saveAgent(AgentData agentData) {
		if (agentData.getContactDetailDto() != null) {
			contactDetailDataService.saveContactDetail(agentData.getContactDetailDto());
		}

		Agent agent = null;
		if (agentData.getRid() != null) {
			agent = agentRepository.findOne(agentData.getRid());
		}
		else {
			agent = new Agent();
		}

		if (agentData.getContactDetailDto() != null) {
			ContactDetails contactDetails = contactDetailsRepository.findOne(agentData.getContactDetailDto().getRid());
			agent.setContactDetails(contactDetails);
		}

		if (!agentData.hasChanged()) {
			return agentData;
		}

		ctracObjectMapper.map(agentData, agent);
		agent = agentRepository.save(agent);
		agentData.setRid(agent.getRid());
		agentData.saveACopy();
		return agentData;
	}

	@Override
	public List<ProofOfCoverageDTO> mapProofsOfCoverage(Collection<ProofOfCoverage> policies, Long collateralRid) {
		List<ProofOfCoverageDTO> proofOfCoverageDTOs = new ArrayList<>();
		for (ProofOfCoverage proofOfCoverage : policies) {
		    ProofOfCoverageDTO proofOfCoverageData = mapProofsOfCoverage(proofOfCoverage, collateralRid);
		    proofOfCoverageDTOs.add(proofOfCoverageData);
		}
		return proofOfCoverageDTOs;
	}

	@Override
	public ProofOfCoverageDTO mapProofsOfCoverage(ProofOfCoverage proofOfCoverage, Long collateralRid){
	    proofOfCoverage = CtracBaseEntity.deproxy(proofOfCoverage, ProofOfCoverage.class);
	    PolicyStatus collateralPolicyStatus = activePolicyService.getPolicyStatus(proofOfCoverage, collateralRid);
	    proofOfCoverage.setCollateralPolicyStatus(collateralPolicyStatus);
        ProofOfCoverageDTO proofOfCoverageData = null;
        if (proofOfCoverage instanceof FloodInsurance) {
            proofOfCoverageData = ctracObjectMapper.map(proofOfCoverage, FloodInsuranceDTO.class);
            List<ProvidedCoverageDTO> providedCoverageDTOs = new ArrayList<>();
            for (ProvidedCoverage providedCoverage : proofOfCoverage.getProvidedCoverages()) {
                providedCoverageDTOs.add(mapProvidedCoverage(providedCoverage, proofOfCoverageData));
            }
            proofOfCoverageData.setProvidedCoverageDTOs(providedCoverageDTOs);
        }
        if (proofOfCoverageData != null) {
        	if (proofOfCoverageData.getPolicyType() != null && proofOfCoverageData.getPolicyType().isBorrowerPolicy() &&
        			collateralPolicyStatus.isActive(false)) {
        		proofOfCoverageData.setHasException(
            			birRuleConclusionService.hasException(proofOfCoverageData.getRid()));
        	}
            proofOfCoverageData.setProvidedCoverageMap(
                    insuranceCoverageMapFactory.getProvidedInsuranceCoverageMap(
                            proofOfCoverageData.getProvidedCoverageDTOs()));
            LenderPlaceItem lenderPlaceItem = proofOfCoverage.findLenderPlaceItem();
            if (lenderPlaceItem != null) {
            	LenderPlaceItemDTO lenderPlaceItemDTO = ctracObjectMapper.map(lenderPlaceItem, LenderPlaceItemDTO.class);
                proofOfCoverageData.setLenderPlaceItemData(lenderPlaceItemDTO);
                mapPremiumAndRefundInfo(lenderPlaceItem, lenderPlaceItemDTO, proofOfCoverage);
                //setting isCancelledNoRefund on LenderPlaceItemDTO for display on policy overlay
                if (LpInsuranceVendor.ALTHANS.getDisplayName().equals(proofOfCoverageData.getInsuranceAgency())
                		&& proofOfCoverageData.getPolicyStatus().isCancelled()
                		&& !CoverageLapseDetector.hasLapseInCoverageDates(proofOfCoverageData)
                		&& !isWireRefundNeeded(lenderPlaceItem)) {
                	proofOfCoverageData.getLenderPlaceItemData().setIsCancelledNoRefund(true);
                }
            }
            InsuranceRenewalItem renewalItem = proofOfCoverage.findInsuranceRenewalItem();
            if (renewalItem != null && renewalItem.getPreRenewalLetterDate() != null) {
            	proofOfCoverageData.setPreRenewalLetterDate(DateFormatter.toString(renewalItem.getPreRenewalLetterDate()));
            }
            proofOfCoverageData.setRenewable(isPolicyRenewable(proofOfCoverageData));
            proofOfCoverageData.setRenewed(isRenewed(proofOfCoverageData));
        }
        return proofOfCoverageData;
	}

	private void mapPremiumAndRefundInfo(LenderPlaceItem lenderPlaceItem, LenderPlaceItemDTO lenderPlaceItemDTO, ProofOfCoverage proofOfCoverage) {
		BigDecimal totalPremiumAmount = BigDecimal.ZERO;
		if (lenderPlaceItem.getPremiumAmount() != null) {
			totalPremiumAmount = totalPremiumAmount.add(lenderPlaceItem.getPremiumAmount());
		}
		if (lenderPlaceItem.getBankPremiumAmount() != null) {
			totalPremiumAmount = totalPremiumAmount.add(lenderPlaceItem.getBankPremiumAmount());
		}
		if (totalPremiumAmount.compareTo(BigDecimal.ZERO) > 0) {
			lenderPlaceItemDTO.setTotalPremiumAmount(AmountFormatter.format(totalPremiumAmount));
			int totalPremiumDays = bankPortionRule.calculateTotalPremiumPeriod(proofOfCoverage.getEffectiveDate(), proofOfCoverage.getExpirationDate());
			int bankPremiumDays = bankPortionRule.calculateBankPremiumDays(proofOfCoverage.getEffectiveDate(), proofOfCoverage.getExpirationDate(), lenderPlaceItem.getBillingDate());
			lenderPlaceItemDTO.setTotalPremiumDays(totalPremiumDays);
			lenderPlaceItemDTO.setBankPremiumDays(bankPremiumDays);
			lenderPlaceItemDTO.setBorrowerPremiumDays(totalPremiumDays - bankPremiumDays);
		}

		BigDecimal totalRefundAmount = BigDecimal.ZERO;
		if (lenderPlaceItem.getRefundAmount() != null) {
			totalRefundAmount = totalRefundAmount.add(lenderPlaceItem.getRefundAmount());
		}
		if (lenderPlaceItem.getBankRefundAmount() != null) {
			totalRefundAmount = totalRefundAmount.add(lenderPlaceItem.getBankRefundAmount());
		}
		if (totalRefundAmount.compareTo(BigDecimal.ZERO) > 0) {
			lenderPlaceItemDTO.setTotalRefundAmount(AmountFormatter.format(totalRefundAmount));
		}
	}

	@Override
	public boolean isPolicyRenewable(ProofOfCoverageDTO proofOfCoverageData) {
		if((proofOfCoverageData.getPolicyStatus().isActive(false) || PolicyStatus.EXPIRED.equals(proofOfCoverageData.getPolicyStatus())) &&
				proofOfCoverageData.getPolicyType().isPolicy()) {
			List<ParentPolicyDetailsViewData> parentPolicyChildren = parentPolicyDetailsRepository.findAllByParentPolicyRid(proofOfCoverageData.getRid());
			if(parentPolicyChildren == null) {
				return true;
			}
			for (ParentPolicyDetailsViewData parentPolicyDetailsViewData : parentPolicyChildren) {
				PolicyType childPolicyType = PolicyType.valueOf(parentPolicyDetailsViewData.getChildPolicyType());
				if(childPolicyType.isPolicy()) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	@Override
    public boolean isRenewalPolicyAccepted(ProofOfCoverage proofOfCoverage) {
        return floodInsuranceRenewalService.isRenewalPolicyAccepted(proofOfCoverage);
    }

	@Override
	public boolean isRenewed(ProofOfCoverageDTO proofOfCoverageData){
		if(proofOfCoverageData.getParentPolicyRid() == null){
			return false;
		}
		ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(proofOfCoverageData.getParentPolicyRid());
		PolicyType parentPolicyType = proofOfCoverage.getPolicyType_();
		PolicyType childPolicyType = proofOfCoverageData.getPolicyType();
		return (parentPolicyType.isPolicy() && childPolicyType.isPolicy()) || (parentPolicyType.isLenderPlaced() && childPolicyType.isLenderPlaced());
	}

	private ProvidedCoverageDTO mapProvidedCoverage(ProvidedCoverage providedCoverage, ProofOfCoverageDTO proofOfCoverageDto) {
		InsurableAsset insurableAsset = CtracBaseEntity.deproxy(providedCoverage.getInsurableAsset(),
				InsurableAsset.class);
		ProvidedCoverageDTO providedCoverageDTO = ctracObjectMapper.map(providedCoverage, ProvidedCoverageDTO.class);
		InsurableAssetDTO insurableAssetDTO = ctracObjectMapper.map(insurableAsset, InsurableAssetDTO.class);
		providedCoverageDTO.setInsurableAssetDTO(insurableAssetDTO);
		providedCoverageDTO.setProofOfCoverageDto(proofOfCoverageDto);
		providedCoverageDTO.setPropertyType(insurableAsset.getPropertyType());
		providedCoverageDTO.saveACopy();
		return providedCoverageDTO;
	}


	private LenderPlaceItem getNewLPItem() {
		LenderPlaceItem lpItem;
		lpItem =new LenderPlaceItem();
		   lpItem.setWorkFlowID(TaskUniqueIdGenerator.generateAlphaNumericUniqueId(REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher));
		   lpItem.setInitiationDate(calendarDayUtil.getCurrentReferenceDate());
		   lpItem.setPerfectionType(PerfectionItemType.FLOOD_POLICY.name());
		   lpItem.setPerfectionSubType(PerfectionItemSubType.POLICY.name());
		   lpItem.setInitialAuditInfo(SYSTEM);
		return lpItem;
	}

	/**
	 * @param blanketCoverageData
	 */
	private void setBlanketCoverageAmounts(BlanketCoverageDTO blanketCoverageData) {
		if(StringUtils.isNotBlank(blanketCoverageData.getBlanketCoverageType())){
			if(blanketCoverageData.getBlanketCoverageType().equalsIgnoreCase("IND"))
			{
				blanketCoverageData.setBlanketCombinedAmount(null);
				blanketCoverageData.setBlanketContentAmount(null);
				blanketCoverageData.setBlanketBuildingAmount(null);
			}
			else if(blanketCoverageData.getBlanketCoverageType().equalsIgnoreCase("CONTS"))
			{
				blanketCoverageData.setBlanketCombinedAmount(null);
				blanketCoverageData.setBlanketBuildingAmount(null);
			}
			else if (blanketCoverageData.getBlanketCoverageType().equalsIgnoreCase("BLDG"))
			{
				blanketCoverageData.setBlanketCombinedAmount(null);
				blanketCoverageData.setBlanketContentAmount(null);
			}
			else if (blanketCoverageData.getBlanketCoverageType().equalsIgnoreCase("AND_OR"))
			{
				blanketCoverageData.setBlanketCombinedAmount(null);
			}
		}
	}

	private void createAndStoreProofCoverageWorkItem(ProofOfCoverageDTO proofOfCoverageDTO,
			LenderPlaceItem lenderPlaceWorkItem) {
		ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(proofOfCoverageDTO.getRid());
		proofOfCoverage.addWorkItem(lenderPlaceWorkItem, ProofOfCoverageWorkItemRelationType.LENDERPLACEMENT_TO_POLICY);
		proofOfCoverage = proofOfCoverageRepository.saveAndFlush(proofOfCoverage);
	}


	private TMTaskType getTMTaskType(String perfectionSubType) {
		return PerfectionItemSubType.REMAP.name().equals(perfectionSubType) ?
				TMTaskType.FLOOD_REMAP : TMTaskType.FLOOD_INSURANCE;
	}

	/**
	 *  2 - build the Lender place workItem needed to track the LP flow
	 */
	private LenderPlaceItem saveLenderPlaceWorkItem(Collateral collateral, String workflowId, String specialProcessing,
			ProofOfCoverageDTO proofOfCoverageDTO) {
		 LenderPlaceItem lenderPlaceWorkItem = new LenderPlaceItem(workflowId,
		            businessDayUtil.getCurrentReferenceDate(), PerfectionItemType.FLOOD_POLICY.name(),
		            PerfectionItemSubType.POLICY.name(), LpPhase.PRE_LETTER_CYCLE.name(), specialProcessing);
		 lenderPlaceWorkItem.setFirstLetterDate(proofOfCoverageDTO.getExpiredPreRenewalLetterDate());
		 populatetManualLetterDates(proofOfCoverageDTO, lenderPlaceWorkItem);
		 lenderPlaceWorkItem.addCollateral(collateral);
		 lenderPlaceWorkItem = workItemRepository.save(lenderPlaceWorkItem);
		 return lenderPlaceWorkItem;
	}

	protected void populatetManualLetterDates(ProofOfCoverageDTO proofOfCoverageDTO, LenderPlaceItem lenderPlaceWorkItem) {
		if(proofOfCoverageDTO.getManualLetterCycle() != null && proofOfCoverageDTO.getManualLetterCycle().getFirstLetterDate_() != null) {
			 if(WorkflowStateDefinition.SEND_SECOND_LP_LETTER.equals(proofOfCoverageDTO.getLetterCycleWorkflowStep()) ) {
				 lenderPlaceWorkItem.setFirstLetterDate(proofOfCoverageDTO.getManualLetterCycle().getFirstLetterDate_());
			 }
			 if(WorkflowStateDefinition.PENDING_FOR_ALTHANS.equals(proofOfCoverageDTO.getLetterCycleWorkflowStep()) ) {
				 lenderPlaceWorkItem.setFirstLetterDate(proofOfCoverageDTO.getManualLetterCycle().getFirstLetterDate_());
				 lenderPlaceWorkItem.setSecondLetterDate(proofOfCoverageDTO.getManualLetterCycle().getSecondLetterDate_());
			 }
		 }
	}

	protected PerfectionTask createCancellationLetterTask(LenderPlaceItem lpItem){
        PerfectionTask sendCancellationTask = perfectionTaskService.createTask(
                TaskStatus.TRANSIENT, lpItem, WorkflowStateDefinition.SEND_CANCELLATION_LETTER.getFloodRemapTaskState(),
                TMTaskType.FLOOD_INSURANCE, lpItem.getInsertedBy(), null);
		return sendCancellationTask;
	}

	private PerfectionTask createQueueForAlthansTask(LenderPlaceItem lpItem){
        PerfectionTask queueForAlthansTask = perfectionTaskService.createTask(
                TaskStatus.TRANSIENT, lpItem, WorkflowStateDefinition.QUEUE_FOR_ALTHANS.getFloodRemapTaskState(),
                TMTaskType.FLOOD_INSURANCE, lpItem.getInsertedBy(), null);
		return queueForAlthansTask;
	}

	@Override
	@Transactional
	public void deleteProvidedCoverages(CoverageActionResult coverageActionResult) {
        for (Long policyRid: coverageActionResult.getPolicyToDelete() ) {
            providedCoverageRepository.deleteByProofOfCoverageRid(policyRid);
            Collateral collateral = collateralRepository.findOne(coverageActionResult.getCollateralId());
            ProofOfCoverageDTO proofOfCoverageDTO = getProofOfCoverageData(policyRid, collateral.getRid());
            publishLPIEvent(collateral, proofOfCoverageDTO, CollateralEventType.DELETED, true);

        }
	}

	@Override
	public boolean isWireRefundNeeded(WorkItem workItem) {
		if (workItem != null && workItem instanceof LenderPlaceItem) {
			LenderPlaceItem lenderPlaceItem = (LenderPlaceItem)workItem;
			ProofOfCoverage poc = lenderPlaceItem.getProofOfCoverageForItemType(ProofOfCoverageWorkItemRelationType.LENDERPLACEMENT_TO_POLICY);
			boolean isMigratedPolicy = poc != null ? poc.getMigrated(): false;
			LpInsuranceVendor insuranceVendor = LpInsuranceVendor.findByDisplayName(poc != null ? poc.getInsuranceAgency() : StringUtils.EMPTY);
			// true if migrated policy that was created as Paid policy so it needs a refund (letter cycle never started)
			boolean isMigratedPaidPolicy = isMigratedPolicy && lenderPlaceItem.getFirstLetterDate() == null;
			List<WiredPolicy> wireRequest = wiredPolicyRepository.findByWorkItem(workItem);
			// return False when althans and not migrated-paid and existing wire requests for the lpi is empty
			return !(LpInsuranceVendor.ALTHANS.equals(insuranceVendor) && !isMigratedPaidPolicy && CollectionUtils.isEmpty(wireRequest));
		}
		return false;
	}
}
