package com.jpmorgan.cib.wlt.ctrac.service.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRInsuranceCompanyName;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.bir.BIRInsuranceCompanyNameRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AutoSuggestionsDto;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;



@Component
public class SuggestionsUtil {
	@Autowired private BIRInsuranceCompanyNameRepository insuranceCompanyNameRepository;
	
	 @Autowired private CtracObjectMapper ctracObjectMapper;
		
	public List<AutoSuggestionsDto> getInsuranceCompanyNamesContaining(String searchParam){
		List<AutoSuggestionsDto> filtered = new ArrayList<AutoSuggestionsDto>();
		List<BIRInsuranceCompanyName> result = insuranceCompanyNameRepository.findByActiveOrderByApprovedInsuranceCompanyNameAsc("Y");
		if(searchParam ==null){
			filtered = ctracObjectMapper.mapAsList(result, AutoSuggestionsDto.class);
			return filtered;
		}else{			
			for(BIRInsuranceCompanyName item : result){
				if(item.getApprovedInsuranceCompanyName().toLowerCase().contains(searchParam.toLowerCase())){
					filtered.add(ctracObjectMapper.map(item, AutoSuggestionsDto.class));
				}				
			}
			return filtered;
		}
	}
}
