package com.jpmorgan.cib.wlt.ctrac.service.email.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.EmailDetailsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttributeHolder;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.PrimaryLoanBorrowerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import microsoft.exchange.webservices.data.Importance;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by e704298 on 11/3/2017.
 */
@Service
public class FloodEmailServiceImpl implements FloodEmailService {

    private static final String CTL_LOB_CODE = "CTL"; // this is LoB Code Constant

    @Autowired private EmailSender emailSender;
    @Autowired private Environment env;
    @Autowired private ViewDataRetrievalService viewDataRetrievalService;
    @Autowired private CollateralRepository collateralRepository;
    @Autowired private EmailDetailsRepository emailDetailsRepository;
    @Autowired private LineOfBusinessService  lobService;

    private String WLS_FLOOD_EMAIL;
    private String CTL_FLOOD_EMAIL;

    @PostConstruct
    public void init() {
        WLS_FLOOD_EMAIL = env.getRequiredProperty("from.email.address.flood.service");
        CTL_FLOOD_EMAIL = env.getRequiredProperty("from.email.address.ctl.flood.service");
    }

    @Override
    public void sendEmail(EmailAttributeHolder emailAttributeHolder) {
        updateCcAndFromForCollateral(emailAttributeHolder);
        emailSender.sendEmail(emailAttributeHolder);
    }

    @Override
    public void sendInternalEmailThroughEWS(final EmailAttributeHolder emailAttributeHolder) {
        updateCcAndFromForCollateral(emailAttributeHolder);
        emailSender.sendInternalEmailThroughEWS(emailAttributeHolder, Importance.Normal);
    }

    private void updateCcAndFromForCollateral(EmailAttributeHolder emailAttributeHolder) {
        Set<String> lobCodes = getLobCodes(emailAttributeHolder.getCollateralRids());
        if(StringUtils.isNotBlank(emailAttributeHolder.getWorkItemLob())) {
            lobCodes.add(emailAttributeHolder.getWorkItemLob());
        }
        updateCc(emailAttributeHolder, lobCodes);
        updateFrom(emailAttributeHolder, lobCodes);
    }

    private Set<String> getLobCodes(List<Long> collateralRids) {
        Set<String> lobCodes = new HashSet<>();
        if (collateralRids != null && !collateralRids.isEmpty()) {
            for (Long collateralRid : collateralRids) {
                if (collateralRid == null) {
                    continue;
                }
                PrimaryLoanBorrowerViewDto primaryLoan =
                        viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(collateralRid);

                // LCP-4807
                String lobCode = primaryLoan.getLineOfBusiness();

                LineOfBusinessDTO lob = lobService.findByCode(lobCode);
                if (lob != null) {
                    lobCode = lob.getCodeConst();
                }
                lobCodes.add(lobCode);

            }
        }
        return lobCodes;
    }

    protected void updateFrom(EmailAttributeHolder emailAttributeHolder, Set<String> lobCodes) {
        String fromEmail = null;
        for (String lobCode : lobCodes) {
            if (!CTL_LOB_CODE.equals(lobCode)) {
                // if at least 1 primary loan is non-CTL, use WLS email
                fromEmail = WLS_FLOOD_EMAIL;
                break;
            } else if (fromEmail == null) {
                // use CTL email if ALL primary loans are CTL
                fromEmail = CTL_FLOOD_EMAIL;
            }
        }
        updateFrom(emailAttributeHolder, fromEmail);
    }

    private void updateFrom(EmailAttributeHolder emailAttributeHolder, String servicingEmail) {
        String fromAddress = emailAttributeHolder.getFromAddress();
        if (StringUtils.isNotBlank(fromAddress)) {
            String emailWLS = WLS_FLOOD_EMAIL;
            String emailCTL = CTL_FLOOD_EMAIL;
            if (emailWLS.equals(servicingEmail) && emailCTL.equals(fromAddress) ||
                    emailCTL.equals(servicingEmail) && emailWLS.equals(fromAddress)) {
                emailAttributeHolder.setFromAddress(servicingEmail);
            }
        } else if (StringUtils.isNotBlank(servicingEmail)) {
            emailAttributeHolder.setFromAddress(servicingEmail);
        } else {
            //when coming from researchItem.html there's no lobCodes, defaulting to WLS
            emailAttributeHolder.setFromAddress(WLS_FLOOD_EMAIL);
        }
    }

    protected void updateCc(EmailAttributeHolder emailAttributeHolder, Set<String> lobCodes) {
        for (String lobCode : lobCodes) {
            if (CTL_LOB_CODE.equals(lobCode)) {
                emailAttributeHolder.getCcAddresses().add(CTL_FLOOD_EMAIL);
            } else {
                emailAttributeHolder.getCcAddresses().add(WLS_FLOOD_EMAIL);
            }
        }
    }

    @Override
    public String getCTLFloodEmail() {
        return CTL_FLOOD_EMAIL;
    }

    @Override
    public String getWLSFloodEmail() {
        return WLS_FLOOD_EMAIL;
    }

    @Override
    public String getMarketEmailToAddress(Collateral collateral) {
        if (collateral == null || collateral.getEmailRid() == null) {
            throw new CTracApplicationException("E0117", CtracErrorSeverity.APPLICATION);
        }
        EmailDetails emailDetails = emailDetailsRepository.findOne(collateral.getEmailRid());
        if (emailDetails == null) {
            throw new CTracApplicationException("E0116", CtracErrorSeverity.APPLICATION);
        }
        String marketEmailToAddress = emailDetails.getEmailTo();
        if (CTL_LOB_CODE.equals(collateral.getPreferredLoanLOB())) {

            if (StringUtils.isEmpty(marketEmailToAddress)) {
                marketEmailToAddress = getCTLFloodEmail();
            }

        }
        return marketEmailToAddress;
    }
}
