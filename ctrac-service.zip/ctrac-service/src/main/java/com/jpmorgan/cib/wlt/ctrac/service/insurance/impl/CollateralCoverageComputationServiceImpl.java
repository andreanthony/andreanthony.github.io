package com.jpmorgan.cib.wlt.ctrac.service.insurance.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureBook;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureManager;
import com.jpmorgan.cib.wlt.ctrac.service.helper.coverage.RequiredCoverageUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldService;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.RequiredCoverageService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ActivePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.CollateralCoverageComputationService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl.CoverageComputationRuleBuilder;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterCycleDateService;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.*;

/**
 * @author N595724
 *
 */
@Service("collateralCoverageComputationService")
public class CollateralCoverageComputationServiceImpl implements CollateralCoverageComputationService {

	@Autowired
	private WorkItemRepository workItemRepository;

	@Autowired
	private CollateralWorkItemRepository collateralWorkItemRepository;

	@Autowired
	private PerfectionTaskRepository perfectionTaskRepository;

	@Autowired
	private TaskService taskService;

	@Autowired
	private CollateralRepository collateralRepository;

	@Autowired
	private InsuranceMngtService  insuranceMngtService;

	@Autowired
	private InsurableAssetRepository insurableAssetRepository;

	@Autowired
	private BusinessDayUtil businessDayUtil;

	@Autowired
	ActivePolicyService activePolicyService;

	@Autowired
	ProofOfCoverageRepository proofOfCoverageRepository;

	@Autowired
	BorrowerViewRepository borrowerViewRepository;

	@Autowired
	CtracObjectMapper ctracObjectMapper;

	@Autowired private Environment env;

	@Autowired
	private ViewDataRetrievalService viewDataRetrievalService;

	@Autowired
	private LetterCycleDateService letterCycleDateService;

	@Autowired
	private RequiredCoverageService requiredCoverageService;

	@Autowired
	private FeatureManager featureManager;

	@Autowired
	private HoldService holdService;

	@Autowired
	LoanService loanService;

	private static final Logger logger = Logger.getLogger(CollateralCoverageComputationServiceImpl.class);

	@Override
	@Transactional
	public CoverageActionResult evaluateInsuranceCoverageActions(CoverageActionRequest coverageActionRequest) {


		logger.info("\n Starting the execution of evaluateInsuranceCoverageActions( ) : "+ coverageActionRequest.toString());

		/**
		 * 1 -0
		 * reload transactional entities from the DB to avoid dependency on external transactions
		 */
		WorkItem triggerWorkItem =null;
		Long triggerId = null;
		if(coverageActionRequest.getTriggerWorkItemId()!=null){
			triggerWorkItem = workItemRepository.findOne(coverageActionRequest.getTriggerWorkItemId());
			triggerWorkItem = CtracBaseEntity.deproxy(triggerWorkItem, WorkItem.class);
			if(triggerWorkItem!=null){
				triggerId =triggerWorkItem.getRid();
			}

		}

		Collateral collateral = collateralRepository.findOne(coverageActionRequest.getCollateralId() );
		collateral = CtracBaseEntity.deproxy(collateral, Collateral.class);

		CoverageActionResult globalResults = new CoverageActionResult(collateral.getRid(), triggerId);

		/**
		 * 1 -1
		 *
		 * prepare the rule builder to load collateral based coverage rules
		 */
		final Date today = businessDayUtil.getCurrentReferenceDateAtStartOfDay();
		CoverageComputationRuleBuilder coverageRuleBuilder = new CoverageComputationRuleBuilder(collateral, triggerWorkItem,  today);
		processCollateraLevellRules(coverageActionRequest, globalResults, coverageRuleBuilder);
		/**
		 * some rules tells us we don't need any kind of coverage
		 */
		if(!globalResults.areMoreActionsNeeded()){
			logger.info("\n assert that the collateral is not at risk or no LP action is needed");
			return globalResults;
		}

		/**
		 * 2 -
		 * we need further actions(Insurance coverage needed):
		 * for all the Insurable asset associated to the collateral,
		 * Evaluate the insurable asset level coverage rules
		 */
		List<InsurableAsset> insurableAssetList = insurableAssetRepository.findByBuildingCollateralRid(collateral.getRid());
		final String insuredName = viewDataRetrievalService.getUniqueMortgagorAndBorrowerNames(coverageActionRequest.getCollateralId(), " | ");
		final String floodZone = getVerifiedFloodZone(collateral);

		for (InsurableAsset insurableAsset : insurableAssetList) {
			insurableAsset.setFloodZone(floodZone);
			triggerC3ForInsurableAsset(insurableAsset, coverageRuleBuilder, coverageActionRequest, insuredName, globalResults);
		}

		logger.info(" Succesfull completion of evaluateInsuranceCoverageActions() : "+ coverageActionRequest.toString());
		return globalResults;
	}

	private void processCollateraLevellRules(CoverageActionRequest coverageActionRequest, CoverageActionResult globalResults, CoverageComputationRuleBuilder coverageRuleBuilder) {
		TreeSet<C3Rule> collateralCoverageRules = coverageRuleBuilder.getCollateralBasedCoverageRules();

		/**
		 * 1 - 2
		 *
		 * Apply all the collateral level rules.
		 * Check if we don't need to proceed => the collateral is not at risk (we don't need any kind of insurance coverage);
		 *
		 */
		Iterator<C3Rule> collateralRuleItr = collateralCoverageRules.descendingIterator();
		logger.info("\n Starting the execution of Collateral level Rules : ");
		while(collateralRuleItr.hasNext()){
			C3Rule collaralCovRule  = collateralRuleItr.next();
			logger.info("\n executing rule: "+collaralCovRule.toString());
			collaralCovRule.execute(coverageActionRequest, globalResults);
		}
	}

	private String getVerifiedFloodZone(Collateral collateral) {

		for (FloodDetermination floodDetermination : collateral.getFloodDeterminations()) {
			if(VerificationStatus.VERIFIED.name().equals(floodDetermination.getStatus())) {
				return floodDetermination.getFloodZone();
			}
		}
		return null;
	}

	@Override
	@Transactional
	public CoverageActionResult evaluateInsurableAssetCoverageActions(Long collateralRid, Set<Long> insurableAssetRids, Date overrideCalculatedDate) {

		final Collateral collateral = collateralRepository.findOne(collateralRid);
		final CoverageActionRequest coverageActionRequest = getCoverageActionRequest(collateral.getRid(), overrideCalculatedDate);
		final Date today = businessDayUtil.getCurrentReferenceDateAtStartOfDay();
		final String insuredName = viewDataRetrievalService.getUniqueMortgagorAndBorrowerNames(collateralRid, " | ");
		final String floodZone = getVerifiedFloodZone(collateral);
		CoverageComputationRuleBuilder coverageRuleBuilder = new CoverageComputationRuleBuilder(collateral, null, today);
		CoverageActionResult globalResults = new CoverageActionResult(collateral.getRid(), null);
		processCollateraLevellRules(coverageActionRequest, globalResults, coverageRuleBuilder);
		/**
		 * some rules tells us we don't need any kind of coverage
		 */
		if(!globalResults.areMoreActionsNeeded()){
			logger.info("\n assert that the collateral is not at risk or no LP action is needed");
			return globalResults;
		}
		for (Long insurableAssetRid : insurableAssetRids) {
			final InsurableAsset insurableAsset = insurableAssetRepository.findOne(insurableAssetRid);
			insurableAsset.setFloodZone(floodZone);
			triggerC3ForInsurableAsset(insurableAsset, coverageRuleBuilder, coverageActionRequest, insuredName, globalResults);
		}
		return globalResults;
	}

	protected CoverageActionRequest getCoverageActionRequest(Long collateralRid, Date overrideCalculatedDate) {
		if(overrideCalculatedDate == null) {
			return new CoverageActionRequest(collateralRid, null, null);
		}
		return new CoverageActionRequest(collateralRid, overrideCalculatedDate);
	}

	@Override
	public CoverageActionResult evaluateInsurableAssetCoverageActions(Long collateralRid, Set<Long> insurableAssetRids) {
		return evaluateInsurableAssetCoverageActions(collateralRid, insurableAssetRids, null);
	}

	private void triggerC3ForInsurableAsset(InsurableAsset insurableAsset,
											CoverageComputationRuleBuilder coverageRuleBuilder,
											CoverageActionRequest coverageActionRequest, String insuredName, CoverageActionResult globalResults) {
		/**
		 * 2-0
		 * reset the rules break condition since it a "per insurable asset break"
		 * mean we can decide to stop the execution for one insurable asset and move
		 * to the next when the break condition is true;
		 */
		globalResults.setMoreActionsNeeded(true);

		/**
		 * 2 - 1
		 * prepare the data needed to invoke the insurable asset based rules
		 */
		CoverageActionData coverageActionData = getCoverageActionData(coverageActionRequest, null, insurableAsset, insuredName);

		logger.info("\n computated the insurable asset coveraga status  : "+ coverageActionData.toString());

		/**
		 * 2 - 2
		 *  prepare the rules builder to generate insurable asset based rules specific to our
		 *  insurable asset
		 */
		coverageRuleBuilder.withInsurableAsset(insurableAsset);

		/**
		 * 2-3 (load and apply the insurable asset based rules)
		 *
		 * for each insurable asset belonging to the collateral, evaluate how much
		 * coverage need to be issue; what LP policies should be cancel, as well as
		 * the policies which are expired but with status not yet persisted in the DB
		 */
		TreeSet<C3Rule> issurableAssetCoverageRules = coverageRuleBuilder.getInsurableAssetBasedCoverageRules(coverageActionData);
		Iterator<C3Rule> insurableAssetCoverageRulesIter = issurableAssetCoverageRules.descendingIterator();

		logger.info("\n Starting the execution of Insurable asset level coverage Rules : ");
		while (insurableAssetCoverageRulesIter.hasNext()) {
			C3Rule insurableAssetRule = insurableAssetCoverageRulesIter.next();
			logger.info("\n executing rule: " + insurableAssetRule.toString());
			insurableAssetRule.execute(coverageActionRequest, globalResults);
			if (!globalResults.areMoreActionsNeeded()) {
				break;
			}
		}
	}

	@Override
	@Transactional(readOnly = false)
	public void applyInsuranceCoverageActions(CoverageActionResult coverageActionResults , WorkItem triggerWorkItem ) {
		Long collateralId = coverageActionResults.getCollateralId();

		Long triggerWorkItemId = triggerWorkItem != null ? triggerWorkItem.getRid() : null;
		logger.debug("collateralId=" + collateralId + ",triggerWorkItemId=" + triggerWorkItemId +
				", rollback=" + TransactionInterceptor.currentTransactionStatus().isRollbackOnly());
		// has to be done first so it aborts only existing workflows, and not those created in the following steps
		abortWorkflows(coverageActionResults);
		logger.debug("completed abortWorkflows, rollback=" + TransactionInterceptor.currentTransactionStatus().isRollbackOnly());

		insuranceMngtService.initiateLenderPlaceWorkflow(coverageActionResults, triggerWorkItem);
		logger.debug("completed initiateLenderPlaceWorkflow, rollback=" + TransactionInterceptor.currentTransactionStatus().isRollbackOnly());

		insuranceMngtService.initiateLPCancellationWorkflow(coverageActionResults, triggerWorkItem);
		logger.debug("completed initiateLPCancellationWorkflow, rollback=" + TransactionInterceptor.currentTransactionStatus().isRollbackOnly());

		insuranceMngtService.initiateLPUpdateWorkflow(coverageActionResults, triggerWorkItem);
		logger.debug("completed initiateLPUpdateWorkflow, rollback=" + TransactionInterceptor.currentTransactionStatus().isRollbackOnly());

		completeWorkflowAwaitingOperations(coverageActionResults);
		logger.debug("completed completeWorkflowAwaitingOperations, rollback=" + TransactionInterceptor.currentTransactionStatus().isRollbackOnly());

		insuranceMngtService.deleteProvidedCoverages(coverageActionResults);
		logger.debug("completed deletePolicies, rollback=" + TransactionInterceptor.currentTransactionStatus().isRollbackOnly());

	}

	/**
	 *
	 * @param coverageActionRequest
	 * @param triggerWorkItem
	 * @param insurableAsset
	 * @param insuredName
	 * @return
	 */
	private CoverageActionData getCoverageActionData(CoverageActionRequest coverageActionRequest,
													 WorkItem triggerWorkItem, InsurableAsset insurableAsset, String insuredName){

		CoverageActionData coverageActionData = new CoverageActionData(insurableAsset.getRid());
		coverageActionData.setInsurableAsset(insurableAsset);

		final Date today = businessDayUtil.getCurrentReferenceDateAtStartOfDay();
		coverageActionData.today(today);
		final Date nextBusinessDay = businessDayUtil.getNextBusinessDate(today);
		coverageActionData.nextBusinessDay(nextBusinessDay);
		final Date fourtySixthDay = CalendarDayUtil.addCalendarDays(45, nextBusinessDay);
		coverageActionData.fourtySixthDay(fourtySixthDay);
		final Date maxDateForLetterProcessing = letterCycleDateService.getMaxDateForLetterProcessing(today);
		coverageActionData.maxDateForLetterProcessing(maxDateForLetterProcessing);

		RequiredCoverage requiredCoverage = RequiredCoverageUtil.getValidCoverageRequirement(insurableAsset, coverageActionRequest.getInsuranceType());
		coverageActionData.setRequiredCoverage(CtracBaseEntity.deproxy(requiredCoverage, RequiredCoverage.class));

		logger.info(" \n Begin findActivePoliciesByInsurableAssetRid()");
		Collection<ProofOfCoverage> allActivePolicies =
				activePolicyService.findActivePoliciesByInsurableAssetRid(insurableAsset.getRid(), null, null, true);
		coverageActionData.allActivePolicies(allActivePolicies);
		logger.info(" \n End findActivePoliciesByInsurableAssetRid()");

		coverageActionData.allProvidedCoverages(insurableAsset.getProvidedCoverages());

		Long cancelledRorrowerProofOfCoverageRid = coverageActionRequest.getCancelledRorrowerProofOfCoverageRid();
		if(cancelledRorrowerProofOfCoverageRid != null) {
			coverageActionData.setCancelledBorrowerPolicy(proofOfCoverageRepository.findOne(cancelledRorrowerProofOfCoverageRid));
		}
		logger.info(" \n End setCancelledBorrowerPolicy()");
		Collection<ProvidedCoverage> allActiveProvidedCoverages =
				activePolicyService.findActiveCoverages(insurableAsset.getRid(), null, null, true);
		coverageActionData.allActiveProvidedCoverages(allActiveProvidedCoverages);
		logger.info(" \n End findActiveCoverages()");

		coverageActionData.setPreviousRequiredCoveragesForCollateral(requiredCoverageService.getLatestInactiveRequiredCoverages(insurableAsset.getBuilding().getCollateral().getRid()));
		logger.info(" \n End getLatestInactiveRequiredCoverages()");

		coverageActionData.insuredName(insuredName);
		try {
			coverageActionData.setTriggerProofOfCoverage(coverageActionRequest.getTriggerProofOfCoverage());
			if (coverageActionData.getTriggerProofOfCoverage() != null && PolicyType.isLenderPlace(coverageActionData.getTriggerProofOfCoverage().getPolicyType())) {
				Date autoRenewalCutOffDate = DateFormatter.parseDate(env.getProperty("assurant.auto.renewal.cutoff.date"));
				boolean isPreRenewalLetterSent = !coverageActionData.getTriggerProofOfCoverage().getExpirationDate().before(autoRenewalCutOffDate);
				coverageActionData.setPreRenewalLetterSent(isPreRenewalLetterSent);
			}
		}
		catch (ParseException e) {
			logger.error(e.getMessage());
		}
		logger.info(" \n End autoRenewalCutOffDate");

		if(requiredCoverage != null) {
			coverageActionData.populateHolds(requiredCoverage.getPrimaryHold(), requiredCoverage.getExcessHold());
		}
		coverageActionData.setExternallyAgented(loanService.hasExternallyAgented(coverageActionRequest.getCollateralId()));
		logger.info(" \n End getCoverageActionData()");

		return coverageActionData;
	}

	/**
	 * Return the sum of coverage pending review as per the BIR
	 * @param coverageActionRequest
	 * @param triggerWorkItem
	 * @param insurableAsset
	 * @return
	 */

	BigDecimal getCoverageAmountPendingReviewValidOn(CoverageActionRequest coverageActionRequest,
													 WorkItem triggerWorkItem, InsurableAsset insurableAsset, Date refDate) {

		BigDecimal result = new BigDecimal(0);

		//TODO FIXME implements
		//if trigger is of type borrowr review
		if( true){
			List<ProofOfCoverageDTO> cov = coverageActionRequest.getProofOfCoveragePendingReviews();

			//...TODO implements:
			//TODO make sure only policies with effective day(or prior) are accounted today and expiration day
		}
		return result;
	}




	BigDecimal getRequiredCoverageAmount(InsurableAsset insurableAsset,
										 InsuranceType insuranceType){

		//1 is the asset a building or content?
		/*LPConstants lpCoverageType = InsurableAssetDtoUtil.getFloodLPCoverageType(insurableAsset);

        // get the latest required coverage from any source
        BigDecimal requiredCoverageAmount = floodRemapVendorMinMaxRules.getLpVendorAdjustedCoverageAmount(
                RequiredCoverageUtil.getValidCoverageRequirementAmount(insurableAsset, insuranceType), lpCoverageType);*/

		/**
		 * Do not apply the above vendor min and max until C3 calculation!
		 */
		BigDecimal requiredCoverageAmount =
				RequiredCoverageUtil.getValidCoverageRequirementAmount(insurableAsset, insuranceType);

		return requiredCoverageAmount;
	}

	void abortWorkflows(CoverageActionResult coverageActionResults) {

		Set<Long> workItemIds = coverageActionResults.getWorkFlowToCancel();
		if(workItemIds==null ||workItemIds.isEmpty()){
			return;
		}

		for(Long workItemId:workItemIds){
			logger.debug("aborting workflow=" + workItemId);
			WorkItem workItem = workItemRepository.findOne(workItemId);
			// if workItem is related to multiple collaterals, just remove the collateral from the work item
			List<CollateralWorkItem> collateralWorkItems = workItem.getCollateralWorkItems();
			if(collateralWorkItems == null  || collateralWorkItems.size() == 1)	{
				Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();

				inputParameterMap.put(StateParameterType.WORK_ITEM, workItem);

				taskService.abortWorkflow(inputParameterMap, "Insurance coverage requirement changed: "+coverageActionResults.getDetails());
			}
			else {
				CollateralWorkItem collateralWorkItemToRemove = workItem.getCollateralWorkItem(coverageActionResults.getCollateralId());
				collateralWorkItems.remove(collateralWorkItemToRemove);
				collateralWorkItemRepository.delete(collateralWorkItemToRemove);
			}
		}
	}

	void completeWorkflowAwaitingOperations(CoverageActionResult coverageActionResults) {

		Set<Long> awaitingTasks = coverageActionResults.getPerfectionTaskToAdvance();
		if(awaitingTasks==null ||awaitingTasks.isEmpty()){
			return;
		}
		for(Long perfectionTaskId : awaitingTasks){
			logger.debug("advancing workflow=" + perfectionTaskId);
			PerfectionTask  perfectionTask = perfectionTaskRepository.findOne(perfectionTaskId);

			Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();

			inputParameterMap.put(StateParameterType.PERFECTION_TASK, perfectionTask);

			taskService.completeWorkFlowStepOperations(inputParameterMap);
		}
	}




}
