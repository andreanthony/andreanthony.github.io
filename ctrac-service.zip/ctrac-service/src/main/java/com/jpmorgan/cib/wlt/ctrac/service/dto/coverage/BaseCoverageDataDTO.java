package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.AmountFormatter;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.math.BigDecimal;


public abstract class BaseCoverageDataDTO extends BaseDto implements Cloneable {

	private static final long serialVersionUID = 1L;
    private static final Logger logger = Logger.getLogger(BaseCoverageDataDTO.class);

    private InsurableAssetDTO insurableAssetDTO;

    private String propertyType;

	private Boolean hadSomeCoverage = false;

    private CoverageDetailsDTO coverageDetailsDTO;

    private CoverageDetailsDTO primaryCoverageDetailsDto;

    private CoverageDetailsDTO excessCoverageDetailsDto;

    private String totalCoverageAmount;
    private BaseCoverageDataDTO loadTimeValue;

    public String getPrimaryCoverageAmount() {
        if (primaryCoverageDetailsDto != null) {
            return primaryCoverageDetailsDto.getCoverageAmount();
        }
        return null;
    }

    public void setPrimaryCoverageAmount(String coverageAmount) {
        if (primaryCoverageDetailsDto == null) {
        	primaryCoverageDetailsDto = new CoverageDetailsDTO();
        }
        primaryCoverageDetailsDto.setCoverageAmount(coverageAmount);
    }

    public String getExcessCoverageAmount() {
        if (excessCoverageDetailsDto != null) {
            return excessCoverageDetailsDto.getCoverageAmount();
        }
        return null;
    }

    public void setExcessCoverageAmount(String coverageAmount) {
        if (excessCoverageDetailsDto == null) {
        	excessCoverageDetailsDto = new CoverageDetailsDTO();
        }
        excessCoverageDetailsDto.setCoverageAmount(coverageAmount);
    }

    public String getPrimaryCoverageValue() {
        if (primaryCoverageDetailsDto != null) {
            return primaryCoverageDetailsDto.getCoverageValue();
        }
        return null;
    }

    public void setPrimaryCoverageValue(String coverageValue) {
        if (primaryCoverageDetailsDto == null) {
        	primaryCoverageDetailsDto = new CoverageDetailsDTO();
        }
        primaryCoverageDetailsDto.setCoverageValue(coverageValue);
    }

    public void setPrimaryValueBalanceType(String balanceType) {
        if (primaryCoverageDetailsDto == null) {
            primaryCoverageDetailsDto = new CoverageDetailsDTO();
        }
        primaryCoverageDetailsDto.setBuildingContentBalanceType(balanceType);
    }

    public String getExcessCoverageValue() {
        if (excessCoverageDetailsDto != null) {
            return excessCoverageDetailsDto.getCoverageValue();
        }
        return null;
    }

    public void setExcessCoverageValue(String coverageValue) {
        if (excessCoverageDetailsDto == null) {
        	excessCoverageDetailsDto = new CoverageDetailsDTO();
        }
        excessCoverageDetailsDto.setCoverageValue(coverageValue);
    }

    public void setExcessValueBalanceType(String balanceType) {
        if (excessCoverageDetailsDto == null) {
            excessCoverageDetailsDto = new CoverageDetailsDTO();
        }
        excessCoverageDetailsDto.setBuildingContentBalanceType(balanceType);
    }


    public boolean hasNonZeroPrimaryCoverage() {
    	try {
	    	return BigDecimal.ZERO.compareTo(AmountFormatter.parse(primaryCoverageDetailsDto.getCoverageAmount())) < 0;
    	} catch (Exception e) {
    		return false;
    	}
    }

    public boolean hasNonZeroExcessCoverage() {
    	try {
	    	return BigDecimal.ZERO.compareTo(AmountFormatter.parse(excessCoverageDetailsDto.getCoverageAmount())) < 0;
    	} catch (Exception e) {
    		return false;
    	}
    }

    public String getPrimaryCoverageType() {
    	return primaryCoverageDetailsDto.getCoverageType();
    }

    public void setPrimaryCoverageType(String coverageType) {
    	primaryCoverageDetailsDto.setCoverageType(coverageType);
    }

    public String getExcessCoverageType() {
    	return excessCoverageDetailsDto.getCoverageType();
    }

    public void setExcessCoverageType(String coverageType) {
    	excessCoverageDetailsDto.setCoverageType(coverageType);
    }

    public String getOrginalPrimaryCoverageAmount() {
        return this.getPrimaryCoverageDetailsDto().getOrginalCoverageAmount();
    }

    public void setOrginalPrimaryCoverageAmount(String orginalCoverageAmount) {
        this.getPrimaryCoverageDetailsDto().setOrginalCoverageAmount(orginalCoverageAmount);
    }

    public String getOrginalPrimaryCoverageValue() {
        return this.getPrimaryCoverageDetailsDto().getOrginalCoverageValue();
    }

    public void setOrginalPrimaryCoverageValue(String orginalCoverageValue) {
        this.getPrimaryCoverageDetailsDto().setOrginalCoverageValue(orginalCoverageValue);
    }

    public String getOrginalPrimaryBalanceType() {
        return this.getPrimaryCoverageDetailsDto().getOrginalBalanceType();
    }

    public void setOrginalPrimaryBalanceType(String orginalBalanceType) {
        this.getPrimaryCoverageDetailsDto().setOrginalBalanceType(orginalBalanceType);
    }

    public String getOrginalExecessCoverageAmount() {
        return this.getExcessCoverageDetailsDto().getOrginalCoverageAmount();
    }

    public void setOrginalExcessCoverageAmount(String orginalCoverageAmount) {
        this.getExcessCoverageDetailsDto().setOrginalCoverageAmount(orginalCoverageAmount);
    }

    public String getOrginalExecessCoverageValue() {
        return this.getExcessCoverageDetailsDto().getOrginalCoverageValue();
    }

    public void setOrginalExcessCoverageValue(String orginalCoverageValue) {
        this.getExcessCoverageDetailsDto().setOrginalCoverageValue(orginalCoverageValue);
    }

    public String getOrginalExcessBalanceType() {
        return this.getExcessCoverageDetailsDto().getOrginalBalanceType();
    }

    public void setOrginalExcessBalanceType(String orginalBalanceType) {
        this.getExcessCoverageDetailsDto().setOrginalBalanceType(orginalBalanceType);
    }


    public String getVerifyPrimaryCovAmountPriorMissMatch() {
        return  this.getPrimaryCoverageDetailsDto().getVerifyCovAmountPriorMissMatch();
    }

    public void setVerifyPrimaryCovAmountPriorMissMatch(String verifyAmountPriorMissMatch) {
        this.getPrimaryCoverageDetailsDto().setVerifyCovAmountPriorMissMatch(verifyAmountPriorMissMatch);
    }

    public String getVerifyPrimaryBalanceTypePriorMissMatch() {
        return  this.getPrimaryCoverageDetailsDto().getVerifyBalanceTypePriorMissMatch();
    }

    public void setVerifyPrimaryBalanceTypePriorMissMatch(String verifyBalanceTypePriorMissMatch) {
        this.getPrimaryCoverageDetailsDto().setVerifyBalanceTypePriorMissMatch(verifyBalanceTypePriorMissMatch);
    }

    public String getVerifyExecssCovAmountPriorMissMatch() {
        return  this.getExcessCoverageDetailsDto().getVerifyCovAmountPriorMissMatch();
    }

    public void setVerifyExcessCovAmountPriorMissMatch(String verifyAmountPriorMissMatch) {
        this.getExcessCoverageDetailsDto().setVerifyCovAmountPriorMissMatch(verifyAmountPriorMissMatch);
    }

    public String getVerifyExecssBalanceTypePriorMissMatch() {
        return  this.getExcessCoverageDetailsDto().getVerifyBalanceTypePriorMissMatch();
    }

    public void setVerifyExcessBalanceTypePriorMissMatch(String verifyBalanceTypePriorMissMatch) {
        this.getExcessCoverageDetailsDto().setVerifyBalanceTypePriorMissMatch(verifyBalanceTypePriorMissMatch);
    }

    public Boolean hasVerifyPrimaryCovMissMatch(){
        return (this.getPrimaryCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        		this.getPrimaryCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        		this.getPrimaryCoverageDetailsDto().isVerificationBalanceTypeMissMatch() ||
        		this.getPrimaryCoverageDetailsDto().isVerificationValueBalanceTypeMissMatch());
    }

    public Boolean hasVerifyPrimaryCoverageAmountMissMatch(){
        return this.getPrimaryCoverageDetailsDto().isVerificationCoverageAmountMissMatch();
    }

    public Boolean hasVerifyPrimaryCoverageValueMissMatch(){
        return this.getPrimaryCoverageDetailsDto().isVerificationCoverageValueMissMatch();
    }

    public Boolean hasVerifyPrimaryBalanceTypeMissMatch(){
        return this.getPrimaryCoverageDetailsDto().isVerificationBalanceTypeMissMatch();
    }

    public Boolean hasVerifyPrimaryValueBalanceTypeMissMatch(){
        return this.getPrimaryCoverageDetailsDto().isVerificationValueBalanceTypeMissMatch();
    }


    public Boolean hasVerifyExcessCovMissMatch(){
        return (this.getExcessCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        		this.getExcessCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        		this.getExcessCoverageDetailsDto().isVerificationBalanceTypeMissMatch() ||
        		this.getExcessCoverageDetailsDto().isVerificationValueBalanceTypeMissMatch());
    }

    public Boolean hasVerifyExcessCoverageAmountMissMatch(){
        return this.getExcessCoverageDetailsDto().isVerificationCoverageAmountMissMatch();
    }

    public Boolean hasVerifyExcessCoverageValueMissMatch(){
        return this.getExcessCoverageDetailsDto().isVerificationCoverageValueMissMatch();
    }

    public Boolean hasVerifyExcessBalanceTypeMissMatch(){
        return this.getExcessCoverageDetailsDto().isVerificationBalanceTypeMissMatch();
    }

    public Boolean hasVerifyExcessValueBalanceTypeMissMatch(){
        return this.getExcessCoverageDetailsDto().isVerificationValueBalanceTypeMissMatch();
    }

	public CoverageDetailsDTO getPrimaryCoverageDetailsDto() {
		return primaryCoverageDetailsDto;
	}

	public void setPrimaryCoverageDetailsDto(CoverageDetailsDTO primaryCoverageDetailsDto) {
		this.primaryCoverageDetailsDto = primaryCoverageDetailsDto;
	}

	public CoverageDetailsDTO getExcessCoverageDetailsDto() {
		return excessCoverageDetailsDto;
	}

	public void setExcessCoverageDetailsDto(CoverageDetailsDTO excessCoverageDetailsDto) {
		this.excessCoverageDetailsDto = excessCoverageDetailsDto;
	}



    public String getCoverageAmount() {
        if (coverageDetailsDTO != null) {
            return coverageDetailsDTO.getCoverageAmount();
        }
        return null;
    }


    public void setCoverageAmount(String coverageAmount) {
        if (coverageDetailsDTO == null) {
        	coverageDetailsDTO = new CoverageDetailsDTO();
        }
        coverageDetailsDTO.setCoverageAmount(coverageAmount);
    }

    public String getCoverageValue() {
        if (coverageDetailsDTO != null) {
            return coverageDetailsDTO.getCoverageValue();
        }
        return null;
    }


    public void setCoverageValue(String coverageValue) {
        if (coverageDetailsDTO == null) {
        	coverageDetailsDTO = new CoverageDetailsDTO();
        }
        coverageDetailsDTO.setCoverageValue(coverageValue);
    }

	public CoverageDetailsDTO getCoverageDetailsDTO() {
		return coverageDetailsDTO;
	}


	public void setCoverageDetailsDTO(CoverageDetailsDTO coverageDetailsDTO) {
		this.coverageDetailsDTO = coverageDetailsDTO;
	}

    public String getOrginalCoverageAmount() {
        return this.getCoverageDetailsDTO().getOrginalCoverageAmount();
    }

    public void setOrginalCoverageAmount(String orginalCoverageAmount) {
        this.getCoverageDetailsDTO().setOrginalCoverageAmount(orginalCoverageAmount);
    }

    public String getOrginalCoverageValue() {
        return this.getCoverageDetailsDTO().getOrginalCoverageValue();
    }

    public void setOrginalCoverageValue(String orginalCoverageValue) {
        this.getCoverageDetailsDTO().setOrginalCoverageAmount(orginalCoverageValue);
    }

    public String getOrginalBalanceType() {
        return this.getCoverageDetailsDTO().getOrginalBalanceType();
    }

    public void setOrginalBalanceType(String orginalBalanceType) {
        this.getCoverageDetailsDTO().setOrginalBalanceType(orginalBalanceType);
    }

    public String getVerifyCovAmountPriorMissMatch() {
        return  this.getCoverageDetailsDTO().getVerifyCovAmountPriorMissMatch();
    }

    public void setVerifyCovAmountPriorMissMatch(String verifyAmountPriorMissMatch) {
        this.getCoverageDetailsDTO().setVerifyCovAmountPriorMissMatch(verifyAmountPriorMissMatch);
    }

    public String getVerifyBalanceTypePriorMissMatch() {
        return  this.getCoverageDetailsDTO().getVerifyBalanceTypePriorMissMatch();
    }

    public void setVerifyBalanceTypePriorMissMatch(String verifyBalanceTypePriorMissMatch) {
        this.getCoverageDetailsDTO().setVerifyBalanceTypePriorMissMatch(verifyBalanceTypePriorMissMatch);
    }

    public boolean hasNonZeroCoverage() {
    	try {
	    	return BigDecimal.ZERO.compareTo(AmountFormatter.parse(coverageDetailsDTO.getCoverageAmount())) < 0;
    	} catch (Exception e) {
    		return false;
    	}
    }

    public String getCoverageType() {
    	return coverageDetailsDTO.getCoverageType();
    }

    public void setCoverageType(String coverageType) {
    	coverageDetailsDTO.setCoverageType(coverageType);
    }


    public InsurableAssetDTO getInsurableAssetDTO() {
        return insurableAssetDTO;
    }

    public void setInsurableAssetDTO(InsurableAssetDTO insurableAssetDTO) {
        this.insurableAssetDTO = insurableAssetDTO;
    }

    public String getDescription() {
        if (insurableAssetDTO != null) {
            return insurableAssetDTO.getDescription();
        }
        return null;
    }

    public Integer getSortOrder() {
        if (insurableAssetDTO != null) {
            return insurableAssetDTO.getSortOrder();
        }
        return null;
    }

    public void setSortOrder(Integer sortOrder) {
        if (insurableAssetDTO != null) {
            insurableAssetDTO.setSortOrder(sortOrder);
        }
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

	public Boolean getHadSomeCoverage() {
		return hadSomeCoverage;
	}

	public void setHadSomeCoverage(Boolean hadSomeCoverage) {
		this.hadSomeCoverage = hadSomeCoverage;
	}

	public void setTotalCoverageAmount(String totalCoverageAmount) {
		this.totalCoverageAmount = totalCoverageAmount;
	}

	public String getTotalCoverageAmount() {
		BigDecimal primaryAmount = new BigDecimal(0);
		BigDecimal excessAmount= new BigDecimal(0);
		String totalAmount = "";

		if (primaryCoverageDetailsDto != null && primaryCoverageDetailsDto.getCoverageAmount() != null) {
			primaryAmount = AmountFormatter.parse(primaryCoverageDetailsDto.getCoverageAmount());
		}

		if (excessCoverageDetailsDto != null && excessCoverageDetailsDto.getCoverageAmount() != null) {
			excessAmount = AmountFormatter.parse(excessCoverageDetailsDto.getCoverageAmount());
		}

		totalAmount = AmountFormatter.format(primaryAmount.add(excessAmount));

		return (totalAmount);
	}

    public void saveACopy () {
        try {
            this.loadTimeValue = this.clone();
        } catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
        }
    }


    public BaseCoverageDataDTO clone() throws CloneNotSupportedException {
        return (BaseCoverageDataDTO) super.clone();
    }

    public boolean hasChanged() {
        if(this.loadTimeValue ==null || this.getRid()==null){
            return true;
        }

        return !this.deepEquals(this.loadTimeValue);
    }

    public BaseCoverageDataDTO getLoadTimeValue() {
        return this.loadTimeValue;
    }

    private boolean deepEquals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        BaseCoverageDataDTO other = (BaseCoverageDataDTO) obj;
        if (!StringUtils.equals(propertyType, other.propertyType)) {
            return false;
        }
        return true;
    }

}
