package com.jpmorgan.cib.wlt.ctrac.service.helper;

import java.io.IOException;
import java.util.Scanner;
import org.springframework.web.multipart.MultipartFile;

public class PDFChecker {
	
	/**
	 * 	checks if a file is a valid pdf file: the first line should start with %PDF-
	 * @param multipart
	 * @return boolean
	 * @throws IOException
	 */
	public static boolean isPDF(MultipartFile multipart) throws IOException {
		
	    Scanner input = new Scanner(multipart.getInputStream());
	    boolean isPdf = false;
	    if (input.hasNextLine()) {
		    final String checkline = input.nextLine();
		    if(checkline.contains("%PDF-")) { 
		    	isPdf = true;
		    }  
	    }
	    input.close();
	    return isPdf;
	}
}
