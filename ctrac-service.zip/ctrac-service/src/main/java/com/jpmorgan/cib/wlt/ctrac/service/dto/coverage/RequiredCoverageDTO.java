package com.jpmorgan.cib.wlt.ctrac.service.dto.coverage;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsuranceType;
import org.apache.log4j.Logger;

import java.io.Serializable;


public class RequiredCoverageDTO  extends BaseCoverageDataDTO implements Serializable,  Cloneable {

    private static final long serialVersionUID = -7527889873160449903L;
	private static final Logger logger = Logger.getLogger(RequiredCoverageDTO.class);

    private Long rid;

    private RequiredCoverageSourceDto  requiredCoverageSourceDto;

    private String isDescoped;

    private RequiredCoverageDTO loadTimeValue;

    private HoldDTO primaryHold;

    private HoldDTO excessHold;

 	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public RequiredCoverageSourceDto getRequiredCoverageSourceDto() {
		return requiredCoverageSourceDto;
	}

	public void setRequiredCoverageSourceDto(RequiredCoverageSourceDto requiredCoverageSourceDto) {
		this.requiredCoverageSourceDto = requiredCoverageSourceDto;
	}

	public String getIsDescoped() {
		return isDescoped;
	}

	public void setIsDescoped(String isDescoped) {
		this.isDescoped = isDescoped;
	}

	public RequiredCoverageDTO getLoadTimeValue() {
		return loadTimeValue;
	}

	public void setLoadTimeValue(RequiredCoverageDTO loadTimeValue) {
		this.loadTimeValue = loadTimeValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RequiredCoverageDTO other = (RequiredCoverageDTO) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

	private boolean deepEquals(Object obj){
		if(this == obj) {
			return true;
		}
		if(obj == null) {
			return false;
		}
		if(getClass() != obj.getClass()) {
			return false;
		}
		RequiredCoverageDTO other = (RequiredCoverageDTO) obj;
		if(getPrimaryCoverageDetailsDto() == null){
			if(other.getPrimaryCoverageDetailsDto()!=null)
				return false;
		}else if(!getPrimaryCoverageDetailsDto().equals(other.getPrimaryCoverageDetailsDto()))
			return false;
		if(getExcessCoverageDetailsDto() == null){
			if(other.getExcessCoverageDetailsDto()!=null)
				return false;
		}else if(!getExcessCoverageDetailsDto().equals(other.getExcessCoverageDetailsDto()))
			return false;

		if (getInsurableAssetDTO() == null) {
			if (other.getInsurableAssetDTO() != null)
				return false;
		} else if (!getInsurableAssetDTO().equals(other.getInsurableAssetDTO()))
			return false;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;

		return true;
	}

	public boolean hasChanged() {
		return getPrimaryCoverageDetailsDto().hasChanged()|| getExcessCoverageDetailsDto().hasChanged()
				|| (getPrimaryHold()!=null &&getPrimaryHold().hasChanged()) ||
				(getExcessHold()!=null && getExcessHold().hasChanged());
	}

	public void saveACopy() {
		try {
			if(getPrimaryCoverageDetailsDto()!=null) {
				getPrimaryCoverageDetailsDto().saveACopy();
			}
			if(getExcessCoverageDetailsDto()!=null) {
				getExcessCoverageDetailsDto().saveACopy();
			}
			if(getPrimaryHold()!=null) {
				getPrimaryHold().saveACopy();
			}
			if(getExcessHold()!=null) {
				getExcessHold().saveACopy();
			}
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException e) {
            logger.error(e.getMessage(), e);
        }
	}

	@Override
	public RequiredCoverageDTO clone() throws CloneNotSupportedException {
		return (RequiredCoverageDTO) super.clone();
	}

	public RequiredCoverageDTO copyAndResetCoverageDetail(){
		RequiredCoverageDTO clone = null;
		try{
			CoverageDetailsDTO primaryCoverageDetailsDTO = this.getPrimaryCoverageDetailsDto().clone();
			primaryCoverageDetailsDTO.setCoverageAmount(null);
			CoverageDetailsDTO excessCoverageDetailsDTO = this.getExcessCoverageDetailsDto().clone();
			excessCoverageDetailsDTO.setCoverageAmount(null);
			clone = (RequiredCoverageDTO)super.clone();
			clone.setPrimaryCoverageDetailsDto(primaryCoverageDetailsDTO);
			clone.setExcessCoverageDetailsDto(excessCoverageDetailsDTO);

		} catch (CloneNotSupportedException e) {
		    logger.error(e.getMessage(), e);
        }
		return clone;
	}

	//added for LCP-3555
	public static RequiredCoverageDTO Build(InsurableAssetDTO insurableAssetDTO,CoverageDetailsDTO primaryCoverageDetailsDTO,
			CoverageDetailsDTO excessCoverageDetailsDTO) {
		if(primaryCoverageDetailsDTO == null){
			primaryCoverageDetailsDTO = new CoverageDetailsDTO();
			primaryCoverageDetailsDTO.setCoverageType(InsuranceType.FLOOD.name());
		}
		if(excessCoverageDetailsDTO == null){
			excessCoverageDetailsDTO = new CoverageDetailsDTO();
			excessCoverageDetailsDTO.setCoverageType(InsuranceType.FLOOD.name());
		}

		RequiredCoverageDTO newCoverageReqDto = new RequiredCoverageDTO();
		newCoverageReqDto.setInsurableAssetDTO(insurableAssetDTO);
		insurableAssetDTO.addRequiredCoverage(newCoverageReqDto);
		newCoverageReqDto.setPrimaryCoverageDetailsDto(primaryCoverageDetailsDTO);
		newCoverageReqDto.setExcessCoverageDetailsDto(excessCoverageDetailsDTO);

		return newCoverageReqDto;
	}

    public static RequiredCoverageDTO Build(InsurableAssetDTO insurableAssetDTO, CoverageDetailsDTO primaryCoverageDetailsDTO,
                                            CoverageDetailsDTO excessCoverageDetailsDTO, HoldDTO primaryHold, HoldDTO excessHold) {
	    primaryCoverageDetailsDTO.setHoldDTO(primaryHold);
	    excessCoverageDetailsDTO.setHoldDTO(excessHold);
        RequiredCoverageDTO requiredCoverageDTO = Build(insurableAssetDTO, primaryCoverageDetailsDTO, excessCoverageDetailsDTO);
        requiredCoverageDTO.setPrimaryHold(primaryHold);
        requiredCoverageDTO.setExcessHold(excessHold);
        return requiredCoverageDTO;
    }

    public Boolean hasVerifyCovMissMatch(){
        if (getPrimaryCoverageDetailsDto() != null &&
        		(getPrimaryCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        				getPrimaryCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        				getPrimaryCoverageDetailsDto().isVerificationBalanceTypeMissMatch() ||
        				getPrimaryCoverageDetailsDto().isVerificationValueBalanceTypeMissMatch())) {
            return true;
        }
        return getExcessCoverageDetailsDto() != null &&
        		(getExcessCoverageDetailsDto().isVerificationCoverageAmountMissMatch() ||
        				getExcessCoverageDetailsDto().isVerificationCoverageValueMissMatch() ||
        				getExcessCoverageDetailsDto().isVerificationBalanceTypeMissMatch() ||
        				getExcessCoverageDetailsDto().isVerificationValueBalanceTypeMissMatch());
    }

    public HoldDTO getPrimaryHold() {
        if(primaryHold != null) {
            primaryHold.setCoverageType(CoverageType.PRIMARY);
        }
        return primaryHold;
    }

    public void setPrimaryHold(HoldDTO primaryHold) {
        this.primaryHold = primaryHold;
    }

    public HoldDTO getExcessHold() {
        if(excessHold != null) {
            excessHold.setCoverageType(CoverageType.EXCESS);
        }
        return excessHold;
    }

    public void setExcessHold(HoldDTO excessHold) {
        this.excessHold = excessHold;
    }

    public boolean hasNewHold() {
        return (primaryHold != null && primaryHold.isNewVerifiedHold()) ||
                (excessHold != null && excessHold.isNewVerifiedHold());
    }

	public Long deleteNotRequiredHold(CoverageDetailsDTO coverageDetailsDTO) {
		Long holdToDelete = null;
		if(coverageDetailsDTO != null && coverageDetailsDTO.getHoldDTO() != null &&
				!coverageDetailsDTO.getHoldDTO().isRequired()) {
			if(CoverageType.PRIMARY == coverageDetailsDTO.getHoldDTO().getCoverageType()){
				this.primaryHold = new HoldDTO();
			}else if(CoverageType.EXCESS == coverageDetailsDTO.getHoldDTO().getCoverageType()){
				this.excessHold = new HoldDTO();
			}
			holdToDelete = coverageDetailsDTO.getHoldDTO().getRid();
		}
		return holdToDelete;
	}
}
