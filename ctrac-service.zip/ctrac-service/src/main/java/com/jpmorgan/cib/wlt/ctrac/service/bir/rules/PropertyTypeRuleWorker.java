package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.LookUpCodeService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailCollateralDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailRuleDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRInsurableAssetDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;

public class PropertyTypeRuleWorker extends AbstractBIRRuleWorker {
	
	public PropertyTypeRuleWorker(String key) {
		super(key, false, true);
	}
	
	private static final Logger logger = Logger.getLogger(PropertyTypeRuleWorker.class);
	
	private LookUpCodeService lookUpCodeService;
	
	private ViewDataRetrievalService viewDataRetrievalService;
	
	@Override
	public void populateExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData) {
		if (lookUpCodeService == null) {
			lookUpCodeService = ApplicationContextProvider.getContext().getBean(LookUpCodeService.class);
		}
		if (viewDataRetrievalService == null) {
			viewDataRetrievalService = ApplicationContextProvider.getContext().getBean(ViewDataRetrievalService.class);
		}
		
		Iterator<BIRCollateralDetailsDTO> collateralDetailsIter = 
				borrowerInsuranceReviewData.getCollateralDetailsMap().values().iterator();
		while (collateralDetailsIter.hasNext()) {
			BIRCollateralDetailsDTO collateralDetails = collateralDetailsIter.next();
			Long collateralRid = collateralDetails.getCollateralRid();
			
			Iterator<BIRInsurableAssetDetailsDTO> insurableAssetIterator =
					collateralDetails.getInsurableAssetDetailsMap().values().iterator();
			
			
			boolean allPolicyValuesSame = true;
			boolean atLeastOnePolicyValueActionRequired = false;
			boolean allPolicyValuesActionRequired = true;
			boolean allRequiredValuesSame = true;
			String singlePolicyPropertyType = null;
			String singleRequiredPropertyType = null;
			
			StringBuffer currentPolicyData = new StringBuffer();
			StringBuffer requiredValue = new StringBuffer();
			
			while (insurableAssetIterator.hasNext()) {
				BIRInsurableAssetDetailsDTO insurableAssetDetails = insurableAssetIterator.next();
				String propertyTypeCode = insurableAssetDetails.getPropertyType();
				if (StringUtils.isBlank(propertyTypeCode)) {
					logger.debug("blank propertyTypeCode for insurableAssetDetails rid=" + insurableAssetDetails.getRid());
					continue;
				}
				
				LookUpCode policyPropertyTypeCode = lookUpCodeService.findByCodeSetAndCode(
						CtracAppConstants.BRW_INS_REVIEW_COVERAGE_TYPE, propertyTypeCode);
				String policyPropertyType = policyPropertyTypeCode.getDescription();
				if (singlePolicyPropertyType == null) {
					singlePolicyPropertyType = policyPropertyType;
				} else if (!singlePolicyPropertyType.equals(policyPropertyType)) {
					allPolicyValuesSame = false;
				}
				RequiredCoverageViewDto requiredCoverage = viewDataRetrievalService.getRequiredCoverageBuildingDataBySortOrder(
						collateralRid, insurableAssetDetails.getInsurableAssetSortOrder());
				String requiredPropertyType = requiredCoverage.getPropertyType();
				if (singleRequiredPropertyType == null) {
					singleRequiredPropertyType = requiredPropertyType;
				} else if (!singleRequiredPropertyType.equals(requiredPropertyType)) {
					allRequiredValuesSame = false;
				}

				if (insurableAssetDetails.getBirRuleConclusions().get(key).hasException()) {
					atLeastOnePolicyValueActionRequired = true;
					CtracStringUtil.addValueWithSeparator(currentPolicyData, requiredCoverage.getBuildingName(), "<br/>");
					CtracStringUtil.addValueWithSeparator(currentPolicyData, policyPropertyType, ": ");
					CtracStringUtil.addValueWithSeparator(requiredValue, requiredCoverage.getBuildingName(), "<br/>");
					CtracStringUtil.addValueWithSeparator(requiredValue, requiredPropertyType, ": ");
				} else {
					allPolicyValuesActionRequired = false;
				}
			}
			
			if (atLeastOnePolicyValueActionRequired) {
				
				// if the policy property types are all the same and are all Action Required, then we can omit building names
				boolean canShowPolicyPropertyTypeWithoutBuildings = allPolicyValuesSame && allPolicyValuesActionRequired;
				if (!canShowPolicyPropertyTypeWithoutBuildings) {
					// show building names
					singlePolicyPropertyType = currentPolicyData.toString();
				}
				
				if (!allRequiredValuesSame) {
					// if any required value is different, then we must show the building names
					singleRequiredPropertyType = requiredValue.toString();
				}
				
				BIRExceptionEmailCollateralDTO collateralExceptionData =
						getExceptionEmailCollateralData(exceptionEmailData, collateralRid);
				BIRExceptionEmailRuleDTO propertyTypeExceptionData = new BIRExceptionEmailRuleDTO();
				propertyTypeExceptionData.setCurrentPolicyValue(singlePolicyPropertyType);
				propertyTypeExceptionData.setRequiredValue(singleRequiredPropertyType);
				collateralExceptionData.getCollateralExceptions().put(key, propertyTypeExceptionData);
			}
		}
	}

}
