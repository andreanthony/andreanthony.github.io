package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class FloodRemapSendEmailData extends FloodRemapData implements Serializable {
	
	private static final long serialVersionUID = -232021800118654852L;

    private String emailType;
	private List<MultipartFile> files;
	private boolean updateEmailDataInTM;
    private String emailTo;
	private String emailCC;
	private String emailBCC;
    private String SFHDFMessage;
    private Long emailTemplateRid;
    private List<String> allowedEmailDomains;
    
    private String lenderPlacedAmt;
    private String cancelledDate;
    private String lenderPlacedRefundAmt;
    private String thirtyDayRegulatoryDate;
    private String policyExpirationDate;
    private String lenderPlacedAssurantSentDate;
    
    private String applicableReason;
    private String vendorPaymentMethod;
    private String vendorPaymentValue;
    
    private String insuranceAgency;
    
    private boolean isAlthansPolicyAndBankShareZero;
    
	public String getLenderPlacedAmt() {
		return lenderPlacedAmt;
	}

	public void setLenderPlacedAmt(String lenderPlacedAmt) {
		this.lenderPlacedAmt = lenderPlacedAmt;
	}

	public String getCancelledDate() {
		return cancelledDate;
	}

	public void setCancelledDate(String cancelledDate) {
		this.cancelledDate = cancelledDate;
	}

	public String getLenderPlacedRefundAmt() {
		return lenderPlacedRefundAmt;
	}

	public void setLenderPlacedRefundAmt(String lenderPlacedRefundAmt) {
		this.lenderPlacedRefundAmt = lenderPlacedRefundAmt;
	}

	public String getThirtyDayRegulatoryDate() {
		return thirtyDayRegulatoryDate;
	}

	public void setThirtyDayRegulatoryDate(String thirtyDayRegulatoryDate) {
		this.thirtyDayRegulatoryDate = thirtyDayRegulatoryDate;
	}

	public String getSFHDFMessage() {
		return SFHDFMessage;
	}

	public void setSFHDFMessage(String sFHDFMessage) {
		SFHDFMessage = sFHDFMessage;
	}

	public String getEmailType() {
		return emailType;
	}

	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}

	public List<MultipartFile> getFiles() {
		return files;
	}

	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}

	public boolean isUpdateEmailDataInTM() {
		return updateEmailDataInTM;
	}

	public void setUpdateEmailDataInTM(boolean updateEmailDataInTM) {
		this.updateEmailDataInTM = updateEmailDataInTM;
	}

	public String getEmailTo() {
		return emailTo;
	}

	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}

	public String getEmailCC() {
		return emailCC;
	}

	public void setEmailCC(String emailCC) {
		this.emailCC = emailCC;
	}

	public String getEmailBCC() {
		return emailBCC;
	}

	public void setEmailBCC(String emailBCC) {
		this.emailBCC = emailBCC;
	}

	public void setAllowedEmailDomains(List<String> allowedEmailDomains) {
		this.allowedEmailDomains = allowedEmailDomains;
	}
	
	public List<String> getAllowedEmailDomains() {
		return this.allowedEmailDomains;
	}

	public Long getEmailTemplateRid() {
		return emailTemplateRid;
	}

	public void setEmailTemplateRid(Long emailTemplateRid) {
		this.emailTemplateRid = emailTemplateRid;
	}

	public String getApplicableReason() {
		return applicableReason;
	}

	public void setApplicableReason(String applicableReason) {
		this.applicableReason = applicableReason;
	}

	public String getVendorPaymentMethod() {
		return vendorPaymentMethod;
	}

	public void setVendorPaymentMethod(String vendorPaymentMethod) {
		this.vendorPaymentMethod = vendorPaymentMethod;
	}

	public String getVendorPaymentValue() {
		return vendorPaymentValue;
	}

	public void setVendorPaymentValue(String vendorPaymentValue) {
		this.vendorPaymentValue = vendorPaymentValue;
	}

	public String getPolicyExpirationDate() {
		return policyExpirationDate;
	}

	public void setPolicyExpirationDate(String policyExpirationDate) {
		this.policyExpirationDate = policyExpirationDate;
	}

	public String getLenderPlacedAssurantSentDate() {
		return lenderPlacedAssurantSentDate;
	}

	public void setLenderPlacedAssurantSentDate(String lenderPlacedAssurantSentDate) {
		this.lenderPlacedAssurantSentDate = lenderPlacedAssurantSentDate;
	}

	public String getInsuranceAgency() {
		return insuranceAgency;
	}

	public void setInsuranceAgency(String insuranceAgency) {
		this.insuranceAgency = insuranceAgency;
	}

	public boolean isAlthansPolicyAndBankShareZero() {
		return isAlthansPolicyAndBankShareZero;
	}

	public void setAlthansPolicyAndBankShareZero(boolean isAlthansPolicyAndBankShareZero) {
		this.isAlthansPolicyAndBankShareZero = isAlthansPolicyAndBankShareZero;
	}
}
