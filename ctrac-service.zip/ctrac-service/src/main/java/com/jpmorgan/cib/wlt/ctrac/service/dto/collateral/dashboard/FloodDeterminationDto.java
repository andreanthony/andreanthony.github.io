package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.util.Comparator;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;


public class FloodDeterminationDto extends BaseDto implements Cloneable, Comparator<FloodDeterminationDto> {

    /**
	 */
    private static final long serialVersionUID = 1L;

    private String vendor;
    private Long floodDeterminationId;

	@NoInvalidCharacters
    private String orderNumber;

	@NoInvalidCharacters
	private String loanIdentifier;
    private String dateOfDetermination;
    private String dateOfMapChange;

    @NoInvalidCharacters
    private String floodZone;
    private Long collateralRid;
	private String status = CoverageRequirementStatus.PENDING_VERIFICATION.name();
	private CollateralDoc determinationDocument;
	private String verificationDate;

	private boolean verifyMode;
	private FloodDeterminationDto loadTimeValue;

	public CollateralDoc getDeterminationDocument() {
		return determinationDocument;
	}

	public void setDeterminationDocument(CollateralDoc determinationDocument) {
		this.determinationDocument = determinationDocument;
	}
	
	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public Long getFloodDeterminationId() {
		return floodDeterminationId;
	}

	public void setFloodDeterminationId(Long floodDeterminationId) {
		this.floodDeterminationId = floodDeterminationId;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getLoanIdentifier() {
		return loanIdentifier;
	}

	public void setLoanIdentifier(String loanIdentifier) {
		this.loanIdentifier = loanIdentifier;
	}

	public String getDateOfDetermination() {
		return dateOfDetermination;
	}

	public void setDateOfDetermination(String dateOfDetermination) {
		this.dateOfDetermination = dateOfDetermination;
	}

	public String getDateOfMapChange() {
		return dateOfMapChange;
	}

	public void setDateOfMapChange(String dateOfMapChange) {
		this.dateOfMapChange = dateOfMapChange;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public String getVerificationDate() {
		return verificationDate;
	}

	public void setVerificationDate(String verificationDate) {
		this.verificationDate = verificationDate;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((floodDeterminationId == null) ? 0 : floodDeterminationId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FloodDeterminationDto other = (FloodDeterminationDto) obj;
		if (floodDeterminationId == null) {
			if (other.floodDeterminationId != null)
				return false;
		} else if (!floodDeterminationId.equals(other.floodDeterminationId))
			return false;
		return true;
	}
	
	private boolean deepEquals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FloodDeterminationDto other = (FloodDeterminationDto) obj;
		if (collateralRid == null) {
			if (other.collateralRid != null)
				return false;
		} else if (!collateralRid.equals(other.collateralRid))
			return false;
		if (floodZone == null) {
			if (other.floodZone != null)
				return false;
		} else if (!floodZone.equals(other.floodZone))
			return false;
	
		if (floodDeterminationId == null) {
			if (other.floodDeterminationId != null)
				return false;
		} else if (!floodDeterminationId.equals(other.floodDeterminationId))
			return false;
		if (vendor == null) {
			if (other.vendor != null)
				return false;
		} else if (!vendor.equals(other.vendor))
			return false;
		
		if (orderNumber == null) {
			if (other.orderNumber != null)
				return false;
		} else if (!orderNumber.equals(other.orderNumber))
			return false;
		
		if (loanIdentifier == null) {
			if (other.loanIdentifier != null)
				return false;
		} else if (!loanIdentifier.equals(other.loanIdentifier))
			return false;
		
		if (dateOfDetermination == null) {
			if (other.dateOfDetermination != null)
				return false;
		} else if (!dateOfDetermination.equals(other.dateOfDetermination))
			return false;
		
		if (dateOfMapChange == null) {
			if (other.dateOfMapChange != null)
				return false;
		} else if (!dateOfMapChange.equals(other.dateOfMapChange))
			return false;
		
		if (verificationDate == null) {
			if (other.verificationDate != null)
				return false;
		} else if (!verificationDate.equals(other.verificationDate))
			return false;
		
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		
		return true;
	}
	
	public boolean hasChanged(){
		
		if(this.loadTimeValue ==null || this.getFloodDeterminationId()==null){
			return true;
		}
		return !deepEquals(this.loadTimeValue);
	}
	
	public void saveACopy () {		
		try {
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException swallow) {
		}
	}
	
	@Override
	protected FloodDeterminationDto clone() throws CloneNotSupportedException {
		return (FloodDeterminationDto) super.clone();
	}

	public boolean isVerifyMode() {
		return verifyMode;
	}

	public void setVerifyMode(boolean verifyMode) {
		this.verifyMode = verifyMode;
	}

	@Override
	public int compare(FloodDeterminationDto determination1, FloodDeterminationDto determination2) {
		if(determination1.getDateOfDetermination()==null && determination2.getDateOfDetermination()==null){
    		return 0;
    	}else if(determination1.getDateOfDetermination()==null && determination2.getDateOfDetermination()!=null){
			return -1;
		}else if(determination1.getDateOfDetermination()!=null && determination2.getDateOfDetermination()==null){
			return 1;
		}else{
			return determination1.dateOfDetermination.compareTo(determination2.dateOfDetermination);
		}	
	}
	
	public boolean isInFloodZone() {
		if (floodZone == null) {
			return false;
		}
		return floodZone.toUpperCase().trim().startsWith("A") || floodZone.toUpperCase().trim().startsWith("V");
		
	}	

}
