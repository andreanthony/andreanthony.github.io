package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import static com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion.ACTION_REQUIRED;

import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailCollateralDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailRuleDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public abstract class AbstractBIRRuleWorker implements BIRRuleWorker {

	protected AbstractBIRRuleWorker(String key, boolean hasRule, boolean isCollateralLevel) {
		this.key = key;
		this.hasRule = hasRule;
		this.isCollateralLevel = isCollateralLevel;
	}
	
	protected AbstractBIRRuleWorker(String key, boolean hasRule) {
		this(key, hasRule, false);
	}
	
	protected final String key;
	
	private final boolean hasRule;
	
	private final boolean isCollateralLevel;
	
	public final String getKey() {
		return key;
	}
	
	/**
	 * default: check if top-level element is enabled (Accepted Policy & Action Required)
	 * NEED TO OVERRIDE IF RULE IS AT THE COLLATERAL OR INSURABLE ASSET LEVEL
	 */
	protected boolean ruleShouldRun(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		return !borrowerInsuranceReviewData.isDisabled(key, null, null);	
	}
	
	protected void runRule(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {}
	
	@Override
	public final void execute(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		if (hasRule && ruleShouldRun(borrowerInsuranceReviewData)) {
			runRule(borrowerInsuranceReviewData);
		}
	}
	
	/**
	 * default: add the key with no policy or required values (template has static text)
	 */
	@Override
	public void populateExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData) {
		exceptionEmailData.getPolicyExceptions().put(key, new BIRExceptionEmailRuleDTO());
	}
	
	protected void populateCollateralExceptionData(BIRExceptionEmailDTO exceptionEmailData,
			BIRCollateralDetailsDTO collateralDetails, String currentPolicyValue, String requiredValue) {
		BIRRuleConclusionDTO birRuleConclusionDTO = collateralDetails.getBirRuleConclusions().get(key);
		if (ACTION_REQUIRED.name().equals(birRuleConclusionDTO.getConclusion())) {
			BIRExceptionEmailCollateralDTO exceptionEmailCollateralData =
					getExceptionEmailCollateralData(exceptionEmailData, collateralDetails.getCollateralRid());
			BIRExceptionEmailRuleDTO birExceptionEmailRuleDTO = new BIRExceptionEmailRuleDTO();
			birExceptionEmailRuleDTO.setCurrentPolicyValue(currentPolicyValue);
			birExceptionEmailRuleDTO.setRequiredValue(requiredValue);
			exceptionEmailCollateralData.getCollateralExceptions().put(key, birExceptionEmailRuleDTO);
		}
	}

	protected BIRExceptionEmailCollateralDTO getExceptionEmailCollateralData(
			BIRExceptionEmailDTO exceptionEmailData, Long collateralRid) {
		Map<Long, BIRExceptionEmailCollateralDTO> collateralExceptionDataMap = exceptionEmailData.getCollateralExceptionDataMap();
		BIRExceptionEmailCollateralDTO exceptionEmailCollateralData = collateralExceptionDataMap .get(collateralRid);
		if (exceptionEmailCollateralData == null) {
			exceptionEmailCollateralData = new BIRExceptionEmailCollateralDTO();
			exceptionEmailCollateralData.setCollateralRid(collateralRid);
			collateralExceptionDataMap.put(collateralRid, exceptionEmailCollateralData);
		}
		return exceptionEmailCollateralData;
	}

	@Override
	public boolean isCollateralLevel() {
		return isCollateralLevel;
	}
	
}
