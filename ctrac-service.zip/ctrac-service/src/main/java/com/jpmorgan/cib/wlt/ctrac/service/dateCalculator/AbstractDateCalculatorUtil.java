package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.springframework.beans.factory.annotation.Autowired;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BankHolidays;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BankHolidaysRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CtracReferenceDateRepository;




public abstract class AbstractDateCalculatorUtil {

	@Autowired protected BankHolidaysRepository bankHolidaysRepository;
	@Autowired protected CtracReferenceDateRepository ctracReferenceDateRepository;
	
	/**
	 * This function gets the reference date from the database, and then updates this date
	 * with the current system time and returns a java.util.date object with this information. 
	 * @return
	 */
	public Date getCurrentReferenceDate() {
		ReferenceDate referenceDate = ctracReferenceDateRepository.findByName(CtracAppConstants.REFERENCE_DATE);
		DateTime referenceDateTime = new DateTime(referenceDate.getReferencDate());
		DateTime returnDate = new DateTime();
		returnDate = returnDate.withDate(referenceDateTime.getYear(), referenceDateTime.getMonthOfYear(), referenceDateTime.getDayOfMonth());
		return returnDate.toDate();
	}
	
	public Date getCurrentReferenceDateAtStartOfDay() {
		ReferenceDate referenceDate = ctracReferenceDateRepository.findByName(CtracAppConstants.REFERENCE_DATE);
		DateTime referenceDateTime = new DateTime(referenceDate.getReferencDate());
		return referenceDateTime.withTimeAtStartOfDay().toDate();
	}
	
	
	public DateTime getLastCLRemapFileReceivedDateTime(){
		ReferenceDate lastFileRecievedDate = ctracReferenceDateRepository.findByName(CtracAppConstants.CL_LAST_REMAP_FILE_RECEIVED_DATE);
	    return new DateTime(lastFileRecievedDate.getReferencDate());
	}
	
	public DateTime getLastSLRemapFileReceivedDateTime(){
		ReferenceDate lastFileRecievedDate = ctracReferenceDateRepository.findByName(CtracAppConstants.SL_LAST_REMAP_FILE_RECEIVED_DATE);
	    return new DateTime(lastFileRecievedDate.getReferencDate());
	}
	
	/**
	 * determine if the @calendarDay is a business day not inserted in JPMC
	 * official holidays.
	 * */
	public boolean isWorkingDay(DateTime calendarDay) {
		if (DateTimeConstants.SATURDAY == calendarDay.getDayOfWeek() || DateTimeConstants.SUNDAY == calendarDay.getDayOfWeek()) {
			return false;
		}
		
		if(isTodayAHoliday(calendarDay, CtracAppConstants.ENABLED_FLAG,
				CtracAppConstants.USA_CALENDAR)){
			return false;
		}
		return true;
	}
	
	public boolean isWorkingDay(Date calendarDay) {
		return isWorkingDay(new DateTime(calendarDay));
	}
	
	public boolean isTodayAHoliday(DateTime calendarDay, Character enabled, String holidayCalendar){
		List<BankHolidays> holidays = bankHolidaysRepository.findByHolidayDateAndHolidayActiveFlagAndHolidayCalendar(
				DateUtils.truncate(calendarDay.toDate(), Calendar.DATE), enabled, holidayCalendar);

		if(holidays ==null){
			return false;
		}
		
		if(holidays.isEmpty()){
			return false;
		}
		
		if(holidays.size()==0){
			return false;
		}
		
		return true;
}
		

	
	//Syntactic suger
	public boolean isWorkingDay() {
		return isWorkingDay(new DateTime(getCurrentReferenceDate()));
	}
	
	public boolean isDateBeforeOrOn(Date first, Date second, boolean ignoreMMSS){
		if(ignoreMMSS){
			first = DateUtils.truncate(first, Calendar.DATE);
			second = DateUtils.truncate(second, Calendar.DATE);
		}
		return(first.equals(second) || first.before(second));
	}
		
	public boolean isDateBefore(Calendar first, Calendar second, boolean ignoreMMSS){
		if(ignoreMMSS){
			first = DateUtils.truncate(first, Calendar.DATE);
			second = DateUtils.truncate(second, Calendar.DATE);			
		}
		return (first.getTime().before(second.getTime()));
	}
	
	/**
	 * @param timeArray
	 *            = array [ss,mm,hh] return today as a calendar populated with
	 *            the time array
	 */
	public Calendar populateTodayCalendar(String[] timeArray) {

		Calendar ret = Calendar.getInstance();
		ret.setTime(getCurrentReferenceDate());
		
		ret.set(Calendar.HOUR_OF_DAY, Integer.parseInt(timeArray[2]));
		ret.set(Calendar.MINUTE, Integer.parseInt(timeArray[1]));
		ret.set(Calendar.SECOND, Integer.parseInt(timeArray[0]));
		ret.set(Calendar.MILLISECOND, 0);

		return ret;
	}
	/**
	 * @param timeArray
	 *            = array [ss,mm,hh] return today as a calendar populated with
	 *            the time array
	 */
	public Calendar populateTodayCalendar(int[] timeArray) {
		Calendar ret = Calendar.getInstance();
		ret.setTime(getCurrentReferenceDate());
		ret.set(Calendar.HOUR_OF_DAY, timeArray[2]);
		ret.set(Calendar.MINUTE, timeArray[1]);
		ret.set(Calendar.SECOND, timeArray[0]);
		ret.set(Calendar.MILLISECOND, 0);

		return ret;
	}
}
