package com.jpmorgan.cib.wlt.ctrac.service.dto.base;


public interface Collateraldata {

}
