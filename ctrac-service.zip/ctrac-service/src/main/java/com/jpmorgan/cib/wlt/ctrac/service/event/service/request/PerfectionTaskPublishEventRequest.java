package com.jpmorgan.cib.wlt.ctrac.service.event.service.request;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.*;

public class PerfectionTaskPublishEventRequest extends AbstractPublishEventRequest {

    private PerfectionTask perfectionTask;
    private static final List<String> EXCLUDED_TASK_NAMES = Collections.unmodifiableList(Arrays.asList(
            COMPLETE.getName(),
            CANCELLED.getName(),
            FIAT_RECEIVED.getName(),
            SBA_COVERAGE_RECEIVED.getName()));

    public PerfectionTaskPublishEventRequest(PerfectionTask perfectionTask, Long collateralRid,
                                             String lineOfBusiness){
        this.collateralRid = collateralRid;
        this.lineOfBusiness = lineOfBusiness;
        this.perfectionTask = perfectionTask;
    }

    public PerfectionTaskPublishEventRequest forCollateralEventType(CollateralEventType collateralEventType){
        this.collateralEventType = collateralEventType;
        return this;
    }

    @Override
    public CollateralEventType getCollateralEventType(){
        if(this.collateralEventType == null) {
            if(perfectionTask.getRid() == null) {
                collateralEventType = CollateralEventType.CREATED;
            }
            else if(!perfectionTask.getTaskStatus().equals(perfectionTask.getLoadTimeTaskStatus()) ||
                    !perfectionTask.getWorkflowStep().equals(perfectionTask.getLoadTimeWorkflowStep())) {
                collateralEventType = CollateralEventType.TRANSITIONED;
            }
            else {
                if(perfectionTask.isUpdatedByAdmin()) {
                    collateralEventType = CollateralEventType.EDITED;
                }
            }
        }
        return getCollateralEventTypeForAdmin();
    }

    CollateralEventType getCollateralEventTypeForAdmin() {
        if (perfectionTask.isUpdatedByAdmin()) {
            if (collateralEventType == CollateralEventType.CREATED) {
                return CollateralEventType.ADMIN_CREATED;
            }
            if (collateralEventType == CollateralEventType.TRANSITIONED) {
                return CollateralEventType.ADMIN_TRANSITIONED;
            }
            if (collateralEventType == CollateralEventType.EDITED) {
                return CollateralEventType.ADMIN_EDITED;
            }
        }
        return collateralEventType;
    }

    @Override
    public String getDescription() {
        StringBuilder description = new StringBuilder();
        if (perfectionTask.isUpdatedByAdmin()
                && !Objects.equals(perfectionTask.getWakeUpDate(), perfectionTask.getLoadTimeWakeUpDate())
                && !Objects.equals(perfectionTask.getExecutionDate(), perfectionTask.getLoadTimeExecutionDate())) {
            return "Changed Wake Up and Execution Date";
        } else if (perfectionTask.isUpdatedByAdmin()
                && !Objects.equals(perfectionTask.getWakeUpDate(), perfectionTask.getLoadTimeWakeUpDate())) {
            return "Changed Wake Up Date";
        } else if (perfectionTask.isUpdatedByAdmin()
                && !Objects.equals(perfectionTask.getExecutionDate(), perfectionTask.getLoadTimeExecutionDate())) {
            return "Changed Execution Date";
        } else if (!Objects.equals(perfectionTask.getTaskStatus(), perfectionTask.getLoadTimeTaskStatus())
                && perfectionTask.getLoadTimeTaskStatus() != null) {
            description.append(perfectionTask.getLoadTimeTaskStatus()).append(" to ");
        }
        description.append(perfectionTask.getTaskStatus());
        return description.toString();
    }

    /**
     * Return the identifier which is equal to the policy RID
     * @return Identifier
     */
    @Override
    public String getIdentifier(){
        if(perfectionTask.getTmTaskId()!= null) {
            return perfectionTask.getTmTaskId();
        }
        return StringUtils.EMPTY;
    }

    @Override
    public String getUser() {
        if(isSystemEvent || (CollateralEventType.CREATED.equals(getCollateralEventType()) &&
                !WorkflowStateDefinition.NEW_ITEM.getName().equals(perfectionTask.getWorkflowStep()))) {
            return SYSTEM;
        }
        return SYSTEM.equals(perfectionTask.getUpdatedBy())? SYSTEM : null;
    }

    @Override
    public String getTaskName() {
        return EXCLUDED_TASK_NAMES.contains(perfectionTask.getWorkflowStep())?
                perfectionTask.getLoadTimeWorkflowStep(): perfectionTask.getWorkflowStep();
    }

}
