package com.jpmorgan.cib.wlt.ctrac.service.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.InsuranceRenewalItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.FloodInsuranceRenewalService;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.email.EmailDataDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VerifyLetterData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VerifyPreRenewalLetterDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProofOfCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.ProvidedCoverageDetailsViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.RequiredCoverageViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailTemplateRetrievalService;
import com.jpmorgan.cib.wlt.ctrac.service.email.FloodEmailService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.VendorPaymentMethodService;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.DateConverter;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TaskUniqueIdGenerator;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.OPTIONAL_WORD_RENEWAL;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.*;

@Service(value = "floodInsuranceRenewalService")
public class FloodInsuranceRenewalServiceImpl implements FloodInsuranceRenewalService {

	@Autowired
	private AuditInformationService auditInformationService;

	@Autowired
	private PerfectionTaskRepository perfectionTaskRepository;

	@Autowired
	private ProofOfCoverageRepository proofOfCoverageRepository;

	@Autowired
    private CtracObjectMapper ctracObjectMapper;

	@Autowired
	private CollateralManagementService collateralManagementSerivce;

	@Autowired
	private EmailTemplateRetrievalService emailTemplateRetrievalService;

	@Autowired
	private CalendarDayUtil calendarDayUtil;

	@Autowired
	private ContactAgentRepository contactAgentRepository;

	@Autowired
	private TaskService taskService;

	@Autowired
	private InsuranceMngtService insuranceMngtService;

	@Autowired
	private InsuranceRenewalItemRepository insuranceRenewalItemRepository;

	@Autowired
	private CollateralInsuranceRepository collateralInsuranceRepository;

	@Autowired
	private OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher;

	@Autowired
	private LoanManagementService loanManagementService;

	@Autowired
	private ViewDataRetrievalService viewDataRetrievalService;

	@Autowired
	private DateCalculator dateCalculator;

	@Autowired
	private ProofOfCovWorkItemRepository proofOfCovWorkItemRepository;

	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Autowired
	private CollateralRepository collateralRepository;

	@Autowired
	private FloodEmailService floodEmailService;

    @Autowired private VendorPaymentMethodService vendorPaymentMethodService;
	@Autowired private LoanService loanService;
    @Autowired private PerfectionTaskService perfectionTaskService;

    private static final Logger logger = Logger.getLogger(FloodInsuranceRenewalServiceImpl.class);
	private static Format formatter_date_us = new SimpleDateFormat(CtracAppConstants.DATE_FORMAT_US);
	public static final Map<String, Ordinal> contactAgentOrdinalMap;
	static
	{
		contactAgentOrdinalMap = new HashMap<>();
		contactAgentOrdinalMap.put(CALL_OR_EMAIL_AGENT_1ST_NOTICE.getName(), Ordinal.FIRST);
		contactAgentOrdinalMap.put(CALL_OR_EMAIL_AGENT_2ND_NOTICE.getName(), Ordinal.SECOND);
		contactAgentOrdinalMap.put(CALL_OR_EMAIL_AGENT_3RD_NOTICE.getName(), Ordinal.THIRD);
	}

	@Override
	@Transactional
	public ContactAgentDto prepareContactAgentDto(TMParams TMParams) {
		logger.debug("prepareContactAgentDto::begin");
		String taskId = TMParams.getId_task();
		ContactAgentDto contactAgentDto = new ContactAgentDto();
		contactAgentDto.setTmParams(TMParams);
		PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(taskId);
		InsuranceRenewalItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), InsuranceRenewalItem.class);
		//1.grab policy information
		ProofOfCoverageDTO proofOfCoverageDto = ctracObjectMapper.map(workItem.getProofOfCoverage(), ProofOfCoverageDTO.class);
		contactAgentDto.setProofOfCoverageDto(proofOfCoverageDto);
		//2.grab all related collateral info with this proof of coverage
		List<CollateralDto> collateralDtos = collateralManagementSerivce.getCollateralDtosByProofOfCoverage(proofOfCoverageDto);
		contactAgentDto.setCollateralDtoList(collateralDtos);
		//3.grab all related loan borrower with this collateral
		contactAgentDto.setLoanDtoList(loanManagementService.getPrimaryLoans(collateralDtos));
		contactAgentDto.setReminderType(getReminderType(proofOfCoverageDto));
		//4.populate email template
		String workflowStep = perfectionTask.getWorkflowStep();
		EmailAttributeHolder emailAttributeHolder = prepareAgentEmailAttr(contactAgentDto, contactAgentDto.getProofOfCoverageDto().getPolicyType(), workflowStep);
	    contactAgentDto.setEmailStaticContent(emailAttributeHolder.getEmailTemplate().getEmailStaticText());
	    //5.set the current date
	    String strCurrentDate = DateFormatter.toString(CtracAppConstants.DATE_FORMAT_US, calendarDayUtil.getCurrentReferenceDate());
		contactAgentDto.setCallPlacedDate(strCurrentDate);
		//6.handle second third contact agent notice
		Ordinal ordinal = contactAgentOrdinalMap.get(workflowStep);
		contactAgentDto.setPageTitle("Flood Insurance - Call or Email Agent - " + ordinal.getOrdinalInst() + " Notice");

		logger.debug("prepareContactAgentDto::end");
		return contactAgentDto;
	}


	@Override
	@Transactional
	public void processContactAgentDto(final ContactAgentDto contactAgentDto) {
		logger.debug("processContactAgentDto::begin");
		ContactAgent contactAgent = new ContactAgent();
		final PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(contactAgentDto.getTmParams().getId_task());
		final InsuranceRenewalItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), InsuranceRenewalItem.class);
		insuranceMngtService.saveProofOfCoverage(contactAgentDto.getProofOfCoverageDto());
		contactAgent.setCallPlaced(contactAgentDto.getIsCallPlacedForAgent());
		contactAgent.setPerfectionTask(perfectionTask);
		EmailAttributeHolder emailAttributeHolder = contactAgentDto.getEmailAttributeHolder();
         //send email and save the email event
		if (!(emailAttributeHolder.getToAddresses().isEmpty() && emailAttributeHolder.getCcAddresses().isEmpty()
				&& emailAttributeHolder.getBccAddresses().isEmpty())) {
			List<CollateralDto> loanDataList = contactAgentDto.getCollateralDtoList();
			for (CollateralDto collateralDto : loanDataList) {
				emailAttributeHolder.getCollateralRids().add(collateralDto.getRid());
			}
			floodEmailService.sendEmail(emailAttributeHolder);
            EmailDetails emailDetails = ctracObjectMapper.map(emailAttributeHolder, EmailDetails.class);
 	    	contactAgent.setEmailDetails(emailDetails);
		}
		contactAgentRepository.save(contactAgent);
		final TMParams TMParams = contactAgentDto.getTmParams();
		logger.debug("debugging when launching contactAgent hyelper id_task:" + TMParams.getId_task() + "  workflowStep:" + TMParams.getWorkflowStep() + " tranid: " +  TMParams.getTmTransactionId());
		Map<StateParameterType, Object> worflowData = new HashMap<StateParameterType, Object>(){{
			put(StateParameterType.HELPER_DATA, contactAgentDto);
			put(StateParameterType.PERFECTION_TASK, perfectionTask);
			put(StateParameterType.WORK_ITEM, workItem);
			put(StateParameterType.TM_PARAMS, TMParams);
		}};

		taskService.completeWorkFlowStepOperations(worflowData);
		logger.debug("processContactAgentDto::end");
	}

    @Override
    @Transactional
	public void initBorrowerRenewalWorkFlow(ProofOfCoverage proofOfCoverage){
		if (proofOfCoverage == null || isRenewalPolicyAccepted(proofOfCoverage)) {
			return;
		}
		//create a new work item  with links with proofofcoverages and collateral
		InsuranceRenewalItem renewalItem = createFloodInsuranceItem();
		List<CollateralInsuranceViewData> collateralInsuranceViewDataList = collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverage.getRid());
		long lastCollateralRid = 0L;
		for (CollateralInsuranceViewData collateralInsuranceViewData : collateralInsuranceViewDataList) {
			lastCollateralRid = collateralInsuranceViewData.getCollateral().getRid();
			renewalItem.addCollateral(collateralInsuranceViewData.getCollateral());
		}

		renewalItem.addProofOfCoverage(proofOfCoverage, ProofOfCoverageWorkItemRelationType.RENEWAL_TO_POLICY.name());
		renewalItem = insuranceRenewalItemRepository.save(renewalItem);
		if (!loanService.hasExternallyAgented(lastCollateralRid)) {
			initContactAgentWorkflow(renewalItem);
			createMarketRenewalEmailTask(renewalItem);
		}
	}

    @Override
    public boolean isRenewalPolicyAccepted(ProofOfCoverage proofOfCoverage) {
        List<ProofOfCoverage> childPolicies = proofOfCoverageRepository.findByParentPolicyRid(proofOfCoverage.getRid());
        for (ProofOfCoverage childPolicy : childPolicies) {
            if (childPolicy.getPolicyType_().isBorrowerPolicy()) {
                return true;
            }
        }
        return false;
	}

    @Override
    @Transactional
    public void prepareAndSendMarketRenewalEmail(InsuranceRenewalItem insuranceRenewalItem){
		logger.debug("prepareAndSendRenewalPolicyEmail::begin");
       	ProofOfCoverage proofOfCoverage = insuranceRenewalItem.getProofOfCoverage();
       	proofOfCoverage  =  CtracBaseEntity.deproxy(proofOfCoverage, ProofOfCoverage.class);

		EmailAttributeHolder emailAttributeHolder = prepareMarketRenewalEmail(proofOfCoverage);
		if (emailAttributeHolder ==  null) {
    		logger.info("Not sending prepareAndSendRenewalPolicyEmail when all primary loans are CTL and none is special handling");
		} else {
			floodEmailService.sendEmail(emailAttributeHolder);
		}
		logger.debug("prepareAndSendRenewalPolicyEmail::end");
  }


	protected EmailAttributeHolder prepareMarketRenewalEmail(ProofOfCoverage proofOfCoverage) {
		ProofOfCoverageDTO proofOfCoverageDto = ctracObjectMapper.map(proofOfCoverage, ProofOfCoverageDTO.class);
		List<CollateralDto> collateralDtos = collateralManagementSerivce.getCollateralDtosByProofOfCoverage(proofOfCoverageDto);
		List<LoanData> loanData = loanManagementService.getPrimaryLoans(collateralDtos);
		ReminderType reminderType = getReminderType(proofOfCoverageDto);
		EmailTemplate emailTemplate = emailTemplateRepository.findByEmailTemplateId("FIBE");

		EmailDataDto emailDataDto = prepareBankerEmailDetailsDto(proofOfCoverageDto, collateralDtos, loanData, reminderType);
	    EmailAttributeHolder emailAttributeHolder = createEmailContent(emailDataDto, emailTemplate);
	    Set<String> marketEmailTo = setMarketEmailAsToEmailAddresses(collateralDtos);

    	if (marketEmailTo.isEmpty()) {
    		return null;
    	} else {
    		emailAttributeHolder.setToAddresses(marketEmailTo);
    	}

	    for (CollateralDto collateralDto : collateralDtos) {
	    	emailAttributeHolder.getCollateralRids().add(collateralDto.getRid());
		}

		return emailAttributeHolder;
	}

	protected EmailAttributeHolder createEmailContent(EmailDataDto emailDataDto, EmailTemplate emailTemplate) {
		EmailAttributeHolder emailAttributeHolder = CtracEmailSender.createEmailContent(emailDataDto, emailTemplate);
		return emailAttributeHolder;
	}

	protected PerfectionTask createMarketRenewalEmailTask(InsuranceRenewalItem renewalItem) {
		logger.debug("createMarketRenewalEmailTask::begin");
		PerfectionTask perfectionTask;
		try{
            perfectionTask = perfectionTaskService.createTask(
                    TaskStatus.TRANSIENT, renewalItem, SEND_MARKET_RENEWAL_EMAIL.getFloodRemapTaskState(),
                    TMTaskType.FLOOD_INSURANCE, null, null);
			logger.debug("createMarketRenewalEmailTask::end");
		}
		catch(Exception e){
			logger.error(e.getMessage());
			throw new CTracApplicationException("E0258", CtracErrorSeverity.APPLICATION);
		}
		return perfectionTask;
	}

	protected void initContactAgentWorkflow(WorkItem floodInsuranceItem){
		logger.debug("initContactAgentWorkflow::begin");
		try{
			Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
			inputParameterMap.put(StateParameterType.WORK_ITEM, floodInsuranceItem);
			perfectionTaskService.createTask(
			        TaskStatus.SLEEPING, floodInsuranceItem, CALL_OR_EMAIL_AGENT_1ST_NOTICE.getFloodRemapTaskState(),
                    TMTaskType.FLOOD_INSURANCE, "SYSTEM", inputParameterMap);
			logger.debug("initContactAgentWorkflow::end");
		}
		catch(Exception e){
			logger.error(e.getMessage());
			throw new CTracApplicationException("E0252", CtracErrorSeverity.APPLICATION);
		}
	}

	@Override
	public ReminderType getReminderType(ProofOfCoverageDTO proofOfCoverageDto) {
		List<CollateralDto> collateralDtos = collateralManagementSerivce.getCollateralDtosByProofOfCoverage(proofOfCoverageDto);
		boolean hasSBALoan = containsSBALoan(collateralDtos);
		return getReminderType(proofOfCoverageDto.getPolicyType(), hasSBALoan);
	}


	@Override
	@Transactional(readOnly = true)
	public VerifyPreRenewalLetterDto prepareVerifyPreRenewalLetterDto(TMParams TMParams)
	{
		logger.debug("prepareVerifyPreRenewalLetterDto::BEGIN");

		 PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(TMParams.getId_task());
	     WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);
	     ProofOfCovWorkItem  proofOfCovWorkItem = proofOfCovWorkItemRepository.findByWorkItemRid(workItem.getRid());
	     Long proofOfCoverageRid =  proofOfCovWorkItem.getProofOfCoverage().getRid();
	     List<CollateralInsuranceViewData> listCollateralInsuranceViewData = collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverageRid);


	     VerifyPreRenewalLetterDto verifyPreRenewalLetterDto = new VerifyPreRenewalLetterDto();
	     Long collateralRid = listCollateralInsuranceViewData.get(0).getCollateral().getRid();

	     //2. Pull Unique Mortgagor and Borrowers
	     verifyPreRenewalLetterDto.setMortgagorNames(viewDataRetrievalService.getUniqueMortgagorAndBorrowerNames(collateralRid, ", "));

	     //3. Pull Collateral Main Details
	     verifyPreRenewalLetterDto.setCollateralMainDetailsViewDto(viewDataRetrievalService.getCollateralMainDetails(collateralRid));

	     //4. Proof of coverage details
	     Long workItemRid = workItem.getRid();
	     ProvidedCoverageDetailsViewDto providedCoverageDetailsViewDto = viewDataRetrievalService.getLPProofOfCoverageDetails(workItemRid);
	     verifyPreRenewalLetterDto.setProvidedCoverageDetailsViewDto(providedCoverageDetailsViewDto);

	     //5. coverage type
	     RequiredCoverageViewDto requiredCoverageViewDto = viewDataRetrievalService.getRequiredCoverageViewData(collateralRid,providedCoverageDetailsViewDto.getInsurableAssetRid());
	     verifyPreRenewalLetterDto.setRequiredCoverageViewDto(requiredCoverageViewDto);

	     ProofOfCoverageDetailsViewDto proofOfCoverageDetailsViewDto = viewDataRetrievalService.getProofOfCoverageDetailsByRid(proofOfCoverageRid);
	     verifyPreRenewalLetterDto.setProofOfCoverageDetailsViewDto(proofOfCoverageDetailsViewDto);

	     //6. Add commnon attributes
	     addCommonAttributes(verifyPreRenewalLetterDto,perfectionTask,TMParams);

	     //7. Policy expiration date/ Reminder date /Current reference date
	     Date expDate = DateConverter.convert(proofOfCoverageDetailsViewDto.getExpirationDate());
		 Date reminderDate = calendarDayUtil.subtractCalendarDays(45, expDate, false);
		 verifyPreRenewalLetterDto.setReminderDate(formatter_date_us.format(reminderDate));
		 verifyPreRenewalLetterDto.setCurrentDate(formatter_date_us.format(calendarDayUtil.getCurrentReferenceDate()));

		logger.debug("prepareVerifyPreRenewalLetterDto::END");
		return verifyPreRenewalLetterDto;
	}

	/**
	 * This method is used to save the date of pre-renewal letter
	 * And complete the task after submission
	 */
	@Override
	@Transactional(value="transactionManager" , readOnly=true)
	public void processVerifyPreRenewalLetterDto(final VerifyPreRenewalLetterDto verifyPreRenewalLetterDto) throws Exception {

		logger.debug("processVerifyPreRenewalLetterDto::Start");
		final PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskId(verifyPreRenewalLetterDto.getTmParams().getId_task());
	    WorkItem workItem = CtracBaseEntity.deproxy(perfectionTask.getWorkItem(), WorkItem.class);

	    InsuranceRenewalItem insuranceRenewal = insuranceRenewalItemRepository.findByRid(workItem.getRid());
		Date preRenewalletterDate = DateFormatter.parseDate(verifyPreRenewalLetterDto.getDateOfLetter(), CtracAppConstants.DATE_FORMAT_US);
		insuranceRenewal.setPreRenewalLetterDate(preRenewalletterDate);
		insuranceRenewal = insuranceRenewalItemRepository.save(insuranceRenewal);

		Map<StateParameterType, Object> worflowData = new HashMap<StateParameterType, Object>(){{
			put(StateParameterType.HELPER_DATA, verifyPreRenewalLetterDto);
			put(StateParameterType.PERFECTION_TASK, perfectionTask);
			put(StateParameterType.TM_PARAMS, verifyPreRenewalLetterDto.getTmParams());
		}};

		taskService.completeWorkFlowStepOperations(worflowData);
	     logger.debug("processVerifyPreRenewalLetterDto::END");
	}

	@Override
	@Transactional
	public PerfectionTask initSendPreRenewalLetter(ProofOfCoverage proofOfCoverage, final Collateral collateral){
		InsuranceRenewalItem insuranceRenewalItem = createInsuranceRenewalItem(proofOfCoverage, collateral);

		// create the Pre-Renewal Letter task
		Map<StateParameterType, Object> inputParameterMap = new HashMap<>();
		inputParameterMap.put(StateParameterType.WORK_ITEM, insuranceRenewalItem);
		String userId = StringUtils.isBlank(auditInformationService.getLoggedInUserSid()) ?
				auditInformationService.getLoggedInUserSid() : "SYSTEM";

		PerfectionTask sendPreRenewalLetterTask = perfectionTaskService.createTask(TaskStatus.TRANSIENT,
				insuranceRenewalItem, SEND_PRE_RENEWAL_EXP_LETTER.getFloodRemapTaskState(),
				TMTaskType.FLOOD_INSURANCE, userId, inputParameterMap);

        vendorPaymentMethodService.setDefaultPreRenewalPaymentMethod(proofOfCoverage, insuranceRenewalItem);
        proofOfCoverageRepository.saveAndFlush(proofOfCoverage);
		return sendPreRenewalLetterTask;
	}

	@Override
	@Transactional
	public InsuranceRenewalItem createInsuranceRenewalItem(final ProofOfCoverage proofOfCoverage, final Collateral collateral) {
		// create INSURANCE_RENEWAL_ITEM and link it to the policy
		InsuranceRenewalItem insuranceRenewalItem = createFloodInsuranceItem();
		insuranceRenewalItem.addProofOfCoverage(proofOfCoverage,
				ProofOfCoverageWorkItemRelationType.RENEWAL_TO_POLICY.name());
		RenewalWorkflowType renewalWorkflowType = RenewalWorkflowType.findByPolicyType(proofOfCoverage.getPolicyType_());
		insuranceRenewalItem.setWorkflowType(renewalWorkflowType.name());
		insuranceRenewalItem = insuranceRenewalItemRepository.save(insuranceRenewalItem);

		// Create Collateral Work Item entry
		insuranceRenewalItem.addCollateral(collateral);
		insuranceRenewalItem = insuranceRenewalItemRepository.save(insuranceRenewalItem);
		return insuranceRenewalItem;
	}

	/**
	 * This method is used to populate email attributes for contact/call agent
	 */
	private EmailAttributeHolder prepareAgentEmailAttr(ContactAgentDto dto, PolicyType policyType, String workflowStep){
		EmailTemplateRulerequest ruleRequest = new EmailTemplateRulerequest();
		ruleRequest.setWorflowStepId(workflowStep);
		Ordinal ordinal = contactAgentOrdinalMap.get(workflowStep);
		EmailTemplate emailTemplate = emailTemplateRetrievalService.findEmailTemplate(ruleRequest);
		ReminderType reminderType = dto.getReminderType();
		EmailDataDto emailDataDto = ctracObjectMapper.map(dto, EmailDataDto.class);
		emailDataDto.setCollateralList(new ArrayList<CollateralDto>(dto.getCollateralDtoList()));
		emailDataDto.setLoanDataList(dto.getLoanDtoList());
		emailDataDto.setTaskUniqueID(populateCollateralIDs(dto.getCollateralDtoList()));
	    emailDataDto.setReminderTypeShort(WordUtils.capitalize(reminderType.getDescription()));
	    emailDataDto.setReminderTypeShortLowerCase(reminderType.getDescription());
	    emailDataDto.setOrdinalNotice(ordinal.getOrdinalword());
	    if(ReminderType.BORROWER.equals(reminderType) || ReminderType.SBA_CONTENTS.equals(reminderType)){
	    	emailDataDto.setOptionalWord(OPTIONAL_WORD_RENEWAL);
	    }

	    EmailAttributeHolder emailAttributeHolder = createEmailContent(emailDataDto, emailTemplate);
		dto.setEmailAttributeHolder(emailAttributeHolder);
		return emailAttributeHolder;
	}

	private String populateCollateralIDs(List<CollateralDto>CollateralDtos ){
		StringBuilder sb = new StringBuilder();
		Iterator<CollateralDto> CollateralDtoIterator = CollateralDtos.iterator();
		while (CollateralDtoIterator.hasNext()) {
			CollateralDto collateralDto = CollateralDtoIterator.next();
			if (collateralDto.getRid()!= null) {
				sb.append(collateralDto.getRid().toString());
			}
			if (CollateralDtoIterator.hasNext()) {
				sb.append(", ");
			}
		}
		return sb.toString();
	}

	protected Set<String> setMarketEmailAsToEmailAddresses(List<CollateralDto> collateralDtos) {
		Set<String> marketEmailSet = new HashSet<String>();
		for (CollateralDto collateralDto : collateralDtos) {
			Collateral collateral = collateralRepository.getOne(collateralDto.getRid());
			String toAddress = floodEmailService.getMarketEmailToAddress(collateral);
			if(toAddress != null) { //market email may not be needed for CTL-no special handling
				marketEmailSet.add(toAddress);
			}
		}
        return marketEmailSet;
	}

	private void addCommonAttributes(VerifyLetterData verifyLetterData,PerfectionTask perfectionTask, TMParams TMParams) {
	     verifyLetterData.setCurrentWorkflowStep(perfectionTask.getWorkflowStep());
	     verifyLetterData.setWorkflowTransitionProcess(ProcessType.MANUAL_PROCESS.getName());
	     verifyLetterData.setTmParams(TMParams);
	     verifyLetterData.setTmTaskType(perfectionTask.getTmTaskId());
	     verifyLetterData.setCurrentReferenceDate(
	        DateFormatter.toJavaScriptDate(dateCalculator.getCurrentReferenceDate()));
	}



	/**
     * (Type of Flood Insurance obtained from the Policy Type in the Insurance Policies section of the CTRAC Collateral Screen.
     * NFIP, Accord, and Private should show as Policy.
     * If at least one Loan Type is SBA and Policy then show SBA Contents Policy)
     */
	private ReminderType getReminderType(PolicyType policyType, Boolean isSBALoan) {
		ReminderType reminderType = null;
		if(PolicyType.APPLICATION == policyType){
			reminderType = ReminderType.APPLICATION;
		}
		else if(PolicyType.BINDER == policyType){
			reminderType = ReminderType.BINDER;
		}
		else if(policyType.isPolicy() && isSBALoan){
			reminderType = ReminderType.SBA_CONTENTS;
		}
		else if(policyType.isPolicy() && !isSBALoan){
			reminderType = ReminderType.BORROWER;
		}
		return reminderType;
	}

   private boolean containsSBALoan(List<CollateralDto> collateralDtoList){
		for(CollateralDto collateralDto: collateralDtoList){
			for(LoanData loanBorrower : collateralDto.getLoansData()){
				if(loanBorrower.getLoanType().equals("SBA")){
					return true;
				}
			}
		}
		return false;
	}


	protected InsuranceRenewalItem createFloodInsuranceItem() {
		InsuranceRenewalItem floodInsuranceItem = new InsuranceRenewalItem();
		floodInsuranceItem.setWorkFlowID(TaskUniqueIdGenerator.generateAlphaNumericUniqueId(TaskUniqueIdGenerator.CORRELEATION_ID_LENGTH, taskUniqueIdSeqFetcher));
		floodInsuranceItem.setInitiationDate(dateCalculator.getCurrentReferenceDate());
		floodInsuranceItem.setPerfectionType(PerfectionItemType.FLOOD_POLICY.name());
		floodInsuranceItem.setPerfectionSubType(PerfectionItemSubType.FLOOD_RENEWAL.name());
		floodInsuranceItem.setInitialAuditInfo("SYSTEM");
		return floodInsuranceItem;
	}



	protected EmailDataDto prepareBankerEmailDetailsDto(ProofOfCoverageDTO proofOfCoverageDto, List<CollateralDto> collateralDtos, List<LoanData> loanData, ReminderType reminderType) {
		EmailDataDto emailDataDto = new EmailDataDto();
		emailDataDto.setInsuredName(proofOfCoverageDto.getInsuredName());
		emailDataDto.setPolicyNumber(proofOfCoverageDto.getPolicyNumber());
		emailDataDto.setExpirationDate(proofOfCoverageDto.getExpirationDate());
		emailDataDto.setCollateralList(collateralDtos);
		emailDataDto.setTaskUniqueID(populateCollateralIDs(collateralDtos));
		emailDataDto.setLoanDataList(loanData);
	    emailDataDto.setReminderTypeShort(WordUtils.capitalize(reminderType.getDescription()));
	    emailDataDto.setReminderTypeShortLowerCase(reminderType.getDescription());
		if (ReminderType.BORROWER.equals(reminderType) || ReminderType.SBA_CONTENTS.equals(reminderType)) {
			// adding a comment for Crucible testing, can remove later...
			emailDataDto.setReminderTypeAction("renew");
		} else {
			emailDataDto.setReminderTypeAction("provide");
		}
		return emailDataDto;
	}


}
