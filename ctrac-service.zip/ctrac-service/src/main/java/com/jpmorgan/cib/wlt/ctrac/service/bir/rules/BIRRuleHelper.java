package com.jpmorgan.cib.wlt.ctrac.service.bir.rules;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRInsurableAssetDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public class BIRRuleHelper {

	public static final Set<String> BUILDING_COVERAGE_CODES =
			new HashSet<String>(Arrays.asList("CB","CCD","RB", "RCD", "RCO", "RMU", "RMH"));
	public static final Set<String> BUILDING_AND_CONTENTS_COVERAGE_CODES =
			new HashSet<String>(Arrays.asList("CBC", "CCC", "RBC"));
	public static final Set<String> CONTENTS_COVERAGE_CODES =
			new HashSet<String>(Arrays.asList("CCT", "RCT"));
	
	public static boolean isCondoAssociationPolicy(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		return "Yes".equals(borrowerInsuranceReviewData.getCondoAssociationPolicy());
	}
	
	public static boolean hasBuildingCoverage(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		return hasCoverageCategory(borrowerInsuranceReviewData, CoverageCategory.BUILDING);
	}
	
	public static boolean hasContentsCoverage(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		return hasCoverageCategory(borrowerInsuranceReviewData, CoverageCategory.CONTENTS);
	}
	
	private static boolean hasCoverageCategory(
			BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, CoverageCategory coverageCategory) {
		for (BIRCollateralDetailsDTO birCollateralDetails : borrowerInsuranceReviewData.getCollateralDetailsMap().values()) {
			for (BIRInsurableAssetDetailsDTO birInsurableAssetDetails : birCollateralDetails.getInsurableAssetDetailsMap().values()) {
				CoverageCategory thisCoverageCategory =
						BIRRuleHelper.getCoverageCategory(birInsurableAssetDetails.getPropertyType());
				if (thisCoverageCategory == coverageCategory ||
						thisCoverageCategory == CoverageCategory.BUILDING_AND_CONTENTS) {
					return true;
				}
			}
		}
		return false;
	}

	private static CoverageCategory getCoverageCategory(String coverageCode) {
		if (StringUtils.isBlank(coverageCode)) {
			return null;
		}
		
		coverageCode = coverageCode.trim().toUpperCase();
		if (BUILDING_COVERAGE_CODES.contains(coverageCode)){
			return CoverageCategory.BUILDING;
		} else if (BUILDING_AND_CONTENTS_COVERAGE_CODES.contains(coverageCode)){
			return CoverageCategory.BUILDING_AND_CONTENTS;
		} else if(CONTENTS_COVERAGE_CODES.contains(coverageCode)){
			return CoverageCategory.CONTENTS;
		}
		
		return null;
	}
	
	private enum CoverageCategory {
		BUILDING,
		BUILDING_AND_CONTENTS,
		CONTENTS;
	}
	
}
