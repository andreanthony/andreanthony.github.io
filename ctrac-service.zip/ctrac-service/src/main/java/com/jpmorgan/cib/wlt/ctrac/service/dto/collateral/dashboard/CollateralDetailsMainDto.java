package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPIType;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;

public class CollateralDetailsMainDto implements Serializable {

	private static final long serialVersionUID = 1697473789253167736L;

	@Valid
	private CollateralDto collateralDto;

	private CollateralSectionDto collateralSectionDto = new CollateralSectionDto();

	private LoanBorrowerSectionDto loanBorrowerSectionData = new LoanBorrowerSectionDto();

	private InsurancePoliciesSectionDto insuranceSectionData = new InsurancePoliciesSectionDto();

	private WorkflowDetailsSectionDto workflowDetailsData = new WorkflowDetailsSectionDto();

	private FloodDeterminationSectionDto floodDeterminationSectionDto = new FloodDeterminationSectionDto();

	private RequiredCoverageSectionDto requiredCoverageSectionDto = new RequiredCoverageSectionDto();

	private String saveStatus = "";

	private boolean isReviewCollateral;

	private String displayMsg = null;

	private boolean readOnlyUserRole = false;

	private Map<Long, String> collateralDescriptions = new HashMap<Long, String>();

	private TMParams tmParams;

	private boolean showDeleteCollateral = false;

	public boolean isReviewCollateral() {
		return isReviewCollateral;
	}

	public void setReviewCollateral(boolean isReviewCollateral) {
		this.isReviewCollateral = isReviewCollateral;
	}

	public String getCollateralDescription(Long collateralRid) {
		String collateralDescription = collateralDescriptions.get(collateralRid);
		if (collateralDescription == null) {
			return "";
		}
		return collateralDescription;
	}

	public CollateralDetailsMainDto() {}

	public CollateralDto getCollateralDto() {
		return collateralDto;
	}

	public void setCollateralDto(CollateralDto collateralDto) {
		this.collateralDto = collateralDto;
	}

	public CollateralSectionDto getCollateralSectionDto() {
		return collateralSectionDto;
	}

	public void setCollateralSectionDto(CollateralSectionDto collateralSectionDto) {
		this.collateralSectionDto = collateralSectionDto;
	}

	public LoanBorrowerSectionDto getLoanBorrowerSectionData() {
		return loanBorrowerSectionData;
	}

	public void setLoanBorrowerSectionData(LoanBorrowerSectionDto loanBorrowerData) {
		this.loanBorrowerSectionData = loanBorrowerData;
	}

	public InsurancePoliciesSectionDto getInsuranceSectionData() {
		return insuranceSectionData;
	}

	public void setInsuranceSectionData(InsurancePoliciesSectionDto insuranceSectionData) {
		this.insuranceSectionData = insuranceSectionData;
	}

	public WorkflowDetailsSectionDto getWorkflowDetailsData() {
		return workflowDetailsData;
	}

	public void setWorkflowDetailsData(WorkflowDetailsSectionDto workflowDetailsData) {
		this.workflowDetailsData = workflowDetailsData;
	}

	public String getSaveStatus() {
		return saveStatus;
	}

	public void setSaveStatus(String saveStatus) {
		this.saveStatus = saveStatus;
	}

	public FloodDeterminationSectionDto getFloodDeterminationSectionDto() {
		return floodDeterminationSectionDto;
	}

	public void setFloodDeterminationSectionDto(
			FloodDeterminationSectionDto floodDeterminationSectionDto) {
		this.floodDeterminationSectionDto = floodDeterminationSectionDto;
	}


	public RequiredCoverageSectionDto getRequiredCoverageSectionDto() {
		return requiredCoverageSectionDto;
	}

	public void setRequiredCoverageSectionDto(
			RequiredCoverageSectionDto requiredCoverageSectionDto) {
		this.requiredCoverageSectionDto = requiredCoverageSectionDto;
	}

	public boolean disableNewReqCov(){
		if(requiredCoverageSectionDto!=null && requiredCoverageSectionDto.getPendingVerificationCoverageRequirement()!= null
				&& requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().getRequiredCoverageMap()!=null
				&& !requiredCoverageSectionDto.getPendingVerificationCoverageRequirement().getRequiredCoverageMap().getInsurableAssetCoverageData().isEmpty()){
			return true;
		}
		return false;
	}

	public String getDisplayMsg() {
		return displayMsg;
	}

	public void setDisplayMsg(String displayMsg) {
		this.displayMsg = displayMsg;
	}

	public List<SectionStatusDto> getSectionStatusDtos(){
		List<SectionStatusDto> list = new ArrayList<SectionStatusDto>();
		list.add(this.getCollateralSectionDto().getSectionStatusDto());
		list.add(this.getLoanBorrowerSectionData().getSectionStatusDto());
		list.add(this.getFloodDeterminationSectionDto().getSectionStatusDto());
		list.add(this.getRequiredCoverageSectionDto().getSectionStatusDto());
		list.add(this.getInsuranceSectionData().getSectionStatusDto());
		return list;
	}

	public Map<Long, String> getCollateralDescriptions() {
		return collateralDescriptions;
	}

	public boolean isShowSFHDFMsg() {
		if (insuranceSectionData != null && insuranceSectionData.isActiveLPPolicyExpering()) {
			return true;
		}
		return false;
	}

	private boolean isSBALoanExists() {
		boolean retValue = false;
		if (loanBorrowerSectionData != null) {
			for (LoanData loanData: loanBorrowerSectionData.getActiveLoansData()) {
				//loanData.getPrimaryFlag() != null && loanData.getPrimaryFlag().equals("Yes") &&
				if (loanData.getStatus().isActive() &&
						LPIType.SBA_CONTENTS_ONLY.getShortDescription().equals(loanData.getLoanType())) {
					retValue = true;
				}
				else{
					retValue = false;
					break;
				}
			}
		}

		return retValue;
	}

	private boolean isBusinessAssestsCollateralType() {
		boolean retValue = false;
		if (collateralDto != null && collateralDto.getCollateralType() !=null && collateralDto.getCollateralType().equals(CollateralType.BUSINESS_ASSETS.getCode())) {
			retValue = true;
		}

		return retValue;
	}

	public boolean isShowUpdateRequiredCoverageMsg() {
		//if (insuranceSectionData != null && insuranceSectionData.isActiveLPPolicyExpering() &&
		if (insuranceSectionData != null && insuranceSectionData.isReviewCollateral() &&
				isBusinessAssestsCollateralType() && isSBALoanExists()) {
			return true;
		}

		return false;
	}

	public boolean isReadOnlyUserRole() {
		return readOnlyUserRole;
	}

	public void setReadOnlyUserRole(boolean readOnlyUserRole) {
		this.readOnlyUserRole = readOnlyUserRole;
	}

	public TMParams getTmParams() {
		return tmParams;
	}

	public void setTmParams(TMParams tmParams) {
		this.tmParams = tmParams;
	}

	public boolean isShowDeleteCollateral() {
		return showDeleteCollateral;
	}

	public void setShowDeleteCollateral(boolean showDeleteCollateral) {
		this.showDeleteCollateral = showDeleteCollateral;
	}

}
