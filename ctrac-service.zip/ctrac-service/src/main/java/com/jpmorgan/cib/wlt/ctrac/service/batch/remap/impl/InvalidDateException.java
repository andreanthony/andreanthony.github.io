package com.jpmorgan.cib.wlt.ctrac.service.batch.remap.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileException;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.Date;

/**
 * Created by E704298 on 8/1/2017.
 */
public class InvalidDateException implements RemapFileException {

    private RemapVendor remapVendor;
    private Date fileDate;
    private static final DateTimeFormatter formatter = DateTimeFormat.forPattern("MM/dd/YYYY");

    public InvalidDateException(RemapVendor remapVendor, Date fileDate) {
        this.remapVendor = remapVendor;
        this.fileDate = fileDate;
    }

    @Override
    public String getMessage() {
        return "Weekly remap file from " + remapVendor.getDisplayName() +
                " was received with an invalid date of " + formatter.print(fileDate.getTime()) +
                " and the file was processed.";
    }

    public RemapVendor getRemapVendor() {
        return remapVendor;
    }

    public Date getFileDate() {
        return fileDate;
    }
}
