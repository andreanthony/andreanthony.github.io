package com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by i569445 on 6/7/2016.
 */
@XmlRootElement(name="getEntitledPrincipalsResponse")
public class GetEntitledPrincipalsResponse {

    List<PrPrincipalInfo> entitledPrincipals;

    @XmlElement(name = "PrPrincipalInfo")
    public List<PrPrincipalInfo> getEntitledPrincipals() {
        if(entitledPrincipals == null) {
            entitledPrincipals = new ArrayList<PrPrincipalInfo>();
        }
        return entitledPrincipals;
    }

    public void setEntitledPrincipals(List<PrPrincipalInfo> entitledPrincipals) {
        this.entitledPrincipals = entitledPrincipals;
    }
}
