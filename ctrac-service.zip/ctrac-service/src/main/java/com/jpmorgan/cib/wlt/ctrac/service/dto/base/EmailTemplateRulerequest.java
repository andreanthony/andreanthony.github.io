package com.jpmorgan.cib.wlt.ctrac.service.dto.base;



/**
 * @author N595724
 *
 *Wrapper Object used to specify the query criteria needed to load the email template
 *
 *All elements are optional but at least one must be provided depending on the attributes needed to uniquely 
 *identify the email template
 *
 */
public class EmailTemplateRulerequest{
	
	/**
	 */
	private String ruleName;
	private String lob;
	private String emailTemplateId;
	private String worflowStepId;
	private String typeId;
	private String others;
	private String additionalInfo;
	
	private String remapType;
	private String status;
	private String escalation;
	private String emailCategory;

	public static String NO_EXCEPTIONS = "NO-EXCPT";
	
	public EmailTemplateRulerequest(){
		
	}
	
	public EmailTemplateRulerequest(String typeId, String worflowStepId){
		this.typeId = typeId;
		this.worflowStepId = worflowStepId;
	}
	
	public EmailTemplateRulerequest(String emailTemplateId, String worflowStepId, String typeId){
		this(emailTemplateId,worflowStepId);
		this.typeId =typeId;
	}
	
	/**
	 * @return the ruleName
	 */
	public String getRuleName() {
		return ruleName;
	}
	/**
	 * @param ruleName the ruleName to set
	 */
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}
	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}
	/**
	 * @return the emailTemplateId
	 */
	public String getEmailTemplateId() {
		return emailTemplateId;
	}
	/**
	 * @param emailTemplateId the emailTemplateId to set
	 */
	public void setEmailTemplateId(String emailTemplateId) {
		this.emailTemplateId = emailTemplateId;
	}
	/**
	 * @return the worflowStepId
	 */
	public String getWorflowStepId() {
		return worflowStepId;
	}
	/**
	 * @param worflowStepId the worflowStepId to set
	 */
	public void setWorflowStepId(String worflowStepId) {
		this.worflowStepId = worflowStepId;
	}
	/**
	 * @return the typeId
	 */
	public String getTypeId() {
		return typeId;
	}
	/**
	 * @param typeId the typeId to set
	 */
	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}
	/**
	 * @return the others
	 */
	public String getOthers() {
		return others;
	}
	/**
	 * @param others the others to set
	 */
	public void setOthers(String others) {
		this.others = others;
	}
	/**
	 * @return the additionalInfo
	 */
	public String getAdditionalInfo() {
		return additionalInfo;
	}
	/**
	 * @param additionalInfo the additionalInfo to set
	 */
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

    /**
     * @return the remapType
     */
    public String getRemapType() {
        return remapType;
    }

    /**
     * @param remapType the remapType to set
     */
    public void setRemapType(String remapType) {
        this.remapType = remapType;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the escalation
     */
    public String getEscalation() {
        return escalation;
    }

    /**
     * @param escalation the escalation to set
     */
    public void setEscalation(String escalation) {
        this.escalation = escalation;
    }

    /**
     * @return the emailCategory
     */
    public String getEmailCategory() {
        return emailCategory;
    }

    /**
     * @param emailCategory the emailCategory to set
     */
    public void setEmailCategory(String emailCategory) {
        this.emailCategory = emailCategory;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder
       .append("EmailTemplateRulerequest [ruleName=")
       .append(ruleName)
       .append(", lob=")
       .append(lob)
       .append(", emailTemplateId=")
       .append(emailTemplateId)
       .append(", worflowStepId=")
       .append(worflowStepId)
       .append(", typeId=")
       .append(typeId)
       .append(", others=")
       .append(others)
       .append(", additionalInfo=")
       .append(additionalInfo)
       .append(", remapType=")
       .append(remapType)
       .append(", status=")
       .append(status)
       .append(", escalation=")
       .append(escalation)
       .append(", emailCategory=")
       .append(emailCategory)
       .append("]");
        return builder.toString();
    }
	
	
}
