package com.jpmorgan.cib.wlt.ctrac.service.batch.remap.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.RemapVendor;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileException;
import com.jpmorgan.cib.wlt.ctrac.service.batch.remap.RemapFileExceptionSender;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import microsoft.exchange.webservices.data.Importance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by E704298 on 8/3/2017.
 */
@Service
public class RemapFileExceptionSenderImpl implements RemapFileExceptionSender{

    private static final String REMAP_FILE_EXCEPTION_SUBJECT_PREFIX = "Error in LOL Remap File from ";
    private static final String EMAIL_NEW_LINE = "<br/>";

    @Resource
    private Environment env;

    @Autowired
    private CtracEmailSender ctracEmailSender;

    @Override
    public void sendExceptions(RemapVendor remapVendor, List<RemapFileException> remapFileExceptions) {
        if (remapFileExceptions == null || remapFileExceptions.isEmpty()) {
            return;
        }
        String toAddress = env.getRequiredProperty("autocopy.email.address.flood.service");
        String ccAddress = env.getRequiredProperty("product.owner.team.email");
        StringBuilder emailBody = new StringBuilder();
        for (RemapFileException exception : remapFileExceptions) {
            emailBody.append(exception.getMessage()).append(EMAIL_NEW_LINE);
        }
        ctracEmailSender.sendAlertEmail(toAddress, ccAddress, REMAP_FILE_EXCEPTION_SUBJECT_PREFIX + remapVendor.getDisplayName(),
                emailBody.toString(), null, Importance.Normal);
    }
}
