package com.jpmorgan.cib.wlt.ctrac.service.event.service.request;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;

public interface PublishEventRequest {
    String SYSTEM = "SYSTEM";

    CollateralEventType getCollateralEventType();

    String getDescription();

    String getIdentifier();

    Long getCollateralRid();

    String getLineOfBusiness();

    String getUser();

    String getTaskName();
}
