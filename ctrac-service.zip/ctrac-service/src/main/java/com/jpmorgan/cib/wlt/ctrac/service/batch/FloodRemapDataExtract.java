/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.service.batch;

/**
 * @author Q003321
 *
 */
public interface FloodRemapDataExtract {	
	
	//to load data from Service link xml or corelogic data to TLCP_SL_FLOOD_REMAP staging table
	void processRemapFiles();
	//to save daily recieved files to there respective staging table
	void processDataLoad();
	
	void processAlthansResponse();
	
	void processAlthansCertificateFile();

}
