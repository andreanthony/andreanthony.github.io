package com.jpmorgan.cib.wlt.ctrac.service.dto.admin;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FileserverDTO implements Serializable {

	private static final long serialVersionUID = -4811827055010718697L;

	private String propertyKey;

	private String label;

	private List<FileDTO> files = new ArrayList<FileDTO>();

	public FileserverDTO(String propertyKey, File landingDirectory, String label) {
		this.propertyKey = propertyKey;
		this.label = label;

		File[] landingDirectoryFiles = landingDirectory.listFiles();
		for (File file : landingDirectoryFiles) {
			addFile(file);
		}
		sortByLastModified();
	}

	public final void addFile(File file) {
		files.add(new FileDTO(file));
	}

	public final void sortByLastModified() {
		Collections.sort(files, new Comparator<FileDTO>() {
			@Override
			public int compare(FileDTO o1, FileDTO o2) {
				if (o1.getFile().lastModified() > o2.getFile().lastModified()) {
					return -1;
				} else if (o1.getFile().lastModified() < o2.getFile().lastModified()) {
					return 1;
				}
				return 0;
			}});
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public List<FileDTO> getFiles() {
		return files;
	}

	public File getFile(String fileName) {
		for (FileDTO file : files) {
			if (file.getFileName().equals(fileName)) {
				return file.getFile();
			}
		}
		return null;
	}

	public String getPropertyKey() {
		return propertyKey;
	}

	public void setPropertyKey(String propertyKey) {
		this.propertyKey = propertyKey;
	}
}
