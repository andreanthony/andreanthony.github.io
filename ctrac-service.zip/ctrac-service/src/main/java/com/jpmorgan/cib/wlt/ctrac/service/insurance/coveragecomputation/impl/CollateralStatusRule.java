package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionRequest;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionResult;

/**
 * @author n595724
 *
 */
public  class CollateralStatusRule extends CollateralCoverageRule {
	
	
	public  CollateralStatusRule(Collateral collateral, WorkItem triggerWorkItem, Date today ){
		super(collateral,triggerWorkItem, today);
	}
	
	/**
	 * The collateral status must indicate it is ready for coverage computations
	 */
	@Override
	public void execute(CoverageActionRequest coverageActionRequest, CoverageActionResult gobalResuls) {
		
		init();
		
		CollateralStatus colStatus = CollateralStatus.valueOf(collateral.getCollateralStatus());
		/**
		 * We do not need coverage for a collateral that is release;
		 */
		//TODO check is something need to be done for Draft collateral
		if(CollateralStatus.RELEASED == colStatus){
		  Date cancellationEffDate = collateral.getReleaseDate();
		  
		  //TODO ask what to to
		  if(cancellationEffDate ==null){
			  cancellationEffDate =today;
		  }
		  prepareCancelCollateralLpPolicies(gobalResuls, cancellationEffDate , CancellationReason.COLLATERAL_RELEASED);
		  return;
	    }
		
		/**
		 * Do not do anything for draft collateral
		 */
		if(CollateralStatus.DRAFT == colStatus){
			gobalResuls.setMoreActionsNeeded(false);
			return;
		}
	}

	@Override
	public Integer getPriority() {
		return 1100;
	}

}
