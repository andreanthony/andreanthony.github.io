package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.*;

public class FloodRemapDto extends CtracBaseHelperData implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    public static final String screenID = CtracAppConstants.FLOOD_REMAP_NEW_RECORD_SCREEN_ID;


    private String tmTaskId;

    @NoInvalidCharacters
    protected String borrowerName;
    @NoInvalidCharacters
    protected String loanNumber;

    private String lineOfBusiness;
    @NoInvalidCharacters
    protected String propertyAddress;
    @NoInvalidCharacters
    private String city;
    
    private String stateCode;
    @NoInvalidCharacters
    private String zipcode;
    
    private String revisedFloodZone;
    
    protected String remapType;

    protected String sourceSystemName;
    
    private String comments;
   
    private String taskType;
    
    private  MultipartFile SFHDF;

    private List<LineOfBusinessDTO> lineOfBusinesses;
    
    private  Date  dateMapChange;
    
    private Date dateOfDetermination;
    
    private String remapCategory;
    /**
     * @return the borrowerName
     */
    public String getBorrowerName() {
        return borrowerName;
    }

    /**
     * @return the loanNumber
     */
    public String getLoanNumber() {
        return loanNumber;
    }

    /**
     * @return the propertyAddress
     */
    public String getPropertyAddress() {
        return propertyAddress;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @return the statecode
     */
    public String getStateCode() {
        return stateCode;
    }

    /**
     * @return the zipcode
     */
    public String getZipcode() {
        return zipcode;
    }

    /**
     * @param borrowerName the borrowerName to set
     */
    public void setBorrowerName(String borrowerName) {
        this.borrowerName = borrowerName;
    }

    /**
     * @param loanNumber the loanNumber to set
     */
    public void setLoanNumber(String loanNumber) {
        this.loanNumber = loanNumber;
    }

    /**
     * @param propertyAddress the propertyAddress to set
     */
    public void setPropertyAddress(String propertyAddress) {
        this.propertyAddress = propertyAddress;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @param statecode the statecode to set
     */
    public void setStateCode(String statecode) {
        this.stateCode = statecode;
    }

    /**
     * @param zipcode the zipcode to set
     */
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    protected List<LookUpCode> remapTypes;
    
    private List<LookUpCode> sourceSystemNames;
    
    private List<LookUpCode> revisedFloodZones;

    protected List<LookUpCode> stateCodes;
    
    
    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<LineOfBusinessDTO> getLineOfBusinesses() {
        return lineOfBusinesses;
    }

    public void setLineOfBusinesses(List<LineOfBusinessDTO> lineOfBusinesses) {
        this.lineOfBusinesses = lineOfBusinesses;
    }

    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public List<LookUpCode> getRevisedFloodZones() {
        return revisedFloodZones;
    }

    public void setRevisedFloodZones(List<LookUpCode> revisedFloodZones) {
        this.revisedFloodZones = revisedFloodZones;
    }

    public String getRevisedFloodZone() {
        return revisedFloodZone;
    }

    public void setRevisedFloodZone(String revisedFloodZone) {
        this.revisedFloodZone = revisedFloodZone;
    }

    public String getRemapCategory() {
		return remapCategory;
	}

	public void setRemapCategory(String remapCategory) {
		this.remapCategory = remapCategory;
	}

	public String getTmTaskId() {
        return tmTaskId;
    }

    public void setTmTaskId(String tmTaskId) {
        this.tmTaskId = tmTaskId;
    }

    public String getScreenId() {
        return screenID;
    }

    public List<LookUpCode> getRemapTypes() {
        return remapTypes;
    }

    public void setRemapTypes(List<LookUpCode> remapTypes) {
        this.remapTypes = remapTypes;
    }

    public List<LookUpCode> getSourceSystemNames() {
        return sourceSystemNames;
    }

    public void setSourceSystemNames(List<LookUpCode> sourceSystemNames) {
        this.sourceSystemNames = sourceSystemNames;
    }
    
    /**
     * @return the remapType
     */
    public String getRemapType() {
        return remapType;
    }

    /**
     * @return the stateCodes
     */
    public List<LookUpCode> getStateCodes() {
        return stateCodes;
    }

    /**
     * @param remapType the remapType to set
     */
    public void setRemapType(String remapType) {
        this.remapType = remapType;
    }

    /**
     * @param stateCodes the stateCodes to set
     */
    public void setStateCodes(List<LookUpCode> stateCodes) {
        this.stateCodes = stateCodes;
    }

    /**
     * Set used on the front end as "select options " to display to the user. it
     * either LookUpCode.description, or LookUpCode.code
     * 
     * @return
     */
    public Set<String> getLineOfBusinessOptions() {
        SortedSet<String> response = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        if (lineOfBusinesses != null) {
            for (LineOfBusinessDTO entry : lineOfBusinesses) {
                response.add(entry.getDescription());
            }
        }
        return response;
    }

    /**
     * Set used on the front end as "select options " to display to the user. it
     * either LookUpCode.description, or LookUpCode.code
     * 
     * @return Set<LookUpCode.description >
     */
    public Set<String> getRemapTypeOptions() {
        Set<String> result = getAllOptionsAsSetFromList(remapTypes, "description");
        result.remove("No_Change");
        return result;
    }

    public Set<String> getSourceSystemNameOptions() {
        Set<String> result = getAllOptionsAsLinkedHashSetFromList(sourceSystemNames, "description");
        result.remove("No_Change");
        return result;
    }

    /**
     * Set used on the front end as "select options " to display to the user. it
     * either LookUpCode.description, or LookUpCode.code
     * 
     * @return Set <LookUpCode.code>
     */
    public Set<String> getStateOptions() {
        return getAllOptionsAsSetFromList(stateCodes, "code");
    }

    /**
     * Set used on the front end as "select options " to display to the user. it
     * either LookUpCode.description, or LookUpCode.code
     * 
     * @return Set<LookUpCode.code>
     */
    public Set<String> getRevisedFloodZoneOptions(String currentRemapType) {
        List<LookUpCode> floodZonesByRemapType = new ArrayList<LookUpCode>();
        for (LookUpCode floodZone : revisedFloodZones) {
            if (floodZone.getDescription().equalsIgnoreCase(currentRemapType)) {
                floodZonesByRemapType.add(floodZone);
            }
        }
        return getAllOptionsAsSetFromList(floodZonesByRemapType, "code");
    }

    /**
     * mapping back the front end display value (description) to the actual code
     * 
     * @return
     */
    public String getLineOfBusinessCodeFromDescr() {
        if (!StringUtils.isBlank(lineOfBusiness)) {
            for (LineOfBusinessDTO entry : lineOfBusinesses) {
                if (lineOfBusiness.equals(entry.getDescription())) {
                    return entry.getCode();
                }
            }
        }
        return null;
    }

    /**
     * mapping back the front end display value (description) to the actual code
     * 
     * @return
     */
    public String getStatusChangeCodeFromDescr() {
        LookUpCode entry = getFieldEntryFormSet(remapTypes, "description", remapType);
        return entry != null ? entry.getCode() : null;
    }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public void setSFHDF(MultipartFile multipartFile) {
       this.SFHDF = multipartFile;
        
    }
    /**
     * @return the sFHDF
     */
    public MultipartFile getSFHDF() {
        return SFHDF;
    }

    public Date getDateMapChange() {
        return dateMapChange;
    }

    public void setDateMapChange(Date dateMapChange) {
        this.dateMapChange = dateMapChange;
    }
        
    public Date getDateOfDetermination() {
		return dateOfDetermination;
	}

	public void setDateOfDetermination(Date dateOfDetermination) {
		this.dateOfDetermination = dateOfDetermination;
	}

	protected Set <String> getAllOptionsAsSetFromList( List<LookUpCode> input, String accessKeyType ){
        SortedSet <String> response = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
        if(input!=null){
            for(LookUpCode entry :input ){
                if("description".equalsIgnoreCase(accessKeyType)){
                    response.add(entry.getDescription());
                }
                if("code".equalsIgnoreCase(accessKeyType)){
                    response.add(entry.getCode());
                }
                //TODO need more?
            }
        }
        return response;
    }
    
    protected Set <String> getAllOptionsAsLinkedHashSetFromList( List<LookUpCode> input, String accessKeyType ){
        Set <String> response = new LinkedHashSet<String>();
        if(input!=null){
            for(LookUpCode entry :input ){
                if("description".equalsIgnoreCase(accessKeyType)){
                    response.add(entry.getDescription());
                }
                if("code".equalsIgnoreCase(accessKeyType)){
                    response.add(entry.getCode());
                }
                //TODO need more?
            }
        }
        return response;
    }
    protected LookUpCode getFieldEntryFormSet(List<LookUpCode> input, String accessKeyType, String keyValue){
        
        if(input!=null && !StringUtils.isBlank(keyValue)){
            for(LookUpCode entry :input ){
                if("description".equalsIgnoreCase(accessKeyType)){
                    if(keyValue.equals(entry.getDescription()) )
                        return entry;
                }
                if("code".equalsIgnoreCase(accessKeyType)){
                    if(keyValue.equals(entry.getCode()) )
                        return entry;
                }
                //TODO need more?
            }
        }
        return null;
    }
    

}
