package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

public class HoldDetailsViewDto implements Serializable {
	
	private static final long serialVersionUID = 3953244370852597689L;
			
	private Long holdRid;
	private Long collateralRid;
	private Long parentWorkItemRid;
	private String coverageType;
	private String buildingName;
	private Long parentHoldRid;
	private String holdType;	
	private String startDate;	
	private String holdPeriod;
	private String lpiDate;
    private String holdPeriodExpirationDate;
    private Long insurableAssetRid;
	private String insurableAssetType;

	public Long getHoldRid() {
		return holdRid;
	}
	public void setHoldRid(Long holdRid) {
		this.holdRid = holdRid;
	}
	public Long getCollateralRid() {
		return collateralRid;
	}
	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}
	public Long getParentWorkItemRid() {
		return parentWorkItemRid;
	}
	public void setParentWorkItemRid(Long parentWorkItemRid) {
		this.parentWorkItemRid = parentWorkItemRid;
	}
	public String getCoverageType() {
		return coverageType;
	}
	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public Long getParentHoldRid() {
		return parentHoldRid;
	}
	public void setParentHoldRid(Long parentHoldRid) {
		this.parentHoldRid = parentHoldRid;
	}
	public String getHoldType() {
		return holdType;
	}
	public void setHoldType(String holdType) {
		this.holdType = holdType;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getHoldPeriod() {
		return holdPeriod;
	}
	public void setHoldPeriod(String holdPeriod) {
		this.holdPeriod = holdPeriod;
	}
	public String getLpiDate() {
		return lpiDate;
	}
	public void setLpiDate(String lpiDate) {
		this.lpiDate = lpiDate;
	}

    public String getHoldPeriodExpirationDate() {
        return holdPeriodExpirationDate;
    }

    public void setHoldPeriodExpirationDate(String holdPeriodExpirationDate) {
        this.holdPeriodExpirationDate = holdPeriodExpirationDate;
    }

	public Long getInsurableAssetRid() { return insurableAssetRid;	}

	public void setInsurableAssetRid(Long assetRid) {
		this.insurableAssetRid = assetRid;
	}

	public String getInsurableAssetType() {
		return insurableAssetType;
	}

	public void setInsurableAssetType(String assetType) {
		this.insurableAssetType = assetType;
	}

}
