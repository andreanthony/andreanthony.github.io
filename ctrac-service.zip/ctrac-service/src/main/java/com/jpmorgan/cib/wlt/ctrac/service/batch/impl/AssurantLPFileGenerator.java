package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import java.util.Collection;

import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LPPolicyRequestViewData;
import com.jpmorgan.cib.wlt.ctrac.service.batch.LPVendorFileGenerator;

@Service("assurantLPFileGenerator")
public class AssurantLPFileGenerator implements LPVendorFileGenerator {

	@Override
	public Collection<LPPolicyRequest> generateLpPolicyRequest(Collection<LPPolicyRequestViewData> lpPolicyViewData) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLpRequestCode() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLpCancellationCode() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLpRenewalCode() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isNewOrRenewalPolicyRequest(String transCode) {
		// TODO Auto-generated method stub
		return false;
	}

}
