package com.jpmorgan.cib.wlt.ctrac.service.dto.builder;

import java.util.Collection;

import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsuranceCoverageMap;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProvidedCoverageDTO;

@Service
public class InsuranceCoverageMapFactoryImpl implements InsuranceCoverageMapFactory {
    
    @Override
    public InsuranceCoverageMap<ProvidedCoverageDTO> getProvidedInsuranceCoverageMap(
            Collection<ProvidedCoverageDTO> providedCoverageDTOs) {
        InsuranceCoverageMap<ProvidedCoverageDTO> providedInsuranceCoverageMap =
                new InsuranceCoverageMap<ProvidedCoverageDTO>(ProvidedCoverageDTO.class);
        if (providedCoverageDTOs != null) {
            for (ProvidedCoverageDTO providedCoverageDTO : providedCoverageDTOs) {
                providedInsuranceCoverageMap.put(providedCoverageDTO);
            }
        }
        return providedInsuranceCoverageMap;
    }
    
}
