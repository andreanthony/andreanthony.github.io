package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.DB_FLAG_NO;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.DB_FLAG_YES;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.UI_FLAG_FALSE;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.UI_FLAG_TRUE;

import java.io.Serializable;
import java.util.Date;

import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;

public class FloodRenewalData implements Serializable {

    private static final long serialVersionUID = -7845691777670192598L;
    
    private Long rid;
    private String loanActive;
    private String loanActiveRadio;
    private String reminderType;
    private String ticklerID;
    private String ticklerComments;
    private String lpCancellationDateComment;
    private String lpEffectiveDate;
    private Date preRenewalLetterDate;
    private ProofOfCoverageDTO proofOfCoverageData;
    
    public Long getRid() {
        return rid;
    }
    
    public void setRid(Long rid) {
        this.rid = rid;
    }
    
    public String getLoanActive() {
        return loanActive;
    }
    
    public void setLoanActive(String loanActive) {
        this.loanActive = loanActive;
    }

    public String getLoanActiveRadio() {
        return loanActiveRadio;
    }

    public void setLoanActiveRadio(String loanActiveRadio) {
        this.loanActiveRadio = loanActiveRadio;
        if (UI_FLAG_TRUE.equalsIgnoreCase(this.loanActiveRadio)) {
            this.loanActive = DB_FLAG_YES.toString();
        } else if (UI_FLAG_FALSE.equalsIgnoreCase(this.loanActiveRadio)) {
            this.loanActive = DB_FLAG_NO.toString();
        }
    }
    
    public String getReminderType() {
        return reminderType;
    }
    
    public void setReminderType(String reminderType) {
        this.reminderType = reminderType;
    }
    
    public String getTicklerID() {
        return ticklerID;
    }
    
    public void setTicklerID(String ticklerID) {
        this.ticklerID = ticklerID;
    }
    
    public String getTicklerComments() {
        return ticklerComments;
    }
    
    public void setTicklerComments(String ticklerComments) {
        this.ticklerComments = ticklerComments;
    }
    
    public String getLpCancellationDateComment() {
        return lpCancellationDateComment;
    }
    
    public void setLpCancellationDateComment(String lpCancellationDateComment) {
        this.lpCancellationDateComment = lpCancellationDateComment;
    }
    
    public Date getPreRenewalLetterDate() {
        return preRenewalLetterDate;
    }
    
    public void setPreRenewalLetterDate(Date preRenewalLetterDate) {
        this.preRenewalLetterDate = preRenewalLetterDate;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((rid == null) ? 0 : rid.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        FloodRenewalData other = (FloodRenewalData) obj;
        if (rid == null) {
            if (other.rid != null)
                return false;
        } else if (!rid.equals(other.rid))
            return false;
        return true;
    }

	public ProofOfCoverageDTO getProofOfCoverageData() {
		return proofOfCoverageData;
	}

	public void setProofOfCoverageData(ProofOfCoverageDTO proofOfCoverageData) {
		this.proofOfCoverageData = proofOfCoverageData;
	}

	public String getLpEffectiveDate() {
		return lpEffectiveDate;
	}

	public void setLpEffectiveDate(String lpEffectiveDate) {
		this.lpEffectiveDate = lpEffectiveDate;
	}

}
