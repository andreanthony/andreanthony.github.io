package com.jpmorgan.cib.wlt.ctrac.service.bir.impl;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CREATE_PIA_REQUEST;

import java.util.HashMap;
import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.service.helper.PerfectionTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProofOfCoverageWorkItemRelationType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.StateParameterType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AgentResponseItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.AgentResponseItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.ProofOfCoverageRepository;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRActionRequiredService;
import com.jpmorgan.cib.wlt.ctrac.service.command.impl.EmailNotificationCommand;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationType;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TaskUniqueIdGenerator;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;

@Service
public class BIRActionRequiredServiceImpl implements BIRActionRequiredService {
	
	private static final int REMAP_TASK_UNIQUE_ID_LENGTH = 6;
	@Autowired private AgentResponseItemRepository agentResponseItemRepository;

	@Autowired private AuditInformationService auditInformationService;
	
	@Autowired private CalendarDayUtil calendarDayUtil;

    @Autowired private PerfectionTaskService perfectionTaskService;

	@Autowired private ProofOfCoverageRepository proofOfCoverageRepository;
	
	@Autowired private TaskService taskService;	
	
	@Autowired private OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher;
	@Autowired private TMService tmService;
	
	@Override
	public void triggerPIAWorkflow(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		// TODO: find the item for this BIR
		AgentResponseItem agentResponseItem = getAgentResponseItem(
					borrowerInsuranceReviewData, PerfectionItemSubType.INSURANCE_EXCEPTION, null);
		try {	
			tmService.createTask(TMTaskType.FLOOD_INSURANCE, agentResponseItem,CREATE_PIA_REQUEST.getFloodRemapTaskState());
		}catch (TMServiceApplicationException ex) {
			throw new CTracApplicationException(ex.getErrorCode(), CtracErrorSeverity.APPLICATION, ex);
		}catch (Exception ex) {
			throw new CTracApplicationException("E0125", CtracErrorSeverity.APPLICATION, ex);
		}		
	}

	@Override
	public void triggerInsuranceExceptionEmailWorkflow(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		// TODO: find the item for this BIR
		AgentResponseItem agentResponseItem = getAgentResponseItem(
					borrowerInsuranceReviewData, PerfectionItemSubType.INSURANCE_EXCEPTION, null);
		triggerExceptionEmailWorkflow(borrowerInsuranceReviewData,
				agentResponseItem, WorkflowStateDefinition.POLICY_EXCEPTION_1ST_CONTACT);
	}
	
	@Override
	public void triggerZoneVarianceWorkflow(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, Long collateralRid) {
		AgentResponseItem zoneVarianceItem = getAgentResponseItem(
				borrowerInsuranceReviewData, PerfectionItemSubType.ZONE_VARIANCE, collateralRid);
		triggerExceptionEmailWorkflow(borrowerInsuranceReviewData,
				zoneVarianceItem, WorkflowStateDefinition.ZONE_VARIANCE_1ST_CONTACT);
	}
	
	
	
	@Override
	public void triggerRejectionExceptionEmails(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		
		AgentResponseItem marketItem = getAgentResponseItem(borrowerInsuranceReviewData,
				PerfectionItemSubType.AGENT, null);
		triggerExceptionEmailWorkflow(borrowerInsuranceReviewData, marketItem,
				WorkflowStateDefinition.SEND_POLICY_REJECTION_MARKET_EMAIL);		
		
		AgentResponseItem agentItem = getAgentResponseItem(borrowerInsuranceReviewData,
				PerfectionItemSubType.AGENT, null);
		triggerExceptionEmailWorkflow(borrowerInsuranceReviewData, agentItem,
				WorkflowStateDefinition.SEND_POLICY_REJECTION_AGENT_EMAIL);		
	}
	
	private AgentResponseItem getAgentResponseItem(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			PerfectionItemSubType perfectionSubType, Long collateralRid) {
		Long proofOfCoverageRid = borrowerInsuranceReviewData.getProofOfCoverageData().getRid();
		ProofOfCoverage proofOfCoverage = proofOfCoverageRepository.findOne(proofOfCoverageRid);
		AgentResponseItem agentResponseItem = 
				agentResponseItemRepository.findByProofOfCoverageRidAndCollateralRid(proofOfCoverageRid, collateralRid);
		if (agentResponseItem == null) {
			agentResponseItem = new AgentResponseItem(perfectionSubType);
			agentResponseItem.setItemCreatedDate(calendarDayUtil.getCurrentReferenceDate());
			agentResponseItem.setInitiationDate(calendarDayUtil.getCurrentReferenceDate());
			agentResponseItem.setWorkFlowID(TaskUniqueIdGenerator.generateAlphaNumericUniqueId(REMAP_TASK_UNIQUE_ID_LENGTH, taskUniqueIdSeqFetcher));
			agentResponseItem.addProofOfCoverage(proofOfCoverage,ProofOfCoverageWorkItemRelationType.AGENT_RESPONSE_TO_POLICY.name());
			agentResponseItem.setProofOfCoverageRid(proofOfCoverageRid);
			agentResponseItem.setCollateralRid(collateralRid);
			agentResponseItem = agentResponseItemRepository.save(agentResponseItem);
		}
		return agentResponseItem;
	}
	
	private void triggerExceptionEmailWorkflow(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			AgentResponseItem agentResponseItem, WorkflowStateDefinition workflowState) {
		PerfectionTask firstZoneVarianceEmailTask = createExceptionEmailTask(agentResponseItem, workflowState);
		Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
		inputParameterMap.put(StateParameterType.PERFECTION_TASK, firstZoneVarianceEmailTask);
		inputParameterMap.put(StateParameterType.BORROWER_INSURANCE_REVIEW_DATA, borrowerInsuranceReviewData);
		taskService.completeWorkFlowStepOperations(inputParameterMap);
	}
	
	@Override
	public void triggerPolicyAcceptedWithNoExceptionEmails(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {	
		Map<StateParameterType, Object> inputParameterMap = new HashMap<StateParameterType, Object>();
		inputParameterMap.put(StateParameterType.BORROWER_INSURANCE_REVIEW_DATA, borrowerInsuranceReviewData);
		
		EmailNotificationCommand enc = new EmailNotificationCommand(EmailNotificationType.INSURANCE_NO_EXCEPTION_EMAIL, inputParameterMap, -1);
		enc.execute();
	}
	
	private PerfectionTask createExceptionEmailTask(WorkItem workItem, WorkflowStateDefinition workflowState) {
		return perfectionTaskService.createTask(
				TaskStatus.TRANSIENT, workItem, workflowState.getFloodRemapTaskState(),
				TMTaskType.FLOOD_INSURANCE, auditInformationService.getLoggedInUserSid(), null);
	}

}
