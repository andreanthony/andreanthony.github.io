package com.jpmorgan.cib.wlt.ctrac.service.dto.view;

import java.util.Date;

public class BorrowerViewDetailsDto {	
	
	private Long collateralRid;
	
	private Long loanRid;		
	
	private Long borrowerRid;
	
	private String borrowerName;
	
	private String borrowerAddress;
	
	private String borrowerCity;
	
	private String borrowerState;

	private String borrowerZipCode;
	
	private String borrowerUnitBuilding;
	
	private String borrowerCreatedBy;
	
	private String borrowerLastUpdatedBy;
	
	private Date borrowerCreatedDate;
	
	private Date borrowerLastUpdatedDate;
	

	public Long getLoanRid() {
		return loanRid;
	}

	public void setLoanRid(Long loanRid) {
		this.loanRid = loanRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getBorrowerRid() {
		return borrowerRid;
	}

	public void setBorrowerRid(Long borrowerRid) {
		this.borrowerRid = borrowerRid;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getBorrowerAddress() {
		return borrowerAddress;
	}

	public void setBorrowerAddress(String borrowerAddress) {
		this.borrowerAddress = borrowerAddress;
	}

	public String getBorrowerCity() {
		return borrowerCity;
	}

	public void setBorrowerCity(String borrowerCity) {
		this.borrowerCity = borrowerCity;
	}

	public String getBorrowerState() {
		return borrowerState;
	}

	public void setBorrowerState(String borrowerState) {
		this.borrowerState = borrowerState;
	}

	public String getBorrowerZipCode() {
		return borrowerZipCode;
	}

	public void setBorrowerZipCode(String borrowerZipCode) {
		this.borrowerZipCode = borrowerZipCode;
	}

	public String getBorrowerUnitBuilding() {
		return borrowerUnitBuilding;
	}

	public void setBorrowerUnitBuilding(String borrowerUnitBuilding) {
		this.borrowerUnitBuilding = borrowerUnitBuilding;
	}

	public String getBorrowerCreatedBy() {
		return borrowerCreatedBy;
	}

	public void setBorrowerCreatedBy(String borrowerCreatedBy) {
		this.borrowerCreatedBy = borrowerCreatedBy;
	}

	public String getBorrowerLastUpdatedBy() {
		return borrowerLastUpdatedBy;
	}

	public void setBorrowerLastUpdatedBy(String borrowerLastUpdatedBy) {
		this.borrowerLastUpdatedBy = borrowerLastUpdatedBy;
	}

	public Date getBorrowerCreatedDate() {
		return borrowerCreatedDate;
	}

	public void setBorrowerCreatedDate(Date borrowerCreatedDate) {
		this.borrowerCreatedDate = borrowerCreatedDate;
	}

	public Date getBorrowerLastUpdatedDate() {
		return borrowerLastUpdatedDate;
	}

	public void setBorrowerLastUpdatedDate(Date borrowerLastUpdatedDate) {
		this.borrowerLastUpdatedDate = borrowerLastUpdatedDate;
	}
	
	public String getPropertyAddressUnitBuilding(){
		StringBuffer propAddrUnit=new StringBuffer();
		propAddrUnit.append(borrowerAddress);
		propAddrUnit.append(", ");
		propAddrUnit.append(borrowerUnitBuilding);
		return propAddrUnit.toString();
	}
	
	public String getCityStateZipCode(){
		StringBuffer cityStateZip=new StringBuffer();
		cityStateZip.append(borrowerCity);
		cityStateZip.append(", ");
		cityStateZip.append(borrowerState);
		cityStateZip.append(", ");
		cityStateZip.append(borrowerZipCode);
		return cityStateZip.toString();
	}

}
