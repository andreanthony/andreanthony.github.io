package com.jpmorgan.cib.wlt.ctrac.service.aggregate;


import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AccountWireReference;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AggregateItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WiredPolicy;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.impl.PolicyAggregationRequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.CollectWireConfirmationData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.WireRequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AccountWireReferenceDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;


public interface WireProcessingService {

	// Responsible for preparing the Collect Wire Confirmation Page
	public WireRequestData prepareCreateWireRequestPage(TMParams tmParams);

	public List<WiredPolicy> getWiredPolicyByAccountWireReference(
			AccountWireReference accountWireReference);

	byte[] generateWireDocumentByAccountWireReference(
			AccountWireReferenceDto accountWireReferenceDto, String workflowStep);

	// main method to create Wire request task and get policies that are in
	// WFSID in Approved Pending wire request
	// and add the data in wiredPolciy table and wire ref table. Also creates
	// necessary records in CTRAC and sends an IBML message
	// to TM
	public void processWiredPolicy(PolicyAggregationRequestData aggeationType);

	public AggregateItem createAggregateItem(String wflsId, PerfectionItemSubType perfectionItemSubType);

	public void processWireRequestInformation(WireRequestData wireRequestData);

	public CollectWireConfirmationData prepareCollectWireConfirmationData(TMParams tmParams);

	public void processConfirmedWiredRequest();

	void processPendingSendLOBEmailForAlthans();

	boolean isPolicyIncludedInAggregateWirePremium(LenderPlaceItem lenderPlaceItem);

}