package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import org.springframework.web.multipart.MultipartFile;

public class FileItem {

	private MultipartFile fileItem;
	private String name;
	private String taskUUId;

	public String getTaskUUId() {
		return taskUUId;
	}

	public void setTaskUUId(String taskUUId) {
		this.taskUUId = taskUUId;
	}


	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}



	public FileItem(MultipartFile fileItem, String name, String taskUUId) {
		this.fileItem = fileItem;
		this.name = name;
		this.taskUUId = taskUUId;
	}
	
	public FileItem(){
		
	}

	public MultipartFile getFileItem() {
		return fileItem;
	}

	public void setFileItem(MultipartFile fileItem) {
		this.fileItem = fileItem;
	}

	public String toString() {
		return "[   " + name + " of size  " + fileItem.getSize() + "   ]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileItem other = (FileItem) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}