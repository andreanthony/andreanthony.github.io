package com.jpmorgan.cib.wlt.ctrac.service.dto.loan;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class LoanMaintenanceLoanData implements Serializable {

	private static final long serialVersionUID = -3615835619758882211L;
	
	private Long loanRid;
	
	private String loanNumber;
	
	private String borrowerNameSearch;
	
	private String loanAccountingSystem;
	
	private String lineOfBusiness;
	
	private String loanType;
	
	private String loadedDate;
	
	private String releasedDate;
	
	private Collection<LoanMaintenanceBorrowerData> borrowerData = new ArrayList<LoanMaintenanceBorrowerData>();
	
	private Collection<LoanMaintenanceCollateralData> collateralData = new ArrayList<LoanMaintenanceCollateralData>();

	public Long getLoanRid() {
		return loanRid;
	}

	public void setLoanRid(Long loanRid) {
		this.loanRid = loanRid;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getBorrowerNameSearch() {
		return borrowerNameSearch;
	}

	public void setBorrowerNameSearch(String borrowerNameSearch) {
		this.borrowerNameSearch = borrowerNameSearch;
	}

	public String getLoanAccountingSystem() {
		return loanAccountingSystem;
	}

	public void setLoanAccountingSystem(String loanAccountingSystem) {
		this.loanAccountingSystem = loanAccountingSystem;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getLoadedDate() {
		return loadedDate;
	}

	public void setLoadedDate(String loadedDate) {
		this.loadedDate = loadedDate;
	}

	public String getReleasedDate() {
		return releasedDate;
	}

	public void setReleasedDate(String releasedDate) {
		this.releasedDate = releasedDate;
	}

	public Collection<LoanMaintenanceBorrowerData> getBorrowerData() {
		return borrowerData;
	}

	public void setBorrowerData(Collection<LoanMaintenanceBorrowerData> borrowerData) {
		this.borrowerData = borrowerData;
	}

	public Collection<LoanMaintenanceCollateralData> getCollateralData() {
		return collateralData;
	}

	public void setCollateralData(Collection<LoanMaintenanceCollateralData> collateralData) {
		this.collateralData = collateralData;
	}
	
}
