package com.jpmorgan.cib.wlt.ctrac.service.excel.definitions.wiredrequests;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WiredPolicy;
import com.jpmorgan.cib.wlt.ctrac.service.excel.ColumnDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;

import java.util.List;
import java.util.Map;

/**
 * Created by V704662 on 5/16/2017.
 */
public interface AlthansExcelWiredRequestsDefinitions {

    ColumnDefinition[] getExcelColumnDefinitions();

    Map<String, String> getWiredRequestAttributes();

    ColumnDefinition findColumnDefinitionForFieldName(String fieldName);

    List convertWiredPoliciesToExcelTableRowData(CtracObjectMapper ctracObjectMapper, List<WiredPolicy> wiredPolicies);

}
