package com.jpmorgan.cib.wlt.ctrac.service.batch;

import java.util.Collection;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LPPolicyRequestViewData;

public interface LPVendorFileGenerator {

	Collection<LPPolicyRequest> generateLpPolicyRequest(Collection<LPPolicyRequestViewData> lpPolicyViewData);
	
	String getLpRequestCode();
	
	String getLpCancellationCode();

	String getLpRenewalCode();

	boolean isNewOrRenewalPolicyRequest(String transCode);
	
}
