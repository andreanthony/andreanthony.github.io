package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;

public class LookUpCodeData implements Serializable {
	
	private static final long serialVersionUID = -6096383811748092981L;
	private Long rid;
	public Long getRid() {
		return rid;
	}
	public void setRid(Long rid) {
		this.rid = rid;
	}
	public String getCodeSet() {
		return codeSet;
	}
	public void setCodeSet(String codeSet) {
		this.codeSet = codeSet;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public Integer getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}
	private String codeSet;
	private String code;
	private String description;
	private String active;
	private Integer sortOrder;

}
