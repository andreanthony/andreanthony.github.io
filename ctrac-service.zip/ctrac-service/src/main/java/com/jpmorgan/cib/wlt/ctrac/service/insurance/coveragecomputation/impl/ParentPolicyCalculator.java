package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions.*;

public class ParentPolicyCalculator {

    private Map<LPActions, List<ProofOfCoverage>> policiesGroupedByLPAction;
    //LP Action used as priority to pick parent policy RID
    private final LinkedList<LPActions> priorityOrder = new LinkedList<>(Arrays.asList(NEW_BP, null, PENDING_C3));

    ParentPolicyCalculator(Collection<ProofOfCoverage> policies){
        policiesGroupedByLPAction = groupPoliciesByLPAction(policies);
    }

    /**
     * Group the Policies in a map together by LP Action which will be used to pick parent policy by priority
     * @param policies - Policies to calculate from
     * @return grouped map of policies by LPAction
     */
    private Map<LPActions, List<ProofOfCoverage>> groupPoliciesByLPAction(Collection<ProofOfCoverage> policies){
        HashMap<LPActions, List<ProofOfCoverage>> groupedPolicies = new HashMap<>();
        if(CollectionUtils.isNotEmpty(policies)) {
            for (ProofOfCoverage policy : policies) {
                List<ProofOfCoverage> policiesForCurrentLpAction = groupedPolicies.get(policy.getLpAction_()) == null ?
                        new ArrayList<ProofOfCoverage>() : groupedPolicies.get(policy.getLpAction_());
                policiesForCurrentLpAction.add(policy);
                groupedPolicies.put(policy.getLpAction_(),policiesForCurrentLpAction);
            }
        }
        return groupedPolicies;
    }

    /**
     * Main method of the calculator that will be called to determine the parent Policy for a given Policy DTO
     * @param coverageType - The coverage Type to lookup the parent policy for
     * @return Parent Policy
     */
    ProofOfCoverage calculateParentPolicy(CoverageType coverageType){
        for (LPActions lpAction : priorityOrder) {
            ProofOfCoverage parentPolicy = lookupParentPolicyWithPriority(lpAction, coverageType);
            if (parentPolicy != null) {
                return parentPolicy;
            }
        }
        //Did not find any policy that classify to be the parent policy
        return null;
    }

    private ProofOfCoverage lookupParentPolicyWithPriority(LPActions lpActions, CoverageType coverageType){
        if(MapUtils.isNotEmpty(policiesGroupedByLPAction)){
            List<ProofOfCoverage> policiesFound = policiesGroupedByLPAction.get(lpActions);
            List<ProofOfCoverage> filteredList = filterOutPoliciesToExclude(policiesFound, coverageType);
            if(CollectionUtils.isNotEmpty(filteredList)){
                return filteredList.get(0);
            }
        }
        return null;
    }

    /**
     * From all the policies, there will be policies that we need to exclude to determine the parent policy rid.
     * This will look over all policies and call method to verify if that policy needs to be excluded.
     * @param policies - Policies to calculate from
     * @param coverageType - The coverage Type to lookup the parent policy for
     * @return List of filtered policies
     */
    private List<ProofOfCoverage> filterOutPoliciesToExclude(List<ProofOfCoverage> policies,CoverageType coverageType){
        List<ProofOfCoverage> filteredPolicies = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(policies)) {
            for (ProofOfCoverage policy : policies) {
                if (!excludePolicyFromCalculation(policy, coverageType)) {
                    filteredPolicies.add(policy);
                }
            }
        }
        return filteredPolicies;
    }

    /**
     * Exclude policies from being a parent policy based on rules:
     * - No LP Policy can be a parent
     * - No pending verification policy can be a parent
     * - Policy with different CoverageType than the new Policy can't be a parent
     * @param policy - Policy to verify if it needs to be excluded
     * @param coverageType - The coverage Type to lookup the parent policy for
     * @return exclusion flag
     */
    private boolean excludePolicyFromCalculation(ProofOfCoverage policy, CoverageType coverageType){
        //When policy is an LP - Can't be a parent
        if (policy.getPolicyType_().isLenderPlaced()) {
            return true;
        }
        //When policy is in pending verification - Can't be a parent
        if(policy.getPolicyStatus_() == PolicyStatus.PENDING_VERIFICATION){
            return true;
        }
        //When policy coverage type is not matching from the coverage type of new Policy - Can't be a parent
        return !(policy.getCoverageType_().isMatching(coverageType));
    }
}
