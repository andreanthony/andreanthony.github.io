package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

import java.util.Set;

public interface ExternallyAgentedWorkflowService {

    int START_REVIEW_COLLATERAL_BD = 13;

    void removeExternallyAgentedCollateralsNotReady(Set<Collateral> collaterals, ProofOfCoverage proofOfCoverage);

}
