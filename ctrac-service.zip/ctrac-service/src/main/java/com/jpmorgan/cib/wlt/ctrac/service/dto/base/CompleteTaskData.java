package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.io.Serializable;
import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;


public class CompleteTaskData extends FloodRemapData implements Serializable {
	
	private static final long serialVersionUID = -232021800118654853L;	
	
	private String taskType;
	
	private List<LookUpCode> closeReasons;
	
	private Long closeReasonId;

	@NoInvalidCharacters
	private String comments;
	
	private String closeReasonCode;
	
	private String actionSaveUrl;

	private String janusUserId;
	
	//If this task is launched from CTRAC, we are using this field to hold tm task id value
	//if a task is launched from TM then taskId should be inside TMParams ->taskId
	private String tmTaskId;
	
	private String sourceAction;

	public String getTmTaskId() {
		return tmTaskId;
	}

	public void setTmTaskId(String tmTaskId) {
		this.tmTaskId = tmTaskId;
	}

	public String getJanusUserId() {
		return janusUserId;
	}

	public void setJanusUserId(String janusUserId) {
		this.janusUserId = janusUserId;
	}

	public String getCloseReasonCode() {
		return closeReasonCode;
	}

	public void setCloseReasonCode(String closeReasonCode) {
		this.closeReasonCode = closeReasonCode;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public List<LookUpCode> getCloseReasons() {
		return closeReasons;
	}

	public void setCloseReasons(List<LookUpCode> closeReasons) {
		this.closeReasons = closeReasons;
	}

	public Long getCloseReasonId() {
		return closeReasonId;
	}

	public void setCloseReasonId(Long closeReasonId) {
		this.closeReasonId = closeReasonId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	/**
	 * @return the actionSaveUrl
	 */
	public String getActionSaveUrl() {
		return actionSaveUrl;
	}

	/**
	 * @param actionSaveUrl the actionSaveUrl to set
	 */
	public void setActionSaveUrl(String actionSaveUrl) {
		this.actionSaveUrl = actionSaveUrl;
	}
	
	/**
	 * @return the sourceAction
	 */
	public String getSourceAction() {
		return sourceAction;
	}

	/**
	 * @param sourceAction the sourceAction to set
	 */
	public void setSourceAction(String sourceAction) {
		this.sourceAction = sourceAction;
	}
}
