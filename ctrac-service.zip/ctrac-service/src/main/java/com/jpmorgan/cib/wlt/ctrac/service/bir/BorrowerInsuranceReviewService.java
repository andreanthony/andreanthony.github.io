package com.jpmorgan.cib.wlt.ctrac.service.bir;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AgentResponseData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.PIARequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ReferenceValues;

public interface BorrowerInsuranceReviewService {
	
	/**
	 * Prepare a new BIR initialized with this collateral.
	 * @param collateralRid
	 * @return
	 */
	BorrowerInsuranceReviewDTO prepareNewBIR(Long collateralRid);

	/**
	 * Prepare a BIR given by a specific BIRMode. All previous values should be pre-populated except:
	 * expiration date, amounts, and conclusions.
	 * @param proofOfCoverageRid
	 * @return
	 */
	BorrowerInsuranceReviewDTO prepareBIRByBIRMode(Long proofOfCoverageRid, Long collateralRid, BIRMode birMode);

	/**
	 * Prepare a BIR that has already been saved. All fields and user-selected conclusions should
	 * be pre-populated and editable.
	 * @param proofOfCoverageRid
	 * @return
	 */
	BorrowerInsuranceReviewDTO prepareExistingBIR(Long proofOfCoverageRid, Long collateralRid);
	
	BorrowerInsuranceReviewDTO prepareExistingBIR(PerfectionTask perfectionTask);
	
	/**
	 * Prepare a BIR for verification. Non-amount fields and user-selected conclusions should be
	 * pre-populated and editable. User must re-key amounts.
	 * @param proofOfCoverageRid
	 * @return
	 */
	BorrowerInsuranceReviewDTO prepareVerifyBIR(Long proofOfCoverageRid, Long collateralRid);
	
	ReferenceValues getBorrowerInsuranceReviewReferenceValues(BIRMode birMode);
	
	void addCollateralToBIR(Long collateralId, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void removeCollateralFromBIR(Long collateralId, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	void reviewBorrowerInsurance(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, boolean isSubmitting);
	
	void submitBorrowerInsuranceReview(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);
	
	PIARequestData  preparePIARequestData(TMParams otmParams);
	
	void processPIARequestData(final PIARequestData pIARequestData);
	
	AgentResponseData getAgentResponse(TMParams otmParams);

	void deleteBorrowerInsuranceReview(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData);

	LoanData getPrimaryLoanOfBorrowerInsurance(Long collateralRid);

	boolean validateBorrowerInsurancePolicyDeletion(Long policyRid,Long collateralRid, boolean isDeleteButtonVisible);

}
