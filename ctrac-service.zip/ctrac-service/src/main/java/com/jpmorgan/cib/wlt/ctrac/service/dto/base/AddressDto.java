package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.service.validator.annotation.NoInvalidCharacters;
import org.apache.commons.lang.StringUtils;

import javax.validation.constraints.Size;
import java.io.Serializable;

public class AddressDto extends BaseDto implements Serializable, Cloneable {
	
	private static final long serialVersionUID = 1L;

	private Long rid;

	@NoInvalidCharacters
	@Size(max=255, message="{invalid.addressDto.streetAddress}")
	private String streetAddress;

	@NoInvalidCharacters
	@Size(max=255, message="{invalid.addressDto.city}")
	private String city;

	@NoInvalidCharacters
	@Size(max=255, message="{invalid.addressDto.zipCode}")
	private String zipCode;

	@Size(max=255, message="{invalid.addressDto.state}")
	private String state;
	
	@NoInvalidCharacters
	private String county;

	@NoInvalidCharacters
	private String unitOrBuilding;
	
	private AddressDto loadTimeValue;
	
	
	public Long getRid() {
		return rid;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public String getCity() {
		return city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public String getState() {
		return state;
	}

	public String getCounty() {
		return county;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public void setStreetAddress(String address) {
		this.streetAddress = address;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setCounty(String county) {
		this.county = county;
	}


	public String getUnitOrBuilding() {
		return unitOrBuilding;
	}

	public void setUnitOrBuilding(String unitOrBuilding) {
		this.unitOrBuilding = unitOrBuilding;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AddressDto other = (AddressDto) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}
	
	public String getFormattedFullAddress() {
		// 8/26/2016: updated to including unitOrBuilding
		// added TestAddressDto to test different combinations against expected output
		StringBuffer formattedFullAddress = new StringBuffer();
		CtracStringUtil.addValueWithSeparator(formattedFullAddress, getFormattedAddressLine1Sb(), "");
		CtracStringUtil.addValueWithSeparator(formattedFullAddress, getCityStateZipCodeSb(), ", ");
		return formattedFullAddress.toString();
	}
	
	public String getFormattedAddressLine1() {
		return getFormattedAddressLine1Sb().toString();
	}
	
	public StringBuffer getFormattedAddressLine1Sb() {
		// 8/26/2016: updated to including unitOrBuilding
		// added TestAddressDto to test different combinations against expected output
		StringBuffer formattedFullAddress = new StringBuffer();
		CtracStringUtil.addValueWithSeparator(formattedFullAddress, streetAddress, "");
		CtracStringUtil.addValueWithSeparator(formattedFullAddress, unitOrBuilding, " ");
		return formattedFullAddress;
	}

	public String getCityStateZipCode() {
		return getCityStateZipCodeSb().toString();
	}
	
	public StringBuffer getCityStateZipCodeSb() {
		// 8/26/2016: added TestAddressDto to test different combinations against expected output
		StringBuffer cityStateZipCode = new StringBuffer();
		CtracStringUtil.addValueWithSeparator(cityStateZipCode, city, "");
		CtracStringUtil.addValueWithSeparator(cityStateZipCode, state, ", ");
		CtracStringUtil.addValueWithSeparator(cityStateZipCode, zipCode, " ");
		return cityStateZipCode;
	}

	public boolean hasChanged(){
		
		if(this.loadTimeValue ==null || this.getRid()==null){
			return true;
		}
		return !deepEquals(this.loadTimeValue);
	}
	
	public void saveACopy () {
		//this.loadTimeValue = (AddressDto) SerializationUtils.clone(this);
		try {
			this.loadTimeValue = this.clone();
		} catch (CloneNotSupportedException swallow) {
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	
	private boolean deepEquals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AddressDto other = (AddressDto) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (county == null) {
			if (other.county != null)
				return false;
		} else if (!county.equals(other.county))
			return false;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (streetAddress == null) {
			if (other.streetAddress != null)
				return false;
		} else if (!streetAddress.equals(other.streetAddress))
			return false;
		if (zipCode == null) {
			if (other.zipCode != null)
				return false;
		} else if (!zipCode.equals(other.zipCode))
			return false;
		if (unitOrBuilding == null ) {
			if (other.unitOrBuilding != null && !StringUtils.isBlank(other.unitOrBuilding))
				return false;
		} else if (!unitOrBuilding.equals(other.unitOrBuilding)&& !StringUtils.isBlank(unitOrBuilding))
			return false;
		return true;
	}
	
	
	@Override
	protected AddressDto clone() throws CloneNotSupportedException {
		return (AddressDto) super.clone();
	}

	public String toHTML() {
		StringBuffer sb = new StringBuffer();
		CtracStringUtil.addValueWithSeparator(sb, getFormattedAddressLine1Sb(), "<br/>");
		CtracStringUtil.addValueWithSeparator(sb, getCityStateZipCodeSb(), "<br/>");
		return sb.toString();
	}
	

}
