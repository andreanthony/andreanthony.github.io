package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewConclusion;
import org.apache.log4j.Logger;

import java.io.Serializable;

public class BIRRuleConclusionDTO implements Serializable, Cloneable {

	private static final long serialVersionUID = -7409440879249756970L;

    private static final Logger logger = Logger.getLogger(BIRRuleConclusionDTO.class);

	private Long rid;

	private Long proofOfCoverageRid;

	private Long collateralRid;

	private Long insurableAssetSortOrder;

	private String fieldName;

	private String conclusion;

	private BIRRuleConclusionDTO loadTimeValue;

	/**
	 * Populate all of the keys for the conclusion, which will be populated from being bound to the
	 * form on the front-end.
	 *
	 * @param proofOfCoverageRid
	 * @param collateralRid
	 * @param insurableAssetSortOrder
	 * @param fieldName
	 */
	public void populateValues(Long proofOfCoverageRid, Long collateralRid, Long insurableAssetSortOrder, String fieldName, String conclusion) {
		this.proofOfCoverageRid = proofOfCoverageRid;
		this.collateralRid = collateralRid;
		this.insurableAssetSortOrder = insurableAssetSortOrder;
		this.fieldName = fieldName;
		this.conclusion = conclusion;
	}

	public boolean hasException() {
		return BorrowerInsuranceReviewConclusion.ACTION_REQUIRED.name().equals(conclusion);
	}

	public boolean isReasonForReject() {
		return BorrowerInsuranceReviewConclusion.REJECTED.name().equals(conclusion);
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getInsurableAssetSortOrder() {
		return insurableAssetSortOrder;
	}

	public void setInsurableAssetSortOrder(Long insurableAssetSortOrder) {
		this.insurableAssetSortOrder = insurableAssetSortOrder;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getConclusion() {
		return conclusion;
	}

	public void setConclusion(String conclusion) {
		this.conclusion = conclusion;
	}

	public BIRRuleConclusionDTO getLoadTimeValue() {
		return loadTimeValue;
	}

	@Override
	public BIRRuleConclusionDTO clone() {
		BIRRuleConclusionDTO birRuleConclusionDTO;
		try {
			birRuleConclusionDTO = (BIRRuleConclusionDTO) super.clone();
		} catch (CloneNotSupportedException e) {
		    logger.error(e.getMessage(), e);
			birRuleConclusionDTO = new BIRRuleConclusionDTO();
		}
		birRuleConclusionDTO.setRid(rid);
		birRuleConclusionDTO.setProofOfCoverageRid(proofOfCoverageRid);
		birRuleConclusionDTO.setCollateralRid(collateralRid);
		birRuleConclusionDTO.setInsurableAssetSortOrder(insurableAssetSortOrder);
		birRuleConclusionDTO.setFieldName(fieldName);
		birRuleConclusionDTO.setConclusion(conclusion);
		return birRuleConclusionDTO;
	}

	public void saveACopy() {
		this.loadTimeValue = this.clone();
	}

}
