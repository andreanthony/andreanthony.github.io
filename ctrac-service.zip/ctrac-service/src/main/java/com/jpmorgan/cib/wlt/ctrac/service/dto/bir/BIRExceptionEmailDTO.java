package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewRule;
import com.jpmorgan.cib.wlt.ctrac.service.bir.EmailSequence;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;

public class BIRExceptionEmailDTO {

	private EmailSequence emailSequence;
	
	private String currentReferenceDate;
	
	private String insuredName;
	
	private String policyNumber;
	
	private String effectiveDate;
	
	private String expirationDate;
	
	private String collateralIDs;
	
	private String policyAmount;
	
	private AddressDto policyAddress;
	
	private Long collateralRid; // used for Zone Variance
	
	private String initialZoneVarianceDate;
	
	private File singleFileAttachment;
	
	private String borrowerName;
	
	private String loanNumber;
	
	private String proofOfPaymentDescription;
	
	private List<LoanData> loanData;
	
	private boolean hasCTLLOB =  false;
	
	private boolean primaryLoanLOBCTL =  false;
		
	/*
	 * for the policy:
	 * insured name
	 * mortgagee payee
	 * lender loss payee
	 * lender lien position
	 * total # of condo units
	 */
	private Map<String, BIRExceptionEmailRuleDTO> policyExceptions = new HashMap<String, BIRExceptionEmailRuleDTO>();
	
	private boolean nonRejectReasons = false;
	
	/*
	 * for each collateral:
	 * property address
	 * unit/building
	 * flood zone
	 * coverage type
	 * gap in coverage
	 */
	private Map<Long, BIRExceptionEmailCollateralDTO> collateralExceptionDataMap = new HashMap<Long, BIRExceptionEmailCollateralDTO>();
	
	public boolean isPrimaryLoanLOBCTL() {
		primaryLoanLOBCTL =  false; 
		if(loanData == null) return primaryLoanLOBCTL;
		
		for(LoanData data : loanData){
			
			boolean isPrimary = data.getChkPrimaryLoan() != null ? data.getChkPrimaryLoan().booleanValue() : false;
			isPrimary = isPrimary || ("Yes".equals(data.getPrimaryFlag()));
			
			if(isPrimary && "CTL".equals(data.getLineOfBusinessCodeConst())){
				primaryLoanLOBCTL =  true;	
				break;
			}			
		}
		return primaryLoanLOBCTL;
	}

	public void setPrimaryLoanLOBCTL(boolean primaryLoanLOBCTL) {
		this.primaryLoanLOBCTL = primaryLoanLOBCTL;
	}
	
	public boolean isHasCTLLOB() {
		hasCTLLOB =  false;	
		if (loanData != null) {
			for(LoanData data : loanData){
				if("CTL".equals(data.getLineOfBusinessCodeConst())){
					hasCTLLOB =  true;	
					break;
				}			
			}
		}
		return hasCTLLOB;
	}

	public boolean isLoanType(String checkForLoanType) {
		if (loanData != null) {
			for(LoanData data : loanData){
				if(checkForLoanType.equals(data.getLoanType())){
					return(true);
				}			
			}
		}
		return false;
	}

	
	public boolean hasNonRejectReasons() {
		return nonRejectReasons;
	}

	public void setNonRejectReasons(boolean hasNonRejectReasons) {
		this.nonRejectReasons = hasNonRejectReasons;
	}

	public String getBorrowerPolicyFloodZone() {
		BIRExceptionEmailRuleDTO floodZoneException = getFloodZoneException(collateralRid);
		if (floodZoneException != null) {
			return floodZoneException.getCurrentPolicyValue();
		}
		return "";
	}
	
	public String getSFHDFFloodZone() {
		BIRExceptionEmailRuleDTO floodZoneException = getFloodZoneException(collateralRid);
		if (floodZoneException != null) {
			return floodZoneException.getRequiredValue();
		}
		return "";
	}
	
	public BIRExceptionEmailRuleDTO getFloodZoneException(Long collateralRid) {
		if (collateralRid != null && collateralExceptionDataMap.containsKey(collateralRid)) {
			return collateralExceptionDataMap.get(collateralRid).
					getCollateralExceptions().get(BorrowerInsuranceReviewRule.FLOOD_ZONE_RULE.getKey());
		}
		return null;
	}
	
	public EmailSequence getEmailSequence() {
		return emailSequence;
	}

	public void setEmailSequence(EmailSequence emailSequence) {
		this.emailSequence = emailSequence;
	}

	public String getCurrentReferenceDate() {
		return currentReferenceDate;
	}

	public void setCurrentReferenceDate(String currentReferenceDate) {
		this.currentReferenceDate = currentReferenceDate;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	
	public String getProofOfPaymentDescription() {
		return proofOfPaymentDescription;
	}

	public void setProofOfPaymentDescription(String proofOfPaymentDescription) {
		this.proofOfPaymentDescription = proofOfPaymentDescription;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getCollateralIDs() {
		return collateralIDs;
	}

	public void setCollateralIDs(String collateralIDs) {
		this.collateralIDs = collateralIDs;
	}

	public List<LoanData> getLoanData() {
		return loanData;
	}

	public void setLoanData(List<LoanData> loanData) {
		this.loanData = loanData;
	}

	public Map<String, BIRExceptionEmailRuleDTO> getPolicyExceptions() {
		return policyExceptions;
	}

	public void setPolicyExceptions(Map<String, BIRExceptionEmailRuleDTO> policyExceptions) {
		this.policyExceptions = policyExceptions;
	}

	public Map<Long, BIRExceptionEmailCollateralDTO> getCollateralExceptionDataMap() {
		return collateralExceptionDataMap;
	}

	public void setCollateralExceptionDataMap(Map<Long, BIRExceptionEmailCollateralDTO> collateralExceptionDataMap) {
		this.collateralExceptionDataMap = collateralExceptionDataMap;
	}

	public String getPolicyAmount() {
		return policyAmount;
	}

	public void setPolicyAmount(String policyAmount) {
		this.policyAmount = policyAmount;
	}

	public AddressDto getPolicyAddress() {
		return policyAddress;
	}

	public void setPolicyAddress(AddressDto policyAddress) {
		this.policyAddress = policyAddress;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getInitialZoneVarianceDate() {
		return initialZoneVarianceDate;
	}

	public void setInitialZoneVarianceDate(String initialZoneVarianceDate) {
		this.initialZoneVarianceDate = initialZoneVarianceDate;
	}

	public File getSingleFileAttachment() {
		return singleFileAttachment;
	}

	public void setSingleFileAttachment(File singleFileAttachment) {
		this.singleFileAttachment = singleFileAttachment;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}
	
	public Set<Long> getCollateralIdSet() {
		Set<Long> idSet = new HashSet<Long>();
		for (String collateralRid : collateralIDs.split(", ")) {
			idSet.add(new Long(collateralRid));
		}
		return idSet;
	}
		
}
