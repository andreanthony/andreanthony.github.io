package com.jpmorgan.cib.wlt.ctrac.service.dateCalculator;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.DateTimeComparator;
import org.joda.time.Years;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("dateCalculator")
public class DateCalculatorImpl implements DateCalculator {

	@Autowired
	private BusinessDayUtil businessDayUtil;
	
	@Autowired
	private CalendarDayUtil calendarDayUtil;
	
	@Override
	public Date addBusinessDays(int businessDays, Date start) {
		return businessDayUtil.addBusinessDays(businessDays, start);
	}

	@Override
	public Date subtractBusinessDaysExclusive(int businessDays, Date start) {
		return businessDayUtil.subtractBusinessDaysExclusive(businessDays, start);
	}

	@Override
	public int getBusinessDaysBetween(Date firstDate, Date secondDate) {
		return businessDayUtil.getBusinessDaysBetween(firstDate, secondDate);
	}

	@Override
	public Date addCalendarDays(int calanderDays, Date start, Boolean endOnBusinessDay) {
		return calendarDayUtil.addCalendarDays(calanderDays, start, endOnBusinessDay);
	}

	@Override
	public Date subtractCalendarDays(int calanderDays, Date start, Boolean endOnBusinessDay) {
		return calendarDayUtil.subtractCalendarDays(calanderDays, start, endOnBusinessDay);
	}

	@Override
	public Date getNextBusinessDate(Date curDate) {
		return businessDayUtil.getNextBusinessDate(curDate);
	}

	@Override
	public Date getPreviousBusinessDate(Date curDate) {
		return businessDayUtil.getPreviousBusinessDate(curDate);
	}

	@Override
	public Date getNextCalendarDate(Date referencDate) {
		return calendarDayUtil.getNextCalendarDate(referencDate);
	}

	@Override
	public Date getPreviousCalendarDate(Date referencDate) {
		return calendarDayUtil.getPreviousCalendarDate(referencDate);
	}

	@Override
	public Date getCurrentReferenceDate() {
		return calendarDayUtil.getCurrentReferenceDate();
	}


	public Date advanceDateBasedOnCurrentRefYear(Date expDate, int wakeUpConstant){
		DateTime expDateTime = new DateTime(expDate).withTimeAtStartOfDay();
		DateTime tempDate = new DateTime(this.addBusinessDays(wakeUpConstant < 0?0:wakeUpConstant,expDate));
		DateTime curRefDate = new DateTime(getCurrentReferenceDate()).withTimeAtStartOfDay();

        //Sum up the years to the input date
        DateTime calcDate = tempDate;
		while(calcDate.isBefore(curRefDate)){
			calcDate = calcDate.plusYears(1);
			expDateTime = expDateTime.plusYears(1);
        }

		return expDateTime.toDate();
	}
	

	@Override
	public boolean isBusinessDay(Date referencDate) {
		
		DateTime theDate = new DateTime(referencDate);
		return businessDayUtil.isWorkingDay(theDate);
	}

    @Override
    public boolean isOnOrBeforeToday(Date date) {
        if (date == null) {
            return false;
        }        
        return DateTimeComparator.getDateOnlyInstance().compare(
                date, businessDayUtil.getCurrentReferenceDate()) <= 0;
    }

	@Override
	public Date substractBusinessDaysInclusive(int businessDays, Date start) {
		return businessDayUtil.substractBusinessDaysInclusive(businessDays, start);
	}

}
