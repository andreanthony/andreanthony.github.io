package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LpInsuranceVendor;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LPPolicyRequestRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.AlthansBatchItemService;
import com.jpmorgan.cib.wlt.ctrac.service.batch.LPVendorFileGenerator;
import com.jpmorgan.cib.wlt.ctrac.service.batch.LPVendorFileGeneratorFactory;

@Service
public class AlthansBatchItemServiceImpl implements AlthansBatchItemService {

	@Autowired private LPPolicyRequestRepository lpPolicyRequestRepository;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	@Autowired private LPVendorFileGeneratorFactory lpVendorFileGeneratorFactory;
	
	@Override
	@Transactional(readOnly = true)
	public Set<Long> getRelatedPolicyRids(Long perfectionTaskRid) {
		PerfectionTask task = perfectionTaskRepository.findOne(perfectionTaskRid);
		List<LPPolicyRequest> requests = lpPolicyRequestRepository.findByAlthansBatchItemRid(task.getWorkItem().getRid());
		Set<Long> policyRids = new HashSet<Long>();
		for(LPPolicyRequest lp: requests){
			policyRids.add(lp.getProofOfCoverage().getRid());
		}
		return policyRids;
	}
	
	@Override
	@Transactional(readOnly = true)
	public boolean isNewIssuePolicy(Long batchItemRid,ProofOfCoverage policy) {
		LPVendorFileGenerator lpVendorFileGenerator = lpVendorFileGeneratorFactory.getLPVendorFileGeneratorFactory(LpInsuranceVendor.ALTHANS);
		List<LPPolicyRequest> requests = lpPolicyRequestRepository.findByAlthansBatchItemRidAndProofOfCoverage(batchItemRid,policy);
		for(LPPolicyRequest lp: requests){
			if (lpVendorFileGenerator.isNewOrRenewalPolicyRequest(lp.getTransCode())) {
				return true;
			}
		}
		return false;
	}

}
