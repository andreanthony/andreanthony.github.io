package com.jpmorgan.cib.wlt.ctrac.service.ews.adapter;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import microsoft.exchange.webservices.data.EmailMessage;
import microsoft.exchange.webservices.data.FileAttachment;
import microsoft.exchange.webservices.data.Item;

public interface ExchangeWebServiceAdapter {
	/**
	 * initialize the exchange web service connection
	 */
	void iniExchangeWebService();

	EmailMessage getEmailMessageByBindingServiceWithItem(Item item);

	ArrayList<Item> getItemsFromInbox();

	void moveEmailMessageToFolder(EmailMessage emailMessage, String folderName);

	void setEmailMessageIsRead(EmailMessage emailMessage);

	ArrayList<FileAttachment> getFileAttachmentListFromAnEmail(EmailMessage emailMessage);

	File loadAttachment(FileAttachment fileAttachment, String path);

	String getNamefromFileAttachment(FileAttachment fileAttachment);

	String getEmailAddress(EmailMessage emailMessage);

	String getSubject(EmailMessage emailMessage);

	Date getReceivedDateTime(EmailMessage emailMessage);
}
