package com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard;

import java.io.Serializable;



public abstract class SectionDto implements Serializable {

	private static final long serialVersionUID = 5783982358664791734L;

	protected SectionStatusDto sectionStatusDto;
	
	public SectionStatusDto getSectionStatusDto() {
		return sectionStatusDto;
	}

	public void setSectionStatusDto(SectionStatusDto sectionStatusDto) {
		this.sectionStatusDto = sectionStatusDto;
	}



}
