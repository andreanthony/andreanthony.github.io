package com.jpmorgan.cib.wlt.ctrac.service.batch;

public interface  CLSEmailService {
	
	void createAndSendEmail(Long taskId);

	void createAndSendNoTransactionEmail();
}
