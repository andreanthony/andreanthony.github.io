package com.jpmorgan.cib.wlt.ctrac.service;

import java.math.BigDecimal;
import java.util.Date;

public interface ApplicationParameterService {

    Date getDate(String key);

    Date getDate(String key, Date defaultValue);

    Integer getInteger(String key);

    Integer getInteger(String key, Integer defaultValue);

    BigDecimal getNumber(String key);

    BigDecimal getNumber(String key, BigDecimal defaultValue);

    String getString(String key);

    String getString(String key, String defaultValue);

}
