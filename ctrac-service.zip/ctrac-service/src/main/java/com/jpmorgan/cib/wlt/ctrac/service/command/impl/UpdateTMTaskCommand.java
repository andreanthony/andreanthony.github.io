package com.jpmorgan.cib.wlt.ctrac.service.command.impl;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.service.command.AbstractCommand;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.Attributes;


/**
 * 
 * @author n595724
 * This Class scope should stay "prototype";
 * if at some point we decide to make sprint manage it live circle, the scope must stay prototype
 * 
 */
public class UpdateTMTaskCommand extends AbstractCommand {
	
	private final Attributes attributes;
	private final TMParams tmParams;
	private final PerfectionTask perfectionTask;
	
	private static final Logger logger = Logger.getLogger(UpdateTMTaskCommand.class);
	
	public UpdateTMTaskCommand(Attributes attributes, TMParams tmParams, PerfectionTask perfectionTask){
		this(attributes, tmParams, perfectionTask, 0);
	}

	public UpdateTMTaskCommand(Attributes attributes, TMParams tmParams, PerfectionTask perfectionTask, int priority) {
		this.attributes = attributes;
		this.tmParams = tmParams;
		this.perfectionTask = perfectionTask;
		this.priority = priority;
	}

	@Override
	public void execute() {
		//TODO handle bean not found exceptions
		TMService tmService=  (TMService) ApplicationContextProvider.getContext().getBean("TMService");
		tmParams.setUserId(perfectionTask.getUpdatedBy());
		if (attributes != null && tmParams != null) {
			try {
				tmService.updateAttributes(attributes, tmParams);
			} catch (Exception swallow) {
				logger.error("Error updating TM attributes: " + tmParams.getId_task());
				try {
					tmService.amendTask(perfectionTask);
				}catch (Exception ex) {					
					throw new CTracApplicationException("E0352", CtracErrorSeverity.APPLICATION, ex);
				}
			}
		} else if (perfectionTask != null) {
			try {
				tmService.amendTask(perfectionTask);
			}catch (Exception ex) {
				//logger.error("Error in creating the task.", ex);
				throw new CTracApplicationException("E0352", CtracErrorSeverity.APPLICATION, ex);
			}
		} else {
			logger.error("Invalid parameters for UpdateTMTaskCommand::execute");
			throw new RuntimeException("Invalid parameters for UpdateTMTaskCommand::execute");
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((attributes == null) ? 0 : attributes.hashCode());
		result = prime * result
				+ ((tmParams == null) ? 0 : tmParams.hashCode());
		result = prime * result
				+ ((priority == null) ? 0 : priority.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UpdateTMTaskCommand other = (UpdateTMTaskCommand) obj;
		if (attributes == null) {
			if (other.attributes != null)
				return false;
		} else if (!attributes.equals(other.attributes))
			return false;
		if (tmParams == null) {
			if (other.tmParams != null)
				return false;
		} else if (!tmParams.equals(other.tmParams))
			return false;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		return true;
	}

}
