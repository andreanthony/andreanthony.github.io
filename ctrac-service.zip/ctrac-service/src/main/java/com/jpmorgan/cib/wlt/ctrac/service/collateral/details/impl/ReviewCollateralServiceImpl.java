package com.jpmorgan.cib.wlt.ctrac.service.collateral.details.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.*;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralInsuranceRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.CollateralWorkItemRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.ExternallyAgentedWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.ReviewCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMTaskDataParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.WorkflowStateAttributes;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.externallyAgented.ExternallyAgentedService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.ReadyForLenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import com.jpmorgan.cib.wlt.ctrac.service.workflow.WorkflowRuleEvaluator;
import com.jpmorgan.cib.wlt.ctrac.service.workflow.WorkflowRuleEvaluatorFactory;
import com.jpmorgan.cib.wlt.ctrac.service.workflow.impl.RequiredCoverageRequestWorkflowRuleEvaluator;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.PENDING_VERIFY_COLLATERAL;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.REVIEW_COLLATERAL;


@Service
public class ReviewCollateralServiceImpl implements ReviewCollateralService {

	private static final Logger logger = LoggerFactory.getLogger(ReviewCollateralServiceImpl.class);

	@Autowired private CollateralDetailsStatusService collateralDetailsStatusService;
	@Autowired private CollateralManagementService collateralManagementService;
	@Autowired private CollateralInsuranceRepository collateralInsuranceRepository;
	@Autowired private CollateralWorkItemRepository collateralWorkItemRepository;
	@Autowired private LoanService loanService;
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;
	@Autowired private ReadyForLenderPlaceService readyForLenderPlaceService;
	@Autowired private TaskService taskService;
	@Autowired private CollateralWorkflowService collateralWorkflowService;
	@Autowired private WorkflowRuleEvaluatorFactory workflowEvaluatorFactory;
	@Autowired private DateCalculator dateCalculator;
	@Autowired private ExternallyAgentedService externallyAgentedService;

	@Override
	@Transactional
	public void initiateReadyForLP(Long proofOfCoverageRid) {
		List<CollateralInsuranceViewData> collateralInsuranceList =
	    		collateralInsuranceRepository.findByProofOfCoverageRid(proofOfCoverageRid);
		if (collateralInsuranceList == null || collateralInsuranceList.isEmpty()) {
			logger.error("No collateral found for this insurance while initiating renewal.");
			throw new RuntimeException("No collateral found for this insurance while initiating renewal.");
		}
    	for (CollateralInsuranceViewData collateralInsurance : collateralInsuranceList) {
    	    readyForLenderPlaceService.saveRenewalStarted(collateralInsurance.getCollateral(), collateralInsurance.getProofOfCoverage());
    	}
	}

	@Override
    @Transactional
    public void completeCollateralReview(final CollateralDetailsMainDto collateralDetailsData) {
		collateralDetailsStatusService.saveSectionsStatus(collateralDetailsData.getSectionStatusDtos());
		Long collateralRid = collateralDetailsData.getCollateralDto().getRid();
		final PerfectionTask reviewCollateralTask = findPerfectionTaskForCollateral(
				collateralRid, PerfectionItemType.COLLATERAL, REVIEW_COLLATERAL, TaskStatus.OPEN);
		taskService.completeWorkFlowStepOperations(new HashMap<StateParameterType, Object>() {
			private static final long serialVersionUID = 3730853052500920723L; {
				put(StateParameterType.PERFECTION_TASK, reviewCollateralTask);
				put(StateParameterType.HELPER_DATA, collateralDetailsData);
				put(StateParameterType.TM_PARAMS, collateralDetailsData.getTmParams());
			}
		});
		externallyAgentedService.createLeadBankEmailNoticeTask(collateralRid);
		advancePendingVerifyCollateral(collateralRid);
    }

	@Override
	@Transactional
	public void advancePendingVerifyCollateral(Long collateralRid) {
		logger.debug("advancePendingVerifyCollateral::START ,CollateralRid:"+ collateralRid);
		//Get the Pending verify collateral perfection task for given collateral
		final PerfectionTask pendingVerifyCollateralTask = findPerfectionTaskForCollateral(
				collateralRid, PerfectionItemType.COLLATERAL, PENDING_VERIFY_COLLATERAL, TaskStatus.TRANSIENT);

		// if the first three sections are verified
		if (pendingVerifyCollateralTask != null &&
				collateralDetailsStatusService.areBasicSectionsVerified(collateralRid)) {
			// find all of the policies for this Review Collateral/Pending Verify Collateral
			List<ReadyForLP> policiesForCollateral = readyForLenderPlaceService.findRenewalStartedForCollateralRid(collateralRid);
			final WorkflowStateAttributes nextWorkflowStep = evaluateInitializationRequiredCoverageWorkflow(pendingVerifyCollateralTask,
					collateralRid,policiesForCollateral);

			// transition the pendingVerifyCollateralTask to the next workflow step
			taskService.completeWorkFlowStepOperations(new HashMap<StateParameterType, Object>() {
				private static final long serialVersionUID = 1L;{
					put(StateParameterType.PERFECTION_TASK, pendingVerifyCollateralTask);
					put(StateParameterType.WORKFLOW_STATE_ATTRIBUTES, nextWorkflowStep);
				}
			});
            logger.debug("advancePendingVerifyCollateral::END");
		}
	}

	@Override
	public Date calcReviewCollateralTaskWakeupDate(WorkItem workItem, ProofOfCoverage policy) {
	    WorkItem workItemDeProxy = CtracBaseEntity.deproxy(workItem,WorkItem.class);
		if(workItemDeProxy instanceof CollateralItem){
			CollateralItem collateralItem = (CollateralItem) workItemDeProxy;
			if(policy == null) {
				policy = collateralItem.getProofOfCoverageForItemType(ProofOfCoverageWorkItemRelationType.COLLATERAL_TO_POLICY);
			}
			if (policy != null && PolicyStatus.EXPIRING_EA.equals(policy.getPolicyStatus_())){
				return dateCalculator.subtractBusinessDaysExclusive(
						ExternallyAgentedWorkflowService.START_REVIEW_COLLATERAL_BD,
						new DateTime(dateCalculator.advanceDateBasedOnCurrentRefYear(
								policy.getExpirationDate(),ExternallyAgentedWorkflowService.START_REVIEW_COLLATERAL_BD)).toDate());
			}
		}
		return null;
	}


	public void createSleepingReviewCollateralWorkflow(WorkItem workItem){
		WorkItem workItemDeProxy = CtracBaseEntity.deproxy(workItem,WorkItem.class);
		if(workItemDeProxy instanceof InsuranceRenewalItem) {
			InsuranceRenewalItem insuranceRenewalItem = (InsuranceRenewalItem) workItemDeProxy;
			if (PolicyStatus.EXPIRING_EA.equals(insuranceRenewalItem.getProofOfCoverage().getPolicyStatus_())) {
				List<TMTaskDataParams> tMTaskDataParams = new ArrayList<>();
				List<WorkflowStateDefinition> avoidExistingWorkflowSteps = new ArrayList<>();
				avoidExistingWorkflowSteps.add(WorkflowStateDefinition.PENDING_VERIFY_COLLATERAL);
				avoidExistingWorkflowSteps.add(WorkflowStateDefinition.REVIEW_COLLATERAL);

				for(Collateral collateral: insuranceRenewalItem.getProofOfCoverage().getInsuredCollaterals()){
					collateralWorkflowService.initiateCollateralWorkflow(collateral,
							PerfectionItemSubType.FLOOD_RENEWAL,WorkflowStateDefinition.REVIEW_COLLATERAL,
							tMTaskDataParams,avoidExistingWorkflowSteps);
				}
				collateralWorkflowService.createSleepingCollateralTasks(tMTaskDataParams, insuranceRenewalItem.getProofOfCoverage());
			}
		}
	}

	/**
	 * Evaluate for given Pending Verify collateral task and collateral with its policies that are in current renewal process
	 * what the next workflow state will be in determining if a requirement coverage request should be created or not
	 * @param pendingVerifyCollateralTask - The pending verify collateral perfection task
	 * @param collateralRid - The collateral rid
	 * @param policiesForCollateral - The policies from the collateral that are in renewal workflow
	 * @return evaluated workflowAttributes
	 */
	private WorkflowStateAttributes evaluateInitializationRequiredCoverageWorkflow(PerfectionTask pendingVerifyCollateralTask, Long collateralRid,
																	 List<ReadyForLP> policiesForCollateral){
		logger.debug("evaluateRequiredCoverageWorkflow::START");
		//Load collateral data to get data needed to load the Review Collateral Rules
		CollateralDto collateralDto = collateralManagementService.getCollateralDto(collateralRid);
		//initialize the workflow evaluator for required coverage needed to determine next workflow steps to start and collect data for it
		WorkflowRuleEvaluator workflowEvaluator = workflowEvaluatorFactory.createReqCoverageWorkflowEvaluator(collateralDto);
		//Create a map of params used to evaluate the required coverage workflow initialization
		Map<String,Object> workflowEvaluatorParams = new HashMap<>();
		workflowEvaluatorParams.put(RequiredCoverageRequestWorkflowRuleEvaluator.CONST_COLLATERAL,collateralDto);
		workflowEvaluatorParams.put(RequiredCoverageRequestWorkflowRuleEvaluator.CONST_PERFECTION_TASK,pendingVerifyCollateralTask);
		workflowEvaluatorParams.put(RequiredCoverageRequestWorkflowRuleEvaluator.CONST_RENEWAL_POLICIES,policiesForCollateral);
		workflowEvaluatorParams.put(RequiredCoverageRequestWorkflowRuleEvaluator.CONST_SKIP_REQUIRED_COVERAGE, shouldSkipRequiredCoverage(collateralRid));

		//Do the calculation of what workflow is expected to start in current verify collateral scenario given a list
		// of all policies flagged to be renewed for given collateral
		workflowEvaluator.evaluateWorkflowRules(workflowEvaluatorParams);

		WorkflowStateAttributes evaluatedWorkflowState = workflowEvaluator.getCalculatedWorkflowAttributes();
		//Verify if the current workflow need to initiate a Required Coverage Request Workflow
		if(WorkflowStateDefinition.isRequiredCoverageRequested(evaluatedWorkflowState.getNextWorflowStep())){
			Object calculatedDate = evaluatedWorkflowState.getEvaluatedData()
					.get(RequiredCoverageRequestWorkflowRuleEvaluator.CONST_REQ_COV_DOCUMENT_DUE_DATE);
			collateralWorkflowService.initRequiredCoverageRequestWorkFlow(pendingVerifyCollateralTask.getWorkItem(),
					collateralRid, pendingVerifyCollateralTask.getWorkItem().getPerfectionSubType_(),
					TMTaskType.valueOf(pendingVerifyCollateralTask.getTmTaskType()),
					calculatedDate != null ? (Date)calculatedDate : null);
		}
		logger.debug("evaluateRequiredCoverageWorkflow::END , Evaluated Next WorkflowStep:{}", evaluatedWorkflowState.getNextWorflowStep());
		return evaluatedWorkflowState;
	}


	protected PerfectionTask findPerfectionTaskForCollateral(Long collateralRid, PerfectionItemType perfectionItemType,
    		WorkflowStateDefinition workflowStep, TaskStatus taskStatus) {
    	List<CollateralWorkItem> collateralWorkItems = findCollateralWorkItems(collateralRid, perfectionItemType);
    	for (CollateralWorkItem collateralWorkItem : collateralWorkItems) {
    		List<PerfectionTask> perfectionTaskList =
    				perfectionTaskRepository.findByWorkItemAndWorkflowStepAndTaskStatus(
    						collateralWorkItem.getWorkItem(), workflowStep.getName(), taskStatus.name());
    		if (perfectionTaskList != null && !perfectionTaskList.isEmpty()) {
    			if (perfectionTaskList.size() > 1) {
    				logger.error("Error occurred while selecting tasks. Multiple records found for: Work Item ID: {} Workflow Step: {} Task Status: {}",
							collateralWorkItem.getWorkItem().getRid(), workflowStep.getName(), taskStatus.name());
    				throw new CTracApplicationException("E0256", CtracErrorSeverity.APPLICATION);
    			} else {
    				return perfectionTaskList.get(0);
    			}
    		}
    	}
    	return null;
    }

	@Override
	@Transactional
	public boolean hasActiveReviewCollateralTask(Long collateralRid) {
        logger.debug("getReviewCollateral::START");
        List<CollateralWorkItem> collateralWorkItems = findCollateralWorkItems(collateralRid, PerfectionItemType.COLLATERAL);
        List<WorkItem> collateralItems = getWorkItems(collateralWorkItems);
        Long numReviewTasks = collateralWorkItems.isEmpty() ? 0L :
        		perfectionTaskRepository.countByWorkItemInAndWorkflowStepAndTaskStatus(
        				collateralItems, REVIEW_COLLATERAL.getName(), TaskStatus.OPEN.name());
        logger.debug("getReviewCollateral::END");
        return numReviewTasks > 0;
    }

    private List<CollateralWorkItem> findCollateralWorkItems(Long collateralRid, PerfectionItemType perfectionItemType) {
    	if (perfectionItemType != null) {
    		return collateralWorkItemRepository.findByCollateralRidAndWorkItemPerfectionType(
    				collateralRid, perfectionItemType.name());
    	}
    	return collateralWorkItemRepository.findByCollateralRid(collateralRid);
    }

    private List<WorkItem> getWorkItems(List<CollateralWorkItem> collateralWorkItems) {
		List<WorkItem> collateralItems = new ArrayList<WorkItem>();
        for (CollateralWorkItem collateralWorkItem : collateralWorkItems) {
            collateralItems.add(collateralWorkItem.getWorkItem());
        }
		return collateralItems;
	}

	private boolean shouldSkipRequiredCoverage(Long collateralRid) {
		return loanService.hasExternallyAgented(collateralRid)
				|| (!loanService.hasActiveLoans(collateralRid)
					&& loanService.hasInactiveExternallyAgented(collateralRid));
	}
}
