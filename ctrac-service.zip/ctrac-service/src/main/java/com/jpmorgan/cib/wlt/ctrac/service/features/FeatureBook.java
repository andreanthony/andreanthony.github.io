package com.jpmorgan.cib.wlt.ctrac.service.features;

public enum FeatureBook {

    @FeatureLabel("General Insurance")
    GENERAL_INSURANCE,

    @FeatureLabel("Micro Services Management page")
    MICRO_SERVICES_MANAGEMENT_PAGE,

    @FeatureLabel("Placeholder for future features")
    FEATURE_PLACEHOLDER

}
