package com.jpmorgan.cib.wlt.ctrac.service.comparators;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WiredPolicy;
import org.apache.commons.lang.builder.CompareToBuilder;

import java.util.Comparator;

/**
 * Created by V704662 on 5/16/2017.
 */
public class WiredPolicyPolicyNumberComparator implements Comparator<WiredPolicy> {

    @Override
    public int compare(WiredPolicy o1, WiredPolicy o2) {
        return new CompareToBuilder().append(o1.getPolicyRid(), o2.getPolicyRid())
                .append(o2.getPayor(), o1.getPayor()).toComparison();
    }
}
