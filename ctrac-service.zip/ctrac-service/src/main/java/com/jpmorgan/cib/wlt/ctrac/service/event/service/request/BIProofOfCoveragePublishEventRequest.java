package com.jpmorgan.cib.wlt.ctrac.service.event.service.request;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRMode;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import org.apache.commons.lang3.StringUtils;

public class BIProofOfCoveragePublishEventRequest extends AbstractPublishEventRequest {

    private final String CONST_DESC_REPLACEMENT = "Replacement";
    private final String CONST_DESC_RENEWAL = "Renewal";
    private Long birPolicyRid;
    private BIRMode birActionMode;
    private boolean isAdminOverride=false;

    public BIProofOfCoveragePublishEventRequest(BorrowerInsuranceReviewDTO borrowerInsuranceReviewDTO, LoanData loanData, Long collateralRid){
        this.collateralRid = collateralRid;
        this.birActionMode = borrowerInsuranceReviewDTO.getBirMode();
        this.birPolicyRid = borrowerInsuranceReviewDTO.getProofOfCoverageData().getRid();
        this.lineOfBusiness = loanData.getLineOfBusiness();
        this.isAdminOverride=borrowerInsuranceReviewDTO.isAdminOverride();
    }

    public BIProofOfCoveragePublishEventRequest forCollateralEventType(CollateralEventType collateralEventType){
        this.collateralEventType = collateralEventType;
        return this;
    }


    /**
     * Construct the description of the event which is based of the value of the BirMode attribute
     * @return Description
     */
    @Override
    public String getDescription(){
        if(birActionMode == null){
            return StringUtils.EMPTY;
        }
        switch(birActionMode){
            case RENEWAL:
                return CONST_DESC_RENEWAL;
            case REPLACE:
                return CONST_DESC_REPLACEMENT;
            default:
                return StringUtils.EMPTY;
        }
    }

    /**
     * Return the event type which is based on what the current value is of the BIRMode attribute
     * @return CollateralEventType
     */
    @Override
    public CollateralEventType getCollateralEventType(){
        if(this.collateralEventType != null){
            return this.collateralEventType;
        }
        if(birActionMode != null){
            switch(birActionMode){
                case VERIFY:
                    return CollateralEventType.VERIFIED;
                case EDIT:
                    if(isAdminOverride) {
                        return CollateralEventType.ADMIN_EDITED;
                    }
                    return CollateralEventType.EDITED;
                case NEW: case REPLACE: case RENEWAL:
                    return CollateralEventType.ADDED;
            }
        }
        return null;
    }

    /**
     * Return the identifier which is equal to the policy RID
     * @return Identifier
     */
    @Override
    public String getIdentifier(){
        if(this.birPolicyRid != null) {
            return this.birPolicyRid.toString();
        }
        return StringUtils.EMPTY;
    }

}
