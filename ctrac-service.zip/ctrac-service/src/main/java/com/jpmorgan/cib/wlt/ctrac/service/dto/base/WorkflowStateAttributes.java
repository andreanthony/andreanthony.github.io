package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.service.statemachine.TaskState;

public class WorkflowStateAttributes {

	@Deprecated //TODO uses current/next workflowStep to avoid ambiguity
	private String workflowState;
	
	@Deprecated
	private String taskSubType;
	
	private String transition;

	private int slaTimer;
	
	private String trackingType;
	
	private Date workflowStartDate;
	
	private String currentWorflowStep;
	
	private String nextWorflowStep;
	
	private TaskState currentTaskState;
	
	private TaskState nextTaskState;
	
	private String currentTaskStatus;
	
	private String nextTaskStatus;	
	
	private int nextStateInitialSLADays;
	
	private Date nextTaskStateWakeUpDate;
	
	private String comments;

	private Map<String,Object> evaluatedData = new HashMap<>();
	
	public String getNextTaskStatus() {
		return nextTaskStatus;
	}

	public void setNextTaskStatus(String nextTaskStatus) {
		this.nextTaskStatus = nextTaskStatus;
	}

	public Date getWorkflowStartDate() {
		return workflowStartDate;
	}

	public void setWorkflowStartDate(Date workflowStartDate) {
		this.workflowStartDate = workflowStartDate;
	}

	public String getTransition() {
		return transition;
	}

	public void setTransition(String transition) {
		this.transition = transition;
	}

	public int getSlaTimer() {
		return slaTimer;
	}

	public void setSlaTimer(int slaTimer) {
		this.slaTimer = slaTimer;
	}
    
	@Deprecated
	public String getWorkflowState() {
		return workflowState;
	}

	@Deprecated
	public void setWorkflowState(String workflowState) {
		this.workflowState = workflowState;
	}

	public String getTrackingType() {
		return trackingType;
	}

	public void setTrackingType(String trackingType) {
		this.trackingType = trackingType;
	}
	
	public TaskState getCurrentTaskState() {
		return currentTaskState;
	}

	public void setCurrentTaskState(TaskState currentTaskState) {
		this.currentTaskState = currentTaskState;
	}

	public TaskState getNextTaskState() {
		return nextTaskState;
	}

	public String getTaskSubType() {
		return taskSubType;
	}

	public void setTaskSubType(String taskSubType) {
		this.taskSubType = taskSubType;
	}

	public void setNextTaskState(TaskState nextTaskState) {
		this.nextTaskState = nextTaskState;
	}

	/**
	 * @return the currentWorflowStep
	 */
	public String getCurrentWorflowStep() {
		return currentWorflowStep;
	}

	/**
	 * @param currentWorflowStep the currentWorflowStep to set
	 */
	public void setCurrentWorflowStep(String currentWorflowStep) {
		this.currentWorflowStep = currentWorflowStep;
	}

	/**
	 * @return the nextWorflowStep
	 */
	public String getNextWorflowStep() {
		return nextWorflowStep;
	}

	/**
	 * @param nextWorflowStep the nextWorflowStep to set
	 */
	public void setNextWorflowStep(String nextWorflowStep) {
		this.nextWorflowStep = nextWorflowStep;
	}

	public Date getNextTaskStateWakeUpDate() {
		return nextTaskStateWakeUpDate;
	}

	public void setNextTaskStateWakeUpDate(Date nextTaskStateWakeUpDate) {
		this.nextTaskStateWakeUpDate = nextTaskStateWakeUpDate;
	}

	public int getNextStateInitialSLADays() {
		return nextStateInitialSLADays;
	}

	public void setNextStateInitialSLADays(int nextStateInitialSLADays) {
		this.nextStateInitialSLADays = nextStateInitialSLADays;
	}

	public String getCurrentTaskStatus() {
		return currentTaskStatus;
	}

	public void setCurrentTaskStatus(String currentTaskStatus) {
		this.currentTaskStatus = currentTaskStatus;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Map<String, Object> getEvaluatedData() {
		return evaluatedData;
	}

}
