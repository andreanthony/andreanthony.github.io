package com.jpmorgan.cib.wlt.ctrac.service.bir;

import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.BIRRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.CoversAllRiskOfFloodRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.EvidenceOfInsuranceRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.ExpirationDateRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.FloodCoverageIncludedRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.FloodZoneRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.FloodZonesListedRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.GapInCoverageRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.IndividualCondoUnitsRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.InsuredNameRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.JPMLenderLossPayeeRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.JPMLienPositionRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.JPMMortgageePayeeRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.PiaAssessmentExceptionsRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.PolicyAddressRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.ProofOfPaymentRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.PropertyTypeRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.SignedByAgentRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.bir.rules.TotalNumberOfCondoUnitsRuleWorker;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRExceptionEmailDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;

public enum BorrowerInsuranceReviewRule {
	
	// TODO: create RuleWorkers for user-selected conclusions; execute() should do nothing
	COVERS_ALL_RISK_OF_FLOOD_RULE(new CoversAllRiskOfFloodRuleWorker("coversAllRiskOfFlood")),
	EXPIRATION_DATE_RULE(new ExpirationDateRuleWorker("expirationDate")),
	EVIDENCE_OF_INSURANCE_RULE(new EvidenceOfInsuranceRuleWorker("eoiType")),
	FLOOD_COVERAGE_INCLUDED_RULE(new FloodCoverageIncludedRuleWorker("floodCoverageIncluded")),
	FLOOD_ZONES_LISTED_RULE(new FloodZonesListedRuleWorker("floodZonesListed")),
	FLOOD_ZONE_RULE(new FloodZoneRuleWorker("policyFloodZone")),
	GAP_IN_COVERAGE_RULE(new GapInCoverageRuleWorker("gapInCoverage")),
	INSURED_NAME_RULE(new InsuredNameRuleWorker("insuredName")),
	JPM_LENDER_LOSS_PAYEE_RULE(new JPMLenderLossPayeeRuleWorker("jpmListedAsLenderLossPayee")),
	JPM_LIEN_POSITION_RULE(new JPMLienPositionRuleWorker("jpmLienPosition")),
	JPM_MORTGAGEE_PAYEE_RULE(new JPMMortgageePayeeRuleWorker("jpmListedAsMortgageePayee")),
	PIA_ASSESSMENT_EXCEPTIONS_RULE(new PiaAssessmentExceptionsRuleWorker("piaAssessmentExceptions")),
	POLICY_ADDRESS_RULE(new PolicyAddressRuleWorker("policyAddress")),
	PROPERTY_TYPE_RULE(new PropertyTypeRuleWorker("propertyType")),
	PROOF_OF_PAYMENT_RULE(new ProofOfPaymentRuleWorker("proofOfPayment")),
	INDIVIDUAL_CONDO_UNITS_RULE(new IndividualCondoUnitsRuleWorker("individualCondoUnits")),
	TOTAL_NUMBER_OF_CONDO_UNITS_RULE(new TotalNumberOfCondoUnitsRuleWorker("totalNumberOfCondoUnits")),
	SIGNED_BY_AGENT_RULE(new SignedByAgentRuleWorker("signedByAgent"));
	
	private final BIRRuleWorker ruleWorker;
	
	private BorrowerInsuranceReviewRule(BIRRuleWorker ruleWorker) {
		this.ruleWorker = ruleWorker;
	}
	
	public String getKey() {
		return ruleWorker != null ? ruleWorker.getKey() : null;
	}
	
	public boolean isCollateralLevel() {
		return ruleWorker != null ? ruleWorker.isCollateralLevel() : null;
	}
	
	public void execute(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		if (ruleWorker != null) {
			ruleWorker.execute(borrowerInsuranceReviewData);
		}
	}

	public void populateExceptionEmailData(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
			BIRExceptionEmailDTO exceptionEmailData) {
		if (ruleWorker != null) {
			ruleWorker.populateExceptionEmailData(borrowerInsuranceReviewData, exceptionEmailData);
		}
	}
	
	public static BorrowerInsuranceReviewRule findByKey(String key) {
		if (StringUtils.isBlank(key)) {
			return null;
		}
		for (BorrowerInsuranceReviewRule birRule : BorrowerInsuranceReviewRule.values()) {
			if (birRule.ruleWorker.getKey().equals(key)) {
				return birRule;
			}
		}
		return null;
	}
	
	/**
	 * Insertion-order Set with rules for Insurance Exception Rejection Emails
	 */
	public static final Set<BorrowerInsuranceReviewRule> REJECTION_RULES;
	static {
		REJECTION_RULES = new LinkedHashSet<BorrowerInsuranceReviewRule>();
		REJECTION_RULES.add(PROOF_OF_PAYMENT_RULE);
		REJECTION_RULES.add(FLOOD_COVERAGE_INCLUDED_RULE);
		//Not a possible reason due to front end validation, handling if somebody passes the front end validation
		REJECTION_RULES.add(EXPIRATION_DATE_RULE);		
		REJECTION_RULES.add(FLOOD_ZONES_LISTED_RULE);
		REJECTION_RULES.add(COVERS_ALL_RISK_OF_FLOOD_RULE);
		//Not a possible reason due to front end validation, handling if somebody passes the front end validation
		REJECTION_RULES.add(INDIVIDUAL_CONDO_UNITS_RULE);
		//Not a possible reason due to front end validation, handling if somebody passes the front end validation
		REJECTION_RULES.add(TOTAL_NUMBER_OF_CONDO_UNITS_RULE);	
		REJECTION_RULES.add(SIGNED_BY_AGENT_RULE);
	}
	
	/**
	 * Insertion-order Set with rules for Insurance Exception Emails
	 */
	public static final Set<BorrowerInsuranceReviewRule> INSURANCE_EXCEPTION_RULES;
	static {
		INSURANCE_EXCEPTION_RULES = new LinkedHashSet<BorrowerInsuranceReviewRule>();
		INSURANCE_EXCEPTION_RULES.add(GAP_IN_COVERAGE_RULE);
		INSURANCE_EXCEPTION_RULES.add(INSURED_NAME_RULE);
		INSURANCE_EXCEPTION_RULES.add(JPM_MORTGAGEE_PAYEE_RULE);
		INSURANCE_EXCEPTION_RULES.add(JPM_LENDER_LOSS_PAYEE_RULE);
		INSURANCE_EXCEPTION_RULES.add(JPM_LIEN_POSITION_RULE);
		INSURANCE_EXCEPTION_RULES.add(POLICY_ADDRESS_RULE);
		INSURANCE_EXCEPTION_RULES.add(PROPERTY_TYPE_RULE);
		INSURANCE_EXCEPTION_RULES.add(FLOOD_ZONE_RULE);
	}
	
	/**
	 * Insertion-order Set with rules for Zone Variance Emails
	 */
	public static final Set<BorrowerInsuranceReviewRule> ZONE_VARIANCE_RULES;
	static {
		ZONE_VARIANCE_RULES = new LinkedHashSet<BorrowerInsuranceReviewRule>();
		ZONE_VARIANCE_RULES.add(FLOOD_ZONE_RULE);
	}
	
}
