package com.jpmorgan.cib.wlt.ctrac.service.admin.impl;

import org.apache.commons.lang3.StringUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "zipCode"
})
@XmlRootElement(name = "CityStateLookupResponse")
public class CityStateLookupResponse {

    @XmlElement(name = "ZipCode", required = true)
    protected CityStateLookupResponse.ZipCode zipCode;

    public boolean hasError() {
        return zipCode.getError() != null && StringUtils.isNotBlank(zipCode.getError().getDescription());
    }

    /**
     * Gets the value of the zipCode property.
     * 
     * @return
     *     possible object is
     *     {@link CityStateLookupResponse.ZipCode }
     *     
     */
    public CityStateLookupResponse.ZipCode getZipCode() {
        return zipCode;
    }

    /**
     * Sets the value of the zipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link CityStateLookupResponse.ZipCode }
     *     
     */
    public void setZipCode(CityStateLookupResponse.ZipCode value) {
        this.zipCode = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Zip5" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *       &lt;attribute name="ID" type="{http://www.w3.org/2001/XMLSchema}int" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "zip5",
        "city",
        "state",
        "error"
    })
    public static class ZipCode {

        @XmlElement(name = "Zip5")
        protected int zip5;
        @XmlElement(name = "City", required = true)
        protected String city;
        @XmlElement(name = "State", required = true)
        protected String state;
        @XmlAttribute(name = "ID")
        protected Integer id;
        @XmlElement(name = "Error", required = true)
        protected ErrorResponse error;

        public ErrorResponse getError() { return error; }

        public void setError(ErrorResponse error) { this.error = error; }

        /**
         * Gets the value of the zip5 property.
         * 
         */
        public int getZip5() {
            return zip5;
        }

        /**
         * Sets the value of the zip5 property.
         * 
         */
        public void setZip5(int value) {
            this.zip5 = value;
        }

        /**
         * Gets the value of the city property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCity() {
            return city;
        }

        /**
         * Sets the value of the city property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCity(String value) {
            this.city = value;
        }

        /**
         * Gets the value of the state property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getState() {
            return state;
        }

        /**
         * Sets the value of the state property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setState(String value) {
            this.state = value;
        }

        /**
         * Gets the value of the id property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getID() {
            return id;
        }

        /**
         * Sets the value of the id property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setID(Integer value) {
            this.id = value;
        }

    }

}
