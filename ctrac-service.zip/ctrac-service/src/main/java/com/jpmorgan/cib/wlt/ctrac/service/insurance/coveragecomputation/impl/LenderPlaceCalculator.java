package com.jpmorgan.cib.wlt.ctrac.service.insurance.coveragecomputation.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.*;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.MoreThanOneExcessPolicyException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CoverageDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.service.dto.builder.FloodInsuranceDTOBuilder;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.*;
import com.jpmorgan.cib.wlt.ctrac.service.helper.LPCapMaxAmountUtil;
import com.jpmorgan.cib.wlt.ctrac.service.helper.LPGapAndLapseUtil;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.impl.CoverageActionData;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class LenderPlaceCalculator {

	private static final Logger logger = Logger.getLogger(LenderPlaceCalculator.class);
	public static final BigDecimal lPPolicyDeductibleAmount = new BigDecimal(1000);
	public static final RoundingMode ASSURANT_ROUNDING_MODE = RoundingMode.HALF_UP;
	public static final RoundingMode ALTHANS_ROUNDING_MODE = RoundingMode.FLOOR;

    public static Collection<FloodInsuranceDTO> calculateRequiredLPs(
            CoverageActionData coverageActionData, Date date, InsurableAssetDTO insurableAssetDTO) throws MoreThanOneExcessPolicyException {
        Collection<FloodInsuranceDTO> lpPolicies = new ArrayList<>();
        populateRequiredLPsForDate(date, coverageActionData, insurableAssetDTO, lpPolicies);
        //also calculate required coverage on all lapse dates
        SortedSet<Date> lapseDates = getBorrowerPolicyLapseDates(coverageActionData, lpPolicies);
        // add primary and/or excess hold LPI date and keep it sorted by date
        lapseDates.addAll(coverageActionData.getCurrentHoldLpiDates(date));

        for (Date lapseDate : lapseDates) {
            populateRequiredLPsForDate(lapseDate, coverageActionData, insurableAssetDTO, lpPolicies);
        }
        LPGapAndLapseUtil.combineChainedLPs(lpPolicies);
        return lpPolicies;
    }

    private static SortedSet<Date> getBorrowerPolicyLapseDates(CoverageActionData coverageActionData, Collection<FloodInsuranceDTO> lpPolicies) {
        SortedSet<Date> lapseDates = new TreeSet<>();
        for (FloodInsuranceDTO lpPolicy: lpPolicies) {
            Collection<ProofOfCoverage> borrowerPolicies =
                    coverageActionData.getBorrowerPoliciesEffectiveOnOrAfter(lpPolicy.getEffectiveDate_(), lpPolicy.getCoverageType());
            Map<Date, ProofOfCoverage> lapseDateMap =
                    LPGapAndLapseUtil.buildLapseDateMap(borrowerPolicies, lpPolicy.getEffectiveDate_());
            lapseDates.addAll(lapseDateMap.keySet());
        }
        return lapseDates;
    }

    static Collection<FloodInsuranceDTO> populateRequiredLPsForDate(
            Date date, CoverageActionData coverageActionData, InsurableAssetDTO insurableAssetDTO,
            Collection<FloodInsuranceDTO> lpPolicies) throws MoreThanOneExcessPolicyException {
		logger.debug("calculateRequiredLPs::BEGIN for date: " + date);
		Collection<ProvidedCoverage> borrowerProvidedCoverages = coverageActionData.getBorrowerCoveragesEffectiveOn(date);

		if(coverageActionData.getRequiredCoverage() == null || date == null){
			return lpPolicies;
		}
		CoverageDetails primaryCoverageDetails = coverageActionData.getRequiredCoverage().getPrimaryCoverageDetails();
		BigDecimal primaryRequired = coverageActionData.getPrimaryHold().isWithinDateRange(date)? BigDecimal.ZERO : getCoverageAmount(primaryCoverageDetails);
		CoverageDetails excessCoverageDetails = coverageActionData.getRequiredCoverage().getExcessCoverageDetails();
		BigDecimal excessRequired = coverageActionData.getExcessHold().isWithinDateRange(date)? BigDecimal.ZERO : getCoverageAmount(excessCoverageDetails);

		BigDecimal primaryProvidedCoverageAmt = BigDecimal.ZERO;
		BigDecimal excessProvidedCoverageAmt = BigDecimal.ZERO;
		BigDecimal excessDeductible = BigDecimal.ZERO;
		BigDecimal primaryAndExcessCoverageAmt = BigDecimal.ZERO;

		for (ProvidedCoverage providedCoverage : borrowerProvidedCoverages) {
			ProofOfCoverage proofOfCoverage = providedCoverage.getProofOfCoverage();
			if (proofOfCoverage.getCoverageType_() == CoverageType.PRIMARY) {
				primaryProvidedCoverageAmt = primaryProvidedCoverageAmt.add(getCoverageAmount(providedCoverage.getCoverageDetails()));
			} else if (proofOfCoverage.getCoverageType_() == CoverageType.EXCESS) {
				if (excessProvidedCoverageAmt.compareTo(BigDecimal.ZERO) > 0) {
					throw new MoreThanOneExcessPolicyException(insurableAssetDTO.getCollateralRid());
				}

				excessProvidedCoverageAmt = getCoverageAmount(providedCoverage.getCoverageDetails());
				if (insurableAssetDTO.getInsurableAssetType() == InsurableAssetType.STRUCTURE) {
					excessDeductible = providedCoverage.getProofOfCoverage().getBuildingDeductible();
				} else if (insurableAssetDTO.getInsurableAssetType() == InsurableAssetType.BASE_INSURABLE_ASSET) {
					excessDeductible = providedCoverage.getProofOfCoverage().getContentsDeductible();
				}
			} else if (proofOfCoverage.getCoverageType_() == CoverageType.PRIMARY_AND_EXCESS) {
				primaryAndExcessCoverageAmt = primaryAndExcessCoverageAmt.add(getCoverageAmount(providedCoverage.getCoverageDetails()));
			}
		}

		// Create Primary LP Policy by default
		BigDecimal primaryLpAmount = primaryRequired;
		PolicyType primaryPolicyType = PolicyType.LP;
		BigDecimal additionalExcessCoverage = BigDecimal.ZERO;
		boolean hasPrimaryRequirement = primaryRequired.compareTo(BigDecimal.ZERO) > 0;
		boolean hasProvidedPrimaryCoverage = primaryProvidedCoverageAmt.add(primaryAndExcessCoverageAmt).compareTo(BigDecimal.ZERO) > 0;
		if (hasPrimaryRequirement && hasProvidedPrimaryCoverage) {
			// There is primary requirement and borrower has provided coverage; Change to create Gap LP Policy
			primaryPolicyType = PolicyType.LP_GAP;
			// Subtract Primary coverage from requirement
			primaryLpAmount = primaryRequired.subtract(primaryProvidedCoverageAmt).max(BigDecimal.ZERO);
			// Calculate if you have Primary and Excess coverage left over
			additionalExcessCoverage = additionalExcessCoverage.max(primaryAndExcessCoverageAmt.subtract(primaryLpAmount));
			// Subtract Primary and Excess coverage from requirement
			primaryLpAmount = primaryLpAmount.subtract(primaryAndExcessCoverageAmt).max(BigDecimal.ZERO);
		}
		if (primaryCoverageDetails != null) {
			createLpPolicyIfNecessary(CoverageType.PRIMARY, primaryPolicyType, date, primaryLpAmount,
					insurableAssetDTO, coverageActionData, lpPolicies, primaryCoverageDetails.getBalanceType());
		}

		if (excessRequired.compareTo(BigDecimal.ZERO) > 0) {
			// Create Excess LP Policy
			excessRequired = excessRequired.subtract(additionalExcessCoverage).max(BigDecimal.ZERO);
			BigDecimal excessLpAmount = BigDecimal.ZERO;
			BigDecimal deductibleShortage = excessDeductible.subtract(primaryRequired);
			boolean isExcessDeductibleMet = deductibleShortage.compareTo(BigDecimal.ZERO) <= 0;
			if (isExcessDeductibleMet) {
				// Excess Deductible met -> Subtract Excess coverage from requirement
				excessLpAmount = excessRequired.subtract(excessProvidedCoverageAmt).max(BigDecimal.ZERO);
			} else {
				BigDecimal additionalExcessNeeded = excessRequired.subtract(excessProvidedCoverageAmt);
				if (excessProvidedCoverageAmt.add(deductibleShortage).compareTo(excessRequired) >= 0) {
					// Meeting Excess Deductible leads to sufficient coverage -> Pay the deductible
					excessLpAmount = deductibleShortage;
				} else {
					// Meeting Excess Deductible is not enough -> Purchase additional coverage
					excessLpAmount = additionalExcessNeeded;
				}
			}
			if(excessCoverageDetails != null) {
				createLpPolicyIfNecessary(CoverageType.EXCESS, PolicyType.LP_EXCESS, date, excessLpAmount,
						insurableAssetDTO, coverageActionData, lpPolicies, excessCoverageDetails.getBalanceType());
			}
		}
		logger.debug("calculateRequiredLPs::END");
		return lpPolicies;
	}

	private static BigDecimal getCoverageAmount(CoverageDetails coverageDetails) {
		if (coverageDetails != null && coverageDetails.getCoverageAmount() != null) {
			return coverageDetails.getCoverageAmount();
		}
		return BigDecimal.ZERO;
	}

	private static void createLpPolicyIfNecessary(CoverageType coverageType, PolicyType policyType, Date date,
			BigDecimal lpAmount, InsurableAssetDTO insurableAssetDTO, CoverageActionData coverageActionData,
			Collection<FloodInsuranceDTO> lpPolicies, String balanceType) {
		lpAmount = lpAmount.setScale(0, ALTHANS_ROUNDING_MODE).setScale(2);
		if (lpAmount.compareTo(lPPolicyDeductibleAmount) <= 0) {
			return;
		}
		lpAmount = LPCapMaxAmountUtil.capLPCoverageAmount(coverageType, insurableAssetDTO, lpAmount);
		CoverageDetailsDTO coverageDetailsDTO = new CoverageDetailsDTO();
		coverageDetailsDTO.setCoverageAmount(lpAmount.toString());
		coverageDetailsDTO.setBalanceType(balanceType);
		ProvidedCoverageDTO providedCoverageDTO = ProvidedCoverageDTO.build(insurableAssetDTO, coverageDetailsDTO);
		FloodInsuranceDTO floodInsuranceDTO = new FloodInsuranceDTOBuilder(date,policyType,PolicyStatus.PENDING_LETTER_CYCLE)
				.providedCoverageDTO(providedCoverageDTO)
				.floodZone(insurableAssetDTO.getFloodZone())
				.insuredName(coverageActionData.getInsuredName())
				.coverageType(coverageType)
				.build();

		//Calculate for the new LP policy what the parent policy rid would be
		ParentPolicyCalculator parentPolicyCalculator = new ParentPolicyCalculator(coverageActionData.getAllActivePolicies());
		ProofOfCoverage parentPolicy = parentPolicyCalculator.calculateParentPolicy(coverageType);
		floodInsuranceDTO.setParentPolicyRid(parentPolicy != null ? parentPolicy.getRid() : null);

		populateGapAndLapse(coverageActionData.getBorrowerPoliciesEffectiveOnOrAfter(date, coverageType), floodInsuranceDTO);
		lpPolicies.add(floodInsuranceDTO);
	}

	protected static void populateGapAndLapse(Collection< ProofOfCoverage > borrowerPolicies, ProofOfCoverageDTO lpPolicy) {
        ProofOfCoverage gapBorrowerPolicy = LPGapAndLapseUtil.populateDateLapse(borrowerPolicies,lpPolicy);
		if(gapBorrowerPolicy != null){
			if(!PolicyType.LP_EXCESS.equals(lpPolicy.getPolicyType())) {
                // NOT needed for Excess policy
				lpPolicy.setPolicyType(PolicyType.LP_GAP);
				lpPolicy.setLenderPlaceReason(LenderPlaceReason.BORROWER_POLICY_RECEIVED_DATE_LAPSE);
				lpPolicy.setGapBorrowerPolicyRid(gapBorrowerPolicy.getRid());
                // so renewal workflow should not start
				lpPolicy.setIndRenewal("Y");
			}
		}
		else {
			if(PolicyType.LP_GAP.equals(lpPolicy.getPolicyType())) {
				lpPolicy.setLenderPlaceReason(LenderPlaceReason.BORROWER_POLICY_RECEIVED_AMOUNT_GAP);
				lpPolicy.setGapBorrowerPolicyRid(lpPolicy.getParentPolicyRid());//Rid of borrower policy that initiated the gap
			}
		}
	}

}

