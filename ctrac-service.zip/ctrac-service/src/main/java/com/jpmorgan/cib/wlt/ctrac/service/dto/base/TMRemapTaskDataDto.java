package com.jpmorgan.cib.wlt.ctrac.service.dto.base;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class TMRemapTaskDataDto extends FloodRemapData {
	
	private static final long serialVersionUID = 7182615623563599802L;

	private String borrowerNumber;
	
	private String statusChange;
	
	private String requestNumber;
	
	private Date sourceCreationDate;
	
	private String originalFloodZone;
	
	private String revisedFloodZone;
	
	private String participatingCommunity;
	
	private String lineOfBusiness;
	
	private String sourceSystem;
	
	private String trackingType;
	
	private String ctracUniqueId;
	
	private String tmTaskId;
	
	private String sourceTaskStatus;
	
	private String initiatorId;
	
	private Date taskCreationDate;

	private String breakReason;
	
	private String collateralId;
	
	private String workFlowStep;
	
	public String getCollateralId() {
		return collateralId;
	}

	public void setCollateralId(String collateralId) {
		this.collateralId = collateralId;
	}

	public Date getTaskCreationDate() {
		return taskCreationDate;
	}

	public void setTaskCreationDate(Date taskCreationDate) {
		this.taskCreationDate = taskCreationDate;
	}

	public String getBorrowerNumber() {
		return borrowerNumber;
	}

	public void setBorrowerNumber(String borrowerNumber) {
		this.borrowerNumber = borrowerNumber;
	}

	public String getStatusChange() {
		return statusChange;
	}

	public void setStatusChange(String statusChange) {
		this.statusChange = statusChange;
	}

	public String getRequestNumber() {
		return requestNumber;
	}

	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}

	public Date getSourceCreationDate() {
		return sourceCreationDate;
	}

	public void setSourceCreationDate(Date sourceCreationDate) {
		this.sourceCreationDate = sourceCreationDate;
	}

	public String getOriginalFloodZone() {
		return originalFloodZone;
	}

	public void setOriginalFloodZone(String originalFloodZone) {
		this.originalFloodZone = originalFloodZone;
	}

	public String getRevisedFloodZone() {
		return revisedFloodZone;
	}

	public void setRevisedFloodZone(String revisedFloodZone) {
		this.revisedFloodZone = revisedFloodZone;
	}

	public String getParticipatingCommunity() {
		return participatingCommunity;
	}

	public void setParticipatingCommunity(String participatingCommunity) {
		this.participatingCommunity = participatingCommunity;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getTrackingType() {
		return trackingType;
	}

	public void setTrackingType(String trackingType) {
		this.trackingType = trackingType;
	}

	public String getCtracUniqueId() {
		return ctracUniqueId;
	}

	public void setCtracUniqueId(String ctracUniqueId) {
		this.ctracUniqueId = ctracUniqueId;
	}

	public String getTmTaskId() {
		return tmTaskId;
	}

	public void setTmTaskId(String tmTaskId) {
		this.tmTaskId = tmTaskId;
	}

	public String getSourceTaskStatus() {
		return sourceTaskStatus;
	}

	public void setSourceTaskStatus(String sourceTaskStatus) {
		this.sourceTaskStatus = sourceTaskStatus;
	}
	
	public String getInitiatorId() {
		return initiatorId;
	}

	public void setInitiatorId(String initiatorId) {
		this.initiatorId = initiatorId;
	}

	public String getBreakReason() {
		return breakReason;
	}

	public void setBreakReason(String breakReason) {
		this.breakReason = breakReason;
	}
	
	public String getWorkFlowStep() {
		return workFlowStep;
	}

	public void setWorkFlowStep(String workFlowStep) {
		this.workFlowStep = workFlowStep;
	}

	@Override
	public String toString() {
	    return ReflectionToStringBuilder.toString(this);
	}
}
