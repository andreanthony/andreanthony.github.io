package com.jpmorgan.cib.wlt.ctrac.service.dto.datatable;

public class EntityDataTableDto extends AbstractDataTableDto{

	private static final long serialVersionUID = 8878579366019975177L;
	protected String name;
	protected String address;
	protected String unitBuilding;
	protected String city;
	protected String state;
	protected String zipcode;
	protected String rid;
	protected String collateralRids;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getUnitBuilding() {
		return (unitBuilding == null) ?  "":  unitBuilding;
	}
	public void setUnitBuilding(String unitBuilding) {
		this.unitBuilding = unitBuilding;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRid() {
		return rid;
	}
	public void setRid(String rid) {
		this.rid = rid;
	}
	public String getCollateralRids() {
		return collateralRids;
	}
	public void setCollateralRids(String collateralRids) {
		this.collateralRids = collateralRids;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(" name ").append(name)
				.append(" address ").append(address)
				.append(" city ").append(city)
				.append(" state ").append(state)
				.append(" zip ").append(zipcode)
				.append(" rid ").append(rid)
				.append(" collateralRids ").append(collateralRids);
		return sb.toString();
	}
	
}
