package com.jpmorgan.cib.wlt.ctrac.service.collateral;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ContactDetailDto;

public interface ContactDetailDataService {
    ContactDetailDto saveContactDetail(ContactDetailDto contactDetail);
    void deleteContactDetail(ContactDetailDto contactDetailDto);
}
