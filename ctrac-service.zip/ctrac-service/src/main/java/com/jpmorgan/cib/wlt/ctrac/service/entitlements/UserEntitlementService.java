package com.jpmorgan.cib.wlt.ctrac.service.entitlements;


import java.util.List;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.UserEntitlementAction;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.ManageUserEntitlementRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.UsersDto;

import com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements.GroupIdentifier;
import net.jpmchase.cbhub.rsam.data.ioconsole.IOConsoleUserInventoryRequestData;




public interface UserEntitlementService {

	/**
	 * Method Responsible for building the user certification details
	 * @return
	 */
	List<IOConsoleUserInventoryRequestData.UserRecord> getUserCertificationDetails();

	/**
	 * Method responsible for building the user certification details for one particular user
	 * @param sid
	 * @return
	 */
	UsersDto getUserDetails(String sid);

	/**
	 * Method Responsible for processing the weekly user certification process which includes
	 * using the CBHub RSAM library to integrate with RSAM and send the user info.
	 * @throws Exception
	 */
	void processWeeklyCertification() throws Exception;

	/**
	 * Method responsible handling auto-provisioning of users
	 * @param requestedUser
	 * @return
	 * @throws Exception
	 */
	UsersDto processAutoProvisioning(UsersDto requestedUser) throws Exception;


	void processUserEntitlementRequest(ManageUserEntitlementRequest request
										,UserEntitlementAction action)throws Exception;

	List<GroupIdentifier> getAllAvailableUserGroups();

	/**
	 * Method responsible for hard removal or disablement of a user and all their associated roles
	 * from the database.
	 * @return
	 * @throws Exception
	 */
	void performUserInactivityActions() throws Exception;

	/**
	 * Methond responsible for syncing Janus entitlement user list
	 * with ctrac entitlement tables
	 * @throws Exception
	 */
	void performSyncOfUsersBetweenJanusAndCtrac (List<Users> janusUserList, List<Users> ctracUserList) throws Exception;

	/**
	 * Method responsible for performing a REST call to JANUS to get this list
	 * of current users with the CTRAC entitlement.
	 * @return
	 */
	List<Users> getJanusUserList();

	/**
	 * Method responsible for returning a list of all
	 * users found in the CTRAC database regardless if
	 * active or not.
	 * @return
	 */
	List<Users> getCTRACUserList();

	UsersDto getUserDetailsbyUserName(String username);

	UserEntitlementsDTO getByJanusUsername(String janusUsername);
}
