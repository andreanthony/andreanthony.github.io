package com.jpmorgan.cib.wlt.ctrac.service.dto.bir;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;

public class BIRExceptionEmailCollateralDTO implements Serializable {

	private static final long serialVersionUID = 881730534467088606L;

	private Long collateralRid;
	
	private String propertyAddress;
	
	private AddressDto addressData;
	
	private Map<String, BIRExceptionEmailRuleDTO> collateralExceptions = new HashMap<String, BIRExceptionEmailRuleDTO>();

	private List<BIRExceptionEmailRuleDTO> gapInCoverageExceptions = new ArrayList<BIRExceptionEmailRuleDTO>();
	
	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public AddressDto getAddressData() {
		return addressData;
	}

	public void setAddressData(AddressDto addressData) {
		this.addressData = addressData;
	}

	public Map<String, BIRExceptionEmailRuleDTO> getCollateralExceptions() {
		return collateralExceptions;
	}

	public void setCollateralExceptions(Map<String, BIRExceptionEmailRuleDTO> collateralExceptions) {
		this.collateralExceptions = collateralExceptions;
	}

	public List<BIRExceptionEmailRuleDTO> getGapInCoverageExceptions() {
		return gapInCoverageExceptions;
	}

	public void setGapInCoverageExceptions(List<BIRExceptionEmailRuleDTO> gapInCoverageExceptions) {
		this.gapInCoverageExceptions = gapInCoverageExceptions;
	}
	
}
