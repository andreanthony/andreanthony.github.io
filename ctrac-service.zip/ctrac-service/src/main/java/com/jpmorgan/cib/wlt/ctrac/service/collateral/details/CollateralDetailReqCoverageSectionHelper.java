package com.jpmorgan.cib.wlt.ctrac.service.collateral.details;

import java.util.Collection;
import java.util.Set;

import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.InsurancePolicyRequirementDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.RequiredCoverageSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;

/**
 * @author n595724
 *
 */
public interface CollateralDetailReqCoverageSectionHelper {
    
     /**
     * @param collateralDto
     * @param coverageInputSource
     * @return
     */
    RequiredCoverageSectionDto prepareRequiredCoverageSection(
    		Long collateralRid, RequiredCoverageSectionDto requiredCoverageSectionDto);
     
	
	/**
	 * @param requiredCoverageSectionDto
	 * @param action
	 * @return
	 */
	InsurancePolicyRequirementDto prepareRequiredCoverageOverlayData(CollateralDto CollateralDto, RequiredCoverageSectionDto requiredCoverageSectionDto, String action, Long fiatId);

	/**
	 * @param collateralDto
	 * @param coverageRequirementPendingVerification
	 * @param sortOrder  //in most of the cases, keep sortOrder null
	 */
	void createAndAppendNewCoverageRequiremnetRow(CollateralDto collateralDto, InsurancePolicyRequirementDto coverageRequirementPendingVerification, Integer sortOrder, boolean initAssetDescription);


	/**
	 * @param collateralDto
	 * @param coverageRequirementPendingVerification
	 * @param action
	 */
	Collection<RequiredCoverageDTO> persistCollateralInsurenaceRequirementSection(CollateralDto collateralDto, InsurancePolicyRequirementDto coverageRequirementPendingVerification, String action);

	void notifyFiatVerificationEvents(Long collateralRid, Collection<RequiredCoverageDTO> requiredCoverageDtos);


	boolean areInsurableAssetDeletable(Set<Long> insurableAssetID);


	void proccessRequiredCoverageSubmit( InsurancePolicyRequirementDto insurancePolicyRequirementDto, CollateralDetailsMainDto collateralDetailsMainDto, String action) throws Exception;

	

	void updateDescopedCoverageAmounts( InsurancePolicyRequirementDto insurancePolicyRequirementDto);


	void deleteAllRequiredCoverages(InsurancePolicyRequirementDto insurancePolicyRequirementDto, CollateralDetailsMainDto collateralDetailsMainDto);


	
}
 
