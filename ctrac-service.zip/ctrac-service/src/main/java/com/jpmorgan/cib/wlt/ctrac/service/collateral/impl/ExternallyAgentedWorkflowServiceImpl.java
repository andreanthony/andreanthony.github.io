package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.ExternallyAgentedWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class ExternallyAgentedWorkflowServiceImpl implements ExternallyAgentedWorkflowService {

    private DateCalculator dateCalculator;

    @Autowired
    public ExternallyAgentedWorkflowServiceImpl(DateCalculator dateCalculator) {
        assert(dateCalculator != null);
        this.dateCalculator = dateCalculator;
    }

    @Override
    public void removeExternallyAgentedCollateralsNotReady(Set<Collateral> collaterals, ProofOfCoverage proofOfCoverage) {
        if (dateCalculator.getBusinessDaysBetween(dateCalculator.getCurrentReferenceDate(), proofOfCoverage.getExpirationDate()) > START_REVIEW_COLLATERAL_BD ||
                proofOfCoverage.getPolicyType_().isLenderPlaced()) {
            collaterals.clear();
        }
    }
}
