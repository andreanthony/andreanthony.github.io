package com.jpmorgan.cib.wlt.ctrac.service.config;

import javax.annotation.Resource;
import javax.jms.JMSException;

import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.destination.DynamicDestinationResolver;

import com.ibm.mq.jms.MQQueue;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EncryptionUtil;

@Configuration
public class JmsConfig {

	@Resource
	private Environment env;

	private static final String PROPERTY_NAME_JMS_HOST = "jms.mq.hostName";
	private static final String PROPERTY_NAME_JMS_PORT = "jms.mq.port";
	private static final String PROPERTY_NAME_QUEUE_MANAGER = "jms.mq.queue.manager";
	private static final String PROPERTY_NAME_JMS_CHANNEL = "jms.mq.channel";
	private static final String PROPERTY_NAME_JMS_OUTBOUND_QUEUE = "jms.mq.outbound.queue";
	private static final String PROPERTY_NAME_JMS_TRANSPORT_TYPE = "jms.mq.transportType";
	private static final String PROPERTY_NAME_JMS_KEYSTORE_PATH = "jms.keystore.path";
	//private static final String PROPERTY_NAME_JMS_KEYSTORE_PASSWORD = "jms.keystore.password";
	private static final String PROPERTY_NAME_JMS_SSL_CIPHER_SUITE = "jms.mq.SSLCipherSuite";
	private static final String PROPERTY_NAME_JMS_SESSION_CACHE_SIZE = "jms.session.cache.size";

	@Bean
	public MQQueueConnectionFactory mqConnectionFactory() throws NumberFormatException, JMSException {
		MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
		mqQueueConnectionFactory.setHostName(env.getRequiredProperty(PROPERTY_NAME_JMS_HOST));
		mqQueueConnectionFactory.setPort(Integer.parseInt(env.getRequiredProperty(PROPERTY_NAME_JMS_PORT)));
		mqQueueConnectionFactory.setChannel(env.getRequiredProperty(PROPERTY_NAME_JMS_CHANNEL));
		mqQueueConnectionFactory.setQueueManager(env.getRequiredProperty(PROPERTY_NAME_QUEUE_MANAGER));
		mqQueueConnectionFactory.setTransportType(Integer.parseInt(env.getRequiredProperty(PROPERTY_NAME_JMS_TRANSPORT_TYPE)));
		mqQueueConnectionFactory.setSSLCipherSuite(env.getRequiredProperty(PROPERTY_NAME_JMS_SSL_CIPHER_SUITE));
		return mqQueueConnectionFactory;
	}
	
	public CachingConnectionFactory cachingConnectionFactory() throws NumberFormatException, JMSException{
		CachingConnectionFactory cachingConnectionFactory =  new CachingConnectionFactory();
		cachingConnectionFactory.setTargetConnectionFactory(mqConnectionFactory());
		cachingConnectionFactory.setSessionCacheSize(Integer.parseInt(env.getRequiredProperty(PROPERTY_NAME_JMS_SESSION_CACHE_SIZE)));
		return cachingConnectionFactory;
	}

	@Bean
	public MQQueue mqReader() throws JMSException {
		MQQueue mqQueue = new MQQueue();
		mqQueue.setBaseQueueName(env.getRequiredProperty(PROPERTY_NAME_JMS_OUTBOUND_QUEUE));
		return mqQueue;
	}

	@Bean
	public org.springframework.jms.support.destination.DynamicDestinationResolver destResolver() {
		return new DynamicDestinationResolver();
	}

	@Bean
	public JmsTemplate jmsTemplate() throws NumberFormatException, JMSException {
		JmsTemplate jmsTemplate = new JmsTemplate();
		jmsTemplate.setConnectionFactory(cachingConnectionFactory());
		jmsTemplate.setDestinationResolver(destResolver());
		jmsTemplate.setDefaultDestinationName(env.getRequiredProperty(PROPERTY_NAME_JMS_OUTBOUND_QUEUE));
		jmsTemplate.setPubSubDomain(false);
		jmsTemplate.setReceiveTimeout(20000);
		return jmsTemplate;

	}

	@Bean(name = "jSSL")
	public MethodInvokingFactoryBean methodInvokingFactoryBeanJSSL() {
		MethodInvokingFactoryBean methodInvokingFactoryBean = new MethodInvokingFactoryBean();
		methodInvokingFactoryBean.setTargetClass(java.lang.System.class);
		methodInvokingFactoryBean.setTargetMethod("setProperty");
		methodInvokingFactoryBean.setArguments(
				new Object[] { "javax.net.ssl.keyStore", env.getRequiredProperty(PROPERTY_NAME_JMS_KEYSTORE_PATH) });
		return methodInvokingFactoryBean;
	}

	@Bean(name = "jPASS")
	public MethodInvokingFactoryBean methodInvokingFactoryBeanJPASS() {
		MethodInvokingFactoryBean methodInvokingFactoryBean = new MethodInvokingFactoryBean();
		methodInvokingFactoryBean.setTargetClass(java.lang.System.class);
		methodInvokingFactoryBean.setTargetMethod("setProperty");
		methodInvokingFactoryBean.setArguments(new Object[] { "javax.net.ssl.keyStorePassword",
				EncryptionUtil.decrypt(env.getRequiredProperty("jms.keystore.password")) });
		return methodInvokingFactoryBean;
	}
	
}