package com.jpmorgan.cib.wlt.ctrac.service.dto.json;

import java.io.Serializable;

/**
 * Created by V704662 on 8/8/2017.
 */
public class ValidationError implements Serializable {

    private static final long serialVersionUID = 1495215105446231813L;
    private String fieldId;
    private String message;

    public ValidationError(String message){
        this.message = message;
    }

    public ValidationError(String fieldId, String message){
        this.fieldId = fieldId;
        this.message = message;
    }

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(String fieldId) {
        this.fieldId = fieldId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
