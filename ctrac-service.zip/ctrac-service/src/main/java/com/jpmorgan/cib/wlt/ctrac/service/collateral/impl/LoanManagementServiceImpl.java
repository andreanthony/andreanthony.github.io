/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.service.collateral.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CollateralEventType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.*;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.AddressDataService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CustomerDataService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.view.PrimaryLoanBorrowerViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.event.store.client.CollateralEventSection;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LineOfBusinessService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LineOfBusinessDTO;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.viewdata.ViewDataRetrievalService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author n595724
 *
 */
@Service(value = "loanManagementService")
public class LoanManagementServiceImpl implements LoanManagementService {

    @Autowired
    private AddressDataService addressDataService;
    @Autowired
    private CollateralRepository collateralRepository;
    @Autowired
    private CtracObjectMapper ctracObjectMapper;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CustomerDataService customerDataService;
    @Autowired
    private LineOfBusinessService lobService;
    @Autowired
    private LoanRepository loanRepository;
    @Autowired
    private LoanBorrowerRepository loanBorrowerRepository;
    @Autowired
    private LoanCollateralRepository loanCollateralRepository;
	@Autowired
	private CollateralInsuranceRepository collateralInsuranceRepository;
	@Autowired
	private ViewDataRetrievalService viewDataRetrievalService;
    @Autowired private PublishEventService publishEventService;


    private static final Logger logger = Logger.getLogger(LoanManagementServiceImpl.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService
     * #getLoanByCollateral(java.lang.Long)
     */
    @Override
    @Transactional
    public Collection<LoanData> getLoanByCollateral(Long collateralRId) {

        logger.debug("getLoanByCollateral(" + collateralRId + " )::BEGIN");

        Collateral collateral = collateralRepository.findOne(collateralRId);

        if (collateral != null && collateral.getLoanCollaterals() != null) {
            return getUniqueLoans(collateral.getLoanCollaterals());
        }
        logger.debug("getLoanByCollateral::END");
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService
     * #getBorrowersByLoan(java.lang.Long)
     */
    @Override
    @Transactional
    public Collection<CustomerData> getBorrowersByLoan(Long loanRid) {

        logger.debug("getBorrowersByLoan(" + loanRid + " )::BEGIN");

        Loan aloan = loanRepository.findOne(loanRid);

        if (aloan != null && aloan.getLoanBorrowers() != null) {
            return getUniqueCustomers(aloan.getLoanBorrowers());
        }

        logger.debug("getBorrowersByLoan::END");
        return null;
    }

    @Override
    public String getBranchCode(Long loanRid) {
        logger.debug("getBranchCode(" + loanRid + " )::BEGIN");
        Loan loan = loanRepository.findOne(loanRid);
        if (loan != null) {
            LineOfBusinessDTO lob = lobService.findByCode(loan.getLineOfBusiness());
            if (lob != null) {
                return lob.getBranchCode();
            }
        }
        logger.debug("getBranchCode::END");
        return "";
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService
     * #geBorrowersByCollateral(java.lang.Long)
     */
    @Override
    @Deprecated
    // implement and remove deprecation
    public Collection<CustomerData> geBorrowersByCollateral(Long collateralRId) {

        // List<CollateralOwner> collateralOwner =
        // //TODO FIXME implement

        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService
     * #saveLoans(java.util.Collection)
     */
    @Override
    @Transactional
    public Collection<LoanData> saveLoans(Long collateralID,Collection<LoanData> loansData) {

        for (LoanData oneLoanData : loansData) {
            saveLoan(collateralID, oneLoanData);
        }
        return loansData;

    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService
     * #saveLoan(com.jpmorgan.cib.wlt.ctrac.dto.LoanData)
     */
    @Override
    @Transactional
    public LoanData saveLoan(Long collateralID,LoanData loanData) {
    	logger.debug(" save loan start: loan id is : " + loanData.getRid());
        Set<Long> borrowerNumber = new HashSet<>();
        // 1- First save the inner properties recursively
        if (loanData.getBorrowersData() != null && !loanData.getBorrowersData().isEmpty()) {
        	for (CustomerData borrower : loanData.getBorrowersData()) {
        		if (borrower.hasChanged()) {
        			customerDataService.saveCustomer(borrower);
                    borrowerNumber.add(borrower.getRid());
             		}
        	}
        }

        // 2 Create a new loan or fetch and existing one that need to be updated
        Loan loan = new Loan();
        if (loanData.getRid() != null) {
            loan = loanRepository.findOne(loanData.getRid());
         }
        
        // 3 create new LoanBorrowers relation if needed
        if (loanData.getBorrowersData() != null && !loanData.getBorrowersData().isEmpty()) {
            Set<Long> customerRids = new HashSet<>();
            for (CustomerData customerData : loanData.getBorrowersData()) {
                customerRids.add(customerData.getRid());
            }
            Iterator<LoanBorrower> lbIter = loan.getLoanBorrowers().iterator();
            while (lbIter.hasNext()) {
                LoanBorrower lb = lbIter.next();
                if (!customerRids.contains(lb.getBorrower().getRid())) {
                    loanBorrowerRepository.delete(lb);
                    publishEventService.publishLoanBorrowerEvent(loanData, collateralID, CollateralEventType.REMOVED, CollateralEventSection.BORROWER);
                    lbIter.remove();
                }

            }
            for (CustomerData customerData : loanData.getBorrowersData()) {
                // only new relation will be added as per the {loan.addBorrower} specs
                Customer savedBorrower = customerRepository.findOne(customerData.getRid());
                if (loan.addBorrower(savedBorrower)) {
                    publishEventService.publishLoanBorrowerEvent(loanData, collateralID, CollateralEventType.ADDED, CollateralEventSection.BORROWER);
                }
                else
                {
                    for (Long borrowerId : borrowerNumber)
                    {
                        if(customerData.getRid().equals(borrowerId))
                        {    publishEventService.publishLoanBorrowerEvent(loanData, collateralID, CollateralEventType.EDITED, CollateralEventSection.BORROWER);
                        }
                    }
                }

            }

        }


        // 4 check if loan's property has changed (only top level properties)
        // copy outer/top properties of the dto to the top property of loan
        // the loan inner properties were already copied and persisted on step 1 & 3
        if (loanData.hasChanged()) {
            ctracObjectMapper.map(loanData, loan);

          if(collateralID!=null)  // do not publish event for create collateral. the code for that is in createcollateralservice
            {
                if (loanData.getRid() == null) {
                    publishEventService.publishLoanBorrowerEvent(loanData, collateralID, CollateralEventType.ADDED, CollateralEventSection.LOAN);
                } else {
                    if (LoanStatus.PENDING_VERIFICATION != loanData.getStatus()) {
                        publishEventService.publishLoanBorrowerEvent(loanData, collateralID, CollateralEventType.VERIFIED, CollateralEventSection.LOAN);
                    }
                    if(loanData.hasLoanChanged())
                    {
                            publishEventService.publishLoanBorrowerEvent(loanData, collateralID, CollateralEventType.EDITED, CollateralEventSection.LOAN);

                    }

                }
            }
        }

        loan = loanRepository.save(loan);

        loanData.setRid(loan.getRid());
        // cache a copy for comparison when saving back the object
        // if the properties values had not changed, skip saving to the DB
        loanData.saveACopy();
        loanData.refreshAuditUpdate(loan);

        logger.debug(" save loan end : loan id is : " + loanData.getRid());
        return loanData;
    }

    private Collection<LoanData> getUniqueLoans(List<LoanCollateral> loanCollaterals) {
        Set<Loan> loanSet = new HashSet<Loan>();
        for (LoanCollateral loanCollateral : loanCollaterals) {
            loanSet.add(loanCollateral.getLoan());
        }
        return getLoanDataFromLoans(loanSet);
    }

	private Collection<LoanData> getLoanDataFromLoans(Collection<Loan> loans) {
		List<LoanData> loansData = ctracObjectMapper.mapAsList(loans, LoanData.class);
        for (LoanData aloan : loansData) {
            aloan.saveACopy();
        }
        return loansData;
	}
	
	private LoanData getLoanDataFromLoan(Loan loan) {
		LoanData loanData = ctracObjectMapper.map(loan, LoanData.class);
       	loanData.saveACopy();
        return loanData;
	}

    private Collection<CustomerData> getUniqueCustomers(List<LoanBorrower> loanBorrowers) {
        // TODO Auto-generated method stub
        Set<Customer> customerSet = new HashSet<Customer>();
        for (LoanBorrower loanBorrower : loanBorrowers) {
            customerSet.add(loanBorrower.getBorrower());
        }

        List<CustomerData> borrowersData = ctracObjectMapper.mapAsList(customerSet, CustomerData.class);
        for (CustomerData customerData : borrowersData) {
            customerData.saveACopy();

        }
        return borrowersData;
    }

    @Transactional
    public void removeLoanCollateral(long collateralID, Collection<LoanData> loansToDelete) {

        if (loansToDelete == null || loansToDelete.isEmpty()) {
            return;
        }
        Collateral colateral = collateralRepository.findOne(collateralID);

        Iterator<LoanData> loanDataItr = loansToDelete.iterator();
  		while (loanDataItr.hasNext()) {
  			LoanData loanData  =loanDataItr.next();	
        LoanCollateral lcdelete = loanCollateralRepository.findByLoanRidAndCollateralRid(loanData.getRid(), collateralID);
        if (lcdelete != null) {
            loanCollateralRepository.delete(lcdelete);
            colateral.getLoanCollaterals().remove(lcdelete);
            Loan loan = loanRepository.findOne(loanData.getRid());
            publishEventService.publishLoanBorrowerEvent(loanData,collateralID, CollateralEventType.DELETED, CollateralEventSection.LOAN);

            loan.getLoanCollaterals().remove(lcdelete);
        }
    }       
    collateralRepository.save(colateral);
   

    }
   
    
    @Override
    @Transactional
	public List<LoanData> getPrimaryLoans(List<CollateralDto> collateralDtoList) {
		List<LoanData> loanBorrowerList = new ArrayList<LoanData>();
		for(CollateralDto collateralDto: collateralDtoList){
			for(LoanData loanBorrower : collateralDto.getLoansData()){
				if("Yes".equalsIgnoreCase(loanBorrower.getPrimaryFlag())){
					loanBorrowerList.add(loanBorrower);
				}
			}
		}
		return loanBorrowerList;
	}

	@Override
	public boolean hasAtLeastOneActiveLoan(Long collateralRid){
		Collection<LoanData> loanDatas = getLoanByCollateral(collateralRid);
		for(LoanData loanData: loanDatas){
			if(LoanStatus.ACTIVE == loanData.getStatus()){
				return true;
			}
		}
		return false;
	}

	@Override
	@Transactional(readOnly = true)
	public Collection<LoanData> findByLoanNumber(String loanNumber) {
		Collection<LoanData> loanData = new ArrayList<LoanData>();
		List<Loan> loans = loanRepository.findByLoanNumberContaining(loanNumber);
		if (loans != null && !loans.isEmpty()) {
			loanData = getLoanDataFromLoans(loans);
		}
		return loanData;
	}
	
	@Override
	@Transactional(readOnly = true)
	public Collection<LoanData> findByBorrowerName(String borrowerName) {
		Collection<LoanData> loanData = new ArrayList<LoanData>();
		List<LoanBorrower> loanBorrowers = loanBorrowerRepository.findDistinctByBorrowerNameContaining(borrowerName);
		for (LoanBorrower loanBorrower : loanBorrowers) {
			loanData.add(getLoanDataFromLoan(loanBorrower.getLoan()));
		}
		return loanData;
	}

	@Override
	@Transactional(readOnly = true)
	public LoanData findByRid(Long loanRid, Long collateralRid) {
		Loan loan = loanRepository.findOne(loanRid);
		LoanData loanData = getLoanDataFromLoan(loan);
		for (LoanCollateral lc : loan.getLoanCollaterals()) {
			if (collateralRid.equals(lc.getCollateral().getRid())) {
				loanData.setPrimaryFlag(lc.getPrimaryFlag());
				break;
			}
		}
		return loanData;
	}
	
	@Override
	@Transactional
	public LoanSystem getLoanSystem(Long lpPolicyRid) {
		logger.debug("getLoanSystem: start");
		LoanSystem loanSystem = null;
		List<CollateralInsuranceViewData> ci = collateralInsuranceRepository.findByProofOfCoverageRid(lpPolicyRid);
		if(ci != null && !ci.isEmpty()){
			PrimaryLoanBorrowerViewDto loanDetails = viewDataRetrievalService.getPrimaryLoanBorrowerDetailsByCollateral(ci.get(0).getCollateral().getRid());
		    loanSystem = LoanSystem.fromString(loanDetails.getLoanAccountingSystem());
		}
		logger.debug("getLoanSystem: end" + (loanSystem == null? null : loanSystem.toString()));
		return loanSystem;
	}


}
