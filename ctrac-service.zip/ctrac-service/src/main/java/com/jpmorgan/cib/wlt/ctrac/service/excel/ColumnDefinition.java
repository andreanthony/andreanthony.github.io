package com.jpmorgan.cib.wlt.ctrac.service.excel;

public class ColumnDefinition {

	private String columnLabel;
	private String fieldName;
	private FieldType fieldType;
	private FieldExpression fieldExpression;

	public ColumnDefinition (String columnLabel, String fieldName, FieldType fieldType) {
		this.columnLabel = columnLabel;
		this.fieldName = fieldName;
		this.fieldType = fieldType;
	}

	public ColumnDefinition (String columnLabel, String fieldName, FieldType fieldType, FieldExpression fieldExpression) {
		this(columnLabel,fieldName,fieldType);
		this.fieldExpression = fieldExpression;
	}

	public String getColumnLabel() {
		return columnLabel;
	}

	public void setColumnLabel(String columnLabel) {
		this.columnLabel = columnLabel;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public FieldType getFieldType() {
		return fieldType;
	}

	public void setFieldType(FieldType fieldType) {
		this.fieldType = fieldType;
	}

	public FieldExpression getFieldExpression() {
		return fieldExpression;
	}

	public void setFieldExpression(FieldExpression fieldExpression) {
		this.fieldExpression = fieldExpression;
	}
}
