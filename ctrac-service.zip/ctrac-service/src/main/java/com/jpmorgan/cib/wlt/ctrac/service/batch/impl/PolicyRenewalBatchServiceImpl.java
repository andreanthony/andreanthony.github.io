/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.service.batch.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpmorgan.cib.wlt.ctrac.service.batch.PolicyRenewalBatchService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;

/**
 * @author Q003321
 * 
 */
@Service(value = "policyRenewalBatchService")
public class PolicyRenewalBatchServiceImpl implements PolicyRenewalBatchService {

	private static final Logger logger = Logger.getLogger(PolicyRenewalBatchServiceImpl.class);

	@Autowired
	protected InsuranceMngtService insuranceMngtService;

	/*
	 * (non-Javadoc) job to create a renewalpolicy with status as Inreview for
	 * an existing policy that is of type Barrower Ins and about to expire in
	 * less than or equal to 50 calendar days
	 */
	@Override
	public void initiatePolicyRenewalReviewProcess() {
		// run the batch only if the frequency is ok.
		logger.debug("initiatePolicyRenewalReviewProcess::BEGIN");
		insuranceMngtService.initiateRenewalWorkflow();
		logger.debug("initiatePolicyRenewalReviewProcess::END");
	}

}
