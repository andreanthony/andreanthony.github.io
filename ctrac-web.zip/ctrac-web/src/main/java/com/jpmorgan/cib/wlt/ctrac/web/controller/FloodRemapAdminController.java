package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.BatchJobMaintenanceData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodZoneDto;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


@Controller
@SessionAttributes({ "floodRemapDto", "batchJobMaintenanceData" })
public class FloodRemapAdminController extends BaseController {

	@Autowired
	@Qualifier("floodRemapAdminService")
	FloodRemapAdminService floodRemapAdminService;

	@Autowired
	@Qualifier("emailAttachmentsBucket")
	EmailAttachmentsBucket emailAttachmentsBucket;

	@Autowired
	private BatchCtrlRepository	batchCtrlRepository;

	@Resource
	private Environment env;

	private static final Logger logger = Logger.getLogger(FloodRemapAdminController.class);

	@RequestMapping(value = "admin/floodRemap/launchCreate", method = RequestMethod.GET)
	@Secured({EntitlementRoles.WRITER_ROLE})
	public String displayCreateFloodRemapRecord(HttpServletRequest request, HttpServletResponse response, ModelMap model) {

		try {
			logger.debug("displayCreateFloodRemapRecord::Start");
			FloodRemapDto floodRemapDto = floodRemapAdminService.prepareDisplayCreateNewRemap();
			model.addAttribute("floodRemapDto", floodRemapDto);
			logger.debug("displayCreateFloodRemapRecord() from research item::END");
			return "admin/floodRemapCreateNewRecord";

		}catch (Exception ex) {
			logger.error("Unable to launch displayCreateFloodRemapRecord");
			// TODO: use proper error message
			throw new CTracWebAppException("E0192", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "admin/floodRemap/createRecord", method = RequestMethod.POST)
	public ModelAndView processCreateFloodRemapRecord(
			@Valid @ModelAttribute("floodRemapDto") FloodRemapDto floodRemapDto,
			BindingResult binding, HttpServletRequest request, HttpServletResponse response/*, final RedirectAttributes redirectAttributes*/) {

		ModelAndView modelAndView = new ModelAndView();
		try {
			logger.debug("processCreateFloodRemapRecord::Start");

			EmailAttachments attachments = emailAttachmentsBucket.popEmailAttachments(floodRemapDto.getTmTaskId());

			if (attachments != null && !attachments.getAllFilesAsList().isEmpty()) {
				floodRemapDto.setSFHDF(attachments.getAllFilesAsList().get(0));
			}

			if (binding.hasErrors()) {
				logger.error("binding has errors");
				modelAndView.addObject("floodRemapDto", floodRemapDto);
				modelAndView.setViewName("admin/floodRemapCreateNewRecord");
				return modelAndView;
			} else {
				String janusUserId = (String) request.getSession().getAttribute("JANUS_USER_ID");
				if (janusUserId == null) {
					janusUserId = "LOCAL";
				}
				logger.debug("creating new record for user: " + janusUserId);

				PerfectionTask task = floodRemapAdminService.processCreateNewRemap(floodRemapDto);

				logger.debug("processCreateFloodRemapRecord()::END");

				modelAndView.setViewName("redirect:/admin/confirmation");
			}

			return modelAndView;

		} catch (Exception ex) {
			logger.error("Manual create failed while creating new task in TM. Error: " + ex.getMessage());
			throw new CTracWebAppException("E0147", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	@Secured({EntitlementRoles.OPERATE_WRITERS})
	public ModelAndView launchAdminHome(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		try {
            logger.debug("launchAdminHome::Start");
            String serverEnv = env.getActiveProfiles()[0];

            if (serverEnv != null && !serverEnv.equalsIgnoreCase("PROD")) {
                modelAndView.setViewName("admin/index");
            } else {
                modelAndView.setViewName("admin/prod-admin-index");
            }

			logger.debug("launchAdminHome::END");
			return modelAndView;

		} catch (Exception e) {
			logger.error("Unable to open launchAdminHome");
			// TODO: use proper error message
			throw new CTracWebAppException("E0193", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "/admin2", method = RequestMethod.GET)
	@Secured({EntitlementRoles.OPERATE_WRITERS})
    public ModelAndView launchOperateAdminPage(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView modelAndView = new ModelAndView();
        try {
            logger.debug("launchAdminHome::Start");

            String serverEnv = env.getActiveProfiles()[0];
            if (serverEnv != null && !serverEnv.equalsIgnoreCase("PROD")) {
                modelAndView.setViewName("admin/operateadmin");
            } else {
                modelAndView.setViewName("/index");
            }
            logger.debug("launchAdminHome::END");
            return modelAndView;

        } catch (Exception e) {
            logger.error("Unable to open launchAdminHome");
            throw new CTracWebAppException("E0193", CtracErrorSeverity.APPLICATION);
        }
    }

	@RequestMapping(value = "/admin/floodRemap/getFloodZoneOptions", method = RequestMethod.GET)
	public @ResponseBody List<FloodZoneDto> getFloodZoneOptions(@ModelAttribute("floodRemapDto") FloodRemapDto floodRemapDto, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("getFloodZoneOptions::BEGIN");
		String remapType = request.getParameter("remapType");
		List<FloodZoneDto> floodZoneOptions = new ArrayList<FloodZoneDto>();
		if (remapType == null) {
			return floodZoneOptions;
		} else {
			Set<String> floodZoneCodes = floodRemapDto.getRevisedFloodZoneOptions(remapType);
			for (String floodZoneCode : floodZoneCodes) {
				floodZoneOptions.add(new FloodZoneDto(floodZoneCode));
			}
		}
		logger.debug("getFloodZoneOptions::END");
		return floodZoneOptions;
	}

	@RequestMapping(value = "/admin/confirmation", method = RequestMethod.GET)
	@Secured({EntitlementRoles.READER_ROLE})
	public String launchAdminConfirmation(HttpServletRequest request, HttpServletResponse response, ModelMap model) {

		try {
			logger.debug("launchAdminHome::Start");
			logger.debug("launchAdminHome::END");
			return "admin/confirmation";
		} catch (Exception e) {
			logger.error("Unable to open launchAdminConfirmation");
			throw new CTracWebAppException("E0193", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "/admin/manageBatchJobs", method = RequestMethod.GET)
	public String manageBatchJobs(HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		logger.debug("manageBatchJobs::BEGIN");

		BatchJobMaintenanceData batchJobMaintenanceData = new BatchJobMaintenanceData();
		List<BatchCtrl> batches = batchCtrlRepository.findByCanHoldReleaseFlag('Y');
		batchJobMaintenanceData.setBatchCtrl(batches);

		model.addAttribute("batchJobMaintenanceData", batchJobMaintenanceData);
		session.setAttribute("batchJobMaintenanceData", batchJobMaintenanceData);

		logger.debug("manageBatchJobs::END");
		return ("admin/manageBatchJobs");
	}

	@RequestMapping(value = "/admin/updateBatchJob", method = RequestMethod.POST)
	public String updateBatchJob(@ModelAttribute("batchJobMaintenanceData") BatchJobMaintenanceData batchJobMaintenanceData,
			@RequestParam("batchId") Long batchId,
			@RequestParam("action") String action,
			HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		logger.debug("updateLoanBorrowerAddress::BEGIN");

		logger.info("updateBatchJob. batchId: " + batchId + " action: " + action);
		for (BatchCtrl batchCtrl : batchJobMaintenanceData.getBatchCtrl()) {
			if (batchCtrl.getRid().equals(batchId)) {
				if (action.equals("hold")) {
					batchCtrl.setCtrlFlag('N');
				} else if (action.equals("release")) {
					batchCtrl.setCtrlFlag('Y');
				}

				batchCtrlRepository.save(batchCtrl);
			}
		}

		batchJobMaintenanceData = new BatchJobMaintenanceData();
		List<BatchCtrl> batches = batchCtrlRepository.findByCanHoldReleaseFlag('Y');
		batchJobMaintenanceData.setBatchCtrl(batches);

		model.addAttribute("batchJobMaintenanceData", batchJobMaintenanceData);
		session.setAttribute("batchJobMaintenanceData", batchJobMaintenanceData);

		logger.debug("updateBatchJob::END");
		return ("admin/manageBatchJobs");
	}

}
