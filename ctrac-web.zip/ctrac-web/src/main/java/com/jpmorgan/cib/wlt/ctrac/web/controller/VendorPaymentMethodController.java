package com.jpmorgan.cib.wlt.ctrac.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VendorInvoiceData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
@Controller
@RequestMapping(value = "/floodRemap")
@SessionAttributes({ "floodRemapVendorInvoiceVerificationData", "tmParams"})
public class VendorPaymentMethodController extends BaseController  {

	private static final Logger logger = Logger.getLogger(VendorPaymentMethodController.class);
	
	@Autowired
	@Qualifier("lenderPlaceService")
	LenderPlaceService lenderPlaceService;
	
	@Autowired
	private MessageSource messageSource;
	
	@RequestMapping(value = "/launchVerifyPaymentMethod", method = RequestMethod.GET)
	public String launchVerifyPaymentMethod(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchVerifyPaymentMethod start()");
		
		if (tmParams.getId_task() != null) {
			String strConfirmHelperPage = checkTaskInReviewStatus(model,tmParams);
			if(strConfirmHelperPage != null && strConfirmHelperPage.equalsIgnoreCase("")){
			
				try {				
					VendorInvoiceData floodRemapVendorInvoiceVerificationData = lenderPlaceService.prepareVendorInvoiceVerificationData(tmParams);
					model.addAttribute("floodRemapVendorInvoiceVerificationData", floodRemapVendorInvoiceVerificationData);
					//dynamic title		
					if(floodRemapVendorInvoiceVerificationData.getIsPolicyCancelled()){
						floodRemapVendorInvoiceVerificationData.setScreenTitle("Vendor Refund Method");
					}else{
						floodRemapVendorInvoiceVerificationData.setScreenTitle("Vendor Payment Method");
					}
					
					return "verifyPaymentMethod";
					
				}catch(Exception e){
					logger.error(e.getMessage());
					logger.error("Error occurred while preparing VerifyPaymentMethod page" + e.getMessage());				
					throw new CTracWebAppException("E0242", CtracErrorSeverity.APPLICATION, tmParams);
				}finally {
					logger.debug("launchVerifyPaymentMethod()::End");
				}
			}else {
				return strConfirmHelperPage;//return 'InReview' confirmation page.
			}
			
		}else {
			logger.error("Received Task UUID from TM is null");
			logger.debug("launchVerifyPaymentMethod exit()");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}
	}
	
	/**
	 * Controller method to save and continue from Cancel refund confirmation helper page
	 * @param ModelAttribute floodRemapVendorInvoiceVerificationData
	 * @param request HttpServletRequest
	 * @param model ModelMap 
	 * @param tmParams.id_task String
	 * @param SessionStatus sessionStatus
	 *  @param  BindingResult binding
	 * @return String
	 */	
	@RequestMapping(value = "/savePaymentMethod/{taskId}", method = RequestMethod.POST, params = { "saveAndContinue" })
	public String saveAndContinuePaymentMethod(@Valid @ModelAttribute("floodRemapVendorInvoiceVerificationData") VendorInvoiceData floodRemapVendorInvoiceVerificationData, BindingResult binding, @PathVariable String taskId,
			ModelMap model, SessionStatus sessionStatus, HttpServletRequest request) {
		
		if(floodRemapVendorInvoiceVerificationData.getTmParams() == null){
			logger.error("Received TM params is null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		try {  
			logger.debug("saveAndContinuePaymentMethod()::Start");
        	
        	if (!binding.hasErrors()) {
        		logger.debug("Inside saveAndContinuePaymentMethod handling request '/floodRemapVendorInvoice' with save and continue");
        		TMParams tmParams = floodRemapVendorInvoiceVerificationData.getTmParams();
				//save the inforamtion
				lenderPlaceService.processSubmitVendorInvoiceVerification(floodRemapVendorInvoiceVerificationData);			    
			    logger.debug("TM transaction ID ::" + floodRemapVendorInvoiceVerificationData.getTmParams().getTmTransactionId());
			    model.addAttribute("confirmation", messageSource.getMessage("paymentMethod.save.confirmation", null, null));
			    return "floodRemapConfirmation";
        	} else {
        		logger.debug("saveAndContinuePaymentMethod()::validationFailure");
				     		
        		return "verifyPaymentMethod";
        	}
		}
		catch(Exception e) {
            logger.error(e.getMessage());
            throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, floodRemapVendorInvoiceVerificationData.getTmParams());
		}
	}

	@RequestMapping(value = "/savePaymentMethod/{taskId}", method = RequestMethod.POST, params = { "process" })
	public ModelAndView savePaymentMethod(@Valid @ModelAttribute("floodRemapVendorInvoiceVerificationData") VendorInvoiceData floodRemapVendorInvoiceVerificationData,BindingResult binding,
										  @PathVariable String taskId, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request) {
		
		if(floodRemapVendorInvoiceVerificationData.getTmParams() == null){
			logger.error("Received TM params is null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		try{  
			logger.debug("savePaymentMethod()::Start");
			ModelAndView modelAndView = new ModelAndView();
        	
        	if (!binding.hasErrors()) {
        		logger.debug("Inside savePaymentMethod handling request '/floodRemapVendorInvoice' with submit only");
				
				lenderPlaceService.processSubmitVendorInvoiceVerification(floodRemapVendorInvoiceVerificationData);

				modelAndView.addObject("confirmation", messageSource.getMessage("invoiceVerification.submit.confirmation", null, null));
    			
    			modelAndView.setViewName("floodRemapConfirmation"); 
    			logger.debug("floodRemapCoverageInputSubmit()::End");
    			return modelAndView;
        	} else {
        		modelAndView.setViewName("verifyPaymentMethod");
				modelAndView.addObject("floodRemapVendorInvoiceVerificationData", floodRemapVendorInvoiceVerificationData);	
				logger.debug("savePaymentMethod()::validationFailure");
				return modelAndView;
        	}
		}
		catch(Exception e) {
            logger.error(e.getMessage());
            throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, floodRemapVendorInvoiceVerificationData.getTmParams());
		}
		
	}

}
