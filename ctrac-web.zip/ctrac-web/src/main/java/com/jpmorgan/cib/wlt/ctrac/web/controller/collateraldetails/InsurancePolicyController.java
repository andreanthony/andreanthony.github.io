package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.validator.StartLetterCycleWorkflowValidator;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.*;

@Controller
@RequestMapping("admin")
@SessionAttributes({ "collateralDetailsData", "proofOfCoverageData","referenceValues" })
public class InsurancePolicyController {

    private static final String DEFAULT_ERROR_MESSAGE = "Save failed. Please try again.";

	private static final Logger logger = Logger.getLogger(InsurancePolicyController.class);

    @Autowired private CollateralDetailsService collateralDetailsService;
    @Autowired private CollateralDetailsStatusService collateralDetailsStatusService;
    @Autowired private CollateralDocumentService collateralDocumentService;
    @Autowired private InsuranceMngtService insuranceMngtService;
    @Autowired private StartLetterCycleWorkflowValidator startLetterCycleWorkflowValidator;
        
    @Secured({EntitlementRoles.READER_ROLE}) 
    @RequestMapping(value = "getInsuranceSection", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView getInsuranceSection(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto, ModelMap model) {
        logger.debug("getInsuranceSection::BEGIN");
        // LCP-3411 Start verification button should go away after the last LP policy is verified (or only LP policy if there is just one). This should happen after Complete Verification
        //  and before screen refresh.
        CollateralDto collateralDto = collateralDetailsMainDto.getCollateralDto();
        collateralDetailsStatusService.loadAllCollateralSectionsStatus(collateralDto, collateralDetailsMainDto.getSectionStatusDtos());
        collateralDetailsService.refreshInsurancePoliciesSection(
        		collateralDetailsMainDto.getCollateralDto().getRid(), collateralDetailsMainDto.getInsuranceSectionData());
        logger.debug("getInsuranceSection::END ");
        return new ModelAndView("admin/insurancePolicySection", model);
    }

    @Secured({EntitlementRoles.READER_ROLE})
    @RequestMapping(value = "newInsurancePolicy", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView launchNewInsurancePolicy(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
            @RequestParam("policyRid") Long policyRid, @RequestParam("mode") Integer mode,
            ModelMap model, SessionStatus sessionStatus, HttpServletRequest request, HttpServletResponse response) {
        logger.debug("launchNewInsurancePolicy::BEGIN");
        ProofOfCoverageDTO proofOfCoverageData;
		try {
			response.setContentType(TEXT_PLAIN);
			response.setCharacterEncoding(UTF_8);
			response.addHeader(X_UA_COMPATIBLE, IE_EDGE);
			proofOfCoverageData = collateralDetailsMainDto.getInsuranceSectionData().getFloodPolicy(
					policyRid, collateralDetailsMainDto.getCollateralDto().getRid());
			if (proofOfCoverageData.getRid() == null) {
				proofOfCoverageData.setMigrated(true);
			}
			for (Long collateralId : proofOfCoverageData.getProvidedCoverageMap().getInsurableAssetCoverageData().keySet()) {
				collateralDetailsService.putCollateralDescription(collateralDetailsMainDto, collateralId);
			}
            collateralDetailsMainDto.getInsuranceSectionData().setVerifyMode(
					proofOfCoverageData.getPolicyStatus() == PolicyStatus.PENDING_VERIFICATION && mode == 2);
			model.addAttribute("proofOfCoverageData", proofOfCoverageData);
		} catch (CTracWebAppException e) {
			collateralDetailsMainDto.setDisplayMsg(e.getErrorMessage());
			handleRemoteException(e.getErrorMessage(), e, collateralDetailsMainDto);
		} catch (Exception e) {
			handleRemoteException(DEFAULT_ERROR_MESSAGE, e, collateralDetailsMainDto);
		}
		logger.debug("launchNewInsurancePolicy::END");
		return new ModelAndView("collateralScreenNewInsurancePolicy", model);
    }

    @Secured({EntitlementRoles.ADMIN_ROLE})
    @RequestMapping(value = "overrideInsurancePolicy", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView launchOverridePolicy(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
            @RequestParam("policyRid") Long policyRid, @RequestParam("mode") Integer mode,
            ModelMap model, SessionStatus sessionStatus, HttpServletRequest request, HttpServletResponse response) {
        logger.debug("launchOverridePolicy::BEGIN");
        ProofOfCoverageDTO proofOfCoverageData;
		try {
			response.setContentType(TEXT_PLAIN);
			response.setCharacterEncoding(UTF_8);
			response.addHeader(X_UA_COMPATIBLE, IE_EDGE);
			proofOfCoverageData = collateralDetailsMainDto.getInsuranceSectionData().getFloodPolicy(
					policyRid, collateralDetailsMainDto.getCollateralDto().getRid());
			for (Long collateralId : proofOfCoverageData.getProvidedCoverageMap().getInsurableAssetCoverageData().keySet()) {
				collateralDetailsService.putCollateralDescription(collateralDetailsMainDto, collateralId);
			}
			model.addAttribute("proofOfCoverageData", proofOfCoverageData);
		} catch (CTracWebAppException e) {
			collateralDetailsMainDto.setDisplayMsg(e.getErrorMessage());
			handleRemoteException(e.getErrorMessage(), e, collateralDetailsMainDto);
		} catch (Exception e) {
			handleRemoteException(DEFAULT_ERROR_MESSAGE, e, collateralDetailsMainDto);
		}
		logger.debug("launchOverridePolicy::END");
		return new ModelAndView("collateralScreenOverrideInsurancePolicy", model);
    }

    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "addCollateralToPolicy", method = RequestMethod.GET)
    public String addCollateralToPolicy(@ModelAttribute("proofOfCoverageData") ProofOfCoverageDTO proofOfCoverageData,
            @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
            @RequestParam("collateralId") Long collateralId, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request,
            HttpServletResponse response) {
        logger.debug("launchNewInsurancePolicy::BEGIN");
        try {
            response.setContentType(TEXT_PLAIN);
            response.setCharacterEncoding(UTF_8);
            response.addHeader(X_UA_COMPATIBLE, IE_EDGE);
            proofOfCoverageData.setDisplayMessage(null);
    		insuranceMngtService.addCollateralToPolicy(proofOfCoverageData, collateralId);
    		collateralDetailsService.putCollateralDescription(collateralDetailsMainDto, collateralId);
        } catch (CTracApplicationException e) {
        	proofOfCoverageData.setDisplayMessage(e.getErrorMessage());
        } catch (Exception e) {
            handleRemoteException(DEFAULT_ERROR_MESSAGE, e, collateralDetailsMainDto);
        }
        logger.debug("launchNewInsurancePolicy::END");
        return "collateralScreenNewInsurancePolicy";
    }

    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "removeCollateralFromPolicy", method = RequestMethod.POST)
    public ResponseEntity<String> removeCollateralFromPolicy(
            @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
            @RequestParam("collateralId") Long collateralId, @RequestParam("policyId") Long policyId, HttpServletRequest request) {
        logger.debug("removeCollateralFromPolicy::BEGIN");

        try {
            ProofOfCoverageDTO proofOfCoverageDTO = collateralDetailsMainDto.getInsuranceSectionData().getFloodPolicy(policyId, collateralId);
            insuranceMngtService.removeInsurancePolicyFromCollateral(collateralId, proofOfCoverageDTO);
            logger.debug("removeCollateralFromPolicy::END");
        } catch (Exception e) {
            handleRemoteException(DEFAULT_ERROR_MESSAGE, e, collateralDetailsMainDto);
        }
        return new ResponseEntity<>("Removed.", HttpStatus.NO_CONTENT);
    }

    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "saveInsurancePolicy", method = RequestMethod.POST)
    public ResponseEntity<BaseApiResponse> saveInsurancePolicy(
    		@Valid @ModelAttribute("proofOfCoverageData") ProofOfCoverageDTO proofOfCoverageData, BindingResult errors,
            @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto) {
        logger.debug("saveInsurancePolicy::BEGIN");
        try {
            if(!errors.hasErrors()){
            	startLetterCycleWorkflowValidator.validate(proofOfCoverageData, collateralDetailsMainDto);
                savePolicyAndDocuments(proofOfCoverageData, collateralDetailsMainDto);
                // Repopulate all building/contents amounts, including $0.00
                for (Long collateralRid : proofOfCoverageData.getProvidedCoverageMap().getInsurableAssetCoverageData().keySet()) {
                    proofOfCoverageData.getProvidedCoverageMap().addCollateral(collateralRid);
                }
            }
            logger.debug("saveInsurancePolicy::END");
        } catch (CTracApplicationException e) {
        	proofOfCoverageData.setDisplayMessage(e.getErrorMessage());
            return new ResponseEntity<>(new BaseApiResponse(e,e.getErrorMessage()), HttpStatus.BAD_REQUEST);

       } catch (Exception e) {
        	String defaultMsg = DEFAULT_ERROR_MESSAGE;        	          
            handleRemoteException(defaultMsg, e, collateralDetailsMainDto);
        }
        return new ResponseEntity<>(new BaseApiResponse(errors,"Saved."),
                errors.hasErrors()? HttpStatus.BAD_REQUEST : HttpStatus.OK);
    }
   
    @Secured({EntitlementRoles.ADMIN_ROLE})
    @RequestMapping(value = "saveOverrideInsurancePolicy", method = RequestMethod.POST)
    public String saveOverrideInsurancePolicy(
    		@ModelAttribute("proofOfCoverageData") ProofOfCoverageDTO proofOfCoverageData,
            @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto) {
        logger.debug("saveOverrideInsurancePolicy::BEGIN");
        try {
        	
            saveOverridePolicy(proofOfCoverageData, collateralDetailsMainDto);
            // Repopulate all building/contents amounts, including $0.00
            for (Long collateralRid : proofOfCoverageData.getProvidedCoverageMap().getInsurableAssetCoverageData().keySet()) {
            	proofOfCoverageData.getProvidedCoverageMap().addCollateral(collateralRid);
    		}
            logger.debug("saveOverrideInsurancePolicy::END");
        } catch (Exception e) {
            handleRemoteException(DEFAULT_ERROR_MESSAGE, e, collateralDetailsMainDto);
        }
        return "redirect:/admin/collateralDetails?collateralID=" + collateralDetailsMainDto.getCollateralDto().getRid();
    }
    
    @Secured({EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(value = "verifyInsurancePoliciesSection", method = RequestMethod.POST)
    public ResponseEntity<String> verifyInsurancePoliciesSection(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto) {
        logger.debug("saveInsurancePolicy::BEGIN");
        try {
        	collateralDetailsStatusService.updateInsurancePoliciesSection(
        			collateralDetailsMainDto.getCollateralDto(), CollateralScreenAction.VERIFY,collateralDetailsMainDto.getTmParams());
            logger.debug("saveInsurancePolicy::END");
        } catch (Exception e) {
            handleRemoteException(DEFAULT_ERROR_MESSAGE, e, collateralDetailsMainDto);
        }
        return new ResponseEntity<>("Verified.", HttpStatus.NO_CONTENT);
    }
    
	private void savePolicyAndDocuments(ProofOfCoverageDTO proofOfCoverageData,
			CollateralDetailsMainDto collateralDetailsMainDto) {
		String key = proofOfCoverageData.getRid() != null ? proofOfCoverageData.getRid().toString() :
			"NEW_POLICY_" + collateralDetailsMainDto.getCollateralDto().getRid().toString();
		List<MultipartFile> policyAttachments = collateralDocumentService.fetchAttachedDocuments(key);
		collateralDetailsService.savePolicy(collateralDetailsMainDto, proofOfCoverageData, policyAttachments);
	}
	
	private void saveOverridePolicy(ProofOfCoverageDTO proofOfCoverageData,
			CollateralDetailsMainDto collateralDetailsMainDto) {
		collateralDetailsService.saveOverridePolicyOnly(collateralDetailsMainDto, proofOfCoverageData);
	}

    // TODO push into a utility methods
    private void handleRemoteException(String defaultUserMessage, Throwable e, CollateralDetailsMainDto collateralDetailsMainDto) {
        logger.error("Data access exception occured : ", e);
        collateralDetailsMainDto.setDisplayMsg(defaultUserMessage);
        if (e instanceof JpaSystemException) {
            Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
            if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
                collateralDetailsMainDto
                        .setDisplayMsg("the collateral informations was updated by a different user since loaded; please review the most up to date information");
            }
        }
        throw new CtracAjaxException(e);
    }
}
