package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import java.io.Serializable;

public class ReferenceDateDTO implements Serializable {
    private static final long serialVersionUID = 1;
    public ReferenceDateDTO() { super(); }

    public ReferenceDateDTO(String errorMessage) {
        super();
        this.errorMessage = errorMessage;
    }

    private String referenceDate;

    private String longDate;

    private boolean workingDay = true;

    private String errorMessage = null;

    public String getReferenceDate() {
        return referenceDate;
    }

    public void setReferenceDate(String referenceDate) {
        this.referenceDate = referenceDate;
    }

    public String getLongDate() {
        return longDate;
    }

    public void setLongDate(String longDate) {
        this.longDate = longDate;
    }

    public boolean isWorkingDay() {
        return workingDay;
    }

    public void setWorkingDay(boolean workingDay) {
        this.workingDay = workingDay;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
