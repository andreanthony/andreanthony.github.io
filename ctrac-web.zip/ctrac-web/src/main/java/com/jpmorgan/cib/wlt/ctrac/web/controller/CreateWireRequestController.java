package com.jpmorgan.cib.wlt.ctrac.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.WireRequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

@Controller
@RequestMapping(value = "/floodRemap")
@SessionAttributes({ "wireRequestData", "tmParams"})
public class CreateWireRequestController extends BaseController {

	private static final Logger logger = Logger
			.getLogger(CreateWireRequestController.class);

	@Autowired
	@Qualifier("wireProcessingService")
	WireProcessingService wireProcessingService;

	@Autowired
	private MessageSource messageSource;
	
	@RequestMapping(value = "/launchCreateWireRequestHelper", method = RequestMethod.GET)
	public String launchCreateWireRequestHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		WireRequestData wireRequestData = null;
		if (tmParams.getId_task() != null) {
			try {			
				wireRequestData = wireProcessingService.prepareCreateWireRequestPage(tmParams);				
				wireRequestData.setScreenId(CtracAppConstants.WIRE_CREATE_REQUEST_SCREEN_ID);
				wireRequestData.setTmParams(tmParams);
				model.addAttribute("wireRequestData", wireRequestData);
				return "createWireRequest";
				
			} catch (Exception e) {
				logger.error("Error occurred while preparing Create Wire Request page" + e.getMessage());
				throw new CTracWebAppException("E0177", CtracErrorSeverity.APPLICATION, tmParams);
				
			} finally {
				logger.debug("launchCollectWireConfirmationHelper()::End");
			}
		} else {
			logger.error("Received Task UUID from TM is null");
			logger.debug("launchCollectWireConfirmationHelper exit()");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}

	}

	@RequestMapping(value = "/submitWireRequest/{taskId}", method = RequestMethod.POST)
	public ModelAndView submitWireRequest(@Valid @ModelAttribute("wireRequestData") WireRequestData wireRequestData,BindingResult binding, @PathVariable Long taskId,HttpServletRequest request) {

		if (wireRequestData.getTmParams() == null) {
			logger.error("Received TM params are null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}

		try {
			logger.debug("submitWireRequest()::Start");

			ModelAndView modelAndView = new ModelAndView();
			
			if (!binding.hasErrors()) {
				TMParams tmParams = wireRequestData.getTmParams();
				logger.debug("TM Transaction ID::" + wireRequestData.getTmParams() .getTmTransactionId());			
				wireProcessingService.processWireRequestInformation(wireRequestData);
				modelAndView.addObject("confirmation", messageSource.getMessage("create.wire.request.submit.confirmation", null, null));
				modelAndView.setViewName("floodRemapConfirmation");
				logger.debug("submitWireConfirmation()::End");
				return modelAndView;
			} else {
				modelAndView.setViewName("createWireRequest");
				modelAndView.addObject("wireRequestData", wireRequestData);
				logger.debug("Request Number Validation:validationFailure");
				return modelAndView;
			}
		} 
		catch(Exception e){
			logger.error(e.getMessage());
			throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, wireRequestData.getTmParams());
		}
	}

}
