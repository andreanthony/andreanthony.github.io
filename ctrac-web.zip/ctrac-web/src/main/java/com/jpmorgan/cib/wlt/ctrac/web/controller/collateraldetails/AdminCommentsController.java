package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralAdminCommentsDto;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Created by E704298 on 7/24/2017.
 */
@RestController
@RequestMapping("admin")
public class AdminCommentsController {

    private static final Logger logger = Logger.getLogger(AdminCommentsController.class);

    @Autowired
    private CollateralDetailsService collateralDetailsService;

    @Secured({EntitlementRoles.ADMIN_ROLE})
    @RequestMapping(value = "collateral/{collateralRid}/adminComments", method = RequestMethod.GET)
    public CollateralAdminCommentsDto getAdminComments(@PathVariable Long collateralRid) {
        logger.debug("getAdminComments::BEGIN");
        String adminComments = collateralDetailsService.getAdminComments(collateralRid);
        CollateralAdminCommentsDto adminCommentsDto = new CollateralAdminCommentsDto(adminComments);
        logger.debug("getAdminComments::END ");
        return adminCommentsDto;
    }

    @Secured({EntitlementRoles.ADMIN_ROLE})
    @RequestMapping(value = "collateral/{collateralRid}/adminComments", method = RequestMethod.POST)
    public CollateralAdminCommentsDto saveAdminComments(@PathVariable Long collateralRid, @Valid @RequestBody CollateralAdminCommentsDto adminCommentsDto, BindingResult binding) {
        logger.debug("saveAdminComments::BEGIN");
        if (binding.hasErrors()) {
            return adminCommentsDto;
        }
        collateralDetailsService.updateAdminComments(collateralRid, adminCommentsDto.getAdminComments());
        logger.debug("saveAdminComments::END ");
        return adminCommentsDto;
    }

}
