package com.jpmorgan.cib.wlt.ctrac.web.controller;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.OperationTask;
import com.jpmorgan.cib.wlt.ctrac.service.admin.TaskAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.OperationsAdminDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.TaskAdminDTO;

@Controller
@SessionAttributes({ "operationsAdminData"})
@RequestMapping(value = "/admin")
public class OperationsAdminController {

	private static final String OPERATIONS_ADMINISTRATION_URL = "/admin/operationsAdministration";


	private static final Logger logger = Logger.getLogger(OperationsAdminController.class);
	
	@RequestMapping(value = "operationsAdministration", method = RequestMethod.GET)
	public ModelAndView launchOperationsAdministration() {
		logger.debug("launchOperationsAdministration::BEGIN");
		ModelAndView mav = new ModelAndView(OPERATIONS_ADMINISTRATION_URL);
		OperationsAdminDTO operationsAdminData = new OperationsAdminDTO();
		mav.addObject("operationsAdminData", operationsAdminData);
		logger.debug("launchOperationsAdministration::END");
		return mav;
	}
	
	@RequestMapping(value = "operationsAdministration", method = RequestMethod.POST, params = "submitme")
	public String submitOperationsAdministration(@ModelAttribute("operationsAdminData") OperationsAdminDTO operationsAdminData) {
		String targetURL = "";	
		logger.debug("submitOperationsAdministration::BEGIN");		
	
		for (OperationTask operationTask: OperationTask.values()) {
			if (operationsAdminData.getAction().equals(operationTask.getDisplayName())) {
				targetURL= "redirect:" + operationTask.getPageURL();
				break;
			}			
		}
		logger.debug("submitOperationsAdministration::END");		
		return targetURL;
	}
}
