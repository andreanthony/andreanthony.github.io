package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
@SessionAttributes({ "searchCollateralData", "collateralDetailsData","referenceValues" })
public class CollateralDetailsSectionController {

	private static final Logger logger = Logger.getLogger(CollateralDetailsSectionController.class);

	@Resource
	private Environment env;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	@Qualifier("emailAttachmentsBucket")
	EmailAttachmentsBucket emailAttachmentsBucket;

	@Autowired
	private CollateralDetailsService collateralDetailsService;

	@RequestMapping(value = "/admin/saveCollateralSectionInfo", method = RequestMethod.POST)
	public ResponseEntity<BaseApiResponse> saveCollateralSectionInfo(
			@Valid @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
			BindingResult errors,HttpSession session, ModelMap model) {
		logger.debug("saveCollateralSectionInfo:BEGIN");
		String saveSuccessMessage = messageSource.getMessage("service.save.success.message", null, null);
		if (!errors.hasErrors()) {
			saveCollateralSectionInfo(collateralDetailsData, errors, session, model, "edit");
		}
		logger.debug("saveCollateralSectionInfo:END");
		BaseApiResponse apiResponse = new BaseApiResponse(errors, saveSuccessMessage);
		return new ResponseEntity<>(apiResponse,apiResponse.isSuccess()?HttpStatus.OK: HttpStatus.BAD_REQUEST);
	}
	
	@RequestMapping(value = "admin/verifyCollateralSectionInfo", method = RequestMethod.POST)
	public String verifyCollateralSectionInfo(
			@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
			BindingResult errors, HttpSession session, ModelMap model) {
		logger.debug("verifyCollateralSectionInfo:BEGIN");
		saveCollateralSectionInfo(collateralDetailsData, errors, session, model, "verify");
		logger.debug("verifyCollateralSectionInfo:END");
		return "admin/collateralDetailsSection :: collateralDetailsSection";
	}

	@RequestMapping(value = "admin/saveCollateralSectionInfo/updateMortgagers", method = RequestMethod.POST)
	public String updateMortgagers(
			@Valid @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
			HttpServletRequest request, HttpServletResponse response, ModelMap modelMap, Integer index, String action) {
		try {
			logger.debug("updateMortgagers:BEGIN");
			CollateralDto collateralDto = null;
			if ("delete".equals(action)) {
				collateralDto = collateralDetailsService.removeCollateralOwner(
						collateralDetailsMainDto.getCollateralDto(), index);
			}
			else if ("add".equals(action)) {
				collateralDto = collateralDetailsService
						.addCollateralOwner(collateralDetailsMainDto.getCollateralDto());
			}
			collateralDetailsMainDto.setCollateralDto(collateralDto);

			modelMap.addAttribute("collateralDetailsData", collateralDetailsMainDto);

			logger.debug("updateMortgagers:END");
			return "admin/collateralDetails";
		}
		catch (Exception e) {
			logger.error("Unable to update mortgager" + index + ". Error message: " + e.getMessage());
			throw new CTracWebAppException("E0246", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "admin/saveCollateralSectionInfo/removeMortgagorDoc", method = RequestMethod.POST)
	public void removeMortgagorFile(
			@Valid @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
			HttpServletRequest request, HttpServletResponse response, ModelMap modelMap, Integer index) {
		try {
			logger.debug("removeMortgagorDoc::BEGIN");
			CollateralSectionDto collateralSectionDto = collateralDetailsService.removeMortgagorDoc(
					collateralDetailsMainDto.getCollateralSectionDto(), index);
			collateralDetailsMainDto.setCollateralSectionDto(collateralSectionDto);
			modelMap.addAttribute("collateralDetailsData", collateralDetailsMainDto);
			logger.debug("removeMortgagorDoc::END");
			//return "admin/collateralDetailsSection :: collateralDetailsSection";
		}
		catch (Exception e) {
			logger.error("Unable to remove mortgagor file: " + index + ". Error message: " + e.getMessage());
			throw new CTracWebAppException("E0246", CtracErrorSeverity.APPLICATION);
		}
	}
	
	private String saveCollateralSectionInfo(CollateralDetailsMainDto collateralDetailsData, BindingResult errors, HttpSession session, ModelMap model, String action) {
		try {
			collateralDetailsData.setSaveStatus("");
						
			// TODO: if server side validation failed
			List<MultipartFile> files = fetchAttachedDocuments(collateralDetailsData.getCollateralDto().getRid()
					.toString());
			collateralDetailsData.getCollateralSectionDto().setNewFiles(files);
			// collateralDetailsValidator.validate(collateralDetailsData,
			// binding);
			if (errors.hasErrors()) {
				model.addAttribute("collateralDetailsData", collateralDetailsData);
				return "admin/collateralDetails";
			}
			CollateralScreenAction screenAction = CollateralScreenAction.getCollateralScreenAction(action);
			// else...
			collateralDetailsService.saveCollateralSectionInfo(collateralDetailsData, screenAction);
			
    	    // previous call
    	    CollateralDetailsMainDto prevCollateralDetailsData = (CollateralDetailsMainDto) session
					.getAttribute("collateralDetailsData");
    	    
    	    boolean prevShowVerify = prevCollateralDetailsData.getCollateralSectionDto().getSectionStatusDto().getShowVerify();
    	    
			// After saving, get from DB			
			collateralDetailsData = collateralDetailsService.populateCollateralDetailsInformation(
					collateralDetailsData.getCollateralDto().getRid());
    	    // check if any session variable set for this collateral
    	    if (prevCollateralDetailsData != null && 
    	    		collateralDetailsData.getCollateralSectionDto().getSectionStatusDto().getStatusId().getName().equals(VerificationStatus.PENDING_VERIFICATION.getName()) &&
    	    		prevCollateralDetailsData.getCollateralDto().getRid().longValue() == collateralDetailsData.getCollateralDto().getRid().longValue()) {
    	    	
    	    	if(prevShowVerify){
    	    		collateralDetailsData.getCollateralSectionDto().setVerificationStarted(true);
    	    	}else{
    	    		collateralDetailsData.getCollateralSectionDto().setVerificationStarted(prevCollateralDetailsData.getCollateralSectionDto().getVerificationStarted());
    	    	}   
    	    	//collateralDetailsData.getCollateralSectionDto().setVerificationStarted(prevShowVerify);
    	    }
    	    
    	    session.setAttribute("collateralDetailsData", collateralDetailsData);
			model.addAttribute("collateralDetailsData", collateralDetailsData);

			collateralDetailsData.setSaveStatus("<strong>Success! </strong>Changes have been saved successfully.");
			logger.debug("saveCollateralDetails :: END");

			return "admin/collateralDetails";
			// return "admin/collateralDetails";
		}
		catch (Exception e) {
			logger.error("Unable to save collateral details. Error message: " + e.getMessage());
			throw new CTracWebAppException("E0227", CtracErrorSeverity.APPLICATION);
		}
	}
	
    @RequestMapping(value = "admin/editCollateralDetails", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    @Secured({EntitlementRoles.READER_ROLE})
    public ModelAndView launchCollateralDetailsSection(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
            @RequestParam("collateralRid") Long collateralRid, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request,
            HttpServletResponse response) {
        logger.debug("launchCollateralDetailsSection::BEGIN");
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        response.addHeader("X-UA-Compatible", "IE=edge");
      
        logger.debug("launchCollateralDetailsSection::END");
        return new ModelAndView("collateralDetailsModal", model);
    }
    
    @RequestMapping(value = "admin/saveCollateralDetailsSection", method = RequestMethod.POST, produces = MediaType.TEXT_HTML_VALUE)
    public String saveCollateralDetailsSection(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto) {
        logger.debug("saveCollateralDetailsSection::BEGIN");
        try {	            
            collateralDetailsService.saveCollateralSectionInfo(collateralDetailsMainDto, CollateralScreenAction.EDIT);
            logger.debug("saveCollateralDetailsSection::END ");
        } catch (Exception e) {
        	String defaultMsg=null;
        	if(e.getMessage().contains("The expirtaion date")){
        		defaultMsg=e.getMessage().substring(20);
        	} else {
        		defaultMsg = "Save collateral owner failed: Some system error occured: Please try again or contact the feature team ";
        	}            
            handleRemoteException(defaultMsg, e, collateralDetailsMainDto);
        }
        return "admin/collateralDetailsSection :: collateralDetailsSection";
    }

    @Secured({EntitlementRoles.READER_ROLE})
    @RequestMapping(value = "admin/collateralDetailsSection", method = RequestMethod.GET)
    public String launchCollateralDetailsSection(@RequestParam("collateralID") String collateralID, HttpServletRequest request,
	    HttpServletResponse response, ModelMap model) {
    	try {
    		logger.debug("collateralDetailsSection::BEGIN");    
			
    		CollateralDetailsMainDto collateralDetailsData = collateralDetailsService
    				.populateCollateralDetailsInformation(Long.valueOf(collateralID));
    		model.addAttribute("collateralDetailsData", collateralDetailsData);
    		model.addAttribute("referenceValues", collateralDetailsService.getCollateralScreenReferenceValues());
    		logger.debug("collateralDetailsSection::END");
    		return "admin/collateralDetailsSection :: collateralDetailsSection";
    	} catch (Exception e) {
    		logger.error("Unable to launch launchCollateralDetails. Error message: " + e.getMessage());
    		throw new CTracWebAppException("E0224", CtracErrorSeverity.APPLICATION);
    	}
    }

    @RequestMapping(value = "admin/reloadCollateralDetailsSectionFromSession", method = RequestMethod.GET)
    @Secured({EntitlementRoles.READER_ROLE})
    public String reloadCollateralDetailsSectionFromSession(@Valid @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
    	    BindingResult errors, HttpServletRequest request, HttpServletResponse response, SessionStatus sessionStatus, ModelMap model) {
    	
    	logger.debug("reloadCollateralDetailsSectionFromSession:BEGIN");

    	return "admin/collateralDetailsSection :: collateralDetailsSection";
    }
    @RequestMapping(value = "admin/resetPageTitle", method = RequestMethod.POST)
    @ResponseBody
    public String resetPageTitle(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
                HttpServletRequest request, HttpServletResponse response, SessionStatus sessionStatus, ModelMap model)
	  {          
		    logger.debug("resetPageTitle::BEGIN");
	          String pageTitle = "";
	          try {
	        	  pageTitle = getValidedString(collateralDetailsData.getCollateralDto().getCollateralDescription());
	           } catch (Exception ex) {
	        	   throw new CTracWebAppException("E0224", CtracErrorSeverity.APPLICATION);
	           } 
	          logger.debug("resetPageTitle::END");    
	          return pageTitle; 
    } 
	
	
    private List<MultipartFile> fetchAttachedDocuments(String attachmentKey) {
    	EmailAttachments emailAttachments = emailAttachmentsBucket.popEmailAttachments(attachmentKey);
		if (emailAttachments == null) {
			logger.debug("attachment is null");
			return new ArrayList<MultipartFile>();
		}
		return emailAttachments.getAllFilesAsList();
	}

	// TODO push into a utility methods
	private void handleRemoteException(String defaultUserMessage, Throwable e, CollateralDetailsMainDto collateralDetailsMainDto) {
		logger.error("Data access exception occured : ", e);
		collateralDetailsMainDto.setDisplayMsg(defaultUserMessage);
		if (e instanceof JpaSystemException) {
		    Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
		    if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
		    	collateralDetailsMainDto
					.setDisplayMsg("the collateral informations was updated by a different user since loaded; please review the most up to date information");
		    }
		}
		throw new CtracAjaxException(e);
	}
	
	protected String getValidedString(String urlParams) {
		String validRedirectURL = null;
		try{
			validRedirectURL= ESAPI.validator().getValidInput("ACSVAlidator", urlParams , "ACSVAlidator", 5000, true);
			return validRedirectURL;
		} catch(ValidationException e){
			logger.error("Malicious character found during url validation");
			throw new CTracWebAppException("E0244", CtracErrorSeverity.APPLICATION);
		}	
	}
}
