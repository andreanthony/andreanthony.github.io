package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EntitySearchCriteria;
import com.jpmorgan.cib.wlt.ctrac.service.customer.CustomerService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.DataTablesRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.DataTablesResponse;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.EntityDataTableDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.EntityDataTableDtoWrapper;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@Controller
public class LoanEntityMergeController {
	private static final Logger logger = Logger.getLogger(LoanEntityMergeController.class);

	@Autowired
	private CustomerService customerService;

	@RequestMapping(value= "admin/merge", method = RequestMethod.GET)
	@Secured({ EntitlementRoles.ADMIN_ROLE})//TODO
	public ModelAndView displayLoan() {
        return new ModelAndView("admin/loan-entity-merge");
	}

	@RequestMapping(value = "admin/get-entities", method = RequestMethod.GET, produces = "application/json")
	@Secured({EntitlementRoles.READER_ROLE})
	public @ResponseBody DataTablesResponse<EntityDataTableDto> getEntities(
			HttpServletRequest request, HttpServletResponse response, HttpSession session, @RequestParam Map<String,String> allRequestParams) {
		try {
			logger.debug("getEntities::BEGIN");
			DataTablesRequest dataTablesRequest = new DataTablesRequest(EntityDataTableDto.class, request);
			EntitySearchCriteria entitySearchCriteria = new EntitySearchCriteria();
			entitySearchCriteria.setName(allRequestParams.get("searchEntity"));
			setAdditionalFilter(allRequestParams, entitySearchCriteria);
			List<EntityDataTableDto> resultContent = customerService.getEntities(entitySearchCriteria, dataTablesRequest);
			DataTablesResponse<EntityDataTableDto> result = new DataTablesResponse<EntityDataTableDto>(dataTablesRequest, resultContent);
			logger.debug("getEntities::END");
			return result;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new CTracWebAppException("E0314", CtracErrorSeverity.APPLICATION);
		}
	}

	private void setAdditionalFilter(Map<String, String> allRequestParams, EntitySearchCriteria entitySearchCriteria) {
		try {
			String additionalFilter = allRequestParams.get("additionalFilter");
			if (StringUtils.isNotBlank(additionalFilter)) {
				String[] args = additionalFilter.split("=");
				if (args.length == 2) {
					Long rid = Long.valueOf(args[1]);
					if ("loanRid".equals(args[0])) {
						entitySearchCriteria.setLoanRid(rid);
					} else if ("collateralRid".equals(args[0])) {
						entitySearchCriteria.setCollateralRid(rid);
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	@RequestMapping(value = "admin/merge-entities", method = RequestMethod.POST)
	@Secured({EntitlementRoles.ADMIN_ROLE})
	public String mergeEntities(@RequestBody EntityDataTableDtoWrapper entitiesDtoWrapper) {
		try {
			logger.debug("mergeEntities::BEGIN");
			customerService.mergeTo(entitiesDtoWrapper.getEntitiesMap(), entitiesDtoWrapper.getEntityToKeep());
			logger.debug("mergeEntities::END");
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return "admin/loan-entity-merge";
	}

}
