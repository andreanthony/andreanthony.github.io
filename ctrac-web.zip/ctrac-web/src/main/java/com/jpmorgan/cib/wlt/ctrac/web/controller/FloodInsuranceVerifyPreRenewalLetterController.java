package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.service.FloodInsuranceRenewalService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.GenericScreenProperties;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VerifyPreRenewalLetterDto;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_INSURANCE_VERIFY_RENEWAL_LETTER_SCREEN_ID;

@Controller
@SessionAttributes({ "verifyPreRenewalLetterDto"})
public class FloodInsuranceVerifyPreRenewalLetterController extends BaseController {

	private static final Logger logger = Logger.getLogger(FloodInsuranceVerifyPreRenewalLetterController.class);

	@Autowired
	@Qualifier("floodInsuranceRenewalService")
	FloodInsuranceRenewalService floodInsuranceRenewalService;

	@Autowired private CtracAuthenticationManager ctracAuthenticationManager;
	
	@Autowired
	private MessageSource messageSource;


	@RequestMapping(value = "/floodInsurance/launchVerifyPreRenewalLetterHelper", method = RequestMethod.GET)
	public String launchPreRenewalLetterHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {

		GenericScreenProperties details = new GenericScreenProperties("floodInsuranceVerifyPreRenewalLetter", FLOOD_INSURANCE_VERIFY_RENEWAL_LETTER_SCREEN_ID);
		logger.debug("launchVerifyPreRenewalLetterHelper()::Start");
		if (tmParams.getId_task() != null) {
			logger.debug("id_task:" + tmParams.getId_task() + " workflowStep:" + tmParams.getWorkflowStep());
			String userId = ctracAuthenticationManager.getJanusUserCredentials(request);
			logger.debug("Login user SID:" + userId +" launched Verify Pre-Renewal Letter");
			try {
				VerifyPreRenewalLetterDto verifyPreRenewalLetterDto = floodInsuranceRenewalService.prepareVerifyPreRenewalLetterDto(tmParams);
				verifyPreRenewalLetterDto.setScreenId(details.getScreenID());

				model.addAttribute("verifyPreRenewalLetterDto", verifyPreRenewalLetterDto);
				return details.getPageUrl();

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new CTracWebAppException("E0242", CtracErrorSeverity.APPLICATION, e);
			}finally {
				logger.debug("launchVerifyPreRenewalLetterHelper()::End");
			}
		}
		else {
			logger.error("Received Task UUID from TM is null");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "/floodInsurance/submitVerifyPreRenewalLetterHelper/{taskId}", method = RequestMethod.POST, params = { "save" })
	public ModelAndView processVerifyPreRenewalLetter(@ModelAttribute("verifyPreRenewalLetterDto") VerifyPreRenewalLetterDto verifyPreRenewalLetterDto, @PathVariable String taskId,
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request){
		if (taskId != null)  {
			try{
				logger.debug("processVerifyPreRenewalLetter()::Start");

	        	if (!binding.hasErrors()) {
	        		ModelAndView modelAndView = new ModelAndView();
	        		logger.debug("processVerifyPreRenewalLetter handling request '/submitVerifyPreRenewalLetterHelper' ");

	        		floodInsuranceRenewalService.processVerifyPreRenewalLetterDto(verifyPreRenewalLetterDto);

	    			modelAndView.addObject("confirmation", messageSource.getMessage("verifyPreRenewalLetter.confirmation.message", null, null));
	    			modelAndView.setViewName("floodRemapConfirmation");
	    		    return modelAndView;
				} else {
	        		//Deal with validation Errors
	        		ModelAndView view = new ModelAndView();
	        		view.setViewName("floodInsuranceVerifyPreRenewalLetter");
	        		view.addObject("verifyPreRenewalLetterDto", verifyPreRenewalLetterDto);
					logger.debug("floodInsuranceVerifyPreRenewalLetter()::validationFailure");
					return view;
	        	}
			}catch(Exception e){
				logger.error(e.getMessage(), e);
                throw new CTracApplicationException("E0243", CtracErrorSeverity.APPLICATION);
			}
			finally{
				logger.debug("processVerifyPreRenewalLetter()::End");
			}
		}
		else {
            logger.error("Perfection task ID is null");
            throw new CTracApplicationException("E0190", CtracErrorSeverity.APPLICATION);
		}
	}

}
