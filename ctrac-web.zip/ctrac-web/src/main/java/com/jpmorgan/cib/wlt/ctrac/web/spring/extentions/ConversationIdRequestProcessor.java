package com.jpmorgan.cib.wlt.ctrac.web.spring.extentions;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.web.servlet.support.csrf.CsrfRequestDataValueProcessor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.support.RequestDataValueProcessor;

@Component
public class ConversationIdRequestProcessor implements RequestDataValueProcessor {

	
	private CsrfRequestDataValueProcessor csrfRequestDataValueProcessor = new CsrfRequestDataValueProcessor();

	@Override
	public String processAction(HttpServletRequest httpServletRequest, String s, String s1) {
		return csrfRequestDataValueProcessor.processAction(httpServletRequest, s, s1);
	}

	@Override
	public String processFormFieldValue(HttpServletRequest request,
			String name, String value, String type) {
		return csrfRequestDataValueProcessor.processFormFieldValue(request, name, value, type);
	}

	@Override
	public Map<String, String> getExtraHiddenFields(HttpServletRequest request) {
		//Append csrf hidden fields
		Map<String, String> hiddenFields =csrfRequestDataValueProcessor.getExtraHiddenFields(request);   //new HashMap<String, String>();
		if (request.getAttribute(ConversationalSessionAttributeStore.CID_FIELD) != null) {
			hiddenFields.put(
					ConversationalSessionAttributeStore.CID_FIELD,
					request.getAttribute(
							ConversationalSessionAttributeStore.CID_FIELD)
							.toString());
		}
		return hiddenFields;
	}

	@Override
	public String processUrl(HttpServletRequest request, String url) {
		return csrfRequestDataValueProcessor.processUrl(request, url);
	}

}
