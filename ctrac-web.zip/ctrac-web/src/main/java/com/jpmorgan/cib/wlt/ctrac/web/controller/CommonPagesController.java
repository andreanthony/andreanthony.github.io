package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.FULL_EOD_JOB;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.batch.scheduler.SchedulerMngtService;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;




@Controller
@SessionAttributes({"tmParams"})
public class CommonPagesController extends BaseController{

	private static final Logger logger = Logger
			.getLogger(CommonPagesController.class);


	@Autowired
	private  SchedulerMngtService schedulechedulerMngtService;
	
	@Autowired 
	private FloodRemapAdminService floodRemapAdminService;
	
	@Autowired
	private BusinessDayUtil businessDayUtil;
	
	
	/**
	 * Login page
	 * 
	 * @return login page id
	 */
	@RequestMapping(value = { "/login" })
	public String getLoginPage() {
		logger.debug("Calling Login page.");
		return "loginPage";
	}
	
	
	@RequestMapping(value = "/displayconfirmationItem", method = RequestMethod.GET)
	public String launchDisplayConfirmHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("confirmation")  String confirmMessage, BindingResult mapping1BindingResult) {
		
		model.addAttribute("confirmation",confirmMessage );
		return "floodRemapConfirmation";
	}
	
	

	/**
	 * Home Page
	 * 
	 * @return home page id
	 */
	@RequestMapping(value={"/", "index"}, method=RequestMethod.GET)
	public ModelAndView index() {
		ModelAndView mav = new ModelAndView("index");
		mav.addObject("message", "Menu Options Below:");
		ReferenceDate referenceDate=floodRemapAdminService.getAppReferenceDate();
		SimpleDateFormat sdf  = new SimpleDateFormat("EEEE, MMMM d, yyyy");
		mav.addObject("refDate", sdf.format(referenceDate.getReferencDate()));
		mav.addObject("isWorkingDay", businessDayUtil.isWorkingDay(new DateTime(referenceDate.getReferencDate())) ? "Yes": "No");
		return mav;
	}
	
	/**
	 * Batch is running
	 * 
	 * @return login page id
	 */
	@RequestMapping(value = { "/batchIsRunning" }, method = RequestMethod.GET)
	public String getBatchIsRunningPage(HttpServletRequest request, ModelMap model) {
		logger.debug("Batch is running. Forwarding...");
		model.addAttribute("confirmation","Batch is running, please try accessing the application after few minutes." );
		return "floodRemapConfirmation";
	}
	

	/**
	 *Query the environment property file to determine the scheduled time of the batch process
	 * 
	 * @return a Json representation of the batch run time
	 */
	@RequestMapping(value = "/batchRunTimeCountDown", method = RequestMethod.GET)
	@ResponseBody public String getbatchRunTimeCountDown(HttpServletRequest request) {
		
		logger.info("getbatchRunTimeCountDown()::Start" );
		
		Long countDown = schedulechedulerMngtService.getTodayJobScheduledTimeCountDownInMiliSec(FULL_EOD_JOB, false);
		
		if( countDown!=null ){
			
			logger.info( "getbatchRunTimeCountDown()::End, run time countDown is : "+"{countDown:"+countDown+"}" );
			return "{\"countDown\":"+countDown+"}";
			
		}else{//Null is returned only if the job is not enabled to run for the day;
			logger.info( "getbatchRunTimeCountDown()::End, run time is null: which mean job disabled" );
			return null;
		}
		
	}
	
	
	
	@RequestMapping(value = "/admin/batchRunTimeCountDown", method = RequestMethod.GET)
	public String getbatchRunTimeCountDowv2(HttpServletRequest request) {
	    return "redirect:/batchRunTimeCountDown";
	}
	
	@RequestMapping(value = "/unLockTMTask", method = RequestMethod.GET)
	public String unLockTMTask(@ModelAttribute("tmParams") TMParams tmParams, HttpServletRequest request, SessionStatus sessionStatus) {
		logger.debug("id_task:" + tmParams.getId_task() + " workflowStep:" + tmParams.getWorkflowStep() +" transid: " + tmParams.getTmTransactionId());
		super.unLockTMTask(tmParams, request);
		return "floodRemapConfirmation";
	}
}
