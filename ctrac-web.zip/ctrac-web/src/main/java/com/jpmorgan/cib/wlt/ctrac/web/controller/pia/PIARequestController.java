package com.jpmorgan.cib.wlt.ctrac.web.controller.pia;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.PIARequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.web.controller.BaseController;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;


@Controller
@SessionAttributes({"pIARequestData","tmParams"})  
public class PIARequestController extends BaseController {

	private static final Logger logger = Logger.getLogger(PIARequestController.class);

	@Autowired
	private BorrowerInsuranceReviewService borrowerInsuranceReviewService;
	
	@Autowired
	private MessageSource messageSource;
	
	@Secured({EntitlementRoles.READER_ROLE}) 
	@RequestMapping(value = "/floodInsurance/launchPIARequestHelper", method = RequestMethod.GET)
	public String launchPIARequestHelper(HttpServletRequest request, ModelMap model,  @ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchPIARequestHelper()::Start");
		logger.debug("id_task:" + tmParams.getId_task() + " workflowStep:" + tmParams.getWorkflowStep() + " tranid: " +  tmParams.getTmTransactionId());
		if (tmParams.getId_task() != null) {
			try 
			{
				PIARequestData pIARequestData = borrowerInsuranceReviewService.preparePIARequestData(tmParams);
				model.addAttribute("pIARequestData", pIARequestData);				
				
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new CTracWebAppException("E0257", CtracErrorSeverity.APPLICATION, e);
			}finally {
				logger.debug("launchPIARequestHelper()::End");
			}			
		}
		else {
			logger.error("Received Task UUID from TM is null");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION);
		}
		return "bir/privateInsuranceAssessment";
		
	}
	
	
	@RequestMapping(value = "/floodInsurance/submtiPIARequest", method = RequestMethod.POST, params = { "save" })
	public ModelAndView processPIARequest(@Valid @ModelAttribute("pIARequestData") PIARequestData pIARequestData, BindingResult binding){
			try{
				logger.debug("processPIARequest()::Start");
	        	if (!binding.hasErrors()) {
	        		ModelAndView modelAndView = new ModelAndView();
	        		logger.debug("processPIARequest handling request '/submtiProcessPIARequest' "); 
	        		borrowerInsuranceReviewService.processPIARequestData(pIARequestData);	        	
				    
	    			modelAndView.addObject("confirmation", messageSource.getMessage("CreatePIARequest.confirmation.message", null, null));
	    			modelAndView.setViewName("floodRemapConfirmation"); 
	    		    return modelAndView;
				}
	        	else{ //Deal with validation Errors
	        		ModelAndView contactView = new ModelAndView();
	        		contactView.setViewName("bir/privateInsuranceAssessment");
	        		contactView.addObject("pIARequestData", pIARequestData);	
					logger.debug("processPIARequest::validationFailure");
					return contactView;
	        	}
			}catch(Exception e){
				logger.error(e.getMessage());
				 throw new CTracWebAppException("E0243", CtracErrorSeverity.CRITICAL, pIARequestData.getTmParams());
			}
			finally{
				logger.debug("processPIARequest()::End");
			}
	}
	
	

}
