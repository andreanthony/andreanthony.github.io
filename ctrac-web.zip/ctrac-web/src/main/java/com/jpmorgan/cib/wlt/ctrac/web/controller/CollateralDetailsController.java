package com.jpmorgan.cib.wlt.ctrac.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.ReviewCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
//import com.jpmorgan.cib.wlt.ctrac.service.dto.EmailAttachments;
//import com.jpmorgan.cib.wlt.ctrac.service.dto.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.EntitlementUtil;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;


@Controller
@SessionAttributes({ "searchCollateralData", "collateralDetailsData", "insurancePolicyRequirementDto","tmParams","referenceValues" })
public class CollateralDetailsController {

	private static final Logger logger = Logger.getLogger(CollateralDetailsController.class);
	
	@Autowired private CollateralDetailsService collateralDetailsService;
	@Autowired private CollateralManagementService collateralManagementService;
	@Autowired private ReviewCollateralService reviewCollateralService;

	@RequestMapping(value = "admin/collateralDetails", method = RequestMethod.GET)
	@Secured({ EntitlementRoles.READER_ROLE })
	public String launchCollateralDetails(@RequestParam("collateralID") Long collateralID, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		try {
			logger.debug("launchCollateralDetails::BEGIN");
			// previous call
			CollateralDetailsMainDto prevCollateralDetailsData =
					(CollateralDetailsMainDto) session.getAttribute("collateralDetailsData");
			
			CollateralDetailsMainDto collateralDetailsData =
					collateralDetailsService.populateCollateralDetailsInformation(collateralID);
			Object tmParams = model.get("tmParams");
			collateralDetailsData.setTmParams(tmParams != null ? (TMParams) tmParams : null);
			
			//check is used changed the url and should not see this collateral details page based on his LOB
	        List<LoanData>  loans =  collateralDetailsData.getCollateralDto().getLoansData();
	        if(!EntitlementUtil.hasLOBAccessAuthority(loans)){
	        	return "generic/403";
	        }

			model.addAttribute("collateralDetailsData", collateralDetailsData);
			model.addAttribute("referenceValues", collateralDetailsService.getCollateralScreenReferenceValues());
			session.setAttribute("collateralDetailsData", collateralDetailsData);

			logger.debug("launchCollateralDetails::END");
			return "admin/collateralDetails";
		} catch (Exception e) {
			logger.error("Unable to launch launchCollateralDetails. Error message: " + e.getMessage());
			if (e instanceof CTracApplicationException) {
				throw new CTracWebAppException(((CTracApplicationException) e).getErrorCode(), ((CTracApplicationException) e).getSeverity());
			}
			throw new CTracWebAppException("E0224", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "admin/fwd/collateral-detail/", method = RequestMethod.GET)
	@Secured({ EntitlementRoles.READER_ROLE })
	public String redirectToCollateralDetailHelper(@ModelAttribute("tmParams") TMParams tmParams,
			HttpServletRequest request, HttpServletResponse response, HttpSession session, ModelMap model) {
		try {
			Collateral col = collateralManagementService.getPrimaryCollateralByTmTaskId(tmParams.getId_task());
			return launchCollateralDetails(col.getRid(), request, response, session, model);
		} catch (Exception e) {
			logger.error(" Could not retrieve task with TM ID " + tmParams.getId_task() + " from CTRAC: cause " + e.getMessage());
			throw new CTracWebAppException("E0224", CtracErrorSeverity.APPLICATION, tmParams);
		}
	}

	/**
	 * Assuming the DTO was pre-populated, this method will reload the main
	 * collateral screen without DB query
	 * 
	 * @param collateralDetailsData
	 * @param errors
	 * @param request
	 * @param response
	 * @param sessionStatus
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/admin/reloadCollateralDetailsFromSession", method = RequestMethod.GET)
	@Secured({ EntitlementRoles.WRITER_ROLE, EntitlementRoles.VERIFER_ROLE, EntitlementRoles.READER_ROLE })
	public String reloadCollateralDetailsFromSession(
			@Valid @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
			BindingResult errors, HttpServletRequest request, HttpServletResponse response, SessionStatus sessionStatus,
			ModelMap model) {
		logger.debug("getRequiredInsuranceCoverage:BEGIN");
		try {
			model.addAttribute("collateralDetailsData", collateralDetailsData);
			return "admin/collateralDetails";
		} catch (Exception e) {
			logger.error("Unable to save collateral details. Error message: " + e.getMessage());
			throw new CTracWebAppException("E0227", CtracErrorSeverity.APPLICATION);
		}
	}
	    
	/**
	 * Assuming the DTO was pre-populated, this method will reload the main
	 * collateral screen from the db
	 * 
	 * @param collateralDetailsData
	 * @param errors
	 * @param request
	 * @param response
	 * @param sessionStatus
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/admin/reloadCollateralDetailsFromDb", method = RequestMethod.GET)
	@Secured({ EntitlementRoles.WRITER_ROLE, EntitlementRoles.VERIFER_ROLE, EntitlementRoles.READER_ROLE })
	public String reloadCollateralDetailsFromDb(
			@Valid @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
			BindingResult errors, HttpServletRequest request, HttpServletResponse response, SessionStatus sessionStatus,
			ModelMap model, final RedirectAttributes redirectAttributes) {
		logger.debug("reloadCollateralDetailsFromDb:BEGIN");
		Long collateralId = collateralDetailsData.getCollateralDto().getRid();
		redirectAttributes.addFlashAttribute("displayMsg", collateralDetailsData.getDisplayMsg());
		return "redirect:/admin/collateralDetails?collateralID=" + collateralId;
	}
	    
	    
	@RequestMapping(value = "admin/changeCollateralDraftToVerify", method = RequestMethod.GET)
	public String changeCollateralDraftToVerify(
			@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
			HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		try {
			logger.debug("changeCollateralDraftToVerify::BEGIN");
			collateralDetailsData = collateralDetailsService.submitForVerification(collateralDetailsData);
			model.addAttribute("collateralDetailsData", collateralDetailsData);
			logger.debug("changeCollateralDraftToVerify::END");
		} catch (CTracApplicationException e) {
			collateralDetailsData.setDisplayMsg(e.getMessage());
			return "admin/collateralDetails";
		} catch (Exception e) {
			logger.error("Unable to submit draft collateral for verification. Error message: " + e.getMessage());
    		throw new CTracWebAppException("E0248", CtracErrorSeverity.APPLICATION);
		}
		return "redirect:/admin/collateralDetails?collateralID=" + collateralDetailsData.getCollateralDto().getRid();
	}

	@RequestMapping(value = "admin/completeCollateralReview", method = RequestMethod.POST)
	public String completeCollateralReview(
			@Valid @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
			BindingResult errors, ModelMap model) {
		try {
			reviewCollateralService.completeCollateralReview(collateralDetailsData);
		} catch (Exception ex) {
			String defaultMsg = "Operation failed. Please try again and raise a ticket if the issue persists.";
			handleRemoteException(defaultMsg, ex, collateralDetailsData);
		}
		return "redirect:/admin/collateralDetails?collateralID="+collateralDetailsData.getCollateralDto().getRid();
		//return "admin/collateralDetailsSection :: collateralDetailsSection";
	}
	    
	@RequestMapping(value = "admin/deleteCollateral", method = RequestMethod.POST)
	@ResponseBody
	public String deleteCollateral(
			@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
			HttpServletRequest request, HttpServletResponse response, SessionStatus sessionStatus, ModelMap model) {
		logger.debug("deleteCollateral::BEGIN");
        CollateralDetailsMainDto dbData = collateralDetailsService.populateCollateralDetailsInformation(collateralDetailsData.getCollateralDto().getRid());
        try {
           if(dbData.isShowDeleteCollateral()){
                  collateralManagementService.deleteCollateral(collateralDetailsData.getCollateralDto());
           }else{
                 throw new CtracAjaxException("The collateral informations was updated by a different user since loaded.");
           }
		} catch (Exception ex) {
			String defaultMsg = "Delete operation failed.";
			handleRemoteException(defaultMsg, ex, collateralDetailsData);
		}
		logger.debug("deleteCollateral::BEGIN");
		return "SUCCESS";
	}
	    
	// TODO push into a utility methods
	private void handleRemoteException(String defaultUserMessage, Throwable e, CollateralDetailsMainDto collateralDetailsMainDto) {
		logger.error("Data access exception occured : ", e);
		collateralDetailsMainDto.setDisplayMsg(defaultUserMessage);
		if (e instanceof JpaSystemException) {
			Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
			if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
				collateralDetailsMainDto.setDisplayMsg(
						"The collateral information was updated by a different user since loaded. Please review the most up to date information.");
			}
		}
		throw new CtracAjaxException(e);
	}
	
}
