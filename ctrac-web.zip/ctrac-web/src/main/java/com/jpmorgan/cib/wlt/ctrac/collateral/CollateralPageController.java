package com.jpmorgan.cib.wlt.ctrac.collateral;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/collateral")
public class CollateralPageController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CollateralPageController.class);

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView loadCollateral() {
        return loadCollateralSection("home");
    }

    @RequestMapping(value = "/{page}/**", method = RequestMethod.GET)
    public ModelAndView loadCollateralSection(@PathVariable("page") String page) {
        LOGGER.trace("Render page: {}", page);
        return new ModelAndView("/ctrac-ui/index");
    }
}
