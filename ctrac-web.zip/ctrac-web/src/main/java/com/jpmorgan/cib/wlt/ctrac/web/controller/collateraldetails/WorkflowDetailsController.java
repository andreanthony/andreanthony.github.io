package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;


import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.WorkflowDetailsSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.WorkflowDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.WorkflowDetailsService;


@Controller
@SessionAttributes({"collateralDetailsData", "loansData", "referenceValues"})
public class WorkflowDetailsController {

    private static final Logger logger = Logger.getLogger(WorkflowDetailsController.class);

    @Resource
    private Environment env;

    @Autowired
    private CollateralDetailsService collateralDetailsService;
    
    @Autowired
    private WorkflowDetailsService workflowDetailsService;

    @Secured({EntitlementRoles.READER_ROLE})
    @RequestMapping(value = "admin/viewWorkflowDetails", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView launchWorkflowDetails(
    		@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
    		@RequestParam("rid") Long workflowDetailsRid, ModelMap model,
    		SessionStatus sessionStatus, HttpServletRequest request, HttpServletResponse response) {
        logger.debug("launchNewInsurancePolicy::BEGIN");
        request.setAttribute("mode", "edit");
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        response.addHeader("X-UA-Compatible", "IE=edge");
        
        WorkflowDetailsSectionDto workflowDetailsSection = collateralDetailsMainDto.getWorkflowDetailsData();
        WorkflowDetailsDTO workflowDetailsDTO = workflowDetailsSection.getWorkflowDetails(workflowDetailsRid);

        model.addAttribute("workflowDetailsDTO", workflowDetailsDTO);
        logger.debug("launchWorkflowDetails::END");
        return new ModelAndView("workflowDetailsModal", model);
    }

    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "admin/stopWorkflow", method = RequestMethod.POST)
    public String stopWorkflow(@ModelAttribute("workflowDetailsDTO") WorkflowDetailsDTO workflowToStop,
    		@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto) {
        logger.debug("stopWorkflow::BEGIN");
        try {           	
            workflowDetailsService.stopWorkflow(workflowToStop.getRid());

            WorkflowDetailsSectionDto workflowDetailsSection = collateralDetailsMainDto.getWorkflowDetailsData();
            collateralDetailsService.refreshWorkflowDetailsSection(workflowToStop.getCollateralRid(), workflowDetailsSection);
 
            collateralDetailsMainDto.setSaveStatus("Workflow has stopped successfully");
            logger.debug("stopWorkflow :: END");

        } catch (Exception e) {
            logger.error("Data access exception occured : ", e);
            collateralDetailsMainDto.setDisplayMsg("Stop Workflow operation failled: Some system error occured: Please try again or contact the feature team ");
            if (e instanceof JpaSystemException) {
                Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
                if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
                    collateralDetailsMainDto
                            .setDisplayMsg("Details Informations was updated by a different user since loaded; please review the most up to date information");
                }
            }
            throw new CtracAjaxException(e);
        }
        return "admin/collateralDetailsSection :: workflowDetailsSection";

    }

}