package com.jpmorgan.cib.wlt.ctrac.web.controller.report;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredProvidedCoverageGapViewData;
import com.jpmorgan.cib.wlt.ctrac.service.ReportDataProviderService;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

@Controller
@RequestMapping("report")
public class ReportDataProviderController {

	private static final Logger logger = Logger.getLogger(ReportDataProviderController.class);
    
	@Autowired
	private ReportDataProviderService reportDataProviderService;
    

	@RequestMapping(value = "getGapReportData", method = RequestMethod.GET, produces = "application/json")
   	@Secured({EntitlementRoles.WRITER_ROLE})
   	public @ResponseBody List<RequiredProvidedCoverageGapViewData> getGapReportData(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
   		try {
   			logger.debug("getGapReportData::BEGIN");			
   			List<RequiredProvidedCoverageGapViewData> gap = reportDataProviderService.getGapReportData();
   			logger.debug("getGapReportData::END");
   			return gap;
   		} catch (Exception e) {
   			logger.error("Unable to get data for Gap Report", e);
   			throw new CTracWebAppException("E0345", CtracErrorSeverity.APPLICATION);
   		}
   	}
    
}
