package com.jpmorgan.cib.wlt.ctrac.web.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;



@Controller
@RequestMapping(value = "/floodRemap")
@SessionAttributes({"tmParams"})
public class FloodRemapGenericHelperController extends BaseController {

	private static final Logger logger = Logger.getLogger(FloodRemapGenericHelperController.class);	
	
	@Qualifier("taskService")
	@Autowired
	private TaskService taskService;
	
	
	@RequestMapping(value="/launchCtracDashboardHelper", method = RequestMethod.GET)
	public String launchFromDashboard(HttpServletRequest request, ModelMap model, TMParams tmParams) {
		tmParams.setLaunchedFromCtrac(true);
		return processGenericHelperLaunch(model, tmParams, Arrays.asList(TaskStatus.OPEN, TaskStatus.SLEEPING), request);
	}
	
	@RequestMapping(value = "/launchCtracGenericHelper", method = RequestMethod.GET)
    @Secured({EntitlementRoles.READER_ROLE})
	public String launchRempGenericHelper(HttpServletRequest request, ModelMap model, TMParams tmParams) {
		logger.debug("launchRempGenericHelper()::Start");
		//Lock the TM Task using the TM Params and transaction is stored in TM Params afterwards
		lockTMTask(request,tmParams);
		model.addAttribute("tmParams",tmParams);
		//modify the original request params so that it does not update the session attribute
		if(request.getParameterMap().get("tmTransactionId") != null){
			request.getParameterMap().get("tmTransactionId")[0] = tmParams.getTmTransactionId();
		}
		if(request.getParameterMap().get(TMParams.CONST_REQUEST_USER_ID) != null){
			request.getParameterMap().get(TMParams.CONST_REQUEST_USER_ID)[0] = tmParams.getUserId();
		}
		logger.debug("id_task workflowStep tranid ");
		return processGenericHelperLaunch(model, tmParams, Arrays.asList(TaskStatus.OPEN),request);
			
	}

	private String processGenericHelperLaunch(ModelMap model, TMParams tmParams, List<TaskStatus> status,HttpServletRequest request) {
		
		if (tmParams.getId_task() != null) {
			
			//DO we need to redirect/display a warning msg for in review task
			
			boolean isHelperDisabled = taskService.isHelperPageDisabled(tmParams, status);
			
			if(isHelperDisabled){
				//TODO change the message, the helper  might be locked for reasons other than task in review
				model.addAttribute("confirmation",messageSource.getMessage("task.ineligible", null, null));
			//	model.addAttribute("confirmation",messageSource.getMessage("task.inborrowerreview.confirmation", null, null));
				return  "floodRemapConfirmation";
			}

			//Using the tmParams, the getHelperURL will return the correct URL for your workflow step.
			//The logic for this is contained within your implementation of TaskState.getHelperURL
			String endPoint =  taskService.getHelperUrl(tmParams, status);
			
			if (!StringUtils.isBlank(endPoint)) {
				logger.debug("launchRempGenericHelper()::End");
				logger.debug("id_task workflowStep tranid: ");
				return "forward:"+endPoint;//+tmParams.toUrlParams();
			}
			//Field not in the map, no View defined
			logger.error("No view defined for the work flow step::");
			throw new CTracWebAppException("E0150", CtracErrorSeverity.APPLICATION, tmParams);
			
		}else{
			//Task ID null
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}
	}
	
	@RequestMapping(value = "/404", method = RequestMethod.GET)
	public String display404(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
			logger.debug("display404: Page not found ::Start");
			return "generic/404";
	}	
	
	@RequestMapping(value = "/permissions", method = RequestMethod.GET)
	public String display403(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
			logger.debug("display403: Page not found ::Start");
			return "generic/403";
	}
	
}
