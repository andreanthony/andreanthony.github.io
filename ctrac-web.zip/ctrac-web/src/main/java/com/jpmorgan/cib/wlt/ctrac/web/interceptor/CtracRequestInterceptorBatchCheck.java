package com.jpmorgan.cib.wlt.ctrac.web.interceptor;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.FULL_EOD_JOB;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.EOD_C3_JOB;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;

public class CtracRequestInterceptorBatchCheck extends HandlerInterceptorAdapter {

	private static final Logger logger = Logger.getLogger(CtracRequestInterceptorBatchCheck.class);
	
	@Autowired
	private BatchCtrlRepository batchCtrlRepository;
	
	@Autowired
	Environment env;
	
	
	private List<BatchCtrl> runningBatchProcesses;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		logger.info("Batch check interceptor::Begin");
		if (request.getRequestURI().contains(CtracAppConstants.BATCH_IS_RUNNING_URI)) {
			return true;
		}
		//DISABLE CHECK IN DEV
	/*	if("DEV".equalsIgnoreCase(env.getActiveProfiles()[0] ) ||  "LOCAL".equalsIgnoreCase(env.getActiveProfiles()[0] )  ){
			return true;
		}*/

		if(request.getRequestURL().toString().contains(env.getProperty("ctrac.event.api.url")) ||
				request.getRequestURL().toString().contains(env.getProperty("ctrac.audit.api.url"))) {
			return true;
		}

		List<String> batchTypes = new ArrayList<String>();
		batchTypes.add(FULL_EOD_JOB.getName());
		batchTypes.add(EOD_C3_JOB.getName());
		
		runningBatchProcesses = batchCtrlRepository.findByRunningAndBatchTypeIn(CtracAppConstants.DB_FLAG_YES, batchTypes);
		if (!runningBatchProcesses.isEmpty()) {
			logger.info("A batch process is running. Intercepting request...");
			
			response.sendRedirect(CtracAppConstants.BATCH_IS_RUNNING_URI);
			return false;
		}
		logger.info("Batch check interceptor::End");
		return true;
	}
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		super.postHandle(request, response, handler, modelAndView);
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		super.afterCompletion(request, response, handler, ex);
	}

}
