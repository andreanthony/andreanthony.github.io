package com.jpmorgan.cib.wlt.ctrac.web.spring.processor;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.web.spring.extentions.ConversationIdRequestProcessor;
import org.thymeleaf.Arguments;
import org.thymeleaf.context.IWebContext;
import org.thymeleaf.dom.Element;
import org.thymeleaf.spring4.requestdata.RequestDataValueProcessorUtils;
import org.thymeleaf.standard.processor.attr.AbstractStandardSingleAttributeModifierAttrProcessor;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by V704662 on 7/14/2017.
 */
public class CustomSpringActionAttrProcessor  extends AbstractStandardSingleAttributeModifierAttrProcessor {

    public static final int ATTR_PRECEDENCE = 2000;
    public static final String ATTR_NAME = "action";

    public CustomSpringActionAttrProcessor() {
        super(ATTR_NAME);
    }

    @Override
    public int getPrecedence() {
        return ATTR_PRECEDENCE;
    }

    @Override
    protected String getTargetAttributeName(Arguments arguments, Element element, String attributeName) {
        return ATTR_NAME;
    }

    @Override
    protected String getTargetAttributeValue(Arguments arguments, Element element, String attributeName) {
        String attributeValue = super.getTargetAttributeValue(arguments, element, attributeName);
        String httpMethod = element.getAttributeValueFromNormalizedName("method");
        return RequestDataValueProcessorUtils.processAction(arguments.getConfiguration(), arguments, attributeValue, httpMethod);
    }

    @Override
    protected ModificationType getModificationType(Arguments arguments, Element element, String attributeName, String newAttributeName) {
        return ModificationType.SUBSTITUTION;
    }

    @Override
    protected boolean removeAttributeIfEmpty(Arguments arguments, Element element, String attributeName, String newAttributeName) {
        return false;
    }

    @Override
    protected void doAdditionalProcess(Arguments arguments, Element element, String attributeName) {
        if("form".equals(element.getNormalizedName())) {
            Map extraHiddenFields = getCidRequestProcessor().getExtraHiddenFields(((IWebContext)arguments.getContext()).getHttpServletRequest());
            if(extraHiddenFields != null && extraHiddenFields.size() > 0) {
                Iterator var5 = extraHiddenFields.entrySet().iterator();
                while(var5.hasNext()) {
                    Map.Entry extraHiddenField = (Map.Entry)var5.next();
                    Element extraHiddenElement = new Element("input");
                    extraHiddenElement.setAttribute("type", "hidden");
                    extraHiddenElement.setAttribute("name", (String)extraHiddenField.getKey());
                    extraHiddenElement.setAttribute("value", (String)extraHiddenField.getValue());
                    element.insertChild(element.numChildren(), extraHiddenElement);
                }
            }
        }

    }

    ConversationIdRequestProcessor getCidRequestProcessor(){
        return ApplicationContextProvider.getContext().getBean(ConversationIdRequestProcessor.class);
    }
}
