package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralCreationService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CreateNewCollateralRecord;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

@Controller
@SessionAttributes({ "createNewCollateralRecord" })
public class CreateNewCollateralRecordController {

	private static final Logger logger = Logger.getLogger(CreateNewCollateralRecordController.class);

	private final CollateralCreationService collateralCreationService;
	private final CollateralDetailsService collateralDetailsService;

	@Autowired
    public CreateNewCollateralRecordController(CollateralCreationService collateralCreationService,
                                               CollateralDetailsService collateralDetailsService) {
        this.collateralCreationService = collateralCreationService;
        this.collateralDetailsService = collateralDetailsService;
    }

	@RequestMapping(value = "admin/launchNewCollateralRecord", method = RequestMethod.GET)
	@Secured({EntitlementRoles.WRITER_ROLE})
	public String launchNewCollateralRecord(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		try {
			logger.debug("launchNewcollateralRecord::BEGIN");
			CreateNewCollateralRecord createNewCollateralRecord =
                    collateralDetailsService.prepareCreateNewCollateralRecord();
		    model.addAttribute("createNewCollateralRecord", createNewCollateralRecord);
			logger.debug("launchNewcollateralRecord::END");
			return "admin/createNewCollateral";
		} catch (Exception e) {
			logger.error("Unable to launch launchNewcollateralRecord. Error message: " + e.getMessage(), e);
			throw new CTracWebAppException("E0224", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "admin/processNewCollateralRecord", method = RequestMethod.POST)
	public ModelAndView processNewCollateralRecord(
			@Valid @ModelAttribute("createNewCollateralRecord") CreateNewCollateralRecord createNewCollateralRecord,
			BindingResult binding, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		try {
			logger.debug("processNewCollateralRecord::Start");
			if (binding.hasErrors()) {
				logger.error("binding has errors");
				modelAndView.addObject("createNewCollateralRecord", createNewCollateralRecord);
				modelAndView.setViewName("admin/createNewCollateral");
				return modelAndView;
			}
            // based on the collateral type instantiate the object
            CollateralDto collateralDto = collateralCreationService.createCollateral(createNewCollateralRecord);
            modelAndView.setViewName("redirect:/admin/collateralDetails?collateralID="+collateralDto.getRid());
            logger.debug("processNewCollateralRecord()::END");
			return modelAndView;
		} catch (Exception e) {
			logger.error("Creating Manual Collateral record failed. Error: " + e.getMessage(), e);
			throw new CTracWebAppException("E0247", CtracErrorSeverity.APPLICATION);
		}
	}
}
