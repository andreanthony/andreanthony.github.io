package com.jpmorgan.cib.wlt.ctrac.web.init;

import javax.servlet.ServletContext;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
import org.springframework.web.multipart.support.MultipartFilter;

/**
 * @author
 *When this class is on the classpath, the security filter chain will get registered before
 *other filters. Use the @order() in to override the ordering.. in most case, this is the most wanted ordering.
 */
public class SpringSecurityInitializer extends AbstractSecurityWebApplicationInitializer {
	
	//Trying to register the file upload filter prior to the security filter to simplify csrf implementation
	//This will remove the Multipart file upload from the need of doing csrf
	@Override
	protected void beforeSpringSecurityFilterChain(ServletContext servletContext) {
		insertFilters(servletContext, new MultipartFilter());
	}
	
}
