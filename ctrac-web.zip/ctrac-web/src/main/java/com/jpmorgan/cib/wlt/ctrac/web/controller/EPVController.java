package com.jpmorgan.cib.wlt.ctrac.web.controller;


import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbcp2.PoolingDriver;
import org.apache.commons.pool2.ObjectPool;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;

import javapasswordsdk.PSDKPassword;
import javapasswordsdk.PSDKPasswordRequest;
import javapasswordsdk.PasswordSDK;
import javapasswordsdk.exceptions.PSDKException;

@Controller
public class EPVController extends BaseController{

	private static final Logger logger = Logger.getLogger(EPVController.class);
	@Autowired private CollateralDetailsService collateralDetailsService;
	
	@RequestMapping(value = "testDBConnection", method = RequestMethod.GET)
	public String testDBConnection(@RequestParam("iterations") Long iterations, @RequestParam("collateralID") Long collateralID, HttpServletRequest request, HttpSession session, ModelMap model) {
		
		try {
			for (int i=0; i<iterations; i++) {
				logger.info("Iteration Number: " + (i+1) + "Starting CollateralSearch for collateral Id: " + collateralID);
				(new Thread(new DBRunnable(collateralDetailsService, collateralID))).start();
			}			
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}
		
		return("testDBConnection");
	}
}
