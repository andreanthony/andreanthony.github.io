package com.jpmorgan.cib.wlt.ctrac.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.PolicyReviewData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
/**
 * Controller to prepare lob email helper page to send an email to market [i.e LP Premium Paid] 
 * @author v589461
 */
@Controller
@RequestMapping(value = "/floodRemap")
@SessionAttributes({ "completeLPPolicyReviewData" ,"tmParams"})
public class CompleteLPPolicyReviewController extends BaseController {
	
	private static final Logger logger = Logger.getLogger(CompleteLPPolicyReviewController.class);
	
//	@Autowired
//	@Qualifier("floodInsurancePolicyService")
//	FloodInsurancePolicyService floodInsurancePolicyService;
	
	@Autowired
	@Qualifier("lenderPlaceService")
	LenderPlaceService lenderPlaceService;

	
	@Autowired
	private MessageSource messageSource;

	/**
	 * Controller method to invoke the CTRAC Complete LP Policy Review helper page
	 * @param request HttpServletRequest
	 * @param model ModelMap
	 * @param tmParams.id_task String
	 * @param tmParams.tmReturn String
	 * @param tmParams.workflowStep String
	 * @return String
	 */
	@RequestMapping(value = "/launchCompleteLPPolicyReviewHelper", method = RequestMethod.GET)
	public String launchCompleteLPPolicyReviewHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		
		logger.debug("launchCompleteLPPolicyReviewHelper start()");
		
		if (tmParams.getId_task() != null) {
			String strConfirmHelperPage = checkTaskInReviewStatus(model,tmParams);
			if(strConfirmHelperPage != null && strConfirmHelperPage.equalsIgnoreCase("")){
				try {
					//CompleteLPPolicyReviewData policyData = floodInsurancePolicyService.prepareCompleteLPPolicyReviewData(tmParams);
					PolicyReviewData policyData=lenderPlaceService.prepareCompleteLPPolicyReviewData(tmParams);
					model.addAttribute("completeLPPolicyReviewData", policyData);
					
					return "floodRemapCompleteLPPolicyReviewPage";
					
				}catch(Exception e){
					logger.error("Error occurred while preparing Complete LP Policy Review page" + e.getMessage(), e);				
					throw new CTracWebAppException("E0242", CtracErrorSeverity.APPLICATION, tmParams);
				}finally {
					logger.debug("launchCompleteLPPolicyReviewHelper end()");	
				}
			}else {
				return strConfirmHelperPage;//return 'InReview' confirmation page.
			}			
		}else {
			logger.error("Received Task UUID from TM is null");
			logger.debug("launchCompleteLPPolicyReviewHelper exit()");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.CRITICAL, tmParams);
		}
	}
	
	@RequestMapping(value = "/saveCompleteLPPolicyReview/{taskId}", method = RequestMethod.POST, params = { "save" })
	public ModelAndView saveCompleteLPPolicyReview(@ModelAttribute("completeLPPolicyReviewData") /*CompleteLPPolicyReviewData completeLPPolicyReviewData*/ PolicyReviewData completeLPPolicyReviewData, @PathVariable String taskId, 
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {	
		try{
		ModelAndView modelAndView = new ModelAndView();
		if(completeLPPolicyReviewData.getTmParams() == null){
			logger.error("Received TM params are null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		
		if (binding.hasErrors()) {
			modelAndView.addObject("completeLPPolicyReviewData", completeLPPolicyReviewData);
			modelAndView.setViewName("completeLPPolicyReview");
		} else {
			
			//floodInsurancePolicyService.processCompleteLPPolicyReview(completeLPPolicyReviewData);
			lenderPlaceService.processCompleteLPPolicyReview(completeLPPolicyReviewData);
			modelAndView.addObject("confirmation", messageSource.getMessage("lenderplaced.policy.review.confirmation", null, null));
			modelAndView.setViewName("floodRemapConfirmation"); 
		}		
		return modelAndView;
		}
		catch(Exception e){
			logger.error(e.getMessage());
			throw new CTracWebAppException("E0243", CtracErrorSeverity.CRITICAL, completeLPPolicyReviewData.getTmParams());
		}
	}
	
}
