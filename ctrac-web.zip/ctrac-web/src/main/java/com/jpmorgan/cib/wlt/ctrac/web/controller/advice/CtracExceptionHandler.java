package com.jpmorgan.cib.wlt.ctrac.web.controller.advice;

import javax.servlet.http.Cookie;

//import java.nio.file.AccessDeniedException;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracBaseException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceBaseException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.UsersRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
//import com.jpmorgan.cib.wlt.tm.client.common.exception.TMClientApplicationException;
import com.jpmorgan.cib.wlt.tm.client.dto.LockedTaskDto;
import com.jpmorgan.cib.wlt.tm.client.dto.UserInformationDto;



@ControllerAdvice
public class CtracExceptionHandler {
	
	@Autowired private CtracAuthenticationManager ctracAuthenticationManager;
	@Autowired private TMService tmService;
	@Autowired private UsersRepository usersRepository;
	
	private static final Logger logger = Logger.getLogger(CtracExceptionHandler.class);
	
	@ExceptionHandler(CTracBaseException.class)
	public ModelAndView handleFloodTaskException(CTracBaseException ex) {
		logger.error(ex,ex);
		String errmsg="";
		
		if(ex instanceof CTracWebAppException && ((CTracWebAppException) ex).getTmParams() != null){
			TMParams tmParams = ((CTracWebAppException) ex).getTmParams();
			Users user = usersRepository.findBySidIgnoreCase(tmParams.getUserId());
			String fullName = String.format("%s %s", user.getFirstName(), user.getLastName());
			if (StringUtils.isNotBlank(tmParams.getTmTransactionId())) {
				logger.info("Unlocking TM task...");
				LockedTaskDto lockedTaskDto = TMUtility.buildLockedTaskDto(tmParams,fullName);
				errmsg=ex.getErrorMessage();
				try {
					Cookie[] janusCookies = ctracAuthenticationManager.getJanusAuthenicationAndCookies();
					tmService.unlockTask(lockedTaskDto, new UserInformationDto(tmParams.getUserId(),tmParams.getUserId(),janusCookies));
				} catch (TMServiceApplicationException e) {
					errmsg="Rest call failed for lock the task";
				}catch (Exception exception) {
					errmsg="Rest call failed for lock the task";
				}
			}
		}else if(ex instanceof CTracWebAppException){
			errmsg=ex.getErrorMessage();
		}
		return errorModelAndView(ex,ex.getErrorMessage());
	}
	@ExceptionHandler(TMServiceBaseException.class)
	public ModelAndView handleFloodTaskException(TMServiceBaseException ex) {
		return errorModelAndView(ex,ex.getErrorMessage());
	}

	/**
	 * Catch CTracBaseException and redirect to a 'error' page.
	 * @throws AccessDeniedException,SecurityException 
	 */
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleCtracException(Exception ex) {
		/**
		 * Discuss with me @Christian if needed
		 * This interceptor/filter should not be allowed to handle security exceptions.
		 * the exception must propagated through the whole filter chains so that the appropriate 
		 * post error handling(redirect to login for instance) doesn't get swallowed by this.
		 * hence the configuration below
		 */
		logger.info("handleCtracException - Catching: " + ex.getClass().getSimpleName());
		return errorModelAndView(ex,ex.getMessage());
	}
	
	
	@ExceptionHandler(value={AccessDeniedException.class, SecurityException.class})
	public void special(Exception ex ,HttpServletResponse response){
	    /**
	     * As mentioned above, swallow security exceptions by throwing them back so that the security handler pick them up
	     * TODO @Christian make sure this doesnt result in a deadlock AuthenticationCredentialsNotFoundException
	     */
		if(ex instanceof AccessDeniedException){
			throw new AccessDeniedException(ex.getMessage(), ex.getCause()); 
		}
		throw (AccessDeniedException)ex; 
	}

	/**
	 * Get the users details for the 'personal' page
	 */
	private ModelAndView errorModelAndView(Exception ex,String message) {
		logger.error(ex,ex);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("genericErrorPage");
		modelAndView.addObject("errorName", ex.getClass().getSimpleName());
		modelAndView.addObject("errorDetails", ex.getMessage());

		return modelAndView;
	}
	
	/**
	 * We shouldn't intercept ajax
	 */
	@ExceptionHandler(CtracAjaxException.class)
	private String handleCtracException(CtracAjaxException ex) {
		logger.error(ex,ex);
		throw ex;
	}


	/**
	 * We shouldn't intercept ajax
	 */
	@ExceptionHandler(BindException.class)
	private String handleCtracException(BindException ex) throws BindException {
		logger.error(ex,ex);
		throw ex;
	}



	
	
}
