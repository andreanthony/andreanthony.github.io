package com.jpmorgan.cib.wlt.ctrac.web.controller.insurance.requirement;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailReqCoverageSectionHelper;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.InsurancePolicyRequirementDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.RequiredCoverageSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.BaseCoverageDataDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.InsurableAssetCoverageData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.RequiredCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.helper.coverage.RequiredCoverageUtil;
import com.jpmorgan.cib.wlt.ctrac.service.validator.InsuranceCoverageRequirementValidator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.management.RuntimeErrorException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashSet;
import java.util.Set;

@Controller
@SessionAttributes({ "collateralDetailsData", "insurancePolicyRequirementDto","referenceValues" })
public class InsuranceCoverageRequirementController {

    private static final Logger logger = Logger.getLogger(InsuranceCoverageRequirementController.class);

    @Autowired
    private CollateralDetailReqCoverageSectionHelper collateralDetailReqCoverageSectionHelper;
    
    @Autowired
    private InsuranceCoverageRequirementValidator insuranceCoverageRequirementValidator;
    
    /**
     * This is the main method invoked from the collateral main section to load
     * the coverage requirement overlay for Display purposes or to create a new
     * coverage requirements
     */
    @RequestMapping(value = "admin/displayCoverageRequirement", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView launchDisplayCoverageRequirement(
            @ModelAttribute("collateralDetailsData") final CollateralDetailsMainDto collateralDetailsMainDto,
            @RequestParam("fiatDocID") Long fiatId, @RequestParam("action") String action, ModelMap model, SessionStatus sessionStatus,
            HttpServletRequest request, HttpServletResponse response) {
        logger.debug("launchDisplayCoverageRequirement::BEGIN");
        request.getSession().setAttribute("mode", "display");
        InsurancePolicyRequirementDto insurancePolicyRequirementPendingVerifDto =
                loadOverlayInsuranceRequirements(collateralDetailsMainDto, action, fiatId, response);
        insurancePolicyRequirementPendingVerifDto.setSuccessMessage(null);
        model.addAttribute("insurancePolicyRequirementDto", insurancePolicyRequirementPendingVerifDto);
        logger.debug("launchDisplayCoverageRequirement::END");
        return new ModelAndView("insurancecoverage/coveragerequirements", model);
    }

    /**
     * This is the main method invoked from the collateral main section to load
     * the coverage requirement overlay for edit purposes or to create a new
     * coverage requirements
     */
    @RequestMapping(value = "admin/editCoverageRequirement", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView launchEditCoverageRequirement(
            @ModelAttribute("collateralDetailsData") final CollateralDetailsMainDto collateralDetailsMainDto, @RequestParam("fiatDocID") Long fiatId,
            @RequestParam("action") String action, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request,
            HttpServletResponse response) {
        logger.debug("launchEditCoverageRequirement::BEGIN");
        request.getSession().setAttribute("mode", "edit");
        InsurancePolicyRequirementDto insurancePolicyRequirementPendingVerifDto =
                loadOverlayInsuranceRequirements(collateralDetailsMainDto, action, fiatId, response);
        if (insurancePolicyRequirementPendingVerifDto.canDelete()) {
            boolean deleteAllAllowed = RequiredCoverageUtil.canDeletePendingVerificationRequiredCoverage(collateralDetailsMainDto);
            insurancePolicyRequirementPendingVerifDto.setCanDelete(deleteAllAllowed);
        }
        insurancePolicyRequirementPendingVerifDto.setSuccessMessage(null);
        model.addAttribute("insurancePolicyRequirementDto", insurancePolicyRequirementPendingVerifDto);
        logger.debug("launchEditCoverageRequirement::END");
        return new ModelAndView("insurancecoverage/coveragerequirements", model);
    }

    /**
     * This is the main method invoked from the collateral main section to
     * load the coverage requirement overlay for edit purposes or to create a
     * new coverage requirements
     */
    @RequestMapping(value = "admin/verifyCoverageRequirement", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView launchVerifyCoverageRequirement(
            @ModelAttribute("collateralDetailsData") final CollateralDetailsMainDto collateralDetailsMainDto, @RequestParam("fiatDocID") Long fiatId,
            @RequestParam("action") String action, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request,
            HttpServletResponse response) {
        logger.debug("launchNewCoverageRequirement::BEGIN");
        try {
            if (!"verify".equals(action)) {
                throw new RuntimeErrorException(null, "invalid access");
            }
            request.getSession().setAttribute("mode", "verify");
            InsurancePolicyRequirementDto insurancePolicyRequirementStartVerificationDto =
                    loadOverlayInsuranceRequirements(collateralDetailsMainDto, action, fiatId, response);
            insurancePolicyRequirementStartVerificationDto.setAction(action);
            model.addAttribute("insurancePolicyRequirementDto", insurancePolicyRequirementStartVerificationDto);
            logger.debug("launchNewCoverageRequirement::END");
            return new ModelAndView("insurancecoverage/coveragerequirements");
        } catch (Exception e) {
            String defaultMsg = "Delete operation failled: Some system error occured: Please try again or contact the feature team ";
            handleRemoteException(defaultMsg, e, collateralDetailsMainDto);
        }
        return new ModelAndView("insurancecoverage/coveragerequirements");
    }

    /**
     * This is the main method Invoked from the coverage requirement overlay to
     * perform ROW LEVEL CRUD operations
     */
    @RequestMapping(value = "admin/editCoverageRequirement/update", method = RequestMethod.POST)
    public String updateCoverageDetails(@ModelAttribute("insurancePolicyRequirementDto") InsurancePolicyRequirementDto insurancePolicyRequirementDto,
            @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto, @RequestParam("action") final String action,
            ModelMap model, @RequestParam("collateralId") Long collateralId, @RequestParam("sortOrder") Integer sortOrder,
            HttpServletRequest request, SessionStatus sessionStatus, final RedirectAttributes redirectAttributes) {
        logger.debug("updateCoverageDetails::BEGIN ");
        // the only type of fiat we can edit is a draft...
        try {
            // prevent front end javascript hijacking do nothing
            if (!"edit verify verify-missmatch".contains((String) request.getSession().getAttribute("mode"))) {
                throw new RuntimeErrorException(null, "invalid access");
            }
            // 1) are we adding a new row?
            if ("addRow".equals(action)) {
                logger.debug("adding a new row to the insurance requirement table::BEGIN ");
                collateralDetailReqCoverageSectionHelper.createAndAppendNewCoverageRequiremnetRow(
                        collateralDetailsMainDto.getCollateralDto(), insurancePolicyRequirementDto, null, false);
            }
            // 2) are we deleting a row?
            if ("deleteRow".equals(action)) {
                logger.debug("deleting a row from the insurance requirement map::BEGIN ");
                InsurableAssetCoverageData<RequiredCoverageDTO> insurableData = insurancePolicyRequirementDto.getRequiredCoverageMap().pop(
                        collateralDetailsMainDto.getCollateralDto().getRid(), sortOrder);
                if (insurableData != null) {
                    BaseCoverageDataDTO coverageData = insurableData.getBuildingCoverageData();
                    addInsurableAssetToDelete(collateralDetailsMainDto, coverageData);
                    coverageData = insurableData.getContentsCoverageData();
                    addInsurableAssetToDelete(collateralDetailsMainDto, coverageData);
                    coverageData = insurableData.getBusinessIncomeCoverageData();
                    addInsurableAssetToDelete(collateralDetailsMainDto, coverageData);
                }
            }
            if ("deleteAll".equals(action)) {
                collateralDetailReqCoverageSectionHelper.deleteAllRequiredCoverages(insurancePolicyRequirementDto, collateralDetailsMainDto);

                redirectAttributes.addFlashAttribute("message", "the fiat pending verification was successfully deleted");
                redirectAttributes.addFlashAttribute("collateralDetailsData", collateralDetailsMainDto);
                return  "redirect:/admin/collateralDetails?collateralID="+collateralDetailsMainDto.getCollateralDto().getRid();
            }
            // was cancel button clicked with dirty values? reload the required coverage data
            if ("discard-draft".equals(action)) {
                //1 reload all values from the DB
                RequiredCoverageSectionDto requiredCoverageSectionDto = collateralDetailReqCoverageSectionHelper.prepareRequiredCoverageSection(
                        collateralDetailsMainDto.getCollateralDto().getRid(), collateralDetailsMainDto.getRequiredCoverageSectionDto());
                collateralDetailsMainDto.setRequiredCoverageSectionDto(requiredCoverageSectionDto);
                model.addAttribute("insurancePolicyRequirementDto", collateralDetailsMainDto.getRequiredCoverageSectionDto()
                        .getPendingVerificationCoverageRequirement());
                request.getSession().removeAttribute ("mode");
            }
            model.addAttribute("insurancePolicyRequirementDto", insurancePolicyRequirementDto);
        } catch (Exception e) {
            String defaultMsg = "Delete operation failled: Some system error occured: Please try again or contact the feature team ";
            handleRemoteException(defaultMsg, e, collateralDetailsMainDto);
        }
        return "insurancecoverage/coveragerequirements";
    }

    /**
     * This is the main method invoked from the coverage requirement overlay to
     * store the coverage requirement form as whole
     */
    @RequestMapping(value = "admin/saveCoverageRequirement", method = RequestMethod.POST)
    public String saveRequiredCoverageDetails(
            final @ModelAttribute("insurancePolicyRequirementDto") InsurancePolicyRequirementDto insurancePolicyRequirementDto,
            @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto, ModelMap model, HttpServletRequest request,
            SessionStatus sessionStatus, final RedirectAttributes redirectAttributes) {
        logger.debug("saveRequiredCoverageDetails::BEGIN ");
        String action = (String) request.getSession().getAttribute("mode");
        try {
            //Validate the balance type was entered where there are amounts known.
            insuranceCoverageRequirementValidator.validateBalanceTypeEntered(insurancePolicyRequirementDto);
            // 1- are we dealing with the submit of verify?
        	insurancePolicyRequirementDto.setSuccessMessage("The coverage requirement was successfully Saved");
        	collateralDetailReqCoverageSectionHelper.updateDescopedCoverageAmounts(insurancePolicyRequirementDto);
            if ("verify".equals(action) ) {
                /*
                 * this action prepate the DTO for the display of the missmatch overlay
                 */
                Boolean hasMissMatch = insuranceCoverageRequirementValidator.verifyMissMatchingPrimaryExcessCoverage(insurancePolicyRequirementDto);
                /*
                 * IF there is a miss-match, we do not persist, 
                 * we just prepare and load the miss-match page
                 */
                if(hasMissMatch){
                	insurancePolicyRequirementDto.setSuccessMessage(null);
                    request.getSession().setAttribute("mode", "verify-missmatch");
                    return "insurancecoverage/coveragerequirements";
                }
                insurancePolicyRequirementDto.setSuccessMessage("The coverage requirement was successfully verified");
                /*
                 * otherwise, just proceed recording the verification
                 */
            } else {
                if ("verify-missmatch".equals(action)) {
                    insurancePolicyRequirementDto.setSuccessMessage("The coverage requirement was successfully verified");
                }
            }
            collateralDetailReqCoverageSectionHelper.proccessRequiredCoverageSubmit(insurancePolicyRequirementDto, collateralDetailsMainDto, action);
            redirectAttributes.addFlashAttribute("collateralDetailsData", collateralDetailsMainDto);
            redirectAttributes.addFlashAttribute("insurancePolicyRequirementDto", insurancePolicyRequirementDto);
            request.getSession().removeAttribute("mode");
            logger.debug("saveRequiredCoverageDetails:: End ");
        } catch (Exception e) {
            String defaultMsg = "Save required coverage operation failled: Some system error occured."+e.getMessage();
            handleRemoteException(defaultMsg, e, collateralDetailsMainDto);
        }
        return "redirect:/admin/collateralDetails?collateralID="+collateralDetailsMainDto.getCollateralDto().getRid();
    }

    private void addInsurableAssetToDelete(CollateralDetailsMainDto collateralDetailsMainDto, BaseCoverageDataDTO coverageData) {
        Long insurableAssetId;
        if (coverageData != null) {
            insurableAssetId = coverageData.getInsurableAssetDTO().getRid();
            // it was saved in the DB, need to be
            if (insurableAssetId != null) {
                // // deleted later
            	Set<Long> insAssetRids= new HashSet<>();
            	insAssetRids.add(insurableAssetId);
                boolean canDel = collateralDetailReqCoverageSectionHelper.areInsurableAssetDeletable(insAssetRids);
                if(!canDel){
                	 throw new RuntimeException(" Cannot delete a building/content with a policy attached to it");
                }
                collateralDetailsMainDto.getRequiredCoverageSectionDto().addInsuableAssetToDelete(insurableAssetId);
            }
        }
    }

    private InsurancePolicyRequirementDto loadOverlayInsuranceRequirements(final CollateralDetailsMainDto collateralDetailsMainDto,
                                                                           String action, Long fiatId, HttpServletResponse response) {
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        response.addHeader("X-UA-Compatible", "IE=edge");
        //1 clear the delete queue just in case ...
        collateralDetailsMainDto.getRequiredCoverageSectionDto().getDeletedCoverageIds().clear();
        return collateralDetailReqCoverageSectionHelper.prepareRequiredCoverageOverlayData(
                collateralDetailsMainDto.getCollateralDto(), collateralDetailsMainDto.getRequiredCoverageSectionDto(), action, fiatId);
    }

    // TODO push into a utility methods
    private void handleRemoteException(String defaultUserMessage, Throwable e, CollateralDetailsMainDto collateralDetailsMainDto) {
        logger.error("Data access exception occured : ", e);
        collateralDetailsMainDto.setDisplayMsg(defaultUserMessage);
        if (e instanceof JpaSystemException) {
            Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
            if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
                collateralDetailsMainDto.setDisplayMsg(
                        "the collateral informations was updated by a different user since loaded; please review the most up to date information");
            }
        }
        throw new CtracAjaxException(e);
    }
}
