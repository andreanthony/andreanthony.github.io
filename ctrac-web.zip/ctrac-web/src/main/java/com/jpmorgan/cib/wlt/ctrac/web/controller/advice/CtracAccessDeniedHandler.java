package com.jpmorgan.cib.wlt.ctrac.web.controller.advice;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

/**
 * @author
 * The responsibility of this class is to redirect to a predefined error page when 
 * the user attempt to perform a forbidden operation
 *
 */
public class CtracAccessDeniedHandler implements AccessDeniedHandler {

	private static final Logger logger = Logger.getLogger(CtracAccessDeniedHandler.class);
	
	private String errorPage;

	public CtracAccessDeniedHandler(String errorPage) {
		this.errorPage = errorPage;
	}

	public String getErrorPage() {
		return errorPage;
	}

	public CtracAccessDeniedHandler setErrorPage(String errorPage) {
		this.errorPage = errorPage;
		return this;
	}

	@Override
	public void handle(HttpServletRequest request,HttpServletResponse response,AccessDeniedException accessDeniedException) throws IOException,
			ServletException {
		// TODO @Christian implement more business operations if needed before redirecting 
		/**
		 * resting the security context isn't a mandatory but doing so will avoid some caching issue.
		 * it will be rebuilt anyway since we have and auto-pre-authentication which used janus cookies 
		 */
		//SecurityContextHolder.getContext().setAuthentication(null);
		response.sendRedirect(errorPage);

	}
	
	
	
}
