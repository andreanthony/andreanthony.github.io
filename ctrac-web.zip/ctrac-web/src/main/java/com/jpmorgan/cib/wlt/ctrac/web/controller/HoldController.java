package com.jpmorgan.cib.wlt.ctrac.web.controller;


import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracBaseException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.HoldStatusDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.Arrays;


@Controller
@SessionAttributes({ "holdStatusDto","tmParams"})
public class HoldController extends BaseController{

	private static final Logger logger = Logger.getLogger(HoldController.class);
	@Autowired private PerfectionTaskRepository perfectionTaskRepository;

	@Autowired protected TMService tmService;

	@Autowired private HoldService holdService;

	@Autowired
	@Qualifier("emailAttachmentsBucket")
	EmailAttachmentsBucket emailAttachmentsBucket;

	@RequestMapping(value = "launchHoldHelperPage", method = RequestMethod.GET)
	public String launchHoldHelperPage(HttpServletResponse response, HttpServletRequest request, HttpSession session, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchHoldHelperPage()::Start");

		if (tmParams.getId_task() != null) {
			try {
				logger.debug("launchHoldHelperPage: tmParams.getTmTransactionId(): " + tmParams.getTmTransactionId());

				validateTmParams(tmParams);

				String janusUserId = (String) request.getSession().getAttribute("JANUS_USER_ID");
				if (janusUserId == null) {
					janusUserId = "LOCAL";
				}

				HoldStatusDto holdStatusDto = holdService.prepareHoldHelperData(tmParams, janusUserId);

				model.addAttribute("holdStatusDto", holdStatusDto);
				session.setAttribute("holdStatusDto", holdStatusDto);
			} catch(CTracBaseException e) {
				logger.debug(e.getMessage(), e);
				throw new CTracWebAppException(e.getErrorCode(), CtracErrorSeverity.TRIVIAL, tmParams);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new CTracWebAppException("E0111", CtracErrorSeverity.APPLICATION, tmParams);
			} finally {
				logger.debug("launchHoldHelperPage()::End");
			}
		} else {
			logger.error("Received Task UUID from TM is null");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}

		return("holdHelperPage");
	}

	@RequestMapping(value = "updateHoldStatus", method = RequestMethod.POST)
	@Transactional
	public ModelAndView updateHoldStatus(
			@Valid @ModelAttribute("holdStatusDto") HoldStatusDto holdStatusDto,
			BindingResult binding, HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = new ModelAndView();
		try {
			logger.debug("updateHoldStatus::Start");

			TMParams tmParams = holdStatusDto.getTmParams();
			//tmParams.setTmHelper(TMUtility.createTMHelper(request, tmParams.getTmReturn()));
			logger.debug("updateHoldStatus: tmParams.getTmTransactionId(): " + tmParams.getTmTransactionId());

			EmailAttachments attachments = emailAttachmentsBucket.popEmailAttachments(holdStatusDto.getPerfectionTask().getTmTaskId());

			if (attachments != null && !attachments.getAllFilesAsList().isEmpty()) {
				holdStatusDto.setDocumentAttachment(attachments.getAllFilesAsList().get(0));
			}

			if (binding.hasErrors()) {
				logger.error("binding has errors");
				modelAndView.addObject("holdStatusDto", holdStatusDto);
				modelAndView.setViewName("admin/floodRemapCreateNewRecord");
				return modelAndView;
			} else {
				holdService.processUpdateHoldStatus(holdStatusDto);

				logger.debug("updateHoldStatus()::END");

				modelAndView.setViewName("redirect:confirmationHoldStatus");
			}

			return modelAndView;

		} catch (Exception e) {
			logger.error("Error occurred while updating hold status. Error: " + e.getMessage());
			throw new CTracWebAppException("E0347", CtracErrorSeverity.APPLICATION);
		}
	}

	@RequestMapping(value = "/confirmationHoldStatus", method = RequestMethod.GET)
	@Secured({EntitlementRoles.READER_ROLE})
	public String launchHoldStatusConfirmation(HttpServletRequest request, HttpServletResponse response, ModelMap model) {

		try {
			logger.debug("launchHoldStatusConfirmation::Start");
			logger.debug("launchHoldStatusConfirmation::END");
			return "confirmationHoldStatus";
		} catch (Exception e) {
			logger.error("Unable to open launchHoldStatusConfirmation");
			throw new CTracWebAppException("E0193", CtracErrorSeverity.APPLICATION);
		}
	}


	protected void validateTmParams(TMParams tmParams) {
		if(tmParams == null || tmParams.getId_task() == null){
				logger.error("Task UUID from TM is null");
				throw new CTracApplicationException("E0109", CtracErrorSeverity.CRITICAL);
			}

			PerfectionTask perfectionTask = perfectionTaskRepository.findByTmTaskIdAndTaskStatusIn(
					tmParams.getId_task(), Arrays.asList(TaskStatus.OPEN.toString(), TaskStatus.SLEEPING.toString()));
			if (perfectionTask == null) {
				logger.error("Task not found for the given UUID: " + tmParams.getId_task());
				throw new CTracApplicationException("E0111", CtracErrorSeverity.APPLICATION);
			}
		}

	protected PerfectionTask getPerfectionTaskByUUID(String tmTaskId) {
		return perfectionTaskRepository.findByTmTaskId(tmTaskId);
	}
}
