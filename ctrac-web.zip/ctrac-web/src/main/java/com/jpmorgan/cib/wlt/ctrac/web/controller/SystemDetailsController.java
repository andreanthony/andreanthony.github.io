package com.jpmorgan.cib.wlt.ctrac.web.controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.jar.Manifest;
import java.util.jar.Attributes;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.SystemData;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

@Controller
@SessionAttributes({ "systemData" })
public class SystemDetailsController {
	@Resource
	private Environment env;

	private static final String PROPERTY_NAME_DATABASE_URL = "db.url";
	public static final String PROPERTY_NAME_DATABASE_USERNAME = "db.username";
	public static final String PROPERTY_NAME_TM_OUTBOUND_QUEUE = "jms.mq.outbound.queue";

	private static final Logger logger = Logger.getLogger(SystemDetailsController.class);

	HashMap<String, String> databaseServerList = new HashMap<String, String>() {
		{
			put("cpdcd1-loan02v", "DEV");
			put("cpdcd1-loan04v", "SIT");
			put("psin2p463-scan", "UAT");
			put("psin1p520-scan", "PROD");
			put("psin2p061-scan", "DR");
		}
	};

	HashMap<String, String> tmEnvironmentList = new HashMap<String, String>() {
		{
			put("IBCPLCP.BUS.FROM.LCP.SIT3", "S13");
			put("IBCPLCP.BUS.FROM.LCP.UAT4", "U11");
			put("IBCPLCP.BUS.FROM.LCP.UAT1", "U13");
			put("IBCPLCP.BUS.FROM.LCP", "PROD");
		}
	};

	Manifest loadManifestFromStream(InputStream inputStream) throws IOException {
		return new Manifest(inputStream);
	}

	@RequestMapping(value = "systemDetails", method = RequestMethod.GET)
	@Secured({ EntitlementRoles.READER_ROLE })
	public String getSystemDetails(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			ModelMap model) {
		try {
			logger.debug("getSystemDetails::BEGIN");

			SystemData systemData = new SystemData();

			ServletContext application = request.getServletContext();
			InputStream inputStream = application.getResourceAsStream("/META-INF/MANIFEST.MF");

			if (inputStream == null) {
				systemData.setMessage("Applicaiton's MANIFEST.MF file not found.");
			} else {
				Manifest manifest = loadManifestFromStream(inputStream);

				Attributes attr = manifest.getMainAttributes();
				Iterator<Entry<Object, Object>> iter = attr.entrySet().iterator();

				while (iter.hasNext()) {
					Map.Entry<Object, Object> currKeyValue = iter.next();

					String key = currKeyValue.getKey().toString();
					String value = currKeyValue.getValue().toString();

					logger.info(key + ": " + value);

					switch (key) {
					case "Project-Name":
						systemData.setProjectName(value);
						break;
					case "Project-Version":
						systemData.setProjectVersion(value);
						break;
					case "Build-Number":
						systemData.setBuildNumber(value);
						break;
					case "Subversion-URL":
						systemData.setSvnURL(value);
						break;
					case "Subversion-Revision":
						systemData.setSvnRevision(value);
						break;
					default:
						break;
					}
				}
			}

			// Get Database Server and Database Service Name
			String dbURL = env.getRequiredProperty(PROPERTY_NAME_DATABASE_URL);

			String[] urlParts = dbURL.split(":");
			if (urlParts.length == 5 || urlParts.length == 6) {
				String dbName = urlParts[3].replace("@", "").split("\\.")[0];

				systemData.setDbName(databaseServerList.get(dbName) + " Database (" + dbName + ")");
				systemData.setDbServiceName(urlParts[urlParts.length - 1]);
			}

			systemData.setDbUserName(env.getRequiredProperty(PROPERTY_NAME_DATABASE_USERNAME));
			if (env.getProperty("db.password") == null) {
				systemData.setPasswordProvider("Enterprise Password Vault (EPV-AIM).");
			} else {
				systemData.setPasswordProvider("Encrypted password from properties file.");
			}
			systemData.setTmEnvironment(
					tmEnvironmentList.get(env.getRequiredProperty(PROPERTY_NAME_TM_OUTBOUND_QUEUE)));

			InetAddress ip = InetAddress.getLocalHost();
			String hostName = ip.getHostName();

			systemData.setIpAddress(ip.toString().split("/")[1]);
			systemData.setHostName(hostName);

			String url = request.getRequestURL().toString().replace("systemDetails", "");
			systemData.setUrl(url);

			Map<String, Object> map = new HashMap<>();
			for (Iterator it = ((AbstractEnvironment) env).getPropertySources().iterator(); it.hasNext();) {
				PropertySource propertySource = (PropertySource) it.next();
				if (propertySource instanceof MapPropertySource) {
					map.putAll(((MapPropertySource) propertySource).getSource());
				}
			}

			HashMap<String, String> cronJobs = new HashMap<>();
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String key = entry.getKey();
				String value = (String) entry.getValue();
				if (key.startsWith("cron.")) {
					// System.out.print("key: " + key + " value: " + value +
					// "<br/>");
					String[] s = value.split(" ");
					if (s.length == 6) {
						String seconds = s[0];
						String minutes = s[1];
						String hours = s[2];
						String dayOfMonth = s[3];
						String month = s[4];
						String dayOfWeek = s[5];
						
						if (dayOfMonth.equals("*") || dayOfMonth.equals("?")) {
							dayOfMonth = "All";
						}
						
						if (month.equals("*") || month.equals("?")) {
							month = "All";
						}
						
						if (dayOfWeek.equals("*") || dayOfWeek.equals("?")) {
							dayOfWeek = "All";
						}

						if (minutes.length() == 1) {
							minutes = "0" + minutes;
						}

						if (seconds.length() == 1) {
							seconds = "0" + seconds;
						}
						
						String timeString = "";
						String amPm = "";
						
						String hours1 = "";
						String hours2 = "";
						String amPm1 = "";
						String amPm2 = "";
						
						String[] hoursRange;
						String delimitor = "";
						if (hours.indexOf(",") > -1) {
							delimitor = ",";
						} else if (hours.indexOf("-") > -1) {
							delimitor = "-";								
						}
						
						if (!delimitor.equals("")) {
							hoursRange = hours.split(delimitor);
							hours1 = hoursRange[0];
							hours2 = hoursRange[1];
							
							if (Integer.parseInt(hours1) == 0) {
								hours1 = "24";
							}
							hours1 = (new Integer(Integer.parseInt(hours1) - 1)).toString();
							
							if (Integer.parseInt(hours2) == 0) {
								hours2 = "24";
							}
							hours2 = (new Integer(Integer.parseInt(hours2) - 1)).toString();
							
							if (Integer.parseInt(hours1) - 1 > 12) {
								hours1 = (new Integer(Integer.parseInt(hours1) - 12)).toString();
								amPm1 = "PM";
							} else {
								amPm1 = "AM";
							}
							
							if (hours1.length() == 1) {
								hours1 = "0" + hours1;
							}
							
							if (Integer.parseInt(hours2) - 1 > 12) {
								hours2 = (new Integer(Integer.parseInt(hours2) - 12)).toString();
								amPm2 = "PM";
							} else {
								amPm2 = "AM";
							}
							
							timeString = hours1 + ":" + minutes + " " + amPm1 + " " + delimitor + " " + hours2 + ":" + minutes + " " + amPm2;
							if (delimitor.equals("-")) {
								timeString = timeString+ " [Every Hour]";
							}
							
						} else {
							if (Integer.parseInt(hours) == 0) {
								hours = "24";
							}
							hours = (new Integer(Integer.parseInt(hours) - 1)).toString();
							
							if (Integer.parseInt(hours) - 1 > 12) {
								hours = (new Integer(Integer.parseInt(hours) - 12)).toString();
								amPm = "PM";
							} else {
								amPm = "AM";
							}
							
							if (hours.length() == 1) {
								hours = "0" + hours;
							}
							
							timeString = hours + ":" + minutes + " " + amPm;
						}

						String jobSchedule ="Day of week: " + dayOfWeek + ". Month: " + month + " Date: " + dayOfMonth + " Time: " + timeString  + " (Central Time).";
						logger.info("CronJob: " + key + " Schedule: " + jobSchedule);
						
						cronJobs.put(key, jobSchedule);
					}
					systemData.setCronJobs(cronJobs);
				}
			}

			model.addAttribute("systemData", systemData);
			session.setAttribute("systemData", systemData);

			logger.debug("getSystemDetails::END");
			return "systemDetails";
		} catch (Exception e) {
			logger.error("Unable to launch getSystemDetails. Error message: " + e.getMessage());
			throw new CTracWebAppException("E0306", CtracErrorSeverity.APPLICATION);
		}
	}
}
	