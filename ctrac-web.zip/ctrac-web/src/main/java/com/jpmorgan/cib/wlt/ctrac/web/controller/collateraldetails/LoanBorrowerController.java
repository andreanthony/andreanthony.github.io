package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.admin.LoanBorrowerAddressService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.LoanBorrowerAddressDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.LoanBorrowerSectionDto;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Controller
@SessionAttributes({"collateralDetailsData", "loansData", "referenceValues"})
public class LoanBorrowerController {

    private static final Logger logger = Logger.getLogger(LoanBorrowerController.class);

    @Autowired
    private CollateralDetailsService collateralDetailsService;

    @Autowired
    private CollateralDetailsStatusService collateralDetailsStatusService;

    @Autowired
    private LoanBorrowerAddressService loanBorrowerAddressService;

    @Secured({EntitlementRoles.READER_ROLE})
    @RequestMapping(value = "admin/editLoanBorrower", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView launchEditLoanBorrower(
    		@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
    		@RequestParam("loanId") Long loanId, @RequestParam("mode") Integer mode, ModelMap model,
    		SessionStatus sessionStatus, HttpServletRequest request, HttpServletResponse response) {
        logger.debug("launchNewInsurancePolicy::BEGIN");
        request.setAttribute("mode", "edit");
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        response.addHeader("X-UA-Compatible", "IE=edge");
        LoanBorrowerSectionDto loanSection = collateralDetailsMainDto.getLoanBorrowerSectionData();
        LoanData loanData = loanSection.getloanData(loanId);
        //set the value for release date flag
    	loanData.setDisplayReleaseDate(loanData.getRid() != null &&
    			collateralDetailsMainDto.getCollateralDto().getCollateralStatus() != CollateralStatus.DRAFT &&
    			(StringUtils.isBlank(loanData.getPrimaryFlag()) || loanSection.getActiveLoansData().size() == 1));
    	loanSection.setVerifyMode(loanData.getStatus() == LoanStatus.PENDING_VERIFICATION && mode == 2);
        model.addAttribute("loansData", loanData);
        logger.debug("launchNewLoanBorrower::END");
        return new ModelAndView("loanBorrowerModal", model);
    }

    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "admin/deleteLoanBorrower", method = RequestMethod.POST)
    public String deleteLoanBorrower(
    		@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
    		@RequestParam("loanRid") Long loanToDelete, HttpServletRequest request,
    		HttpServletResponse response, ModelMap modelMap, BindingResult result) {
        try {
            logger.debug("deleteLoanBorrower::BEGIN");
            if (result.hasErrors()) {
                modelMap.addAttribute("collateralDetailsData", collateralDetailsMainDto);
                return "admin/collateralDetails";
            }
            if (loanToDelete != null && loanToDelete > 0) {
            	collateralDetailsService.deleteLoanBorrower(collateralDetailsMainDto, loanToDelete);
            }

            collateralDetailsService.refreshLoanBorrowerSection(collateralDetailsMainDto);
            collateralDetailsMainDto.setSaveStatus("Changes have been saved successfully");
            modelMap.addAttribute("collateralDetailsData", collateralDetailsMainDto);
            logger.debug("deleteLoanBorrower :: END");
            return "admin/collateralDetails";

        } catch (Exception e) {
            logger.error("Data access exception occured : ", e);
            collateralDetailsMainDto.setDisplayMsg("Save Loan Borrower operation failled: Some system error occured: Please try again or contact the feature team ");
            if (e instanceof JpaSystemException) {
                Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
                if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
                    collateralDetailsMainDto
                            .setDisplayMsg("The Loan Borrower Informations was updated by a different user since loaded; please review the most up to date information");
                }
            }
            throw new CtracAjaxException(e);
        }
    }

    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "admin/saveLoanBorrower", method = RequestMethod.POST)
    public String saveLoanBorrowerInfo(
    		@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
    		@ModelAttribute("loansData") LoanData loansData, @RequestParam("isPrimaryLoan") boolean isPrimary,
	        BindingResult errors, ModelMap model) {
        logger.debug("saveLoanBorrowerInfo:BEGIN");
        try {
            collateralDetailsData.setSaveStatus("");
            collateralDetailsService.saveLoanBorrower(collateralDetailsData, loansData, isPrimary);
            collateralDetailsService.refreshLoanBorrowerSection(collateralDetailsData);
            collateralDetailsData.setSaveStatus("Changes have been saved successfully");
            model.addAttribute("collateralDetailsData", collateralDetailsData);
            logger.debug("saveLoanBorrowerInfo :: END");
            return "admin/collateralDetails";
        } catch (Exception e) {
            logger.error("Data access exception occured : ", e);
            collateralDetailsData.setDisplayMsg(
            		"Save Loan Borrower operation failled: Some system error occured: Please try again or contact the feature team ");
            if (e instanceof JpaSystemException) {
                Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
                if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
                    collateralDetailsData.setDisplayMsg(
                    		"The Loan / Borrower section was updated by a different user since loaded. Please review the most up-to-date information.");
                }
            }
            throw new CtracAjaxException(e);
        }
    }

    @Secured({EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(value = "admin/verifyLoanBorrower", method = RequestMethod.POST)
    public String verifyLoanBorrowerInfo(
    		@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData,
    		BindingResult errors, HttpServletRequest request, HttpServletResponse response,
    		SessionStatus sessionStatus, ModelMap model) {
        logger.debug("verifyLoanBorrowerInfo:BEGIN");
        try {
        	collateralDetailsData.getLoanBorrowerSectionData().setVerifyMode(true);
        	collateralDetailsStatusService.updateLoanBorrowerSection(collateralDetailsData);
            collateralDetailsService.refreshLoanBorrowerSection(collateralDetailsData);
            boolean fullyVerified = VerificationStatus.VERIFIED ==
            		collateralDetailsData.getLoanBorrowerSectionData().getSectionStatusDto().getStatusId();
            collateralDetailsData.getLoanBorrowerSectionData().setVerifyMode(!fullyVerified);

            collateralDetailsData.setSaveStatus("Changes have been saved successfully");
            model.addAttribute("collateralDetailsData", collateralDetailsData);
            logger.debug("verifyLoanBorrowerInfo :: END");
            return "admin/collateralDetails";
        } catch (Exception e) {
            logger.error("Data access exception occured : ", e);
            collateralDetailsData.setDisplayMsg(
            		"Save Loan Borrower operation failed: Some system error occured: Please try again or contact the feature team ");
            if (e instanceof JpaSystemException) {
                Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
                if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
                    collateralDetailsData.setDisplayMsg(
                    		"The Loan Borrower Informations was updated by a different user since loaded; please review the most up to date information");
                }
            }
            throw new CtracAjaxException(e);
        }
    }

	@RequestMapping(value = "admin/getVerifiedPostalAddressForLoanBorrower", method = RequestMethod.GET)
	@ResponseBody
	public String getVerifiedPostalAddressForLoanBorrower(@RequestParam("entityMailingAddress") String entityMailingAddress,
			@RequestParam("entityUnitBuilding") String entityUnitBuilding,
			@RequestParam("entityCity") String entityCity,
			@RequestParam("entityState") String entityState,
			@RequestParam("entityZip") String entityZip
			) {

		String validatedAddress = "";
		try{
			validatedAddress = getVerifiedPostalAddress(entityMailingAddress, entityUnitBuilding, entityCity, entityState, entityZip);
		} catch(Exception e){
		    logger.error(e.getMessage(), e);
        }
		return validatedAddress;
	}

	@RequestMapping(value = "admin/getVerifiedPostalAddressForCollateralOwner", method = RequestMethod.GET)
	@ResponseBody
	public String getVerifiedPostalAddressForCollateralOwner(@RequestParam("contactDetailDto.address.streetAddress") String collateralOwnerMailingAddress,
			@RequestParam("contactDetailDto.address.unitOrBuilding") String collateralOwnerUnit,
			@RequestParam("contactDetailDto.address.city") String collateralOwnerCity,
			@RequestParam("contactDetailDto.address.state") String collateralOwnerState,
			@RequestParam("contactDetailDto.address.zipCode") String collateralOwnerZipCode
			) {

		String validatedAddress = "";
		try {
			validatedAddress = getVerifiedPostalAddress(collateralOwnerMailingAddress, collateralOwnerUnit, collateralOwnerCity, collateralOwnerState, collateralOwnerZipCode);
		} catch(Exception e){
		    logger.error(e.getMessage(), e);
        }
		return validatedAddress;
	}

	private String getVerifiedPostalAddress(String mailingAddress, String unitBuilding, String city, String state, String zip) {
		String returnedValue = "";

		try {
			LoanBorrowerAddressDTO loanBorrowerAddressDTO = new  LoanBorrowerAddressDTO();
			loanBorrowerAddressDTO.setStreetAddress(mailingAddress);
			loanBorrowerAddressDTO.setUnitBuilding(unitBuilding);
			loanBorrowerAddressDTO.setCity(city);
			loanBorrowerAddressDTO.setState(state);
			loanBorrowerAddressDTO.setZipCode(zip);

			loanBorrowerAddressService.setVerifiedPostalAddressFields(loanBorrowerAddressDTO);

			if (loanBorrowerAddressDTO.getErrorMessage().equals("")) {
				returnedValue = loanBorrowerAddressDTO.getVerifiedStreetAddress() + "|" +
						loanBorrowerAddressDTO.getVerifiedUnitBuilding() + "|" +
						loanBorrowerAddressDTO.getVerifiedCity() + "|" +
						loanBorrowerAddressDTO.getVerifiedState() + "|" +
						loanBorrowerAddressDTO.getVerifiedZipCode();
			} else {
				returnedValue=loanBorrowerAddressDTO.getErrorMessage();
			}

			return (returnedValue);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return ("");
	}

}