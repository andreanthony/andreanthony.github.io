package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_REMAP_RESEARCH_ITEM_SCREEN_ID;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracBaseException;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapResearchDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.GenericScreenProperties;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

@Controller
@SessionAttributes({ "floodRemapResearchDto","tmParams"})
public class RecordResearchController extends BaseController {

	private static final Logger logger = Logger.getLogger(RecordResearchController.class);

	@Autowired
	@Qualifier("floodRemapService")
	private FloodRemapService floodRemapService;

	@Autowired
	@Qualifier("emailAttachmentsBucket")
	private EmailAttachmentsBucket emailAttachmentsBucket;

	@Autowired
	private CollateralManagementService collateralManagementService;

	@Autowired
	private MessageSource messageSource;


	private UserEntitlementService userEntitlementService;

	@Autowired
	public RecordResearchController(UserEntitlementService userEntitlementService) {
		assert(userEntitlementService != null);
		this.userEntitlementService = userEntitlementService;
	}
	@RequestMapping(value = "/floodRemap/launchResearchItemHelper", method = RequestMethod.GET)
	public String launchResearchItemHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {

		GenericScreenProperties details = new GenericScreenProperties("workflows/floodremap/researchItem", FLOOD_REMAP_RESEARCH_ITEM_SCREEN_ID);
		return launchResearchItemHelper(request, model, tmParams, details);
	}

	@RequestMapping(value = "/floodRemap/recordResearchItemResponse/{taskId}", method = RequestMethod.POST)
	public ModelAndView researchItemSubmit(@Valid @ModelAttribute("floodRemapResearchDto") FloodRemapResearchDto floodRemapResearchDto, BindingResult binding, @PathVariable String taskId,
										   ModelMap model, SessionStatus sessionStatus, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		logger.debug("researchItemSubmit()::Start");

		String userId = floodRemapResearchDto.getTmParams().getUserId();
		UserEntitlementsDTO userEntitlementsDTO = userEntitlementService.getByJanusUsername(userId);

		if (WorkflowStateDefinition.findByWorkflowStep(floodRemapResearchDto.getCurrentWorkFlowStep()) == WorkflowStateDefinition.VERIFY_RESEARCH
				&& !userEntitlementsDTO.getAuthorities().containsKey(EntitlementRoles.VERIFER_ROLE)) {
			throw new CTracWebAppException("E0360", CtracErrorSeverity.APPLICATION, floodRemapResearchDto.getTmParams());
		}

		ModelAndView redirectView = processResearchResponse(floodRemapResearchDto, taskId, binding, request, "submit");
		redirectAttributes.addAttribute("confirmation", messageSource.getMessage("researchitem.save.confirmation", null, null));
		logger.debug("researchItemSubmit()::End");
		return redirectView;

	}

	private String launchResearchItemHelper(HttpServletRequest request, ModelMap model, TMParams tmParams, GenericScreenProperties details) {
		logger.debug("launchResearchItemHelper()::Start");
		if (tmParams.getId_task() != null) {
			try {
				FloodRemapResearchDto floodRemapResearchDto = floodRemapService.populateResearchItemData(tmParams);
				model.addAttribute("floodRemapResearchDto", floodRemapResearchDto);
				return details.getPageUrl();
			} catch(CTracBaseException e) {
				logger.debug(e.getMessage(), e);
				throw new CTracWebAppException(e.getErrorCode(), CtracErrorSeverity.TRIVIAL, tmParams);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new CTracWebAppException("E0111", CtracErrorSeverity.APPLICATION, tmParams);
			} finally {
				logger.debug("launchResearchItemHelper()::End");
			}
		} else {
			logger.error("Received Task UUID from TM is null");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}
	}

	private ModelAndView processResearchResponse(FloodRemapResearchDto floodRemapResearchDto, String tmTaskId, BindingResult binding, HttpServletRequest request,
												 String action) {

		try {
			logger.debug("processReseachResult()::Start");
			// FIXME: How does the binding get errors if not validating?
			if (!binding.hasErrors()) {
				logger.debug("Inside saveResearchItem handling request '/recordResearchItemResponse' with save only");
				floodRemapService.processResearchResponse(floodRemapResearchDto);
				logger.debug("researchItemSave()::End");
				return new ModelAndView(new RedirectView("/displayconfirmationItem/", true));
			} else { // Deal with validation Errors
				ModelAndView researchview = new ModelAndView();
				researchview.setViewName("workflows/floodremap/researchItem");
				researchview.addObject("floodRemapResearchDto", floodRemapResearchDto);
				logger.debug("processResearchPages()::validationFailure");
				return researchview;
			}
		}
		catch(Exception e){
			logger.error(e.getMessage());
			throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, floodRemapResearchDto.getTmParams());
		}
	}

	@RequestMapping(value = "/floodRemap/isValidForLinking", method = RequestMethod.GET)
	@ResponseBody
	public String isValidForLinking(
			@ModelAttribute("floodRemapResearchDto") FloodRemapResearchDto floodRemapResearchDto,
			@RequestParam("collateralId") Long collateralId) {
		return floodRemapService.isValidForLinking(floodRemapResearchDto, collateralId) ? "true" : "false";
	}

	//End point for getting collateral description
	@RequestMapping(value = "/floodRemap/getCollateralDescription", method = RequestMethod.POST)
	@ResponseBody
	public String getCollateralDescription(@ModelAttribute("floodRemapResearchDto") FloodRemapResearchDto floodRemapResearchDto, HttpServletRequest request, String collateralId,
										   SessionStatus sessionStatus) {
		String description = "";
		try{
			description = collateralManagementService.getCollateralDescription(Long.valueOf(collateralId));
			logger.debug("collateral id:"+ collateralId + "collateral description " + description);
		}
		catch(Exception e){
		}
		return description;
	}

}
