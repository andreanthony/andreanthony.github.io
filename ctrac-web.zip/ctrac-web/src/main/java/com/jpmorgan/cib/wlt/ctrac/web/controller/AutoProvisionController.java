package com.jpmorgan.cib.wlt.ctrac.web.controller;


import com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.UsersDto;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.CtracAutoProvisionHandler;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.security.CtracUserDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;

import net.jpmchase.cbhub.rsam.handlers.AutoProvisioningHandler;
import net.jpmchase.cbhub.rsam.servlet.AutoProvisioningServlet;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author N664895
 *
 */
@Controller
public class AutoProvisionController extends AutoProvisioningServlet {

	private static final long serialVersionUID = 1668659262312004841L;
	
	Logger logger = Logger.getLogger(AutoProvisionController.class);
	
	@Autowired private CtracAuthenticationManager ctracAuthenticationManager;

    @Resource(name="autoProvisioningHandler")
    private CtracAutoProvisionHandler autoProvisionHandler;

    @Resource
    private CtracUserDetailsService userDetailsService;

    @Resource
    private UserEntitlementService userEntitlementService;

    @Resource
    private Environment env;

    @Override
    protected AutoProvisioningHandler getHandler() {
        return autoProvisionHandler;
    }

    /**
     * Why do we have an init method?  Because the RSAM API requires
     * calling init to set the variable _handler set which is required.
     */
    @PostConstruct
    public void init() {
        super.init();
    }

    @Override
    protected boolean isAuthenicated(HttpServletRequest httpServletRequest) {
        String id_user = ctracAuthenticationManager.getJanusUserCredentials(httpServletRequest);
        logger.debug("Login user SID:" + id_user + " requested the user provisioning services");
        if(id_user != null) {
            //track the fact they've logged in
            userDetailsService.updateLastLogin(id_user);
            //do they have the proper entitlement to perform auto-provisioning
            return userDetailsService.hasRole(id_user, EntitlementRoles.IDNOW_AUTO_PROVISION);
        } else {
            return false;
        }
    }

    @ResponseBody
    @RequestMapping(value = "api/userProvisioningServices", method = RequestMethod.POST, produces = MediaType.APPLICATION_XML_VALUE)
    public void processAutoProvisioning(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        super.service(req, res);
    }


    @ResponseBody
    @RequestMapping(value = "api/setupTestUser", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
    public void setupTestUser(HttpServletRequest req, HttpServletResponse res,
                              @RequestParam(CtracAutoProvisionHandler.SID_PARAMETER) String sid,
                              @RequestParam(CtracAutoProvisionHandler.JANUS_USERNAME_PARAMETER) String username,
                              @RequestParam(value = "PROFILE", required = false) String profile,
                              @RequestParam(CtracAutoProvisionHandler.ACTION_PARAMETER) String action,
                              @RequestParam(value=CtracAutoProvisionHandler.FIRSTNAME_PARAMETER, required=false) String first,
                              @RequestParam(value=CtracAutoProvisionHandler.LASTNAME_PARAMATER, required=false) String last)
            throws ServletException, IOException {

        String serverEnv = env.getActiveProfiles()[0];
        if(serverEnv != null && !serverEnv.equalsIgnoreCase("PROD")) {
            logger.debug("Requesting to switch profile for SID=" + sid + " JANUS USER= " + username + " PROFILE= " + profile + " ACTION= " + action);
            if(sid == null || username == null || action == null) {
                throw new IllegalArgumentException("Failed to process setup test user request due to missing required parameter");
            }
            String rawRequest = toXML(sid, username, profile, action, first, last);
            String response= autoProvisionHandler.processProvisioningRequest(rawRequest);
            sendResponse(res, response);
        } else {
            throw new AccessDeniedException("Not permitted to setup users in production.");
        }
    }



    @RequestMapping(value = "api/lookupTestUser", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    public ModelAndView getTestUserEntitlements(HttpServletRequest req, HttpServletResponse res,
                                @RequestParam(CtracAutoProvisionHandler.SID_PARAMETER) String sid, ModelMap model
    ) throws ServletException, IOException {

        String serverEnv = env.getActiveProfiles()[0];
        if(serverEnv != null && !serverEnv.equalsIgnoreCase("PROD")) {
            logger.debug("Requesting to view user entitlements for SID= " + sid);
            if(sid == null) {
                throw new IllegalArgumentException("Failed to process setup test user request due to missing required parameter SID");
            }
            UsersDto user = userEntitlementService.getUserDetails(sid);
            ModelAndView mv = new ModelAndView("admin/userEntitlements", model);

            if(user == null) {
                mv.addObject("statusMessage", "User Not Found with SID: " + sid);
                user = new UsersDto();
            }
            mv.addObject("usersDto", user);
            return mv;
        } else {
            throw new AccessDeniedException("Not permitted to lookup users in production.");
        }
    }

    /**
     * Method to convert into raw entitlement request XML so that auto-provisioning
     * service can handle requests.
     * @param params
     * @return
     */
    private String toXML(String... params) {
        StringBuilder result = new StringBuilder();
        result.append("<provisionRequest xmlns='http://jpmorgan/rmt/bo'>");
        result.append("<action>").append(params[3]).append("</action>");
        result.append("<requestId>").append(1).append("</requestId>");
        result.append("<recipientType>").append(1).append("</recipientType>");
        result.append("<recipientId>").append(1).append("</recipientId>");
        result.append("<provAttributeMap>");
        result.append("<entry>").append("<key>").append(CtracAutoProvisionHandler.SID_PARAMETER).append("</key>").append("<value>").append(params[0]).append("</value>").append("</entry>");
        result.append("<entry>").append("<key>").append(CtracAutoProvisionHandler.JANUS_USERNAME_PARAMETER).append("</key>").append("<value>").append(params[1]).append("</value>").append("</entry>");
        if(params[2] != null) {
            result.append("<entry>").append("<key>").append(CtracAutoProvisionHandler.ROLE_PARAMETER).append("</key>").append("<value>").append(params[2]).append("</value>").append("</entry>");
        }
        result.append("<entry>").append("<key>").append(CtracAutoProvisionHandler.ACTION_PARAMETER).append("</key>").append("<value>").append(params[3]).append("</value>").append("</entry>");
        if(params[4] != null && params[5] != null) {
            result.append("<entry>").append("<key>").append(CtracAutoProvisionHandler.FIRSTNAME_PARAMETER).append("</key>").append("<value>").append(params[4]).append("</value>").append("</entry>");
            result.append("<entry>").append("<key>").append(CtracAutoProvisionHandler.LASTNAME_PARAMATER).append("</key>").append("<value>").append(params[5]).append("</value>").append("</entry>");
        }
        result.append("</provAttributeMap>");
        result.append("</provisionRequest>");
        return result.toString();
    }

}
