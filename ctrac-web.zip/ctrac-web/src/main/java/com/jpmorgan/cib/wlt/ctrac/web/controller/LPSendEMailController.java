package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@SessionAttributes({ "searchCollateralData","ownerData", "collateralDetailsData", "insurancePolicyRequirementDto" })
public class LPSendEMailController  {

	private static final Logger logger = Logger.getLogger(CollateralDetailsController.class);

	@Autowired private LenderPlaceService lenderPlaceService;

	@RequestMapping(value = "admin/sendLPPremiumEMail", method = RequestMethod.GET)
	public String sendLPPremiumEMail(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		try {
			logger.debug("sendLPPremiumEMail::BEGIN");
			lenderPlaceService.processLpPremiumPaidLOBEmail();
			logger.debug("sendLPPremiumEMail::END");
			return "admin/sendLPPremiumEMailStatus";
		} catch (Exception e) {
			logger.error("Unable to launch launchCollateralDetails. Error message: " + e.getMessage(), e);
			throw new CTracWebAppException("E0224", CtracErrorSeverity.APPLICATION);
		}
	}
}
