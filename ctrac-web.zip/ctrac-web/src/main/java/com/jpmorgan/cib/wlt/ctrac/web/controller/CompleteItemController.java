package com.jpmorgan.cib.wlt.ctrac.web.controller;


import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CALL_OR_EMAIL_AGENT_1ST_NOTICE;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CALL_OR_EMAIL_AGENT_2ND_NOTICE;
import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.CALL_OR_EMAIL_AGENT_3RD_NOTICE;

import java.util.HashSet;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.CommonTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CompleteItemData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;



@Controller
@SessionAttributes({"completeItemData", "tmParams"})
public class CompleteItemController extends BaseController{

	private static final Logger logger = Logger.getLogger(CompleteItemController.class);



	@Autowired
	private LookupCodeRepository lookupCodeRepository;
	
//	@Autowired
//	@Qualifier("completeItemAndChildrenCommand")
//	private GenericCommand<CompleteItemParams> completeItemAndChildrenCommand;

	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private PerfectionTaskRepository perfectionTaskRepository;
	
	@Autowired
	@Qualifier("CommonTaskService")
	private CommonTaskService commonTaskService;
	
	private Set<String> workflowStepsWithCompleteItemEnabled = new HashSet<String>();
	//private HashMap<String, GenericCommand<CompleteItemParams>> completeItemAlterantePostCommand = new HashMap<String, GenericCommand<CompleteItemParams>>();
	
	@PostConstruct
	public void init() {
		//"completeItem.generic.alternate.message"
		workflowStepsWithCompleteItemEnabled.add(CALL_OR_EMAIL_AGENT_1ST_NOTICE.getName());
		workflowStepsWithCompleteItemEnabled.add(CALL_OR_EMAIL_AGENT_2ND_NOTICE.getName());
		workflowStepsWithCompleteItemEnabled.add(CALL_OR_EMAIL_AGENT_3RD_NOTICE.getName());
	}
	
	@RequestMapping(value = "/floodRemap/launchCompleteItemHelper", method = RequestMethod.GET)
	public String launchCompleteItemHelper(HttpServletRequest request, ModelMap model, TMParams tmParams) {

		return processLaunchComplete(request, model, tmParams);
	}
	
	
	@RequestMapping(value = "/floodInsurance/launchCompleteItemHelper", method = RequestMethod.GET)
	public String launchInsuranceCompleteItemHelper(HttpServletRequest request, ModelMap model, TMParams tmParams) {

		return processLaunchComplete(request, model, tmParams);
	}
	
	

	private String processLaunchComplete(HttpServletRequest request,
			ModelMap model, TMParams tmParams) {
		if (tmParams.getId_task() != null) {
			logger.debug("launchCompleteItemHelper()::Start");
			String workflowStep = perfectionTaskRepository.getWorkFlowStepForTmTaskId(tmParams.getId_task());
			if(workflowStepsWithCompleteItemEnabled.contains(workflowStep)){
				//Lock the TM Task using the TM Params and transaction is stored in TM Params afterwards
				lockTMTask(request,tmParams);

				CompleteItemData completeItemData = commonTaskService.prepareCompleteItem(tmParams);
				model.addAttribute("completeItemData", completeItemData);
				model.addAttribute("tmParams", tmParams);
				logger.debug("completeItemHelper()::End");
				return "completeItem";
			}
			// disply msg that the normal Complete Item will not be shown for this workflow step.
			logger.debug("For workflow step : "+ workflowStep + " user is not allowed to complete the task.");
			model.addAttribute("confirmation", messageSource.getMessage("completeItem.generic.alternate.message", null, null));
			return "floodRemapConfirmation";
			
		}
		else {			
			logger.error("Received Task UUID from TM is null");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION);		
		}
	}
	

@RequestMapping(value = "/floodRemap/completeItem/{taskId}", method = RequestMethod.POST)
	public ModelAndView completeRemapTask(@ModelAttribute("completeItemData") CompleteItemData completeItemData, @PathVariable String taskId, 
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {
		if (taskId != null) {
			logger.debug("completeItem()::Start");
			//String id_user = (String)request.getSession().getAttribute("JANUS_USER_ID");
			//logger.debug("Login user SID:" + id_user);
			//floodRemapCompleteItemData.getTmParams().setUserId(id_user);
			ModelAndView modelAndView = new ModelAndView();
			//floodRemapTaskValidator.validate(floodRemapCompleteItemData, binding);
			if (!binding.hasErrors()) {
				commonTaskService.processCompleteItem(completeItemData);		
				modelAndView.addObject("confirmation", messageSource.getMessage("completeitem.submit.OtherConfirmation", null, null));
				modelAndView.setViewName("floodRemapConfirmation");   
				logger.debug("completeItem()::End");
				return modelAndView;
			}
			else {
				modelAndView.setViewName("floodRemapCompleteItem");
				modelAndView.addObject("floodRemapCompleteItemData", completeItemData);
				logger.debug("completeItem()::validationFailure");
				return modelAndView;
			}
		}
		else {
			logger.error("Perfection task ID is null");
			throw new CTracWebAppException("E0190", CtracErrorSeverity.APPLICATION);
		}
	}

	
	
}
