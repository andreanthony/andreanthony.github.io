package com.jpmorgan.cib.wlt.ctrac.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.LPPolicyCertificateData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
@Controller
@SessionAttributes({ "lpPolicyCertificateData", "tmParams"})
public class AlthansCertificateController extends BaseController  {

	private static final Logger logger = Logger.getLogger(AlthansCertificateController.class);
	
	@Autowired
	@Qualifier("lenderPlaceService")
	LenderPlaceService lenderPlaceService;
	
	@Autowired
	private MessageSource messageSource;
	
	@RequestMapping(value = "/floodInsurance/launchAlthansCertificate", method = RequestMethod.GET)
	public String launchCertificateHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchCertificateHelper start()");
		
		if (tmParams.getId_task() != null) {
				try {				
					LPPolicyCertificateData lpPolicyCertificateData = lenderPlaceService.prepareLPPolicyData(tmParams);
					model.addAttribute("lpPolicyCertificateData", lpPolicyCertificateData);
					return "althansCertificate";					
				}catch(Exception e){
					logger.error(e.getMessage());
					logger.error("Error occurred while preparing"+ tmParams  +" page" + e.getMessage());				
					throw new CTracWebAppException("E0242", CtracErrorSeverity.APPLICATION, tmParams);
				}finally {
					logger.debug("launchCertificateHelper()::End");
				}
		}else {
			logger.error("Received Task UUID from TM is null");
			logger.debug("launchCertificateHelper exit()");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}
	}
	
	
	
	@RequestMapping(value = "/floodInsurance/verifyAlthansCertificate/{taskId}", method = RequestMethod.POST)
	public String verifyAlthansCertificate(@ModelAttribute("lpPolicyCertificateData") LPPolicyCertificateData lpPolicyCertificateData, @PathVariable String taskId, 
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {		
		if(lpPolicyCertificateData.getTmParams() == null){
			logger.error("Received TM params is null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		try {  
			logger.debug("verifyAlthansCertificate()::Start");
        	
        	if (!binding.hasErrors()) {
        		logger.debug("Inside submit handling request");
        		TMParams tmParams = lpPolicyCertificateData.getTmParams();
				//save the inforamtion
				lenderPlaceService.saveVendorCertificate(lpPolicyCertificateData);
			    
			    logger.debug("TM transaction ID ::" + lpPolicyCertificateData.getTmParams().getTmTransactionId());
			    model.addAttribute("confirmation", messageSource.getMessage("certificate.confirmation.message", null, null));
			    return "floodRemapConfirmation";
        	} else {
        		logger.debug("verifyAlthansCertificate()::validationFailure");				     		
        		return "althansCertificate";	
        	}
		}
		catch(Exception e) {
            logger.error(e.getMessage());
        	if (e instanceof CTracApplicationException) {
				throw new CTracWebAppException(((CTracApplicationException) e).getErrorCode(), ((CTracApplicationException) e).getSeverity());
			}
            throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, lpPolicyCertificateData.getTmParams());
		}
	}
}
