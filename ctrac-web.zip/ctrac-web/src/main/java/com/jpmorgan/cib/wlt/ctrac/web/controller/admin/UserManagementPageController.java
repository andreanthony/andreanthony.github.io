package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.NoUserFoundException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.ManageUserEntitlementRequest;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.validator.UserEntitlementManagementValidator;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * Page controller for managing user entitlements
 */
@SessionAttributes({ "userEntitlementRequest", "availableGroups" })
@Controller
@RequestMapping(value = "admin/entitlements")
public class UserManagementPageController {

    private static final Logger LOG = Logger.getLogger(UserManagementPageController.class);
    protected static final String CONST_SESSION_AVAILABLE_ROLES_LIST = "availableUserRoles";
    @Autowired private UserEntitlementManagementValidator userEntitlementManagementValidator;
    @Autowired private UserEntitlementService userEntitlementService;

    @Secured({EntitlementRoles.EAA_WRITER_ROLE,EntitlementRoles.ADMIN_ROLE,
           EntitlementRoles.OPERATE_WRITERS})
    @RequestMapping(value = "userSearch",method = RequestMethod.GET)
    public String loadManageUserEntitlementsPage(HttpServletRequest request){
        LOG.debug("loadManageUserEntitlementsPage:::START");
        //On page load store the available user roles in session
        request.getSession().setAttribute(CONST_SESSION_AVAILABLE_ROLES_LIST,
                userEntitlementService.getAllAvailableUserGroups());
        return "/admin/entitlements/userSearch";
    }

   @Secured({EntitlementRoles.EAA_WRITER_ROLE,EntitlementRoles.ADMIN_ROLE,
           EntitlementRoles.OPERATE_WRITERS})
    @RequestMapping(value = "userSearchResult/{sid}",method = RequestMethod.GET)
    public String searchUser(@PathVariable String sid, ModelMap model, HttpServletRequest servletRequest){
        LOG.debug("searchUser:::START ,user:" + sid);
        ManageUserEntitlementRequest request = new ManageUserEntitlementRequest(sid);
        try{
        	 model.addAttribute("availableGroups",servletRequest.getSession().
                     getAttribute(CONST_SESSION_AVAILABLE_ROLES_LIST));
            userEntitlementManagementValidator.validateSearchUserValidate(request);
            
             model.addAttribute("userEntitlementRequest",request);
        }catch(NoUserFoundException noUser){
        	request.setDisplayMsg(noUser.getErrorMessage());
            //User was not found - set the request asa model attribute so user will be able to add a new user
            model.addAttribute("userEntitlementRequest",request);
        }catch(Exception e){
            LOG.error(e.getMessage(), e);
            throw new CTracWebAppException("E0101", CtracErrorSeverity.TRIVIAL);
        }
        return "/admin/entitlements/userMaintenance :: userMaintenance";
    }
}
