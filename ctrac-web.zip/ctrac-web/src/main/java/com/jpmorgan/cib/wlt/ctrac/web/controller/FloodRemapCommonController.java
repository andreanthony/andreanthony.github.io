package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.batch.scheduler.TaskOnDemandScheduler;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapBatchService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AdminAjaxDTO;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ERR_SEVERITY_CRITICAL_MESSAGE;

/*
 * TODO @Christian Change this class:
 * Even though this is mainly a QA file/functionality, any request to 
 * update state should be configured as a POST not a get.
 */
@Controller
@RequestMapping(value = "/floodRemap")
public class FloodRemapCommonController extends BaseController {
	private static final Logger logger = LoggerFactory.getLogger(FloodRemapCommonController.class);

	@Autowired
	private FloodRemapBatchService floodRemapBatchService;

	@Autowired
	private DateCalculator dateCalculator;

	@Autowired
	@Qualifier("taskOnDemandScheduler")
	private TaskOnDemandScheduler taskOnDemandScheduler;

	@RequestMapping(value = "/remapTaskList", method = RequestMethod.GET)
	public ModelAndView getFloodRemapTaskList() {
		logger.debug("handling request '/remapTaskList'");
		ModelAndView modelAndView = new ModelAndView("floodRemapTaskList");
		return modelAndView;
	}

	@RequestMapping(value = "/runRSAMWeeklyCertification", method = RequestMethod.GET)
	public ModelAndView runRSAMWeeklyCertification(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runRSAMWeeklyCertification()::Start");
		taskOnDemandScheduler.runRSAMWeeklyCertification(true);
		ModelAndView modelAndView = getConfirmationMav("Sent CTRAC User Information to RSAM.");
		logger.debug("runRSAMWeeklyCertification()::End");
		return modelAndView;
	}
	
	@RequestMapping(value = "/runUserInactivityJob", method = RequestMethod.GET)
	public ModelAndView runUserInactivityJob(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runUserInactivityJob()::Start");
		taskOnDemandScheduler.runUserInactivityJob(true);
		ModelAndView modelAndView = getConfirmationMav("User Inactivity Job Completed");
		logger.debug("runUserInactivityJob()::End");
		return modelAndView;
	}

	@RequestMapping(value = "/runJanusCtracEntitlementSync", method = RequestMethod.GET)
	public ModelAndView runJanusCtracEntitlementSync(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runJanusCtracEntitlementSync()::Start");
		taskOnDemandScheduler.runJanusCtracEntitlementSync(true);
		ModelAndView modelAndView = getConfirmationMav("Janus Users Synced With CTRAC.");
		logger.debug("runJanusCtracEntitlementSync()::End");
		return modelAndView;
	}
	
	@RequestMapping(value = "/runSendRequestToInsuranceVendor", method = RequestMethod.GET)
	public ModelAndView runSendRequestToInsuranceVendor(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runSendRequestToInsuranceVendor()::Start");
        taskOnDemandScheduler.runSendRequestToInsuranceVendorJob(true);
		ModelAndView modelAndView = getConfirmationMav("Request to insurance vendor has been sent successfully.");
		logger.debug("runSendRequestToInsuranceVendor()::End");
		return modelAndView;	
	}
	
	@RequestMapping(value = "/runSendRequestToInsuranceVendorAlthans", method = RequestMethod.GET)
	public ModelAndView runSendRequestToInsuranceVendorAlthans(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runSendRequestToInsuranceVendorAlthans()::Start");
        taskOnDemandScheduler.runSendRequestToInsuranceVendorAlthansJob(true);
		ModelAndView modelAndView = getConfirmationMav("Request to insurance vendor has been sent successfully.");
		logger.debug("runSendRequestToInsuranceVendorAlthans()::End");
		return modelAndView;	
		
	}
	
	@RequestMapping(value = "/runProcessAlthansResponseFile", method = RequestMethod.GET)
	public ModelAndView runProcessAlthansResponseFile(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runProcessAlthansResponseFile()::Start");	
        taskOnDemandScheduler.runProcessAlthansResponseFile(true);
		ModelAndView modelAndView = getConfirmationMav("Althans response has been processed successfully.");
		logger.debug("runProcessAlthansResponseFile()::End");
		return modelAndView;	
	}
	
	@RequestMapping(value = "/runProcessAlthansCertificateFile", method = RequestMethod.GET)
	public ModelAndView runProcessAlthansCertificateFile(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runProcessAlthansCertificateFile()::Start");	
        taskOnDemandScheduler.runProcessAlthansCertificateFile(true);
		ModelAndView modelAndView = getConfirmationMav("Althans certificates have been processed successfully.");
		logger.debug("runProcessAlthansCertificateFile()::End");
		return modelAndView;	
	}
	
	@RequestMapping(value = "/runEntireEODProcess", method = RequestMethod.GET)
	public ModelAndView runEntireEODProcess(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runEntireEODProcess()::Start");
		taskOnDemandScheduler.runEndOfTheDayJob(true);
		ModelAndView modelAndView = getConfirmationMav("Entire Flood Remap Batch Process completed.");
		logger.debug("runEntireEODProcess()::End");
		return modelAndView;	
	}

	@RequestMapping(value = "/runSendCoverageGapReport", method = RequestMethod.GET)
	public ModelAndView runSendCoverageGapReport(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runSendCoverageGapReport()::Start");
		taskOnDemandScheduler.runSendCoverageGapReportEmail(true);
		ModelAndView modelAndView = getConfirmationMav("Coverage gap report email sent.");
		logger.debug("runSendCoverageGapReport()::End");
		return modelAndView;
	}

	@RequestMapping(value = "/runStarWarsProcess", method = RequestMethod.GET)
	public String runStarWarsProcess() {
		logger.debug("runStarWarsProcess()::Start");
		logger.debug("runStarWarsProcess()::End");
		return "admin/starWars";
	}

    @RequestMapping(value = "/runMigrateOpenTasksToTMProcess", method = RequestMethod.GET)
    public ModelAndView runMigrateOpenTasksToTMProcess(HttpServletRequest request, ModelMap model) {
        logger.debug("runMigrateTasksToTMProcess()::Start");
        try {
            floodRemapBatchService.migrateOpenTasksToTM();
            logger.debug("\n Migration of all OPEN tasks completed");
        } catch (Exception e) {
            logger.error("{} Migration of open tasks to TM completed with exception", ERR_SEVERITY_CRITICAL_MESSAGE, e);
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("confirmation", "Migration of tasks to TM completed sucessfully.");
        modelAndView.setViewName("floodRemapConfirmation");
        logger.debug("runMigrateTasksToTMProcess()::End");
        return modelAndView;
    }
	
	@RequestMapping(value = "/runEODC3Process", method = RequestMethod.GET)
	public ModelAndView runEODC3Process(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runEODC3Process()::Start");
		taskOnDemandScheduler.runEndOfTheDayC3Job(true);
		ModelAndView modelAndView = getConfirmationMav("End Of The Day C3 Batch Process completed.");
		logger.debug("runEODC3Process()::End");
		return modelAndView;	
	}
	
	@RequestMapping(value = "/runServiceLinkDataExtract", method = RequestMethod.GET)
	public ModelAndView runServiceLinkDataExtract(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runServiceLinkDataExtract()::Start");
		taskOnDemandScheduler.runServiceLinkJob(true);
		ModelAndView modelAndView = getConfirmationMav("Service Link data extract was successfully completed.");
		logger.debug("runServiceLinkDataExtract()::End");
		return modelAndView;	
	}
	
	@RequestMapping(value = "/runCoreLogicDataExtract", method = RequestMethod.GET)
	public ModelAndView runCoreLogicDataExtract(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runCoreLogicDataExtract()::Start");
		taskOnDemandScheduler.runCoreLogicDataJob(true);
		ModelAndView modelAndView = getConfirmationMav("Core Logic data extract was successfully completed.");
		logger.debug("runCoreLogicDataExtract()::End");
		return modelAndView;	
	}
	
	@RequestMapping(value = "/runProcessGDSImage", method = RequestMethod.GET)
	public ModelAndView runGDSImageDataExtract(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runProcessGDSImage()::Start");
		ModelAndView modelAndView;
        if (taskOnDemandScheduler.runProcessGDSImageJob(true)) {
            modelAndView = getConfirmationMav("GDS Image processed successfully.");
        } else {
            modelAndView = getConfirmationMav("GDS Image not processed successfully.");
        }
		logger.debug("runProcessGDSImage()::End");
		return modelAndView;	
	}
	
	@RequestMapping(value = "/runCheckRemapFileLastUpdateJob", method = RequestMethod.GET)
	public ModelAndView runCheckRemapFileLastUpdateJob(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runCheckRemapFileLastUpdateJob()::Start");
		taskOnDemandScheduler.runCheckRemapFileLastUpdateJob(true);
		ModelAndView modelAndView = getConfirmationMav("Check last remap file job was successfully completed.");
		logger.debug("runCheckRemapFileLastUpdateJob()::End");
		return modelAndView;	
	}


	@RequestMapping(value = "/runUpdateReferenceDate", method = RequestMethod.GET)
	public ModelAndView runUpdateReferenceDate(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runUpdateReferenceDate()::Start");
		taskOnDemandScheduler.runUpdateReferenceDateJob(true);
		ModelAndView modelAndView = getConfirmationMav("Reference date has successfully been updated.");
		logger.debug("runUpdateReferenceDate()::End");
		return modelAndView;	
	}
	
	@RequestMapping(value = "/runUpdateReferenceDateAjax", method = RequestMethod.GET)
    @ResponseBody
    public AdminAjaxDTO runUpdateReferenceDateAjax(HttpServletRequest request, ModelMap model, String taskType) {
        logger.debug("runUpdateReferenceDateAjax()::Start");    
        AdminAjaxDTO responseBody = new AdminAjaxDTO();
        taskOnDemandScheduler.runUpdateReferenceDateJob(true);
        Date referenceDate = dateCalculator.getCurrentReferenceDate();
        SimpleDateFormat fullDateFormat  = new SimpleDateFormat("EEEE, MMMM d, yyyy");
        responseBody.setReferenceDate(fullDateFormat.format(referenceDate));
        responseBody.setIsWorkingDay(dateCalculator.isBusinessDay(referenceDate) ? "Yes": "No");
        logger.debug("runUpdateReferenceDateAjax()::End");
        return responseBody;    
    }

	@RequestMapping(value = "/addToReferenceDate", method = RequestMethod.GET)
	@ResponseBody
    public String addToReferenceDate(@RequestParam("daysToAdd") Integer daysToAdd) {
	    DateTime updatedReferenceDate = floodRemapBatchService.updateReferenceDate(daysToAdd);
	    String className = dateCalculator.isBusinessDay(updatedReferenceDate.toDate()) ? "workingDay" : "notWorkingDay";
	    SimpleDateFormat sdf  = new SimpleDateFormat("EEEE, MMMM d, yyyy");
	    return "<strong id='referenceDate' class='" + className + "'>" + sdf.format(updatedReferenceDate.toDate()) + "</strong>";
	}

	@RequestMapping(value = "/runProcessToRenewPolicy", method = RequestMethod.GET)
	public ModelAndView runProcessToRenewPolicy(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runProcessToRenewPolicy()::Start");
		taskOnDemandScheduler.runProcessToReviewPolicyJob(true);
		ModelAndView modelAndView = getConfirmationMav("New Renewal policies are created for expiring policies.");
		logger.debug("runProcessWireRequest()::End");
		return modelAndView;
	}
	
	@RequestMapping(value = "/runProcessWireRequest", method = RequestMethod.GET)
	public ModelAndView runProcessWireRequest(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runProcessWireRequest()::Start");
		taskOnDemandScheduler.runProcessWireRequestJob(true);
		ModelAndView modelAndView = getConfirmationMav("Creating Wire Request Batch Process completed.");
		logger.debug("runProcessWireRequest()::End");
		return modelAndView;			
	}
	
	@RequestMapping(value = "/runEntirePostEODProcess", method = RequestMethod.GET)
	public ModelAndView runEntirePostEODProcess(HttpServletRequest request, ModelMap model, String taskType) {
		logger.debug("runEntirePostEODProcess()::Start");
		taskOnDemandScheduler.runPostFullEodJob(true);
		ModelAndView modelAndView = getConfirmationMav("Entire Post EOD Flood Remap Batch Process completed.");
		logger.debug("runEntirePostEODProcess()::End");
		return modelAndView;	
	}

	private ModelAndView getConfirmationMav(String confirmationMessage) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("confirmation", confirmationMessage);
        modelAndView.setViewName("floodRemapConfirmation");
        return modelAndView;
    }
}
