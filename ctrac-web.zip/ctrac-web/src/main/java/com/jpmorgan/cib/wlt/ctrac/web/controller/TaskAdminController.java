package com.jpmorgan.cib.wlt.ctrac.web.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.service.admin.TaskAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.TaskAdminDTO;

@Controller
@SessionAttributes({ "taskAdminData"})
@RequestMapping(value = "/admin")
public class TaskAdminController {

	private static final String TASK_ADMINISTRATION_URL = "/admin/taskAdministration";

	private static final Logger logger = Logger.getLogger(TaskAdminController.class);

	@Autowired
	private TaskAdminService taskAdminService;
	
	@RequestMapping(value = "taskAdministration", method = RequestMethod.GET)
	public ModelAndView launchTaskAdministration() {
		logger.debug("launchTaskAdministration::BEGIN");
		ModelAndView mav = new ModelAndView(TASK_ADMINISTRATION_URL);
		TaskAdminDTO taskAdminData = taskAdminService.prepareTaskAdminData();
		mav.addObject("taskAdminData", taskAdminData);
		logger.debug("launchTaskAdministration::END");
		return mav;
	}
	
	@RequestMapping(value = "taskAdministration", method = RequestMethod.POST, params = "validate")
	public ModelAndView validateTaskAdministration(@ModelAttribute("taskAdminData") TaskAdminDTO taskAdminData) {
		logger.debug("validateTaskAdministration::BEGIN");
		ModelAndView mav = new ModelAndView(TASK_ADMINISTRATION_URL);
		taskAdminService.validateTaskAdminData(taskAdminData);
		mav.addObject("taskAdminData", taskAdminData);
		logger.debug("validateTaskAdministration::END");
		return mav;
	}
	
	@RequestMapping(value = "taskAdministration", method = RequestMethod.POST, params = "submitme")
	public ModelAndView submitTaskAdministration(@ModelAttribute("taskAdminData") TaskAdminDTO taskAdminData) {
		logger.debug("submitTaskAdministration::BEGIN");
		ModelAndView mav = new ModelAndView(TASK_ADMINISTRATION_URL);
		taskAdminService.submitTaskAdminData(taskAdminData);
		mav.addObject("taskAdminData", taskAdminData);
		logger.debug("submitTaskAdministration::END");
		return mav;
	}
	
}
