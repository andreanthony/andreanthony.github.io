package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationUtils;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VendorInvoiceData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.AWAITING_VENDOR_INVOICE;
@Controller
@RequestMapping(value = "/floodRemap")
@SessionAttributes({ "floodRemapVendorInvoiceVerificationData", "tmParams"})
public class FloodRemapVendorInvoiceVerificationController extends BaseController  {

    private static final Logger logger = Logger.getLogger(FloodRemapVendorInvoiceVerificationController.class);
    public static final String FLOOD_REMAP_VENDOR_INVOICE_VERIFICATION = "floodRemapVendorInvoiceVerification";

    @Autowired
	@Qualifier("lenderPlaceService")
	private LenderPlaceService lenderPlaceService;

	@Autowired
	private MessageSource messageSource;

	@RequestMapping(value = "/launchFloodVendorInvoiceHelper", method = RequestMethod.GET)
	public String launchFloodVendorInvoiceHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchFloodVendorInvoiceHelper start()");

		if (tmParams.getId_task() != null) {
			String strConfirmHelperPage = checkTaskInReviewStatus(model,tmParams);
			if(strConfirmHelperPage != null && strConfirmHelperPage.equalsIgnoreCase("")){

				try {
					VendorInvoiceData floodRemapVendorInvoiceVerificationData = lenderPlaceService.prepareVendorInvoiceVerificationData(tmParams);
					model.addAttribute("floodRemapVendorInvoiceVerificationData", floodRemapVendorInvoiceVerificationData);
					//dynamic title

					if (floodRemapVendorInvoiceVerificationData.isCancellation()) {
						// for refund completion
						if (floodRemapVendorInvoiceVerificationData.isCollectVendorRefund()) {
							floodRemapVendorInvoiceVerificationData.setScreenTitle("Refund Confirmation");
							floodRemapVendorInvoiceVerificationData.setScreenId(CtracAppConstants.FLOOD_REMAP_VENDOR_REFUND_CONFIRMATION_SCREEN_ID);
						} else {
                            floodRemapVendorInvoiceVerificationData.setScreenTitle("Vendor Refund Verification");
                            floodRemapVendorInvoiceVerificationData.setScreenId(CtracAppConstants.FLOOD_REMAP_VENDOR_INVOICE_VERIFICATION_CANCELLATION_SCREEN_ID);
						}
					} else {
						floodRemapVendorInvoiceVerificationData.setScreenTitle(ApplicationUtils.setScreenTitle(floodRemapVendorInvoiceVerificationData.getTmTaskType())+" - Vendor Invoice Verification");
						floodRemapVendorInvoiceVerificationData.setScreenId(AWAITING_VENDOR_INVOICE.getName());
					}

					return FLOOD_REMAP_VENDOR_INVOICE_VERIFICATION;

				}catch(Exception e){
					logger.error("Error occurred while preparing flood insurance verify vendor invoice page" + e.getMessage(), e);
					throw new CTracWebAppException("E0242", CtracErrorSeverity.APPLICATION, tmParams);
				}finally {
					logger.debug("launchFloodVendorInvoiceHelper()::End");
				}
			}else {
				//return 'InReview' confirmation page.
				return strConfirmHelperPage;
			}

		}else {
			logger.error("Received Task UUID from TM is null");
			logger.debug("launchFloodVendorInvoiceHelper exit()");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}
	}

	/**
	 * Controller method to save and continue from Cancel refund confirmation helper page
	 */
	@RequestMapping(value = "/floodRemapVendorInvoice/{taskId}", method = RequestMethod.POST, params = { "saveAndContinue" })
	public String floodRemapVendorInvoiceCancellationSaveAndContinue(@ModelAttribute("floodRemapVendorInvoiceVerificationData") VendorInvoiceData floodRemapVendorInvoiceVerificationData, @PathVariable String taskId,
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {

		if(floodRemapVendorInvoiceVerificationData.getTmParams() == null){
			logger.error("Received TM params is null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		try {
			logger.debug("floodRemapVendorInvoiceVerificationDataSave()::Start");

        	if (!binding.hasErrors()) {
        		logger.debug("Inside floodRemapVendorInvoiceCancellationSaveAndContinue handling request '/floodRemapVendorInvoice' with save only");
				//save the inforamtion
				lenderPlaceService.processSubmitVendorInvoiceVerification(floodRemapVendorInvoiceVerificationData);

				lenderPlaceService.triggerMarketRefundEmail(floodRemapVendorInvoiceVerificationData);

			    logger.debug("TM transaction ID ::" + floodRemapVendorInvoiceVerificationData.getTmParams().getTmTransactionId());
			    model.addAttribute("confirmation", messageSource.getMessage("sendemail.save.confirmation", null, null));
			    return "floodRemapConfirmation";
        	} else {
        		logger.debug("floodRemapVendorCancellationConfirmation()::validationFailure");
        		return FLOOD_REMAP_VENDOR_INVOICE_VERIFICATION;
        	}
		}
		catch(Exception e) {
            logger.error(e.getMessage(), e);
            throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, floodRemapVendorInvoiceVerificationData.getTmParams());
		}
	}

	@RequestMapping(value = "/floodRemapVendorInvoice/{taskId}", method = RequestMethod.POST, params = { "process" })
	public ModelAndView floodRemapVendorInvoiceVerificationSubmit(@Valid @ModelAttribute("floodRemapVendorInvoiceVerificationData") VendorInvoiceData floodRemapVendorInvoiceVerificationData, BindingResult binding,
																  @PathVariable String taskId, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request) {

		if(floodRemapVendorInvoiceVerificationData.getTmParams() == null){
			logger.error("Received TM params is null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		try{
			logger.debug("floodRemapVendorInvoiceVerificationDataSubmit()::Start");
			ModelAndView modelAndView = new ModelAndView();

        	if (!binding.hasErrors()) {
        		logger.debug("Inside floodRemapVendorInvoiceVerificationDataSubmit handling request '/floodRemapVendorInvoice' with submit only");

				lenderPlaceService.processSubmitVendorInvoiceVerification(floodRemapVendorInvoiceVerificationData);

				modelAndView.addObject("confirmation", messageSource.getMessage("invoiceVerification.submit.confirmation", null, null));

    			modelAndView.setViewName("floodRemapConfirmation");
    			logger.debug("floodRemapCoverageInputSubmit()::End");
    			return modelAndView;
        	} else {
        		modelAndView.setViewName(FLOOD_REMAP_VENDOR_INVOICE_VERIFICATION);
				modelAndView.addObject("floodRemapVendorInvoiceVerificationData", floodRemapVendorInvoiceVerificationData);
				logger.debug("floodRemapCoverageInput()::validationFailure");
				return modelAndView;
        	}
		}
		catch(Exception e) {
            logger.error(e.getMessage(), e);
            throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, floodRemapVendorInvoiceVerificationData.getTmParams());
		}
	}
}
