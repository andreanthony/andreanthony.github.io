package com.jpmorgan.cib.wlt.ctrac.audit;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/audit")
public class AuditPageController {

    @Secured({ EntitlementRoles.WRITER_ROLE, EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView loadAuditPage() {
        return new ModelAndView("/audit/index");
    }
}
