package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.LOB_MAPPING_FOR_DATA_FEED_SECTION;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.LOB_MAPPING_FOR_DROP_DOWN_SECTION;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.lob.LOBInclusionExclusionService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LobMappingDTO;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

@Controller
@RequestMapping(value = "/admin")
@SessionAttributes({"lobMappingData"})
public class ConfigureLOBController {
	private static final Logger logger = Logger.getLogger(ConfigureLOBController.class);
	
	@Autowired private LOBInclusionExclusionService lobInclusionExclusionService;

	@RequestMapping(value = "configureLOB",method=RequestMethod.GET)
	@Secured({ EntitlementRoles.ADMIN_ROLE })
	public String launchConfigureLOB(ModelMap model, HttpSession session) {
		logger.debug("launchConfigureLOB:: BEGIN");
		LobMappingDTO lobMappingData = lobInclusionExclusionService.populateLOBs();
		lobMappingData.getLobMappingForDataFeeds().setDisplayMessage("");
		lobMappingData.getLobMappingForDropDown().setDisplayMessage("");
		model.addAttribute("lobMappingData", lobMappingData);
		session.setAttribute("lobMappingData", lobMappingData);
		logger.debug("launchConfigureLOB:: END");
		return "admin/lobInclusionExclusion";
	}
	
	@RequestMapping(value = "editLOB", method = RequestMethod.POST)
	@Secured({ EntitlementRoles.ADMIN_ROLE })
	public String editLOB(@ModelAttribute("lobMappingData") LobMappingDTO lobMappingData,
			@RequestParam("availableLobs") String[] availableLobs,
			@RequestParam("configuredLobs") String[] configuredLobs,@RequestParam("triggeredSectionId") String triggeredSectionId, ModelMap model) {
		logger.debug("editLOB:: BEGIN");
		lobMappingData.setTriggeredScreenId(triggeredSectionId);
		if(triggeredSectionId.equals(LOB_MAPPING_FOR_DATA_FEED_SECTION)){
			lobInclusionExclusionService.updateLOBListForSection(lobMappingData.getLobMappingForDataFeeds(), availableLobs, configuredLobs);
		}else if(triggeredSectionId.equals(LOB_MAPPING_FOR_DROP_DOWN_SECTION)){
			lobInclusionExclusionService.updateLOBListForSection(lobMappingData.getLobMappingForDropDown(), availableLobs, configuredLobs);
		}
		model.addAttribute("lobMappingData", lobMappingData);
		logger.debug("editLOB:: END");
		return "admin/lobInclusionExclusion";
	}
		
	@RequestMapping(value = "updateLOBs", method = RequestMethod.POST)
	@Secured({ EntitlementRoles.ADMIN_ROLE })
	public String updateLOBs(@ModelAttribute("lobMappingData") LobMappingDTO lobMappingData,ModelMap model){
		try{
			logger.debug("updateLOBs:: BEGIN");
			lobInclusionExclusionService.updateAvailableConfiguredLOBList(lobMappingData);
			model.addAttribute("lobMappingData", lobMappingData);
			logger.debug("updateLOBs:: END");
			return "admin/lobInclusionExclusion";
		}catch(Exception ex){
			logger.error("An error occurred while updating available and active LOB list");
			throw new CTracWebAppException("E0319",CtracErrorSeverity.CRITICAL);
		}		
	}
		
}
