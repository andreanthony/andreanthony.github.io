package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.SearchCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralSearchResultData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralSearchResultDataTablesRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralSearchResultDataTablesResponse;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.SearchCollateralData;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;


@Controller
@SessionAttributes({ "searchCollateralData" })
public class SearchCollateralController {

	private static final Logger logger = Logger.getLogger(SearchCollateralController.class);
	
	@Autowired
	@Qualifier("searchCollateralService")
	private SearchCollateralService searchCollateralService;
	

	@RequestMapping(value = "admin/searchCollateral", method = RequestMethod.GET)
	@Secured({EntitlementRoles.READER_ROLE})
	public String launchSearchCollateral(HttpServletRequest request,
			HttpServletResponse response, ModelMap model, HttpSession session) {
		try {
			logger.debug("launchSearchCollateral::BEGIN");
			Object searchCollateralData = session.getAttribute("searchCollateralData");
			model.addAttribute("searchCollateralData",
					searchCollateralData != null && searchCollateralData instanceof SearchCollateralData ?
							searchCollateralData : searchCollateralService.prepareSearchCollateralRecord());
			model.remove("errMsgServerSide");
			logger.debug("launchSearchCollateral::END");
			return "admin/searchCollateral";
		} catch (Exception e) {
			logger.error("Unable to launch launchSearchCollateral", e);
			throw new CTracWebAppException("E0193", CtracErrorSeverity.APPLICATION);
		}
	}
			
	@RequestMapping(value = "admin/collateralSearchResultAjax", method = RequestMethod.GET, produces = "application/json")
	@Secured({EntitlementRoles.READER_ROLE})
	public @ResponseBody CollateralSearchResultDataTablesResponse<CollateralSearchResultData> launchcollateralSearchResultAjax(
			HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			logger.debug("launchcollateralSearchResult::BEGIN");
			CollateralSearchResultDataTablesRequest dataTablesRequest =
					new CollateralSearchResultDataTablesRequest(SearchCollateralData.class, request);
			List<CollateralSearchResultData> resultContent =
					searchCollateralService.getCollateralSearchResult(dataTablesRequest);
			CollateralSearchResultDataTablesResponse<CollateralSearchResultData> result =
					new CollateralSearchResultDataTablesResponse<CollateralSearchResultData>(
							dataTablesRequest, resultContent);
			logger.debug("launchcollateralSearchResult::END");
			return result;
		} catch (Exception e) {
			logger.error("Unable to launch launchcollateralSearchResult", e);
			throw new CTracWebAppException("E0223", CtracErrorSeverity.APPLICATION);
		}
	}
	
	@RequestMapping(value = "admin/collateralSearchResult", method = RequestMethod.POST)
	@Secured({EntitlementRoles.READER_ROLE})
	public String postCollateralSearchCriteria(
			@ModelAttribute("searchCollateralData") SearchCollateralData searchCollateralData,
			HttpServletRequest request, HttpServletResponse response, ModelMap model, HttpSession session) {
		try {
			logger.debug("postCollateralSearchCriteria::BEGIN");
			session.setAttribute("searchCollateralData", searchCollateralData);
			logger.debug("postCollateralSearchCriteria::END");
			return "redirect:/admin/collateralSearchResult";
		} catch (Exception e) {
			logger.error("Unable to launch launchcollateralSearchResult", e);
			throw new CTracWebAppException("E0223", CtracErrorSeverity.APPLICATION);
		}
	}
	
	@RequestMapping(value = "admin/collateralSearchResult", method = RequestMethod.GET)
	@Secured({EntitlementRoles.READER_ROLE})
	public String launchCollateralSearchResult(ModelMap model, HttpSession session) {
		try {
			logger.debug("launchcollateralSearchResult::BEGIN");
			model.addAttribute("searchCollateralData", session.getAttribute("searchCollateralData"));
			logger.debug("launchcollateralSearchResult::END");
			return "admin/collateralSearchResult";
		} catch (Exception e) {
			logger.error("Unable to launch launchCollateralSearchResult", e);
			throw new CTracWebAppException("E0223", CtracErrorSeverity.APPLICATION);
		}
	}
	
}
