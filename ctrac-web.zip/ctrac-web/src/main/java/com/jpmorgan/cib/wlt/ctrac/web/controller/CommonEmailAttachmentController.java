package com.jpmorgan.cib.wlt.ctrac.web.controller;


import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FileItem;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;



@Controller
public class CommonEmailAttachmentController {

	 
	private static final Logger logger = Logger.getLogger(CommonEmailAttachmentController.class);
	
	
	@Autowired
	@Qualifier("emailAttachmentsBucket")
	EmailAttachmentsBucket emailAttachmentsBucket;
	
	@RequestMapping(value = "/uploadEmailAttachments", method = RequestMethod.POST)
	@ResponseBody public String uploadEmailAttachments(MultipartHttpServletRequest mpRequest,HttpServletRequest request, @ModelAttribute FileItem file, BindingResult binding ) {
		logger.debug("uploadEmailAttachments()::Start current bucket is "+file.getTaskUUId() );
		EmailAttachments attachment = new EmailAttachments(file.getTaskUUId());
		Set<FileItem> files = new HashSet<FileItem>();
		Iterator<String> itr = mpRequest.getFileNames();
		MultipartFile multiPartFile;
		while (itr.hasNext()) {
			multiPartFile = mpRequest.getFile(itr.next());
			FileItem afile = new FileItem(multiPartFile,multiPartFile.getOriginalFilename(), file.getTaskUUId());
			files.add(afile);
			logger.debug("  \n  file added "+afile);

		}
		attachment.pushAllFiles(files);
		emailAttachmentsBucket.pushEmailAttachments(attachment);
		return "Success";
	}
	
	
	@RequestMapping(value = "/deleteFile", method = RequestMethod.POST)
	@ResponseBody public String deleteAttachment(
			@RequestParam("taskUUId") String bucketKey, @RequestParam("name") String fileName) {
		logger.debug("deleteAttachment()::Start" );
		logger.debug("\n Attmepting to delete"+fileName+" from bucket key: "+bucketKey+"." );
		if("all".equals(fileName)){
			emailAttachmentsBucket.clear(bucketKey);
			return "success";
		}
		FileItem result = emailAttachmentsBucket.removeFile(bucketKey, fileName);
		return result==null?"noSuchFile":"success";
	}
	
	@RequestMapping(value = "/admin/deleteFile", method = RequestMethod.POST)
	@ResponseBody public String deleteAttachment2(
			@RequestParam("taskUUId") String bucketKey, @RequestParam("name") String fileName) {
		logger.debug("deleteAttachment2::Start");
		return deleteAttachment(bucketKey, fileName);
	}
	
}
