package com.jpmorgan.cib.wlt.ctrac.web.config;

import com.jpmorgan.cib.wlt.ctrac.batch.config.BaseBatchConfig;
import com.jpmorgan.cib.wlt.ctrac.service.aspect.AuditInformationBean;
import com.jpmorgan.cib.wlt.ctrac.web.interceptor.CtracRequestInterceptor;
import com.jpmorgan.cib.wlt.ctrac.web.interceptor.CtracRequestInterceptorBatchCheck;
import com.jpmorgan.cib.wlt.ctrac.web.spring.dialect.CustomSpringDialect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
import org.thymeleaf.extras.springsecurity4.dialect.SpringSecurityDialect;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.spring4.view.ThymeleafViewResolver;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.annotation.Resource;

@Configuration
@EnableWebMvc
@EnableTransactionManagement
@EnableScheduling
@ComponentScan(basePackages = {"com.jpmorgan.cib.wlt.ctrac.web","com.jpmorgan.cib.wlt.ctrac.auth","com.jpmorgan.cib.wlt.ctrac.event","com.jpmorgan.cib.wlt.ctrac.audit","com.jpmorgan.cib.wlt.ctrac.entitlements", "com.jpmorgan.cib.wlt.ctrac.dashboard", "com.jpmorgan.cib.wlt.ctrac.collateral", "com.jpmorgan.cib.wlt.tm.client"}, excludeFilters = { @ComponentScan.Filter(Configuration.class) })
@Import({BaseBatchConfig.class, SecurityConfig.class})
public class WebAppConfig extends WebMvcConfigurerAdapter{

    /*cache for a day */
    private static final int CACHE_PERIOD = 87000;

	@Resource
	private Environment env;

	@Autowired
	private LocalValidatorFactoryBean validator;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Bean
	public MultipartResolver  filterMultipartResolver() {
		MultipartResolver multipartResolver = new CommonsMultipartResolver();
		((CommonsMultipartResolver) multipartResolver).setMaxInMemorySize(Integer.MAX_VALUE);
        return multipartResolver;
    }

	@Bean
	public ThymeleafViewResolver getViewResolver(){
		ThymeleafViewResolver viewResolver = new ThymeleafViewResolver();
		viewResolver.setTemplateEngine(getTemplateEngine());
		//Thymeleaf View resolver - Set UTF-8 encoding (When application is
		// populating model values in the templates)
		viewResolver.setCharacterEncoding("UTF-8");
		viewResolver.setContentType("text/html;charset=UTF-8");
		return viewResolver;

	}

	@Bean
	public ServletContextTemplateResolver getTemplateResolver(){
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver();
		templateResolver.setPrefix("/WEB-INF/pages/");
		templateResolver.setSuffix(".html");
		templateResolver.setTemplateMode("HTML5");
		//set time to live to 1 day
		templateResolver.setCacheable(false);
		//Set UTF-8 encoding when thymeleaf is requesting the view templates
		templateResolver.setCharacterEncoding("UTF-8");
		return templateResolver;
	}

	@Bean
	public SpringTemplateEngine getTemplateEngine(){
		SpringTemplateEngine templateEngine = new SpringTemplateEngine();
		templateEngine.setTemplateResolver(getTemplateResolver());

		templateEngine.addDialect(new SpringSecurityDialect());
		templateEngine.addDialect(new CustomSpringDialect());

		return templateEngine;
	}

	@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/css/**").addResourceLocations("/css/").setCachePeriod(CACHE_PERIOD);
        registry.addResourceHandler("/img/**").addResourceLocations("/img/").setCachePeriod(CACHE_PERIOD);
        registry.addResourceHandler("/js/**").addResourceLocations("/js/").setCachePeriod(CACHE_PERIOD);
        registry.addResourceHandler("/ux/**").addResourceLocations("/ux/").setCachePeriod(CACHE_PERIOD);
    }

    @Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }

	@Bean
	public CtracRequestInterceptor ctracRequestInterceptor() {
		return new CtracRequestInterceptor();
	}

	@Bean
	public CtracRequestInterceptorBatchCheck ctracRequestInterceptorBatchCheck() {
		return new CtracRequestInterceptorBatchCheck();
	}

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
    	registry.addInterceptor(ctracRequestInterceptor());
        registry.addInterceptor(ctracRequestInterceptorBatchCheck());
    }

	@Bean
	public RequestMappingHandlerAdapter getRequestMappingHandlerAdapter(){
		return new RequestMappingHandlerAdapter();
	}

	@Bean
	public RequestContextListener requestContextListener() {
	    return new RequestContextListener();
	}

	@Bean
	@Scope(value="session", proxyMode=ScopedProxyMode.TARGET_CLASS)
	public AuditInformationBean auditInformationBean() {
		return new AuditInformationBean();
	}

    @Override
    public Validator getValidator(){
		return validator;
    }
}
