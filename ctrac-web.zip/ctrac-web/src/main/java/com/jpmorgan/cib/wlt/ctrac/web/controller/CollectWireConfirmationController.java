package com.jpmorgan.cib.wlt.ctrac.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.CollectWireConfirmationData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;


@Controller
@RequestMapping(value = "/floodRemap")
@SessionAttributes({"collectWireConfirmationData","tmParams"})
public class CollectWireConfirmationController extends BaseController {

	private static final Logger logger = Logger.getLogger(CollectWireConfirmationController.class);

	@Autowired
	private Environment env;

	@Autowired
	@Qualifier("wireProcessingService")
	WireProcessingService wireProcessingService;

	
	@RequestMapping(value = "/launchCollectWireConfirmationHelper", method = RequestMethod.GET)
	public String launchCollectWireConfirmation(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		logger.info("launchCollectWireConfirmation::Start()");
		try{
			String strConfirmHelperPage = checkTaskInReviewStatus(model,tmParams);
			if(strConfirmHelperPage != null && strConfirmHelperPage.equalsIgnoreCase("")){
				CollectWireConfirmationData	collectWireConfirmationData = wireProcessingService.prepareCollectWireConfirmationData(tmParams);
				model.addAttribute("collectWireConfirmationData", collectWireConfirmationData);
				logger.info("launchCollectWireConfirmation::End()");
				return "collectWireConfirmation";
			}else {
				return strConfirmHelperPage;//return 'InReview' confirmation page.
			}			
		}
		catch(Exception e) {
			logger.error(e.getMessage());
			throw new CTracWebAppException("E0242", CtracErrorSeverity.APPLICATION, tmParams);
		}
	}

	@RequestMapping(value = "/collectWireConfirmation", method = RequestMethod.POST)
	public ModelAndView collectWireConfirmationNotify(@ModelAttribute("collectWireConfirmationData") CollectWireConfirmationData collectWireConfirmationData, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request) {
		logger.info("collectWireConfirmation::Start()");
		TMParams tmParams = collectWireConfirmationData.getTmParams();
		if (tmParams.getUserId() == null) {
			logger.error("Received user id is null");
			throw new CTracWebAppException("E0173", CtracErrorSeverity.APPLICATION, tmParams);
		}
		logger.debug("Request user id: " + tmParams.getUserId());
		logger.info("collectWireConfirmation::End()");
		return null;
	}

}
