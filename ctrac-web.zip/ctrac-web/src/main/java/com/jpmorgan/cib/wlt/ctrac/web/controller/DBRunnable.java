package com.jpmorgan.cib.wlt.ctrac.web.controller;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;

public class DBRunnable implements Runnable {
	private static final Logger logger = Logger.getLogger(DBRunnable.class);

	private Long collateralID;
	private CollateralDetailsService collateralDetailsService;
	
	 public DBRunnable(CollateralDetailsService collateralDetailsService, Long collateralID) {
		 this.collateralDetailsService = collateralDetailsService;
		 this.collateralID = collateralID;
	 }
	 
	 public void run() {
	        logger.info("Starting a new thread.");
			CollateralDetailsMainDto collateralDetailsData =
					collateralDetailsService.populateCollateralDetailsInformation(collateralID);
			logger.info("Found Borrower Names: " + collateralDetailsData.getCollateralDto().getBorrowerNames());

	    }
	

}
