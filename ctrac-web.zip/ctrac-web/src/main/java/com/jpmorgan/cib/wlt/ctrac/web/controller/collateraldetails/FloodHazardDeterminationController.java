package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.FloodDeterminationDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.FloodDeterminationService;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

@Controller
@SessionAttributes({ "collateralDetailsData", "floodHazardDeterminationDto" })
public class FloodHazardDeterminationController {

	private static final Logger logger = Logger.getLogger(FloodHazardDeterminationController.class);

	@Autowired
	private CollateralDetailsService collateralDetailsService;
	
	@Autowired
	private FloodDeterminationService floodDeterminationService;

	/**
	 * This is the main method invoked from the collateral main section to load
	 * the flood determination overlay for Display purposes or to create a new
	 * flood determination
	 * 
	 * @param collateralDetailsMainDto
	 * @param floodDeterminationId
	 * @param action
	 * @param model
	 * @param sessionStatus
	 * @param request
	 * @param response
	 * @return
	 */
	@Secured({EntitlementRoles.READER_ROLE})
	@RequestMapping(value = "admin/displayFloodDetermination", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
	@ResponseBody
	public ModelAndView launchDisplayFloodDetermination(@ModelAttribute("collateralDetailsData") final CollateralDetailsMainDto collateralDetailsMainDto,
			@RequestParam("floodDeterminationId") Long floodDeterminationId, @RequestParam("action") String action, ModelMap model,
			SessionStatus sessionStatus, HttpServletRequest request, HttpServletResponse response) {

		logger.debug("launchDisplayFloodDetermination::BEGIN");
		request.getSession().setAttribute("mode", "display");

		FloodDeterminationDto displayedFloodDeterminationDto = loadOverlayFloodDetermination(collateralDetailsMainDto, "display", floodDeterminationId, response);
		model.addAttribute("floodHazardDeterminationDto", displayedFloodDeterminationDto);
		logger.debug("launchDisplayFloodDetermination::END");

		return new ModelAndView("flooddetermination/floodHazardDetermination", model);
	}

	/**
	 * This is the main method invoked from the collateral main section to load
	 * the flood determination overlay for Display purposes or to create a new
	 * flood determination
	 * 
	 * @param collateralDetailsMainDto
	 * @param floodDeterminationId
	 * @param action
	 * @param model
	 * @param sessionStatus
	 * @param request
	 * @param response
	 * @return
	 */
	@Secured({EntitlementRoles.READER_ROLE})
	@RequestMapping(value = "admin/editFloodDetermination", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
	@ResponseBody
	public ModelAndView launchNewFloodDetermination(@ModelAttribute("collateralDetailsData") final CollateralDetailsMainDto collateralDetailsMainDto,
			@RequestParam("floodDeterminationId") Long floodDeterminationId, @RequestParam("action") String action, ModelMap model,
			SessionStatus sessionStatus, HttpServletRequest request, HttpServletResponse response) {

		logger.debug("launchNewFloodDetermination::BEGIN");
		request.getSession().setAttribute("mode", "edit");

		FloodDeterminationDto pendingVerificationFloodDeterminationDto = loadOverlayFloodDetermination(collateralDetailsMainDto, action, floodDeterminationId, response);

		model.addAttribute("floodHazardDeterminationDto", pendingVerificationFloodDeterminationDto);

		logger.debug("launchNewFloodDetermination::END");

		return new ModelAndView("flooddetermination/floodHazardDetermination", model);
	}
	
	
	/**
	 * This is the main method Invoked from the flood determination overlay to delete
	 * 
	 * @param collateralDetailsMainDto
	 * @return
	 */ 		
	@RequestMapping(value = "admin/saveFloodDetermination/", method = RequestMethod.POST, params = { "saveAndVerify" })
	public ResponseEntity<BaseApiResponse> verifyFloodDetermination(@Valid @ModelAttribute("floodHazardDeterminationDto") FloodDeterminationDto floodDeterminationDto,
            BindingResult errors, @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto) {
		logger.debug("verifyFloodDetermination::BEGIN ");
		// the only type of determination we can edit is a draft...
		try {
            if(!errors.hasErrors()){
                floodDeterminationService.verifyFloodDeterminationSection(collateralDetailsMainDto);
                collateralDetailsService.refreshFloodDeterminationSection(collateralDetailsMainDto);
            }
			BaseApiResponse apiResponse = new BaseApiResponse(errors,StringUtils.EMPTY);
            return new ResponseEntity<>(apiResponse,errors.hasErrors()?HttpStatus.BAD_REQUEST:HttpStatus.OK);
		} catch (Exception e) {
			return handleApiException(collateralDetailsMainDto,e);
		}
	}

	@RequestMapping(value = "admin/reloadFloodDeterminationSectionFromSession", method = RequestMethod.GET)
	@Secured({EntitlementRoles.READER_ROLE})
	public String reloadFloodDeterminationSectionFromSession(
			@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData) {
		logger.debug("reloadFloodDeterminationSectionFromSession:BEGIN");
		return "admin/floodHazardDeterminationSection :: floodHazardDeterminationSection";
	}

	/**
	 * Handle the exception for any Flood Determination API's
	 * @param collateralDetailsMainDto
	 * @param e
	 * @return Exception will get thrown
	 */
	private ResponseEntity<BaseApiResponse> handleApiException(CollateralDetailsMainDto collateralDetailsMainDto, Exception e){
		logger.error("Data access exception occured : ", e);
		collateralDetailsMainDto
				.setDisplayMsg("Save required coverage operation failled: Some system error occured: Please try again or contact the feature team ");
		if (e instanceof JpaSystemException) {
			Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
			if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
				collateralDetailsMainDto
						.setDisplayMsg("the collateral informations was updated by a different user since loaded; please review the most up to date information");
			}
		}
		throw new CtracAjaxException(e);
	}


	/**
	 * This is the main method Invoked from the flood determination overlay to delete
	 * 
	 * @param collateralDetailsMainDto
	 * @param floodHazardDeterminationDto
	 * @param action
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "admin/editFloodDetermination/update", method = RequestMethod.POST)
	public ResponseEntity<BaseApiResponse> updateFloodDetermination(@ModelAttribute("collateralDetailsData") final CollateralDetailsMainDto collateralDetailsMainDto,
			@ModelAttribute("floodHazardDeterminationDto") final FloodDeterminationDto floodHazardDeterminationDto,
			@RequestParam("action") final String action, ModelMap model, HttpServletRequest request) {

		logger.debug("updateFloodDetermination::BEGIN ");
		// the only type of fiat we can edit is a draft...
		try {
			if ("delete".equals(action) && "edit".equals(request.getSession().getAttribute("mode"))) {
				floodDeterminationService.persistFloodDeterminationSection(collateralDetailsMainDto, floodHazardDeterminationDto, action);
                return new ResponseEntity<>(new BaseApiResponse("reload"),HttpStatus.OK);
			}
			
			model.addAttribute("floodHazardDeterminationDto", floodHazardDeterminationDto);
            return new ResponseEntity<>(new BaseApiResponse(),HttpStatus.OK);
		} catch (Exception e) {
			return handleApiException(collateralDetailsMainDto,e);
		}
	}

	/**
     * This is the main method Invoked from the flood determination overlay to delete
	 * 
	 * @param floodDeterminationDto
	 * @param collateralDetailsMainDto
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "admin/saveFloodDetermination/", method = RequestMethod.POST, params = { "save" })
	public ResponseEntity<BaseApiResponse> saveFloodDeterminationDetails(@Valid @ModelAttribute("floodHazardDeterminationDto") FloodDeterminationDto floodDeterminationDto, BindingResult errors,
																		 @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto, HttpServletRequest request) {

		logger.debug("saveFloodDeterminationDetails::BEGIN ");
		try {
			if(!errors.hasErrors() && "edit".equals(request.getSession().getAttribute("mode"))){
				String action = "inputDraft"; // TODO when implementing verify, get the action from the session,// input vs verify
				floodDeterminationService.persistFloodDeterminationSection(collateralDetailsMainDto, floodDeterminationDto, action);
			}
			logger.debug("saveFloodDeterminationDetails::END ");
			BaseApiResponse apiResponse = new BaseApiResponse(errors, StringUtils.EMPTY);
			return new ResponseEntity<>(apiResponse,errors.hasErrors()?HttpStatus.BAD_REQUEST: HttpStatus.OK);
		} catch (Exception e) {
			return handleApiException(collateralDetailsMainDto,e);
		}
	}

	private FloodDeterminationDto loadOverlayFloodDetermination(final CollateralDetailsMainDto collateralDetailsMainDto, String action,
			Long floodDeterminationId, HttpServletResponse response) {
		logger.debug("loadOverlayFloodDetermination::BEGIN ");
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		response.addHeader("X-UA-Compatible", "IE=edge");

		FloodDeterminationDto displayedInsurancePolicyRequirementDto = collateralDetailsService.prepareFloodDeterminationOverlayData(
				collateralDetailsMainDto.getCollateralDto(), collateralDetailsMainDto.getFloodDeterminationSectionDto(), action, floodDeterminationId);
		logger.debug("loadOverlayFloodDetermination::END ");
		return displayedInsurancePolicyRequirementDto;
	}

}
