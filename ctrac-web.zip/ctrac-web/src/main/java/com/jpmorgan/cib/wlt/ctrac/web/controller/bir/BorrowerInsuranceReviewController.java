package com.jpmorgan.cib.wlt.ctrac.web.controller.bir;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyReasonForVerification;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRMode;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AgentResponseData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AutoSuggestionsDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ReferenceValues;
import com.jpmorgan.cib.wlt.ctrac.service.helper.SuggestionsUtil;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("bir")
@SessionAttributes({ "borrowerInsuranceReviewData", "referenceValues" ,"otmParams" })
public class BorrowerInsuranceReviewController {

	private static final Logger logger = Logger.getLogger(BorrowerInsuranceReviewController.class);
    
	@Autowired
	private BorrowerInsuranceReviewService borrowerInsuranceReviewService;


	@Autowired
	private SuggestionsUtil suggestionsUtil;

    @Autowired
    private MessageSource messageSource;
    

	@Secured({EntitlementRoles.READER_ROLE}) 
    @RequestMapping(value = "launchBIROverlay", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView launchBIRModal(@RequestParam("policyRid") Long policyRid, 
    		@RequestParam("collateralRid") Long collateralRid, @RequestParam("mode") Integer mode,HttpSession session) {
        logger.debug("launchBorrowerInsuranceReview::BEGIN");
        
        TMParams tmParams =null;
        if(session.getAttribute("tmParams") !=null){
        	tmParams =(TMParams)session.getAttribute("tmParams");
        }
        ModelAndView mav = launchBorrowerInsuranceReview(policyRid, collateralRid, mode,tmParams);
        logger.debug("launchBorrowerInsuranceReview::END ");
        return mav;
    }
	
    @Secured({EntitlementRoles.READER_ROLE}) 
    @RequestMapping(value = "launchBorrowerInsuranceReview", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView launchBorrowerInsuranceReview() {
        logger.debug("launchBorrowerInsuranceReview::BEGIN");
        ModelAndView mav = launchBorrowerInsuranceReview(null, null, 1, null);
        logger.debug("launchBorrowerInsuranceReview::END ");
        return mav;
    }
    
    private ModelAndView launchBorrowerInsuranceReview(Long policyRid, Long collateralRid, Integer mode, TMParams tmParams) {
    	ModelAndView mav = new ModelAndView("/bir/borrowerInsuranceReview");
        policyRid = policyRid != null && policyRid > 0 ? policyRid : null;
        BorrowerInsuranceReviewDTO borrowerInsuranceReviewData;
        BIRMode birMode = BIRMode.find(mode);
        if (policyRid != null && birMode == BIRMode.EDIT) {
        	borrowerInsuranceReviewData = borrowerInsuranceReviewService.prepareExistingBIR(policyRid, collateralRid);
        } else if (policyRid != null && birMode == BIRMode.VERIFY) {
        	borrowerInsuranceReviewData = borrowerInsuranceReviewService.prepareVerifyBIR(policyRid, collateralRid);
        } else if (policyRid != null && (birMode == BIRMode.RENEWAL || birMode == BIRMode.REPLACE)) {
        	borrowerInsuranceReviewData = borrowerInsuranceReviewService.prepareBIRByBIRMode(policyRid, collateralRid, birMode);
        } else {
        	borrowerInsuranceReviewData = borrowerInsuranceReviewService.prepareNewBIR(collateralRid);
        }
        borrowerInsuranceReviewData.setBirMode(birMode);
        borrowerInsuranceReviewData.setCollateralRid(collateralRid);
        borrowerInsuranceReviewData.setTmParams(tmParams);
        if(BIRMode.VERIFY.equals(birMode)) {
            borrowerInsuranceReviewData.saveACopy();
        }
        mav.addObject("borrowerInsuranceReviewData", borrowerInsuranceReviewData);
        mav.addObject("referenceValues",
                borrowerInsuranceReviewService.getBorrowerInsuranceReviewReferenceValues(birMode));
        addExtraObjectsOnModelAndView(mav,borrowerInsuranceReviewData );
        return mav;
    }

    
    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "addCollateralToBIR", method = RequestMethod.POST)
    public String addCollateralToBIR(
    		@ModelAttribute("borrowerInsuranceReviewData") BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
            @RequestParam("collateralId") Long collateralId, HttpServletResponse response) {
        logger.debug("addCollateralToBIR::BEGIN");
        try {
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.addHeader("X-UA-Compatible", "IE=edge");
            removeErrorMessage(borrowerInsuranceReviewData);
            borrowerInsuranceReviewService.addCollateralToBIR(collateralId, borrowerInsuranceReviewData);
        } catch (CTracApplicationException e) {
        	borrowerInsuranceReviewData.getProofOfCoverageData().setDisplayMessage(e.getErrorMessage());
        }
        logger.debug("addCollateralToBIR::END");
        return "/bir/borrowerInsuranceReview";
    }
    
    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "removeCollateralFromBIR", method = RequestMethod.POST)
    public String removeCollateralFromBIR(
    		@ModelAttribute("borrowerInsuranceReviewData") BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
            @RequestParam("collateralId") Long collateralId, HttpServletResponse response) {
        logger.debug("addCollateralToBIR::BEGIN");
        try {
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.addHeader("X-UA-Compatible", "IE=edge");
            removeErrorMessage(borrowerInsuranceReviewData);
            borrowerInsuranceReviewService.removeCollateralFromBIR(collateralId, borrowerInsuranceReviewData);
        } catch (CTracApplicationException e) {
        	borrowerInsuranceReviewData.getProofOfCoverageData().setDisplayMessage(e.getErrorMessage());
        }
        logger.debug("addCollateralToBIR::END");
        return "/bir/borrowerInsuranceReview";
    }
    
    
    @Secured({EntitlementRoles.ADMIN_ROLE})
    @RequestMapping(value = "overrideAdmin", method = RequestMethod.POST)
    public String overrideAdmin(
    		@ModelAttribute("borrowerInsuranceReviewData") BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
            HttpServletResponse response) {
        logger.debug("overrideAdmin::BEGIN");
        try {
            borrowerInsuranceReviewData.setAdminOverride(true);
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.addHeader("X-UA-Compatible", "IE=edge");
            removeErrorMessage(borrowerInsuranceReviewData);
        	borrowerInsuranceReviewData.getProofOfCoverageData().setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
    		borrowerInsuranceReviewData.getProofOfCoverageData().setReasonForVerification(PolicyReasonForVerification.OTHER.name());
    		BIRCollateralDetailsDTO birCollateralDetailsDTO = borrowerInsuranceReviewData.getCollateralDetailsMap().get(borrowerInsuranceReviewData.getCollateralRid());
    		birCollateralDetailsDTO.setReasonForVerification(PolicyReasonForVerification.OTHER.name());
    		birCollateralDetailsDTO.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
        } catch (CTracApplicationException e) {
        	borrowerInsuranceReviewData.getProofOfCoverageData().setDisplayMessage(e.getErrorMessage());
        }
        logger.debug("overrideAdmin::END");
        return "/bir/borrowerInsuranceReview";
    }
    
    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "submitBorrowerInsuranceReview", method = RequestMethod.POST, params = "review")
    public ModelAndView reviewBorrowerInsurance(
            @Valid  @ModelAttribute("borrowerInsuranceReviewData") BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, BindingResult errors,
    		@ModelAttribute("referenceValues") ReferenceValues referenceValues) {
        logger.debug("reviewBorrowerInsurance::BEGIN");
        ModelAndView mav = new ModelAndView("/bir/borrowerInsuranceReview");
        try {
            if(!errors.hasErrors()){
                removeErrorMessage(borrowerInsuranceReviewData);
                
                resetSignedByAgentValue(borrowerInsuranceReviewData);
                
                borrowerInsuranceReviewService.reviewBorrowerInsurance(borrowerInsuranceReviewData, false);
                mav.addObject("borrowerInsuranceReviewData", borrowerInsuranceReviewData);
                mav.addObject("referenceValues", borrowerInsuranceReviewService.
                        getBorrowerInsuranceReviewReferenceValues(borrowerInsuranceReviewData.getBirMode()));
            }
        } catch (CTracApplicationException e) {
        	borrowerInsuranceReviewData.getProofOfCoverageData().setDisplayMessage(e.getErrorMessage());
        } finally {
            addExtraObjectsOnModelAndView(mav,borrowerInsuranceReviewData);
        }
        logger.debug("reviewBorrowerInsurance::END");
        return mav;
    }
    
    private void resetSignedByAgentValue(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
		//resets the signedByAgent value if use selected an eoi other than AWP
		if (!"AWP".equals(borrowerInsuranceReviewData.getEoiType())) {
			borrowerInsuranceReviewData.setSignedByAgent(null);
		}
	}
    
    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value = "submitBorrowerInsuranceReview", method = RequestMethod.POST, params = "save")
    public ModelAndView submitBorrowerInsuranceReview(
    		@Valid @ModelAttribute("borrowerInsuranceReviewData") BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, BindingResult errors,
    		@ModelAttribute("referenceValues") ReferenceValues referenceValues) {
        logger.debug("submitBorrowerInsuranceReview::BEGIN");
        // FIXME: make this go to confirmation page
        ModelAndView mav = new ModelAndView("/bir/borrowerInsuranceReview");
        try {
            if(!errors.hasErrors()){
                removeErrorMessage(borrowerInsuranceReviewData);
                
                resetSignedByAgentValue(borrowerInsuranceReviewData);
                
                borrowerInsuranceReviewService.submitBorrowerInsuranceReview(borrowerInsuranceReviewData);
            }
        } catch (CTracApplicationException e) {
        	mav.setViewName("/bir/borrowerInsuranceReview");
        	mav.addObject("borrowerInsuranceReviewData", borrowerInsuranceReviewData);
            mav.addObject("referenceValues", borrowerInsuranceReviewService.
                    getBorrowerInsuranceReviewReferenceValues(borrowerInsuranceReviewData.getBirMode()));
            borrowerInsuranceReviewData.getProofOfCoverageData().setDisplayMessage(e.getErrorMessage());
        }finally {
            addExtraObjectsOnModelAndView(mav,borrowerInsuranceReviewData );
        }
        logger.debug("submitBorrowerInsuranceReview::END");
        return mav;
    }
    
    
    @Secured({EntitlementRoles.WRITER_ROLE})
    @RequestMapping(value="deleteBorrowerInsuranceReview", method=RequestMethod.POST)
    public String deleteBorrowerInsuranceReview(@ModelAttribute("borrowerInsuranceReviewData")BorrowerInsuranceReviewDTO borrowerInsuranceReviewData,
    		HttpServletRequest request, HttpServletResponse response, HttpSession session){
        if (!borrowerInsuranceReviewService.validateBorrowerInsurancePolicyDeletion(borrowerInsuranceReviewData.getProofOfCoverageData().getRid(), borrowerInsuranceReviewData.getCollateralRid(), borrowerInsuranceReviewData.isDeleteButtonVisible())) {
            logger.error(" Open tasks exist and must be closed before deleting this policy will be allowed.  Look for matching tasks using the Policy RID and if appropriate close them and try the delete again");
            throw new CTracWebAppException("E0348", CtracErrorSeverity.APPLICATION);
        }
    	logger.debug("deleteBorrowerInsuranceReview::BEGIN");
    	borrowerInsuranceReviewService.deleteBorrowerInsuranceReview(borrowerInsuranceReviewData);
    	logger.debug("deleteBorrowerInsuranceReview::END");
    	return "redirect:/admin/collateralDetails?collateralID="+borrowerInsuranceReviewData.getCollateralRid();
    }
    
    @RequestMapping(value = "launchLogPIAReview", method = RequestMethod.GET)
	@Secured({ EntitlementRoles.READER_ROLE })
	public String redirectTolaunchBIR(@ModelAttribute("tmParams") TMParams tmParams,
			HttpServletRequest request, HttpServletResponse response, HttpSession session, ModelMap model) {
    		String launchBIR = null;
    	try {
			AgentResponseData agentResponseData = borrowerInsuranceReviewService.getAgentResponse(tmParams);
		
			launchBIR= "/bir/launchBIROverlay?policyRid="+agentResponseData.getProofOfCoverageRid()+"&"+ "collateralRid="+agentResponseData.getCollateralRid()+"&"+"mode=1";
		} catch (Exception e) {
			logger.error(" redirectTolaunchBIR" + tmParams.getId_task() + " from CTRAC: cause " + e.getMessage());
			
		}
    	return "forward:"+launchBIR ;
    	//return "redirect:"+launchBIR ;
    	
	} 
    
    @RequestMapping(value = "loadInsuranceCompanyNames", method = RequestMethod.GET, produces = "application/json")
	@Secured({EntitlementRoles.WRITER_ROLE})
	public @ResponseBody List<AutoSuggestionsDto> loadInsuranceCompanyNames(@RequestParam("searchParam") String searchParam, 
			HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			logger.debug("loadInsuranceCompanyNames::BEGIN");			
			List<AutoSuggestionsDto> suggestions = suggestionsUtil.getInsuranceCompanyNamesContaining(searchParam);			
			logger.debug("loadInsuranceCompanyNames::END");
			return suggestions;
		} catch (Exception e) {
			logger.error("Unable to load InsuranceCompanyNames", e);
			throw new CTracWebAppException("E0345", CtracErrorSeverity.APPLICATION);
		}
	}
    
    private void removeErrorMessage(BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
    	borrowerInsuranceReviewData.getProofOfCoverageData().setDisplayMessage(null);
    }

    private String getMortgagePayeeLabel(Long collateralRid) {
        StringBuilder mortgagePayeeLabelBasedOnLoanType = new StringBuilder("primaryLoanTypeAs");
        mortgagePayeeLabelBasedOnLoanType.append(borrowerInsuranceReviewService.getPrimaryLoanOfBorrowerInsurance(collateralRid) != null
                ? borrowerInsuranceReviewService.getPrimaryLoanOfBorrowerInsurance(collateralRid).getLoanType() : "Other");
        mortgagePayeeLabelBasedOnLoanType.append(".borrowInsurance.Mortgage.Payee.label");
        String mortgagePayeeLabel = messageSource.getMessage(mortgagePayeeLabelBasedOnLoanType.toString(), null,
                "", Locale.getDefault());
        if (StringUtils.isEmpty(mortgagePayeeLabel)) {
            mortgagePayeeLabel = messageSource.getMessage("primaryLoanTypeAsOther.borrowInsurance.Mortgage.Payee.label",
                    null, Locale.getDefault());
        }
        return mortgagePayeeLabel;
    }

    private  void addExtraObjectsOnModelAndView(ModelAndView mav, BorrowerInsuranceReviewDTO borrowerInsuranceReviewData) {
        mav.addObject("borrowInsuranceMortgagePayeeLabel",getMortgagePayeeLabel(borrowerInsuranceReviewData.getCollateralRid()));
        mav.addObject("deleteBorrowerInsurancePolicyValidation",
                borrowerInsuranceReviewService.validateBorrowerInsurancePolicyDeletion(borrowerInsuranceReviewData.getProofOfCoverageData().getRid(),
                        borrowerInsuranceReviewData.getCollateralRid(), borrowerInsuranceReviewData.isDeleteButtonVisible()));
    }
}
