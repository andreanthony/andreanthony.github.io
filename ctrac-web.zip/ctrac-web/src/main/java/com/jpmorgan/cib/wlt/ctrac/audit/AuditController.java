package com.jpmorgan.cib.wlt.ctrac.audit;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.AuditService;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditEntrySearchCriteria;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditRetrieveResult;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/audit")
public class AuditController {

    private AuditService auditService;

    @Autowired
    public AuditController(AuditService auditService) {
        assert(auditService != null);
        this.auditService = auditService;
    }

    @RequestMapping(method = RequestMethod.GET)
    @Secured({ EntitlementRoles.WRITER_ROLE, EntitlementRoles.VERIFER_ROLE})
    public AuditRetrieveResult retrieve(AuditEntrySearchCriteria auditEntrySearchCriteria) {
        return auditService.retrieve(auditEntrySearchCriteria);
    }

    @RequestMapping(method = RequestMethod.POST)
    @Secured({EntitlementRoles.API_ROLE, EntitlementRoles.API_PROCESSES})
    public ResponseEntity publish(@RequestBody AuditEventDTO auditEventDTO) {
        auditService.create(auditEventDTO);
        return ResponseEntity.ok().build();
    }

}
