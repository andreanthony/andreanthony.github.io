package com.jpmorgan.cib.wlt.ctrac.web.controller.generic;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.AuthenticationEntryPoint;

import com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;

/**
 * @author
 * The responsibility of the class is to simply redirect to a 
 * designated authentication entry point; ideally TM url for Ctrac app
 *
 */
public class CtracAuthenticationEntryPoint implements AuthenticationEntryPoint {

	private static final Logger logger = Logger.getLogger(CtracAuthenticationEntryPoint.class);
	
	private String loginPageUrl; //This will Ideally be set to TM url
	
	private static final String ctrac403 ="/403";
	
	@Autowired private CtracAuthenticationManager ctracAuthenticationManager;
	
	public CtracAuthenticationEntryPoint(String errorPage){
		this.loginPageUrl = errorPage;
	}
	
    /**
     * Always returns to the authentication entry point, Ideally TM
     *
     */
	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
			throws IOException, ServletException {
		
		//TODO @Christian clear the User sessions attribute and auth. context. need a kind of fake logout
		SecurityContextHolder.getContext().setAuthentication(null);
		request.logout();
		
		/**
		 * if the username is not null and is not local, then the user had janus credential in session but is not known by ctrac;
		 * In that case it make no sence to redirect him to tm/janus login; always show 403 in that case;
		 */
		String userName = ctracAuthenticationManager.getJanusUserCredentials(request);
		
		if(!StringUtils.isBlank(userName) ||"LOCAL".equalsIgnoreCase(userName)){
			response.sendRedirect(ctrac403);
		}else{
			response.sendRedirect(loginPageUrl);
		}

	}

}