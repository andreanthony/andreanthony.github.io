package com.jpmorgan.cib.wlt.ctrac.web.controller.api;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.api.RestPathVariable;
import com.jpmorgan.cib.wlt.ctrac.service.api.RestService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AbstractApiController<T> {
    private final RestService<T> restService;

    protected AbstractApiController(RestService<T> restService) {
        assert(restService != null);
        this.restService = restService;
    }

    @Secured({EntitlementRoles.WRITER_ROLE, EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<T> create(T t, @PathVariable(required = false) Long collateralId) {
        return new ResponseEntity<>(restService.create(t, generatePathVariableMap(collateralId)), HttpStatus.OK);
    }

    @Secured({EntitlementRoles.READER_ROLE})
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<T>> retrieveAll(Object criteria, @PathVariable(required = false) Long collateralId) {
        return new ResponseEntity<>(restService.retrieveAll(criteria, generatePathVariableMap(collateralId)), HttpStatus.OK);
    }

    @Secured({EntitlementRoles.READER_ROLE})
    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    public ResponseEntity<T> retrieve(@PathVariable Long id, @PathVariable(required = false) Long collateralId) {
        return new ResponseEntity<>(restService.retrieve(id, generatePathVariableMap(collateralId)), HttpStatus.OK);
    }

    @Secured({EntitlementRoles.WRITER_ROLE, EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(value = "{id}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<T> update(@PathVariable Long id, @PathVariable(required = false) Long collateralId, T t) {
        return new ResponseEntity<>(restService.update(t, generatePathVariableMap(collateralId)), HttpStatus.OK);
    }

    @Secured({EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(value = "{id}/verify", method = RequestMethod.POST)
    public ResponseEntity<T> verify(@PathVariable Long id, @PathVariable(required = false) Long collateralId, T t) {
        return new ResponseEntity<>(restService.verify(t, generatePathVariableMap(collateralId)), HttpStatus.OK);
    }

    @Secured({EntitlementRoles.WRITER_ROLE, EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(value = "{id}/delete", method = RequestMethod.POST)
    public ResponseEntity delete(@PathVariable Long id, @PathVariable(required = false) Long collateralId) {
        restService.delete(id, generatePathVariableMap(collateralId));
        return ResponseEntity.ok(null);
    }

    @Secured({EntitlementRoles.WRITER_ROLE, EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(value = "delete", method = RequestMethod.POST)
    public ResponseEntity deleteAll(@PathVariable Long id, @PathVariable(required = false) Long collateralId) {
        restService.deleteAll(id, generatePathVariableMap(collateralId));
        return ResponseEntity.ok(null);
    }

    private Map<RestPathVariable, Object> generatePathVariableMap(Long collateralId) {
        Map<RestPathVariable, Object> pathVariables = new HashMap<>();
        if (collateralId != null) {
            pathVariables.put(RestPathVariable.COLLATERAL_ID, collateralId);
        }
        return pathVariables;
    }
}
