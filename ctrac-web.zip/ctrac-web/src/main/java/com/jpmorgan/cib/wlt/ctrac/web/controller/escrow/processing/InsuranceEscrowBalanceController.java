/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.web.controller.escrow.processing;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.EscrowProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.escrowbalance.EscrowBalanceData;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.controller.BaseController;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

/**
 * @author I031731
 *
 */

@Controller
@RequestMapping(value = "/floodRemap")
@SessionAttributes({"escrowBalanceData", "tmParams"})
public class InsuranceEscrowBalanceController extends BaseController {
	
	private static final Logger logger = Logger.getLogger(InsuranceEscrowBalanceController.class);	
	
    
	@Autowired
	@Qualifier("escrowProcessingService")
	private EscrowProcessingService escrowProcessingService;
		
	@Autowired
	private MessageSource messageSource;
	
	@RequestMapping(value = "/launchInsuranceEscrowBalanceHelper", method = RequestMethod.GET)
	public String launchInsruanceEscrowBalanceHelper(HttpServletRequest request,HttpSession session,  ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		
		logger.info("launchInsuranceEscrowBalanceHelper()::start");
		if (tmParams.getId_task() != null) {
			try {						
				EscrowBalanceData escrowBalanceData =escrowProcessingService.populateEscrowBalanceData(tmParams);						
				model.addAttribute("escrowBalanceData", escrowBalanceData);
				session.setAttribute("escrowBalanceData", escrowBalanceData);
				return "escrowBalance";
				
			} catch (Exception e) {
				logger.error("Error occurred while preparing Escrow Balance page" + e.getMessage());
				throw new CTracWebAppException("E0304", CtracErrorSeverity.APPLICATION, tmParams);
				
			} finally {
				logger.info("launchInsuranceEscrowBalanceHelper()::End");
			}
		} else {
			logger.error("Received Task UUID from TM is null");
			logger.info("launchInsuranceEscrowBalanceHelper exit()");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}

	}
	
	@RequestMapping(value = "/submitInsuranceEscrowBalanceHelper/{taskId}", method = RequestMethod.POST)
	public ModelAndView submitInsruanceEscrowBalance(  @ModelAttribute("escrowBalanceData") EscrowBalanceData escrowBalanceData, ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {

		if (escrowBalanceData.getTmParams() == null) {
			logger.error("Received TM params are null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		try {
			logger.debug("submitInsuranceEscrowBalanceHelper()::Start");
			ModelAndView modelAndView = new ModelAndView();			
			if (!binding.hasErrors()) {
				
				logger.debug("TM Transaction ID::" + escrowBalanceData.getTmParams() .getTmTransactionId());						
				escrowProcessingService.processEscrowBalance(escrowBalanceData);						
				modelAndView.addObject("confirmation", messageSource.getMessage("confirm.escrowbalance.request.submit.confirmation", null, null));
				modelAndView.setViewName("floodRemapConfirmation");
				logger.debug("submitInsuranceEscrowBalanceHelper()::End");
				return modelAndView;				
				
			} else {
				modelAndView.setViewName("escrowBalance");
				modelAndView.addObject("escrowBalanceData", escrowBalanceData);
				logger.debug("Escrow Balance Validation:validationFailure");
				return modelAndView;
			}
		} 
		catch(Exception e){
			logger.error(e.getMessage());
			throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, escrowBalanceData.getTmParams());
		}
	}
}
