package com.jpmorgan.cib.wlt.ctrac.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.service.admin.RestartLetterCycleService;
import com.jpmorgan.cib.wlt.ctrac.service.admin.TaskAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.RestartLetterCycleDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.TaskAdminDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.BaseDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

@Controller
@SessionAttributes({ "restartLetterCycleData"})
@RequestMapping(value = "/admin")
public class RestartLetterCycleController {

	private static final String RESTART_LETTER_CYCLE_URL = "admin/restartLetterCycle";

	private static final Logger logger = Logger.getLogger(RestartLetterCycleController.class);
	
	@Autowired private InsuranceMngtService insuranceMngtService;
	@Autowired private RestartLetterCycleService restartLetterCycleService;
	
	@RequestMapping(value = "restartLetterCycle", method = RequestMethod.GET)
	public String launchRestartLetterCycle(HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		logger.debug("launchRestartLetterCycle::BEGIN");
		ModelAndView mav = new ModelAndView(RESTART_LETTER_CYCLE_URL);
		
		RestartLetterCycleDTO  restartLetterCycleData = new RestartLetterCycleDTO();
		
		model.addAttribute("restartLetterCycleData", restartLetterCycleData);
		session.setAttribute("restartLetterCycleData", restartLetterCycleData);
		
		logger.debug("launchRestartLetterCycle::END");
		return RESTART_LETTER_CYCLE_URL;
	}
	
	@RequestMapping(value = "getRestartLetterCycleData", method = RequestMethod.POST)
	public String getRestartLetterCycleData(@ModelAttribute("restartLetterCycleData") RestartLetterCycleDTO restartLetterCycleData, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		logger.debug("getRestartLetterCycleData::BEGIN");
		
		try {			
			restartLetterCycleData = restartLetterCycleService.prepareRestartLetterCycleData(restartLetterCycleData.getCollateralID());
		
			model.addAttribute("restartLetterCycleData", restartLetterCycleData);
			session.setAttribute("restartLetterCycleData", restartLetterCycleData);
		}  catch (Exception e) {
			logger.error("Unable to get data for restart letter cycle. Error message: " + e.getMessage());
			if (e instanceof CTracApplicationException) {
				throw new CTracWebAppException(((CTracApplicationException) e).getErrorCode(), ((CTracApplicationException) e).getSeverity());
			}
			throw new CTracWebAppException("E0312", CtracErrorSeverity.APPLICATION);
		}
		
		logger.debug("getRestartLetterCycleData::END");
		return RESTART_LETTER_CYCLE_URL;
	}
	
	@RequestMapping(value = "initiateRestartLetterCycle", method = RequestMethod.POST)
	public String initiateRestartLetterCycle(@ModelAttribute("restartLetterCycleData") RestartLetterCycleDTO restartLetterCycleData, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		logger.debug("initiateRestartLetterCycle::BEGIN");
		
		restartLetterCycleData.setSuccessMsg(null);
		restartLetterCycleData.setErrorMsg(null);
				
		try {
			List<Long> proofOfCoverageRids = new ArrayList<Long>();
			
			String selectedRIDs = restartLetterCycleData.getSelectedRIDs();
			
			if (!selectedRIDs.equals("")) {
				String arrSelectedRIDs[] = selectedRIDs.substring(1).split("\\|");
				for (String s:arrSelectedRIDs) {
				   proofOfCoverageRids.add(new Long(s));
				}
				
				int restartLpCycleWorkflowCount = insuranceMngtService.restartLpCycleWorkflow(proofOfCoverageRids.toArray(new Long[0]));
				
				String policyText;
				if (arrSelectedRIDs.length > 1) {
					policyText="policies'";
				} else {
					policyText="policy's";
				}
				
				String message = "";
				switch(restartLpCycleWorkflowCount) {
					case 0:  message="No selected " + policyText + " LP letter cycle can be restarted."; break;
					case 1:  message="Restarted LP letter cycle for 1 selected policy."; break;
					default:  message="Restarted LP letter cycle for " + restartLpCycleWorkflowCount + " selected policies."; break;
				}
				
				if (restartLpCycleWorkflowCount == 0) {
					
				}
				
				restartLetterCycleData.setSuccessMsg(message);
			} else {
				restartLetterCycleData.setErrorMsg("Nothing is selected to restart letter cycle.");
			}
			
			restartLetterCycleData.setSelectedRIDs("");
		
			model.addAttribute("restartLetterCycleData", restartLetterCycleData);
			session.setAttribute("restartLetterCycleData", restartLetterCycleData);
		} catch (Exception e) {
			logger.error("Unable to restart letter cycle. Error message: " + e.getMessage());
			if (e instanceof CTracApplicationException) {
				throw new CTracWebAppException(((CTracApplicationException) e).getErrorCode(), ((CTracApplicationException) e).getSeverity());
			}
			throw new CTracWebAppException("E0311", CtracErrorSeverity.APPLICATION);
		}
		
		logger.debug("initiateRestartLetterCycle::END");
		return RESTART_LETTER_CYCLE_URL;
	}	
}
