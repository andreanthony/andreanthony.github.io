package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * Created by V704662 on 9/8/2017.
 */
@RestController
@RequestMapping(value = "admin/loan/borrower")
public class BorrowerRestController {

    @Secured({EntitlementRoles.WRITER_ROLE,EntitlementRoles.VERIFER_ROLE})
    @RequestMapping(value = "validate",method = RequestMethod.POST)
    public ResponseEntity<BaseApiResponse> validateBorrower(@Valid @RequestBody CustomerData borrower,
                                                            BindingResult bindingResult){
        BaseApiResponse apiResponse = new BaseApiResponse(bindingResult, StringUtils.EMPTY);
        return new ResponseEntity<>(apiResponse, apiResponse.isSuccess() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

}
