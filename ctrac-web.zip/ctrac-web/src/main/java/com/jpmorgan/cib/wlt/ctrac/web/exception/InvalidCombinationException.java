package com.jpmorgan.cib.wlt.ctrac.web.exception;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;


public class InvalidCombinationException extends CTracWebAppException  {

	 /**
	 * 
	 */
	private static final long serialVersionUID = -6687518503635666652L;

	public InvalidCombinationException(String errorCode, CtracErrorSeverity severity) {
		super(errorCode, severity);
	}

	    
}
