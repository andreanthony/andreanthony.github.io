package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.enums.ServiceAction;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.MicroServiceBroadcastEventDTO;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureBook;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Secured({EntitlementRoles.OPERATE_WRITERS})
@Controller
public class ServiceManagementController {

	private static final Logger log = LoggerFactory.getLogger(ServiceManagementController.class);

	private AuditInformationService auditInformationService;
	private PublishEventService publishEventService;
	private FeatureManager featureManager;

	@Autowired
	public ServiceManagementController(PublishEventService publishEventService,
									   AuditInformationService auditInformationService,
									   FeatureManager featureManager) {
		Assert.notNull(publishEventService, "Publish Event Service injected as null");
		this.publishEventService = publishEventService;
		Assert.notNull(auditInformationService, "Audit Information Service injected as null");
		this.auditInformationService = auditInformationService;
		Assert.notNull(featureManager, "Feature manager injected as null");
		this.featureManager = featureManager;
	}

	@RequestMapping(value = "/admin/serviceManagementPage", method = RequestMethod.GET)
	public ModelAndView getPage() {
		if(!featureManager.isActive(FeatureBook.MICRO_SERVICES_MANAGEMENT_PAGE)){
			return new ModelAndView("genericErrorPage");
		}
		return new ModelAndView("/admin/serviceManagement");
	}


	@RequestMapping(value = "/api/admin/clearCacheUserEntitlements", method = RequestMethod.POST)
	public ResponseEntity<String> clearServicesUserEntitlementsCache() {
		try {
			if(!featureManager.isActive(FeatureBook.MICRO_SERVICES_MANAGEMENT_PAGE)){
				return ResponseEntity.badRequest().body("Feature not enabled");
			}
			MicroServiceBroadcastEventDTO eventDTO =
					new MicroServiceBroadcastEventDTO(auditInformationService.getLoggedInUserSid());
			eventDTO.addAction(ServiceAction.CLEAR_ENTITLEMENTS_CACHE);
			publishEventService.publishEvent(eventDTO);
			return ResponseEntity.ok("Clear Cache triggered");
		} catch (Exception e) {
			log.error("Unable to send clearing cache event out to all services", e);
			return ResponseEntity.badRequest().body("Sending Clear Cache event failed");
		}
	}
}
