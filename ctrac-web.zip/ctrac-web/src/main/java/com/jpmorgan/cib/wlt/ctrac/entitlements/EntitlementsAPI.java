package com.jpmorgan.cib.wlt.ctrac.entitlements;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/entitlements")
public class EntitlementsAPI {

    private static final Logger logger = LoggerFactory.getLogger(EntitlementsAPI.class);

    private UserEntitlementService userEntitlementService;

    @Autowired
    public EntitlementsAPI(UserEntitlementService userEntitlementService) {
        assert(userEntitlementService != null);
        this.userEntitlementService = userEntitlementService;
    }

    @RequestMapping(method = {RequestMethod.GET,RequestMethod.POST}, value = "/{janusUsername}")
    @Secured({EntitlementRoles.API_ROLE, EntitlementRoles.API_PROCESSES})
    public ResponseEntity<UserEntitlementsDTO> getUserEntitlements(@PathVariable String janusUsername) {
        try {
            return ResponseEntity.ok(userEntitlementService.getByJanusUsername(janusUsername));
        } catch (Exception e) {
            return getUserEntitlementsResponseError(e);
        }
    }

    private ResponseEntity<UserEntitlementsDTO> getUserEntitlementsResponseError(Exception e) {
        logger.error(e.getMessage(), e);
        return ResponseEntity.badRequest().body(new UserEntitlementsDTO());
    }
}