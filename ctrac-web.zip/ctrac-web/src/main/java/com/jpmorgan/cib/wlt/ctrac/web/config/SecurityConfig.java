package com.jpmorgan.cib.wlt.ctrac.web.config;

import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;
import org.springframework.security.core.userdetails.UserDetailsByNameServiceWrapper;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.security.web.util.matcher.RegexRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import com.jpmorgan.cib.wlt.ctrac.web.controller.advice.CtracAccessDeniedHandler;
import com.jpmorgan.cib.wlt.ctrac.web.interceptor.filter.CookieSessionFilter;

/**
 *
 * @author
 * This is the main security driver. Custom ACL related config must not appear here
 */
@Configuration
@ComponentScan(basePackages = "com.jpmorgan.cib.wlt.ctrac.web", excludeFilters = { @ComponentScan.Filter(Configuration.class) })
@EnableWebSecurity
@EnableWebMvcSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true,securedEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	@Qualifier("ctracUserDetailsService")
	UserDetailsService ctracUserDetailsService;

	@Autowired
	DataSource ctracDataSource;

	@Autowired
	CookieSessionFilter cookieSessionFilter;

	@Value("${tm.url}")
	private String tmUrl;

	@Resource
	private Environment env;

	/**
	 * This is the main authentication provider injected//set into the class  in @com.jpmorgan.cib.wlt.ctrac.interceptor.filter.CookieSessionFilter
	 * but spring  @org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter will ultimately redelegate to the
	 * preauth. filter set below. Nevertheless we need both exposed as beans
	 */
	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {

		AuthenticationManager authManager = super.authenticationManagerBean();

		return authManager;

	}

	/**
	 * This bean configure a preauthentication filter that will make us bypass
	 * the username/password form base authentication
	 * @return
	 */
	@Bean
	public PreAuthenticatedAuthenticationProvider preauthAuthProvider(){

		UserDetailsByNameServiceWrapper<PreAuthenticatedAuthenticationToken> userDetailByNameWraper = new UserDetailsByNameServiceWrapper<PreAuthenticatedAuthenticationToken>(ctracUserDetailsService);

		PreAuthenticatedAuthenticationProvider preAuthenticatedAuthenticationProvider = new PreAuthenticatedAuthenticationProvider();
		preAuthenticatedAuthenticationProvider.setPreAuthenticatedUserDetailsService(userDetailByNameWraper);

		return preAuthenticatedAuthenticationProvider;
	}


	/**
	 * we set the main authentication provider to a pre-authentication wrapper capable of loading the user detail
	 * from the username (with or without a password)
	 * @param auth
	 * @throws Exception
	 */
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {

		auth.authenticationProvider(preauthAuthProvider());
	}


	/**
	 *
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		/**
		 * When running in the local environment,we will need a way to mock janus auth;
		 * Ideally a dummy page where users can setup the Username he need in the session.
		 * on our QA environments, it make sense to set this to tm url
		 */
		String authUrl = tmUrl;
		if(env.acceptsProfiles("local")){
			//
			authUrl="/403";
		}

		/**
		 * 1- //configuring ctrac pre-authentication filter. this will parse Janus credentials and uses it to authenticate to our DB
		 * 2- //grant access to static resources (js & css)
		 * 3- //Configure Global URl restrictions; this could have been done on the controller/service methods as well
		 * 4- //configure the redirect page for authenticated user trying to access restricted pages
		 * 5- //configure the redirect page for non authenticated users. This is where(url) user must authenticate
		 */
		 http
		 // Allow pages to be displayed in frames
		 .headers().frameOptions().disable()
		 .and().addFilter(cookieSessionFilter)
		 .authorizeRequests()
		 .antMatchers("/").permitAll()
		 .antMatchers("/css/**").permitAll()
		 .antMatchers("/js/**").permitAll()
		 .antMatchers("/403/**").permitAll()
		 .and().exceptionHandling().accessDeniedHandler(new CtracAccessDeniedHandler("/ctrac/floodRemap/permissions"))
		 .and().httpBasic()

		 //Enable cross site request forgery prevention from all pages
		 //Add exception points to exclude end points that don't need CSRF...
		.and().csrf().requireCsrfProtectionMatcher(new RequestMatcher() {
		        private Pattern allowedMethods = Pattern.compile("^(GET|HEAD|TRACE|OPTIONS)$");
		        private RegexRequestMatcher exceptionEndPoints = new RegexRequestMatcher("/uploadEmailAttachments/*/.*", null);
			 	private RegexRequestMatcher restEndPoints = new RegexRequestMatcher("/api/*/.*", null);
		       @Override
		        public boolean matches(HttpServletRequest request) {
		            // No CSRF is needed of methods that normally don't update the state
		            if(allowedMethods.matcher(request.getMethod()).matches())
		                return false;
		            // No CSRFis needed for method in our exception queue; our attachment unloader will be specified here
		            if(exceptionEndPoints.matches(request))
		                return false;
				   // No CSRF is needed, authentication handled by end point itself
				   if(restEndPoints.matches(request))
					   return false;
		            // CSRF for everything else that is not an API call or an allowedMethod
		            return true;
		        }
		    });

		 //.disable();
		 //TODO @Christian enable csrf filter


	}


}
