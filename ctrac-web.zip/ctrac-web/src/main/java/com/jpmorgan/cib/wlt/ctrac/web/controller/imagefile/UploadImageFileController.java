/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.web.controller.imagefile;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FileProcessingUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.letterImage.ImageFileData;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterImageService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.controller.BaseController;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

/**
 * @author Q003321
 *
 */

@Controller
@RequestMapping(value = "/floodRemap")
@SessionAttributes({"imageFileData", "tmParams"})
public class UploadImageFileController extends BaseController {
	
	private static final Logger logger = Logger.getLogger(UploadImageFileController.class);	

    private static final String GDS_IMAGE_ARCHIVE_OUTPUT_DIR = "gdsLetters.zipfile.archive.incoming.directory";
	
    @Autowired
    private CollateralDocumentRepository collateralDocumentRepository;
    
	@Autowired
	@Qualifier("letterImageService")
	private LetterImageService letterImageService;
	
	@Autowired
	@Qualifier("wireProcessingService")
	private WireProcessingService wireProcessingService;
	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private Environment env;
	
	@RequestMapping(value = "/launchImageFileHelper", method = RequestMethod.GET)
	public String launchImageFileHelper(HttpServletRequest request,HttpSession session,  ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		
		if (tmParams.getId_task() != null) {
			try {						
				ImageFileData imageFileData =letterImageService.populateImageFileData(tmParams);						
				model.addAttribute("imageFileData", imageFileData);
				session.setAttribute("imageFileData", imageFileData);
				return "imageLetters";
				
			} catch (Exception e) {
				logger.error("Error occurred while preparing Letter Image page" + e.getMessage());
				throw new CTracWebAppException("E0304", CtracErrorSeverity.APPLICATION, tmParams);
				
			} finally {
				logger.debug("launchImageFileHelper()::End");
			}
		} else {
			logger.error("Received Task UUID from TM is null");
			logger.debug("launchImageFileHelper exit()");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION, tmParams);
		}

	}
	
	@RequestMapping(value = "/submitImageFileRequest/{taskId}", method = RequestMethod.POST)
	public ModelAndView submitImageFileRequest(  @ModelAttribute("imageFileData") ImageFileData imageFileData, ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {

		if (imageFileData.getTmParams() == null) {
			logger.error("Received TM params are null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		try {
			logger.debug("submitImageFileRequest()::Start");
			ModelAndView modelAndView = new ModelAndView();			
			if (!binding.hasErrors()) {
				
				logger.debug("TM Transaction ID::" + imageFileData.getTmParams() .getTmTransactionId());						
				letterImageService.processImageFileConfirmation(imageFileData.getTmParams());						
				modelAndView.addObject("confirmation", messageSource.getMessage("confirm.image.request.submit.confirmation", null, null));
				modelAndView.setViewName("floodRemapConfirmation");
				logger.debug("submitImageFileRequest()::End");
				return modelAndView;				
				
			} else {
				modelAndView.setViewName("imageLetters");
				modelAndView.addObject("imageFileData", imageFileData);
				logger.debug("Image Confirmation Validation:validationFailure");
				return modelAndView;
			}
		} 
		catch(Exception e){
			logger.error(e.getMessage());
			throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, imageFileData.getTmParams());
		}
	}
	
	@RequestMapping(value = "getImageFileDetails", method = RequestMethod.GET,produces = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	public void getImageFileDetails( HttpServletRequest request,HttpServletResponse response, HttpSession session) {
		try {
			logger.debug("getImageFileDetails() from image file excel::Start");
			ImageFileData imageFileData = (ImageFileData) session.getAttribute("imageFileData");
			XSSFWorkbook imageFile = letterImageService.getLetterImageFile(imageFileData);
			response.setHeader("Content-Disposition", "attachment; filename=" + imageFileData.getExcelFileName());
			imageFile.write(response.getOutputStream());
			logger.debug("getImageFileDetails() from Wire Confirmation::END");
		} catch (Exception e) {

			logger.error("Unable to create lettters excel document");
			throw new CTracWebAppException("E0302", CtracErrorSeverity.APPLICATION);

		} finally {
			try {
				response.getOutputStream().close();
			} catch (IOException e) {
				logger.error("Failed to close response output stream");
				throw new CTracWebAppException("E0302", CtracErrorSeverity.APPLICATION);
			}
		}
	}

	@Transactional
	@RequestMapping(value = "/getImageFile", method = RequestMethod.GET,produces = "application/zip")
	public void getImageFile( HttpServletRequest request,HttpServletResponse response, HttpSession session) {

		try {
			logger.debug("getImageFileDocument() from image file ::Start");			
			
			ImageFileData imageFileData = (ImageFileData)session.getAttribute("imageFileData");	
		
			List<CollateralDocument> imageFiles =
					collateralDocumentRepository.findByFileNameAndDocIdentifier(imageFileData.getImageFileName(), CtracAppConstants.IMAGE_FILE_IDENTIFIER);
				
			if (imageFiles != null && !imageFiles.isEmpty()) {
				CollateralDocument imageFile = imageFiles.get(0);
				byte[] fileBytes = imageFile.getFileContent().getFileContent();
				response.setContentType("application/zip");				
				response.setContentLength(fileBytes.length);
				response.setHeader("Content-Disposition","attachment; filename=" + imageFile.getFileNameWithExt());
				response.getOutputStream().write(fileBytes);
			} else {
				logger.debug("getImageFile() from letter image : " + FileProcessingUtil.getPath( env.getRequiredProperty(GDS_IMAGE_ARCHIVE_OUTPUT_DIR)).getAbsolutePath() + ") path does not exist");
			}

			logger.debug("getImageFile() from letter image::END");
		} catch (Exception e) {			
			logger.error("Unable to stream letter image file");
			throw new CTracWebAppException("E0303", CtracErrorSeverity.APPLICATION);
		} finally {
			try {
				response.getOutputStream().close();
			} catch (IOException e) {
				logger.error("Failed to close response output stream");				
				throw new CTracWebAppException("E0303", CtracErrorSeverity.APPLICATION);
			}
		}
	}
	
	
}
