package com.jpmorgan.cib.wlt.ctrac.web.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import javapasswordsdk.PSDKPassword;
import javapasswordsdk.PSDKPasswordRequest;
import javapasswordsdk.PasswordSDK;
import javapasswordsdk.exceptions.PSDKException;

@Controller
public class PrototypeController extends BaseController{

	private static final Logger logger = Logger.getLogger(PrototypeController.class);

	@RequestMapping(value = "fiat-prototype", method = RequestMethod.GET)
	public String getCollateralDescription(HttpServletRequest request) {
		return "fiat-prototype/index";
	}
	
	@RequestMapping(value = "fiat-prototype/1", method = RequestMethod.GET)
	public String getCollateralDescription1(HttpServletRequest request) {
		return "fiat-prototype/1";
	}
	
	@RequestMapping(value = "fiat-prototype/1.1", method = RequestMethod.GET)
	public String getCollateralDescription1_1(HttpServletRequest request) {
		return "fiat-prototype/1.1";
	}
	
	@RequestMapping(value = "fiat-prototype/1.2", method = RequestMethod.GET)
	public String getCollateralDescription1_2(HttpServletRequest request) {
		return "fiat-prototype/1.2";
	}
	
	@RequestMapping(value = "fiat-prototype/3.1", method = RequestMethod.GET)
	public String getCollateralDescription3_1(HttpServletRequest request) {
		return "fiat-prototype/3.1";
	}
	
	@RequestMapping(value = "fiat-prototype/3.2", method = RequestMethod.GET)
	public String getCollateralDescription3_2(HttpServletRequest request) {
		return "fiat-prototype/3.2";
	}

	@RequestMapping(value = "fiat-prototype/3.3", method = RequestMethod.GET)
	public String getCollateralDescription3_3(HttpServletRequest request) {
		return "fiat-prototype/3.3";
	}
	
	@RequestMapping(value = "fiat-prototype/2.1", method = RequestMethod.GET)
	public String getCollateralDescription2_1(HttpServletRequest request) {
		return "fiat-prototype/2.1";
	}
	
	@RequestMapping(value = "fiat-prototype/2.2", method = RequestMethod.GET)
	public String getCollateralDescription2_2(HttpServletRequest request) {
		return "fiat-prototype/2.2";
	}
}
