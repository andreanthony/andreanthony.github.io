package com.jpmorgan.cib.wlt.ctrac.web.controller.generic;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/**
 * 
 * @author
 * The responsibility of this class is to simply display the 403( access denied) page
 *
 */
@Controller
public class AccessDeniedController{

	@Autowired
	private MessageSource messageSource;


	
	@Resource
	private Environment env;

	private static final Logger logger = Logger.getLogger(AccessDeniedController.class);
	
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public String display403(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
			logger.debug("display403 ::Start");
			return "generic/403";
	
	}

	
}
