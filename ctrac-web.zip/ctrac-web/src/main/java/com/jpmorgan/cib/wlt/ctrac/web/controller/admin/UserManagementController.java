package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.UserEntitlementAction;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracBaseException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.ManageUserEntitlementRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements.GetAvailableGroupsResponse;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements.GroupIdentifier;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.validator.UserEntitlementManagementValidator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * Rest controller for managing user entitlements (Add / Update / Delete / Disable)
 */
@RestController
@RequestMapping(value = "admin/entitlements")
public class UserManagementController {

    private static final Logger LOG = Logger.getLogger(UserManagementController.class);
    @Autowired private UserEntitlementService userEntitlementService;
    @Autowired private UserEntitlementManagementValidator userEntitlementManagementValidator;

    @Secured({EntitlementRoles.EAA_WRITER_ROLE,EntitlementRoles.ADMIN_ROLE,
            EntitlementRoles.OPERATE_WRITERS})
    @RequestMapping(value = "groups",method = RequestMethod.GET)
    public ResponseEntity<BaseApiResponse> getAllAvailableUserGroups(){
        LOG.debug("getAvailableUserGroups:::START");
        try{
            List<GroupIdentifier> groups = userEntitlementService.getAllAvailableUserGroups();
            return new ResponseEntity<BaseApiResponse>(new GetAvailableGroupsResponse(groups), HttpStatus.OK);
        }catch(Exception e){
            LOG.error(e.getMessage(),e);
            return new ResponseEntity<>(new BaseApiResponse(e,null), HttpStatus.BAD_REQUEST);
        }
    }

    @Secured({EntitlementRoles.EAA_WRITER_ROLE})
    @RequestMapping(value = "user/{sid}/update",method = RequestMethod.POST)
    public ResponseEntity<BaseApiResponse> updateUser(@Valid @ModelAttribute("userEntitlementRequest") ManageUserEntitlementRequest request,
                                                      BindingResult modelBinding,@PathVariable String sid){
        LOG.debug("updateUser:::START ,user:" + sid);
        request.setSid(sid);
        return performEntitlementAction(request,modelBinding,UserEntitlementAction.UPDATE);
    }

    @Secured({EntitlementRoles.EAA_WRITER_ROLE})  
    @RequestMapping(value = "user/{sid}/add",method = RequestMethod.POST)
    public ResponseEntity<BaseApiResponse> addUser(@Valid @ModelAttribute("userEntitlementRequest") ManageUserEntitlementRequest request,
                                                      BindingResult modelBinding,@PathVariable String sid){
        LOG.debug("addUser:::START ,user:" + sid);
        request.setSid(sid);
        return performEntitlementAction(request,modelBinding,UserEntitlementAction.ADD);
    }

    @Secured({EntitlementRoles.EAA_WRITER_ROLE})
    @RequestMapping(value = "user/{sid}/delete",method = RequestMethod.POST)
    public ResponseEntity<BaseApiResponse> deleteUser(@Valid @ModelAttribute("userEntitlementRequest") ManageUserEntitlementRequest request,
                                                   BindingResult modelBinding,@PathVariable String sid){
        LOG.debug("deleteUser:::START ,user:" + sid);
        request.setSid(sid);
        return performEntitlementAction(request,modelBinding,UserEntitlementAction.DELETE);
    }

    @Secured({EntitlementRoles.EAA_WRITER_ROLE})
    @RequestMapping(value = "user/{sid}/disable",method = RequestMethod.POST)
    public ResponseEntity<BaseApiResponse> disableUser(@Valid @ModelAttribute("userEntitlementRequest") ManageUserEntitlementRequest request,
                                                      BindingResult modelBinding,@PathVariable String sid){
        LOG.debug("disableUser:::START ,user:" + sid);
        request.setSid(sid);
        return performEntitlementAction(request,modelBinding,UserEntitlementAction.DISABLE);
    }

    /**
     * Common method to validate a manage user entitlement request and call service
     * with expected params and handle any Exceptions that may have occurred
     * @param request - ManageUserEntitlementRequest instance
     * @param bindingResult - Spring binding result of the ManageUserEntitlementRequest model
     * @param action - The action to perform for the user entitlements
     * @return
     */
    private ResponseEntity<BaseApiResponse> performEntitlementAction(ManageUserEntitlementRequest request,
                                                                         BindingResult bindingResult, UserEntitlementAction action){
        try{
            userEntitlementManagementValidator.
                    validateUserEntitlementRequest(request, action, bindingResult);
            if(!bindingResult.hasErrors()){
                userEntitlementService.processUserEntitlementRequest(request,action);
                return new ResponseEntity<>(new BaseApiResponse(), HttpStatus.OK);
            }
            return new ResponseEntity<>(new BaseApiResponse(bindingResult,null)
                    , HttpStatus.BAD_REQUEST);
        }catch(CTracBaseException e){
            //Handle the CTRAC exceptions which contains localised error messaging
            LOG.error(e.getErrorMessage(),e);
            return new ResponseEntity<>(new BaseApiResponse(e,e.getErrorMessage()), HttpStatus.BAD_REQUEST);
        }catch(Exception e){
            LOG.error(e.getMessage(),e);
            return new ResponseEntity<>(new BaseApiResponse(e,null), HttpStatus.BAD_REQUEST);
        }
    }
}
