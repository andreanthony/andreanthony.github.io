package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_INSURANCE_SEND_LENDER_PLACE_CANCELLATION_EMAIL_SCREEN_ID;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_INSURANCE_SEND_LENDER_PLACE_EMAIL_SCREEN_ID;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_REMAP_RENWAL_SEND_BANKER_EMAIL_SCREEN_ID;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_REMAP_SEND_MARKET_REFUND_EMAIL_SCREEN_ID;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationUtils;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.GenericEmailData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.GenericScreenProperties;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
//import com.jpmorgan.cib.wlt.ctrac.validator.FloodRemapTaskValidator;
//import com.jpmorgan.cib.wlt.ctrac.service.FloodInsurancePolicyService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

/**
 * Controller to prepare lob email helper page to send an email to market [i.e LP Premium Paid] 
 * @author v589461
 */
@Controller
@SessionAttributes({ "floodRemapSendEmailData","tmParams"})
public class SendEmailNotifcationController extends BaseController  {
	
	private static final Logger logger = Logger.getLogger(SendEmailNotifcationController.class);
	
//	@Autowired
//	@Qualifier("floodInsurancePolicyService")
//	private FloodInsurancePolicyService floodInsurancePolicyService;
	
	@Autowired
	private LenderPlaceService lenderPlaceService;
	
	@Autowired
	@Qualifier("floodRemapService")
	FloodRemapService floodRemapService;
	
//	@Autowired
//	private FloodRemapTaskValidator floodRemapTaskValidator;
//	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	@Qualifier("emailAttachmentsBucket")
	EmailAttachmentsBucket emailAttachmentsBucket;
	
	/**
	 * Controller method to invoke the CTRAC LP Premium paid helper page
	 * @param request HttpServletRequest
	 * @param model ModelMap
	 * @param tmParams.id_task String
	 * @param tmParams.tmReturn String
	 * @param tmParams.workflowStep String
	 * @return String
	 */
	@RequestMapping(value = "/floodRemap/launchSendMarketRefundEmailHelper", method = RequestMethod.GET)
	public String launchSendMarketRefundEmailHelper(HttpServletRequest request, ModelMap model,@ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchSendMarketRefundEmailHelper start()");		
		GenericScreenProperties screenProperties = new GenericScreenProperties( 
											  "floodRemapReadOnlyEmail",//pageUrl
											  FLOOD_REMAP_SEND_MARKET_REFUND_EMAIL_SCREEN_ID,//screenID
											  "Send Market Refund Email",//pageTitle
											  "/floodRemap/sendMarketRefundEmail"//actionUrl
				);
		return prepareLaunchEmailNotification(request, model, tmParams, screenProperties);
	}
	
	@RequestMapping(value = "/floodInsurance/launchSendBankerEmailHelper", method = RequestMethod.GET)
	public String launchSendBankerEmailHelper(HttpServletRequest request, ModelMap model,@ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchSendBankerEmailHelper start()");	
		GenericScreenProperties screenProperties = new GenericScreenProperties( 
											  "floodRemapReadOnlyEmail",//pageUrl
											  FLOOD_REMAP_RENWAL_SEND_BANKER_EMAIL_SCREEN_ID,//screenID
											  "Flood Remap - Send Banker Email",//pageTitle
											  "/floodInsurance/sendBankerEmail"//actionUrl
				);
		return prepareLaunchEmailNotification(request, model, tmParams, screenProperties);
	}
	
	@RequestMapping(value = "/floodInsurance/launchSendLenderPlacedEmailLOBHelper", method = RequestMethod.GET)
	public String launchSendLenderPlaceEmailHelper(HttpServletRequest request, ModelMap model,@ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchSendLenderPlaceEmailHelper start()");	
		GenericScreenProperties screenProperties = new GenericScreenProperties( 
											  "floodRemapReadOnlyEmail",//pageUrl
											  FLOOD_INSURANCE_SEND_LENDER_PLACE_EMAIL_SCREEN_ID,//screenID
											  "Flood Insurance - Market Email LP Notification",//pageTitle
											  "/floodInsurance/sendLenderPlacedLOBEmail"//actionUrl
				);
		return prepareLaunchEmailNotification(request, model, tmParams, screenProperties);
	}
	
	@RequestMapping(value = "/floodInsurance/launchSendLenderPlacedCancellationEmailLOBHelper", method = RequestMethod.GET)
	public String launchSendLenderPlaceCancellationEmailHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("launchSendLenderPlacedCancellationEmailLOBHelper start()");	
		GenericScreenProperties screenProperties = new GenericScreenProperties( 
											  "floodInsuranceMarketLPCancellationEmail",//pageUrl
											  FLOOD_INSURANCE_SEND_LENDER_PLACE_CANCELLATION_EMAIL_SCREEN_ID,//screenID
											  "Flood Insurance - Market Email LP Cancellation",//pageTitle
											  "/floodInsurance/sendLenderPlacedCancellationLOBEmail"//actionUrl
				);
		return prepareLaunchEmailNotification(request, model, tmParams, screenProperties);
	}
	
	private String prepareLaunchEmailNotification(HttpServletRequest request,
			ModelMap model, TMParams tmParams, GenericScreenProperties screenProperties) {
		logger.debug("prepareLaunchEmailNotification start()");
		if (tmParams.getId_task() != null) {
			try {				
				GenericEmailData floodRemapSendEmailData=null;
				if(FLOOD_REMAP_SEND_MARKET_REFUND_EMAIL_SCREEN_ID.equalsIgnoreCase(screenProperties.getScreenID())){
					floodRemapSendEmailData=lenderPlaceService.prepareSendMarketRefundEmail(tmParams);
					floodRemapSendEmailData.setScreenId(screenProperties.getScreenID());
					floodRemapSendEmailData.setPageTitle(ApplicationUtils.setScreenTitle(floodRemapSendEmailData.getTmTaskType())+" - "+screenProperties.getPageTitle());
					floodRemapSendEmailData.setSendEmailUrl(screenProperties.getActionUrl());
				}
				model.addAttribute("floodRemapSendEmailData", floodRemapSendEmailData);
				return screenProperties.getPageUrl() ;
			} catch(Exception e) {
				logger.error("Error while preparing:  "+screenProperties.getPageTitle()+"  " + e.getMessage(), e);				
				throw new CTracWebAppException("E0171", CtracErrorSeverity.APPLICATION);
			} finally {
				logger.debug("prepareLaunchEmailNotification end()");	
			}
		} else {
			logger.error("Received Task UUID from TM is null");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION);
		}
	}
	
	/**		
	 * PBI LCP 630 - New method added. 
	 * This controller method will be called on click of send email button from Send Market Refund Email Screen. This will be responsible to -
	 * 1. Call service method to prepare email template and send email.
	 * 2. Save task events and complete the task.
	 */
	@RequestMapping(value = "/floodRemap/sendMarketRefundEmail", method = RequestMethod.POST, params = { "save" })
	public ModelAndView sendMarketRefundEmail(@ModelAttribute("floodRemapSendEmailData") GenericEmailData floodRemapSendEmailData, 
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {	
		
		logger.debug("sendMarketRefundEmail()::Start");		
		return processEmailNotification(floodRemapSendEmailData, binding, request);
	}

	@RequestMapping(value = "/floodInsurance/sendBankerEmail", method = RequestMethod.POST, params = { "save" })
	public ModelAndView sendBankerEmail(@ModelAttribute("floodRemapSendEmailData") GenericEmailData floodRemapSendEmailData, 
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {	
		
		return processEmailNotification(floodRemapSendEmailData, binding, request);
	}
	
	@RequestMapping(value = "/floodInsurance/sendLenderPlacedLOBEmail", method = RequestMethod.POST, params = { "save" })
	public ModelAndView sendLenderPlacedLOBEmail(@ModelAttribute("floodRemapSendEmailData") GenericEmailData floodRemapSendEmailData, 
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {	
		
		return processEmailNotification(floodRemapSendEmailData, binding, request);
	}
	
	@RequestMapping(value = "/floodInsurance/sendLenderPlacedCancellationLOBEmail", method = RequestMethod.POST, params = { "save" })
	public ModelAndView sendLenderPlacedCancellationLOBEmail(@ModelAttribute("floodRemapSendEmailData") GenericEmailData floodRemapSendEmailData, 
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {	
		
		return processEmailNotification(floodRemapSendEmailData, binding, request);
	}
	
	private ModelAndView processEmailNotification( GenericEmailData floodRemapSendEmailData, BindingResult binding, HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView();
		if(floodRemapSendEmailData.getTmParams() == null){
			logger.error("Received TM params are null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		
		populateTaskEmailAttachment(floodRemapSendEmailData);
		
		//floodRemapTaskValidator.validate(floodRemapSendEmailData, binding);
        try{
		if (binding.hasErrors()) {
			modelAndView.addObject("floodRemapSendEmailData", floodRemapSendEmailData);
			modelAndView.setViewName("floodRemapReadOnlyEmail");
			return modelAndView;
		} else {
			
			// PBI LCP 630 - call to service method added by AB - 6/15/2015
			// This method handles Send Banker Email feature as well - updated as part of LCP 1120 - 8/12/2015
			// This method handles  Send LOB Email for Lender Placed - updated as part of LCP 680 - 10/13/2015
			//floodInsurancePolicyService.processSendMarketRefundEmail(floodRemapSendEmailData);
			lenderPlaceService.processSendMarketRefundEmail(floodRemapSendEmailData);
			modelAndView.addObject("confirmation", messageSource.getMessage("sendemail.save.confirmation", null, null));
			modelAndView.setViewName("floodRemapConfirmation"); 
		}		
		return modelAndView;
        }
        catch(Exception e){
        	logger.error(e.getMessage());
			throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, floodRemapSendEmailData.getTmParams());
        }
	}
	
void populateTaskEmailAttachment(GenericEmailData floodRemapSendEmailData) {
		
		EmailAttachments attachments = emailAttachmentsBucket.popEmailAttachments(floodRemapSendEmailData.getTmParams().getId_task());
		
		if(attachments == null){
			attachments = new EmailAttachments(floodRemapSendEmailData.getTmParams().getId_task());
		}
		
		List<MultipartFile> files = attachments.getAllFilesAsList();
		floodRemapSendEmailData.setFiles(files);
		floodRemapSendEmailData.getEmailAttributeHolder().setFiles(files);
		
		
	}
}
