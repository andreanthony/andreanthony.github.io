package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_INSURANCE_VERIFY_VENDOR_CANCELATION_LETTER;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_REMAP_VERIFY_VENDOR_INSURANCE;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.GenericScreenProperties;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VerifyLetterData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

@Controller
@SessionAttributes({"floodRemapResearchData", "floodRemapVendorInsuranceData","tmParams"})
public class FloodRemapVendorInsuranceController extends BaseController {

	private static final Logger logger = Logger.getLogger(FloodRemapVendorInsuranceController.class);

	@Autowired
	@Qualifier("lenderPlaceService")
	LenderPlaceService lenderPlaceService;

	@Autowired
	private MessageSource messageSource;
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	    dateFormat.setLenient(false);
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value = "/floodRemap/launchVerifyVendorInsuranceHelper", method = RequestMethod.GET)
	public String launchVerifyVendorInsuranceHelper(HttpServletRequest request, ModelMap model,  @ModelAttribute("tmParams") TMParams tmParams) {
		GenericScreenProperties details = new GenericScreenProperties(
				"floodRemapVerifyVendorInsuranceInfo",
				FLOOD_REMAP_VERIFY_VENDOR_INSURANCE,
				"Flood Remap - Verify Vendor Insurance Info",
				"/submitVerificationOfLetter/");
		return processLaunchVerifyLetter(request, model, tmParams, details);
	}
	
	
	@RequestMapping(value = "/floodInsurance/launchVerifyVendorCancellationHelper", method = RequestMethod.GET)
	public String launchVerifyVendorCancellationHelper(HttpServletRequest request, ModelMap model, @ModelAttribute("tmParams") TMParams tmParams) {
		GenericScreenProperties details = new  GenericScreenProperties(
				"floodRemapVerifyVendorInsuranceInfo",
				FLOOD_INSURANCE_VERIFY_VENDOR_CANCELATION_LETTER,
				"Verify Vendor Insurance Cancellation Letter",
				"/submitVerificationOfLetter/");
		return processLaunchVerifyLetter(request, model, tmParams, details);
	}


	private String processLaunchVerifyLetter(HttpServletRequest request, ModelMap model,  @ModelAttribute("tmParams") TMParams tmParams, GenericScreenProperties details) {
		try{
			logger.debug("launchVerifyVendorInsuranceHelper()::Start");
			String strConfirmHelperPage = checkTaskInReviewStatus(model,tmParams);
			if(strConfirmHelperPage != null && strConfirmHelperPage.equalsIgnoreCase("")){
				VerifyLetterData policyVendorInsuranceData = lenderPlaceService.preparePolicyVerifyLetterDates(tmParams);
				policyVendorInsuranceData.setScreenTitle(details.getPageTitle());
				model.addAttribute("floodRemapVendorInsuranceData", policyVendorInsuranceData);
				logger.debug(" "+details.getScreenID()+"()::End");
				return details.getPageUrl();
			} else {
				return strConfirmHelperPage;
			}			
		}
		catch(Exception e) {			
			logger.error(e.getMessage());
			throw new CTracWebAppException("E0242", CtracErrorSeverity.CRITICAL, tmParams);		
		}
	}
	
	
	

	@RequestMapping(value = "/floodRemap/submitVerificationOfLetter/{taskId}", method = RequestMethod.POST)
	public ModelAndView recordVendorInsuranceDateofLetter(@ModelAttribute("floodRemapVendorInsuranceData") VerifyLetterData floodRemapVendorInsuranceData, @PathVariable String taskId, 
			ModelMap model, BindingResult binding, SessionStatus sessionStatus, HttpServletRequest request) {

		if(floodRemapVendorInsuranceData.getTmParams() == null){
			logger.error("Received TM params is null");
			throw new CTracWebAppException("E0189", CtracErrorSeverity.APPLICATION);
		}
		
		try {
			logger.debug("recordVendorInsuranceDateofLetter()::Start");
			
			ModelAndView modelAndView = new ModelAndView();
			
			if (!binding.hasErrors()) {
			
				TMParams tmParams = floodRemapVendorInsuranceData.getTmParams();
				
				logger.debug("New Transaction ID::"+ tmParams.getTmTransactionId());
				
				lenderPlaceService.processSaveDateOfLetter(floodRemapVendorInsuranceData, request);

				modelAndView.addObject("confirmation", messageSource.getMessage("vendor.insurance.submit.confirmation", null, null));
				modelAndView.setViewName("floodRemapConfirmation");   
				
				logger.debug("saveFirstVendorInsurance()::End");

				return modelAndView;
			}
			else {
				modelAndView.setViewName("floodRemapVerifyVendorInsuranceInfo");
				modelAndView.addObject("floodRemapVendorInsuranceData", floodRemapVendorInsuranceData);
				logger.debug("recordVendorInsuranceDateofLetter()::validationFailure");
				return modelAndView;
			}
		}
		catch(Exception e){
			logger.error(e.getMessage());
			throw new CTracWebAppException("E0243", CtracErrorSeverity.APPLICATION, floodRemapVendorInsuranceData.getTmParams());
		}
	}	

}
