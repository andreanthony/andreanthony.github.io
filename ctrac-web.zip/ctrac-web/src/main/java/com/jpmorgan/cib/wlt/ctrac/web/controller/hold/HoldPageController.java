package com.jpmorgan.cib.wlt.ctrac.web.controller.hold;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/hold")
public class HoldPageController {

    @Secured({ EntitlementRoles.READER_ROLE})
    @RequestMapping(value = "history", method = RequestMethod.GET)
    public ModelAndView loadHoldHistoryPage() {
            return new ModelAndView("/hold/holdHistory");
    }

}
