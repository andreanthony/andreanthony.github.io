package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralDetailsSection;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.datatable.EntityDataTableDto;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;

@Controller
@SessionAttributes({ "searchCollateralData", "collateralDetailsData", "ownerData", "referenceValues" })
public class CollateralOwnerController {

	private static final Logger logger = Logger.getLogger(CollateralOwnerController.class);

	@Resource
	private Environment env;

	@Autowired
	@Qualifier("emailAttachmentsBucket")
	EmailAttachmentsBucket emailAttachmentsBucket;
	
	@Autowired
	private CollateralDetailsService collateralDetailsService;
	
	@RequestMapping(value = "admin/searchCustomer", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
	@Secured({EntitlementRoles.READER_ROLE})
	public String searchCustomers(HttpServletRequest request,
			HttpServletResponse response, ModelMap model, HttpSession session) {
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		response.addHeader("X-UA-Compatible", "IE=edge");
		try {
			logger.debug("searchCustomers::BEGIN");
			EntityDataTableDto searchCustomerData = new EntityDataTableDto();
			model.addAttribute("searchCustomerData", searchCustomerData);
			model.remove("errMsgServerSide");
			logger.debug("searchCustomers::END");
			return "admin/searchCustomer";
		} catch (Exception e) {
			logger.error("Unable to launch launchSearchCollateral");
			throw new CTracWebAppException("E0193", CtracErrorSeverity.APPLICATION);
		}
	}
	
	
	@RequestMapping(value = "admin/addCustomer", method = RequestMethod.POST, produces = MediaType.TEXT_HTML_VALUE)
    public String launchSearchCustomer(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
            @RequestParam("ownerRid") String ownerRid, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request,
            HttpServletResponse response) {
        logger.debug("launchCollateralOwner::BEGIN");
        try {
            collateralDetailsService.addExistingCollateralOwner(collateralDetailsMainDto , Long.valueOf(ownerRid));
            logger.debug("saveCollateralOwner::END ");
        } catch (Exception e) {
        	String defaultMsg="Save collateral owner failed: Some system error occured: Please try again or contact the feature team ";
            handleRemoteException(defaultMsg, e, collateralDetailsMainDto);
        }
        logger.debug("launchCollateralOwner::END");
        return "admin/collateralDetailsSection :: collateralDetailsSection";
    }

	
	@Secured({EntitlementRoles.READER_ROLE})
    @RequestMapping(value = "admin/editCollateralOwner", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ModelAndView launchCollateralOwner(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
            @RequestParam("ownerRid") Long ownerRid, ModelMap model, SessionStatus sessionStatus, HttpServletRequest request,
            HttpServletResponse response) {
        logger.debug("launchCollateralOwner::BEGIN");
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        response.addHeader("X-UA-Compatible", "IE=edge");
       
        if (ownerRid != null && ownerRid != 0) {
        	for (CustomerData customerData: collateralDetailsMainDto.getCollateralDto().getOwnerData()) {
        		if (customerData.getRid().compareTo(ownerRid) == 0) {
        			model.addAttribute("ownerData", customerData);
        			break;
        		}
        	}
        } else {
        	CustomerData customerData = new CustomerData();
        	collateralDetailsMainDto.getCollateralDto().getOwnerData().add(customerData);
        			
        	model.addAttribute("ownerData", customerData);

        }

        model.addAttribute("collateralDetailsMainDto",collateralDetailsMainDto);
        logger.debug("launchCollateralOwner::END");
        return new ModelAndView("collateralOwnerModal", model);
    }

    @RequestMapping(value = "admin/saveCollateralOwner", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BaseApiResponse> saveCollateralOwner(@Valid @ModelAttribute("ownerData") CustomerData ownerData,BindingResult errors,
															   @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto
											  ) {
        logger.debug("saveCollateralOwner::BEGIN");
        try {
        	if(!errors.hasErrors()){
				collateralDetailsService.saveCollateralSectionInfo(collateralDetailsMainDto, CollateralScreenAction.EDIT);
			}
            logger.debug("saveCollateralOwner::END ");
        } catch (Exception e) {
        	String defaultMsg="Save collateral owner failed: Some system error occured: Please try again or contact the feature team ";
            handleRemoteException(defaultMsg, e, collateralDetailsMainDto);
        }
        BaseApiResponse apiResponse = new BaseApiResponse(errors, StringUtils.EMPTY);
        return new ResponseEntity<>(apiResponse,errors.hasErrors()? HttpStatus.BAD_REQUEST:HttpStatus.OK);
    }

    @RequestMapping(value = "admin/deleteCollateralOwner", method = RequestMethod.POST, produces = MediaType.TEXT_HTML_VALUE)
    public String deleteCollateralOwner(@ModelAttribute("ownerData") CustomerData ownerData,
            @ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto) {
        logger.debug("deleteCollateralOwner::BEGIN");
        try {
        	if(!collateralDetailsMainDto.getCollateralDto().hasMultipleOwners()) {
				throw new CtracException("Delete collateral owner Not allowed since collateral contains a single owner");
			}
			else {
				CollateralDto collateralDto = collateralDetailsService.removeCollateralOwner(collateralDetailsMainDto, ownerData);
				// set session variable if there is no exception during db save
				collateralDetailsMainDto.setCollateralDto(collateralDto);
			}
            logger.debug("deleteCollateralOwner::END ");
        } catch (Exception e) {
        	String defaultMsg="Delete collateral owner failed: Some system error occured: Please try again or contact the feature team ";
            handleRemoteException(defaultMsg, e, collateralDetailsMainDto);
        }
        return "admin/collateralDetailsSection :: collateralDetailsSection";
    }
    
	 // TODO push into a utility methods
    private void handleRemoteException(String defaultUserMessage, Throwable e, CollateralDetailsMainDto collateralDetailsMainDto) {
    	logger.error("Data access exception occured : ", e);
    	collateralDetailsMainDto.setDisplayMsg(defaultUserMessage);
    	if (e instanceof JpaSystemException) {
    		Throwable errorCause = ((JpaSystemException) e).getMostSpecificCause();
    		if (errorCause != null && errorCause.toString().contains("CONCURRENT MODIFICATION OF DATA")) {
    			collateralDetailsMainDto
    				.setDisplayMsg("the collateral informations was updated by a different user since loaded; please review the most up to date information");
    		}
    	}
    	throw new CtracAjaxException(e);
    }

}
