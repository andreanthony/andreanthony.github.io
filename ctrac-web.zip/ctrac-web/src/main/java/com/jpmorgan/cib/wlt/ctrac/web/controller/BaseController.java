package com.jpmorgan.cib.wlt.ctrac.web.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.ui.ModelMap;

import com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.TMServiceApplicationException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.UsersRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.TMService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMConstants;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import com.jpmorgan.cib.wlt.tm.client.dto.LockedTaskDto;
import com.jpmorgan.cib.wlt.tm.client.dto.Status;
import com.jpmorgan.cib.wlt.tm.client.dto.UserInformationDto;

public class BaseController  {

	private static final Logger logger = Logger.getLogger(BaseController.class);

	@Autowired private UsersRepository usersRepository;
	@Autowired private LenderPlaceService lenderPlaceService;
	@Autowired MessageSource messageSource;
	@Autowired private CtracAuthenticationManager ctracAuthenticationManager;
	@Autowired private TMService tmService;
	@Value("${janus.api.sso.account}")
	private String functionalUserId;

	public void unLockTMTask(TMParams tmParams, HttpServletRequest request) {
		logger.debug("unLockTMTask()::Start");
		try {
			if (tmParams != null) {
				
				/* unlock the task in TM */
				Cookie[] janusCookies = ctracAuthenticationManager.getJanusAuthenicationAndCookies();
				Users user = usersRepository.findBySidIgnoreCase(tmParams.getUserId());
				String fullName = String.format("%s %s", user.getFirstName(), user.getLastName());
				LockedTaskDto lockedTaskDto = TMUtility.buildLockedTaskDto(tmParams,fullName);
				Status status = tmService.unlockTask(lockedTaskDto, new UserInformationDto(tmParams.getUserId(),tmParams.getUserId(),janusCookies));
				if (status.getStatus().name().equalsIgnoreCase("SUCCESS")) {
					logger.debug("Flood remap task unlock completed");
				} else {
					logger.debug("Flood remap task unlock failed");
					throw new CTracWebAppException("E0105", CtracErrorSeverity.APPLICATION);
				}
				logger.debug("unLockTMTask()::End");
			}
		} catch (TMServiceApplicationException ex) {
			logger.error(ex.getMessage());
		}catch (Exception ex) {
			logger.error(ex.getMessage());
		}
	}
	
	/**
	 * Method to check whether the task in 'InReview' status
	 * if true - then return 'floodRemapConfirmation' else "".
	 * @param model
	 * @param tmParams
	 * @return
	 */
	//TODO: revisit to enable when it is needed
	public String checkTaskInReviewStatus(ModelMap model,TMParams tmParams) {
		String strViewName = "";
		if(isInInsuranceReview(tmParams)) { // TODO redirect to display confirmation with redirect attributes
			model.addAttribute("confirmation",messageSource.getMessage("task.inborrowerreview.confirmation", null, null));
			strViewName = "floodRemapConfirmation";
		}		
		return strViewName;
	}

	// create protected method to check if policy is in insurance review

	private boolean isInInsuranceReview(TMParams tmParams) {
		return lenderPlaceService.isPolicyInInsuranceReview(tmParams.getId_task());
	}

	/**
	 * Abstract method to lock a given TM task and store its transaction ID into the TM Params
	 * @param request
	 * @param tmParams
	 * 
	 * @return
	 */
	protected void lockTMTask(HttpServletRequest request,TMParams tmParams){
		logger.debug("id_task:" + tmParams.getId_task() + "  workflowStep:" + tmParams.getWorkflowStep());
		String id_user = ctracAuthenticationManager.getJanusUserCredentials(request);
		logger.debug("Login user SID:" + id_user);
		String janusUserId = TMUtility.getJanusUserId(id_user, functionalUserId);
		tmParams.setUserId(janusUserId);
		HttpSession session = request.getSession();
		
		
		Status status = null;
		try {
			Cookie[] janusCookies = ctracAuthenticationManager.getJanusAuthenicationAndCookies();
			Users user = usersRepository.findBySidIgnoreCase(janusUserId);
			String fullName = String.format("%s %s", user.getFirstName(), user.getLastName());
			UserInformationDto userInformationDto = new UserInformationDto(janusUserId,fullName,janusCookies);
			LockedTaskDto lockedTaskDto = TMUtility.buildLockedTaskDto(tmParams,fullName);
			status = tmService.lockTask(lockedTaskDto,userInformationDto);
			
			if (status.getStatus().name().equalsIgnoreCase(TMConstants.ERROR)) {
				logger.debug("Error in Locking task ID From TM Message : "+status.getMessage());
				lockedTaskDto.setIsForceUnLock(true);
				status = tmService.unlockTask(lockedTaskDto,  userInformationDto);
				if(status.getStatus().name().equalsIgnoreCase(TMConstants.SUCCESS)){
					status = tmService.lockTask(lockedTaskDto, userInformationDto);
					logger.debug("Task Locked successfully Task ID Transaction ID : " + (status!=null? status.getTransactionId(): null));
					tmParams.setUserId(janusUserId);
				}
			}
			tmParams.setUserId(janusUserId);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}
		logger.debug("Task Locked successfully Task ID  Transaction ID : " + (status!=null? status.getTransactionId(): null));
		tmParams.setTmTransactionId((status!=null? status.getTransactionId(): null));
		session.setAttribute("tmParams", tmParams);
	}

}
