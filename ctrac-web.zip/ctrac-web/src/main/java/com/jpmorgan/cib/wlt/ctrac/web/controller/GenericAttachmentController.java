package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.itextpdf.text.exceptions.InvalidPdfException;
import com.itextpdf.text.pdf.PdfReader;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FileContent;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.WireRequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AccountWireReferenceDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapResearchDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.FloodDeterminationDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.InsurancePolicyRequirementDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@Controller
@SessionAttributes({ "floodRemapResearchDto","floodRemapSendEmailData","proofOfCoverageData", "insurancePolicyRequirementDto","floodRemapCoverageInputData","wireRequestData","borrowerInsuranceReviewData","floodRemapRecordCollateralInfoData","collateralDetailsData","floodHazardDeterminationDto","borrowerInsuranceReviewData"})
@Transactional(readOnly = true)
public class GenericAttachmentController extends BaseController {

	private static final Logger logger = Logger.getLogger(GenericAttachmentController.class);
	
	@Autowired
	private CollateralDocumentRepository collateralDocumentRepository;
	
	@Autowired @Qualifier("wireProcessingService")
	WireProcessingService wireProcessingService;

	@RequestMapping(value="/collateralDetails/getMortgageDocument/{index}",method=RequestMethod.GET,produces="application/pdf")
	public void getMortgageDocumentForCollateral(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsData , HttpServletRequest request , HttpServletResponse response , @PathVariable int index){
		logger.debug("getMortgageDocumentForCollateral():: Start");
		try {
			CollateralDoc mortgageDocument = collateralDetailsData.getCollateralSectionDto().getMortgageDocs().get(index);
			streamCollateralDocument(mortgageDocument, response);
		} catch (Exception e) {
			logger.error("Error streaming mortgage document for collateral ID=" + collateralDetailsData.getCollateralDto().getRid() + ", index=" + index);
			throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
		}
		logger.debug("getMortgageDocumentForCollateral() :: End");
	}

	@RequestMapping(value="/collateralDetails/streamFiatDocuments/{docRid}",method=RequestMethod.GET,produces="application/pdf")
	public void streamFiatDocuments(@ModelAttribute("insurancePolicyRequirementDto") InsurancePolicyRequirementDto insurancePolicyRequirementDto , HttpServletRequest request , HttpServletResponse response, @PathVariable Long docRid ){
		logger.debug("streamFiatDocuments():: Start");
		try {
			CollateralDocument fiatDocument = collateralDocumentRepository.findOne(docRid);
			streamCollateralDocument(fiatDocument, response);
		} catch (Exception e) {
			logger.error("Error streaming FIAT: source document ID=" + insurancePolicyRequirementDto.getRequiredCoverageSourceDto().getRid() );
			throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
		}
		logger.debug("streamFiatDocuments() :: End");
	}
	
	@RequestMapping(value="/collateralDetails/streamFloodDeterminationDocuments/",method=RequestMethod.GET,produces="application/pdf")
	public void streamFloodDeterminationDocuments(@ModelAttribute("floodHazardDeterminationDto") FloodDeterminationDto floodHazardDeterminationDto , HttpServletRequest request , HttpServletResponse response ){
		logger.debug("streamFloodDeterminationDocuments():: Start");
		try {
			CollateralDocument floodDocument =
					collateralDocumentRepository.findOne(floodHazardDeterminationDto.getDeterminationDocument().getDocRid());
			streamCollateralDocument(floodDocument, response);
		} catch (Exception e) {
			logger.error("Error streaming Flood Determination document ID=" + floodHazardDeterminationDto.getDeterminationDocument().getDocRid());
			throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
		}
		logger.debug("streamFloodDeterminationDocuments() :: End");
	}
	
	@RequestMapping(value="/admin/getInsuranceDocument/{index}",method=RequestMethod.GET,produces="application/pdf")
	public void getInsuranceDocument(@ModelAttribute("proofOfCoverageData") ProofOfCoverageDTO proofOfCoverageData, HttpServletRequest request, HttpServletResponse response, @PathVariable int index) {
		logger.debug("getMortgageDocumentForCollateral():: Start");
		try {
			CollateralDocument insuranceDocument = proofOfCoverageData.getPolicyDocuments().get(index);
			streamCollateralDocument(insuranceDocument, response);
		} catch (Exception e) {
			logger.error("Error streaming insurance document with rid=" + proofOfCoverageData.getRid() + ", index=" + index);
			throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
		}
		logger.debug("getMortgageDocumentForCollateral() :: End");
	}
	
	@RequestMapping(value="/admin/getBorrowerInsuranceDocument/{index}",method=RequestMethod.GET,produces="application/pdf")
	public void getInsuranceDocument(@ModelAttribute("borrowerInsuranceReviewData") BorrowerInsuranceReviewDTO borrowerInsuranceReviewData, HttpServletRequest request, HttpServletResponse response, @PathVariable int index) {
		logger.debug("getMortgageDocumentForCollateral():: Start");
		try {
			CollateralDocument insuranceDocument = borrowerInsuranceReviewData.getProofOfCoverageData().getPolicyDocuments().get(index);
			streamCollateralDocument(insuranceDocument, response);
		} catch (Exception e) {
			logger.error("Error streaming insurance document with rid=" + borrowerInsuranceReviewData.getRid() + ", index=" + index);
			throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
		}
		logger.debug("getMortgageDocumentForCollateral() :: End");
	}
	
	
	@RequestMapping(value="/researchItem/streamSFHDF",method=RequestMethod.GET,produces="application/pdf")
	public void streamFloodDeterminationDocuments(@ModelAttribute("floodRemapResearchDto") FloodRemapResearchDto floodRemapResearchDto , HttpServletRequest request , HttpServletResponse response ){
		logger.debug("streamFloodDeterminationDocuments():: Start");
		try {
			streamCollateralDocument(floodRemapResearchDto.getSFHDF().getName(), floodRemapResearchDto.getSFHDF().getBytes(),  response);
		} catch (Exception e) {
			logger.error("Error streaming Flood Determination document name=" + floodRemapResearchDto.getSFHDF().getName());
			throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
		}
		logger.debug("streamFloodDeterminationDocuments() :: End");
	}
	
	@RequestMapping(value="/getCollateralDocument",method=RequestMethod.GET,produces="application/pdf")
	public void getInsuranceDocument(@RequestParam("collateralDocumentRid") Long collateralDocumentRid, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("getMortgageDocumentForCollateral():: Start");
		try {
			CollateralDocument insuranceDocument = collateralDocumentRepository.findOne(collateralDocumentRid);
			streamCollateralDocument(insuranceDocument, response);
		} catch (Exception e) {
			logger.error("Error streaming CollateralDocument with rid=" + collateralDocumentRid);
			throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
		}
		logger.debug("getMortgageDocumentForCollateral() :: End");
	}
	
	private void streamCollateralDocument(CollateralDoc mortgageDocument, HttpServletResponse response) {
		streamCollateralDocument(mortgageDocument.getFileName(), mortgageDocument.getFileContent(), response);
	}
	
	public void streamCollateralDocument(CollateralDocument collateralDocument, HttpServletResponse response) {
		FileContent fileContent = collateralDocument.getFileContent();
		streamCollateralDocument(collateralDocument.getFileName(), fileContent.getFileContent(), response);
	}
	
	public void streamCollateralDocument(String fileName, byte[] fileContent, HttpServletResponse response) {
		logger.debug("streamCollateralDocument::BEGIN");
		try {
			validatePdf(fileContent);
			response.setContentType("application/pdf");
			response.setHeader("Content-Disposition", "inline; filename="+fileName);
			response.getOutputStream().write(fileContent);
		} catch (InvalidPdfException invalidPdf) {
            logger.error("Exception is : "+invalidPdf.getMessage() );
            throw new CTracWebAppException("E0133B", CtracErrorSeverity.APPLICATION);
        } catch (Exception e) {
			logger.error("Unable to open attachment from database");
			throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
		} finally {
			try {
				response.getOutputStream().close();
			} catch (IOException e) {
				logger.error("Failed to close response output stream");
				throw new CTracWebAppException("E0133", CtracErrorSeverity.APPLICATION);
			}
		}
		logger.debug("streamCollateralDocument::END");
	}

	void validatePdf(byte[] fileContent) throws IOException {
		logger.debug("validatePdf::BEGIN");
        PdfReader reader = new PdfReader(fileContent);
        if (Character.isWhitespace(reader.getPdfVersion())) {
            throw new InvalidPdfException("The document is not a valid pdf");
        }
		logger.debug("validatePdf::END");
	}
	
	@RequestMapping(value = "/floodRemap/getCollectWireConfirmationDocument/{index}", method = RequestMethod.GET,produces = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	public void getWireRequestDocument(@ModelAttribute("wireRequestData") WireRequestData wireConfirmationData, @PathVariable Integer index,HttpServletRequest request,HttpServletResponse response) {

		try {
			logger.debug("getCollectWireConfirmationDocument() from Wire Confirmation::Start");
			if(wireConfirmationData.getAccountWireReferences().size()>index.intValue())
			{
				AccountWireReferenceDto accountWireReferenceDto = wireConfirmationData.getAccountWireReferences().get(index.intValue());
				response.setHeader("Content-Disposition", "attachment; filename="+accountWireReferenceDto.getFilename());
				response.getOutputStream().write(wireProcessingService.generateWireDocumentByAccountWireReference(accountWireReferenceDto,
						wireConfirmationData.getWorkFlowStep()));
			}
			logger.debug("getCollectWireConfirmationDocument() from Wire Confirmation::END");

		} catch (Exception e) {
			logger.error("Unable to create wire document",e);
			//TODO Check the error code.
			throw new CTracWebAppException("E0172", CtracErrorSeverity.APPLICATION);

		} finally {
			try {
				response.getOutputStream().close();
			} catch (IOException e) {
				logger.error("Failed to close response output stream");
				//TODO Check the error code.
				throw new CTracWebAppException("E0172", CtracErrorSeverity.APPLICATION);
			}
		}
	}
	
}
