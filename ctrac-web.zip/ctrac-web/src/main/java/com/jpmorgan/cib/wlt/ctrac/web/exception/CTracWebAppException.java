package com.jpmorgan.cib.wlt.ctrac.web.exception;

import java.util.Map;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracBaseException;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;

public class CTracWebAppException extends CTracBaseException {

	private static final long serialVersionUID = 234815384593378402L;

	private TMParams tmParams;

	public CTracWebAppException(String errorCode, CtracErrorSeverity severity, TMParams tmParams) {
		super(errorCode, severity);
		this.tmParams = tmParams;
	}

	public CTracWebAppException(String errorCode, CtracErrorSeverity severity) {
		super(errorCode, severity);
	}

	public CTracWebAppException(String errorCode, CtracErrorSeverity severity, Throwable throwable) {
		super(errorCode, severity, throwable);
	}

	public CTracWebAppException(String errorCode, CtracErrorSeverity severity, Map<String, Object> modelViewObject,
			String strErrorPage, Throwable throwable) {
		super(errorCode, severity, modelViewObject, strErrorPage, throwable);
	}

	public CTracWebAppException(String errorCode, CtracErrorSeverity severity, String strErrorPage) {
		super(errorCode, severity, strErrorPage);
	}

	@Override
	public String getMessage() {
		return super.getErrorMessage();
	}

	public TMParams getTmParams() {
		return tmParams;
	}

}
