package com.jpmorgan.cib.wlt.ctrac.dashboard;

import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureBook;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/dashboard")
public class DashboardPageController {

    private static final Logger LOGGER = Logger.getLogger(DashboardPageController.class);
    @Autowired
    private FeatureManager featureManager;


    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView loadDashboard() {
        return loadDashboardSection("home");
    }

    @RequestMapping(value="/{page}/**", method = RequestMethod.GET)
    public ModelAndView loadDashboardSection(@PathVariable("page") String page) {
        LOGGER.debug("Render page: "+ page);
        if(!featureManager.isActive(FeatureBook.GENERAL_INSURANCE)) {
            throw new RuntimeException("Feature not enabled");
        }
        return new ModelAndView("/ctrac-ui/index");
    }
}
