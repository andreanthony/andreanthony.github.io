package com.jpmorgan.cib.wlt.ctrac.web.controller;


import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.FLOOD_INSURANCE_CONTACT_AGENT_SCREEN_ID;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.service.FloodInsuranceRenewalService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ContactAgentDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.GenericScreenProperties;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;


@Controller
@SessionAttributes({"contactAgentDto","tmParams"})  
public class FloodInsuranceContactAgentController extends BaseController {

	private static final Logger logger = Logger.getLogger(FloodInsuranceContactAgentController.class);
	
	@Autowired
	@Qualifier("floodInsuranceRenewalService")
	FloodInsuranceRenewalService floodInsuranceRenewalService;
	
	@Autowired
	private MessageSource messageSource;
	
	
	@RequestMapping(value = "/floodInsurance/launchContactAgentHelper", method = RequestMethod.GET)
	public String launchContactAgentHelper(HttpServletRequest request, ModelMap model,  @ModelAttribute("tmParams") TMParams tmParams) {
		logger.debug("debugging when launching contactAgent hyelper id_task:" + tmParams.getId_task() + " workflowStep:" + tmParams.getWorkflowStep() + "tranid: " +  tmParams.getTmTransactionId());
		GenericScreenProperties details = new GenericScreenProperties("floodInsuranceContactAgent", FLOOD_INSURANCE_CONTACT_AGENT_SCREEN_ID);
		return launchContactAgentHelper(request, model, tmParams,  details);
	}
	
	private String launchContactAgentHelper(HttpServletRequest request,ModelMap model,  TMParams tmParams, GenericScreenProperties details) {
		logger.debug("ContactAgentDtoHelper()::Start");
		logger.debug("id_task:" + tmParams.getId_task() + " workflowStep:" + tmParams.getWorkflowStep() + " tranid: " +  tmParams.getTmTransactionId());
		if (tmParams.getId_task() != null) {
			try {
				ContactAgentDto contactAgentDto = floodInsuranceRenewalService.prepareContactAgentDto(tmParams);
			    model.addAttribute("contactAgentDto", contactAgentDto);				
				return details.getPageUrl();
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new CTracWebAppException("E0237", CtracErrorSeverity.APPLICATION, e);
			}finally {
				logger.debug("ContactAgentDtoHelper()::End");
			}			
		}
		else {
			logger.error("Received Task UUID from TM is null");
			throw new CTracWebAppException("E0109", CtracErrorSeverity.APPLICATION);
		}
	}
	
	@RequestMapping(value = "/floodInsurance/submtiContactAgent", method = RequestMethod.POST, params = { "save" })
	public ModelAndView processContactAgent(@Valid @ModelAttribute("contactAgentDto") ContactAgentDto contactAgentDto, BindingResult binding){
			try{
				logger.debug("processContactAgent()::Start");
	        	if (!binding.hasErrors()) {
	        		ModelAndView modelAndView = new ModelAndView();
	        		logger.debug("processContactAgent handling request '/submtiContactAgent' "); 
	     
	        		floodInsuranceRenewalService.processContactAgentDto(contactAgentDto);
				    
	    			modelAndView.addObject("confirmation", messageSource.getMessage("contactAgent.confirmation.message", null, null));
	    			modelAndView.setViewName("floodRemapConfirmation"); 
	    		    return modelAndView;
				}
	        	else{ //Deal with validation Errors
	        		ModelAndView contactView = new ModelAndView();
	        		contactView.setViewName("floodInsuranceContactAgent");
	        		contactView.addObject("contactAgentDto", contactAgentDto);	
					logger.debug("contactAgent()::validationFailure");
					return contactView;
	        	}
			}catch(Exception e){
				logger.error(e.getMessage());
				 throw new CTracWebAppException("E0243", CtracErrorSeverity.CRITICAL, contactAgentDto.getTmParams());
			}
			finally{
				logger.debug("processContactAgent()::End");
			}
	}
	
	

}
