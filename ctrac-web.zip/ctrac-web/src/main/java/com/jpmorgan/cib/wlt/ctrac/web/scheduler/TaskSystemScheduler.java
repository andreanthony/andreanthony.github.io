package com.jpmorgan.cib.wlt.ctrac.web.scheduler;


import com.jpmorgan.cib.wlt.ctrac.batch.scheduler.AbstractScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.Schedules;
import org.springframework.stereotype.Component;

@Component
public class TaskSystemScheduler extends AbstractScheduler {

    @Scheduled(cron = "${cron.rsam.weekly.certification.expression}")
    public void runRSAMWeeklyCertification() {
        super.runRSAMWeeklyCertification(false);
    }

    @Scheduled(cron = "${cron.user.inactivity.job.expression}")
    public void runUserInactivityJob() {
        super.runUserInactivityJob(false);
    }

    //leaving it can used in the future if needed
    public void runJanusCtracEntitlementSync() {
        super.runJanusCtracEntitlementSync(false);
    }

    @Scheduled(cron = "${cron.eod.expression}")
    public void runEndOfTheDayJob() {
        super.runEndOfTheDayJob(false);
    }

    @Schedules({
            @Scheduled(cron = "${cron.eodc3.first.expression}"),
            @Scheduled(cron = "${cron.eodc3.second.expression}")
    })
    public void runEndOfTheDayC3Job() {
        super.runEndOfTheDayC3Job(false);
    }

    @Scheduled(cron = "${cron.serviceLink.poller.expression}")
    public void runServiceLinkJob() {
        super.runServiceLinkJob(false);
    }

    @Scheduled(cron = "${cron.corelogic.poller.expression}")
    public void runCoreLogicDataJob() {
        super.runCoreLogicDataJob(false);
    }

    @Scheduled(cron = "${cron.gds.image.poller.expression}")
    public void runProcessGDSImageJob() {
        super.runProcessGDSImageJob(false);
    }

    @Scheduled(cron = "${cron.last.remap.file.notify.expression}")
    public void runCheckRemapFileLastUpdate() {
        super.runCheckRemapFileLastUpdateJob(false);
    }

    @Scheduled(cron = "${cron.create.wire.expression}")
    public void runProcessWireRequestJob() {
        super.runProcessWireRequestJob(false);
    }

    @Scheduled(cron = "${cron.process.renewal.borrowerInsurancePolicy.expression}")
    public void runProcessToReviewPolicyJob() {
        super.runProcessToReviewPolicyJob(false);
    }


    @Scheduled(cron = "${cron.update.reference.date.expression}")
    public void runUpdateReferenceDateJob() {
        super.runUpdateReferenceDateJob(false);
    }


    @Scheduled(cron = "${cron.insurance.request.expression}")
    public void runSendRequestToInsuranceVendorJob() {
        super.runSendRequestToInsuranceVendorJob(false);
    }

    @Scheduled(cron = "${cron.althans.request.expression}")
    public void runSendRequestToInsuranceVendorAlthansJob() {
        super.runSendRequestToInsuranceVendorAlthansJob(false);
    }

    @Scheduled(cron = "${cron.post.eod.expression}")
    public void runPostFullEodJob() {
        super.runPostFullEodJob(false);
    }

    @Scheduled(cron = "${cron.althans.response.expression}")
    public void runProcessAlthansResponseFile() {
        super.runProcessAlthansResponseFile(false);
    }

    @Scheduled(cron = "${cron.althans.response.expression}")
    public void runProcessAlthansCertificateFile() {
        super.runProcessAlthansCertificateFile(false);
    }

    @Scheduled(cron = "${cron.coverageGapReport.expression}")
    public void runSendCoverageGapReportEmail() {
        super.runSendCoverageGapReportEmail(false);
    }

    @Override
    protected String getSchedulerName() {
        return "Task System Scheduled";
    }
}
