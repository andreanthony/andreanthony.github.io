package com.jpmorgan.cib.wlt.ctrac.event.store.api;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.EventStore;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.ConnectionManager;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventSubscriberDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PreDestroy;
import java.util.List;

@RestController
@RequestMapping("/api/event")
public class EventController {

    private EventStore eventStore;

    @Autowired
    public EventController(EventStore eventStore) {
        assert(eventStore != null);
        this.eventStore = eventStore;
    }

    @RequestMapping(method = RequestMethod.POST)
    @Secured({EntitlementRoles.API_ROLE, EntitlementRoles.API_PROCESSES})
    public ResponseEntity receive(@RequestBody String event) {
        eventStore.receive(event);
        return ResponseEntity.ok().build();
    }

    @RequestMapping(value = "subscribe", method = RequestMethod.POST)
    public ResponseEntity subscribe(@RequestBody List<CtracEventSubscriberDTO> subscriptions) {
        eventStore.subscribe(subscriptions);
        return ResponseEntity.ok().build();
    }

    @PreDestroy
    public void shutdown() {
        ConnectionManager.shutdown();
    }
}
