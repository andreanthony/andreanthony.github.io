package com.jpmorgan.cib.wlt.ctrac.web.controller.loan;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.LoanBorrowerSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanMaintenanceService;
import com.jpmorgan.cib.wlt.ctrac.service.validator.LoanMaintenanceValidator;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;

@Controller
@RequestMapping(value = "/loan")
@SessionAttributes({ "loanData", "collateralDetailsData","tmParams" })
public class LoanMaintenanceController {

	private static final String LOAN_DATA = "loanData";

	@Autowired
	private MessageSource messageSource;
	@Autowired LoanMaintenanceValidator loanMaintenanceValidator;

	private static final Logger logger = Logger.getLogger(LoanMaintenanceController.class);

	@Autowired
	private LoanMaintenanceService loanMaintenanceService;

	@Autowired
	private CollateralManagementService collateralManagementService;

	@Autowired
	private CollateralDetailsService collateralDetailsService;

	@RequestMapping(value = "view", method = RequestMethod.GET)
	@Secured({ EntitlementRoles.READER_ROLE })
	public ModelAndView viewLoan(@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto,
			@RequestParam Long collateralRid, @RequestParam(required = false) String loanRid,
			@RequestParam Integer mode, ModelMap model, SessionStatus sessionStatus) {
		logger.debug("viewLoan");
		ModelAndView mav = new ModelAndView("loan/loan-maintenance");

		LoanData loanData = null;
        LoanBorrowerSectionDto loanSection = collateralDetailsMainDto.getLoanBorrowerSectionData();
		if (loanRid != null) {
			try {
		        loanData = loanSection.getloanData(Long.valueOf(loanRid));
		        loanData.setDisplayReleaseDate(loanData.getRid() != null &&
		    			collateralDetailsMainDto.getCollateralDto().getCollateralStatus() != CollateralStatus.DRAFT
						);
		    	loanSection.setVerifyMode(loanData.getStatus() == LoanStatus.PENDING_VERIFICATION && mode == 2);
			} catch (Exception e) {
				logger.error("Loan not found, rid=" + loanRid);
			}
		}
		
		Object taskManagerParams = model.get("tmParams");
		collateralDetailsMainDto.setTmParams(taskManagerParams != null ? (TMParams) taskManagerParams : null);
		loanSection.setCollateralRid(collateralRid);
		loanSection.setLaunchingNew(loanData == null);
		if (loanData == null) {
			loanData = loanMaintenanceService.prepareNewLoanData(collateralRid);
		}
		mav.addObject(LOAN_DATA, loanData);
        mav.addObject("referenceValues", loanMaintenanceService.getLoanReferenceValues(loanSection));
        return mav;
	}

	@RequestMapping(value = "save", method = RequestMethod.POST)
	@Secured({ EntitlementRoles.READER_ROLE })
	public ResponseEntity<BaseApiResponse> saveLoan(@Valid @ModelAttribute(LOAN_DATA) LoanData loanData, BindingResult errors,
													@ModelAttribute("collateralDetailsData") CollateralDetailsMainDto collateralDetailsMainDto, ModelMap model) {
		logger.debug("saveLoan");
		collateralDetailsMainDto.setSaveStatus("");
		String saveSuccessMessage = messageSource.getMessage("service.save.success.message", null, null);
		Object taskManagerParams = model.get("tmParams");
		collateralDetailsMainDto.setTmParams(taskManagerParams != null ? (TMParams) taskManagerParams : null);
		loanMaintenanceValidator.validatePrimaryLoan(collateralDetailsMainDto, loanData, errors);
		if(!errors.hasErrors()){
			boolean marketEmailChangeDetected = collateralManagementService.hasMarketEmailChanged(collateralDetailsMainDto);
			loanMaintenanceService.saveLoanData(loanData, collateralDetailsMainDto);
			collateralDetailsMainDto.setSaveStatus(saveSuccessMessage);

			// LCP-4049 CTL - Coding Special Handling Collateral Records
			// in case MarketEmail has changed due to change in LoB from CTL to non-CTL
			if(marketEmailChangeDetected){
				CollateralScreenAction screenAction = CollateralScreenAction.getCollateralScreenAction("edit");
				collateralDetailsService.saveCollateralSectionInfo(collateralDetailsMainDto, screenAction);
			}
	        model.addAttribute("collateralDetailsData", collateralDetailsMainDto);
		}
        logger.debug("saveLoanBorrowerInfo :: END");
        BaseApiResponse apiResponse = new BaseApiResponse(errors,saveSuccessMessage);
        return new ResponseEntity<>(apiResponse,errors.hasErrors()? HttpStatus.BAD_REQUEST:HttpStatus.OK);
	}

}
