package com.jpmorgan.cib.wlt.ctrac.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.service.admin.LoanBorrowerAddressService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.LoanBorrowerAddressDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.LoanBorrowerAddressMaintenanceDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.RestartLetterCycleDTO;

@Controller
@SessionAttributes({ "loanBorrowerAddressMaintenanceData"})
@RequestMapping(value = "/admin")
public class LoanBorrowerAddressController {

	private static final String LOAN_BORROWER_ADDRESS_URL = "admin/loanBorrowerAddress";

	private static final Logger logger = Logger.getLogger(LoanBorrowerAddressController.class);
	
	@Autowired private LoanBorrowerAddressService loanBorrowerAddressService;

	@RequestMapping(value = "loanBorrowerAddressAuto", method = RequestMethod.GET)
	public String launchLoanBorrowerAddressAuto(HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		logger.debug("launchLoanBorrowerAddressAuto::BEGIN");
						
		LoanBorrowerAddressMaintenanceDTO loanBorrowerAddressMaintenanceData = new LoanBorrowerAddressMaintenanceDTO();
		
		// auto correct addresses
		List<LoanBorrowerAddressDTO> loanBorrowerAddressDTOList =loanBorrowerAddressService.autoCorrectLoanBorrowerAddress();
		
		// Set display object
		loanBorrowerAddressMaintenanceData.setLoanBorrowerAddressData(loanBorrowerAddressDTOList);
		loanBorrowerAddressMaintenanceData.setMode("Auto");
		loanBorrowerAddressMaintenanceData.setAutoCorrectLoanBorrowerAddressCount(loanBorrowerAddressDTOList.size());
		loanBorrowerAddressMaintenanceData.setSuccessMsg(null);
		loanBorrowerAddressMaintenanceData.setErrorMsg(null);
		
		model.addAttribute("loanBorrowerAddressMaintenanceData", loanBorrowerAddressMaintenanceData);
		session.setAttribute("loanBorrowerAddressMaintenanceData", loanBorrowerAddressMaintenanceData);
		
		logger.debug("launchLoanBorrowerAddressAuto::END");
		return LOAN_BORROWER_ADDRESS_URL;
	}
	
	@RequestMapping(value = "loanBorrowerAddress", method = RequestMethod.GET)
	public String launchLoanBorrowerAddress(HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		logger.debug("launchLoanBorrowerAddress::BEGIN");
				
		LoanBorrowerAddressMaintenanceDTO loanBorrowerAddressMaintenanceData = new LoanBorrowerAddressMaintenanceDTO();

		loanBorrowerAddressMaintenanceData.setUnverifiedRecordsCount(loanBorrowerAddressService.getUnverifiedLoanBorrowerAddressDataCount());
		List<LoanBorrowerAddressDTO> loanBorrowerAddressDTOList = loanBorrowerAddressService.prepareLoanBorrowerAddressData();
		
		// Set display object
		loanBorrowerAddressMaintenanceData.setLoanBorrowerAddressData(loanBorrowerAddressDTOList);
		loanBorrowerAddressMaintenanceData.setMode("Manual");
		loanBorrowerAddressMaintenanceData.setSuccessMsg(null);
		loanBorrowerAddressMaintenanceData.setErrorMsg(null);
		
		model.addAttribute("loanBorrowerAddressMaintenanceData", loanBorrowerAddressMaintenanceData);
		session.setAttribute("loanBorrowerAddressMaintenanceData", loanBorrowerAddressMaintenanceData);
		
		logger.debug("launchLoanBorrowerAddress::END");
		return LOAN_BORROWER_ADDRESS_URL;
	}
	
	@RequestMapping(value = "updateLoanBorrowerAddress", method = RequestMethod.POST)
	public String updateLoanBorrowerAddress(@ModelAttribute("loanBorrowerAddressMaintenanceData") LoanBorrowerAddressMaintenanceDTO loanBorrowerAddressMaintenanceData, 
			HttpServletRequest request,
			HttpServletResponse response, HttpSession session, ModelMap model) {
		logger.debug("updateLoanBorrowerAddress::BEGIN");
		
		loanBorrowerAddressService.saveLoanBorrowerAddressRecords(loanBorrowerAddressMaintenanceData.getLoanBorrowerAddressData());
		
		List<LoanBorrowerAddressDTO> loanBorrowerAddressDTOList = loanBorrowerAddressService.prepareLoanBorrowerAddressData();
		
		
		// Set display object
		loanBorrowerAddressMaintenanceData.setLoanBorrowerAddressData(loanBorrowerAddressDTOList);
		loanBorrowerAddressMaintenanceData.setSuccessMsg(null);
		loanBorrowerAddressMaintenanceData.setErrorMsg(null);
		
		model.addAttribute("loanBorrowerAddressMaintenanceData", loanBorrowerAddressMaintenanceData);
		session.setAttribute("loanBorrowerAddressMaintenanceData", loanBorrowerAddressMaintenanceData);
		
		logger.debug("updateLoanBorrowerAddress::END");
		return LOAN_BORROWER_ADDRESS_URL;
	}	
		
}
