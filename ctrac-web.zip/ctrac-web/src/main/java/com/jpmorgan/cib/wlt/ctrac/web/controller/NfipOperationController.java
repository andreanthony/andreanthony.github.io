package com.jpmorgan.cib.wlt.ctrac.web.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.NfipProgramService;

@Controller
@SessionAttributes({ "operationsAdminData"})
@RequestMapping(value = "/admin")
public class NfipOperationController {

	@Autowired
	private NfipProgramService nfipProgramService;

	private static final String NFIP_ADMINISTRATION_URL = "/admin/nfipProgramOperation";


	private static final Logger logger = Logger.getLogger(NfipOperationController.class);
	
	@Secured({EntitlementRoles.ADMIN_ROLE})
	@RequestMapping(value = "nfipProgramOperation", method = RequestMethod.GET)
	public ModelAndView launchOperationsAdministration() {
		logger.debug("launchOperationsAdministration::BEGIN");
		ModelAndView mav = new ModelAndView(NFIP_ADMINISTRATION_URL);
		boolean isNfip = nfipProgramService.isNfipProgramActive();
		mav.addObject("isNfip", isNfip);
		logger.debug("launchOperationsAdministration::END");
		return mav;
	}
	
	@Secured({EntitlementRoles.ADMIN_ROLE})	
	@RequestMapping(value = "nfipProgramOperation", method = RequestMethod.POST )
	public ModelAndView submitOperationsAdministration(@ModelAttribute("isNfip") boolean isNfip ) {
		logger.debug("submitOperationsAdministration::BEGIN");		
		nfipProgramService.setNfipProgramActive(isNfip);
		String newStatus = isNfip? "Active" : "Expired";
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("confirmation", "NFIP Program status successfully updated to <strong>" + newStatus + "</strong>");
		modelAndView.setViewName("floodRemapConfirmation");

		logger.debug("submitOperationsAdministration::END");		
		return modelAndView;	
	}
}
