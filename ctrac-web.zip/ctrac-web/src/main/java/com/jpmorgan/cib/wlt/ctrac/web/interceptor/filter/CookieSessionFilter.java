package com.jpmorgan.cib.wlt.ctrac.web.interceptor.filter;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;


/**
 * @author
 * 
 * The responsibility of this class is to bypass the Form based authentication.
 * This filter intercept the first un-authenticated request and attempt to build a username/password authentication token
 * which is them passed to the authenticationProvider as described in @org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter
 *
 */
@Component(value="cookieSessionFilter")
public class CookieSessionFilter extends AbstractPreAuthenticatedProcessingFilter {

	
	@Resource
	private Environment env;
	
	@Autowired
	AuthenticationManager authenticationManagerBean;
	
	@Autowired private CtracAuthenticationManager ctracAuthenticationManager;
	
	private static final Logger logger = Logger.getLogger(CookieSessionFilter.class);
	
	
	
	@PostConstruct
	public void init() {
	   super.setAuthenticationManager(authenticationManagerBean);
	}
	
	

	
	@Override
	protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {

		logger.info("CookieSessionFilter.getPreAuthenticatedPrincipal()::start ");
		
		String userName = ctracAuthenticationManager.getJanusUserCredentials(request);
		
		logger.info("======================== \n Authenticated username is:  "+userName +"====================\n");
		
		
		/**
		 * TODO 
		 * @Christian// even though this work just fine now, it can't be considered a robust authentication 
		 * mechanism as the session cookie alone are easy to compromise.
		 * Investigate with Janus/TM and implement a callback service to validate the cookies
		 */
			  
	 return userName;
	}

	@Override
	protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {

		/**
		 * TODO @Chrisitan
		 * For now, we can statically assign the same password to all ctrac Users and since we ultimately are relying on Janus,
		 * if we validate back the cookie with janus, we don't care what the value of this password is.
		 * 
		 */
	
	 return "lifeofloan123";
	}

}
