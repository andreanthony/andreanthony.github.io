package com.jpmorgan.cib.wlt.ctrac.web.spring.dialect;

import com.jpmorgan.cib.wlt.ctrac.web.spring.processor.CustomSpringActionAttrProcessor;
import org.thymeleaf.context.IProcessingContext;
import org.thymeleaf.dialect.IExpressionEnhancingDialect;
import org.thymeleaf.processor.IProcessor;
import org.thymeleaf.spring4.dialect.SpringStandardDialect;
import org.thymeleaf.spring4.expression.Mvc;

import java.util.*;

/**
 * Created by V704662 on 7/14/2017.
 */
public class CustomSpringDialect extends SpringStandardDialect implements IExpressionEnhancingDialect {

    @Override
    public Set<IProcessor> getProcessors() {
        Set<IProcessor> processors = new HashSet<>();
        processors.add(new CustomSpringActionAttrProcessor());
        return processors;
    }

    @Override
    public Map<String, Object> getAdditionalExpressionObjects(IProcessingContext iProcessingContext) {
        HashMap additionalExpressionObjects = new HashMap(2, 1.0F);
        additionalExpressionObjects.put("mvc", new Mvc());
        return additionalExpressionObjects;
    }
}
