package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DefaultDateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.HTMLDateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.LongDateFormatter;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.ReferenceDateService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping(value = "/api/admin/referenceDate")
public class ReferenceDateController {

    private static final Logger logger = Logger.getLogger(ReferenceDateController.class);
    private static final DateFormatter DEFAULT_DATE_FORMATTER = new DefaultDateFormatter();
    private static final DateFormatter HTML_DATE_FORMATTER = new HTMLDateFormatter();
    private static final DateFormatter LONG_DATE_FORMATTER = new LongDateFormatter();
    private static final String CANNOT_GET_REFERENCE_DATE = "Cannot get reference date";
    private static final String REFERENCE_DATE_NOT_UPDATED = "Reference date not updated";

    private ReferenceDateService referenceDateService;
    private DateCalculator dateCalculator;

    @Autowired
    public ReferenceDateController(ReferenceDateService referenceDateService, DateCalculator dateCalculator) {
        assert(referenceDateService != null);
        this.referenceDateService = referenceDateService;
        assert(dateCalculator != null);
        this.dateCalculator = dateCalculator;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<ReferenceDateDTO> getReferenceDate() {
        try {
            ReferenceDateDTO referenceDateDTO = new ReferenceDateDTO();
            Date referenceDate = dateCalculator.getCurrentReferenceDate();
            referenceDateDTO.setReferenceDate(HTML_DATE_FORMATTER.print(referenceDate));
            referenceDateDTO.setLongDate(LONG_DATE_FORMATTER.print(referenceDate));
            referenceDateDTO.setWorkingDay(dateCalculator.isBusinessDay(referenceDate));
            return ResponseEntity.ok(referenceDateDTO);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResponseEntity.badRequest().body(new ReferenceDateDTO(CANNOT_GET_REFERENCE_DATE));
        }
    }

    @RequestMapping(method = RequestMethod.POST)
    @Secured({EntitlementRoles.OPERATE_WRITERS})
    public ResponseEntity<ReferenceDateDTO> updateReferenceDate(@RequestBody ReferenceDateDTO referenceDateDTO) {
        try {
            referenceDateService.updateReferenceDate(parseDate(referenceDateDTO.getReferenceDate()));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResponseEntity.badRequest().body(new ReferenceDateDTO(REFERENCE_DATE_NOT_UPDATED));
        }
        return getReferenceDate();
    }

    private Date parseDate(String dateStr) {
        try {
            return HTML_DATE_FORMATTER.parse(dateStr);
        } catch (Exception e) {
            return DEFAULT_DATE_FORMATTER.parse(dateStr);
        }
    }

    @RequestMapping(value = "advance", method = RequestMethod.POST)
    @Secured({EntitlementRoles.OPERATE_WRITERS})
    public ResponseEntity<ReferenceDateDTO> advanceReferenceDate() {
        try {
            referenceDateService.advanceReferenceDate();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResponseEntity.badRequest().body(new ReferenceDateDTO(REFERENCE_DATE_NOT_UPDATED));
        }
        return getReferenceDate();
    }

    @RequestMapping(value = "advance/{dayOfWeek}", method = RequestMethod.POST)
    @Secured({EntitlementRoles.OPERATE_WRITERS})
    public ResponseEntity<ReferenceDateDTO> advanceReferenceDate(@PathVariable String dayOfWeek) {
        try {
            referenceDateService.advanceReferenceDate(dayOfWeek);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResponseEntity.badRequest().body(new ReferenceDateDTO(REFERENCE_DATE_NOT_UPDATED));
        }
        return getReferenceDate();
    }
}
