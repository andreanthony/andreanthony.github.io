package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;


import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.UUID;

@Controller
public class EventManagementController {

	private static final Logger log = LoggerFactory.getLogger(EventManagementController.class);

	private PublishEventService publishEventService;

	@Autowired
	public EventManagementController(PublishEventService publishEventService) {
		assert (publishEventService != null);
		this.publishEventService = publishEventService;
	}

	@RequestMapping(value = "/admin/eventManagementPage", method = RequestMethod.GET)
	@Secured({EntitlementRoles.OPERATE_WRITERS})
	public ModelAndView getPage() {
		return new ModelAndView("/admin/eventManagement");
	}

	@RequestMapping(value = "/api/admin/eventManagement/republish/{eventUuid}", method = RequestMethod.POST)
	@Secured({EntitlementRoles.OPERATE_WRITERS})
	public ResponseEntity<String> republishEvent(@PathVariable String eventUuid) {
		try {
			publishEventService.republishEvent(parseUUID(eventUuid));
			return ResponseEntity.ok("Event republished");
		} catch (CtracException e) {
			log.error("Unable to republish event with uuid {}", eventUuid, e);
			return ResponseEntity.badRequest().body(e.getMessage());
		} catch (Exception e) {
			log.error("Unable to republish event with uuid {}", eventUuid, e);
			return ResponseEntity.badRequest().body("Unable to republish event");
		}
	}

	@RequestMapping(value = "/api/admin/eventManagement/republishByDate", method = RequestMethod.POST)
	@Secured({EntitlementRoles.OPERATE_WRITERS})
	public ResponseEntity<String> republishEvents(@RequestBody RepublishEventRequestDTO republishRequest) {
		try {
			if (republishRequest.getFromDate() == null) {
				return ResponseEntity.badRequest().body("From Date is null");
			}

			if (republishRequest.getToDate() == null) {
				republishRequest.setToDate(new Date());
			}

			publishEventService.republishEvents(republishRequest.getFromDate(), republishRequest.getToDate());
			return ResponseEntity.ok("Events republished");
		} catch (Exception e) {
			log.error("Unable to republish events between {} and {}", republishRequest.getFromDate(), republishRequest.getToDate(), e);
			return ResponseEntity.badRequest().body("Unable to republish events");
		}
	}

	private UUID parseUUID(String eventUuid) {
		try {
			eventUuid = eventUuid.toLowerCase();
			if (StringUtils.countMatches(eventUuid, "-") != 4) {
				eventUuid = eventUuid.replaceFirst(
						"([0-9a-fA-F]{8})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]+)",
						"$1-$2-$3-$4-$5");
			}
			return UUID.fromString(eventUuid);
		} catch (Exception e) {
			log.error("Invalid UUID", e);
			throw new CtracException("Invalid UUID");
		}
	}

	public static class RepublishEventRequestDTO {
		private Date fromDate;
		private Date toDate;

		public Date getFromDate() {
			return fromDate;
		}

		public void setFromDate(Date fromDate) {
			this.fromDate = fromDate;
		}

		public Date getToDate() {
			return toDate;
		}

		public void setToDate(Date toDate) {
			this.toDate = toDate;
		}
	}
}
