package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.SectionStatusDto;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/api/admin/sectionStatuses")
public class SectionStatusController {

    private static final Logger logger = Logger.getLogger(SectionStatusController.class);

    private CollateralDetailsStatusService collateralDetailsStatusService;

    @Autowired
    public SectionStatusController(CollateralDetailsStatusService collateralDetailsStatusService) {
        assert(collateralDetailsStatusService != null);
        this.collateralDetailsStatusService = collateralDetailsStatusService;
    }

    @RequestMapping(value = "/{collateralId}", method = RequestMethod.GET)
    public ResponseEntity<List<SectionStatusDto>> getSectionStatuses(@PathVariable Long collateralId) {
        try {
            return ResponseEntity.ok(collateralDetailsStatusService.getSectionStatuses(collateralId));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResponseEntity.badRequest().body(null);
        }
    }

    @RequestMapping(value = "/{collateralId}/allowVerification", method = RequestMethod.POST)
    @Secured({EntitlementRoles.OPERATE_WRITERS})
    public ResponseEntity<List<SectionStatusDto>> allowVerification(@PathVariable Long collateralId) {
        try {
            collateralDetailsStatusService.allowAnyVerification(collateralId);
            return getSectionStatuses(collateralId);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResponseEntity.badRequest().body(null);
        }
    }
}
