package com.jpmorgan.cib.wlt.ctrac.web.init;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;

@WebListener
public class CtracSessionListener implements HttpSessionListener {

    private static final Logger logger = Logger.getLogger(CtracSessionListener.class);
    
    @Override
    public void sessionCreated(HttpSessionEvent event) {
        event.getSession().setMaxInactiveInterval(60 * 60); //in seconds
    }
    
    @Override
    public void sessionDestroyed(HttpSessionEvent event) {
        HttpSession session = event.getSession();
        String id_user = (String) session.getAttribute("JANUS_USER_ID");
        if (id_user != null) {
	        logger.info("USER LOGGING OUT: " + id_user);
	        session.removeAttribute("JANUS_USER_ID");
        }
        session.invalidate();
    }

}
