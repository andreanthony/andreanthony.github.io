package com.jpmorgan.cib.wlt.ctrac.web.interceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.UsersDto;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;

public class CtracRequestInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = Logger.getLogger(CtracRequestInterceptor.class);

	@Autowired
	AuditInformationService auditInformationService;
	
	@Resource
	private UserEntitlementService userEntitlementService;
	
	@Autowired private CtracAuthenticationManager ctracAuthenticationManager;
	
	@Value("${ctrac.views.token}")
	private String resourceToken;

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		
		request.getSession().setAttribute("resourceToken",resourceToken );
		
		String userName = (String)request.getSession().getAttribute("JANUS_USER_ID");
		String id_user = ctracAuthenticationManager.getJanusUserCredentials(request);
		
		UsersDto user = userEntitlementService.getUserDetailsbyUserName(id_user);		
		String sid_user = user.getSid();
		
		if (userName == null) {
			logger.info("Session doesn't exist for user.");
			//TODO: create a user profile object based on Janus credential and set the object in the user's session
			request.getSession().setAttribute("JANUS_USER_ID", sid_user);
			logger.info("USER LOGGING IN: " + sid_user);
		}

		if (StringUtils.isBlank(auditInformationService.getLoggedInUserSid())) {
			// userd for app audit
			auditInformationService.setAuditInformation(sid_user,user.getFirstName(),user.getLastName());
		}
		
		logger.info("Proceeding with request for URI: "+request.getRequestURI()+ " for user: "+(String)request.getSession().getAttribute("JANUS_USER_ID"));		
		return true;
		
	}
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		String Myhandler = handler.toString();
		logger.debug("handler.toString content: " + Myhandler);
		//super.postHandle(request, response, handler, modelAndView);
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		super.afterCompletion(request, response, handler, ex);
	}

}
