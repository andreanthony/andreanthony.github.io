package com.jpmorgan.cib.wlt.ctrac.web.controller.hold.api;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/collateral/{collateralRid}/holds")
public class HoldApiController {

    private HoldService holdService;

    @Autowired
    public HoldApiController(HoldService holdService) {
        assert(holdService != null);
        this.holdService = holdService;
    }

    @Secured({EntitlementRoles.READER_ROLE})
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity getAllHolds(@PathVariable Long collateralRid) {
        try{
            return new ResponseEntity<>(holdService.getHoldHistory(collateralRid), HttpStatus.OK);
        }catch(Exception ex){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
