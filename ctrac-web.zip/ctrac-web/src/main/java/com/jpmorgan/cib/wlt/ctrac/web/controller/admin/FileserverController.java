package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.FilenameValidator;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.FileserverDTO;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

@Controller
@Secured({EntitlementRoles.ADMIN_ROLE, EntitlementRoles.OPERATE_READERS, EntitlementRoles.OPERATE_WRITERS})
@RequestMapping(value = "admin/fileserver")
@SessionAttributes({ "fileserverDTOs" })
public class FileserverController {

	private static final Logger logger = Logger.getLogger(FileserverController.class);

	private static final String FILESERVER_CONFIG = "fileserver.config";


	@Autowired
	private Environment env;

	@RequestMapping(method = RequestMethod.GET)
	public String getFileserver(ModelMap model) {
		Scanner scanner = null;
		try {
			logger.debug("getFileserver::START");
			List<FileserverDTO> fileserverDTOs = new ArrayList<>();
			scanner = new Scanner(loadFileFrom(env.getRequiredProperty(FILESERVER_CONFIG)));
			while (scanner.hasNextLine()) {
				String[] fileserverConfig = scanner.nextLine().split(";");
				if (fileserverConfig.length >= 2) {
					try {
						String propertyKey = fileserverConfig[0];
						String path = env.getRequiredProperty(propertyKey);
						String label = fileserverConfig[1];
						fileserverDTOs.add(new FileserverDTO(propertyKey, loadFileFrom(path), label));
					} catch (Exception e) {
						logger.debug(e.getMessage(), e);
					}
				}
			}
			model.addAttribute("fileserverDTOs", fileserverDTOs);
			logger.debug("getFileserver::END");
			return "/admin/fileserver";
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
			throw new CTracWebAppException("E0101", CtracErrorSeverity.APPLICATION);
		} finally {
			if (scanner != null) { scanner.close(); }
		}
	}

	/**
	 * Load the file for given path / filename
	 * @param filePath
	 * @return File instance
	 */
	File loadFileFrom(String filePath){
		return new File(filePath);
	}

	static final private Map<String, String> extensionToContentType = new HashMap<String, String>();
	static {
		extensionToContentType.put("zip", "application/zip");
		extensionToContentType.put("xml", "text/xml");
		extensionToContentType.put("pdf", "application/pdf");
		extensionToContentType.put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
	}

	@RequestMapping(value = "download/{index}/{extension}/{fileName:.+}", method = RequestMethod.GET, produces={ "application/zip", "text/xml", "application/pdf", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" })
	public void streamFilePdf(@PathVariable int index, @PathVariable String extension, @PathVariable String fileName, @ModelAttribute("fileserverDTOs") List<FileserverDTO> fileserverDTOs,
			HttpServletResponse response) {
		streamFile(fileName, extension, extensionToContentType.get(extension), fileserverDTOs.get(index), response);
	}

	private void streamFile(String fileName, String extension, String contentType, FileserverDTO fileserverDTO,
			HttpServletResponse response) {
		logger.debug("streamFile::START");
		InputStream inputStream = null;
		OutputStream outputStream = null;
		try {
			outputStream = response.getOutputStream();
			response.setContentType(contentType);
			response.setHeader("Content-Disposition", "inline; filename=" + fileName + "." + extension);
			File file = fileserverDTO.getFile(fileName);
			if (file != null) {
				inputStream = FileUtils.openInputStream(file);
				IOUtils.copy(inputStream, outputStream);
			}
			logger.debug("streamFile::END");
		} catch (Exception e) {
			logger.error("Unable to launch getFileserver");
			throw new CTracWebAppException("E0192", CtracErrorSeverity.APPLICATION);
		} finally {
			IOUtils.closeQuietly(inputStream);
			IOUtils.closeQuietly(outputStream);
		}
	}

	@RequestMapping(value = "upload/{index}/", method = RequestMethod.POST)
	public String uploadFile(@PathVariable int index, @RequestParam("fileToUpload") MultipartFile fileToUpload,
							 @ModelAttribute("fileserverDTOs") List<FileserverDTO> fileserverDTOs) {
		logger.debug("uploadFile::START");
		InputStream in = null;
		OutputStream out = null;
		try {
			if (!fileToUpload.isEmpty()) {
				String filename = FilenameUtils.normalize(fileToUpload.getOriginalFilename());
				if (!FilenameValidator.isValidFilename(filename)) {
					throw new RuntimeException("Filename must be valid characters");
				}
				File srcFile = loadFileFrom(filename);
				in = fileToUpload.getInputStream();
				out = new FileOutputStream(srcFile);
				FileUtils.copyInputStreamToFile(in, srcFile);
				String pathPropertyKey = fileserverDTOs.get(index).getPropertyKey();
				File destDir = loadFileFrom(env.getRequiredProperty(pathPropertyKey));
				FileUtils.copyFileToDirectory(srcFile, destDir);
			}
			logger.debug("uploadFile::END");
			return "redirect:/admin/fileserver";
		} catch (Exception e) {
			logger.error("Unable to launch uploadFile: " + e.getMessage(),e);
			throw new CTracWebAppException("E0192", CtracErrorSeverity.APPLICATION);
		} finally {
			IOUtils.closeQuietly(in);
			IOUtils.closeQuietly(out);
		}
	}


}
