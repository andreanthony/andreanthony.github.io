var isBrowserClose = true;
var errorClass = "has-error text-danger";
jQuery.extend(jQuery.validator.messages, {required: " "});

$(document).ready(function($) {
    $("#escrowBalanceForm").validate({
        ignore : "input:hidden",
        groups: {
            name: 'negativeEscrowBalance escrowBalanceAmount'
        },
        submitHandler: function() { isBrowserClose = false;return true;}
    });

    disableDoubleClick('submitCmd');
    $(window).on('unload', closeCallBack);
    registerEscrowBalanceEventListener();
    $('.numeric').each(function() {
        $(this).autoNumeric('init');
    });
});

function closeCallBack() {
    if (isBrowserClose) {
        unlockTask();
    }
}

function registerEscrowBalanceEventListener(){
    $('input[name=negativeEscrowBalance]').on('change', function() {
        if($('input[name=negativeEscrowBalance]:checked').val() === 'Yes'){
            $("#divEscrowBalance").show();
        } else {
            $("#divEscrowBalance").hide();
        }
    });
    $('input[name=negativeEscrowBalance]').change();
}