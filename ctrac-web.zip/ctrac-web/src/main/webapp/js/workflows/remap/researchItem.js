
function registerCompleteReasonEventListener(){
	$("#completeReason").change(function () {
        if(this.value != ""){
        	disableFields("input[name=clientFound]");
        	$('input[name=clientFound]').change();
        	enableFields("#comment");
        	$('#counter').show();
        } else {
        	$('#counter').hide();
        	disableFields("#comment");
        	enableFields("input[name=clientFound]");
        }
	});
	$("#completeReason").change();
}

function registerClientFoundEventListener(){
	$('input[name=clientFound]').on('change', function() {
		  if($('input[name=clientFound]:checked').val() === 'Y'){
			  enableFields('#marketEmailAddress, .clientfound-dependent');
		  } else {
			  disableFields('#marketEmailAddress, .clientfound-dependent');
			  $('.clientfound-dependent').change();
		  }
	});
	$('input[name=clientFound]').change();
}

function registerPropertyPledgedEventListener(){
	$('input[name=propertyPledge]').on('change', function() {
		  if($('input[name=propertyPledge]:checked').val() === 'Y'){
			  enableFields('input[name=exposure]');
		  } else {
			  disableFields('input[name=exposure]');
		  }
	});
	$('input[name=propertyPledge]').change();
}

function registerZoneInEvents(){
	$('.clientfound-dependent').on('change', function() {
		 if($('input[name=propertyPledge]:checked').val() === 'N'){
			 enableFields(".borrower-info");
			 hideFields(".collateral-info");
		 }
		 else if($('input[name=propertyPledge]:checked').val() === 'Y' && $('input[name=exposure]:checked').val() === 'Y'){
			 $('.collateral-info').prop('hidden', false);
			 disableFields(".borrower-info");
		 }
		 else if($('input[name=propertyPledge]:checked').val() === 'Y' && $('input[name=exposure]:checked').val() === 'N'){
			 enableFields(".borrower-info");
			 hideFields(".collateral-info");
		 } else {
			 hideFields(".collateral-info");
		 }
	});
	$('.clientfound-dependent').change();
}

function registerZoneOutEvents(){
	$('input[name=propertyPledge]').on('change', function() {
		if($('input[name=propertyPledge]:checked').val() === 'N'){
			  enableFields(".borrower-info");
			  hideFields(".collateral-info, .notice-letter");
		 }
		 else if($('input[name=propertyPledge]:checked').val() === 'Y'){
			 disableFields(".borrower-info");
			$('.collateral-info, .notice-letter').prop('hidden', false);
		 } else {
			 disableFields(".borrower-info");
			 hideFields(".collateral-info, .notice-letter");
		 }
	});
	$('input[name=propertyPledge]').change();
}
function revertToOriginalVal(ele){
	 if($(ele).is('select')) {
		 $(ele).val($(ele).find('option[selected]').val());
	 } 
	 else if($(ele).is(':radio')){
		 $(ele).attr('checked',false);
	 }
	 else{
		 $(ele).val(ele.defaultValue);
	 }
}

function enableFields(targetClass){
	 $(targetClass).each(function() {
		 $(this).prop('disabled', false);
		 $(this).closest('div .form-group').find(".require-symbol").show();
	 });
}

function disableFields(targetClass){
 $(targetClass).each(function() {
	 revertToOriginalVal(this);
	 $(this).prop('disabled', 'disabled');
	 $(this).closest('div .form-group').find(".require-symbol").hide();
	 $(this).closest("div").removeClass("has-error text-danger");
 });
 $("#errorContainer").hide();		
}

function hideFields(targetClass){
 $(targetClass).each(function() {
	revertToOriginalVal(this);
	$(this).prop('hidden', true);
 });
 $("#errorContainer").hide();	
}

function reset(){
	hideFields(".onload-hidden");
	disableFields(".onload-disabled");
	enableFields(".onload-enabled");
}

function getCollateralDescription(){
  var collateralId = $('#collateralId').val();
  if(collateralId != ""){
	  $.ajax({
	        type: "POST",
	        url: 'getCollateralDescription',
	        data: $('form#taskResearchItemForm').serialize(),		        
	        success: function(data) {
	        	$('#collateralDescription').text(data);
	        }
	    }); 
  }
}

function closeCallBack(){
	if (isBrowserClose) {
		unlockTask();
	}
}

function uploadCallBack(){
	isBrowserClose=false;
}	