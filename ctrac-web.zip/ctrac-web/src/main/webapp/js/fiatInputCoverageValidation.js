var isBrowserClose = true;		  
var errorClass = "has-error text-danger";
var validClass ="";
jQuery.validator.addMethod("totalAmountGreaterThan0", 
			function(value, element) {
										
					var pairClass='';
					if($(element).hasClass('buildingAmount')){
						pairClass ='contentAmount';
					}else{
						pairClass ='buildingAmount';
					}	
					var pairElem = $(element).parents('.table-line').find('.'+pairClass);
					
				    if( pairElem && !isBlank($(pairElem).val()) && !isBlank($(element).val()) ){
				    	var pairVal = $(pairElem).val();
					    var sum = getFloatFromString($(element).val() )+getFloatFromString(pairVal);
					    if (sum <=0)
						  {  
					    	hightlightFieldError(element);
					    	hightlightFieldError(pairElem);
						     return false;
						  }else{
							  unhightlightFieldError(pairElem);
						  }
					}
					if(!isBlank(value)){
						 unhightlightFieldError(element);
					}
					if(!isBlank(pairElem)){
						unhightlightFieldError(pairElem);
					}
					return true;
		 },  
			" "  //Total of Building and Content amount must be greater than 0.
);

function getFloatFromString(stringAmount) {
	return parseFloat(stringAmount.replace(/,/g, ''));
}   

function hideAttachLink(){    	
	$('#attachDivID').hide();
}

function uploadCallBack(){
	isBrowserClose=false;
}

function closeCallBack() {
	if (isBrowserClose) {
		unlockTask();
	}
}

function hightlightFieldError(element){
	   if(typeof element === 'undefined') return;
	   $(element).closest("div").addClass(errorClass).removeClass(validClass);	
}

function unhightlightFieldError(element){
	   if(typeof element === 'undefined') return;
	   $(element).closest("div").removeClass(errorClass).addClass(validClass);	
}

function isBlank(str) {
	   if(typeof str === 'undefined') return true;
	   if(str.val().trim()=="") return true;
	   return (!str || /^\s*$/.test(str));
}
