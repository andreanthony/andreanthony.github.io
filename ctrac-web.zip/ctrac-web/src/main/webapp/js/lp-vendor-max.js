var LpVendorMaxCheck = function(buildingClass, contentsClass, warningId, buildingMax, contentsMax) {
  var self = this;
  this.buildingClass = buildingClass;
  this.contentsClass = contentsClass;
  this.warningId = warningId;
  this.buildingMax = buildingMax;
  this.contentsMax = contentsMax;
  this.init = function() {
    $('.'+buildingClass).on('keyup change', function() {
        checkMaxValue(this.value, self.buildingMax);
    });
    $('.'+contentsClass).on('keyup change', function() {
        checkMaxValue(this.value, self.contentsMax);
    });
  };
  this.init();
    
  this.checkAllValues = function() {
      var hide = true;
      $('.'+self.buildingClass).each(function(index, input)  {
          if (valueExceedsMax(input.value, self.buildingMax)) {
              hide = false; return false;
          }
      });
      if(!hide){return;}
      $('.'+self.contentsClass).each(function(index, input)  {
          if (valueExceedsMax(input.value, self.contentsMax)) {
              hide = false; return false;
          }
      });
      if(hide){$('#'+self.warningId).hide();}
      else{$('#'+self.warningId).show();}
  };
  var dollarToNumber = function(dollar) {
      return dollar.replace(/\,/g, '');
  };
  var checkMaxValue = function(value, maxValue) {
      var warning = $('#'+self.warningId);
      if (valueExceedsMax(value, maxValue)) {
          warning.show();
      } else if (warning.is(':visible')) {
          // check if it needs to be hidden
          self.checkAllValues();
      }
  };
  var valueExceedsMax = function(value, maxValue) {
	  var number = dollarToNumber(value);
      if(isNaN(number)){number = 0;}
      return number > maxValue;
  };
};