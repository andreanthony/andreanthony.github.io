/**
 * Requires jQuery
 */

function Toggleable(modeOneSelector, modeTwoSelector) {
	this.modeOneSelector = modeOneSelector;
	this.modeTwoSelector = modeTwoSelector;
	this.modeOne();
}

Toggleable.prototype.modeOne = function() {
	$(this.modeTwoSelector).hide();
	$(this.modeOneSelector).show();
	this.mode = 1;
};

Toggleable.prototype.modeTwo = function() {
	$(this.modeOneSelector).hide();
	$(this.modeTwoSelector).show();
	this.mode = 2;
};

Toggleable.prototype.refresh = function() {
	if (this.mode===2) {
		this.modeTwo();
	} else {
		this.modeOne();
	}
}