var newWindow=null;
var selectedCheckBoxes=new Object();
var currentSelectedStatus='None';
var collateralListTable;
var host=window.location.protocol+"//"+window.location.host;

// Level 1 Search Variables
var collateralId="";
var loanNumber="";
var policyNumber="";
var name="";
var collateralType="";
var collateralStatus="";
var collateralDescription="";
var propertyAddress="";
var unitBuilding="";
var propertyCity="";
var propertyState="";
var propertyZipCode="";
var lineOfBusiness="";


//This won't be needed because the dashboard are mostly get methods
//and csrf is disabled for file upload
var csrfParameter = $("meta[name='_csrf_parameter']").attr("content");
var csrfHeader = $("meta[name='_csrf_header']").attr("content");
var csrfToken = $("meta[name='_csrf']").attr("content");
var cid= $("meta[name='_cid']").attr("content");


Object.size=function(obj){
    var size=0,key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) {
            size++;
        }
    }
    return size;
};

Object.getArray=function(obj){
    var array=[];
    for (key in obj) {
        if (obj.hasOwnProperty(key)) {
            array.push(obj[key]);
        }
    }
    return array;
};

//https://datatables.net/examples/basic_init/hidden_columns.html
function getData () {
    initializeSearchesLevel2();
    collateralListTable = $('#collateral-list-table').DataTable({
        serverSide: true,
        ajax: {
            url: 'collateralSearchResultAjax',
            type: 'GET',
            "data": function (d) {
                //Add all config/extra data here as a property of d
                d.totalSearchField = 10; //total number of searchable fields;
                
                // Search Level 1 Search
                d.collateralId = collateralId;
                d.loanNumber = loanNumber;                
                d.name = name;
                d.collateralType = collateralType;
                d.collateralStatus = collateralStatus;
                d.collateralDescription = collateralDescription;
                d.propertyAddress = propertyAddress;
                d.propertyCity = propertyCity;                
                d.propertyState = propertyState;
                d.propertyZipCode = propertyZipCode;
                d.lineOfBusiness = lineOfBusiness; 
                d.policyNumber = policyNumber;        
                d.unitBuilding = unitBuilding;
            } 
        },
        // WHEN ADDING A NEW COLUMN, UPDATE the param d.totalSearchField = 9   in the the ajax method above
        "columns": [
            { "data": "collateralId",		"targets": 0 },
            { "data": "lineOfBusiness",     "targets": 1 },
            { "data": "loanNumber",         "targets": 2 },
            { "data": "borrowerName",       "targets": 3 },
            { "data": "collateralType",     "targets": 4 },
            { "data": "propertyFullAddress","targets": 5 },
            { "data": "ownerName",         	"targets": 6 },
            { "data": "collateralStatus",   "targets": 7 },
            { "data": "policyNumber",   	"targets": 8 },
            { "data": "unitBuilding",   	"targets": 9 }
        ],
        "columnDefs": [
                       {
                           "targets": [ 8, 9 ],
                           "visible": false
                        }
                       ],
        "autoWidth" : false,
        "dom" : '<"col-md-12"<"pull-right"l>rtip>',
        "order": [[ 0, "asc" ]],
        "paging" : true,
        "lengthMenu" : [ 25,50,100,200 ],
        "lengthChange" : true, 
        
        initComplete : function () { // Move the search boxes to the top of the page
        	var r = $('#collateral-list tfoot tr');
        	$('#collateral-list thead').prepend(r);
            
            $('.dataTables_length label').css('display', 'inline');
        }
    });
    
    collateralListTable.on("draw", function(){
    	
    	    $("#collateral-list-data tr").on("click", function(){
    			var collateralID = $(this).children("td:first-child").text();
    			window.open("collateralDetails?collateralID="+collateralID);
    			//window.location = 'collateralDetails?collateralID='+collateralID;
		});
    });

}


function initializeSearchesLevel2() {
    // Apply the search
    var timer;

    // input propertychange are used to support clear (X) button in IE10 for text boxes
    $('.search-field').on('change paste keyup input propertychange',function(){
        clearInterval(timer);
        
        $('.search-field').each(function() {
            var searchKey=this.value;
            var thisTd=$(this).closest('th');
            var visIdx=$(thisTd).index();
            var colIdx=collateralListTable.column(visIdx).index();
            collateralListTable.column(colIdx).search(searchKey);
            
            // Set Level 1 Search Criteria
            var id = "#" + $(this).attr("id") + "_Search";
            $(id).text($(this).val());
        });
        timer = setTimeout(function(){
            collateralListTable.draw();
        }, 2000);
    });
    
}