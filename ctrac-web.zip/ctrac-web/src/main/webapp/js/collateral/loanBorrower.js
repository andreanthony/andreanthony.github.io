/**
 * JavaScript methods used for loan borrower section
 */

var LOAN_BORROWER = {};
var allowedEmailDomainNames = [ 'chase.com', 'jpmorgan.com', 'jpmchase.com' ];
var LoanBorrowerFormId ="loanBorrowerForm";
var submitOverlayUrl ="saveLoanBorrowerOverlay";
var LoanBorrowerOverlayFormId ="frmloanBorrowerModal";

var maxDate;

LOAN_BORROWER.verifyLoanBorrowerSection= function(e) {
	e.stopPropagation();
	e.preventDefault();
	$("input, select").prop('disabled', false); //need to talk to Aruna	
	$('.start-verification-loan-borrower').hide();
	$('.read-only-loan-barrower').hide();
	$('.editable-loan-barrower').hide();
	$('.verifycancel-loan-borrower').show();
	$('.deleteColumnLoanBorrowerDetails').show();	
};

LOAN_BORROWER.completeVerifyLoanBorrowerSection= function(e){
	e.stopPropagation();
	e.preventDefault();
	if ($("#loanBorrowerForm").valid()) {	
		LOAN_BORROWER.saveLoanBorrowerSectionInfo("verify");
		LOAN_BORROWER.setCompleteVerifyForLoanBorrower();
	}
};
LOAN_BORROWER.setCompleteVerifyForLoanBorrower = function(){
	$('.read-verification-loan-borrower').hide();
};

LOAN_BORROWER.editLoanBorrower = function(e, rid) {
	var title = 'Edit - Borrower /  Loan Information';
	e.stopPropagation();
	e.preventDefault();
	CTRAC_MODAL.launchLoanBorrowerModal(e, title, rid, "edit",maxDate);
};

LOAN_BORROWER.newLoanBorrower = function(e) {
	e.stopPropagation();
	e.preventDefault();
	$("#collateralLoanRID").val("");
	CTRAC_MODAL.launchLoanBorrowerModal(e, 'New - Borrower/ Loan Information', -1, "new",maxDate);
};

LOAN_BORROWER.closeModal = function(e) {
	e.preventDefault();
	e.stopPropagation();
	$("#ctracModal").modal('toggle');
};

LOAN_BORROWER.saveOrDelete = function(e, action, loanId) {
	e.stopPropagation();
	e.preventDefault();
	$("#action").val(action);
	$( "#frmloanBorrowerModal").validate();
    if(!$( "#frmloanBorrowerModal").valid() ){
       return;
    }
	var primary = $("#chkPrimaryLoan").is(':checked');
	var extraData = "&isPrimaryLoan=" + primary;
	var url = "saveLoanBorrower";
	var form = LoanBorrowerOverlayFormId;
	var callback = reloadSave;
	
	if(action == "delete") {
		var remove = confirm('Are you sure you want to remove this loan from this collateral?');
        if (remove == true) {
			extraData = "&action=delete&loanRid=" + loanId;
            url = "deleteLoanBorrower";
            form = LoanBorrowerFormId;
           	callback = deleteResponse;
		} else {
			return;
		}
	}
	
	if (action == "edit") {
		$("#btnLoanBorrowerSave").prop("disabled", true);
	} else if (action == "delete") {
		$("#btnLoanBorrowerDelete").prop("disabled", true);
	}
	
    makeARemotePost(url, form, extraData, callback);
};

LOAN_BORROWER.removeLoan = function(e, action, loanId) {
	e.stopPropagation();
	e.preventDefault();
	var url = "saveLoanBorrower";
	var form = loanMaintenanceForm;
	var callback = reloadSave;
	
	var remove = confirm('Are you sure you want to remove this loan from this collateral?');
    if (remove === true) {
		extraData = "&action=delete&loanRid=" + loanId;
        url = "deleteLoanBorrower";
        form = LoanBorrowerFormId;
       	callback = deleteResponse;
	} else {
		return;
	}
	$("#btnLoanBorrowerDelete").prop("disabled", true);
    makeARemotePost(url, form, extraData, callback);
};

function repaintLoanBorrowerSection(response, callback){
	$('#loanBorrowerDetails').replaceWith($(response).find('#loanBorrowerDetails'));
	LOAN_BORROWER.initializeVerificationMode($(response));
	LOAN_BORROWER.reInitializeLoanBorrowerSection();
	$("#chkInactiveLoanBorrwer").on("click", function () {
	    checkboxControl(this, $("#inactiveLoan"));
    });
	if (typeof(callback) == "function"){
		callback(response);
	}
}

LOAN_BORROWER.initializeVerificationMode = function (ele) {
	//Section is in start verification mode when Verify Mode is set to true on model object OR
	// when loanborrower section status is pending verification and the toggle mode set to 2 which means verify mode
	var inVerify = ele.find('#loanBorrowerVerifyMode').val()=='true' ||
		($('#loanBorrowerSectionPVStatus').length === 1 && LOAN_BORROWER.toggleable.mode === 2);
    setVerificationModeForLoanBorrowerSection(inVerify);
};

function reloadSave(response, callback) {
	$("#saveStatus").html("<strong>Success! </strong>Changes have been saved successfully.");
	$("#saveStatus").show();
	repaintLoanBorrowerSection(response);
	if (typeof(callback) == "function"){
    		callback(response);
    }
}

function deleteResponse(response, callback) {
	$('#loanModal').modal('hide');
	repaintLoanBorrowerSection(response);
	if (typeof(callback) == "function"){
    		callback(response);
    }
}

LOAN_BORROWER.initializeLoanBorrowerSection = function(ctracReferenceDate) {
	maxDate = ctracReferenceDate;

    $("#chkInactiveLoanBorrwer").on("click", function () {
        checkboxControl(this, $("#inactiveLoan"));
    });
	LOAN_BORROWER.toggleable = LOAN_BORROWER.toggleable || new Toggleable('#loanBorrowerVerificationRow .editMode', '#loanBorrowerVerificationRow .verifyMode');
	LOAN_BORROWER.initializeVerificationMode($('#loanBorrowerDetails'));
	LOAN_BORROWER.reInitializeLoanBorrowerSection();
};

LOAN_BORROWER.reInitializeLoanBorrowerSection = function() {	
	
	$("#btnStartVerificationLoanBorrowerSection").off("click").on("click", function(event) {				
		event.preventDefault();
		event.stopPropagation();
		$("#saveStatus").text("");
		$("#saveStatus").hide();
		setVerificationModeForLoanBorrowerSection(true);
	});
	
	$("#btnCancelVerificationLoanBorrowerSection").off("click").on("click", function(event) {
		if (confirm("Are you sure you want to cancel your verification?")) {
			setVerificationModeForLoanBorrowerSection(false);
		}
	});
	
	$("#btnCompleteVerificationLoanBorrowerSection").off("click").on("click", function(event) {
		var cid = $("meta[name='_cid']").attr("content");
		loanBorrowerToggleLoader(true);
		$.ajax({
			type : "POST",
			url : 'verifyLoanBorrower?cid='+cid,
			data : $('form#loanBorrowerForm').serialize(),
			success : function(response) {
				COLLSCREENAjaxError.reloadThecollateralScreen(null);
				loanBorrowerToggleLoader(false);
			},
			error : function(xhr, ajaxOptions, thrownError) {
				COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
			}
		});
	});	
};

function setVerificationModeForLoanBorrowerSection(verifyMode) {
	if (verifyMode) {
		$('#new-loan-Borrower').prop('disabled',true);
		LOAN_BORROWER.toggleable.modeTwo();
	} else {
        $('#new-loan-Borrower').removeAttr('disabled');
		LOAN_BORROWER.toggleable.modeOne();
	}
	$('#loanBorrowerVerifyMode').val(verifyMode);
}

function makeARemotePost(url,formID, extraData, callback ){
   var cid= $("meta[name='_cid']").attr("content");
   loanBorrowerToggleLoader(true);
   $.ajax({
        type: "POST",
        url: CTRAC.context+url+'?_cid='+cid+extraData,
        data: $( 'form#'+formID ).serialize(),
        success: function(response){
        	dataChanged=false;
	        if (typeof(callback) === "function"){
	        		 callback(response);
	        }
	        loanBorrowerToggleLoader(false);
        },
        error: function(xhr, ajaxOptions, thrownError) {
           	COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
        }
	});
}

//spinner
var opts = {
    color: '#ADD8E6', // #rgb or #rrggbb
    opacity: 2/4,     // Opacity of the lines
    lines: 12,        // The number of lines to draw
    length: 20,       // The length of each line
    width: 7,         // The line thickness
    radius: 20        // The radius of the inner circle
};
var spinner;
function loanBorrowerToggleLoader(on) {
	if (on) {
 		   target = document.getElementById('tableContentIDLoanBorrower');
 		   spinner = new Spinner(opts).spin(target);
		return;
	}
	if(spinner){
		spinner.stop();
	}
}
//spinner functionality

function handleCheck() {
	var primary = $("#chkPrimaryLoan").is(':checked');
    $("#isPrimaryLoan").val(primary);
}

jQuery.validator.addMethod("hasLoanBorrower", function(value, element) {
	var activeLoanCount = $("#loanBorrowerCount").val();
	var action = $("#action").val();
	if(action == "delete" && (activeLoanCount - 1) <= 0) {
		//deleting only one left
		return false;
	}
	return true;
},'');

jQuery.validator.addMethod("hasNonSBALoans", function(value, element) {	
	// if current loan is not non-SBA and primary is check and nonSBA loans exists then validation error
	var action = $("#action").val();
	var loanType = $("#loanType").val();
	var primary = $("#chkPrimaryLoan").is(':checked');
	
	if (action === "edit" && primary && nonSBALoanExists && loanType !== "Non SBA") {
		return false;
	}

	return true;
},'');

jQuery.validator.addMethod("hasChargedOffLoans", function(value, element) {
	// if current loan is not non-SBA and not Charged Off and primary is check and
	// Non-SBA doesn't exist and Charged Off loans exists then validation error
	var action = $("#action").val();
	var loanType = $("#loanType").val();
	var primary = $("#chkPrimaryLoan").is(':checked');
	
	if (action === "edit" && primary && !nonSBALoanExists && chargedOffLoanExists &&
		loanType !== "Non SBA" && loanType !== "Charged Off") {
		return false;
	}
	
	return true;
},'');

jQuery.validator.addMethod("hasPrimaryDelete", function(value, element) {
	var activeLoanCount = $("#loanBorrowerCount").val();
	var action = $("#action").val();
	var primary = $("#chkPrimaryLoan").is(':checked');
	if(action =="delete" && primary) {
		//deleting the primary loan when there isn't another primary defined.
		return false;
	}
	return true;
},'');

jQuery.validator.addMethod("hasPrimarySave", function(value, element) {
	var activeLoanCount = $("#loanBorrowerCount").val();
	var action = $("#action").val();
	var primaryOnSubmit = $("#chkPrimaryLoan").is(':checked');
	var primaryOnLoad = $("#primaryInitially").val() == "true" ? true : false;
	if(action === "edit" && (activeLoanCount - 1) <= 0 && !primaryOnSubmit) {
		//new one, and is not selected as primary, so force as primary
		return false;
	}
	if(action === "edit" && primaryOnLoad && !primaryOnSubmit) {
    		//this was the primary now deselecting it (meaning no others are primary at this time)
    	return false;
    }
	return true;
},'');