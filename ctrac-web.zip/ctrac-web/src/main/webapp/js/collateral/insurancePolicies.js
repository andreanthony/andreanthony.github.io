/**
 * JavaScript methods used for Insurance Policies section
 */

INSURANCE_POLICIES = {
	editMode   : false,
	verifyMode : false
};

INSURANCE_POLICIES.viewPolicy = function(e, policyType, rid, status, numDocs) {
    var isLpPolicy = policyType === 'LP' || policyType === 'LP_GAP' || policyType === 'LP_EXCESS';
    var prefix = INSURANCE_POLICIES.editMode ? 'Edit' : 'View';
    var title = prefix + (isLpPolicy ? ' - Lender Placed Insurance Policy' : ' - Borrower Insurance Policy');
    var show = isLpPolicy ? '.lp-policy-field' : '.borrower-policy-field';
    var hide = isLpPolicy ? '.borrower-policy-field' : '.lp-policy-field';
    if (isLpPolicy) {
    	CTRAC_MODAL.launchPolicyModal(e, title, show, hide, rid, status, numDocs);
    } else {
    	window.open(CTRAC.root+'bir/launchBIROverlay?policyRid='+rid+
    			'&collateralRid='+CTRAC.collateralRID+'&mode='+INSURANCE_POLICIES.toggleable.mode,
    			'_blank','menubar=no,toolbar=no,scrollbars=yes,resizable=yes');
    }
};

INSURANCE_POLICIES.removePolicy = function(e, collateralId, policyId, policyNumber) {
	e.stopPropagation();
    e.preventDefault();
    var remove = confirm('Are you sure you want to remove policy "' + policyNumber + '" from this collateral?');
    if (remove === true) {
    	$('#insuranceSectionCollateralId').val(collateralId);
        $('#insuranceSectionPolicyId').val(policyId);
        var form = $('#policySectionForm');
        form.find('input').removeAttr('disabled');
        $.ajax({
        	type: form.attr('method'),
            url: form.attr('action'),
            data: form.serialize(),
            cache: false,
            success: function(data) {
            	CTRAC_MODAL.postSubmit();
            },
       		error: function(xhr, ajaxOptions, thrownError) {
       			COLLSCREENAjaxError.ajaxErrorProcessing(thrownError)
       		}
        });
    }
};

INSURANCE_POLICIES.overridePolicy = function(e) {
	e.preventDefault();
	var policyRid = $("#collateralScreenNewInsurancePolicyModal #policy-rid").val();
	CTRAC_MODAL.launchOverridePolicyModal(
            e, 'Override - Lender Placed Insurance Policy', '.lp-policy-field', '.borrower-policy-field', policyRid, 'NEW');
};

INSURANCE_POLICIES.newBorrowerInsuranceReview = function(e) {
	e.preventDefault();
	window.open(
			CTRAC.root+'bir/launchBIROverlay?policyRid=-1&collateralRid='+CTRAC.collateralRID+'&mode=0',
			'_blank','menubar=no,toolbar=no,scrollbars=yes,resizable=yes');
};

INSURANCE_POLICIES.newBorrowerPolicy = function(e) {
    CTRAC_MODAL.launchPolicyModal(
            e, 'New - Borrower Insurance Policy', '.borrower-policy-field', '.lp-policy-field', -1, 'NEW');
};

INSURANCE_POLICIES.newLPPolicy = function(e) {
    CTRAC_MODAL.launchPolicyModal(
            e, 'New - Lender Placed Insurance Policy', '.lp-policy-field', '.borrower-policy-field', -1, 'NEW');
};

INSURANCE_POLICIES.startVerification = function(e) {
	e.preventDefault();
	$('#insurance-policies-buttons a').attr('disabled', 'disabled');
	INSURANCE_POLICIES.toggleable.modeTwo();
};

INSURANCE_POLICIES.completeVerification = function(e) {
	if (e) {
		e.preventDefault();
	}
	INSURANCE_POLICIES.toggleable.modeOne();
	
	// LCP-3411 - we don't need to toggle buttons. Section refresh will take care of proper button state.
    // it takes sometime to get the ajax result. during that time incorrect button is displayed. It is better to hide both button until we get the result
    $("#btnInsuranceStartVerification").hide();
    $("#btnInsuranceCompleteVerification").hide();
    
	$('#insurance-policies-buttons a').removeAttr('disabled');
	var cid=$("meta[name='_cid']").attr("content");
	var csrf=$("meta[name='_csrf']").attr("content");
	$.ajax({
    	method: 'POST',
    	url: CTRAC.context+'verifyInsurancePoliciesSection?_cid='+cid+'&_csrf='+csrf,
        success: function(data) {
        	CTRAC_MODAL.reloadSection();
        },
   		error: function(xhr, ajaxOptions, thrownError) {
   			COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
   		}
    });
};



INSURANCE_POLICIES.initializeInsurancePoliciesSection = function(previousToggleMode) {
	// FIXME: make editMode dynamic based on user entitlements
    INSURANCE_POLICIES.editMode = true;
    $('#new-bir').click(INSURANCE_POLICIES.newBorrowerInsuranceReview);
    $('#new-borrower-policy').click(INSURANCE_POLICIES.newBorrowerPolicy);
    $('#new-lp-policy').click(INSURANCE_POLICIES.newLPPolicy);
    INSURANCE_POLICIES.toggleable = new Toggleable('#insuranceSectionRow .defaultMode', '#insuranceSectionRow .verifyMode');
    if (previousToggleMode !== undefined) {
        INSURANCE_POLICIES.toggleable.mode = previousToggleMode;
        INSURANCE_POLICIES.toggleable.refresh();
    }
    INSURANCE_POLICIES.refresh();
    $('.btn-unclickable').click(function(e) {
    	e.preventDefault();
    });
};

INSURANCE_POLICIES.refresh = function() {
	$("#chkInactive").on("click", function () {
	    checkboxControl(this, $("#inactiveInsurance"));
    });
};

INSURANCE_POLICIES.addCollateralToPolicy = function(e) {
	e.preventDefault();
	var collateralID = $("#collateral-id").val();
	if (collateralID.trim() === "") {
		alert("Collateral ID Cannot Be Blank.");
	} else {
	   var cid= $("meta[name='_cid']").attr("content");
	   $.ajax({
	        type: "GET",
	        url: 'addCollateralToPolicy?_cid='+cid+"&collateralId="+collateralID,
	        data: $('form#policyForm').serialize(),		        
	        success: function(response) {
	        	// Arun: TODO: Consider access only if certain successful keyword is found in the response. 
	        	// This to prevent errors like - "CTRAC - ACCESS DENIED"
	        	if (response.indexOf("ACCESS DENIED") > -1) {
	        		alert("CTRAC - Access Denied.");
	        	}
	        	var errorText = $(response).find('#proofOfCoverageMessage');
	        	if (errorText.text().length > 0) {
	        		$('.modal-body').prepend(errorText);
	        	} else {
	        		CTRAC_MODAL.settings.reload = true;
	        		$("#collateral-id").val('');
		        	$('#collateralPolicyCoverageTable').append($(response).find('#collateralCoverageTable' + collateralID));
		        	hideShowFieldsBasedOnBlanketCoverageType();
		        	initInsurancePoliciesFormValidation();
	        	}
	        },
	   		error: function(xhr, ajaxOptions, thrownError) {
	   			// Exception if proper record not found for CollateralID
	   			alert(xhr.status + " thrownError: " + thrownError);
	   			COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
	   		}
	    });
	}
};

INSURANCE_POLICIES.policyMouseOver = function(event) {
	var obj = $(event.target).parents("tr");
	
	$(obj).addClass("highlightRow");
	
	var selectedPolicyRid = $(obj).children(".policyRid").text();
	$("#workflowTable").find(".workflowStepPolicyRid").each(function() {
		if ($(this).text().indexOf("(" + selectedPolicyRid + ")") > -1) {
			$(this).parent().addClass("highlightRow");
		}
	});
};

INSURANCE_POLICIES.policyMouseOut = function(event) {
	var obj = $(event.target).parents("tr");
	
	$(obj).removeClass("highlightRow");
	
	var selectedPolicyRid = $(obj).children(".policyRid").text();
	$("#workflowTable").find(".workflowStepPolicyRid").each(function() {
		if ($(this).text().indexOf("(" + selectedPolicyRid + ")") > -1) {
			$(this).parent().removeClass("highlightRow");
		}
	});
};

INSURANCE_POLICIES.initializeNewInsurancePolicy = function() {
    $(".datepicker").each(function (){
        CTRAC_MODAL.initializeDatepicker('.datepicker');
    });

    setRequiredForLetterCycleFields();    
    $("#letterCycleWorkflowStep").off("change").on("change", setRequiredForLetterCycleFields);
    $("#lenderPlaceReason").off("change").on("change", setRequiredForlenderPlaceReasonFields);
    $("#policyType").off("change").on("change", setCoverageType);
    $("#firstLetterDate").off("change").on("change", setSecondLetterDate);

    function setRequiredForLetterCycleFields() {
        var letterCycleWorkflowStep = $("#letterCycleWorkflowStep");
        var lenderPlaceReason = $("#lenderPlaceReason");
        var parentPolicyRid = $("#parentPolicyRid");
        var firstLetterDate = $("#firstLetterDate");
        var secondLetterDate = $("#secondLetterDate");
        var marketEmailNeeded = $("#marketEmailNeeded");
    	var refDate = addDays(new Date($("#expDateHidden").val()), 0);
        if (letterCycleWorkflowStep.val() === "" || letterCycleWorkflowStep === undefined) {
            lenderPlaceReason.attr('readonly', true).removeClass("required");
            parentPolicyRid.attr('readonly', true).removeClass("required").val("");
            firstLetterDate.attr('readonly',true).removeClass("required").val("");
            secondLetterDate.attr('readonly',true).removeClass("required").val("");
            marketEmailNeeded.attr('disabled', true).prop('checked',false);
        }
        else {
            parentPolicyRid.attr('readonly', false);
            lenderPlaceReason.attr('readonly', false).addClass("required");
            marketEmailNeeded.attr('disabled', false).prop('checked',true);
            if (letterCycleWorkflowStep.val() === "SEND_FIRST_LP_LETTER") {
	            firstLetterDate.attr('readonly',true).addClass("required").val(refDate);
	            secondLetterDate.attr('readonly',true).removeClass("required").val("");
            }
            if (letterCycleWorkflowStep.val() === "SEND_SECOND_LP_LETTER") {
	            firstLetterDate.attr('readonly',false).addClass("required");
	            secondLetterDate.attr('readonly',true).removeClass("required");
	            setSecondLetterDate();
            }
            if (letterCycleWorkflowStep.val() === "PENDING_FOR_ALTHANS") {
	            firstLetterDate.attr('readonly',false).addClass("required");
                secondLetterDate.attr('readonly',false).addClass("required");
            }
        }
     }
        
    function setRequiredForlenderPlaceReasonFields() {
        if ($("#lenderPlaceReason").val().indexOf('BORROWER_POLICY') === 0){
            $("#parentPolicyRid").addClass("required");
        } else {
            $("#parentPolicyRid").removeClass("required");
        }
    }
    
    function setCoverageType() {
        if ($("#policyType").val() === "LP_EXCESS"){
            $("#coverageType").val("EXCESS");
        } else {
            $("#coverageType").val("PRIMARY");
        }
    }

    function setSecondLetterDate() {
        if ($("#letterCycleWorkflowStep").val() === "SEND_SECOND_LP_LETTER") {
        	if($("#firstLetterDate").val() !== "" && validDateFormat($("#firstLetterDate").val())){
                $("#secondLetterDate").val(addDays(new Date($("#firstLetterDate").val()), 30));
        	}
        	else {
        		$("#secondLetterDate").val("");
        	}
        } 
    }

};

