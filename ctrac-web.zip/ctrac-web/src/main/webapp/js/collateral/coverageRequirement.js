
/*<![CDATA[ */
//<script th:inline="javascript">
/**
 * JavaScript methods used for Insurance Policies section
 */
var COVERAGE_REQUIREMENT = {};

COVERAGE_REQUIREMENT.editMode=false;

COVERAGE_REQUIREMENT.dirty=false;
COVERAGE_REQUIREMENT.initializeRequiredCoverageSection = function(){
     $('#new-required-insurance-coverage').click(function(e){
         var fiatDocId =-1;//TODO find the doc id from the html dom
         CTRAC_MODAL.launchCovergeModal(e, fiatDocId, 'new', function (){COVERAGE_REQUIREMENT.initializeAllEvents('new');}  );
     });

     $("#requiredInsuranceCoverageSection").on("click", ".editable-fiat-div", function(e){
          e.preventDefault();
          e.stopPropagation();
            var fiatDocId =$(this).find("#fiatId").val();
            CTRAC_MODAL.launchCovergeModal(e, fiatDocId, 'edit', function (){COVERAGE_REQUIREMENT.initializeAllEvents('edit');}  );
     });

     $("#requiredInsuranceCoverageSection").on("click", ".fiat-div-no-edit", function(e){
          e.preventDefault();
          e.stopPropagation();
            var fiatDocId =$(this).find("#fiatId").val();
            CTRAC_MODAL.launchCovergeModal(e, fiatDocId, 'display', function (){COVERAGE_REQUIREMENT.initializeAllEvents('display');}  );
     });

     $('.display-coverage-req').click(  function(e){
          e.preventDefault();
          e.stopPropagation();
         var fiatDocId = $(this).attr("data-fiatDocId");
         CTRAC_MODAL.launchCovergeModal(e, fiatDocId, 'display', function (){COVERAGE_REQUIREMENT.initializeAllEvents('display');}  );
     });

     $('#verifyFiatStart').click(function(e){
          e.preventDefault();
          e.stopPropagation();
         var fiatDocId =-1;//TODO find the doc id from the html dom
         CTRAC_MODAL.launchCovergeModal(e, fiatDocId, 'verify', function (){COVERAGE_REQUIREMENT.initializeAllEvents('verify');}  );
     });

     // Required Coverage
     $("#chkInactiveRequiredCoverage").on("click", function () {
          checkboxControl(this, $("#inactiveRequiredCoverage"));
     });

    // Hold History
    $("#holdHistoryLaunchBtn").on("click", function (e) {
        CTRAC_HOLDS.launchHistoryModal(e);
    });

};
var submitVerifycoverageUrl='saveCoverageRequirement';


COVERAGE_REQUIREMENT.initializeAllEvents = function( action ) {
    $("#ctracModal .modal-title").text(pageTile[action]);
    $(".updataAction").on("click", function(e) {
        COVERAGE_REQUIREMENT.dirty = true;}
    );
    //track when section need to be reloaded from db

    $("#ctracModal").on('hidden.bs.modal', function (e) {
      e.preventDefault();
      e.stopPropagation();
      $(this).off('hidden.bs.modal');
      if(COVERAGE_REQUIREMENT.dirty){
          discardDrafData();
      }
    });

    if(action ==='new' || action==='edit' ||  action==='verify' ){
        COVERAGE_REQUIREMENT.disableDescopedBuildings();
        if(action === "verify"){
            $(".verifDisabled").hide();
            $("#newReqCoveModalSave").prop('value', "Save and Verify");
            $('.submitCmd').removeAttr("disabled");
            setupFormSubmitButton("newReqCoveModalSave", CTRAC.root+'admin/'+submitVerifycoverageUrl, "", verifyRequiredCoveragePostOperation );
        }else{
            initEmailAttachments(COVERAGE_REQUIREMENT.pageConfig, COVERAGE_REQUIREMENT.uploadifyConfig);
        }

        CTRAC_MODAL.initializeDatepicker ('#req-cov-document-date', new Date($("#minDocumentDateHidden").val()), new Date($("#maxDocumentDateHidden").val()));
        CTRAC_MODAL.initializeDatepicker ('#req-cov-can-effective-date');
        $("#req-cov-can-effective-date").datepicker();

        ENABLE_ON_EDIT.init('coverageRequirementForm', '#newReqCoveModalSave');

        validateCoverageRequirementForm();

        enableAmountFormatting('#tableContentID');
        if(action ==='new') {
            $("#newReqCoveModalDelete").hide();
        } else {
            $("#newReqCoveModalDelete").show();
        }
    }else{
        COVERAGE_REQUIREMENT.disableAllCommand();
    }

};

COVERAGE_REQUIREMENT.displayConfirmMessage = function  (data, message ){

    if(message == null){
        message =  '<div class="alert alert-success"> <strong> Success!</strong> The coverage requirement was successfully saved</div>';
    }

    $('#messageWrapper').append( message );

    COVERAGE_REQUIREMENT.dirty = false;
    dataChanged=false;

    reloadRequiredCoverageSection(data, COVERAGE_REQUIREMENT.initializeRequiredCoverageSection);
    COVERAGE_REQUIREMENT.disableAllCommand();
    $(".attachDiv").html('the documents were uploaded successfully ...');
};

COVERAGE_REQUIREMENT.disableAllCommand = function(){
    $("input:not(#chkInactive), select").prop('disabled', true);
    $(".cmdBlock").hide();
    //$(".attachDiv").html('the documents were uploaded successfully ...')
    $(".alwaysActive").prop('disabled', false);
    $("#newReqCoveModalCancel").prop('value', "Close");
    if(CTRAC.readOnlyUserRole){
        $("#chkDescoped").prop('disabled', true);
    }
};

COVERAGE_REQUIREMENT.initCopyDataEventListener = function(){
    $(".req-cov-copy-data-link").on("click", function () {
        var targetCoverageElementId = $(this).attr('data-coverage-target');
        var targetBalanceTypeElementId = $(this).attr('data-balancetype-target');
        var skipBalanceTypeCopy = $(this).attr('data-skip-balancetype') === 'true';
        var skipCoverageCopy = $(this).attr('data-skip-coverage') === 'true';

        if(!skipCoverageCopy && targetCoverageElementId !== ''){
            var target = $('#'+targetCoverageElementId);
            target.val($(this).attr('data-coverage-value')).autoNumeric('init')
                .parent().removeClass('has-error').removeClass('text-danger');
            target.change();
        }
        if(!skipBalanceTypeCopy && targetBalanceTypeElementId !== ''){
            $('#'+targetBalanceTypeElementId).val($(this).attr('data-balancetype-value'))
                .parent().removeClass('has-error').removeClass('text-danger');
        }

        $('.submitCmd').removeAttr("disabled");
    });
};

COVERAGE_REQUIREMENT.toggleRow = function(element) {
    var val = element.value;
    if (val !== '') {
        $('.' + val).toggle();
    }
    element.value = '';
};

COVERAGE_REQUIREMENT.showIfValues = function(myClass) {
    $('#coverageRequirementForm').find('tbody').each(function (index, element) {
        var excessFields = $(element).find('.' + myClass + '-check');
        for (var i = 0; i < excessFields.length; i++) {
            var elRowDataSelector = $(excessFields[i]).attr('data-row-selector');
            if(elRowDataSelector !== undefined){
                $(element).find('.' + elRowDataSelector).show();
                continue;
            }
            var val = excessFields[i].value;
            if (val === 'ACV' || val === 'RCV') {
                $(element).find('.tg-' + myClass + '-' + index).show();
                return;
            }
            val = getFloatFromString(excessFields[i].value);
            if (!isNaN(val) && val !== 0) {
                $(element).find('.tg-' + myClass + '-' + index).show();
                return;
            }
        }
    });
};

COVERAGE_REQUIREMENT.handleHoldRow = function(btn, init) {
    var inputs = btn.closest('tr').find('.hold-input'), required = btn.siblings('.holdRequired').first(), holds;
    if (!init || (init && required.val() === 'true')) {
        btn.toggleClass('btn-warning');
    }
    required.val(btn.hasClass('btn-warning') ? 'true' : 'false');
    holds = btn.closest('tr').find('.hold-btn.btn-warning');
    if (holds.length > 0) {
        inputs.removeAttr("disabled");
    } else {
        inputs.attr("disabled", "disabled");
    }
};

COVERAGE_REQUIREMENT.handleHoldCols = function(btn) {
    var table = btn.closest('table'), holds = table.find('.hold-btn.btn-warning'), cols = table.find('.hold-col');
    cols.toggle(holds.length > 0);
};

COVERAGE_REQUIREMENT.findAcvRcv = function(element, className) {
    return $(element).closest('tr').find(className);
};

COVERAGE_REQUIREMENT.initExcessAndBusinessIncome = function() {
    $('.tg-dropdown').change(function() {
        COVERAGE_REQUIREMENT.toggleRow(this);
    });
    COVERAGE_REQUIREMENT.showIfValues('excess');
    COVERAGE_REQUIREMENT.showIfValues('business-income');
    COVERAGE_REQUIREMENT.showIfValues('copy-link');

    $("#reqCovScrollable").scroll(function() {
        var translate = "translate(0," + this.scrollTop + "px)";
        this.querySelector("thead").style.transform = translate;
    });

    $('.hold-btn').click(function() {
        COVERAGE_REQUIREMENT.handleHoldRow($(this), false);
        COVERAGE_REQUIREMENT.handleHoldCols($(this));
    });

    $('.hold-btn').each(function() {
        COVERAGE_REQUIREMENT.handleHoldRow($(this), true);
    });

    COVERAGE_REQUIREMENT.handleHoldCols($('.hold-btn').first());
    CTRAC_MODAL.initializeDatepicker('.hold-date', null, new Date($("#maxDocumentDateHidden").val()));

    COVERAGE_REQUIREMENT.initAcvRcvDependency('.buildingAmount,.buildingExcessAmount', '.buildingBalanceType');
    COVERAGE_REQUIREMENT.initAcvRcvDependency('.contentAmount,.contentExcessAmount', '.contentBalanceType');
    COVERAGE_REQUIREMENT.initAcvRcvDependency('.buildingExcessValue', '.buildingExcessBalanceType');
};

COVERAGE_REQUIREMENT.initAcvRcvDependency = function(amountClass, balanceTypeClass) {
    $(amountClass).each(function(index, element) {
        var acvRcvDependency = new DependentField(element, DEPENDENT_FIELD.positiveAmount, COVERAGE_REQUIREMENT.findAcvRcv(element, balanceTypeClass));
        acvRcvDependency.init();
    });
};

var addBuildingUrl='editCoverageRequirement/update';

function addOneInsurableAssetRow(collateralId){
    var extraData = "&action=addRow&collateralId="+collateralId+"&sortOrder="+-1;
    dataChanged=true;
    COVERAGE_REQUIREMENT.makeRemotePost(addBuildingUrl, extraData, COVERAGE_REQUIREMENT.replaceTableContentDiv);
    return false;
}

function deScopeBuildingRow(elem, collateralId, sortOrder){
    var elementsToToggle = $(elem).parents('.table-line').find('select, input').not(':input[type=hidden]');
    var deScopePair = $(elem).closest('td').find('.deScopedChkPairHidden');
    var descopeValue = deScopePair.val();
    if('Yes' === descopeValue){
        $(deScopePair).val('No');
    }else{
        $(deScopePair).val('Yes');
    }
    $(deScopePair).change();
    descopeValue = deScopePair.val();
    elementsToToggle.each(function(index, ele) {
        var element = $(ele);
        if ($.inArray(this.type,['radio','checkbox']) !== -1) {
            //do nothing
        }else {
            if('Yes' === descopeValue ){
                element.attr('readonly',true);
                if (element.hasClass('buildingAmount') || element.hasClass('contentAmount') || element.hasClass('buildingExcessAmount') || element.hasClass('contentExcessAmount')) {
                    $(element).val('0.00');
                }
            }else{
                element.attr('readonly',false);
            }
        }
    });
    enableDisableField();
}

function enableDisableField(){
    var enable = false;
    $('.deScopedChkPairHidden').each(function() {
        var deScopePair = $(this);
        var descopeValue = deScopePair.val();
        if('Yes' === descopeValue ){
            enable = true;
        }
    });
    if(enable){
        $("#req-cov-can-effective-date").attr('readonly',false);
    }else{
        $("#req-cov-can-effective-date").attr('readonly',true);
    }
}

COVERAGE_REQUIREMENT.disableDescopedBuildings = function() {
    $('.deScopedChkPairHidden').each(function() {
        var deScopePair = $(this);
        var descopeValue = deScopePair.val();
        var elementsToToggle = $(deScopePair).parents('.table-line').find('select, input').not(':input[type=hidden]');
        elementsToToggle.each(function(index, ele) {
            var element = $(ele);
            if ($.inArray(this.type,['radio','checkbox']) !== -1) {
                //do nothing
            }else {
                if('Yes' === descopeValue ){
                    element.attr('readonly',true);
                    if (element.hasClass('buildingAmount') || element.hasClass('contentAmount')) {
                        $(element).val('0.00');
                    }
                }else if (element.hasClass('balanceType')) {
                    element.attr('readonly',false);
                }
            }
        });
    });
    enableDisableField();
};

var deleteBuildingUrl='editCoverageRequirement/update';

function deleteBuildingAnRefresh(collateralId, sortOrder){
    var extraData = "&action=deleteRow&collateralId="+collateralId+"&sortOrder="+sortOrder;
    dataChanged=true;
    COVERAGE_REQUIREMENT.makeRemotePost( deleteBuildingUrl, extraData, COVERAGE_REQUIREMENT.replaceTableContentDiv );
    return false;
}


function setupFormSubmitButton(buttonId, submitUrl, extraData, callback ){
     $('#'+buttonId).off("click").click( function(e){
         e.preventDefault();
         if(! $("#coverageRequirementForm").valid() ){
            return;
         }
         $(this).attr('disabled', 'disabled').clearQueue();
         COVERAGE_REQUIREMENT.makeRemotePost(submitUrl,extraData,callback );
         return false;
     });
}


function verifyRequiredCoveragePostOperation ( data ){
    var pageID = $('<div/>').append(data);
    //we still on the req. cov page mean mismatch preparation
    if($(pageID).find('#coverageRequirementTable').length) {
        COVERAGE_REQUIREMENT.replaceTableContentDiv(data); //in fact there aren't any race conditions between the operations below
        COVERAGE_REQUIREMENT.dirty = true;
        ENABLE_ON_EDIT.init('coverageRequirementForm', '#newReqCoveModalSave');
        COVERAGE_REQUIREMENT.disableDescopedBuildings();
        setupFormSubmitButton("newReqCoveModalSave", CTRAC.root+'admin/'+submitVerifycoverageUrl, "", verifyRequiredCoverageMisMachPostOperation );
        validateCoverageRequirementForm();
        COVERAGE_REQUIREMENT.initCopyDataEventListener();
        COVERAGE_REQUIREMENT.initExcessAndBusinessIncome();
    }else{
        //we are done! do as if this was a missmatch submit
        verifyRequiredCoverageMisMachPostOperation(data);
    }
}

function verifyRequiredCoverageMisMachPostOperation ( data ){
     var message =  '<div class="alert alert-success"> <strong> Success!</strong> The coverage requirement was successfully Verified </div>';
     COVERAGE_REQUIREMENT.displayConfirmMessage(data, message);
     COVERAGE_REQUIREMENT.disableAllCommand();
     $(".attachDiv").html('the documents were uploaded successfully ...');
}


function deleteAllAndRefresh(){
     if(!confirm("Are you sure you want to delete all the coverage requirements?")){
         return false;
     }
     var extraData = "&action=deleteAll&collateralId="+-1+"&sortOrder="+0; //collateralId and sort order don't matter here
     var deleteCallback = function(data){ reloadRequiredCoverageSection(data,closeOverlayAndReinitialize);};
     COVERAGE_REQUIREMENT.makeRemotePost( deleteBuildingUrl, extraData, deleteCallback );
}

COVERAGE_REQUIREMENT.makeRemotePost = function(url,extraData, callback ){
   var cid= $("meta[name='_cid']").attr("content");
    var csrf=$("meta[name='_csrf']").attr("content");
   toggleLoader(true);
   $.ajax({
        type: "POST",
        url: url+'?_cid='+cid+'&_csrf='+csrf + extraData,
        data: $('form#coverageRequirementForm').serialize(),
        success: function(response){
            if (typeof(callback) == "function"){
                callback(response);
            }
            toggleLoader(false);
        },
        error: function(xhr, ajaxOptions, thrownError) {
            COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
        }
    });
};


function enableAmountFormatting(id){
    $(id).on('click',"input.numeric", function() { $(this).select(); }).on('focus' , "input.numeric", function(){ $(this).autoNumeric('init'); });
}

COVERAGE_REQUIREMENT.replaceTableContentDiv = function(response){
    $('#tableContentID').replaceWith( $(response).find('#tableContentID') );
    enableAmountFormatting('#tableContentID');

    $('#tableContentID').find('input, select, textarea').change(function() {
        $(this).removeAttr('disabled');
    });

    COVERAGE_REQUIREMENT.initExcessAndBusinessIncome();
    validateCoverageRequirementForm();
};

function reloadRequiredCoverageSection(response, callback){
    $('#requiredInsuranceCoverageSection').replaceWith( $(response).find('#requiredInsuranceCoverageSection') );
    if (typeof(callback) == "function"){
        callback(response);
    }
}

function closeOverlayAndReinitialize (){
    COVERAGE_REQUIREMENT.initializeRequiredCoverageSection();
    $("#ctracModal").modal("hide");
}

function discardDrafData(){
     var extraData = "&action=discard-draft&collateralId="+-1+"&sortOrder="+-1;
     COVERAGE_REQUIREMENT.makeRemotePost(addBuildingUrl, extraData, COVERAGE_REQUIREMENT.replaceTableContentDiv);
}

function updateExcessSection(element){
    var buildingAmount = getFloatFromString($('.buildingAmount').val());
    if(element === 'excessRequiredYes'){
        if(buildingAmount>0){
            $('#coverageRequirementTable')
            .find(".buildingExcessAmount")
            .attr("readonly",false);
            $('#excessBuildingBalanceType')
            .attr("readonly",false);
            var buildingExcessAmount = getFloatFromString($('.buildingExcessAmount').val());
            if(buildingExcessAmount>0){
                $('#coverageRequirementTable')
                .find(".contentExcessAmount")
                .attr("readonly",false);
                $('#excessContentBalanceType')
                .attr("readonly",false);
            }
        }
    }else if(element === 'excessRequiredNo'){
        $('#coverageRequirementTable')
        .find(".buildingExcessAmount")
        .attr("readonly",true);
        $('#excessBuildingBalanceType')
        .attr("readonly",true);
        $('#coverageRequirementTable')
        .find(".contentExcessAmount")
        .attr("readonly",true);
        $('#excessContentBalanceType')
        .attr("readonly",true);
    }
}
/*]]>*/
//</script>
