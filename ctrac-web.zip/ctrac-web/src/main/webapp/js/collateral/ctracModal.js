/**
 *
 */

var CTRAC_MODAL = {};

CTRAC_MODAL.settings = {
    title: "",
    show: "",
    hide: "",
    rid: "",
    status: "",
    numDocs: 0,
    reload: false
};

CTRAC_MODAL.postSubmit = function() {
    CTRAC_MODAL.settings.reload = false;
    CTRAC_MODAL.initializeUploadify(1);
    $('#proofOfCoverageMessage').hide();
    $('#policySaveSuccess').show();
    CTRAC_MODAL.reinitModal();
    CTRAC_MODAL.reloadSection();
};

CTRAC_MODAL.submitErrorHandler = function(thrownError, xhr) {
    ALL_SECTIONS.handleFormSubmissionFailures(thrownError, xhr, "#" + CTRAC_MODAL.pageConfig.emailFormID);
    CTRAC_MODAL.initializeUploadify(1);
    initEmailAttachments(CTRAC_MODAL.pageConfig, CTRAC_MODAL.uploadifyConfig);
    ENABLE_ON_EDIT.init('collateralScreenNewInsurancePolicyModal',
        $('#policySave').length === 1 ? '#policySave' : '#policySaveAndVerify');
};

CTRAC_MODAL.reloadSection = function() {
    var cid= $("meta[name='_cid']").attr("content");

    // LCP-3411 - we don't need to toggle buttons. Section refresh will take care of proper button state.
    // it takes sometime to get the ajax result. during that time incorrect button is displayed. It is better to hide both button until we get the result
    $("#btnInsuranceStartVerification").hide();
    $("#btnInsuranceCompleteVerification").hide();

    $.ajax({
        url: CTRAC.context+'getInsuranceSection?_cid='+cid,
        cache: false,
        success: function(data) {
            var policyTables = $(data).find('#policyTables');
            dataChanged = false;
            $('#policyTables').replaceWith(policyTables);
            if ($(data).find('#insuranceSectionVerify').length === 0) {
                INSURANCE_POLICIES.toggleable.modeOne();
                $('#insurance-policies-buttons a').removeAttr('disabled');
            } else {
                INSURANCE_POLICIES.toggleable.refresh();
            }
            INSURANCE_POLICIES.refresh();
        },
        error: function(xhr, ajaxOptions, thrownError) {
            COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
        }
    });
};

CTRAC_MODAL.pageConfig = {
    taskUUId : taskUUId,
    cmdClass : 'submitCmd',
    attachDivID : 'insurance-upload-container',         // div containing browse button
    inputFileID : 'insurance-upload',            // id of the file input form
    AttachmentErrMs : 'insurancePolicyAttachmentErrMs',  // div that displays attachment error message
    emailFormID : 'policyForm',  // id of the email form (global from)
    maxTotalQueueSize : '10MB',             // limit on the sum of the size of all files in the queue in MB or KB
    loaderDivID : 'container',              // where to show the spin loader
    allowEmptyAttachement: false,            // allow no attachments
    emptyFileErrMsg: "An insurance policy file is required to be attached. Please attach the document.",
    appendGyfon: true,
    allDoneCallBack: uploadCallBack,
    asynch:true,
    submitCallBack: CTRAC_MODAL.postSubmit,
    submitErrorCallBack: CTRAC_MODAL.submitErrorHandler,
    uploadMinimun: 1
};

CTRAC_MODAL.uploadifyConfig = {
    'formData'     : { 'taskUUId' : CTRAC_MODAL.pageConfig.taskUUId },
    'uploadLimit'  : 6,
    'fileSizeLimit': '10MB', //individual file size limit
    'auto'         : false,
    'fileTypeExts' : '*.pdf',
    'fileTypeDesc' : 'PDF Files',
    'maxSizeErrMsg':"\nFiles were not attached. The number of files selected exceeds the maximum upload limit of six (6) and/or the maximum size of 10MB.",                 //Error message when file size exceeds total allowable file size limit
    'uploadLimitErrMsg' :"\nFiles were not attached. The number of files selected exceeds the maximum upload limit of six (6) and/or the maximum size of 10MB." //Error message when file count exceeds max file count
};

CTRAC_MODAL.updateUploadifyConfig = function(rid) {
    CTRAC_MODAL.uploadifyConfig.formData = { 'taskUUId' : rid };
};

CTRAC_MODAL.initializeDatepicker = function(inputId, minDate, maxDate) {
    $(inputId).bind('keydown', function(event) {
        if (event.which === 13) {
            var e = jQuery.Event("keydown");
            e.which = 9;// tab
            e.keyCode = 9;
            $(this).trigger(e);
            return false;
        }
     }).datepicker({
          showOn: "button",
          buttonImage: '../images/calendar-icon.png',
          buttonImageOnly: true,
          buttonText: '',
          showAnim: 'slide',
          maxDate: maxDate,
          disabled : CTRAC.readOnlyUserRole,
          minDate: minDate,
          onSelect: function(dateText, inst) {
              if (dateText !== inst.lastVal) {
                  $(this).change();
              }
          }
     });
    if (CTRAC.readOnlyUserRole) {
       $(inputId).attr('readonly',true);
    }
};

CTRAC_MODAL.launchPolicyModal = function(e, title, show, hide, rid, status, numDocs) {
    e.preventDefault();
    CTRAC_MODAL.settings.title = title;
    CTRAC_MODAL.settings.show = show;
    CTRAC_MODAL.settings.hide = hide;
    if (rid && rid > 0) {
        CTRAC_MODAL.settings.rid = rid;
    } else {
        var collateralId = $('#collateralID').val();
        CTRAC_MODAL.settings.rid = 'NEW_POLICY_' + collateralId;
    }
    CTRAC_MODAL.settings.status = status;
    CTRAC_MODAL.settings.reload = false;
    var cid = $("meta[name='_cid']").attr("content");
    CTRAC_MODAL.initializeUploadify(numDocs);
    $.ajax({
        url: CTRAC.context+'newInsurancePolicy?_cid='+cid+'&policyRid='+rid+'&mode='+INSURANCE_POLICIES.toggleable.mode,
        cache: false,
        success: function(data) {
            CTRAC_MODAL.createModal(data, CTRAC_MODAL.prepareModal);
            $('#proofOfCoverageMessage').hide();
            // For new policy, don't show delete button
            if (title.indexOf("New") === 0) {
                $("#policyDelete").hide();
            } else {
                $("#policyDelete").show();
            }

            $('#insuredName').change(function() {
                $('#insuredName').attr("title", $('#insuredName').val());
            });
        },
        error: function(xhr, ajaxOptions, thrownError) {
            COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
        }
    });
};

CTRAC_MODAL.launchOverridePolicyModal = function(e, title, show, hide, rid, status, numDocs) {
    e.preventDefault();
    CTRAC_MODAL.settings.title = title;
    CTRAC_MODAL.settings.show = show;
    CTRAC_MODAL.settings.hide = hide;
    if (rid && rid > 0) {
        CTRAC_MODAL.settings.rid = rid;
    } else {
        var collateralId = $('#collateralID').val();
        CTRAC_MODAL.settings.rid = 'NEW_POLICY_' + collateralId;
    }
    CTRAC_MODAL.settings.status = status;
    CTRAC_MODAL.settings.reload = false;
    var cid = $("meta[name='_cid']").attr("content");
    CTRAC_MODAL.initializeUploadify(numDocs);
    $.ajax({
        url: CTRAC.context+'overrideInsurancePolicy?_cid='+cid+'&policyRid='+rid+'&mode='+INSURANCE_POLICIES.toggleable.mode,
        cache: false,
        success: function(data) {
            CTRAC_MODAL.createModal(data, CTRAC_MODAL.prepareModal);
            $('#proofOfCoverageMessage').hide();
            // For new policy, don't show delete button
            if (title.indexOf("New") === 0) {
                $("#policyDelete").hide();
            } else {
                $("#policyDelete").show();
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
        }
    });
};

CTRAC_MODAL.initializeUploadify = function(existingNumDocs) {
    CTRAC_MODAL.settings.numDocs = existingNumDocs;
    var minimumAttachments = Math.max(0, 1-existingNumDocs);
    CTRAC_MODAL.pageConfig.uploadMinimun = minimumAttachments;
    CTRAC_MODAL.pageConfig.allowEmptyAttachement = minimumAttachments === 0;
};

CTRAC_MODAL.createModal = function(data, callback) {
    $('#ctracModal').html(data);
    if (callback && typeof(callback) === "function") {
        callback(CTRAC_MODAL.initModal);
    }
};

CTRAC_MODAL.prepareModal = function(callback) {
    $("#ctracModal .modal-title").text(CTRAC_MODAL.settings.title);
    $("#ctracModal " + CTRAC_MODAL.settings.hide).hide();
    $("#ctracModal " + CTRAC_MODAL.settings.show).show();
    $("#insurance-upload-container").show();
    CTRAC_MODAL.pageConfig.taskUUId = CTRAC_MODAL.settings.rid;
    CTRAC_MODAL.updateUploadifyConfig(CTRAC_MODAL.settings.rid);
    if (callback && typeof(callback) === "function") {
        callback();
    }
};

CTRAC_MODAL.initModal = function() {
    var hide = CTRAC_MODAL.settings.hide;
    var status = CTRAC_MODAL.settings.status;
    if (hasRoleWriter() && (status === 'PENDING_VERIFICATION' || status === 'NEW')) {
        $("#ctracModal input, #ctracModal select, #ctracModal a").not('.alwaysInactive').not('.mayInactive').removeAttr('disabled');
        var fieldsToHide = "#ctracModal " + hide + "," + hide + " input," + hide + " select";
        $(fieldsToHide).attr('disabled','disabled');
        $('#newPolicyModalSave').attr('disabled','disabled');
    } else {
        $("#ctracModal input, #ctracModal select, #ctracModal a").not(".alwaysActive,[name='_csrf']").attr('disabled', 'disabled');
        $("#insurance-upload-container,#insurance-upload-file-link,#addCollateralContainer,.required-field-symbol").hide();
        CTRAC_MODAL.pageConfig.allowEmptyAttachement = true;
    }
    CTRAC_MODAL.reinitModal();
    $("#ctracModal").modal({backdrop: true});
};

CTRAC_MODAL.paymentMethods = {
    'ATL' : 'LoanNumber',
    'MCC' : 'CostCenter',
    'CA'  : 'AccountNumber',
    'CC'  : 'MailingAddress'
};

CTRAC_MODAL.paymentMethodHandler = function(prefix) {
    var paymentMethod = $('#' + prefix + 'PaymentMethod').val();
    var suffix = CTRAC_MODAL.paymentMethods[paymentMethod];
    $('.' + prefix + 'PaymentMethod').hide();
    if (suffix) {
        $('.' + prefix + suffix).show();
    }
};

CTRAC_MODAL.initializePaymentMethod = function(prefix) {
    var paymentMethod = $('#' + prefix + 'PaymentMethod');
    if (paymentMethod.hasClass('enable-me')) {
        paymentMethod.removeAttr('disabled');
        $('.' + prefix + 'PaymentMethod input, .' + prefix + 'PaymentMethod select').removeAttr('disabled');
    }
    paymentMethod.change(function() {
        $('.' + prefix + 'PaymentMethod input').val('');
        $('.' + prefix + 'PaymentMethod select').val('');
        CTRAC_MODAL.paymentMethodHandler(prefix);
    });
};

// This is called from CTRAC_MODAL.initModal and also from the insurance modal when ajax call re-render the modal. This is needed for Add Collateral to Policy to work.
CTRAC_MODAL.reinitModal = function() {
    $("#add-collateral-to-policy").off().on("click", INSURANCE_POLICIES.addCollateralToPolicy);
    // remove the displayed message
    $("#collateralScreenNewInsurancePolicyModal").off().on("click", function(){
        if ($("#proofOfCoverageMessage").text() !== "") {
            $("#proofOfCoverageMessage").remove();
        }
    });
    initInsurancePoliciesFormValidation();
    $('#'+CTRAC_MODAL.pageConfig.inputFileID).off();
    initEmailAttachments(CTRAC_MODAL.pageConfig, CTRAC_MODAL.uploadifyConfig);
    CTRAC_MODAL.initializeDatepicker('#effective-date');
    CTRAC_MODAL.initializeDatepicker('#expiration-date');

    if ($('#lpi-send-date').val() !== "") {
        CTRAC_MODAL.initializeDatepicker('#lpi-send-date');
    }
    if ($('#lpi-cancellation-vendor-request-date').val() !== "") {
       CTRAC_MODAL.initializeDatepicker('#lpi-cancellation-vendor-request-date');
    }
    if ($('#cancellation-effective-date').val() !== "") {
       CTRAC_MODAL.initializeDatepicker('#cancellation-effective-date');
    }
    CTRAC_MODAL.initializePaymentMethod('invoice');
    CTRAC_MODAL.initializePaymentMethod('preRenewal');
    CTRAC_MODAL.initializePaymentMethod('refund');
    CTRAC_MODAL.paymentMethodHandler('invoice');
    CTRAC_MODAL.paymentMethodHandler('preRenewal');
    CTRAC_MODAL.paymentMethodHandler('refund');
    if (typeof hideShowFieldsBasedOnBlanketCoverageType === 'function') {
        hideShowFieldsBasedOnBlanketCoverageType();
    }
    if (!CTRAC_MODAL.settings.reload) {
        ENABLE_ON_EDIT.init('collateralScreenNewInsurancePolicyModal', '#policySave');
    }
};

CTRAC_MODAL.launchLoanBorrowerModal = function(e, title,  rid, action,maxDate) {
    e.preventDefault();
    var cid= $("meta[name='_cid']").attr("content");
    $.ajax({
        url: CTRAC.context+'editLoanBorrower?_cid='+cid+'&loanId='+rid+'&action='+action+'&mode='+LOAN_BORROWER.toggleable.mode,
        cache: false,
        success: function(data) {
               handleResponseLoanBorrower(data, action , maxDate);
            }
    });
};

CTRAC_MODAL.LoandInitModal = function(action, maxDate) {
    CTRAC_MODAL.initializeDatepicker('#loadedDate', null, maxDate);
    if (CTRAC.readOnlyUserRole) {
        $("#ctracModal input, #ctracModal select, #ctracModal a").attr('disabled','disabled');
        $("#btnLoanBorrowerClose").removeAttr('disabled');
    }
    var primaryLoanCheckbox = $('#chkPrimaryLoan');
    var loanBorrowerCount = $('#loanBorrowerCount').val();
    var releaseAllConfirmation = $('#releaseAllConfirmation');
    if($("#collateralStatus").text() !== 'Draft' && action !== 'new' ) {
        CTRAC_MODAL.initializeDatepicker('#releasedDate');
        $('#releasedDate').change(function() {
            if (loanBorrowerCount===1 && this.value.length > 0) {
                releaseAllConfirmation.show();
            } else if (loanBorrowerCount===1) {
                releaseAllConfirmation.hide();
            } else if (this.value.length > 0) {
                primaryLoanCheckbox.prop('checked', false);
                primaryLoanCheckbox.prop('disabled', true);
            } else {
                primaryLoanCheckbox.prop('disabled', false);
            }
        }).change();
    }

    setReleasedCollateralReadonly();

};

function handleResponseLoanBorrower(data, action , maxDate) {
    $('#ctracModal').html(data);
    $("#ctracModal").modal({backdrop: true});
    if(action === "edit") {
        $("#btnLoanBorrowerDelete").show();
    }
    CTRAC_MODAL.LoandInitModal(action , maxDate);
}

////Begin fiat input page modal;
var url = {};
url['new']= 'editCoverageRequirement?_cid=';
url['edit']= 'editCoverageRequirement?_cid=';
url['display']= 'displayCoverageRequirement?_cid=';
url['verify']= 'verifyCoverageRequirement?_cid=';

CTRAC_MODAL.launchCovergeModal = function(e, fiatDocId, action, callback) {
    e.preventDefault();
    var cid= $("meta[name='_cid']").attr("content");
    $.ajax({
        url: CTRAC.context+url[action] +cid+'&fiatDocID='+fiatDocId+'&action='+action,
        cache: false,
        success: function(data) {
            CTRAC_MODAL.createSimpleModal(data, callback);
        }
    });
};

var fdurl = {};
fdurl['new']= 'editFloodDetermination?_cid=';
fdurl['edit']= 'editFloodDetermination?_cid=';
fdurl['display']='displayFloodDetermination?_cid=';
fdurl['verify']='editFloodDetermination?_cid=';

CTRAC_MODAL.launchFloodDeterminationModal = function(e, floodDeterminationId, action) {
    e.preventDefault();
    var cid= $("meta[name='_cid']").attr("content");
    $.ajax({
        url: CTRAC.context+fdurl[action] +cid+'&floodDeterminationId='+floodDeterminationId+'&action='+action,
        cache: false,
        success: function(data) {
            CTRAC_MODAL.createSimpleModal(data, function() {
                FLOOD_DETERMINATION.initializeAllEvents(action);
            });
        }
    });
};

CTRAC_MODAL.createSimpleModal = function(data,callback) {
    $('#ctracModal').html(data);
    if (CTRAC.readOnlyUserRole) {
         $("#ctracModal input, #ctracModal select, #ctracModal a").attr('disabled','disabled');
         $("#newFloodDeterminationModalCancel").removeAttr('disabled');
         $('#fiat-document-container').hide();
         $('#SFHDF-document-container').hide();
         $("#newReqCoveModalCancel").removeAttr('disabled');
    }
    $("#ctracModal").modal({backdrop: true});
    if (callback && typeof(callback) === "function") {
        callback();
    }
};

WORKFLOW_DETAILS = {};


WORKFLOW_DETAILS.viewWorkflowDetails = function(e, rid) {
    e.stopPropagation();
    e.preventDefault();
    CTRAC_MODAL.settings.title = "Workflow Details";
    var cid= $("meta[name='_cid']").attr("content");
    $.ajax({
        url: CTRAC.context+'viewWorkflowDetails?_cid='+cid+'&rid='+rid,
        cache: false,
        success: function(data) {
            CTRAC_MODAL.createModal(data, CTRAC_MODAL.prepareModal);
            $("#ctracModal input[type='hidden']").removeAttr('disabled');
        },
        error: function(xhr, ajaxOptions, thrownError) {
            COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
        }
    });
};



////End fiat input page modal;

function setReleasedCollateralReadonly() {
    if ($("#collateralStatus").text() === "Released")
    {
         $('input, textarea, select').attr('readonly','readonly');
         $('input[type="button"]').removeAttr('readonly');
         $('input[type="button"]').attr('disabled','disabled');
         $('.btn-new').attr('disabled','disabled');
         $('.btn-start-ver').attr('disabled','disabled');
         $('.btn-close').removeAttr('disabled').removeAttr('readonly');
         $('.chk-inactive').removeAttr('disabled').removeAttr('readonly');
         $('.uploadify').hide();

    }
 }