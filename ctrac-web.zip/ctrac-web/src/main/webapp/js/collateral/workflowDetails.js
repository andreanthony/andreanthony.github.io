'use strict';
var WORKFLOW = {};
WORKFLOW.initializeSection = function(){
    $(".workflowRow").off("mouseover").on("mouseover", function() {
        $(this).addClass("highlightRow");

        var selectedPolicyRid = $(this).find(".workflowStepPolicyRid").attr("id");
        $("#policyTables").find(".policyRid").each(function (){
            if ( $(this).text() == selectedPolicyRid) {
                $(this).parent().addClass("highlightRow");			}
        });
    });

    $(".workflowRow").off("mouseout").on("mouseout", function() {
        $(this).removeClass("highlightRow");

        var selectedPolicyRid = $(this).find(".workflowStepPolicyRid").attr("id");
        $("#policyTables").find(".policyRid").each(function (){
            if ( $(this).text() == selectedPolicyRid) {
                $(this).parent().removeClass("highlightRow");
            }
        });
    });
};
$(function(){
    WORKFLOW.initializeSection();
});

