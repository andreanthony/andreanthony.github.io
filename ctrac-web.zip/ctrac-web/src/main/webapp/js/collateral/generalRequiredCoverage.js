var GENERAL_COVERAGE_REQUIREMENT = {};

GENERAL_COVERAGE_REQUIREMENT.initializeGeneralRequiredCoverageSection = function() {
    $('#new-gen-required-insurance-coverage').click(function (e) {
        var collateralRid = $('#collateralID').val();
        e.preventDefault();
        window.open(
            CTRAC.root+'dashboard/requirement/create/'+collateralRid, 'CTRAC - General Coverage Requirement');
    });

    // for inactive GI Coverage
    $("#chkInactiveGeneralRequiredCoverage").on("click", function () {
        checkboxControl(this, $("#inactiveGIRequiredCoverage"));
    });
};