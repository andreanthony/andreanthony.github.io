var newWindow=null;
var selectedCheckBoxes=new Object();
var currentSelectedStatus='None';
var entityTable;
var host=window.location.protocol+"//"+window.location.host;

function initEntityTable() {
    entityTable = $('#entity-table').DataTable({
        serverSide: true,
        ajax: {
            url: 'getentities',
            type: 'GET',
            "data": function (d) {
                d.totalSearchField = 7; 
            } 
        },
        "columns": [
            { "data": "dashboardTaskSelected", "targets": 0, "defaultContent":'<input class="row-checkbox" type="checkbox"/>', "searchable": false,"sortable": false},
            { "data": "rid",                   "targets": 1 },
            { "data": "name",			       "targets": 2 },
            { "data": "address",               "targets": 3 },
            { "data": "city",                  "targets": 4 },
            { "data": "state",                 "targets": 5 },
            { "data": "zipcode",               "targets": 6 },
            { "data": "collateralRids",        "targets": 7 }
        ],
        "autoWidth" : false,
        "dom" : '<<"pull-right"l>rtip>',
        "order": [[ 2, "asc" ]],
        "paging" : true,
        "lengthMenu" : [ 25,50,100,200 ],
        "lengthChange" : true,
        initComplete: function(){
        	initializeSearches();
        }
    });
}


function initializeSearches() {
    var timer;
    $('.search-field').on('change paste keyup',function(){
        clearInterval(timer);
        $('.search-field').each(function() {
            var searchKey=this.value;
            var thisTd=$(this).closest('th');
            var visIdx=$(thisTd).index();
            var colIdx=entityTable.column(visIdx).index();
            entityTable.column(colIdx).search(searchKey);
        });
        timer = setTimeout(
        		function(){entityTable.draw();
        		}, 1000);
    });
}

Object.size=function(obj){
    var size=0,key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) {
            size++;
        }
    }
    return size;
};

Object.getArray=function(obj){
    var array=[];
    for (key in obj) {
        if (obj.hasOwnProperty(key)) {
            array.push(obj[key]);
        }
    }
    return array;
};


