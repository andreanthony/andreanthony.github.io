/*<![CDATA[ */
var FLOOD_DETERMINATION = {};

var pageTitleDetermination = {};
pageTitleDetermination['new']= 'Standard Flood Hazard Determination Form ';
pageTitleDetermination['edit']= 'Standard Flood Hazard Determination Form';
pageTitleDetermination['display']='Standard Flood Hazard Determination Form';

FLOOD_DETERMINATION.editMode=false;

FLOOD_DETERMINATION.initializeFloodDeterminationSection = function(){
	
	$('#new-flood-hazard-determination').click(function(e){ 
		 var determinationId = -1;
		 CTRAC_MODAL.launchFloodDeterminationModal(e, determinationId, 'new', function (){FLOOD_DETERMINATION.initializeAllEvents('new')}  );
	});

	$("#btnStartVerificationFloodDetermination").off("click").on("click", function(event){
		event.preventDefault();
		event.stopPropagation();
		FLOOD_DETERMINATION.setVerificationModeOn();
	});

	//behavior of the completeVerification button:
	$('#btnCompleteVerifyFloodDetermination').click(function(e){ 
		var completeVerificationUrl='editFloodDetermination/completeVerification';
		var extraData = "&action=completeVerification"; //collateralId and sort order don't matter here
		var formName = "floodDeterminationFormSection";
		$("#floodDeterminationFormSection input").removeAttr('disabled');
		FLOOD_DETERMINATION.makeRemotePost( completeVerificationUrl, extraData, COLLSCREENAjaxError.reloadThecollateralScreen,formName );
	});
	 
	$("#btnVerifyCancelFloodDetermination").click(function(event){
		var resp = confirm("Are you sure you want to cancel the verification?");
		if (resp === true) {
			FLOOD_DETERMINATION.setVerificationModeOff();
		}
		event.preventDefault();
		event.stopPropagation();	
	});
	
	$('.display-inactive-flood-determination').click(  function(e){		 
		 var determinationId = $(this).attr("data-floodDeterminationId");		 
		 CTRAC_MODAL.launchFloodDeterminationModal(e, determinationId, 'display', function (){FLOOD_DETERMINATION.initializeAllEvents('display')}  );
    });
	
	$("#chkInactiveFloodDetermination").on("click", function () {
		 checkboxControl(this, $("#inactiveFloodDetermination"));
    });
};

//On click of start verification
FLOOD_DETERMINATION.setVerificationModeOn = function(){		
	$("#editFloodDetermination").hide();//hide edit span
	FLOOD_DETERMINATION.editMode=false;//change mode to false
	$("#btnStartVerificationFloodDetermination").hide();//hide start
	$("#verifyCancelFloodDetermination").show();//show cancel
	$("#btnCompleteVerifyFloodDetermination").show();//show complete
	$("#btnVerifyCancelFloodDetermination").show();	//show complete span
};

//On click of verify cancel
FLOOD_DETERMINATION.setVerificationModeOff = function(){		
	$("#btnCompleteVerifyFloodDetermination").hide();//hide the button
	$("#btnVerifyCancelFloodDetermination").hide();	//hide the button
	$("#verifyCancelFloodDetermination").hide();//hide cancel span
	$("#btnStartVerificationFloodDetermination").hide();//show start
	FLOOD_DETERMINATION.setEditModeOff();//show edit in default
};

//On click of edit
FLOOD_DETERMINATION.setEditModeOn = function(){
	$("#editFloodDetermination").show();
	$("#determination-pending-verification-div").addClass("editable-flood-determination-div").removeClass("noneditable-flood-determination-div");
	$("#edit-flood-hazard-determination").html("Cancel");
	$("#new-flood-hazard-determination").removeAttr('disabled');
	$("#btnStartVerificationFloodDetermination").hide();
	$("#btnCompleteVerifyFloodDetermination").hide();//hide the button
	$("#btnVerifyCancelFloodDetermination").hide();	//hide the button
	$("#verifyCancelFloodDetermination").hide();//hide start span
};

//On click of edit cancel
FLOOD_DETERMINATION.setEditModeOff = function(){
	 $("#editFloodDetermination").show();
	 $("#determination-pending-verification-div").addClass("noneditable-flood-determination-div").removeClass("editable-flood-determination-div");
	 $("#edit-flood-hazard-determination").html("Edit");
	 $("#new-flood-hazard-determination").attr('disabled', 'disabled');
	 $("#btnStartVerificationFloodDetermination").show();//show the start button
};

FLOOD_DETERMINATION.initializeAllEvents = function( action ) {
	$("#ctracModal .modal-title").text(pageTitleDetermination[action]);
	if(action ==='new' || action==='edit' || action==='verify'){
		if(action==='new'){
			$('#newFloodDeterminationModalDelete').hide();
		}
		initEmailAttachments(FLOOD_DETERMINATION.pageConfig, FLOOD_DETERMINATION.uploadifyConfig);
		CTRAC_MODAL.initializeDatepicker('.datepicker');
		ENABLE_ON_EDIT.init('floodDeterminationForm', '#newFloodDeterminationModalSave');
		validateFloodDeterminationForm();
	}else{
		FLOOD_DETERMINATION.disableAllCommand();
	}
};


FLOOD_DETERMINATION.floodFormSubmitFailureHandler = function(thrownError, xhr){
    //On error - display error messages
    ALL_SECTIONS.handleFormSubmissionFailures(thrownError,xhr, "form#floodDeterminationForm");
    //Re-initialize the file upload as the failure come up on submitting (server-side validation)
    FLOOD_DETERMINATION.initializeAllEvents('edit');
};

FLOOD_DETERMINATION.reloadFloodDeterminationSection = function(callback){
    var cid= $("meta[name='_cid']").attr("content");
    $.ajax({
        type: "GET",
        global: false, // prevent global setting to show loading spinner
        url: CTRAC.context + 'reloadFloodDeterminationSectionFromSession?_cid='+cid,
        cache: false,
        data: $('form#floodDeterminationFormSection').serialize(),
        success: function (response) {
            if (response.indexOf("ACCESS DENIED") > -1) {
                alert("CTRAC - Access Denied.");
            }
            $('#floodHazardDeterminationSection').replaceWith(
            	'<div id="floodHazardDeterminationSection" class="results-block">'
				+ response + '</div>');
            if(callback){
                callback();
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status + " thrownError: " + thrownError);
        }
    });
};

FLOOD_DETERMINATION.displayConfirmMessage = function(data){
	var successMessageHtml = '<strong> Success!</strong> Updates are successfully saved';
	if($('#messageWrapper .alert-success').length === 1){
        $('#messageWrapper .alert-success').html(successMessageHtml);
    }else{
        $('#messageWrapper').append( '<div class="alert alert-success"> '+successMessageHtml+'</div>');
	}
	dataChanged = false;
    FLOOD_DETERMINATION.reloadFloodDeterminationSection(FLOOD_DETERMINATION.initializeFloodDeterminationSection);
};

FLOOD_DETERMINATION.disableAllCommand = function(){
	$("input:not(#inactiveFloodDetermination), select").prop('disabled', true);
	$(".cmdBlock").hide();
	$(".alwaysActive").prop('disabled', false);
	$("#newFloodDeterminationModalCancel").prop('value', "Close");
};

FLOOD_DETERMINATION.deleteUrl='editFloodDetermination/update';
FLOOD_DETERMINATION.deleteAndRefresh  = function(){
	 if(!confirm("Are you sure you want to delete this Flood Determination?")){
		 return false;
	 }
	 var extraData = "&action=delete"; //collateralId and sort order don't matter here
	 var deleteCallback = function(data){
	 	if(data != undefined && data.success){
            if("reload" === data.action){
                FLOOD_DETERMINATION.reloadFloodDeterminationSection(closeOverlay);
			}
		}
	 };
	 var formName = "floodDeterminationForm";
	 FLOOD_DETERMINATION.makeRemotePost(FLOOD_DETERMINATION.deleteUrl, extraData, deleteCallback , formName);
};

FLOOD_DETERMINATION.makeRemotePost = function(url,extraData, callback, formName ){
   var cid= $("meta[name='_cid']").attr("content");
   toggleLoader(true);
   $.ajax({
        type: "POST",
        url: CTRAC.context+url+'?_cid='+cid+extraData,
        data: $('form#'+formName).serialize(),
        success: function(response){
	        if (typeof(callback) === "function"){
	        		 callback(response);
	        }
	        toggleLoader(false);
        },
   		error: function(xhr, ajaxOptions, thrownError) {
   			COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
   		}
	});
};

function enableAmountFormatting(id){
	$(id).on('click',"input.numeric", function() { $(this).select(); }).on('focus' , "input.numeric", function(){ $(this).autoNumeric('init'); });
}

function replaceTableContentDiv(response){
    $('#tableContentID').replaceWith( $(response).find('#tableContentID') );
	enableAmountFormatting('#coverageRequirementTable');
}

function closeOverlay (){
	FLOOD_DETERMINATION.initializeFloodDeterminationSection();
	$("#ctracModal").modal("hide");
}
/*]]>*/