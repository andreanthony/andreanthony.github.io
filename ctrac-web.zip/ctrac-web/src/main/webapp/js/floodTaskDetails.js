// Close the popup window when the user clicks 'cancel' and 'X'.
function closeHelperPopup() {
	//alert('about to close the popup');
	var w = self; // grab the reference to your helper window
	while (w.parent != w) w = w.parent; // grab the reference to root window, by pass any level of nested iFrame
	w.close();
}

