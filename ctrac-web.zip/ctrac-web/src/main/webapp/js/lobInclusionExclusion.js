/**
 * 
 */

var LOB_INCLUSION_EXCLUSION = {};

LOB_INCLUSION_EXCLUSION.initializeInclusionExclusionSection = function() {
	$('#addLobForFeed').prop("disabled", true);
	$('#removeLobForFeed').prop("disabled", true);
	$('#addLobForDropDown').prop("disabled", true);
	$('#removeLobForDropDown').prop("disabled", true);
	$('#saveBtnForFeed').prop("disabled", true);
	$('#saveBtnForDropDown').prop("disabled", true);

	var displayMessage = $('#displayMessageForFeed').text();
	console.log(displayMessage);
	if (!displayMessage || displayMessage != "") {
		$('#displayMessageForFeed').show();
	}
}

LOB_INCLUSION_EXCLUSION.enableDisableButtons = function(element) {
	if (element == 'includedLOBsForFeeds') {
		$('#addLobForFeed').prop("disabled", true);
		$('#removeLobForFeed').prop("disabled", false);
	} else if (element == 'excludedLOBsForFeeds') {
		$('#addLobForFeed').prop("disabled", false);
		$('#removeLobForFeed').prop("disabled", true);
	}

	if (element == 'includedLOBsForDropDown') {
		$('#addLobForDropDown').prop("disabled", true);
		$('#removeLobForDropDown').prop("disabled", false);
	} else if (element == 'excludedLOBsForDropDown') {
		$('#addLobForDropDown').prop("disabled", false);
		$('#removeLobForDropDown').prop("disabled", true);
	}
}

LOB_INCLUSION_EXCLUSION.includeExcludeSelectedLOB = function(sourceElement,
		targetElement, triggeredElementId) {

	$('#' + sourceElement + ' option:selected').remove().appendTo(
			'#' + targetElement).removeAttr('selected');
	var availableLobs = [];
	var configuredLobs = [];
	var triggeredSectionId;

	if (sourceElement == 'excludedLOBsForFeeds' || sourceElement == 'excludedLOBsForDropDown') {
		var availableLobsOpts = $('#' + sourceElement)[0].options;
		var configuredLobsOpts = $('#' + targetElement)[0].options;

	} else if(sourceElement == 'includedLOBsForFeeds' || sourceElement == 'includedLOBsForDropDown') {
		var availableLobsOpts = $('#' + targetElement)[0].options;
		var configuredLobsOpts = $('#' + sourceElement)[0].options;
	}

	availableLobs = $.map(availableLobsOpts, function(elem) {
		return elem.value;
	});

	configuredLobs = $.map(configuredLobsOpts, function(elem) {
		return elem.value;
	});

	if (triggeredElementId == 'addLobForFeed'
			|| triggeredElementId == 'removeLobForFeed') {
		triggeredSectionId = 'lobMappingForDataFeed';
	} else if (triggeredElementId == 'addLobForDropDown'
			|| triggeredElementId == 'removeLobForDropDown') {
		triggeredSectionId = 'lobMappingForDropDown';
	}

	$.ajax({
		type : "POST",
		url : "editLOB?availableLobs=" + availableLobs + "&configuredLobs="
				+ configuredLobs + "&triggeredSectionId=" + triggeredSectionId,
		data : $('form#lobInclusionExclusionForm').serialize(),
		success : function(response) {
			enableFields(triggeredSectionId);
		}
	});
}

function enableFields(triggeredSectionId){
	if (triggeredSectionId == 'lobMappingForDataFeed') {
		$('#saveBtnForFeed').prop("disabled", false);
	} else if (triggeredSectionId == 'lobMappingForDropDown') {
		$('#saveBtnForDropDown').prop("disabled", false);
	}
}