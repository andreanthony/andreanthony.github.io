DEPENDENT_FIELD = {};

function DependentField(dependency, condition, dependentField) {
    this.dependency = $(dependency);
    this.condition = condition;
    this.dependentField = $(dependentField);
    this.hideAndShow = false;
}

DependentField.prototype.setHideAndShow = function(hideAndShow) {
    this.hideAndShow = hideAndShow;
};

DependentField.prototype.init = function() {
    var dependency = this.dependency, condition = this.condition, dependentField = this.dependentField,
            hideAndShow = this.hideAndShow;
    dependency.change(function() {
        if (condition(dependency)) {
            dependentField.prop('disabled', false);
            if (hideAndShow) {
                dependentField.show();
            }
        } else {
            dependentField.val('');
            dependentField.prop('disabled', true);
            if (hideAndShow) {
                dependentField.hide();
            }
        }
    });
    dependency.change();
};

DEPENDENT_FIELD.positiveAmount = function(element) {
    var el = $(element), val = el.val(), disabled = el.prop('disabled') || el.is('[readonly]'), amount = parseFloat(val.replace(/,/g, ''));
    return !disabled && (val === '' || (!isNaN(amount) && amount > 0));
};