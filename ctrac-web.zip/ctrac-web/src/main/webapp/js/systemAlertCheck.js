
if (!window.console) {
  var console;
}

var alertMSG  ="<span class='blink'> CTRAC is preparing to run its end of day cycle. \n Please save your work and exit the system immediately. </span>" ;
var closeActivityMSG ="Update Operations are not allowed at this time. Please try again later.";
var endOFDayJobTittle ='End of the day job alert';

var origin = window.location.origin;
var root = origin+window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));

	
$().ready(function($) {
	initBacthIntercept(activateBlink);
	//offerDialog('the caching issue is fixed V2 ....');
}); 


function offerDialog(message){
	
	$(document.createElement('div'))
    .attr({title:endOFDayJobTittle, 'class': 'alert'})
    .html(message)
    .dialog({
        buttons: {OK: function(){$(this).dialog('close');}},
        close: function(){$(this).remove();},
        draggable: true,
        modal: true,
        resizable: false,
        minWidth:'500px',
        minHeight:'400px'
		 });
	activateBlink();
}

function activateBlink(){
	var color='red';
	setInterval(function(){ $('.blink').css({'color': color}); if('red'===color){color='black';} else{color='red';}}, 300);
}

function initBacthIntercept(clbk){
	if(console && console.log){
		console.log('getting the batch Start time ... ');
	}
	$.ajax({
        type: "GET",
        url: root+'/batchRunTimeCountDown',
        success: function(response){
        	if(response && response!=null ){
        		initBacthInterceptTriggers(response, clbk);
        	}
        }
	});
	
}

function initBacthInterceptTriggers( batchRunTimeCountDownText, clbk){
	
	var batchRunTimeData = JSON.parse(batchRunTimeCountDownText);
	var countDown = batchRunTimeData.countDown;
	
	if(countDown <= 60000){
		closeAtivities( );
		return;
	}else if (countDown <= 300000) {
		displayAlert(alertMSG);
		setTimeout(closeAtivities, countDown-60000);
		return;
	}else{
		setTimeout(alertActivitiesClosing, countDown-300000);
		setTimeout(closeAtivities, countDown-60000);
	}
	
	 if (typeof(clbk) == "function"){
		 clbk();
	 }

}

function alertActivitiesClosing(){
	displayAlert(alertMSG,false);
}

function closeAtivities( ){
	var clbkMain= function(){window.location.href = root+'/batchIsRunning';};
	var clbk = setTimeout(clbkMain,4000);
	displayAlert(closeActivityMSG,clbk);
}


function displayAlert(msg, clbk){
	offerDialog(msg);
	
	 if (typeof(clbk) == "function"){
		 clbk();
	 }
}
