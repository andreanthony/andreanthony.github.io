/**
 * For functionality used across CTRAC pages
 */

function initComments(commentsId, counterId, maxChars) {
	var characters = maxChars;
	
	var commentsSelector = '#' + commentsId;
	var counterSelector = '#' + counterId;
	
	$(counterSelector).append("You have <strong>" + characters + "</strong> characters remaining");  
	$(counterSelector).hide();
	
	$(commentsSelector).keyup(function() {
		$(counterSelector).show();
		
		if ($(this).val().length > characters) {
			$(this).val($(this).val().substr(0,characters));
		}
		var remaining = characters - $(this).val().length;
		$(counterSelector).html("You have <strong>" + remaining + "</strong> characters remaining");
		
		if (remaining == characters) {
			$(counterSelector).hide();
			return;
		}
	});
	
}
	
	
function selectOptions(optionEID,  defaultOptionEid, selectedValue){
		if(selectedValue){
			$('#'+optionEID +' option:contains(' + selectedValue + ')').each(function(){
			    if ($(this).text() == selectedValue) {
			    	$('#'+defaultOptionEid).removeAttr("selected");
			        $(this).attr('selected', 'selected');
			        return false;
			    }
			    return true;
			});
		}
}
	
