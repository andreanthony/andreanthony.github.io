var errorClass = "has-error text-danger";
var validClass ="";

function validateFloodDeterminationForm(){
	$("#floodDeterminationForm").validate({
	        rules: {
	        	vendor : {required : true },
	        	orderNumber : {required : true},
	        	loanIdentifier: {required : true},
	        	dateOfDetermination: {required : true, dpDate:true},
	        	dateOfMapChange: {required : true, dpDate:true},
	        	floodZone: {required : true}
			},
			groups : {
				allFields : 'vendor orderNumber loanIdentifier dateOfDetermination dateOfMapChange floodZone'
			},
	        errorContainer      : $('#errorContainerCoverage'),
	        errorLabelContainer : "#errorContainerCoverage",
        	errorElement     	: "span",
        	errorClass          : "has-error text-danger alert-element-padding",
        	validClass          : ""
	    }); 
}
