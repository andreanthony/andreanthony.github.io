	
function registerTextCounter(targetId, counterId, maxChars){
	$(counterId).append("<p>You have <strong>" + maxChars + "</strong> characters remaining</p>");  
	 $(targetId).keyup(function() {
		  $(counterId).prop("hidden", false);
		  if ($(targetId).val().length > maxChars) {
					$(targetId).val($(targetId).val().substr(0,maxChars));
		  }
		  var remaining = maxChars - $(targetId).val().length;
		  $(counterId).html("<p>You have <strong>" + remaining + "</strong> characters remaining</p>"); 
	  });
}
