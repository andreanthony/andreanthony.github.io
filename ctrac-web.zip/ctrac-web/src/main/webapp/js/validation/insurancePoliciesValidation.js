function initInsurancePoliciesFormValidation(){
	$("#policyForm").validate({
        rules: {
        	insuranceType : {required : true},
        	policyType : {required : true},
        	coverageType: {required : true},
        	effectiveDate: {required : true, dpDate:true },
        	expirationDate: {required : true, dpDate: true, futureDate: true, greaterThanEffectiveDate: true },
        	policyNumber: {required : true},
           	insuredName: {required : true},
           	floodZone: {required : true, inFloodZone : true},
           	insuranceAgency: {required : true, althansPolicy : true},
           	collateralID: {number: true},
           	lenderPlaceReason: {requiredForWorkflow : true, matchPolicyType: true},
            parentPolicyRid: {requiredForGap : true },
          	'manualLetterCycle.firstLetterDate': {dpDate: true, requiredForWorkflow : true},
          	'manualLetterCycle.secondLetterDate': {dpDate:true, validSecondLetterDate: true},
           	'agentData.contactDetailDto.emailAddress': {validateMultipleEmail:true},
           	'invoicePaymentMethod.paymentMethod'  : {required : true},
           	'invoicePaymentMethod.paymentAccount' : {required : true},
           	'invoicePaymentMethod.address.streetAddress'  : {required : true},
           	'invoicePaymentMethod.address.city'           : {required : true},
           	'invoicePaymentMethod.address.state'          : {required : true},
           	'invoicePaymentMethod.address.zipCode'        : {required : true, validateZipcodeUS : true},
           	'refundPaymentMethod.paymentAccount'          : {required : true},
           	'refundPaymentMethod.address.streetAddress'   : {required : true},
           	'refundPaymentMethod.address.city'            : {required : true},
           	'refundPaymentMethod.address.state'           : {required : true},
           	'refundPaymentMethod.address.zipCode'         : {required : true, validateZipcodeUS : true},
           	'preRenewalPaymentMethod.paymentMethod'		  : {required : true},
           	'preRenewalPaymentMethod.paymentAccount'      : {required : true}
		},
		groups : {
			allFields : 'insuranceType policyType coverageType effectiveDate expirationDate policyNumber insuredName floodZone'
					  + ' letterCycleWorkflowStep lenderPlaceReason parentPolicyRid firstLetterDate secondLetterDate'
					  + ' buildingDeductible contentsDeductible insuranceAgency agentData.contactDetailDto.emailAddress'
					  + ' invoicePaymentMethod.paymentMethod invoicePaymentMethod.paymentAccount invoicePaymentMethod.address.streetAddress'
					  + ' invoicePaymentMethod.address.city invoicePaymentMethod.address.state invoicePaymentMethod.address.zipCode'
					  + ' refundPaymentMethod.paymentAccount refundPaymentMethod.address.streetAddress'
					  + ' refundPaymentMethod.address.city refundPaymentMethod.address.state refundPaymentMethod.address.zipCode'
					  + ' preRenewalPaymentMethod.paymentMethod preRenewalPaymentMethod.paymentAccount'
		
		},
        errorContainer      : $('#errorContainerInsurancePolicy'),
        errorLabelContainer : "#errorContainerInsurancePolicy",
		errorElement	     : "span",
        errorClass          : "has-error text-danger alert-element-padding",
        validClass          : ""
    });
	$('.numeric').each(function() {  
        $(this).autoNumeric('init');
    });
	
	$("#overridePolicyForm").validate({
        rules: {
        	effectiveDate: {dpDate:true },
        	expirationDate: {dpDate: true },
        	"lenderPlaceItemData.lpSendDate": {dpDate: true },
        	"lenderPlaceItemData.cancellationRequestDate": {dpDate: true },
        	cancellationEffectiveDate: {dpDate: true },
        	"lenderPlaceItemData.cancellationLetterDate": {dpDate: true },
        	"lenderPlaceItemData.refundCompletionDate": {dpDate: true }
        },
		groups : {
			allFields : 'effectiveDate expirationDate lenderPlaceItemData.lpSendDate lenderPlaceItemData.cancellationRequestDate cancellationEffectiveDate lenderPlaceItemData.cancellationLetterDate lenderPlaceItemData.refundCompletionDate '
		},
        errorContainer      : $('#errorContainerOverrideInsurancePolicy'),
        errorLabelContainer : "#errorContainerOverrideInsurancePolicy",
        errorElement	     : "span",
        errorClass          : "has-error text-danger alert-element-padding",
        validClass          : ""
    });

	
}

jQuery.extend(jQuery.validator.messages, { required : ' ' });

jQuery.validator.addMethod("greaterThanEffectiveDate", function(value, element) {
	if (!validEffectiveAndExpirationDateFormats()) {
		return true;
	}
	return new Date($("#expiration-date").val()) > new Date($("#effective-date").val())
},'Expiration date must be greater than the effective date.');

jQuery.validator.addMethod("futureDate", function(value, element) {
	return validDateFormat($("#expiration-date").val()) &&
			new Date($("#expiration-date").val()) > new Date($("#expDateHidden").val());
},'Expiration date must be a future date.');

var validEffectiveAndExpirationDateFormats = function() {
	return validDateFormat($("#effective-date").val()) && validDateFormat($("#expiration-date").val());
}

var validDateFormat = function(val) {
	return !(/Invalid|NaN/.test(new Date(val)));
}

function getFloatFromString(stringAmount) {
	return parseFloat(stringAmount.replace(/,/g, ''));
}

jQuery.validator.addMethod("validCoverageAmounts", function(value, element) {
	var onePositive = false, allNonNegative = true, moreThanOnePositive = false;
	var collateralCoverageTable = $(element).closest('table');
	var errorClass = 'has-error';
	collateralCoverageTable.find('.coverageAmount').each(function(j, input) {
		var amount = getFloatFromString($(input).val());
		var container = $(input).closest('div');
		if (amount < 0) {
			container.addClass(errorClass);
			collateralCoverageTable.addClass(errorClass);
			allNonNegative = false;
		} else if (amount > 0) {
		    if (onePositive) {
		        container.addClass(errorClass);
		        moreThanOnePositive = true;
		    } else {
		        container.removeClass(errorClass);
            	onePositive = true;
		    }
		} else {
			container.removeClass(errorClass);
		}
	});
	if (onePositive) {
		collateralCoverageTable.removeClass(errorClass);
	} else {
		collateralCoverageTable.addClass(errorClass);
	}
	return allNonNegative && onePositive && !moreThanOnePositive;
}, 'Only one coverage amount is allowed per policy.');

jQuery.validator.addClassRules({
	coverageAmount : {
		validCoverageAmounts : true
	}
});

jQuery.validator.addMethod("validExpirationDate",function(value,element,params){
	var application="APPLICATION";
	var binder="BINDER";
	var date1=new Date($(params[0]).val());
	var date2=new Date($(params[1]).val());
	var oneDay=(1000*60*60*24);
	var diff=new Date(date1-date2);
	var numOfDays=Math.round(diff/oneDay);
	if(value==application){
		if(numOfDays>=30 || (new Date(date1)<new Date(date2))){
			return false;
		}
		return true;
	}
	if(value==binder){
		if(numOfDays>=90 || (new Date(date1)<new Date(date2))){
			return false;
		}
		return true;
	}
	return true;
},function(element,params){
	var errMsg="";
	var refDate=$("#expDateHidden").val();
	var policyType=$("#policyType").val();
	if(policyType=="APPLICATION"){
		errMsg="Expiration date for policytype "+policyType+" should be between "+ addDays(new Date(refDate), 0) +" and "+addDays(new Date(refDate),30)+"";
	}
	if(policyType=="BINDER"){
		errMsg="Expiration date for policytype "+policyType+" should be between "+addDays(new Date(refDate), 0) +" and "+addDays(new Date(refDate),90)+"";
	}
	return errMsg;
});
function addDays(date,days){
	var newDate = new Date(date.getTime()+days*24*60*60*1000); 
	var dayPart = newDate.getDate() + "";
	
	if (dayPart.length == 1) {
		dayPart = "0"+dayPart;
	}
	
	var monthPart = (newDate.getMonth() + 1) + "";
	if (monthPart.length == 1) {
		monthPart = "0"+monthPart;
	}
	
	return ( monthPart + "/" + dayPart + "/" + newDate.getFullYear());
}

function startLetterCycle() {
	var val=$("#letterCycleWorkflowStep").val();
	return typeof val != "undefined" && val != ""; 
}
jQuery.validator.addMethod("inFloodZone", function(value, element) {
	var floodZone=value.toUpperCase();
	return !startLetterCycle() || floodZone.indexOf('A') == 0 || floodZone.indexOf('V') == 0;
},'Must be in flood zone to start Letter Cycle Workflow.');

jQuery.validator.addMethod("althansPolicy", function(value, element) {
	return  !startLetterCycle() || value=="Althans";
},'Must be in an Althans policy to start Letter Cycle Workflow.');

jQuery.validator.addMethod("matchPolicyType", function(value, element) {
    var lenderPlaceReason = value;
	var policyType=$("#policyType").val();
	return  !startLetterCycle() ||
		lenderPlaceReason.indexOf('BORROWER_POLICY') < 0 && policyType != "LP_GAP" ||
		lenderPlaceReason.indexOf('BORROWER_POLICY') == 0 && policyType == "LP_GAP";
},'Must match the Policy Type to start Letter Cycle Workflow.');

jQuery.validator.addMethod("requiredForGap", function(value, element) {
    var lenderPlaceReason = $("#lenderPlaceReason").val();
	return  !startLetterCycle() || lenderPlaceReason.indexOf('BORROWER_POLICY') < 0 || value != "";
},'Parent Policy required to start Letter Cycle Workflow.');

jQuery.validator.addMethod("requiredForWorkflow", function(value, element) {
	return !startLetterCycle() || value != "";
},'Fields required to start Letter Cycle Workflow');

jQuery.validator.addMethod("validSecondLetterDate", function(value, element) {
	var letterCycleWorkflowStep=$("#letterCycleWorkflowStep").val();
	var firstLetterDate=$("#firstLetterDate").val();
	return !startLetterCycle() || letterCycleWorkflowStep != "PENDING_FOR_ALTHANS" || 
		(value !="" && firstLetterDate != "" && validDateFormat(firstLetterDate) && validDateFormat(value) &&
				new Date(value) > new Date(firstLetterDate));
},'2nd Letter Date is required and must be after the 1st Letter Date.');




