
jQuery.validator.setDefaults({
	 errorPlacement: function(error, element){
		            //do nothing
	 },
	 errorContainer      : $('#errorContainer'),
	 errorLabelContainer : "#errorContainer", 
	 errorElement        : "span",
	 errorClass          : "has-error text-danger",
	 validClass          : "",
	 highlight           : function(element, errorClass, validClass) {
		                   $(element).closest("div").addClass(errorClass).removeClass(validClass);
	 },
	 unhighlight         : function(element, errorClass, validClass) {
		                   $(element).closest("div").removeClass(errorClass).addClass(validClass);
	 },
	 onkeyup: false
});

