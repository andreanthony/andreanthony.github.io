var errorClass = "has-error text-danger";
var validClass ="";

function amountHasChanged(element) {
    var dependentField = null;
    element = $(element);
    if (element.hasClass("buildingAmount")) {
        dependentField = element.parents("tbody").find(".buildingExcessAmount");
        if (DEPENDENT_FIELD.positiveAmount(element)) {
            if(!$('#excessRequiredNo').is(':checked')){
                dependentField.attr("readonly", false);
            }
        } else {
            dependentField.attr("readonly", true);
            dependentField.val("");
        }
    }
    if (element.hasClass("contentAmount")) {
        dependentField = element.parents("tbody").find(".contentExcessAmount");
        if (DEPENDENT_FIELD.positiveAmount(element)) {
            if(!$('#excessRequiredNo').is(':checked')){
                dependentField.attr("readonly", false);
            }
        } else {
            dependentField.attr("readonly", true);
            dependentField.val("");
        }
    }
    if (dependentField !== null) {
        dependentField.change();
    }
}

function validateCoverageRequirementForm(){
    $("#coverageRequirementForm").validate({
        //ignore: '.ignore',
        onfocusout: function(element) {
            if ($(element).hasClass('buildingValue') || $(element).hasClass('buildingAmount') ||
                $(element).hasClass('contentValue') || $(element).hasClass('contentAmount')) {
                return true;
            }

            return $(element).valid();
        },
        //[], // to validate hidden field(s). Needed this to validate Value and Amounts
        ignore: ':hidden:not(#valueAmountValidation)',
        rules: {
                'valueAmountValidation' : {compareValueAndRqmt:true},
                'requiredCoverageSourceDto.documentDate' : {required : true, dpDate:true},
                'requiredCoverageSourceDto.cancellationEffectiveDate' : {required : true, dpDate:true},
                'requiredCoverageSourceDto.insuranceType' : {required : true},
                'requiredCoverageSourceDto.propertyType': {required : true},
                'requiredCoverageSourceDto.source': {required : true},
                'requiredCoverageSourceDto.reqdCovSameAsOPB': {required : true},
                'requiredCoverageSourceDto.excessRequired': {required : true},
                'requiredCoverageSourceDto.outstandingPrincipleBalance': {required : true, number: true}
            },
            groups : {
                allFields : 'fiatDocumentDate insuranceType propertyType source reqdCovSameAsOPBYes reqdCovSameAsOPBNo excessRequiredYes excessRequiredNo outstandingPrincipleBalance'
            },
            errorContainer      : $('#errorContainerCoverage'),
            errorLabelContainer : "#errorContainerCoverage"
        });
    // For the field level validation
    $(".buildingValue, .buildingAmount, .contentValue, .contentAmount").on("change", function(evt){validateValueAmount(evt.target);});


    // Arun: TODO: can we merge into one statement. if this is executed multiple times, will we have multiple events
    $(".buildingValue").each(function (){
        $(this).rules("add", {compareValueAndRqmt:true});
    });

    $(".buildingAmount").each(function (){
        $(this).rules("add", {compareValueAndRqmt:true});
    });
    $(".contentValue").each(function (){
        $(this).rules("add", {compareValueAndRqmt:true});
    });
    $(".contentAmount").each(function (){
        $(this).rules("add", {compareValueAndRqmt:true});
    });
}


function validateValueAmount(element) {
    // Building
    var isBuildingSuccessful = true;
    // cumulative check
    $(".buildingValue").each(function() {
        isBuildingSuccessful = checkValueAmount($(this), isBuildingSuccessful, "buildingValue", "buildingAmount");
    });
    if (isBuildingSuccessful) {
        $("#errorContainerCoverageBuilding").hide();
    } else {
        $("#errorContainerCoverageBuilding").show();
    }
    // Content
    var isContentSuccessful = true;
    $(".contentValue").each(function() {
        isContentSuccessful = checkValueAmount($(this), isContentSuccessful, "contentValue", "contentAmount");
    });
    if (isContentSuccessful) {
        $("#errorContainerCoverageContent").hide();
    } else {
        $("#errorContainerCoverageContent").show();
    }
}

function checkValueAmount(element, isSuccessful, valueClass, amountClass) {
    var valueElement = element.closest("tbody").find("." + valueClass);
    var amountElement = element.closest("tbody").find("." + amountClass);
    if (valueElement.val().trim() !== "" &&  amountElement.val().trim() !== "") {
        if (getFloatFromString(amountElement.val()) > getFloatFromString(valueElement.val())) {
            isSuccessful=false;
            // mark element as error
            valueElement.addClass("errorInput");
            amountElement.addClass("errorInput");
        } else {
            // mark element as not an error
            valueElement.removeClass("errorInput");
            amountElement.removeClass("errorInput");
        }
    }

    return isSuccessful;
}

jQuery.validator.addMethod(
        "compareValueAndRqmt",
        function(value, element) {
            // Building
            var isBuildingSuccessful = true;
            $(".buildingValue").each(function() {
                isBuildingSuccessful = checkValueAmount($(this), isBuildingSuccessful, "buildingValue", "buildingAmount");
            });
            if (isBuildingSuccessful) {
                $("#errorContainerCoverageBuilding").hide();
            } else {
                $("#errorContainerCoverageBuilding").show();
            }
            // Content
            var isContentSuccessful = true;
            $(".contentValue").each(function() {
                isContentSuccessful = checkValueAmount($(this), isContentSuccessful, "contentValue", "contentAmount");
            });
            if (isContentSuccessful) {
                $("#errorContainerCoverageContent").hide();
            } else {
                $("#errorContainerCoverageContent").show();
            }
            // Building and Content
            return isBuildingSuccessful && isContentSuccessful;
        },
        function(params, element) {
            return "";
        }
);


var settings = {
    // Number of duplicate name count
    dupNameCount: 0,
    // number of total sum<0 count
    totalSumCount: 0
};


//default spiner config
var opts = {
    // #rgb or #rrggbb
    color: '#ADD8E6',
    // Opacity of the lines
    opacity: 2/4,
    // The number of lines to draw
    lines: 12,
    // The length of each line
    length: 20,
    // The line thickness
    width: 7,
    // The radius of the inner circle
    radius: 20
};

//key to access the spiner object
var spinner;

//declaring trim for al browsers
if(typeof String.prototype.trim !== 'function') {
      String.prototype.trim = function() {
        return this.replace(/^\s+|\s+$/g, '');
      };
}


jQuery.validator.addMethod("uniqueBuildingName", function(value, element) {
    var result = true;
    //check and hightlight duplicate names
    $('.buildingName').each(function() {
        if (isDiffElementSameValues($(this), element)) {
            $(element).attr('pairID', $(this).attr('id'));
            $(this).attr('pairID', $(element).attr('id'));
            hightlightFieldError($(this));
            hightlightFieldError(element);
            result = false;
        }
    });
    //check and unhightlight previous duplicate names which are now resolved
    $('.buildingName').each(
            function() {
                if (isBlank($(this)) || result
                        && ($(this).attr('pairID') === $(element).attr('id'))) {
                    $(this).removeAttr('pairID');
                    unhightlightFieldError($(this));
                }
            });
    //un-higlight the current element if there is not duplicated
    if (result) {
        $(element).removeAttr('pairID');
        unhightlightFieldError(element);
    }
    //enable/disable duplicate errors messages
    return result;
}, "  ");

jQuery.validator.addMethod("totalAmountGreaterThan0", function(value, element) {
    var pairClass = '';
    var pairBalanceTypeClass = '';
    if ($(element).hasClass('buildingAmount')) {
        pairClass = 'contentAmount';
        pairBalanceTypeClass = 'buildingBalanceType';
    } else {
        pairClass = 'buildingAmount';
        pairBalanceTypeClass = 'contentBalanceType';
    }
    var pairElem = $(element).parents('.table-line').find('.' + pairClass);
    // LCP-4281
    if ($(element).attr('id') === "finalExcessContentAmount") {
        pairElem = $("#finalExcessBuildingAmount");
    } else if ($(element).attr('id') === "finalExcessBuildingAmount") {
        pairElem = $("#finalExcessContentAmount");
    } else if ($(element).attr('id') === "finalPrimaryContentAmount") {
        pairElem = $("#finalPrimaryBuildingAmount");
    } else if ($(element).attr('id') === "finalPrimaryBuildingAmount") {
        pairElem = $("#finalPrimaryContentAmount");
    }
    var amountValue = getFloatFromString($(element).val());
    if(amountValue === 0){
        $(element).parents("tr").find("." + pairBalanceTypeClass).attr("disabled", true);
    } else if(amountValue > 0){
        $(element).parents("tr").find("." + pairBalanceTypeClass).attr("disabled", false);
    }

    if (pairElem && !isBlank($(pairElem).val()) && !isBlank($(element).val())) {
        var pairVal = $(pairElem).val();
        var sum = getFloatFromString($(element).val())
                + getFloatFromString(pairVal);
        var elementId = $(element).attr('id');
        var pairElemId = $(pairElem).attr('id');
        if (sum <= 0) {
            if((elementId ==='finalExcessContentAmount' && pairElemId === 'finalExcessBuildingAmount')
                    || (elementId ==='finalExcessBuildingAmount' && pairElemId ==='finalExcessContentAmount')){
                $(element).parents("tr").find(".balanceType").attr("disabled", true);
                return true;
            }else{
                hightlightFieldError(element);
                hightlightFieldError(pairElem);
                return false;
            }
        } else {
            unhightlightFieldError(pairElem);
        }
    }
    if (!isBlank(value)) {
        unhightlightFieldError(element);
    }
    if (!isBlank(pairElem)) {
        unhightlightFieldError(pairElem);
    }
    return true;
},
    //Total of Building and Content amount must be greater than 0.
    " ");

jQuery.validator.addClassRules({
    buildingName : {
        uniqueBuildingName : true
    },
    buildingAmount : {
        totalAmountGreaterThan0 : true
    },
    contentAmount : {
        totalAmountGreaterThan0 : true
    }
});

//overide all required message so as to use the default one prepopulated in the error container
jQuery.extend(jQuery.validator.messages, {
    required : " "
});


function getFloatFromString(stringAmount) {
    return parseFloat(stringAmount.replace(/,/g, ''));
}


function hightlightFieldError(element){
   if(typeof element === 'undefined'){
        return;
   }
   $(element).closest("div").addClass(errorClass).removeClass(validClass);
}

function unhightlightFieldError(element){
   if(typeof element === 'undefined'){
        return;
   }
   $(element).closest("div").removeClass(errorClass).addClass(validClass);
}


function isBlank(str) {
   if(typeof str === 'undefined'){
        return true;
   }
    return (!str || /^\s*$/.test(str));
}

function checkandHightDupNameErrors(){
   $("#nameUniquenessErrorContainer").hide();

       $('.buildingName').each(function() {
       var current = $(this);
       $('.buildingName').each(function() {
           if (isDiffElementSameValues($(this), current)){
               $("#nameUniquenessErrorContainer").show();
               return;
           }
       });
   });
}

function isDiffElementSameValues(e1, e2){
   ///can't  compare empty element
   if( isBlank(e1) || isBlank(e2) ||( $(e1).attr('id')===$(e2).attr('id'))){
      return false;
   }
   return $(e1).val().trim().toLowerCase() === $(e2).val().trim().toLowerCase();

}


function toggleLoader(on) {
    if (on) {
           target = document.getElementById('tableContentID');
           spinner = new Spinner(opts).spin(target);
        return;
    }
    if(spinner){
        spinner.stop();
    }
}