BIR_RULES = {};

BIR_RULES.setConclusion = function(anyButton, conclusion) {
	$(anyButton).siblings('.bir-conclusion').val(conclusion).change();
};

BIR_RULES.acceptableSelector = '.bir-acceptable';
BIR_RULES.acceptableButtonClass = 'btn-success active';
BIR_RULES.acceptableValue = 'ACCEPTABLE';
BIR_RULES.actionRequiredSelector = '.bir-action-required';
BIR_RULES.actionRequiredButtonClass = 'btn-warning active';
BIR_RULES.actionRequiredValue = 'ACTION_REQUIRED';
BIR_RULES.rejectedSelector = '.bir-rejected';
BIR_RULES.rejectedButtonClass = 'btn-danger active';
BIR_RULES.rejectedValue = 'REJECTED';
BIR_RULES.noneButtonClass = 'btn-default';
BIR_RULES.noneValue = '';

BIR_RULES.initializeConclusions = function() {
	$('.bir-conclusion').each(function() {
		var conclusionInput = $(this);
		var conclusion = conclusionInput.val();
		var buttonToPress;
		var buttonClass;
		if (conclusion === BIR_RULES.acceptableValue) {
			buttonToPress = conclusionInput.siblings(BIR_RULES.acceptableSelector);
			buttonClass = BIR_RULES.acceptableButtonClass;
		} else if (conclusion === BIR_RULES.actionRequiredValue) {
			buttonToPress = conclusionInput.siblings(BIR_RULES.actionRequiredSelector);
			buttonClass = BIR_RULES.actionRequiredButtonClass;
		} else if (conclusion === BIR_RULES.rejectedValue) {
			buttonToPress = conclusionInput.siblings(BIR_RULES.rejectedSelector);
			buttonClass = BIR_RULES.rejectedButtonClass;
		} else {
			buttonToPress = conclusionInput.siblings(BIR_RULES.acceptableSelector);
			buttonClass = BIR_RULES.noneButtonClass;
		}
		BIR_RULES.setButtons(buttonToPress, buttonClass);
	});
	$(BIR_RULES.acceptableSelector).off().on('click', BIR_RULES.makeAcceptable);
	$(BIR_RULES.actionRequiredSelector).off().on('click', BIR_RULES.makeActionRequired);
	$(BIR_RULES.rejectedSelector).off().on('click', BIR_RULES.makeRejected);
    $('.btn-unclickable').click(function(e) {
    	e.preventDefault();
    });
};

BIR_RULES.makeAcceptable = function() {
	BIR_RULES.setConclusion(this, BIR_RULES.acceptableValue);
	BIR_RULES.setButtons(this, BIR_RULES.acceptableButtonClass);
};

BIR_RULES.makeActionRequired = function() {
	BIR_RULES.setConclusion(this, BIR_RULES.actionRequiredValue);
	BIR_RULES.setButtons(this, BIR_RULES.actionRequiredButtonClass);
};

BIR_RULES.makeRejected = function() {
	BIR_RULES.setConclusion(this, BIR_RULES.rejectedValue);
    BIR_RULES.setButtons(this, BIR_RULES.rejectedButtonClass);
};

BIR_RULES.clearUserConclusions = function(anyButton) {
	BIR_RULES.setConclusion(anyButton, BIR_RULES.noneValue);
	anyButton = $(anyButton);
	BIR_RULES.clearSingleConclusion(anyButton);
	var siblingButtons = anyButton.siblings('button');
	siblingButtons.removeClass('btn-success btn-warning btn-danger active');
	siblingButtons.addClass(BIR_RULES.noneButtonClass);
};

BIR_RULES.clearSingleConclusion = function(anyButton) {
	anyButton = $(anyButton);
	anyButton.removeClass('btn-success btn-warning btn-danger active');
	anyButton.addClass(BIR_RULES.noneButtonClass);
};

BIR_RULES.enableUserConclusions = function(anyButton) {
	anyButton = $(anyButton);
	var siblingButtons = anyButton.siblings('button');
	BIR_RULES.enableElements(anyButton);
	BIR_RULES.enableElements(siblingButtons);
};

BIR_RULES.disableUserConclusions = function(anyButton, clear) {
	anyButton = $(anyButton);
	if (clear) {
		BIR_RULES.clearUserConclusions(anyButton);
	}
	var siblingButtons = anyButton.siblings('button');
	BIR_RULES.disableElements(anyButton, clear);
	BIR_RULES.disableElements(siblingButtons, clear);
};

BIR_RULES.enableElements = function(enableSelector) {
	var elementsToEnable = $(enableSelector);
	elementsToEnable.each(function(index, ele) {
		var element = $(ele);
		if (BIR_RULES.shouldEnableDependentField(element)) {
			if (element.hasClass('userConclusion')) {
				BIR_RULES.enableUserConclusions(element.siblings('button'));
			}
			element.removeAttr('disabled');
			element.removeClass('ignore');
		}
	});
};

BIR_RULES.shouldEnableDependentField = function(ele) {
	var wantToVerify = $(ele).closest('.collateralCoverageTableContainer').find('.want-to-verify');
	return wantToVerify.length === 0 || wantToVerify.is(':checked');
};

BIR_RULES.disableElements = function(disableSelector, clear) {
	var elementsToDisable = $(disableSelector);
	elementsToDisable.each(function(index, ele) {
		var element = $(ele);
		if (clear && $.inArray(this.type,['radio','checkbox']) !== -1) {
			element.prop("checked", false);
    	} else if (clear) {
    		element.val('');
    	}
		if (element.hasClass('userConclusion')) {
			BIR_RULES.disableUserConclusions(element.siblings('button'), clear);
		} else if (element.hasClass('systemConclusion')) {
			element.closest('.form-group,.input-group').find('button').hide();
		}
		element.addClass('ignore').change().blur().focusout();
		clearValidationError(element);
		element.attr('disabled','disabled');
	});
};

BIR_RULES.setChangeEvent = function(listenTo, inValues, inSelector, outSelector) {
	$(listenTo).change(function() {
		var shouldEnable = $(this).is(':enabled') || this.id==='proofOfCoverageData.policyType';
		if ($.inArray(this.value, inValues) !== -1) {
			if (shouldEnable) {
				BIR_RULES.enableElements(inSelector);
			}
            if (outSelector) {
            	BIR_RULES.disableElements(outSelector, true);
            }
        } else {
        	BIR_RULES.disableElements(inSelector, true);
			if (outSelector) {
				BIR_RULES.enableElements(outSelector);
            }
        }
    });
};

BIR_RULES.setButtons = function(buttonObject, newClass) {
	var thisButton = $(buttonObject);
	var siblingButtons = thisButton.siblings('button');
	siblingButtons.removeClass('btn-success btn-warning btn-danger active').addClass(BIR_RULES.noneSelector);
	thisButton.removeClass(BIR_RULES.noneSelector).addClass(newClass);
	thisButton.closest(".form-group").find('input,select').each(function(index, ele) {
		$(ele).blur().focusout();
	});
};

function EnableIfText(enableSelector) {
	$(enableSelector).each(function() {
		var element = $(this);
		var previous = element.val();
		element.focus(function() {
			previous = this.value;
		});
		if (element.is('select')) {
			element.change(function(){
				previous = BIR_RULES.setEnableListener(this, previous);
			}).change();
		} else {
			element.blur(function(){
				previous = BIR_RULES.setEnableListener(this, previous);
			});
			element.keyup(function(){
				previous = BIR_RULES.setEnableListener(this, previous);
			}).keyup();
		}
	});
}

BIR_RULES.setEnableListener = function(element, previous) {
	var acceptableButton =
		$(element).closest('.form-group').find('.bir-acceptable');
	if (element.value === "") {
		BIR_RULES.disableUserConclusions(acceptableButton, true);
	} else if (element.value !== previous){
		BIR_RULES.clearUserConclusions(acceptableButton);
		BIR_RULES.enableUserConclusions(acceptableButton);
	}
	return element.value;
};

BIR_RULES.policyType = function() {
	var policyTypeHidden = $('#proofOfCoverageData\\.policyType');
	var policyTypeSelect = $('#policyTypeSelect');
	var blanketCoverageType = $('#proofOfCoverageData\\.blanketCoverageData\\.blanketCoverageType');
	policyTypeHidden.change(function() {
		policyTypeSelect.val(this.value);
		if ($.inArray(this.value, ['PRIVATE','BINDER','ACCORD']) !== -1) {
			blanketCoverageType.prop('disabled',false);
        } else {
        	blanketCoverageType.val('');
        	blanketCoverageType.change();
        	blanketCoverageType.prop('disabled',true);
        }
	});
	policyTypeHidden.change();
};

BIR_RULES.eoiAndPolicyType = function() {
	BIR_RULES.setChangeEvent('#proofOfCoverageData\\.policyType', ['PRIVATE'], 'input[type=radio][name=proofOfCoverageData\\.coversAllRiskOfFlood]');
	if (!$('#proofOfPayment').is(':disabled')) {
		BIR_RULES.setChangeEvent('#eoiType', ['AWP','BWP'], '#proofOfPayment');
	}
    var policyType = $('#proofOfCoverageData\\.policyType');
    $('#eoiType').change(function() {
    	$('#signedByAgentContainer').hide();
    	if ($.inArray(this.value, ['NP']) !== -1) {
            policyType.val('NFIP');
        } else if ($.inArray(this.value, ['AWP']) !== -1) {
            policyType.val('APPLICATION');
            $('#signedByAgentContainer[data-show-condition=true]').show();
        } else if ($.inArray(this.value, ['BWP']) !== -1) {
            policyType.val('BINDER');
        } else if ($.inArray(this.value, ['PPTCRAEA','PPTCEA','PPTCRA']) !== -1) {
            policyType.val('PRIVATE');
        } else if ($.inArray(this.value, ['PP','PPTCSBAC']) !== -1) {
            policyType.val('PRIVATE');
        } else if ($.inArray(this.value, ['ANCAPYFPOF','AWCONPYFPOF']) !== -1) {
            policyType.val('ACCORD');
        }
        $('#proofOfCoverageData\\.policyType').change();
    });
    $('#eoiType').change();
};

BIR_RULES.condoAssociationPolicy = function() {
	BIR_RULES.setChangeEvent('input[type=radio][name=condoAssociationPolicy]', ['Yes'], '.condo-yes', '.condo-no');
    $('input[type=radio][name=condoAssociationPolicy]').filter(':checked').change();
};

BIR_RULES.floodZoneListed = function() {
	 BIR_RULES.setChangeEvent('input[type=radio][name=proofOfCoverageData\\.floodZonesListed]', ['Yes'], '.floodZone');
	 $('input[type=radio][name=proofOfCoverageData\\.floodZonesListed]').filter(':checked').change();
};

BIR_RULES.jpmLienPosition = function() {
	var init = true;
	$('#jpmLienPosition').change(function() {
		var acceptableButton = $(this).closest('.form-group').find('.bir-acceptable');
		var actionRequiredButton = acceptableButton.siblings('.bir-action-required');
		if (this.value === "FST" || this.value === "NL") {
			BIR_RULES.enableElements(acceptableButton);
			acceptableButton.click();
			BIR_RULES.disableElements(actionRequiredButton, true);
		} else if (this.value === "") {
			BIR_RULES.disableUserConclusions(acceptableButton, true);
		} else if (init) {
			BIR_RULES.enableUserConclusions(acceptableButton);
		} else {
			BIR_RULES.clearUserConclusions(acceptableButton);
			BIR_RULES.enableUserConclusions(acceptableButton);
		}
		init = false;
	});
	$('#jpmLienPosition').change();
};

BIR_RULES.blanketBuilding = function() {
	BIR_RULES.disableElements('.blanket-conts,.blanket-comb', true);
	BIR_RULES.enableElements('.blanket-bldg');
	BIR_RULES.switchToBlanketAmounts();
	BIR_RULES.splitAmounts();
	$('.blanket-contents-amount').hide();
	$('.blanket-building-amount').show();
};

BIR_RULES.blanketContents = function() {
	BIR_RULES.disableElements('.blanket-bldg,.blanket-comb', true);
	BIR_RULES.enableElements('.blanket-conts');
	BIR_RULES.switchToBlanketAmounts();
	BIR_RULES.splitAmounts();
	$('.blanket-building-amount').hide();
	$('.blanket-contents-amount').show();
};

BIR_RULES.blanketAndOr = function() {
	BIR_RULES.disableElements('.blanket-comb', true);
	BIR_RULES.enableElements('.blanket-bldg,.blanket-conts');
	BIR_RULES.switchToBlanketAmounts();
	BIR_RULES.splitAmounts();
	$('.blanket-building-amount,.blanket-contents-amount').show();
};

BIR_RULES.blanketCombined = function() {
	BIR_RULES.disableElements('.blanket-bldg,.blanket-conts', true);
	BIR_RULES.enableElements('.blanket-comb');
	BIR_RULES.switchToBlanketAmounts();
	BIR_RULES.mergeAmounts();
	$('.blanket-building-amount').show();
};

BIR_RULES.blanketNone = function() {
	BIR_RULES.disableElements('.blanket-bldg,.blanket-conts,.blanket-comb', true);
	$('.blanket-checkbox').prop('checked',false).change();
	$('.blanket-building-amount,.blanket-contents-amount').hide();
	BIR_RULES.splitAmounts();
	$('.blanket-checkbox').addClass('ignore');
	$('.coverage-amount-input').removeClass('ignore');
	$('.coverage-amount').show();
};

BIR_RULES.switchToBlanketAmounts = function() {
	$('.coverage-amount-input').val('0.00').addClass('ignore').change();
	$('.coverage-amount').hide();
	$('.blanket-checkbox').removeClass('ignore');
};

BIR_RULES.mergeAmounts = function() {
	$(".contents-amount-cell").hide();
   	$(".building-amount-cell").prop("colspan",2);
};

BIR_RULES.splitAmounts = function() {
	$(".building-amount-cell").prop("colspan",1);
	$(".contents-amount-cell").show();
};

BIR_RULES.blanketCoverageType = function() {
	var checkAllDiv = $('.checkAllBlanketPolicy');
	var checkAllCheckbox = $(".checkAllBlanketPolicyCheckbox");
	checkAllCheckbox.change(function(){
		var amountCells = $(this).closest('.collateralCoverageTableContainer').find('.building-amount-cell,.contents-amount-cell');
    	amountCells.find('input:checkbox').prop('checked', $(this).is(':checked'));
    });

	$('.blanket-checkbox').change(function() {
		var checkAllForCollateral = $(this).closest('.collateralCoverageTableContainer').find(".checkAllBlanketPolicyCheckbox");
		checkAllForCollateral.prop('checked',false);
	});

	$('#proofOfCoverageData\\.blanketCoverageData\\.blanketCoverageType').change(function() {
        if (this.value==='BLDG') {
        	checkAllDiv.show();
        	BIR_RULES.blanketBuilding()
        } else if (this.value==='CONTS') {
        	checkAllDiv.show();
        	BIR_RULES.blanketContents();
        } else if (this.value==='AND_OR') {
        	checkAllDiv.show();
        	BIR_RULES.blanketAndOr();
        } else if (this.value==='COMB') {
        	checkAllDiv.show();
        	BIR_RULES.blanketCombined();
        } else {
        	checkAllCheckbox.prop('checked',false);
        	checkAllCheckbox.change();
        	checkAllDiv.hide();
        	BIR_RULES.blanketNone();
        }
    });
	$('#proofOfCoverageData\\.blanketCoverageData\\.blanketCoverageType').change();
};

BIR_RULES.buildingIsCovered = function(element) {
	var covered = false;
	var coverageAmounts = $(element).closest('tr').find('.blanket-checkbox,.coverage-amount-input');
	$.each(coverageAmounts, function(i, val) {
		var amount = $(val);
		if (amount.is(':disabled')) {
			/*do nothing*/
		} else if (amount.is(':checkbox') && amount.is(':checked')) {
			covered = true;
		} else if (amount.is(':text')) {
			var numberTest = amount.val().replace(/,/g, '');
			covered = covered || !$.isNumeric(numberTest) || parseFloat(numberTest) > 0;
		}
	});
	return covered;	
};

BIR_RULES.buildingMap = {};

BIR_RULES.propertyType = function() {
	$('.propertyType').each(function() {
		var initial = BIR_RULES.buildingIsCovered(this);
		BIR_RULES.buildingMap[this.id] = initial;
		if (!initial) {
			BIR_RULES.disableElements(this, false);
		}
	});
	$('.blanket-checkbox,.coverage-amount-input').change(function() {
		var prior = BIR_RULES.buildingMap[this.id];
		var current = BIR_RULES.buildingIsCovered(this);
		var propertyTypeSelect;
		if (current && !prior) {
			propertyTypeSelect = $(this).closest('tr').find('.propertyType');
			BIR_RULES.enableElements(propertyTypeSelect);
			BIR_RULES.buildingMap[this.id] = current;
		} else if (!current && prior) {
			propertyTypeSelect = $(this).closest('tr').find('.propertyType');
			BIR_RULES.disableElements(propertyTypeSelect, false);
			BIR_RULES.buildingMap[this.id] = current;
		}
	});
	$('.blanket-checkbox,.coverage-amount-input').change();
};

BIR_RULES.initVerify = function() {
	$('.want-to-verify').change(function() {
		var inputs = $(this).closest('.collateralCoverageTableContainer').find(
			'.collateralCoverageInputContainer input,.collateralCoverageInputContainer select').not('.initial-coverage-amount');
		if (!this.checked) {
			BIR_RULES.disableElements(inputs, false);
		} else {
			BIR_RULES.enableElements(inputs);
			$('input[type=radio][name=condoAssociationPolicy]').filter(':checked').change();
			$('input[type=radio][name=proofOfCoverageData\\.floodZonesListed]').filter(':checked').change();
		}
	});
	$('.want-to-verify').change();
};
