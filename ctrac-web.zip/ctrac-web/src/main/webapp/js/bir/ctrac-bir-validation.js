var initializeBIRValidation = function() {
	var validator = $("#policyForm").validate({
		ignore: '.ignore',
		focusCleanup: true,
		onfocusout: function(element) {
			if ($(element).hasClass('ignore')) {
				return true;
			}
			return $(element).valid();
		},
        rules: {
        	'collateral-id' : { atLeastOneCollateral : true },
        	'proofOfCoverageData.effectiveDate' : { dpDate:true },
        	'proofOfCoverageData.expirationDate' : { dpDate: true, futureExpirationDate: true, greaterThanEffectiveDate: true, validExpirationDate: true },
        	'proofOfCoverageData.cancellationEffectiveDate' : { dpDate: true, cancellationDateGreaterThanEffectiveDate: true },
        	'proofOfCoverageData.agentData.contactDetailDto.faxNumber' : {
        		required : {
			        depends: missingContactInfo
		        },
		        validFaxNumber : {
			        depends: missingContactEfaxInfo
		        }
			},
			'proofOfCoverageData.agentData.contactDetailDto.emailAddress' : {
				required : {
			        depends: missingContactInfo
		        },
				validateMultipleEmail:true
			},
			'totalNumberOfCondoUnits' : { digits : true }
		},
        errorContainer      : $('#errorContainerInsurancePolicy'),
        errorLabelContainer : "#errorContainerInsurancePolicy",
        errorElement        : "span",
        errorClass          : "has-error text-danger alert-element-padding",
        validClass          : "",
	   	highlight : function(element) {
	   		setValidationError(element);
	   	},
	   	unhighlight : function(element) {
	   		clearValidationError(element);
	   	}
    });
	return validator;
};

var setValidationError = function(element) {
	$(element).closest(".form-group").addClass("has-error text-danger");
};

var clearValidationError = function(element) {
	$(element).closest(".form-group").removeClass("has-error text-danger");
};

jQuery.extend(jQuery.validator.messages, { required:' ', min:' ', digits:' ' });

jQuery.validator.addMethod("atLeastOneCollateral", function(value, element) {
	return $('.collateralCoverageTable').length > 0;
},' ');

jQuery.validator.addMethod("validFaxNumber", function(value, element) {
	return (!element ||  $(element).val().replace(/\D/g, '').trim().length >= 10);
},' ');

jQuery.validator.addMethod("conclusionRequired", function(value, element) {
	if (isNotMigrated()) {
		var ignoreMe = $(element).hasClass('ignore');
		var conclusion = $(element).closest(".form-group").find('.bir-conclusion').val();
		return ignoreMe || (conclusion && conclusion !== '');
	}
	return true;	
},' ');

jQuery.validator.addMethod("greaterThanEffectiveDate", function(value, element) {
	if (!validEffectiveAndExpirationDateFormats()) {
		return true;
	}
	return new Date($("#proofOfCoverageData\\.expirationDate").val()) > new Date($("#proofOfCoverageData\\.effectiveDate").val());
},'Expiration date must be greater than the effective date.');

jQuery.validator.addMethod("futureExpirationDate", function(value, element) {
	return isDateInFuture($(element).val());
},'Expiration date must be a future date.');

jQuery.validator.addMethod("cancellationDateGreaterThanEffectiveDate", function(value, element) {
    if (!validEffectiveAndCancellationDateFormats()) {
        return true;
    }
    return new Date($("#birCancellationDate").val()) >= new Date($("#proofOfCoverageData\\.effectiveDate").val()) &&
        new Date($("#birCancellationDate").val()) < new Date($("#proofOfCoverageData\\.expirationDate").val()) &&
        cancellationDateLessThanYear();
},'Cancellation Effective date must be between effective date and expiration date but not the same as expiration date.');

var cancellationDateLessThanYear = function(){
    var date = new Date();
    date.setFullYear(date.getFullYear()+1);

    return new Date($("#birCancellationDate").val()) < date;
}

var validEffectiveAndCancellationDateFormats = function() {
    return validDateFormat($("#proofOfCoverageData\\.effectiveDate").val()) && validDateFormat($("#birCancellationDate").val());
};

var validEffectiveAndExpirationDateFormats = function() {
	return validDateFormat($("#proofOfCoverageData\\.effectiveDate").val()) && validDateFormat($("#proofOfCoverageData\\.expirationDate").val());
};

var validDateFormat = function(val) {
	return !(/Invalid|NaN/.test(new Date(val)));
};

var isDateInFuture = function(val) {
	return (validDateFormat(val) && new Date(val) > new Date($("#expDateHidden").val()));
};

var missingContactInfo = function() {
	if (isNotMigrated()) {
		return isEmpty($('#proofOfCoverageData\\.agentData\\.contactDetailDto\\.emailAddress')) &&
			isEmpty($('#proofOfCoverageData\\.agentData\\.contactDetailDto\\.faxNumber'));
	}
	return false;
};
var missingContactEfaxInfo = function() {
	return $('#proofOfCoverageData\\.agentData\\.contactDetailDto\\.faxNumber').val() != '';
};
var isEmpty = function(element) {
	return !element || $(element).val().trim().length === 0;
};

function getFloatFromString(stringAmount) {
	return parseFloat(stringAmount.replace(/,/g, ''));
}

jQuery.validator.addMethod("validCoverageAmounts", function(value, element) {
	var onePositive = false;
	var allNonNegative = true;
	var allCoverageAmounts = $(element).closest('table').find('.coverage-amount-input');
	allCoverageAmounts.each(function(j, input) {
		var amount = getFloatFromString($(input).val());
		if (amount < 0) {
			allNonNegative = false;
		} else if (amount > 0) {
			onePositive = true;
		}
	});
	if (allNonNegative && onePositive) {
		clearValidationError(allCoverageAmounts);
	} else {
		setValidationError(allCoverageAmounts);
	}
	return allNonNegative && onePositive;
}, ' ');

jQuery.validator.addMethod("validBlanketAmounts", function(value, element) {
	var checkboxes = $(element).closest('table').find('.blanket-checkbox');
	var valid = false;
	checkboxes.each(function(j, input){
		var checked = $(input).prop('checked');
		if(checked){
			valid = true;
		}
	});
	if(valid){
		clearValidationError(checkboxes);
	}
	else{
		setValidationError(checkboxes);
	}
	return valid;
}, ' ');

jQuery.validator.addMethod("validExpirationDate",function(value,element){
	var policyType=$("#policyTypeHidden").val();
	var date1=new Date($("#proofOfCoverageData\\.expirationDate").val());
	var date2=new Date($("#proofOfCoverageData\\.effectiveDate").val());
	var oneDay=(1000*60*60*24);
	var diff=new Date(date1-date2);
	var numOfDays=Math.round(diff/oneDay);
	if(policyType==="APPLICATION"){
		if(numOfDays>=30 || (new Date(date1)<new Date(date2))){
			return false;
		}
		return true;
	}
	if(policyType==="BINDER"){
		if(numOfDays>=90 || (new Date(date1)<new Date(date2))){
			return false;
		}
		return true;
	}
	return true;
},function(element,params){
	var errMsg="";
	var refDate=$("#expDateHidden").val();
	var policyType=$("#policyTypeHidden").val();
	if(policyType==="APPLICATION"){
		errMsg="An application should have an expiration date between "+ addDays(new Date(refDate), 0) +" and "+addDays(new Date(refDate),30)+".";
	}
	if(policyType==="BINDER"){
		errMsg="A binder should be have an expiration date between "+ addDays(new Date(refDate), 0) +" and "+addDays(new Date(refDate),90)+".";
	}
	return errMsg;
});

function addDays(date,days){
	var newDate = new Date(date.getTime()+days*24*60*60*1000);
	var dayPart = newDate.getDate() + "";
	if (dayPart.length === 1) {
		dayPart = "0"+dayPart;
	}
	var monthPart = (newDate.getMonth() + 1) + "";
	if (monthPart.length === 1) {
		monthPart = "0"+monthPart;
	}
	return ( monthPart + "/" + dayPart + "/" + newDate.getFullYear());
}

var isNotMigrated = function() {
	return $('input[name=proofOfCoverageData\\.migrated]:checked').val() === 'false';
};

jQuery.validator.addClassRules({
	'userConclusion' : {
		conclusionRequired : true
	},
	'zipCode' : {
		validateZipcodeUS : true
	},
	'coverage-amount-input' : {
		validCoverageAmounts : true
	},
	'blanket-checkbox' : {
		validBlanketAmounts : true
	},
	'required-if-not-migrated' : {
		required : {
			depends : function(element) {
				return isNotMigrated() && !$(element).hasClass('ignore');
			}
		}
	},
	'required-if-awp' : {
		required : {
			depends : function(element) {
				//Only required when radio elements show condition was true and policy type is Application with Pop and Radio elements is enabled
				return $('#signedByAgentContainer').attr('data-show-condition') === 'true' && $('#eoiType').val() === 'AWP' &&
                    !$('#signedByAgentContainer input[type=radio]').prop("disabled");
			}
		}
	}
});


