BIR = {};

BIR.settings = {
	title: "",
	rid: "",
	status: "",
	numDocs: 0,
	reload: false
};

BIR.spinnerOpts = {
    color: '#ADD8E6', // #rgb or #rrggbb
    opacity: 2/4,     // Opacity of the lines
    lines: 12,        // The number of lines to draw
    length: 14,       // The length of each line
    width: 7,         // The line thickness
    radius: 20        // The radius of the inner circle
};

BIR.currentReferenceDate = "";
var isBrowserClose = true;
BIR.isPolicyInactive = false;

$(document).ready(function(){
	$('.bir-pia-yes').click(function() {
	       $('#alertPIA').show();
	    });
	$('.bir-pia-no').click(function() {
	       $('#alertPIA').hide();
	    });
	$(window).on('unload', closeCallBack);
});

BIR.canEnableMigrPolicy = function (){
	if($('#hasRoleVerifier').length > 0){
		$('#migrYes').prop('disabled',false);
		$('#migrNo').prop('disabled',false);
	}else{
		$('#migrYes').prop('disabled',true);
		$('#migrNo').prop('disabled',true);
	}
};

BIR.postSubmit = function(response) {
	$('#container').replaceWith($($.parseHTML(response)).filter('#container'));
	window.scrollTo(0,0);
	BIR.initializeAll(BIR.currentReferenceDate);
	if($(response).find("#disableSubmit").val() === 'true'){
		$('#bir-save').prop('disabled',true);
	}
	else{
		$('#bir-save').prop('disabled',false);
	}
	setValidationError($('.initial-coverage-amount')); //highlight mismatched fields

	//Opener window (Collateral details policies & workFlow section has to be reloaded)
    if(window.opener === undefined){
    	return;
	}
	var mainScreen = window.opener.ALL_SECTIONS !== undefined ? window.opener : window.opener.opener;
	if(mainScreen.ALL_SECTIONS !== undefined){
        //Refresh the policies / Required Insurance Coverage / WorkFlow Section
        mainScreen.ALL_SECTIONS.refreshCollateralPageSections(
			["workflowDetailsRow","insuranceSectionRow","requiredInsuranceCoverageSection"]);
	}
};

BIR.initiateRenewal = function(e, rid, collateralRid) {
	e.preventDefault();
	window.open(
			CTRAC.root+'bir/launchBIROverlay?policyRid='+rid+
			'&collateralRid='+collateralRid+'&mode=3', 'CTRAC - Borrower Insurance Review');
};

BIR.initiateReplacement = function(e, rid, collateralRid) {
    e.preventDefault();
    window.open(
        CTRAC.root+'bir/launchBIROverlay?policyRid='+rid+
        '&collateralRid='+collateralRid+'&mode=4', 'CTRAC - Borrower Insurance Review');
};

BIR.initPageConfig = function(bucketKey, allowEmpty){
	BIR.pageConfig = {
    taskUUId :  bucketKey,
    cmdClass : 'submitCmd',
    attachDivID : 'insurance-upload-container', // div containing browse button
    inputFileID : 'insurance-upload',           // id of the file input form
    AttachmentErrMs : 'insurancePolicyAttachmentErrMs', // div that displays attachment error message
    emailFormID : 'policyForm',   // id of the email form (global from)
    maxTotalQueueSize : '10MB',   // limit on the sum of the size of all files in the queue in MB or KB
    loaderDivID : 'container',    // where to show the spin loader
    allowEmptyAttachement: allowEmpty, // allow no attachments when there are attachment attached
    emptyFileErrMsg: "An insurance policy file is required to be attached. Please attach the document.",
    appendGyfon: true,
    /* allDoneCallBack: uploadCallBack, */
    asynch:true,
    submitCallBack: BIR.postSubmit,
    /* submitErrorCallBack: COLLSCREENAjaxError.ajaxErrorProcessing, */
    uploadMinimun: 0
	};
};

BIR.initUploadifyConfig = function(bucketKey){
	BIR.uploadifyConfig = {
    'formData'     : { 'taskUUId' : bucketKey},
    'uploadLimit'  : 6,
    'fileSizeLimit': '10MB', //individual file size limit
    'auto'         : false,
    'fileTypeExts' : '*.pdf',
    'fileTypeDesc' : 'PDF Files',
    'maxSizeErrMsg': "\nFiles were not attached. The number of files selected exceeds the maximum upload limit of six (6) and/or the maximum size of 10MB.",                 //Error message when file size exceeds total allowable file size limit
    'uploadLimitErrMsg': "\nFiles were not attached. The number of files selected exceeds the maximum upload limit of six (6) and/or the maximum size of 10MB." //Error message when file count exceeds max file count
	};
};

BIR.faxFormatter = function() {
	var value = $(this).val().replace(/\D/g, '');
	if (value.length > 10) {
		value = ['(',value.slice(0, 3),') ',value.slice(3, 6),'-',value.slice(6, 10)].join('');
	} else if (value.length > 6) {
		value = ['(',value.slice(0, 3),') ',value.slice(3, 6),'-',value.slice(6) ].join('');
	} else if (value.length === 6) {
		value = ['(',value.slice(0, 3),') ',value.slice(3, 6),'-' ].join('');
	} else if (value.length > 3) {
		value = ['(',value.slice(0, 3),') ',value.slice(3) ].join('');
	} else if (value.length === 3) {
		value = '('+value+') ';
	} else if (value.length > 0) {
		value = '('+value;
	}
	$(this).val(value);
};

BIR.initializeFieldTypes = function(currentReferenceDate) {
    $('.datepicker').not("#eoiReceivedDate").bind('keydown', function(event) {
        if (event.which === 13) {
            var e = jQuery.Event("keydown");
            e.which = 9;// tab
            e.keyCode = 9;
            $(this).trigger(e);
            return false;
        }
    }).datepicker({
          showOn: "button",
          buttonImage: '../images/calendar-icon.png',
          buttonImageOnly: true,
          buttonText: '',
          showAnim: 'slide',
          onSelect: function(dateText, inst) {
        	  if (dateText !== inst.lastVal) {
                  BIR.toggleAddCollateralIdToBIR($('#birCancellationDate').val());
                  $(this).change().focusout();
              }
          }
    });

    $("#eoiReceivedDate").bind('keydown', function(event){
    	 if (event.which === 13) {
            var e = jQuery.Event("keydown");
            e.which = 9;// tab
            e.keyCode = 9;
            $(this).trigger(e);
            return false;
        }
    }).datepicker({
    	 showOn: "button",
         buttonImage: '../images/calendar-icon.png',
         buttonImageOnly: true,
         buttonText: '',
         showAnim: 'slide',
         maxDate: currentReferenceDate,
         onSelect: function(dateText, inst) {
       	  if (dateText !== inst.lastVal) {
                 $(this).change().focusout();
             }
         }
    });
    $('.datepicker').each(function(index, element) {
		 var isDisabled = $(element).is(':disabled');
	        if (isDisabled) {
	        	$(element).attr('readonly',true).datepicker("option", "disabled", true);
	        }
    });
	$('.numeric').each(function() {
        $(this).autoNumeric('init');
    });
	$("#proofOfCoverageData\\.agentData\\.contactDetailDto\\.faxNumber").blur(BIR.faxFormatter);
	$("#proofOfCoverageData\\.agentData\\.contactDetailDto\\.faxNumber").keyup(BIR.faxFormatter).keyup();

	$('#collateral-id').off().on('keyup', function(e){
		var code = e.which;
		if(code===13) {
			e.preventDefault();
			$('#add-collateral-to-policy').click();
			return false;
		}
	}).on('keydown', function(e) {
		var code = e.which;
		if(code===13) {
    		e.preventDefault();
    		return false;
		}
	});
    $('#birCancellationDate').off().on('keyup', function(e){
        BIR.toggleAddCollateralIdToBIR($(this).val());
    });
 };
BIR.toggleAddCollateralIdToBIR = function(value) {
    $('#collateral-id').prop('disabled', value !== '' || BIR.isPolicyInactive);
};

BIR.initializeRules = function() {
	BIR_RULES.initVerify();
	BIR_RULES.policyType();
	BIR_RULES.eoiAndPolicyType();
	BIR_RULES.condoAssociationPolicy();
	BIR_RULES.floodZoneListed();
	BIR_RULES.jpmLienPosition();
	BIR_RULES.blanketCoverageType();
	BIR_RULES.propertyType();
	new EnableIfText('#proofOfCoverageData\\.insuredName');
	new EnableIfText('.individualCondoUnitNumbers');
	new EnableIfText('.propertyType');
	BIR_RULES.initializeConclusions();
};

BIR.initializeButtons = function() {

};

BIR.disableGlyphiconButton = function(readOnlyUserRole) {
	if(readOnlyUserRole){
		$(document).ready(function(){
			$(".btn-sm,.btn-unclickable").attr("disabled", true);
			$('#jpmLienPosition').prop('disabled',true);
			$('#birCancellationDate').attr('readonly',true).datepicker("option", "disabled", true);
		});
	}
};
BIR.initializeAll = function(currentReferenceDate) {
	if(BIR.currentReferenceDate!==currentReferenceDate){
		BIR.currentReferenceDate = currentReferenceDate;
	}
	BIR.spinner = new Spinner(BIR.spinnerOpts);
	var allowEmptyAttachments = $('#doc-size').val() > 0;
	BIR.container = document.getElementById('container');
	BIR.initializeButtons();
	BIR.initializeFieldTypes(currentReferenceDate);
	BIR.initializeRules();
	BIR.initPageConfig(BIR.getAttachmentBucketKey(), allowEmptyAttachments);
	BIR.initUploadifyConfig(BIR.getAttachmentBucketKey());
	initEmailAttachments(BIR.pageConfig, BIR.uploadifyConfig);
	BIR.validator = initializeBIRValidation();
	$('#bir-cancel').click(BIR.closeBIRWindow);

	$('input,select').change(function() {
		$('#bir-save').prop('disabled',true);
	});
	$('.mismatch').change(function() {
		$('#bir-save').prop('disabled',false);
	});
	$(document).ajaxComplete(function() {
		BIR.spinner.stop();
	});
	$('#errorContainerInsurancePolicy').hide();
	$('.form-group').removeClass('has-error text-danger');

	var birPolicyStatus = $('#birPolicyStatus').val();
    BIR.isPolicyInactive = birPolicyStatus==='CANCELLED' || birPolicyStatus==='EXPIRED' || birPolicyStatus==='REJECTED' || birPolicyStatus==='REPLACED';
    if(!(birPolicyStatus==='PENDING_VERIFICATION' && $('#birCancellationDate').val() ==='') || BIR.isPolicyInactive){
        $('#jpmLienPosition').prop('disabled',true);
    }
    attachFieldErrorBehaviorListener();
    $('#birInsuranceAgency').bind("cut copy paste",function(e) {
        e.preventDefault();
    });
    $('#birInsuranceAgency').autocomplete({
   	 minLength:3,
   	 source: function (request, response) {
   		 var cid= $("meta[name='_cid']").attr("content");
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url : 'loadInsuranceCompanyNames' +'?_cid='+cid+'&searchParam='+ $('#birInsuranceAgency').val(),
                dataType: "json",
                success: function(data) {
                    response($.map(data, function(obj) {
                        return {
                            label: obj.label,
                            value: obj.value,
                            description: obj.description
                        };
                    }));
                },
                error: function(result) {
                    alert("Error ocured while loading data for Insurance Agency Name suggestions");
                }

            });
        }
   });
};

BIR.shouldEnableCoverageAmountSection = function(e) {
	var btnValue = $("#bir-save").attr("value");
	var cancellationEffectiveDate = $('#birCancellationDate').val();
	if(btnValue === 'Submit and Verify'){
		if(cancellationEffectiveDate === ""){
			$('.coverage-amount-input').prop('disabled',false);
		}else{
			$('.coverage-amount-input').prop('disabled',true);
		}
	}
};
BIR.addCollateralToBIR = function(e) {
	e.preventDefault();
    $('#birCancellationDate').attr('readonly',true).datepicker("option", "disabled", true);
	var collateralID = $("#collateral-id").val();
	BIR.performCollateralAction(collateralID, 'add');
};

BIR.removeCollateralFromBIR = function(e, collateralID) {
    e.preventDefault();
    BIR.performCollateralAction(collateralID, 'remove');
};

//delete BIR
BIR.deleteBIR = function(e,collateralID) {
	e.preventDefault();
	var url="deleteBorrowerInsuranceReview";
	var cid= $("meta[name='_cid']").attr("content");
	if(!confirm("Are you sure you want to delete this BIR policy?")){
		 return false;
	}
	$('#policy-delete').prop('disabled',true);
	$('#bir-save').prop('disabled',true);
	$('#bir-review').prop('disabled',true);
	$('#bir-cancel').prop('disabled',true);
	BIR.spinner.spin(container);
	$.ajax({
		type : "POST",
		url : url+'?_cid='+cid,
		data : $('form#policyForm').serialize(),
		cache: false,
		success : function(response){
			BIR.spinner.stop();
			window.close();
		}
	});
};
//delete BIR

//Override BIR
BIR.overrideAdmin = function(e,collateralID) {
	e.preventDefault();
	var url="overrideAdmin";
	var cid= $("meta[name='_cid']").attr("content");
	$('#policy-delete').prop('disabled',true);
	$('#bir-save').prop('disabled',true);
	$('#bir-review').prop('disabled',true);
	$('#bir-cancel').prop('disabled',true);
	BIR.spinner.spin(container);
	$.ajax({
		type : "POST",
		url : url+'?_cid='+cid,
		data : $('form#policyForm').serialize(),
		cache: false,
		success: function(response) {
			BIR.spinner.stop();
        	$('#bir-collateral-details-table').replaceWith($(response).find('#bir-collateral-details-table'));
        	$('#birMainSectionContainer').replaceWith($(response).find('#birMainSectionContainer'));
        	$('#birCondoSectionContainer').replaceWith($(response).find('#birCondoSectionContainer'));
        	$('#birFloodSectionContainer').replaceWith($(response).find('#birFloodSectionContainer'));
            $('#birJpmSectionContainer').replaceWith($(response).find('#birJpmSectionContainer'));
            $('#birBlanketSectionContainer').replaceWith($(response).find('#birBlanketSectionContainer'));
            $('#birCompanySectionContainer').replaceWith($(response).find('#birCompanySectionContainer'));
        	$('#collateralPolicyCoverageTable').replaceWith($(response).find('#collateralPolicyCoverageTable'));
        	$('#bir-review').prop('disabled',false);
        	$('#bir-cancel').prop('disabled',false);
        	BIR.initializeAll(BIR.currentReferenceDate);
        }
	});
};

BIR.getAttachmentBucketKey = function (){
	var collateralId = $('#collateral-rid').val();
	var policyRid = $('#policy-rid').val();
	 if(policyRid === '') {
         return 'NEW_POLICY_' + collateralId;
     } else {
         return policyRid;
     }
};


BIR.performCollateralAction = function(collateralID, action) {
	var url;
	if (!collateralID || (typeof collateralID === 'string' && collateralID.trim() === "")) {
        alert("Cannot add blank Collateral ID.");
        return;
    } else if (action === 'add') {
		url = 'addCollateralToBIR';
	} else if (action === 'remove') {
		url = 'removeCollateralFromBIR';
	}  else {
		return;
	}

    BIR.spinner.spin(container);
    var cid= $("meta[name='_cid']").attr("content");
    $.ajax({
        type: 'POST',
        url: url+'?_cid='+cid+"&collateralId="+collateralID,
        data: $('form#policyForm').serialize(),
        cache: false,
        success: function(response) {
        	BIR.spinner.stop();
            var errorText = $(response).find('#proofOfCoverageMessage');
            if (errorText.text().length > 0) {
                var existingMessage = $('#proofOfCoverageMessage');
                if (existingMessage.length) {
                    existingMessage.replaceWith(errorText);
                } else {
                    $('#policyForm').prepend(errorText);
                }
            } else {
                $("#collateral-id").val('');
                $('#bir-collateral-details-table').replaceWith($(response).find('#bir-collateral-details-table'));
                $('#collateralPolicyCoverageTable').replaceWith($(response).find('#collateralPolicyCoverageTable'));
            }
            BIR.initializeAll(BIR.currentReferenceDate);
        }
    });
};

BIR.closeBIRWindow = function(e){
	if(confirm('Are you sure you want to close the BIR window ?')){
		window.close();
	}
};

function closeCallBack() {
	if(BIR.tmParams != null && isBrowserClose){
		unlockTask();
	}

}
