//var setting
var settings = {
	    dupNameCount: 0,         // Number of duplicate name count
	    totalSumCount: 0        // number of total sum<0 count
};


//default spiner config
var opts = {
	    color: '#ADD8E6',        // #rgb or #rrggbb
	    opacity: 2/4,         // Opacity of the lines
	    lines: 12,            // The number of lines to draw
	    length: 20,            // The length of each line
	    width: 7,             // The line thickness
	    radius: 20            // The radius of the inner circle
};

//key to access the spiner object
var spinner ; 

//declaring trim for al browsers
if(typeof String.prototype.trim !== 'function') {
	  String.prototype.trim = function() {
	    return this.replace(/^\s+|\s+$/g, ''); 
	  };
}


jQuery.validator.addMethod("uniqueBuildingName", function(value, element) {
	var result = true;
	//check and hightlight duplicate names
	$('.buildingName').each(function() {
		if (isDiffElementSameValues($(this), element)) {
			$(element).attr('pairID', $(this).attr('id'));
			$(this).attr('pairID', $(element).attr('id'));
			hightlightFieldError($(this));
			hightlightFieldError(element);
			result = false;
		}
	});
	//check and unhightlight previous duplicate names which are now resolved
	$('.buildingName').each(
			function() {
				if (isBlank($(this)) || result
						&& ($(this).attr('pairID') == $(element).attr('id'))) {
					$(this).removeAttr('pairID');
					unhightlightFieldError($(this));
				}//
			});
	//un-higlight the current element if there is not duplicated
	if (result) {
		$(element).removeAttr('pairID');
		unhightlightFieldError(element);
	}
	//enable/disable duplicate errors messages
	return result;
}, "  ");

jQuery.validator.addMethod("totalAmountGreaterThan0", function(value, element) {

	var pairClass = '';
	if ($(element).hasClass('buildingAmount')) {
		pairClass = 'contentAmount';
	} else {
		pairClass = 'buildingAmount';
	}
	var pairElem = $(element).parents('.table-line').find('.' + pairClass);

	if (pairElem && !isBlank($(pairElem).val()) && !isBlank($(element).val())) {
		var pairVal = $(pairElem).val();
		var sum = getFloatFromString($(element).val())
				+ getFloatFromString(pairVal);
		if (sum <= 0) {
			hightlightFieldError(element);
			hightlightFieldError(pairElem);
			return false;
		} else {
			unhightlightFieldError(pairElem);
		}
	}
	if (!isBlank(value)) {
		unhightlightFieldError(element);
	}
	if (!isBlank(pairElem)) {
		unhightlightFieldError(pairElem);
	}
	return true;
}, " " //Total of Building and Content amount must be greater than 0.
);

jQuery.validator.addClassRules({
	buildingName : {
		uniqueBuildingName : true
	},
	buildingAmount : {
		totalAmountGreaterThan0 : true
	},
	contentAmount : {
		totalAmountGreaterThan0 : true
	}
});

//overide all required message so as to use the default one prepopulated in the error container
jQuery.extend(jQuery.validator.messages, {
	required : " "
});

function deleteBuilding(index, deleteUrl, callback){
	//lastRecordCheck();
//var deleteUrl ='floodRemap/updateCoverageDetails/';
var extraData = "&action=deleteRow&index="+index;
makeRemotePost( deleteUrl, extraData, callback );
		
}

function getFloatFromString(stringAmount) {
	return parseFloat(stringAmount.replace(/,/g, ''));
}   


function addOneBuilding( addUrl, extraData, callback){	    	
	//var addUrl ='floodRemap/updateCoverageDetails/';
	//var extraData = "&action=addRow";
    makeRemotePost( addUrl, extraData, callback);
    //lastRecordCheck();
    return false;
}

function makeRemotePost(url,extraData, callback ){	
   var cid= $("meta[name='_cid']").attr("content");
   toggleLoader(true);
   $.ajax({
        type: "POST",
        url: url+'?cid='+cid,
        data: $('form#floodCoverageInputForm').serialize()+extraData,
        success: function(response){
        	
        	$('#tableContentID').replaceWith( $(response).find('#tableContentID') );
        	// enableSrollBar ();
        	 if (typeof(callback) == "function"){
        		 callback();
        	 }
        	 toggleLoader(false);
        	 //redoValidations();
        }
	});
   
}


function hightlightFieldError(element){
   if(typeof element === 'undefined') return;
   $(element).closest("div").addClass(errorClass).removeClass(validClass);	
}

function unhightlightFieldError(element){
   if(typeof element === 'undefined') return;
   $(element).closest("div").removeClass(errorClass).addClass(validClass);	
}


function isBlank(str) {
   if(typeof str === 'undefined') return true;
    return (!str || /^\s*$/.test(str));
}

function checkandHightDupNameErrors(){
   
   $("#nameUniquenessErrorContainer").hide();

	   $('.buildingName').each(function() {
	   var current = $(this);
	   $('.buildingName').each(function() {
		   if (isDiffElementSameValues($(this), current)){
			   $("#nameUniquenessErrorContainer").show();
			   return;
		   }
	   });
	   
   });
}

function isDiffElementSameValues(e1, e2){
   ///can't  compare empty element
   if( isBlank(e1) || isBlank(e2) ||( $(e1).attr('id')==$(e2).attr('id'))){
	  return false; 
   }
   if( $(e1).val().trim().toLowerCase() == $(e2).val().trim().toLowerCase() ){
   //if( $(e1).val() == $(e2).val() ){
	   return true;
   }
   return false;
}


function toggleLoader(on) {
	if (on) {
 		   target = document.getElementById('tableContentID');
 		   spinner = new Spinner(opts).spin(target);
		return;
	}
	if(spinner){
		spinner.stop();
	}
}
   
