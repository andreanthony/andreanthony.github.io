'use strict';
var CTRAC = {};
CTRAC.context = '/ctrac/admin/';

$(document).ready(function(){
    $("#sidSearchForm").validate(
        {	onkeyup : false,
            rules : {
                sid : {required : true,
                    minlength: 7}
            },
            groups : {
                allFields : 'sid'
            },
            messages : {
                sid : {required : "Enter user SID to search.",
                    minlength : "SID requires 7 characters."}
            },
            errorContainer : $('#errorSearch'),
            errorLabelContainer : "#errorSearch",
            errorElement : "span",
            errorClass : "has-error text-danger",
            validClass : "",
            highlight : function(element, errorClass, validClass) {
                $(element).closest("div").addClass(errorClass)
                    .removeClass(validClass);
                CTRAC.USER_ENTITLEMENTS.hideUserMaintenanceForm();
                $('#searchUserBtn').attr('disabled','disabled');
            },
            unhighlight : function(element, errorClass, validClass) {
                $(element).closest("div").removeClass(errorClass)
                    .addClass(validClass);
                $('#searchUserBtn').removeAttr('disabled');
            }
        });
});

CTRAC.USER_ENTITLEMENTS = {};
CTRAC.USER_ENTITLEMENTS.doUserSearch = function(){
    CTRAC.USER_ENTITLEMENTS.hideUserMaintenanceForm();
    $("#sidSearchForm").validate();
    if(!$( "#sidSearchForm").valid()){
        $("#errorSearch").show();
        return;
    }

    var sid = $("#sid").val();
    var url = CTRAC.context+'entitlements/userSearchResult/'+sid;
    $.ajax({
        type: "GET",
        global: false, // prevent global setting to show loading spinner
        url: url,
        cache: false,
        success: function (response) {
            if (response.indexOf("ACCESS DENIED") > -1) {
                alert("CTRAC - Access Denied.");
            }
            $('#userSearchResultContainer').html(response);
            CTRAC.USER_ENTITLEMENTS.initializeUserMaintenanceForm();

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status + " thrownError: " + thrownError);
        }
    });
};

CTRAC.USER_ENTITLEMENTS.clickAddUser = function(){
    $('#userMaintenanceFormContainer').removeClass("hide-userMaintenance");
    $('#addUserBtn').hide();
    $('#profileAction').hide();
    $('.user-add-messaging').text('');
    $("#action").val('Add');
};

CTRAC.USER_ENTITLEMENTS.hideUserMaintenanceForm = function(){
    CTRAC.USER_ENTITLEMENTS.clearUserMaintenanceMessaging();
    $('#userMaintenanceFormContainer').addClass("hide-userMaintenance");
    $("#errorSearch").hide();
    $('#addUserBtn').hide();
    $('.user-add-messaging').text('');
    $('#profileAction').hide();
};

CTRAC.USER_ENTITLEMENTS.setFormAction = function(){
    if(!$('#userMaintenanceFormContainer').hasClass("hide-userMaintenance")){
        $('#addUserBtn').hide();
    }
};

CTRAC.USER_ENTITLEMENTS.clearUserMaintenanceMessaging = function(){
    $("#userSaveStatus").hide().html('');
};

CTRAC.USER_ENTITLEMENTS.enableDisableButtons = function(element) {
    $('#addProfile').prop("disabled", element == 'includedProfilesDropDown' || element != 'availableProfilesDropDown');
    $('#removeProfile').prop("disabled", element != 'includedProfilesDropDown' || element == 'availableProfilesDropDown');
};

CTRAC.USER_ENTITLEMENTS.includeExcludeSelectedProfile = function(sourceElement,
                                                                 targetElement) {
    $('#' + sourceElement + ' option:selected').remove().appendTo(
        '#' + targetElement).removeAttr('selected');
};


CTRAC.USER_ENTITLEMENTS.initializeUserMaintenanceForm = function(){

    CTRAC.USER_ENTITLEMENTS.setFormAction();

    //There has to be profiles selected to be able to save a user
    $.validator.addMethod("selectedProfiles",function (value,element){
        return $("#includedProfilesDropDown option").size() > 0;
    }, '');

    $("#userMaintenanceForm").validate(
        {	onkeyup : false,
            rules : {
                username : {required : true	},
                firstName : {required : true},
                lastName : {required : true},
                includedProfilesDropDown : {
                    selectedProfiles: true
                }
            },
            groups : {
                allFields : ' username firstName lastName groups '
            },
            messages : {
                username : {required : ""},
                firstName : {required : ""},
                lastName : {required : ""}
            },
            errorContainer : $('#errorContainer'),
            errorLabelContainer : "#errorContainer",
            errorElement : "span",
            errorClass : "has-error text-danger",
            validClass : "",
            highlight : function(element, errorClass, validClass) {
                $(element).closest("div").addClass(errorClass)
                    .removeClass(validClass);
            },
            unhighlight : function(element, errorClass, validClass) {
                $(element).closest("div").removeClass(errorClass)
                    .addClass(validClass);
            }
        });

    $('#action').change(function(e){
        if($(this).val() && $(this).val().toLowerCase() == 'delete'){
            $('.editable-field').hide();
        }else{
            $('.editable-field').show();
        }
    });

    $('#btnSaveUser').off("click").on("click", function(event) {
        CTRAC.USER_ENTITLEMENTS.clearUserMaintenanceMessaging();

        $( "#userMaintenanceForm").validate();
        if(!$( "#userMaintenanceForm").valid() ){
            return;
        }
        var cid= $("#cid-placeholder").val();
        var csrf= $("#csrf-placeholder").val();
        var sid = $("#sid").val();
        var action = $('#action option:selected').val();

        if (typeof action == "undefined") {
            action ='Add';
        }

        var formData = $('form#userMaintenanceForm').serialize();
        $("#includedProfilesDropDown").find("option").each(function(){
            formData += '&groups='+ $(this).val();
        });

        var url = CTRAC.context+'entitlements/user/'+ sid+ '/'+ action.toLowerCase() + '?_cid='+cid + '&_csrf='+csrf;
        $.ajax({
            type: "POST",
            url: url,
            data: formData,
            success: function(response){
                if(response && response.success){
                    $("#userSaveStatus").show().html(
                        "<strong>Success! </strong>Changes have been saved successfully.");
                    if(action.toLowerCase() == 'delete'){
                        $('#userMaintenanceFormContainer').html('');
                    }
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.status + " thrownError: " + thrownError);
            }
        });
    });
};

