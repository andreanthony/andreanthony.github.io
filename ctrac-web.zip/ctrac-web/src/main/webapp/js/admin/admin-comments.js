ADMIN_COMMENTS_MODAL = {
    'MODAL': "#adminCommentsModal",
    'COLLATERAL_RID': "[name='collateralRid']",
    'ADMIN_COMMENTS': "[name='adminComments']"
};

function launchAdminCommentsModal() {
    var cid= $("meta[name='_cid']").attr("content");
    $.ajax({
        url: CTRAC.context+'collateral/'+CTRAC.collateralRID+'/adminComments?_cid='+cid,
        cache: false,
        success: function(data) {
            $(ADMIN_COMMENTS_MODAL.MODAL).find(ADMIN_COMMENTS_MODAL.ADMIN_COMMENTS).val(data.adminComments);
            $(ADMIN_COMMENTS_MODAL.MODAL).modal('show');
        }
    });
}

function submitAdminCommentsModal(e) {
    var form = $(e.target).closest('form'),
        data = {
            'adminComments': $(ADMIN_COMMENTS_MODAL.ADMIN_COMMENTS, form).val()
        }
    jsonSubmit(form, data, adminCommentsModalCallback);
}

function adminCommentsModalCallback(data) {
    $("#adminCommentsModal").modal('hide');
    $('#adminComments').text(data.adminComments);
}

function jsonSubmit(form, data, callback) {
    var cid= $("meta[name='_cid']").attr("content"),
        csrf=$("meta[name='_csrf']").attr("content");
    $.ajax({
        type: form.attr('method'),
        url: form.attr('action') + '?_cid=' + cid + '&_csrf=' + csrf,
        data: JSON.stringify(data),
        contentType: 'application/json',
        dataType: 'json',
        success: function(result) {
            if (typeof callback === 'function') {
                callback(result);
            }
        }
    });
}
