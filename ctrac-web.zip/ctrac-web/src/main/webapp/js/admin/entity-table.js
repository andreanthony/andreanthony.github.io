var newWindow=null;
var currentSelectedStatus='None';
var entityTable;
var host=window.location.protocol+"//"+window.location.host;
var selectedEntitiesMap = {};
var ENTITY_TABLE = {};

ENTITY_TABLE.CONFIG = {
	id:'',
	searchable: true,
	visibleTaskSelected: true,
	lengthMenu : [ 25,50,100,200 ],
	callateralId: null,
	filtering: true,
	initialSearch : [
                     null,
                     null,
                     null,
                     null,
                     null,
                     null,
                     null,
                     null,
                     null
                   ],
    additionalFilter: ''
};

ENTITY_TABLE.searchEntities = function () {
	if ($.fn.dataTable.isDataTable('#' + ENTITY_TABLE.CONFIG.id + ' .entity-table')) {
		ENTITY_TABLE.entityTable.destroy();
    }
    ENTITY_TABLE.CONFIG.initialSearch[2] = { "search": $('#searchEntity').val() };
    ENTITY_TABLE.initEntityTable();
};

ENTITY_TABLE.preInitOverlay = function (id, additionalFilter) {
	ENTITY_TABLE.CONFIG.id = id;
    ENTITY_TABLE.CONFIG.searchable = true;
    ENTITY_TABLE.CONFIG.visibleTaskSelected = false;
    ENTITY_TABLE.CONFIG.lengthMenu = [ 10, 25, 50 ];
    ENTITY_TABLE.CONFIG.filtering = false;
    if (typeof additionalFilter !== 'undefined') {
    	ENTITY_TABLE.CONFIG.additionalFilter = additionalFilter;
    }
	$('#searchEntityBtn').off('click').click(ENTITY_TABLE.searchEntities);
	$("#searchEntity").off('keyup').keyup(function(event){
	    if(event.keyCode === 13){
	        $("#searchEntityBtn").click();
	    }
	});
};

ENTITY_TABLE.initEntityTable = function () {
	if (ENTITY_TABLE.CONFIG.filtering) {
		$(ENTITY_TABLE.CONFIG.id + ' .entity-table tfoot').show();
		moveTfootToTop();
	}
	selectedEntitiesMap = {};
	clearSearchInput();
	ENTITY_TABLE.entityTable = $('#' + ENTITY_TABLE.CONFIG.id + ' .entity-table').DataTable({
        serverSide: false,
        "searchCols": ENTITY_TABLE.CONFIG.initialSearch,
        ajax: {
            url: CTRAC.context + 'get-entities',
            type: 'GET',
            "data": function (d) {
                d.totalSearchField = 8;
                d.searchEntity = $("#searchEntity").val();
                d.additionalFilter = ENTITY_TABLE.CONFIG.additionalFilter;
            }
        },
        "columns": [
            { "targets": 0, "data": "dashboardTaskSelected", "defaultContent":'<input class="row-checkbox" type="checkbox"/>',  "sortable": false , "visible": ENTITY_TABLE.CONFIG.visibleTaskSelected},
            { "targets": 1, "render": appendTitle, "data": "rid" , "className": "idcolumn"},
            { "targets": 2, "render": appendTitle, "data": "name"},
            { "targets": 3, "render": appendTitle, "data": "address"},
            { "targets": 4, "render": appendTitle, "data": "unitBuilding"},
            { "targets": 5, "render": appendTitle, "data": "city"},
            { "targets": 6, "render": appendTitle, "data": "state"},
            { "targets": 7, "render": appendTitle, "data": "zipcode"},
            { "targets": 8, "render": appendTitle, "data": "collateralRids"}
        ],
        "autoWidth" : false,
        "dom" : '<<"pull-right"l>rtip>',
        "order": [[ 2, "asc" ]],
        "paging" : true,
        "lengthMenu" : ENTITY_TABLE.CONFIG.lengthMenu,
        "lengthChange" : true,
        initComplete: function(){
        	$("#entity-data").children("tr").each(function(){
        		$(this).attr("id", "entity-data-row");
        		$(this).prop("id", "entity-data-row");
        	});
        	initializeSearches();
        	var createNewEntityBtn = $('.create-new-entity');
        	if (createNewEntityBtn) {
        		createNewEntityBtn.removeAttr('disabled');
        	}
        },
        "drawCallback" : function(){
        	 $('.row-checkbox').change(checkboxChangeHandler);
        },
        "rowCallback" : function(row,data){
        	retainCheckboxes(row, data);
        }
    });
};

function appendTitle( data, type, full, meta ) {
    return '<span title="'+data+'">'+data+'</span>';
}

function retainCheckboxes(row, data){
	if (selectedEntitiesMap[data.rid] != null) {
        $(row).find(':checkbox').prop("checked", true);
    }
}

function moveTfootToTop(modalId){
	var tfootsection = $('#' + ENTITY_TABLE.CONFIG.id + ' .entity-table tfoot tr');
	$('#' + ENTITY_TABLE.CONFIG.id + ' .entity-table thead').prepend(tfootsection);
}

function checkboxChangeHandler() {
    var row = ENTITY_TABLE.entityTable.row($(this).closest('tr'));
    var entity = row.data();
    if (this.checked) {
        selectedEntitiesMap[entity.rid] = entity;
    }else{
        delete selectedEntitiesMap[entity.rid];
    }
    //hide warning message
    if(Object.keys(selectedEntitiesMap).length > 1) {
        $('#warning').hide();
    }
}


function initializeSearches() {
    var timer;
    $('.search-field').on('change paste keyup',function(){
        clearInterval(timer);
        $('.search-field').each(function() {
            var searchKey=this.value;
            var thisTd=$(this).closest('th');
            var visIdx=$(thisTd).index();
            var colIdx=ENTITY_TABLE.entityTable.column(visIdx).index();
            ENTITY_TABLE.entityTable.column(colIdx).search(searchKey);
        });
        timer = setTimeout(function(){ENTITY_TABLE.entityTable.draw();}, 1000);
    });
}

function clearSearchInput(){
    $('.search-field').each(function() {
       $(this).val("");;
    });
}