var ADMIN_HOME = {
    context: '',
    referenceDateApi: '/referenceDate'
};

ADMIN_HOME.init = function(context) {
    var referenceDateApi = context + ADMIN_HOME.referenceDateApi;
    ADMIN_HOME.context = context;
    $("#adminMenu").menu();
    $.get(referenceDateApi, setReferenceDate);
    $('#advance-one-day').click(function(e) {
        e.preventDefault();
        $.post(referenceDateApi + "/advance", setReferenceDate);
    });
};

function setReferenceDate(referenceDateDTO) {
    var referenceDate = $('#referenceDate');
    $('#set-date').val(referenceDateDTO["referenceDate"]);
    referenceDate.removeClass("workingDay notWorkingDay");
    referenceDate.text(referenceDateDTO["longDate"]);
    if (referenceDateDTO["workingDay"]) {
        referenceDate.addClass("workingDay");
    } else {
        referenceDate.addClass("notWorkingDay");
    }
}

function setDate(e) {
    e.preventDefault();
    var referenceDate = $('#set-date').val();
    $.post({
        url: ADMIN_HOME.context + ADMIN_HOME.referenceDateApi,
        data: JSON.stringify({ "referenceDate": referenceDate }),
        contentType: "application/json",
        success: setReferenceDate
    });
}

function advanceTo(dayOfWeek, e) {
    e.preventDefault();
    $.post(ADMIN_HOME.context + ADMIN_HOME.referenceDateApi + "/advance/" + dayOfWeek, setReferenceDate);
}
