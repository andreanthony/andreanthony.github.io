var EVENT_MENAGEMENT_HOME = {
	context: '',
	controllerPath: '/republish'
};

function initEventManagement(context) {
	EVENT_MENAGEMENT_HOME.context = context;
	var today = new Date();
	var month = today.getUTCMonth()+1;
	var date = today.getUTCFullYear()+'-'+((month < 10 ? '0' : '') + month)+'-'+((today.getUTCDate() < 10 ? '0' : '') + today.getUTCDate());
	var time = ((today.getUTCHours() < 10 ? '0' : '') + today.getUTCHours()) + ":"
		+ ((today.getUTCMinutes() < 10 ? '0' : '') + today.getUTCMinutes());
	var dateTime = date+'T'+time;
	$('#from-datetime').val(dateTime);
	$('#to-datetime').val(dateTime);
}

function submitDates(e) {
	var fromDateTime = $('#from-datetime').val()+":00.000";
	var toDateTime = $('#to-datetime').val()+":59.999";
	$.post({
		url: EVENT_MENAGEMENT_HOME.context + EVENT_MENAGEMENT_HOME.controllerPath + "ByDate",
		data: JSON.stringify({"fromDate": fromDateTime, "toDate": toDateTime}),
		contentType: "application/json",
		success: postedMessage
	});
}

function submitUUID(e) {
	var eventUuid = $('#event-uuid').val();
	$.post({
		url: EVENT_MENAGEMENT_HOME.context + EVENT_MENAGEMENT_HOME.controllerPath + "/" + eventUuid,
		contentType: "application/json",
		success: postedMessage
	});
}

function postedMessage(response) {
	alert(response);
}