var SERVICE_MANAGEMENT_HOME = {
	context: ''
};

function initServiceManagement(context) {
    SERVICE_MANAGEMENT_HOME.context = context;
    clearStatusFields();
}

function clearStatusFields(){
    $('.ctrac-table .alert-success').hide();
    $('.ctrac-table .alert-danger').hide();
}

function toggleLoadingSpinner(containerId){
    $('#' + containerId + ' .ctrac-inline-loader').toggle();
}

function clearUserEntitlementCache() {
    clearStatusFields();
    toggleLoadingSpinner('userEntitlementsCacheStatus');
    $.ajax({
        type : "POST",
        url: SERVICE_MANAGEMENT_HOME.context + "/clearCacheUserEntitlements",
        contentType: "application/json",
        cache: false,
        success: function() {
            $('#userEntitlementsCacheStatus .alert-success').show();
            toggleLoadingSpinner('userEntitlementsCacheStatus');
        },
        error: function() {
            $('#userEntitlementsCacheStatus .alert-danger').show();
            toggleLoadingSpinner('userEntitlementsCacheStatus');
        }
    });
}