/**
 * Created by E704298 on 7/27/2017.
 */
var cancelMe = function() {
    if (confirm('Are you sure you want to cancel the current action?')) {
        $('#validate-container').hide();
    }
}

function initTaskAdministration() {
    $('#taskStatus').change(function() {
        if (this.value==='Dormant' || this.value==='Transient') {
            $('#wakeUpDate').removeAttr('disabled');
            $('#executionDate').removeAttr('disabled');
        } else {
            $('#wakeUpDate').val('').attr('disabled','disabled');
            $('#executionDate').val('').attr('disabled','disabled');
        }
    });
    $('#action').change(function() {
        if (this.value==='Update') {
            $('#workflowStep,#taskStatus').removeAttr('disabled');
            $('#taskStatus').change();
            $('input[type=radio][name=generateNewTaskId]').removeAttr('disabled');
        } else if (this.value==='Sync with TM') {
            $('input[type=radio][name=generateNewTaskId]').removeAttr('disabled');
            $('#workflowStep,#taskStatus,#wakeUpDate').val('').attr('disabled','disabled');
        } else {
            $('#workflowStep,#taskStatus,#wakeUpDate').val('').attr('disabled','disabled');
            $('input[type=radio][name=generateNewTaskId]').attr('checked',false).attr('disabled','disabled');
        }
    });
    $('#action').change();
    $("#taskAdministrationForm").validate();
}