var entityToKeep;
var submitted = false;
function initEntityModal(){
	//Render selected entities on the modal
	$('#entity-merge-dialog').on('show.bs.modal', function (event) {
		resetModal();
		$.each(selectedEntitiesMap, function(index, it){
			 $('#modal-content-id').append("<div class='col-xs-12'><label class='radio-inline'><input type='radio' name='entity-id' value=" + it.rid +" /><b>Entity ID: </b>" + it.rid + "<b> Name: </b>"+ it.name + "</label></div>");
		 });
	});
	//Reset the content of the modal
	$('#entity-merge-dialog').on('hidden.bs.modal', function (event) {
		if(submitted) {
            window.location.reload(true);
        }
		resetModal();
		$('#modal-content-id').html("");
	});
	$('#modal-content-id').on('change', function() {
		   entityToKeep = $('input[name=entity-id]:checked', '#modal-content-id').val();
		   $('#warning-msg').hide();
	});
}

function registerSubmitMergeEvent(){
	$('#merge-submit').click(function(){
		if(entityToKeep===-1){
			$('#warning-msg').show();
			return;
		}
		var cid=$("meta[name='_cid']").attr("content");
		var csrf=$("meta[name='_csrf']").attr("content");
		var entityWrapper = {};
		entityWrapper['entitiesMap']=selectedEntitiesMap;
		entityWrapper['entityToKeep']=entityToKeep;
		$.ajax({
			url: CTRAC.context +'merge-entities?_cid='+cid+'&_csrf='+csrf,
			method: 'POST',
			data:JSON.stringify(entityWrapper),
			dataType: "json",
			async: false,
			contentType: 'application/json',
			complete: function(data){
				$('#sucess-msg').show();
				$('#merge-submit').prop("disabled", true);
				submitted = true;
				return;
			}
		});
	});
}

function resetModal(){
	entityToKeep = -1;
	$('#merge-submit').prop("disabled", false);
	$('#sucess-msg').hide();
	$('#warning-msg').hide();
	submitted = false;
}