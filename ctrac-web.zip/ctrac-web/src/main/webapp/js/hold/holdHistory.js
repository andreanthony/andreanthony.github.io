'use strict';
var CTRAC_HOLDS ={};
CTRAC_HOLDS.launchHistoryModal = function(e) {
    e.preventDefault();
    var cid= $("meta[name='_cid']").attr("content");
    $.ajax({
        url: CTRAC.root + 'hold/history?_cid=' +cid,
        cache: false,
        success: function(data) {
            CTRAC_MODAL.createSimpleModal(data, function() {
                CTRAC_HOLDS.loadHoldData();
            });
        }
    });
};

CTRAC_HOLDS.TEMPLATES = {
    columnTemplate : function(rowSpan){
        var column = $('<td valign="top"></td>');
        $(column).attr('rowspan',rowSpan);
        return column;
    },
    newRow : function(){
        return $('<tr></tr>');
    },
    errorTemplate : function(){
        return $('<tr><td valign="top" colspan="9"></td></tr>');
    },
    buildingRowTemplate : function(rowSpan){
        var row = $('<tr class="hold-history-blg-row"><td class="hold-history-column" valign="top"></td></tr>');
        $(row).find('td').attr('rowspan',rowSpan);
        return row;
    }
};

function HoldHistoryRecord(holdRecord) {
    this.buildingName = holdRecord.buildingName;
    this.coverageType = holdRecord.coverageType;
    this.holdPeriod = holdRecord.holdPeriod;
    this.holdType = holdRecord.holdType;
    this.insurableAssetType = holdRecord.insurableAssetType;
    this.lpiDate = holdRecord.lpiDate;
    this.startDate = holdRecord.startDate;
    this.verifiedBy = holdRecord.verifiedBy;
    this.verifiedDate = holdRecord.verifiedDate;
}
HoldHistoryRecord.prototype = {};
HoldHistoryRecord.prototype.populateInTemplate = function(value, rowspan){
    var column =  CTRAC_HOLDS.TEMPLATES.columnTemplate(rowspan);
    $(column).text(this[value] !== undefined && this[value] !== null ? this[value]: '');
    return column;
};


function HoldHistoryResponse(serverResponse) {
    this.historyRecords = [];
    if(serverResponse !== undefined && serverResponse !== null){
        for(var rowId in serverResponse){
            var historyRecord = new HoldHistoryRecord(serverResponse[rowId]);
            this.historyRecords.push(historyRecord);
        }
    }
}
HoldHistoryResponse.prototype = {};

// Call API to load all hold history data from current collateral
CTRAC_HOLDS.loadHoldData = function() {
    var cid= $("meta[name='_cid']").attr("content");
    var inlineLoader = new InlineLoader("history-meta-container");
    inlineLoader.show();
    $.ajax({
        url: CTRAC.root + 'api/collateral/'+CTRAC.collateralRID+'/holds?_cid=' +cid,
        cache: false,
        success: function(data) {
            inlineLoader.hide();
            //Transform response into Object
            var holdHistory = new HoldHistoryResponse(data);
            //Build HTML table for hold history and render
            var generatedView = CTRAC_HOLDS.buildHoldHistoryUiTable(holdHistory);
            $('#hold-history-table-body').append(generatedView);
        },
        error: function(data) {
            inlineLoader.hide();
            $('#hold-history-table-body').append(CTRAC_HOLDS.TEMPLATES.errorTemplate()
                .find('td').text('An error occurred. Data was not loaded'));
        }
    });
};

//Lookup the first (start index) record going back from a current position
// in the hold history if it has same value as the current row
CTRAC_HOLDS.getStartIndexForValue = function(holds, field, currIndex, cond){
    cond === undefined ? cond = function(){return true}:'';
    var value = holds[currIndex][field];
    var startIndex = currIndex;
    for(var i = currIndex;i>=0;i--){
        if(holds[i][field] === value && cond(holds[i])){
            startIndex = i;
        }
    }
    return startIndex;
};

//Lookup the last (end index) record going forward from a current position
// in the hold history if it has same value as the current row
CTRAC_HOLDS.getEndIndexForValue = function(holds, field, currIndex, cond){
    cond === undefined ? cond = function(){return true}:'';
    var value = holds[currIndex][field];
    var endIndex = currIndex;
    for(var i = currIndex;i<holds.length;i++){
        if(holds[i][field] === value && cond(holds[i])){
            endIndex = i;
        }
    }
    return endIndex;
};

//Build the HTML table based on the hold history data
CTRAC_HOLDS.buildHoldHistoryUiTable = function(holdHistory){
    var dataRow = $('<div id="wrapper"></div>');
    var currentBlgRow = null;
    var holds = holdHistory.historyRecords;
    for(var i = 0;i<holds.length;i++){
        //Lookup first and last index of rows where same value for buildingName was found
        var startIndexFoundB = CTRAC_HOLDS.getStartIndexForValue(holds,'buildingName',i);
        var endIndexFoundB = CTRAC_HOLDS.getEndIndexForValue(holds,'buildingName',i);
        if(startIndexFoundB === i){
            currentBlgRow = CTRAC_HOLDS.TEMPLATES.buildingRowTemplate(String(endIndexFoundB-startIndexFoundB + 1));
            $(currentBlgRow).find('td').text(holds[i].buildingName);
        }

        //Lookup first and last index of rows where same value for insurableAsset was found
        var startIndexFoundA = CTRAC_HOLDS.getStartIndexForValue(holds,'insurableAssetType',i,
            function(holdRecord){return holdRecord.buildingName === holds[i].buildingName});
        var endIndexFoundA = CTRAC_HOLDS.getEndIndexForValue(holds,'insurableAssetType',i,
            function(holdRecord){return holdRecord.buildingName === holds[i].buildingName});
        if(startIndexFoundA === i){
            var column = holds[i].populateInTemplate('insurableAssetType', String(endIndexFoundA-startIndexFoundA + 1));
            $(currentBlgRow).append(column);
        }


        //Lookup first and last index of rows where same value for coverageType was found
        var startIndexFoundC = CTRAC_HOLDS.getStartIndexForValue(holds,'coverageType',i,
            function(holdRecord){return holdRecord.buildingName === holds[i].buildingName
                && holdRecord.insurableAssetType === holds[i].insurableAssetType});
        var endIndexFoundC = CTRAC_HOLDS.getEndIndexForValue(holds,'coverageType',i,
            function(holdRecord){return holdRecord.buildingName === holds[i].buildingName
                && holdRecord.insurableAssetType === holds[i].insurableAssetType});
        if(startIndexFoundC === i){
            var column = holds[i].populateInTemplate('coverageType', String(endIndexFoundC-startIndexFoundC + 1));
            $(currentBlgRow).append(column);
        }

        $(currentBlgRow).append(holds[i].populateInTemplate('holdType'));
        $(currentBlgRow).append(holds[i].populateInTemplate('holdPeriod'));
        $(currentBlgRow).append(holds[i].populateInTemplate('startDate'));
        $(currentBlgRow).append(holds[i].populateInTemplate('lpiDate'));
        $(currentBlgRow).append(holds[i].populateInTemplate('verifiedBy'));
        $(currentBlgRow).append(holds[i].populateInTemplate('verifiedDate'));

        if(endIndexFoundB === i || endIndexFoundA === i || endIndexFoundC === i || i < endIndexFoundC){
            $(dataRow).append(currentBlgRow);
        }
        //Add a new blank row only when we haven't reached the end of the grouped building response
        if(endIndexFoundB !== i) {
            currentBlgRow = CTRAC_HOLDS.TEMPLATES.newRow();
        }
    }
    return $(dataRow).children();
};