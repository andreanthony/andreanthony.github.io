CUSTOMER_MAINTENANCE = {};

CUSTOMER_MAINTENANCE.addOwner = function (rid){
  var cid= $("meta[name='_cid']").attr("content");
  $.ajax({
        type: "POST",
        url: CTRAC.context+'addCustomer?ownerRid='+rid+'&_cid='+cid,
        cache: false,
        data: $('form#collateralSectionForm').serialize(),
        success: function(response){
        	$('#owner-search').closest('.modal').modal('hide');
        	if (response.indexOf("ACCESS DENIED") > -1) {
        		alert("CTRAC - Access Denied.");
        	}		        	
        	$("#collateralDetailsSection").replaceWith('<div id="collateralDetailSection" class="results-block">' + response + '</div>');
        	$("#collateralOwnerSaveStatus").html("<strong>Success! </strong>Changes have been saved successfully.");
        	dataChanged=false;
        	$("#collateralOwnerSaveStatus").show();	        	
        },
   		error: function(xhr, ajaxOptions, thrownError) {
   			COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
   		}		   		
  	});
}

function registerAddNewCollateralOwnerEvent() {
	$('#owner-search').closest('.modal').off('shown.bs.modal').on('shown.bs.modal', function (e) {
		$('#owner-search tbody').on( 'click', 'tr', function () {
			var rowData = ENTITY_TABLE.entityTable.row(this).data();
			if (!rowData || rowData == null) {
				return;
			}
			var rid = escapeHTML(rowData['rid']);
			CUSTOMER_MAINTENANCE.addOwner(rid);
	    });
		
	    ENTITY_TABLE.preInitOverlay('owner-search', 'collateralRid=' + CTRAC.collateralRID);
		$("#searchEntity").focus().val('');
	});
	
	$("#btnAddNewCollateralOwner").off("click").on("click", function() {
			var rid = 0;
			var cid= $("meta[name='_cid']").attr("content");

			$.ajax({
		        url: CTRAC.context+'editCollateralOwner?_cid='+cid+'&ownerRid='+rid,
		        cache: false,
		        data: $('form#collateralSectionForm').serialize(),
		        success: function(data) {
		            $('#newCustomerModel').html(data);
		            $('#collateralOwnerModalTitle').text("New Collateral Owner");
		        	$("#btnCollateralOwnerDelete").hide();//("disabled", true);
		        	$("#ctracModal").modal('toggle');
		            $("#newCustomerModel").modal('toggle');
		        },
		        error: function(xhr, ajaxOptions, thrownError) {
		   			alert(xhr.status + " thrownError: " + thrownError);
		   		}
		    });	
	});
}