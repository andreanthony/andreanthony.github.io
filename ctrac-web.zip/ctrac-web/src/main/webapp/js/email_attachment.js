if (!window.console) {
  var console;
}

//place holder for the spinner div element
var target ;

//key to access the spiner object
var spinner ; 

var origin = window.location.origin;
var root = (function() {
	if (typeof CTRAC === "undefined" || typeof CTRAC.root === "undefined") {
		return origin+window.location.pathname.substring(0, window.location.pathname.indexOf("/",2))+'/';
	} else {
		return CTRAC.root;
	}
})();

//default spiner config
var opts = {
	    color: '#ADD8E6',        // #rgb or #rrggbb
	    opacity: 2/4,         // Opacity of the lines
	    lines: 12,            // The number of lines to draw
	    length: 14,            // The length of each line
	    width: 7,             // The line thickness
	    radius: 20            // The radius of the inner circle
};
//default page config
var defaultPageConfig ={
		 deleteUrl :root+'deleteFile',
		 maxTotalQueueSize:'10MB',     // limit on the sum of the size of all file in the queue in MB or KB
		 allowEmptyAttachement:true, //set to true/false to enforce/enable at least one attachment
		 emptyFileErrMsg:"Email attachment is required.",
		 ctracOnselect:  function() {},
		 appendGyfon:false,
		 asynch:false,
		 uploadMinimun:0
};

//api call
function initEmailAttachments(pageConfig, uploadyfyConfig ){
	
	applyUploadifyConfig.call (this, pageConfig, uploadyfyConfig );
	if($("#SubmitCmdWrapper").length == 0){
		$('#'+pageConfig.emailFormID).append('<input id="SubmitCmdWrapper" type="hidden" class="SubmitCmdWrapper" name=" " value=" " />');
	}
	else{
		//not append
	}
}

//api call
function updateUploadifySetting( pageConfig, paramKey, newValue){
	
	pageConfig =$.extend(defaultPageConfig, pageConfig);
	
	//if we are updating the uploadify config
	 if(paramKey){
		 $('#'+pageConfig.inputFileID).uploadify('settings',paramKey,newValue);
	 }
	//we are only updating the page config
	 //overriding the events associated to the submit buttons if the  page config had changed
	 setupCommandEvent (pageConfig );
	 
	 //since the config had changed, reset error messages if any;
	 resetErrMsg(pageConfig);
	 
}
	

function applyUploadifyConfig(pageConfig, uploadyfyConfig){
	
	//reading the pageSpecific configs;
	defaultPageConfig =$.extend(defaultPageConfig, pageConfig);

	var defaultUploadyfyConfig ={
			'swf' : root+'swf/uploadify.swf',
			'uploader' : root+'uploadEmailAttachments/',
			'cancelImg' : root+'css/images/uploadify-cancel.png',
			'auto' :false,
			'uploadLimit' : 6,
			'fileSizeLimit' : '10KB', //single file size limit
			'multi' : true,
			'method'   : 'post',
			///* 'debug'    : true,
			'removeCompleted' : false,
			//* let's Extend uploadify to implement our customs error processing/highlighting  /
	        'ctracOverrideExisting':true,
	        'maxSizeErrMsg':"\nOne or more file(s) were not attached to the email.",                	//Error message when file size exceeds total allowable file size limit
			'uploadLimitErrMsg':"\nFiles were not attached to the email.",            	//Error message when file count exceeds max file count
			'incrementalUploadLimitErrMsg':"\nAdditional file(s) were not attached to the email. ",    	// Error message when additional files added exceeds max file count
			'ctracErrHandler': function(errMsg) {
				processErrMsg(defaultPageConfig,errMsg);
			} ,
				
			//end uploadyfy extentions//
	        'onCancel' : function(file,ID) { 
	        	resetErrMsg(defaultPageConfig);
	        	deleteFile(defaultPageConfig, file.name);
	        	$('#' + ID).remove();
	        },
	        'onQueueComplete':  function() { sendEmail(defaultPageConfig);} ,
			'onSelect':function(file) {
				resetErrMsg(defaultPageConfig);
				defaultPageConfig.ctracOnselect();
			}
		};
	 //reading the pageSpecific uploadyfy configs;
	 defaultUploadyfyConfig = $.extend( defaultUploadyfyConfig, uploadyfyConfig);
	
	 //deleting remote file if page refresh
	 deleteFile(defaultPageConfig, "all");
	
	 //initializing uploadify
	 $('#'+defaultPageConfig.inputFileID).uploadify(defaultUploadyfyConfig ).uploadify('settings','buttonText','Browse');
	 
	 //overriding the events associated to the submit buttons
	 setupCommandEvent(defaultPageConfig);
	 
	toggleLoader(false, defaultPageConfig);
}	



function setupCommandEvent (pageConfig  ){
	//we are only updating the page config
	 //overriding the events associated to the submit buttons if the  page config had changed
	 $('.'+pageConfig.cmdClass).off("click").click( function(e){ 
		 e.preventDefault();
		 //dealing with multiple click..
		 $('.'+pageConfig.cmdClass).clearQueue();
		 var callback= function(){validadeAndUploadAttachment.call(this,pageConfig);};
		 setupCommandName( $(this).attr('name'), $(this).attr('value'), callback );
		 return false;
	 });
}

function setupCommandName(name, value, callback ){
	 $('#SubmitCmdWrapper').attr('name', name ).attr('value', value);
	 if (typeof(callback) == "function"){
		 callback();
	 }
}

function validadeAndUploadAttachment (pageConfig){
	
	$('.main_container').css({'cursor':'progress'});
	
	$( "#"+pageConfig.emailFormID).validate();
	
	var isValidForm = $( "#"+pageConfig.emailFormID).valid();
	var isvalidAttch = validadeAttachment(pageConfig, isValidForm);
	
	//form validations
	if(!isValidForm || ! isvalidAttch){
		$('.main_container').css({'cursor':'default'});
		//
		return false;
	}else{
		
		if(pageConfig.loaderDivID){
			toggleLoader(true,pageConfig);
		}
		 var callback = function(){ uploadAttachmentent.call(this,pageConfig);};
		 //everything is perfect, upload the file: (upload completion will trigger form submit)
		 disableFormCommands(pageConfig, callback);
	}
	return true;
}


function validadeAttachment (pageConfig, areFormFieldsValids ){
	
	resetErrMsg(pageConfig);
	
	var totalQueusize =  getTotalQueueSize(pageConfig);
	var totalNumberOfFiles = getTotalFileNumber(pageConfig);
	if(totalQueusize<=0){
		//if all the other forms fields are valid, Check if it is ok to submit the form with no attachment and use the default determination form
		if(areFormFieldsValids && pageConfig.allowEmptyAttachement) {
			toggleLoader(true,pageConfig);
			//Need to call alldone callback here
			if (typeof(pageConfig.allDoneCallBack) == "function"){
				pageConfig.allDoneCallBack();
			}
			//disable the button and subit the form
			var callback = function(){ sendEmail(pageConfig);} ;
			
			disableFormCommands(pageConfig, callback);
			
			return;
		}else{
			//there is already a "field required err msg" , 
			if(!areFormFieldsValids) {
				//Changed from processErrMsg(pageConfig, "", false); to reset
				resetErrMsg(pageConfig);
				return  false;
			}
			
			return  processErrMsg(pageConfig, pageConfig.emptyFileErrMsg, true);
		}
	}
	
	//We have some attachments in the queue to validate
	var minFileRequired = pageConfig.uploadMinimun;
	var MaxTotalQueueSize = pageConfig.maxTotalQueueSize;
	var prefix = MaxTotalQueueSize.slice(-2);
	var val = parseInt( MaxTotalQueueSize.substring(0, MaxTotalQueueSize.length-2) );
	
	//KB conversions and rounding
	totalQueusize = (( totalQueusize / 1024).toFixed(1));
	totalQueusize = Math.ceil(totalQueusize);
	
	//MB conversions and rounding
	if("MB"===prefix){ 
		totalQueusize = ((totalQueusize / 1000)).toFixed(1); 
		totalQueusize = Math.ceil(totalQueusize);
	}
	
    if(totalNumberOfFiles<minFileRequired){
    	var errmsg ="The Minimum required attachements is: "+ minFileRequired+". Please attach at least " + minFileRequired+ " Files.";
		return  processErrMsg(pageConfig, errmsg, true);
	}
	
    else if(totalQueusize > val){
		var errmsg =" Files attached exceed the maximum total size limit of "+ pageConfig.maxTotalQueueSize+". Please remove one or more files.";
		return  processErrMsg(pageConfig, errmsg, true);
    }
	
	
  return true;
}

function uploadAttachmentent(pageConfig, callback ){

	$('#'+pageConfig.inputFileID).uploadify('upload','*'); 
	
	if (typeof(pageConfig.allDoneCallBack) == "function"){
		pageConfig.allDoneCallBack();
	}
	
	if (typeof(callback) == "function"){
		 callback();
	}
} 



function disableFormCommands(pageConfig ,  callback ){
	//alert('disabling the commands : '+$('.'+pageConfig.cmdClass).attr('value')  );
	$('.'+pageConfig.cmdClass).attr('disabled', 'disabled').clearQueue() ;
	
	if($('.'+pageConfig.cancelClass)){$('.'+pageConfig.cancelClass).attr('disabled', 'disabled').clearQueue() ;}
	
	if($('#cancel') ) { $('#cancel').attr('disabled', 'disabled').clearQueue() ;}

	 if (typeof(callback) == "function"){
		 callback();
	 }
}


function resetErrMsg(pageConfig){
	$('#'+pageConfig.AttachmentErrMs).html('');
	$('#'+pageConfig.attachDivID+" .span4").removeClass('errBlock');
}

function processErrMsg(pageConfig, errMsg, forceHighlight){
	
	if(pageConfig.appendGyfon){
		errMsg ='<div class="alert alert-danger small" role="alert" style="padding:10px;"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> '+errMsg+'</div>';
	}
	
	$('#'+pageConfig.AttachmentErrMs).html(errMsg);
	//if( forceHighlight || (getTotalQueueSize(pageConfig) <=0 ))
	if( forceHighlight )
	$('#'+pageConfig.attachDivID+" .span4").first().addClass('errBlock');
	
	return false;
}


function getTotalQueueSize(pageConfig ){
	 if ($('#'+pageConfig.inputFileID).length > 0){
	     return $('#'+pageConfig.inputFileID).uploadify('ctracTotalQueueSize',null);
	 }else{
		 return 0;
	 }
}


function getTotalFileNumber(pageConfig ){
	 if ($('#'+pageConfig.inputFileID).length > 0){
	     return $('#'+pageConfig.inputFileID).uploadify('ctracTotalFileNumber',null);
	 }else{
		 return 0;
	 }
}

function sendEmail( pageConfig ) {

	//should the form be submited asynchroneously?
	if (typeof(pageConfig.asynch) != 'undefined' && pageConfig.asynch == true) {
		  var cid= $("meta[name='_cid']").attr("content");
		  var url= $("#"+pageConfig.emailFormID).attr('action').split(".");
		   url = url[0];
		   $.ajax({
		        type: "POST",
		        cache: false,
		        url: url+'?_cid='+cid,
		        data: $("#"+pageConfig.emailFormID).serialize(),
		        success: function(response){
		        	if (typeof (pageConfig.submitCallBack) == "function") {
		    			pageConfig.submitCallBack(response);
		    		}
		        	toggleLoader(false, pageConfig);
		        },
		        error: function(xhr, ajaxOptions, thrownError) {
		        	if (typeof (pageConfig.submitErrorCallBack) == "function") {
		    			pageConfig.submitErrorCallBack(thrownError,xhr);
		    		}
		        }
			});
	} else //need to submit the form synchroneously
	{ 
		$("#" + pageConfig.emailFormID).submit();
	}

	return true;
}


function toggleLoader(show, pageConfig) {
	if (show && pageConfig.loaderDivID) {
 		   target = document.getElementById(pageConfig.loaderDivID);
 		   spinner = new Spinner(opts).spin(target);
		return;
	}
	if(spinner && pageConfig.loaderDivID){
		spinner.stop();
	}
}



function deleteFile(pageConfig, fileName){
	if(console && console.log){
		console.log('call to remove '+fileName+'  form '+pageConfig.taskUUId);
	}
	var deleteFileForm = $('#deleteFileForm');
	deleteFileForm.find('input').removeAttr('disabled');
	$('#deleteFileKey').val(pageConfig.taskUUId);
	$('#deleteFileName').val(fileName);
	$.ajax({
        type: "POST",
        url: ''+pageConfig.deleteUrl,
        data: deleteFileForm.serialize()
	});
}






