var newWindow=null;
var selectedCheckBoxes=new Object();
var currentSelectedStatus='None';
var taskListTable;
var host=window.location.protocol+"//"+window.location.host;


//This won't be needed because the dashboard are mostly get methods
//and csrf is disabled for file upload
var csrfParameter = $("meta[name='_csrf_parameter']").attr("content");
var csrfHeader = $("meta[name='_csrf_header']").attr("content");
var csrfToken = $("meta[name='_csrf']").attr("content");
var cid= $("meta[name='_cid']").attr("content");



Object.size=function(obj){
    var size=0,key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) {
            size++;
        }
    }
    return size;
};

Object.getArray=function(obj){
    var array=[];
    for (key in obj) {
        if (obj.hasOwnProperty(key)) {
            array.push(obj[key]);
        }
    }
    return array;
};

function popupTM(url) {
    if (newWindow === null) {
        newWindow = window.open(url, 'tmWindow');
        newWindow.focus();
    } else {
        if (newWindow !== null && !newWindow.closed) {
            newWindow.focus();
        } else {
            newWindow = window.open(url, 'tmWindow');
            newWindow.focus();
        }
    }
}

function LaunchHelper(tmTaskId){
	var url='floodRemap/launchCtracDashboardHelper?id_task='+tmTaskId;
	helperWindow = window.open(url, "mywindow", "location=1,status=1,scrollbars=1,resizable=yes,width=850,height=650");
}

function CheckedRow(tmTaskId,tmURL,taskStatus,workFlowStep,propAddress) {
    this.tmTaskId=tmTaskId;
    this.tmURL=tmURL;
    this.taskStatus=taskStatus;
    this.propAddress=propAddress;
    this.workFlowStep=workFlowStep;
    
    this.completeItem=function(){
        if(this.taskStatus==='Dormant'){
            completeItemWindow = window.open(host+'dashboard/launchCompleteItemHelper?tmTaskId='+this.tmTaskId /*+'&_csrf='+csrfToken*/, "mywindow", "location=1,status=1,scrollbars=1,width=850,height=650");
            completeItemWindow.focus();
        }else if(this.taskStatus==='Active'){
            popupTM(this.tmURL);
        }
    };
    
    this.workItem=function(){
    	var launchableWorkflow=workableStatuses;
    	var launched=false;
    	if(this.taskStatus==='Dormant'){
    		for(var i=0;i<workableStatuses.length;i++){
        		if(workableStatuses[i]===workFlowStep){
        			launched=true;
        			LaunchHelper(this.tmTaskId);
        		}
        	}
    	}
        if(!launched){
        	popupTM(this.tmURL);
        }
        if(launched){
        	resetCheckboxes();
        	initializeCheckboxes();
        }
    };
 }
    
$(document).ready(function() {
    //BTJ
    var winHeight=window.screen.availHeight;
    var winWidth=window.screen.availWidth;
    var launchBorrowerPolicyHelper = function(selectedTasks) {
        var borrowerWindow=window.open(host+'dashboard/createBorrowerPolicyTasks/'+selectedTasks/* +'&_csrf='+csrfToken*/, "mywindow", "toolbar=no,menubar=no,location=no,status=no,scrollbars=1,resizable=yes,left=0,top=0,width="+winWidth+",height="+winHeight);
        borrowerWindow.focus();
    };
    submitClick = function() {
        var dropDownMenuSelectValue=$("#ctracActions").val();
        var numSelected=Object.size(selectedCheckBoxes);
        var rowArray=Object.getArray(selectedCheckBoxes);
        if(dropDownMenuSelectValue==='Work Item'&&numSelected>0){
            rowArray[0].workItem();
        }else if(dropDownMenuSelectValue==='Complete Item'&&numSelected>0){
            rowArray[0].completeItem();
        }else if(dropDownMenuSelectValue==='Review Borrower Insurance' && numSelected>0){
            var selectedTasks = [];
            var propAddressList = [];
            
            for(var i=0,j=rowArray.length;i<j;i++) {
                var currentRow=rowArray[i];
                selectedTasks.push(currentRow.tmTaskId);
                propAddressList.push(currentRow.propAddress);
            }
  
            var isPropMatch=isPropAddressIdentical(propAddressList);
            if(isPropMatch===true) {
                launchBorrowerPolicyHelper(selectedTasks);
            }else{
                $("#propertyMismatch").dialog({
                    modal: true,
                    title: "Please Confirm",
                    buttons: {
                       "YES": function() {
                           $(this).dialog("close");
                           launchBorrowerPolicyHelper(selectedTasks);
                       },
                       "NO": function() {                                     
                           $(this).dialog("close");
                       }
                   }
               });                            
           }
        }
    };
    
    taskListTable = $('#task-list-table').DataTable({
          serverSide: true,
          ajax: {
              url: 'admin/dashboard/getData',
              type: 'GET',
              "data": function (d) {
                  //Add all config/extra data here as a property of d
                  d.totalSearchField = 9; //total number of searchable fields;
              } 
          },
          // WHEN ADDING A NEW COLUMN, UPDATE the param d.totalSearchField = 8   in the the ajax method above
          "columns": [
              { "data": "dashboardTaskSelected","targets": 0,"defaultContent":'<input class="row-checkbox" type="checkbox" disabled/>', "searchable": false,"sortable": false},
              { "data": "taskStatus",           "targets": 1},
              { "data": "workFlowStep",         "targets": 2 ,"defaultContent":""},
              { "data": "lineOfBusiness",       "targets": 3 },
              { "data": "ctracId",              "targets": 4 },
              { "data": "loanNumber",           "targets": 5 },
              { "data": "borrowerName",         "targets": 6 },
              { "data": "completeAddress",      "targets": 7 },
              { "data": "coverageType",         "targets": 8 ,"defaultContent":""},
              { "data": "buildingName",         "targets": 9 ,"defaultContent":""},
              { "data": "rowNum", "visible": false, "searchable": false,"sortable": false},
              { "data": "tmTaskId", "visible": false, "searchable": false,"sortable": false},
              { "data": "tmURL", "visible": false, "searchable": false,"sortable": false},
              { "data": "perfectionType", "visible": false, "searchable": false,"sortable": false},
              { "data": "cancellation", "visible": false, "searchable": false,"sortable": false}
          ],
          "autoWidth" : false,
          "dom" : '<"col-md-12"<"pull-right"l>rtip>',
          "order" : [6,"asc"],
          "paging" : true,
          "lengthMenu" : [ 25,50,100,200 ],
          "lengthChange" : true,            
          initComplete : function () { // Move the search boxes to the top of the page
              var r = $('#task-list tfoot tr');
              r.find('th').each(function(idx){
                  $(this).css('padding','1px');
                  if(idx!==0) {
                      $(this).html("<input type='text' class='form-control search-field'></input>");
                  }
              });
              
              var headers=r.find('th');
              
              headers.eq(0).css({'width':'3%','min-width':'20px'});
              headers.eq(1).css({'width':'8%','min-width':'76px'});
              headers.eq(2).css({'width':'11%'});
              headers.eq(3).css({'width':'11%'});
              headers.eq(4).css({'width':'6%','min-width':'65px'});
              headers.eq(5).css({'width':'11%'});
              headers.eq(6).css({'width':'12%'});
              headers.eq(7).css({'width':'14%'});
              headers.eq(8).css({'width':'10%'});
              headers.eq(9).css({'width':'14%'});

              $('#task-list thead').prepend(r);
              initializeSearches();
              $('.dataTables_length label').css('display', 'inline');
              $('.row-checkbox').change(checkboxChangeHandler);
              $('#ctracActions').change(ctracActionChangeHandler);
          },
          "drawCallback" : function( settings ) {//table loaded after pagination.
              initializeCheckboxes();
              $('.row-checkbox').change(checkboxChangeHandler);
          },
          "rowCallback" : function(row,data){//retain the selected checkboxes.
              var ctracRid=data.rowNum;
              if (selectedCheckBoxes.hasOwnProperty(ctracRid)) {
                  $(row).find(':checkbox').prop("checked", true);
              }
          }
      });
});

function initializeSearches() {
    // Apply the search
    var timer;
    $('.search-field').on('change paste keyup',function(){
        clearInterval(timer);
        $('.search-field').each(function() {
            var searchKey=this.value;
            var thisTd=$(this).closest('th');
            var visIdx=$(thisTd).index();
            var colIdx=taskListTable.column(visIdx).index();
            taskListTable.column(colIdx).search(searchKey);
        });
        timer = setTimeout(function(){
            taskListTable.draw();
        }, 1000);
    });
}

function checkboxChangeHandler(){
    //get datatable row that was changed
    var dtRow = findDtRow(this);
    
    //update the ctracRid list
    var dtData=dtRow.data();
    var ctracRid=dtData.rowNum;
    var workFlowStep=dtData.workFlowStep;
    var tmTaskId=dtData.tmTaskId;
    var tmURL=dtData.tmURL;
    var taskStatus=dtData.taskStatus;
    var propAddress=dtData.completeAddress;
    if(this.checked){//make sure in the list
        currentSelectedStatus = dtRow.data().taskStatus;
        selectedCheckBoxes[ctracRid]=new CheckedRow(tmTaskId,tmURL,taskStatus,workFlowStep,propAddress);
    }else{//make sure not in the list
        delete selectedCheckBoxes[ctracRid];
    }
    
    var selectedActionMenu = $("#ctracActions").val();
    if(selectedActionMenu==='Complete Item'){
        updateCheckboxesForCompleteItem();
    }
}

function ctracActionChangeHandler() {
    resetCheckboxes();
    initializeCheckboxes();
}

function findDtRow(child){
    return taskListTable.row($(child).closest('tr'));
}

function initializeWorkItem(){
	var selectableWorkflows=workableStatuses;

    $('.row-checkbox').each(function() {
        var taskStatus=findDtRow(this).data().taskStatus;
        if(taskStatus==='Active') {
            $(this).prop("disabled", false);
        }
        var workFlowStep=findDtRow(this).data().workFlowStep;
        var numberOfSteps=selectableWorkflows.length;
        if(taskStatus==='Dormant') {
        	for(var i=0;i<numberOfSteps;i++){
        		if(selectableWorkflows[i]===workFlowStep){
        			$(this).prop("disabled", false);
        		}
        	}
        }
    });
}

function initializeCompleteItem(){
    $('.row-checkbox').each(function() {
        var taskStatus=findDtRow(this).data().taskStatus;
        if(taskStatus==='Active'||taskStatus==='Dormant') {
            $(this).prop("disabled", false);
        }
    });
}

function initializeReviewBorrowerInsurance(){
    $('.row-checkbox').each(function() {
        var dtRowData=findDtRow(this).data();
        var taskStatus=dtRowData.taskStatus;
        var perfectionType=dtRowData.perfectionType;
        var workFlowStep=dtRowData.workFlowStep;
        var cancellation=dtRowData.cancellation;
        if((taskStatus==='Active'||taskStatus==='Dormant'||(workFlowStep==='Completed LP Policy Review'&&taskStatus!=='In Review'))
        		&&(perfectionType==='FLOOD_POLICY'&&cancellation==='N') && (workFlowStep!=='Policy Pending VFVL'))  {
            $(this).prop("disabled", false);
        }
        
      //we could merge to the condition above but will it be more readable?
        if(workFlowStep==='Awaiting Borrower Policy'&&taskStatus!=='In Review'){
        	$(this).prop("disabled", false);
        }  
        
        
        
    });
}

function updateCheckboxesForCompleteItem(){
    initializeCompleteItem();
    var numSelected=Object.size(selectedCheckBoxes);
    if(numSelected===0){//nothing checked, re-initialize
        currentSelectedStatus='None';
        return;
    }
    
    if(currentSelectedStatus==='Dormant') { //disable everything not checked
        $('.row-checkbox:not(:checked)').each(function() {
            $(this).prop("disabled", true);
        });
    }else if(currentSelectedStatus==='Active'){ //disable non-Active tasks
        $('.row-checkbox:not(:checked)').each(function() {
            var taskStatus=findDtRow(this).data().taskStatus;
            if(taskStatus!=='Active') {
                $(this).prop("disabled", true);
            }
        });
    }
}

function isPropAddressIdentical(propAddressList){
    var address = propAddressList[0];
    var isMatch = true;
    for(var i=1,j=propAddressList.length;i<j;i++) {
        if(address!==propAddressList[i]){
            return false;
        }
    }
    return isMatch;
}
    
function resetCheckboxes(){
    $('.row-checkbox').prop('checked', false);
    $('.row-checkbox').prop('disabled', true);
    selectedCheckBoxes=new Object();
}

function enableCheckedBoxes() {
    $('.row-checkbox:checked').each(function() {
        $(this).prop("disabled", false);
    });
}

//Enable/disable check box for tasks.    
function initializeCheckboxes(){
    enableCheckedBoxes();
    var selectedAction=$("#ctracActions").val();
    if(selectedAction!==''){//enable submit button
        $("#submitAction").attr("disabled", false);
    }else{
        $("#submitAction").attr("disabled", true);
    }
    
    if(selectedAction==='Work Item'){
        initializeWorkItem();
    }else if(selectedAction==='Complete Item'){                        
        updateCheckboxesForCompleteItem();
    }else if(selectedAction==='Review Borrower Insurance'){
        initializeReviewBorrowerInsurance();
    }
}
    