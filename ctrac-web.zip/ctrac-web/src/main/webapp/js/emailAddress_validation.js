var emailToShowErrMsg = false;
var emailCCShowErrMsg = false;
var emailBCCShowErrMsg = false;
//Assume it is string being passed in that needs to be
//split into an array then iterate and cleanup each one.
function trimEmailArrays(emailFieldName) {
	var emailString = $('#' + emailFieldName).val();
	if(!isBlank(emailString)) {
		var emails = emailString.split(/[;,]+/);
		$.each(emails, function (idx, val) {
		 	emails[idx] = $.trim(val);
    	});
    	emailString = emails.toString();
    }
    $('#' + emailFieldName).val(emailString);
}
//helper function to check for empty
function isBlank( data ) {
    return ( $.trim(data).length == 0 );
}
//helper function to handle most common email fields
function handleCommonEmailFieldTrims() {
	trimEmailArrays("emailTo");
	trimEmailArrays("emailCC");
	trimEmailArrays("emailBCC");
}
//Validate Multiple email Addresses in send email page.
jQuery.validator.addMethod(
	    "validateMultipleEmail",
	     function(value, element) {
	         if (this.optional(element)) // return true on optional element 
	             return true;
	         if(!validateInvalidCharInEmailAddress(value)){
	        	 return false;//Email contains invalid character in it.
	         }else {
	        	 return true;//Email is valid
	         }	         
	     },
	     jQuery.validator.messages.email
	);
//Checks whether email contains invalid character or not.
//Example : [john@chase.com,,,,,] [john@chase.com;;,;;,;;]
function validateInvalidCharInEmailAddress(value){
	//Regular Expression to check whether email address has any invalid character or not,like
	//continuous comma,continuous semi-colon,other invalid characters in email address.
	var emailInvalidCharFilterExp=/^[A-Z0-9\._%-]+@[A-Z0-9\.-]+\.[A-Z]{2,4}(?:[,;][A-Z0-9\._%-]+@[A-Z0-9\.-]+\.[A-Z]{2,4})*$/i;	
	if(emailInvalidCharFilterExp.test($.trim(value))){
			return true;
		}else {
			return false;
	    }
}
//Validating Email Domain Name and Restrict External Email Domain Names in to,cc,bcc input field.	
jQuery.validator.addMethod(
	    "validateEmailDomainName",
	     function(value, element) {	
	    	 if(value == ""){
	    		//displayWarningMessage(true,element);
	    		return true;//no need to validate empty email fields
	    	}	 
	         var emails = value.split(/[;,]+/); // split element by , and ;
	         if (emails.length == 0){
	        	 return false;
	         }
	         valid = true;
	         for (var i in emails) {
	             value = emails[i];
	             if(valid == true){	 
	            	 var emailAddress = value.toString().toLowerCase();
	            	 valid = checkEmailDomainName($.trim(emailAddress));
	             }
	         }
	       //  displayWarningMessage(valid,element);
	         return valid;
	     },
	    "<br> <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>&nbsp;Email messages are restricted from being sent to external domains. Please remove external email address."
	);

  function displayWarningMessage(valid,element){
	  //1.Enable / Disable 'to,cc,bcc' flag to control 'Email Domain Warning Message'
      //2.if one of the to,cc,bcc flag is enabled - "show err message"
      if($(element).attr('name') == 'emailTo'){
     	 if(valid == true){
     		 emailToShowErrMsg = false;
     	 }else if(valid == false){
     		 emailToShowErrMsg = true;
     	 }	        	 
      }else if($(element).attr('name') == 'emailCC'){
     	 if(valid == true){
     		 emailCCShowErrMsg = false;
     	 }else if(valid == false){
     		 emailCCShowErrMsg = true;
     	 }
      }else if($(element).attr('name') == 'emailBCC'){
     	 if(valid == true){
     		 emailBCCShowErrMsg = false;
     	 }else if(valid == false){
     		 emailBCCShowErrMsg = true;
     	 }
      }
      
      
	  if(emailToShowErrMsg==true||emailCCShowErrMsg==true||emailBCCShowErrMsg==true){
     	 $("#errorContainerEmailDomainName").show();
      }else if(emailToShowErrMsg==false && emailCCShowErrMsg==false && emailBCCShowErrMsg==false){
     	 $("#errorContainerEmailDomainName").hide();
      }
  }
  //Validating Email Domain Name in to,cc,bcc input field.
  function checkEmailDomainName(emailAddress){
	  	var lastIndex = emailAddress.lastIndexOf('@');  		    	
  		for (i=0;i<allowedEmailDomainNames.length;i++)
  		{
  			if (lastIndex != -1) {	    	   
  	    		domainName = emailAddress.substring(lastIndex +1);	    				
  	    		if(allowedEmailDomainNames[i] == domainName){	    	    			 
  	    			return true;
  	    		}
  			} 
  		}
  		return false;
  }
	
  jQuery.validator.addMethod("validateZipcodeUS", function(value, element) {
   return this.optional(element) || /\d{5}-\d{4}$|^\d{5}$/.test(value);
   }, "The specified US ZIP Code is invalid.");
  
  
  ;(function ($) {

		$.fn.maxlength = function(){
			 
			$("textarea[maxlength], input[maxlength]").keypress(function(event){ 
				var key = event.which;
				//all keys including return.
				if(key >= 33 || key == 13 || key == 32) {
					var maxLength = $(this).attr("maxlength");
					var length = this.value.length;
					if(length >= maxLength) {					 
						event.preventDefault();
					}
				}
			});
		}

	})(jQuery);
