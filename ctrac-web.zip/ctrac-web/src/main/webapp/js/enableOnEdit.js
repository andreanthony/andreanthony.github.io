/**
 * Will disable the buttons matching the selector inside the container.
 * Will enable if an input, select, or textarea within the container is changed.
 * 
 * For jQuery Datepicker widgets, need to add the following code to the onSelect method:
 * --> onSelect: function(dateText, inst) {
 * -->     if (dateText !== inst.lastVal) { $(this).change(); }
 * --> }
 * 
 */

ENABLE_ON_EDIT = {};

ENABLE_ON_EDIT.init = function(containerId, buttonSelector) {
	var container = $('#' + containerId);
	var buttons = container.find(buttonSelector);
	buttons.attr('disabled', 'disabled');
	container.find('input, select, textarea').change(function() {
		buttons.removeAttr('disabled');
    });
	
	container.find('.updataAction,.cmdBlock').click(function() {
		buttons.removeAttr('disabled');
    });
}