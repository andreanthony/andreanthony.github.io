function InlineLoader(containerId) {
    this.container = $('#'+ containerId);
    this.template = '<div class="ctrac-inline-loader" style="display:none"></div>';
    $(this.container).append(this.template);
}
InlineLoader.prototype = {};

InlineLoader.prototype.show = function(){
    $(this.container).find('.ctrac-inline-loader').show();
};

InlineLoader.prototype.hide = function(){
    $(this.container).find('.ctrac-inline-loader').hide();
};
