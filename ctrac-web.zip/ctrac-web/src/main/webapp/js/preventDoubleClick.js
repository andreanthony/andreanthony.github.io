 
function disableDoubleClick(commandClass ){
	
	if(!commandClass || typeof submitCmd ==='undefined' ){
		commandClass = 'submitCmd';
	}
	
	if( $('#SubmitCmdWrapper').length<=0 ){
		//alert(' not wrapper----- ');
		$('<input>').attr('type','hidden').attr('class','SubmitCmdWrapper').attr('id','SubmitCmdWrapper').attr('name','').prependTo('form');
	}else{
		//alert('wrapper----- ');
	}
	
	$('.'+commandClass).off("click").click( function(e){ 
		
		 //dealing with multiple click..
		// alert('Dealing ----- ');
		 $('.'+commandClass).clearQueue();
		 e.preventDefault();
		 
		 var callback= function(){ validateAndsubmitTheform.call(this,commandClass);};
		 setupTheCommandName( $(this).attr('name'), $(this).attr('value'), callback );
		 
		 return false;
	});
	
}

 function validateAndsubmitTheform(commandClass){
	
	 var formObject = $('.'+commandClass).parents('form');
	 //alert('disabling prior ----- ');
	 if(formObject && typeof formObject!='undefined'){
	// if(formObject.length){
		 $(formObject).validate();
		 
		 var isvalid = $(formObject).valid();
		 
		 if(!isvalid){
			// alert('not valid  ----- ');
			 return false;
		 }else{
			// alert('valid  ----- ');
			  var callback = function(){ $(formObject).submit();} ;
			 disableTheFormCommands(commandClass, callback );
		 }
	 }
 }
 
 function setupTheCommandName(name, value, callback ){
	 
	// alert('setting namer ----- ');
	 
	 $('#SubmitCmdWrapper').attr('name', name ).attr('value', value);
	 
	 if (typeof(callback) == "function"){
		 callback();
	 }
}
 
 
/* function submitTheForm( formObject ){
	 
	 alert('submiting the form  ----- ');
	 
	 $(formObject).submit();
 }*/
 
 function disableTheFormCommands(cmdClass, callback){
	 
	 //alert('disabling form----- ');
	 
	 $('.'+cmdClass).attr('disabled', 'disabled').clearQueue() ;
	 
	 if($('#cancel') ) { $('#cancel').attr('disabled', 'disabled').clearQueue() ;}
	 if($('#discontinueReview') ) { $('#discontinueReview').attr('disabled', 'disabled').clearQueue() ;}
	 if($('#export') ) { $('#export').attr('disabled', 'disabled').clearQueue() ;}
		
	 if (typeof(callback) == "function"){
		 callback();
	 }
 }