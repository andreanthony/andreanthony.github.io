/**
 *
 */
LOAN_MAINTENANCE = {};

LOAN_MAINTENANCE.init = function () {
    $('#loanModal').off('shown.bs.modal').on('shown.bs.modal', function (e) {
        var loanNumber = $('#loanNumber');
        if (loanNumber.val() === '') {
            loanNumber.focus();
        }
        $('#loanModal .datepicker').bind('keydown', function(event) {
            if (event.which === 13) {
                var e = jQuery.Event("keydown");
                e.which = 9;// tab
                e.keyCode = 9;
                $(this).trigger(e);
                return false;
            }
        }).datepicker({
            showOn : 'both',
            buttonImage : '../images/calendar-icon.png',
            buttonImageOnly: true,
            buttonText : '',
             disabled : CTRAC.readOnlyUserRole,
            showAnim : 'slide',
            onSelect : function(dateText, inst) {
                if (dateText !== inst.lastVal) {
                    $(this).change().focusout();
                }
            }
        });
        var externallyAgentedDependency = new DependentField('#loanType', function(element) {
            return element.find('option:selected').val() === 'Externally Agented';
        }, '.externally-agented');
        externallyAgentedDependency.setHideAndShow(true);
        externallyAgentedDependency.init();
        LOAN_MAINTENANCE.modal();
        if (CTRAC.readOnlyUserRole) {
            $("#loanMaintenanceForm").find("input, select").prop('disabled', true);
            $('.datepicker').attr('readonly',true);
        }
        $('#borrower-search tbody').off('click').on( 'click', 'tr', function () {
            var rowData = ENTITY_TABLE.entityTable.row(this).data();
            if (!rowData || rowData == null) {
                return;
            }

            var rid = escapeHTML(rowData['rid']),
                borrowerName = escapeHTML(rowData['name']),
                address = escapeHTML(rowData['address']),
                unit = escapeHTML(rowData['unitBuilding']),
                city = escapeHTML(rowData['city']),
                state = escapeHTML(rowData['state']),
                zip = escapeHTML(rowData['zipcode']),
                collateralIds = escapeHTML(rowData['collateralRids']);

            LOAN_MAINTENANCE.backToLoan('borrower-search');
            LOAN_MAINTENANCE.addBorrowerToLoan(rid, borrowerName, address, unit, city, state, zip, null, collateralIds);
        });

        ENTITY_TABLE.preInitOverlay('borrower-search', 'loanRid=' + $('#loanRid').val());

        LOAN_MAINTENANCE.registerCreateNewBorrowerEvents();
    });
};

LOAN_MAINTENANCE.modal = function () {
    $("#loanMaintenanceForm").submit(function(e) {
        e.preventDefault();
    }).validate({
        ignore : '.ignore',
        rules : {
          chkPrimaryLoan : { hasPrimaryLoans:true , onlyActivePrimaryLoan:true},
            releasedDate : { activePaidOff:true},
            numBorrowers : { atLeastOneBorrower : true },
            "collateralDto.marketEmailAddress" : {
                validateMultipleEmail : true,
                validateEmailDomainName : true
            }
        },
        errorContainer      : $('#errorContainerLoanMaintenance'),
        errorLabelContainer : "#errorContainerLoanMaintenance",
        errorElement     	: "span",
        errorClass          : "has-error text-danger alert-element-padding",
        validClass          : "",
        highlight : function(element) {
            setValidationError(element);
        },
        unhighlight : function(element) {
            clearValidationError(element);
        },
        submitHandler : function(form) {
            var origNumBorrowers = $('#origNumBorrowers').val(),
                numBorrowers = $('#numBorrowers').val(),
                i = numBorrowers;
            if (!$(form).valid()) {
               return false;
            }
            $('#borrowerData .borrower').each(function(index, element) {
                element = $(element);
                element.find('.rid').attr('name', 'borrowersData[' + index + '].rid');
                element.find('.borrowerName').attr('name', 'borrowersData[' + index + '].borrowerName');
                element.find('.streetAddress').attr('name', 'borrowersData[' + index + '].contactDetailDto.address.streetAddress');
                element.find('.unitOrBuilding').attr('name', 'borrowersData[' + index + '].contactDetailDto.address.unitOrBuilding');
                element.find('.city').attr('name', 'borrowersData[' + index + '].contactDetailDto.address.city');
                element.find('.state').attr('name', 'borrowersData[' + index + '].contactDetailDto.address.state');
                element.find('.zipCode').attr('name', 'borrowersData[' + index + '].contactDetailDto.address.zipCode');
                element.find('.remove').attr('name', 'borrowersData[' + index + '].remove');
            });

            //AJAX Form submission
            var cid= $("meta[name='_cid']").attr("content");
            var csrf=$("meta[name='_csrf']").attr("content");
            var spinnerConfig = {};
            spinnerConfig.loaderDivID = 'loanMaintenanceForm';
            toggleLoader(true,spinnerConfig);
            var disableFields = $("#loanMaintenanceForm")
                .find("button:enabled").prop('disabled', true);
            $.ajax({
                type: "POST",
                url: CTRAC.root+'loan/save?_cid='+cid + '&_csrf='+csrf,
                data: $('form#loanMaintenanceForm').serialize(),
                success: function(response){
                    //Refresh the policies / collateral details / loan - borrower / WorkFlow Section
                    ALL_SECTIONS.refreshCollateralPageSections(
                        ["workflowDetailsRow","insuranceSectionRow","collateralDetailsSection","loanBorrowerDetailsSection"],
                        function done(){
                            $(disableFields).prop('disabled', false);
                            LOAN_MAINTENANCE.displayConfirmMessage();
                            toggleLoader(false,spinnerConfig);
                            $('#loanModal .close').click();
                        });
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    $(disableFields).prop('disabled', false);
                    toggleLoader(false,spinnerConfig);
                    ALL_SECTIONS.handleFormSubmissionFailures(thrownError, xhr,'form#loanMaintenanceForm');
                }
            });
            return false;
        }
    });

    $("#createBorrowerForm").submit(function(e) {
        e.preventDefault();
    }).validate({
        errorContainer      : $('#errorContainerCreateBorrower'),
        errorLabelContainer : "#errorContainerCreateBorrower",
        highlight : function(element) {
            setValidationError(element);
        },
        unhighlight : function(element) {
            clearValidationError(element);
        },
        submitHandler : function(form) {
            //create request object
            var borrowerValidationRequestDto = new BorrowerValidationRequestDto(LOAN_MAINTENANCE.borrowerCustomerObjectToFieldMapper);
            LOAN_MAINTENANCE.validateBorrower(borrowerValidationRequestDto,function onSuccess(){
                //if validation passes - add borrower to the loan
                var borrowerIndex = escapeHTML($('#borrowerIndex').val());
                $('.create-borrower,.edit-borrower').hide();
                $('#loanModal .modal-dialog').removeClass('entityModal');
                $('.loan-details').show();
                LOAN_MAINTENANCE.addBorrowerToLoan('', borrowerValidationRequestDto.borrower.borrowerName,
                    borrowerValidationRequestDto.borrower.contactDetailDto.address.streetAddress,
                    borrowerValidationRequestDto.borrower.contactDetailDto.address.unitOrBuilding,
                    borrowerValidationRequestDto.borrower.contactDetailDto.address.city,
                    borrowerValidationRequestDto.borrower.contactDetailDto.address.state,
                    borrowerValidationRequestDto.borrower.contactDetailDto.address.zipCode,
                    borrowerIndex, CTRAC.collateralRID);
            }, function onError(xhr){
                //clear existing error box and populate with validation errors when found
                $('#errorMessage').html('');
                var formValidator = $('form#createBorrowerForm').validate();
                var errorObject = {};
                for(errorIndex in xhr.responseJSON.validationErrors){
                    if(formValidator.findByName(LOAN_MAINTENANCE.borrowerCustomerObjectToFieldMapper
                            [xhr.responseJSON.validationErrors[errorIndex].fieldId]).length === 1){
                        errorObject[LOAN_MAINTENANCE.borrowerCustomerObjectToFieldMapper
                            [xhr.responseJSON.validationErrors[errorIndex].fieldId]] =
                            xhr.responseJSON.validationErrors[errorIndex].message;
                    }
                }
                //Show errors in form with highlight
                formValidator.showErrors(errorObject);
            });
            return false;
        }
    });
};

//Map the Borrower Response Object to The Form Field ID's
LOAN_MAINTENANCE.borrowerCustomerObjectToFieldMapper = {
    'borrowerName':'entityName',
    'contactDetailDto.address.streetAddress':'entityMailingAddress',
    'contactDetailDto.address.unitOrBuilding':'entityUnitBuilding',
    'contactDetailDto.address.city':'entityCity',
    'contactDetailDto.address.state':'entityState',
    'contactDetailDto.address.zipCode':'entityZip'
};

//Construct borrower request object to send as JSON to perform server-side validation
var BorrowerValidationRequestDto = function (fieldMapper){
    this.borrower = {};
    this.borrower.borrowerName = escapeHTML($('#'+
        fieldMapper['borrowerName']).val());
    this.borrower.contactDetailDto = {};
    this.borrower.contactDetailDto.address = {};
    this.borrower.contactDetailDto.address.streetAddress = escapeHTML($('#'+
        fieldMapper['contactDetailDto.address.streetAddress']).val());
    this.borrower.contactDetailDto.address.unitOrBuilding = escapeHTML($('#'+
        fieldMapper['contactDetailDto.address.unitOrBuilding']).val());
    this.borrower.contactDetailDto.address.city = escapeHTML($('#'+
        fieldMapper['contactDetailDto.address.city']).val());
    this.borrower.contactDetailDto.address.state = escapeHTML($('#'+
        fieldMapper['contactDetailDto.address.state']).val());
    this.borrower.contactDetailDto.address.zipCode = escapeHTML($('#'+
        fieldMapper['contactDetailDto.address.zipCode']).val());
};

LOAN_MAINTENANCE.validateBorrower = function(borrowerValidationRequestDto, successCallback, onError) {
    //make server call to validate borrower object (sever-side validation)
    var cid = $("meta[name='_cid']").attr("content");
    var csrf=$("meta[name='_csrf']").attr("content");
    $.ajax({
        type: "POST",
        url: CTRAC.context + 'loan/borrower/validate?_cid=' + cid + '&_csrf='+csrf,
        contentType: "application/json",
        data:JSON.stringify(borrowerValidationRequestDto.borrower),
        success: function(response){
            if(response && response.success){
                successCallback();
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            onError(xhr);
        }
    });
};

LOAN_MAINTENANCE.addBorrowerToLoan = function (rid, borrowerName, address, unit, city, state, zip, borrowerIndex, collateralIds) {
    var borrowerData = $('#borrowerData'),
        clearfix,
        borrower;
    if (!rid || rid == null) {
        rid = '';
    }
    if (borrowerIndex && !isNaN(borrowerIndex)) {
        borrower = $('#borrowerData').children('.borrower').eq(borrowerIndex);
    } else {
        borrower = $('#borrowerTemplate').clone();
        borrower.removeAttr('id');
        borrower.children('.rid').val(rid);
    }
    borrower.children('.borrowerName').val(borrowerName);
    borrower.children('.streetAddress').val(address);
    borrower.children('.unitOrBuilding').val(unit);
    borrower.children('.city').val(city);
    borrower.children('.state').val(state);
    borrower.children('.zipCode').val(zip);
    borrower.children('.collateralIds').val(collateralIds);
    borrower.show();
    borrower.find('.entityName').html(borrowerName);

    var panelBody = address + ' ' + unit + '<br/>' + city + ', ' + state + ' ' + zip;


    borrower.find('.panel-body').html(panelBody);
    if (!borrowerIndex || isNaN(borrowerIndex)) {
        if (borrowerData.children('.borrower').length % 3 == 0) {
            clearfix = $('#clearfixTemplate');
            clearfix.removeAttr('id');
            borrowerData.append(clearfix);
        }
        borrowerData.append(borrower);
        $('#numBorrowers').valid();
        if ($.fn.dataTable.isDataTable('#borrower-search .entity-table')) {
            ENTITY_TABLE.entityTable.clear().draw();
        }
    }
};

var setValidationError = function(element) {
    $(element).closest(".form-group").addClass("has-error text-danger");
};

var clearValidationError = function(element) {
    $(element).closest(".form-group").removeClass("has-error text-danger");
};

jQuery.extend(jQuery.validator.messages, { required:' ', min:' ', digits:' ' });

jQuery.validator.addMethod("atLeastOneBorrower", function(value, element) {
    value = $('#borrowerData').children('.borrower').length;
    $(element).val(value);
    return value >= 1;
},'Add at least one Borrower.');

jQuery.validator.addClassRules({
    'zipCode' : {
        validateZipcodeUS : true
    }
});

LOAN_MAINTENANCE.viewURL = 'loan/view';

LOAN_MAINTENANCE.newLoan = function (e) {
    e.preventDefault();
    var url = CTRAC.root + LOAN_MAINTENANCE.viewURL;
    LOAN_MAINTENANCE.launchLoan(url, null);
};

LOAN_MAINTENANCE.editLoan = function (e, rid) {
    e.preventDefault();
    var url = CTRAC.root + LOAN_MAINTENANCE.viewURL;
    LOAN_MAINTENANCE.launchLoan(url, rid);
};

LOAN_MAINTENANCE.viewLoan = function (e, rid) {
    e.preventDefault();
    var url = CTRAC.root + LOAN_MAINTENANCE.viewURL;
    LOAN_MAINTENANCE.launchLoanView(url, rid);
};

LOAN_MAINTENANCE.launchLoan = function (url, rid) {
    var cid = $("meta[name='_cid']").attr("content"),
        url = url + '?_cid=' + cid + '&collateralRid=' + CTRAC.collateralRID + '&mode=' + LOAN_BORROWER.toggleable.mode;
    if (rid !== null) {
        url += '&loanRid=' + rid;
    }
    $.ajax({
        url: url,
        success: function(data) {
            var modalDialog = $(data).find('.modal-dialog'),
                loanModal = $('#loanModal'),
                ctracModal = $('#ctracModal');
            ctracModal.html('');
            loanModal.html(modalDialog);
            loanModal.modal({backdrop: true});
            var loanNumber = $('#loanNumber');
            if (loanNumber.val() === '') {
                loanNumber.focus();
            }
            if (rid !== null) {
                $("#btnLoanBorrowerDelete").show();
            }
        }
    });
};

LOAN_MAINTENANCE.launchLoanView = function (url, rid) {
    var cid= $("meta[name='_cid']").attr("content");

    $.ajax({
        url: url + '?_cid=' + cid + '&collateralRid=' + CTRAC.collateralRID + '&mode=' + LOAN_BORROWER.toggleable.mode + '&loanRid=' + rid,
        success: function(data) {
            var modalDialog = $(data).find('.modal-dialog'),
                loanModal = $('#loanModal'),
                ctracModal = $('#ctracModal');

            modalDialog.find(".modal-title").text("View Loan/Borrower");
            modalDialog.find("input, select, .panel").attr("disabled", true);//btnLoanBorrowerClose
            modalDialog.find("button, .required-field-symbol").not(".alwaysActive").hide();


            modalDialog.find(".text-muted").hide();
            modalDialog.find("input").removeClass("datepicker");


            ctracModal.html('');
            loanModal.html(modalDialog);
            loanModal.modal({backdrop: true});
        }
    });
};


LOAN_MAINTENANCE.addBorrower = function () {
    $('.loan-details').hide();
    $('.borrower-search').show();
    $("#searchEntity").focus().val('');
};

LOAN_MAINTENANCE.removeBorrower = function (e, element) {
    e.preventDefault();
    if (CTRAC.readOnlyUserRole) {
        return false;
    }
    var yes = confirm('Are you sure you want to remove this borrower from the loan?');
    if (yes) {
        if($(element).closest('.borrower').find('.pending-record').length > 0) {
            $(element).closest('.borrower').remove();
        }else{
            $(element).closest('.borrower').hide();
            $(element).closest('.borrower').find('.remove').val('true');
        }
    }
};

LOAN_MAINTENANCE.editBorrower = function (e, element) {
    e.preventDefault();
    var borrower = $(element).closest('.borrower'),
        rid = borrower.find('.rid').val(),
        borrowerName = borrower.find('.borrowerName').val(),
        streetAddress = borrower.find('.streetAddress').val(),
        unitOrBuilding = borrower.find('.unitOrBuilding').val(),
        city = borrower.find('.city').val(),
        state = borrower.find('.state').val(),
        zipCode = borrower.find('.zipCode').val(),
        collateralIds = borrower.find('.collateralIds').val(),
        borrowerIndex = $('#borrowerData').children('.borrower').index(borrower);

    $('.loan-details').hide();
    $('#entityName').val(borrowerName);

    $('#entityMailingAddress').val(streetAddress);
    $('#entityUnitBuilding').val(unitOrBuilding);
    $('#entityCity').val(city);
    $('#entityState').val(state);
    $('#entityZip').val(zipCode);
    $('#relatedCollateralIds').text(collateralIds);
    $('#borrowerIndex').val(borrowerIndex);
    LOAN_MAINTENANCE.resetVerifiedPostalFields();
    $('.edit-borrower').show();
    if (CTRAC.readOnlyUserRole) {
        $("#createBorrowerForm").find("input, select").prop('disabled', true);
        $("#saveBorrower").prop("disabled", true);
        $("#verifyLBPostalAddress").prop("disabled", true);
    }

};

LOAN_MAINTENANCE.backToLoan = function () {
    $('.borrower-search').hide();
    $('.loan-details').show();
};

LOAN_MAINTENANCE.createNewBorrower = function () {
    $('.borrower-search').hide();
    $('#loanModal .modal-dialog').addClass('entityModal');
    LOAN_MAINTENANCE.resetVerifiedPostalFields();
    $('.create-borrower').show();
    $('#createBorrowerForm input,#createBorrowerForm select').val('');
    $('#entityName').focus().val($('#searchEntity').val());
};

LOAN_MAINTENANCE.backToBorrower = function () {
    var borrowerIndex = $('#borrowerIndex').val();
    if (borrowerIndex && !isNaN(borrowerIndex)) {
        LOAN_MAINTENANCE.cancelEditBorrower();
    } else {
        $('.create-borrower').hide();
        $('#loanModal .modal-dialog').removeClass('entityModal');
        $('.borrower-search').show();
        $('#searchEntity').focus();
    }
};

LOAN_MAINTENANCE.cancelEditBorrower = function () {
    $('.edit-borrower').hide();
    $('.loan-details').show();
};

function escapeHTML(arg) {
    return arg;
    //FIXME don't want to escape for user... return $("<div>").text(arg).html();
}

LOAN_MAINTENANCE.saveBorrower = function (e) {
    e.preventDefault();
};

LOAN_MAINTENANCE.registerCreateNewBorrowerEvents = function(){
    $("#saveBorrower").off("click").on("click", function(event){
        if ($("#postalAddressLBVerified").val() !== "Y") {
            LOAN_MAINTENANCE.displayMessageCreateBorrower("Please verify postal address first.");
            event.preventDefault();
            return;
        }
    });

    $("#verifyLBPostalAddress").off("click").on("click", function(){
        LOAN_MAINTENANCE.verifyPostalAddress();
    });

    $("#acceptLBVerifiedPostalAddress").off("click").on("click", function(){
        LOAN_MAINTENANCE.acceptVerifiedPostalAddress();
    });

    $("#entityMailingAddress, #entityUnitBuilding, #entityCity, #entityState, #entityZip").off("change").on("change", function(){
        LOAN_MAINTENANCE.resetVerifiedPostalFields();
    });

    LOAN_MAINTENANCE.resetVerifiedPostalFields();
};

LOAN_MAINTENANCE.displayMessageCreateBorrower = function (message) {
    $("#errorMessage").text(message);
    $("#errorContainerCreateBorrower").show();
};

LOAN_MAINTENANCE.resetVerifiedPostalFields = function () {
    $("#errorContainerCreateBorrower").hide();
    $("#errorMessage").val("");

    $("#lblStreetAddress").text("");
    $("#lblUnitBuilding").text("");
    $("#lblCity").text("");
    $("#lblState").text("");
    $("#lblZipCode").text("");
    $("#postalAddressLBVerified").val("N");

    $("#acceptLBVerifiedPostalAddress").hide();
};

LOAN_MAINTENANCE.acceptVerifiedPostalAddress = function() {
    LOAN_MAINTENANCE.setFieldValue("#lblStreetAddress", "#entityMailingAddress");
    LOAN_MAINTENANCE.setFieldValue("#lblUnitBuilding", "#entityUnitBuilding");
    LOAN_MAINTENANCE.setFieldValue("#lblCity", "#entityCity");
    LOAN_MAINTENANCE.setFieldValue("#lblState", "#entityState");
    LOAN_MAINTENANCE.setFieldValue("#lblZipCode", "#entityZip");

    $("#acceptLBVerifiedPostalAddress").hide();
};

LOAN_MAINTENANCE.verifyPostalAddress = function() {
    $("#lblStreetAddress").text("");
    $("#lblUnitBuilding").text("");
    $("#lblCity").text("");
    $("#lblState").text("");
    $("#lblZipCode").text("");
    var cid = $("meta[name='_cid']").attr("content");

    var vUrl = CTRAC.context+'getVerifiedPostalAddressForLoanBorrower?_cid='+cid;

    $.ajax({
        type: "GET",
        url: vUrl,
        data: $('form#createBorrowerForm').serialize(),
        error: function() {
            LOAN_MAINTENANCE.displayMessageCreateBorrower("Error making call to address verification service.");
        },
        success: function(data) {
            var completeAddress = data.split("|");

            if (completeAddress.length === 5) {
                LOAN_MAINTENANCE.setLabelValue("#lblStreetAddress", completeAddress[0], $("#entityMailingAddress").val());
                LOAN_MAINTENANCE.setLabelValue("#lblUnitBuilding", completeAddress[1], $("#entityUnitBuilding").val());
                LOAN_MAINTENANCE.setLabelValue("#lblCity", completeAddress[2], $("#entityCity").val());
                LOAN_MAINTENANCE.setLabelValue("#lblState", completeAddress[3], $("#entityState").val());
                LOAN_MAINTENANCE.setLabelValue("#lblZipCode", completeAddress[4], $("#entityZip").val());

                $(".lbl").show();
                $("#acceptLBVerifiedPostalAddress").show();
                $("#postalAddressLBVerified").val("Y");
            } else {
                if (data.indexOf("Error: ") === 0) {
                    LOAN_MAINTENANCE.displayMessageCreateBorrower(data);
                } else {
                    LOAN_MAINTENANCE.displayMessageCreateBorrower("Error encountered: data returned in incorrect format.");
                }
            }
        }
    });
};

LOAN_MAINTENANCE.setLabelValue = function(labelTagName, newValue, originalValue) {
    var defaultColor = "black";
    var mismatchColor = "red";

    $(labelTagName).text(newValue);
    if (newValue === originalValue) {
        $(labelTagName).css("color", defaultColor);
    } else {
        $(labelTagName).css("color", mismatchColor);
    }
};

LOAN_MAINTENANCE.setFieldValue = function (labelTagName, textTagName) {
    var defaultColor = "black";
    var mismatchColor = "red";

    $(textTagName).val($(labelTagName).text());
    $(labelTagName).css("color", defaultColor);
};

jQuery.validator.addMethod("onlyActivePrimaryLoan", function(value, element) {
    var activeLoanCount = $("#chkPrimaryLoan").attr('data-activeLoans');
    var primaryOnSubmit = $("#chkPrimaryLoan").is(':checked');
    var launchingNew = $("#chkPrimaryLoan").attr('data-launchingNew') === 'true';
    if(launchingNew){
       activeLoanCount = activeLoanCount + 1;
    }
    if((activeLoanCount - 1) <= 0 && !primaryOnSubmit) {
        return false;
    }
    return true;
},'');

jQuery.validator.addMethod("activePaidOff", function(value, element) {
    var activeLoanCount = $("#chkPrimaryLoan").attr('data-activeLoans');
    var primaryOnSubmit = $("#chkPrimaryLoan").is(':checked');
    var releasedDate = $("#releasedDate").val();

    if(activeLoanCount > 1 && primaryOnSubmit && releasedDate !== '' ) {
        $.validator.messages.activePaidOff ='Please select another active Borrower/Loan as the Primary Loan prior to updating this record as paid off.';
        return false;
    }
    return true;
},'');

jQuery.validator.addMethod(
        "hasPrimaryLoans",
        function(value, element) {
        var loanType = $("#loanType").val();
        var primary = $("#chkPrimaryLoan").is(':checked');
        var fhmcLoanExists = $("#chkPrimaryLoan").attr(
                'data-fhmcLoanExists') === 'true';
        var fnmaLoanExists = $("#chkPrimaryLoan").attr(
                'data-fnmaLoanExists') === 'true';
        var standardLoanExists = $("#chkPrimaryLoan").attr(
                'data-standardLoanExists') === 'true';
        var chargedOffLoanExists = $("#chkPrimaryLoan").attr(
                'data-chargedOffLoanExists') === 'true';

        switch (loanType) {
        case 'SBA':
            if (primary && (fhmcLoanExists || fnmaLoanExists || standardLoanExists || chargedOffLoanExists)) {
                  $.validator.messages.hasPrimaryLoans =validateSBALoanprimary(fhmcLoanExists, fnmaLoanExists,  standardLoanExists, chargedOffLoanExists);
                return false;
            }
            break;
        case 'FNMA':
            if (!primary && !fnmaLoanExists) {
                  $.validator.messages.hasPrimaryLoans = 'FNMA Loan Type has to be Primary Loan.';
                return false;
            }
            break;
        case 'Charged Off':
            if (primary && (fhmcLoanExists || fnmaLoanExists || standardLoanExists)) {
                  $.validator.messages.hasPrimaryLoans = validateChargedOffLoanprimary(fhmcLoanExists,  fnmaLoanExists, standardLoanExists);
                return false;
            }
            else if (!primary && !fnmaLoanExists  && !fhmcLoanExists && !standardLoanExists && !chargedOffLoanExists) {
                  $.validator.messages.hasPrimaryLoans = 'Charged Off Loan Type has to be Primary Loan.';
                return false;
            }
            break;
        case 'Standard':
            if (primary && (fhmcLoanExists || fnmaLoanExists)) {
                  $.validator.messages.hasPrimaryLoans = validateStandardLoanprimary(fhmcLoanExists, fnmaLoanExists);
                return false;
            }
            else if (!primary && !fnmaLoanExists && !fhmcLoanExists && !standardLoanExists ) {
                  $.validator.messages.hasPrimaryLoans = 'Standard Loan Type has to be Primary Loan.';
                return false;
            }
            break;
        case 'FHMC':
            if (primary && fnmaLoanExists) {
                  $.validator.messages.hasPrimaryLoans = 'FNMA Loan Type has to be Primary Loan.';
                return false;
            }
            else if(!primary && !fnmaLoanExists && !fhmcLoanExists) {
                  $.validator.messages.hasPrimaryLoans = 'FHMC Loan Type has to be Primary Loan.';
                    return false;
            }
            break;
        default:
            return true;
        }
        return true;
    },$.validator.messages.hasPrimaryLoans);



     //Standard loan cannot be the primary when  fhmcLoanExists or fnmaLoanExists exists
    function validateStandardLoanprimary(fhmcLoanExists, fnmaLoanExists) {
        var msg ;
        if (fnmaLoanExists) {
            msg = "FNMA Loan Type has to be Primary Loan.";
        }
        else if (fhmcLoanExists) {
            msg = "FHMC Loan Type has to be Primary Loan.";
        }
        return msg;
    };

    function  validateChargedOffLoanprimary(fhmcLoanExists,  fnmaLoanExists, standardLoanExists) {
        var msg = validateStandardLoanprimary(fhmcLoanExists, fnmaLoanExists);
        if (msg==null && standardLoanExists) {
            msg = "Standard Loan Type has to be Primary Loan.";
        }
        return msg;

    };
    function validateSBALoanprimary(fhmcLoanExists, fnmaLoanExists,  standardLoanExists, chargedOffLoanExists){
        var msg = validateChargedOffLoanprimary(fhmcLoanExists, fnmaLoanExists, standardLoanExists);
        if (msg==null && chargedOffLoanExists) {
            msg = "Charged Off Loan Type has to be Primary Loan.";

        }
        return msg;
    };


LOAN_MAINTENANCE.displayConfirmMessage = function(){
    var successMessageHtml = '<strong> Success!</strong> Updates are successfully saved';
    if($('#loanMessageWrapper .alert-success').length === 1){
        $('#loanMessageWrapper .alert-success').html(successMessageHtml);
    }else{
        $('#loanMessageWrapper').append( '<div class="alert alert-success"> '+successMessageHtml+'</div>');
    }
};

