var taskUUId = "";
var currentMode = "";
var emailWarningMessage = "A Mortgage/DOT Documents is required to be attached. Please attach the document.";
var realEstateValue = "Real Estate";

var ALL_SECTIONS = {};
var COLLATERAL_DETAILS = {};

var dataChanged = false;
ALL_SECTIONS.dataLoadInProgress = false;

var hasRoleWriter = function() {
    return $('#hasRoleWriter').length > 0;
};

var COLLSCREENAjaxError ={};

COLLSCREENAjaxError.reloadThecollateralScreen = function reloadThecollateralScreen(callbak){
	var cid= $("meta[name='_cid']").attr("content");
	window.location = CTRAC.context+'reloadCollateralDetailsFromDb?_cid='+cid;
	if (typeof(callback) == "function"){
		 callback(response);
	}
};

COLLSCREENAjaxError.ajaxErrorProcessing = function ajaxErrorProcessing(error){
	// if error (like, Concurrent error), entered data will be lost and user has to get the latest data by refreshing.
	dataChanged = false;

	//hide the message box when edit start
   var loadCallBack = function(data){  }; //nothing to be done for now, just a place holder

   COLLSCREENAjaxError.reloadThecollateralScreen(loadCallBack);
};

ALL_SECTIONS.handleFormSubmissionFailures = function(thrownError, xhr, formSelector){
    if(xhr != undefined && xhr.responseJSON != undefined && xhr.responseJSON.validationErrors != undefined){
        var formValidator = $(formSelector).validate();
        var errorObject = {};
      for(errorIndex in xhr.responseJSON.validationErrors){
         if(formValidator.findByName(xhr.responseJSON.validationErrors[errorIndex].fieldId).length == 1){
            errorObject[xhr.responseJSON.validationErrors[errorIndex].fieldId] =
               xhr.responseJSON.validationErrors[errorIndex].message;
         }else{
        	 var selector = formValidator.labelContainer.selector;
            $(selector).append('<span class="has-error text-danger alert-element-padding">' + xhr.responseJSON.validationErrors[errorIndex].message + '</span>');
            $(selector).show();
            return;
         }
      }
      formValidator.showErrors(errorObject);

    }else{
        COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
    }
};

ALL_SECTIONS.initializeAllSections = function(ctracReferenceDate) {
	$.ajaxSetup({
	    beforeSend:function(){
	        $(".ctrac_loader").show();
	    },
	    complete:function(){
	    	if(!ALL_SECTIONS.dataLoadInProgress){
                $(".ctrac_loader").hide();
			}
	    }
	});

	$('#ctracModal').off('DOMNodeInserted').on('DOMNodeInserted', function(e) {
		if (e.target.id && e.target.id.indexOf('SWFUpload_') === 0
				&& $(e.target).attr("class") == "uploadify-queue-item") {
		   var parentForm = $(e.target).parents("form").attr("id");

		   if (parentForm == "frmCollateralDetails") {
			   $("#btnCollateralDetailsSave").prop("disabled", false);
		   } else if (parentForm == "floodDeterminationForm") {
			   $("#newFloodDeterminationModalSave").prop("disabled", false);
		   } else if (parentForm == "coverageRequirementForm") {
			   $("#newReqCoveModalSave").prop("disabled", false);
		   }
		}
	});

	// After event - $('#ctracModal').on('hidden.bs.modal', function () {
	$('#ctracModal').off('hide.bs.modal').on('hide.bs.modal', function () {

		var filesUploaded = $('#ctracModal .uploadify-queue .uploadify-queue-item .data').filter(function(){ if ($(this).text() == "") return true;}).length;
		//alert(filesUploaded);

		var closeModal = true;

		if (dataChanged || filesUploaded > 0) {

			closeModal = confirm("Are you sure you want to close this overlay without saving your changes?");
			if (closeModal) {
				dataChanged=false;
			}
		}

		return(closeModal);
    });

	displaySingle();

    COLLATERAL_DETAILS.initializeCollateralDetailsSection();

	$("#accordionView").on("click", function(event){
		event.preventDefault();

		$("#divExpandAll").show();

		if (currentMode == "Accordion") {
			false;
		}

		$("#singlePageView").removeClass("activeLink");
		$("#accordionView").addClass("activeLink");

		// Accordion
		// multiple accordions are created instead of one to support - opening and closing for multiple tabs(sections)
		// default all to open (verify) - currently making the first section active
		$(".accordionContainer").each(function (index){
			if (index == 0) {
				$(this).accordion({
		            heightStyle: 'content',
		            collapsible: true
		        });
			} else {
				$(this).accordion({
		            heightStyle: 'content',
		            collapsible: true,
		            active: false
		        });

			}

		});

		currentMode="Accordion";
	});

	$("#singlePageView").on("click", function(event){
		event.preventDefault();

		$("#divExpandAll").hide();

		if (currentMode == "SinglePage") {
			return;
		}

		$("#singlePageView").addClass("activeLink");
		$("#accordionView").removeClass("activeLink");

		if (currentMode == "Accordion") {
			$( ".accordionContainer" ).accordion("destroy");
		}

		currentMode = "SinglePage";
	});


	$("#expandAll").on("click", function(event){
		event.preventDefault();
		$( ".accordionContainer" ).accordion( "option", "active", 0 );
	});

	$("#collapseAll").on("click", function(event){
		event.preventDefault();
		$( ".accordionContainer" ).accordion( "option", "active", false );
	});

	jQuery.validator.addMethod("hasCollateralOwner", function(value, element) {
		if ($("#collateralOwners-list-data").find("tr").length == 0) {
			return false;
		} else {
			return true;
		}
	},'');

	jQuery.validator.addMethod("hasMaxNumberOfMortgageDocuments", function(value, element) {
		var totalFileCount = $(".uploadedFile").length +  $("#mortgageDOTDocumentContainerOverlay").find(".fileName").length;
		$("#uploadedFilesCount").val(totalFileCount);

		if (totalFileCount > 6) {
			return false;
		} else {
			return true;
		}
	},'');


    $(document).on("click", function(){
    	$("#saveStatus").text("");
    	$("#saveStatus").hide();
    });

	$( "#radio" ).buttonset();

	INSURANCE_POLICIES.initializeInsurancePoliciesSection();

    COVERAGE_REQUIREMENT.initializeRequiredCoverageSection();

	LOAN_BORROWER.initializeLoanBorrowerSection(ctracReferenceDate);

	FLOOD_DETERMINATION.initializeFloodDeterminationSection();
    GENERAL_COVERAGE_REQUIREMENT.initializeGeneralRequiredCoverageSection();

    setReleasedCollateralReadonly();

};
// End of document ready event


ALL_SECTIONS.reloadCollateralDetails = function(callback) {
    var cid= $("meta[name='_cid']").attr("content");
    ALL_SECTIONS.dataLoadInProgress = true;
    $.ajax({
        type: "GET",
        url: CTRAC.context+'collateralDetails?collateralID='+CTRAC.collateralRID+'&_cid='+cid,
        data: $('form#collateralSectionForm').serialize(),
        success: function(response){
            ALL_SECTIONS.dataLoadInProgress = false;
        	if (response.indexOf("ACCESS DENIED") > -1) {
                alert("CTRAC - Access Denied.");
            }else if (typeof(callback) === "function"){
				callback(response);
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            ALL_SECTIONS.dataLoadInProgress = false;
            COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
        }
    });
};

ALL_SECTIONS.refreshCollateralPageSections = function(sectionsToRefresh, doneCallBack) {
	//Load collateral details screen fresh with values
    var currentPolicyToggleMode = INSURANCE_POLICIES.toggleable.mode;
    var sectionsCloned = $.extend(true, [], sectionsToRefresh);
    ALL_SECTIONS.reloadCollateralDetails(function(response){
		//refresh the collateral detail page notification section
        sectionsCloned.push("collateralDetailNotificationContainer");
    	//For each section part of the given object - refresh the section on screen
        for(var i in sectionsCloned){
            var section = sectionsCloned[i];
            $('#'+section).replaceWith($(response).find('#'+section));
			//Fire any initialization functions depending on what section is refreshing
            if("workflowDetailsRow" === section){
                WORKFLOW.initializeSection();
			}else if("requiredInsuranceCoverageSection" === section){
                COVERAGE_REQUIREMENT.initializeRequiredCoverageSection();
            }else if("generalRequiredInsuranceCoverageSection" === section){
                GENERAL_COVERAGE_REQUIREMENT.initializeGeneralRequiredCoverageSection();
            }else if("insuranceSectionRow" === section){
                INSURANCE_POLICIES.initializeInsurancePoliciesSection(
                	$(response).find('#insuranceSectionVerify').length !== 0
						? currentPolicyToggleMode : undefined);
            }else if("loanBorrowerDetailsSection" === section){
                LOAN_BORROWER.initializeLoanBorrowerSection(CTRAC.ctracReferenceDate);
            }else if("collateralDetailsSection" === section){
                COLLATERAL_DETAILS.initializeCollateralDetailsSection();
			}
        }
        if(typeof(doneCallBack) === 'function'){
        	doneCallBack();
		}
	});
};

function setVerificationModeForCollateralDetailsSection(verifyMode) {

	$("#collateralDetailsSectionVerificationStarted").prop("checked", verifyMode);

	if (verifyMode) {
		$("#btnStartVerificationCollateralDetailsSection").hide();
		$("#btnCompleteVerificationCollateralDetailsSection").show();
		$("#btnCancelVerificationCollateralDetailsSection").show();
	} else {
		$("#btnStartVerificationCollateralDetailsSection").show();
		$("#btnCompleteVerificationCollateralDetailsSection").hide();
		$("#btnCancelVerificationCollateralDetailsSection").hide();
	}
}

function initializeCollateralDetailsFilesUpload() {
	var totalUploadedFiles = $(".uploadedFile").length +
							 $("#mortgageDOTDocumentContainerOverlay").find(".fileName").length;


	var allowEmptyAttachement = false;

	if (totalUploadedFiles > 0) {
		allowEmptyAttachement = true;
	}

	var pageConfig = {
			taskUUId : taskUUId,
			cmdClass : 'submitCmd',
    attachDivID : 'mortgageDOTDocumentContainerOverlay',                 // div containing browse button
    inputFileID : 'file_upload_overlay',                    // id of the file input form
   AttachmentErrMs : 'AttachmentErrMsCollateralDetails',            // div that displays attachment error message
    emailFormID : 'frmCollateralDetails',  // id of the email form (global from)
    maxTotalQueueSize : '10MB',                     // limit on the sum of the size of all files in the queue in MB or KB
    loaderDivID : 'container',                   // where to show the spin loader
    allowEmptyAttachement: allowEmptyAttachement,                   // allow no attachments
    emptyFileErrMsg: "A Mortgage/DOT Document is required to be attached.  Please attach the document.",
    appendGyfon: true,
    allDoneCallBack: uploadCallBack,
    asynch:true,
    submitCallBack: collateralDetailsSuccessHandler,
    submitErrorCallBack:failureHandler,
    uploadMinimun:1
};
var uploadifyConfig = {
	'formData'      : { 'taskUUId' : pageConfig.taskUUId },
    'uploadLimit'   : 6,
    'fileSizeLimit' : '10MB', //individual file size limit
    'auto'          : false,
    'fileTypeExts'  : '*.pdf',
    'fileTypeDesc' : 'PDF Files',
    'maxSizeErrMsg':"\nFiles were not attached. The number of files selected exceeds the maximum upload limit of six (6) and/or the maximum size of 10MB.",                 //Error message when file size exceeds total allowable file size limit
    'uploadLimitErrMsg' :"\nFiles were not attached. The number of files selected exceeds the maximum upload limit of six (6) and/or the maximum size of 10MB." //Error message when file count exceeds max file count
};
initEmailAttachments(pageConfig, uploadifyConfig);
}

// Close the popup window when the user clicks 'cancel' and 'X'.
function closeHelperPopup() {
	var w = self; // grab the reference to your helper window
	while (w.parent != w) w = w.parent; // grab the reference to root window, by pass any level of nested iFrame
	w.close();
}

function checkboxControl(checkbox, control) {
    if (checkbox.checked) { control.show(); }
    else { control.hide(); }
}

function displaySingle() {
	$("#singlePageView").addClass("activeLink");
	$("#accordionView").removeClass("activeLink");

	$(".btnEdits").hide();

	$("#section1").prepend($("#commonInfo"));
	$("#tableBorder").hide();
	$("#divExpandAll").hide();
}

function closeCallBack() {
	if (CTRAC.isBrowserClose) {
		unlockTask();
	}
}

function uploadCallBack(){
	//CTRAC.isBrowserClose=false;
}


function deleteMortagagor(index, callback){
	var extraData = "&action=delete&index="+index;
	updateMortgagor(extraData, callback);
}

function collateralDetailsSuccessHandler() {
	// reset dataChanged
	dataChanged = false;

	$("#collateralDetailsSaveStatus").html(
			"<strong>Success! </strong>Changes have been saved successfully.");
	$("#collateralDetailsSaveStatus").show();
	$("#btnCollateralDetailsSave").prop('disabled', true);

	$.ajax({
		type : "GET",
		global : false, // prevent global setting to show loading spinner
		url : CTRAC.context+'reloadCollateralDetailsSectionFromSession',
		cache : false,
		data : $('form#frmCollateralDetails').serialize(),
		success : function(response) {
			if (response.indexOf("ACCESS DENIED") > -1) {
				alert("CTRAC - Access Denied.");
			}
			// alert(response);
			$("#collateralDetailsSection").replaceWith(
					'<div  id="collateralDetailSection" class="results-block">'
							+ response + '</div>');
			 repaintPageTitle();
			initializeCollateralDetailsFilesUpload();
		},
		error : function(xhr, ajaxOptions, thrownError) {
			alert(xhr.status + " thrownError: " + thrownError);
		}

	});

}

function repaintPageTitle(){
	   $.ajax({
	        type: "POST",
            url: CTRAC.context+ 'resetPageTitle',
	        data: $('form#frmCollateralDetails').serialize(),
	        success: function(data){
	        	document.getElementById('pageTitleDescription').innerHTML=data;
	        },
	   		error: function(xhr, ajaxOptions, thrownError) {
	   			alert(xhr.status + " thrownError: " + thrownError);
	   		}
	   });
}


function deleteMortgageDocument(index, callback){
	var extraData = "&index="+index;

	var cid= $("meta[name='_cid']").attr("content");
	   $.ajax({
	        type: "POST",
	        url: CTRAC.context+'saveCollateralSectionInfo/removeMortgagorDoc?_cid='+cid,
	        data: $('form#collateralSectionForm').serialize()+extraData,
	        success: function(response){
	        	//alert("Success");
				dataChanged = true;
				$("#btnCollateralDetailsSave").prop('disabled', false);
	        },
	   		error: function(xhr, ajaxOptions, thrownError) {
	   			alert(xhr.status + " thrownError: " + thrownError);
	   		}
	   });
}


function deleteTheCollateral(callback){
	   var cid= $("meta[name='_cid']").attr("content");
	   $.ajax({
	        type: "POST",
	        url: CTRAC.context+'deleteCollateral?_cid='+cid,
	        data: $('form#collateralSectionForm').serialize(),
	        success: function(response){
	           alert("Collateral deleted successfully!! ");
	           if (typeof(callback) == "function"){
	       		  callback(response);
	           }
	        },
	   		error: function(xhr, ajaxOptions, thrownError) {
	           alert("Collateral delete failed!!");
	   		   COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
	   		}
	   });
}



function deleteCollateral(){

	if(!confirm (" Are you Sure you want to delete the collateral ? ")){
		return;
	}
	var callback = function(data){ window.location = 'searchCollateral'};
	deleteTheCollateral(callback);
}




function addMortgagor(callback){
	var extraData = "&action=add";
	updateMortgagor(extraData, callback);
}

function updateMortgagor(extraData, callback){
	   var cid= $("meta[name='_cid']").attr("content");
	   $.ajax({
	        type: "POST",
	        global: false, // prevent global setting to show loading spinner
	        url: CTRAC.context+'saveCollateralSectionInfo/updateMortgagers?_cid='+cid,
	        data: $('form#collateralSectionForm').serialize()+extraData,
	        success: function(response){
	        	//alert("Success");
	        },
	   		error: function(xhr, ajaxOptions, thrownError) {
	   			alert(xhr.status + " thrownError: " + thrownError);
	   		}
	   });
}


function cancelCollateralSectionInfo(){
	   var cid= $("meta[name='_cid']").attr("content");
	   var collateralID = $("#collateralID").val();
	   $.ajax({
	        type: "GET",
	        url: CTRAC.context+'collateralDetailsSection?_cid='+cid+"&collateralID="+collateralID,
	        data: $('form#collateralSectionForm').serialize(),
	        success: function(response){
	        	//$(".editSection").prop('disabled', false);
	        	// Arun: TODO: Consider access only if certain successful keyword is found in the response.
	        	// This to prevent errors like - "CTRAC - ACCESS DENIED"
	        	if (response.indexOf("ACCESS DENIED") > -1) {
	        		alert("CTRAC - Access Denied.");
	        	}

	        	//alert("Response: " + response);
	        	$("#collateralDetailsSection").replaceWith('<div  id="collateralDetailSection">' + response + '</div>');

                COLLATERAL_DETAILS.initializeCollateralDetailsSection();
	        },
	   		error: function(xhr, ajaxOptions, thrownError) {
	   			alert(xhr.status + " thrownError: " + thrownError);
	   		}
    });
}

function setReadonlyMode() {
	return;
	$("input:not(#chkInactive):not(), select").not("input[type='hidden']").not("input[type='button']").prop('disabled', true);
	$("#editCollateralDetails").show();
	//$("#editFloodDetermination").show();
	$("#btnStartVerificationCollateralDetails").show();
	//$("#btnStartVerificationFloodDetermination").show();
	$("#saveCancelCollateralDetails").hide();
	$("#verifyCancelCollateralDetails").hide();
	//$("#verifyCancelFloodDetermination").hide();
	$(".deleteColumnCollateralDetails").hide();
	$(".deleteColumnMortgageDocument").hide();
	$("#sfhdfContainer").hide();
	//$("#new-required-insurance-coverage-amount").prop('disabled', true);
	$("#new-flood-hazard-determination").prop('disabled', true);

	// Exception cases
	$(".alwaysActive").prop('disabled', false);
}

function setVerificationMode() {
	$("input, select").prop('disabled', false);
	$("#btnStartVerificationCollateralDetails").hide();
	//$("#btnStartVerificationFloodDetermination").hide();
	$("#verifyCancelCollateralDetails").show();
	//$("#verifyCancelFloodDetermination").show();
	$("#editCollateralDetails").hide();
	//$("#editFloodDetermination").hide();
	$(".deleteColumnCollateralDetails").show();
	$(".deleteColumnMortgageDocument").show();
	$("#sfhdfContainer").show();
}

function registerEditCollateralDetailsEvent() {

	$(".collateral-details-edit-field").off("click").on("click", function(event) {
		var collateralRid = $("#collateralID").val();
		var cid= $("meta[name='_cid']").attr("content");

		$.ajax({
	        url: CTRAC.context+'editCollateralDetails?_cid='+cid+'&collateralRid='+collateralRid,
	        cache: false,
	        data: $('form#collateralSectionForm').serialize(),
	        success: function(data) {
	            $('#ctracModal').html(data);
	            dataChanged=false;
	            if(CTRAC.readOnlyUserRole  )
	       	 	{
	            	 $("#ctracModal input, #ctracModal select, #ctracModal a").attr('disabled','disabled');
	         		 $("#btnCollateralDetailsClose").removeAttr('disabled');
	       	 	}
			  $("#ctracModal").modal('toggle');
	        },
	        error: function(xhr, ajaxOptions, thrownError) {
	   			alert(xhr.status + " thrownError: " + thrownError);
	   		}
	    });
		event.preventDefault();
		event.stopPropagation();
	});
}

function registerEditCollateralOwnerEvent() {
	$(".editCollateralOwner").off("click").on("click", function() {
		var rid = $(this).attr("data-ownerId");
		var cid= $("meta[name='_cid']").attr("content");
		$.ajax({
        url: CTRAC.context+'editCollateralOwner?ownerRid='+rid + '&_cid='+cid,
        cache: false,
        data: $('form#collateralSectionForm').serialize(),
        success: function(data) {
            $('#ctracModal').html(data);
            if(CTRAC.readOnlyUserRole)
       	 {
            	$("#ctracModal input, #ctracModal select, #ctracModal a").attr('disabled','disabled');
    		   	$("#btnCollateralOwnerClose").removeAttr('disabled');
       	 	}
            $('#collateralOwnerModalTitle').text("Edit Collateral Owner");
            $("#ctracModal").modal('toggle');
        },
        error: function(xhr, ajaxOptions, thrownError) {
   			alert(xhr.status + " thrownError: " + thrownError);
   		}
    });
});
}

function registerAddCollateralOwnerEvent() {
	$("#btnCollateralOwnerAddRow").off("click").on("click", function() {
		var rid = 0;
		var cid= $("meta[name='_cid']").attr("content");

		$.ajax({
	        url: CTRAC.context+'searchCustomer?_cid='+cid,
	        cache: false,
	        data: $('form#collateralSectionForm').serialize(),
	        success: function(data) {
	        	//alert(data);
	            $('#ctracModal').html(data);
	            $('#collateralOwnerModalTitle').text("Add Collateral Owner");
	        	$("#btnCollateralOwnerDelete").hide();//("disabled", true);
	            $("#ctracModal").modal('toggle');
	        },
	        error: function(xhr, ajaxOptions, thrownError) {
	   			alert(xhr.status + " thrownError: " + thrownError);
	   		}
	    });
});

	//Reset the content of the new customer Modal modal
	$('#newCustomerModel').on('hidden.bs.modal', function (event) {
		$('#newCustomerModel').html("");
	});

}

function registerDeleteCollateralOwnerEvent() {
	$(".collateralOwnerDelete").on("click", function(){

		$("#saveStatus").text("");
		$("#saveStatus").hide();

		var rowNumber = $(this).closest("tr").attr("name");

		// no need to make Ajax call. It is not in DB yet.
		if (rowNumber != "newlyAddedCollatertalOwner") {
			deleteMortagagor(rowNumber, null);
		}

		$(this).closest("tr").remove();

		// reset alternate row color
		$("#collateralOwners-list-data").each(function (index){
			if (index % 2 == 0) {
				$(this).removeClass("oddRow");
				$(this).addClass("evenRow");
			} else {
				$(this).removeClass("evenRow");
				$(this).addClass("oddRow");
			}
		});


		// rearrange IDs
		// Arun: TODO: Rename these to collateralOwner... to avoid conflict with other sections
		$("[id^=borrowerName_]").each(function (index){
			$(this).attr("id", "borrowerName_" + index);
			$(this).prop("name", "collateralDto.ownerData[" + index + "].borrowerName");
		});

		$("[id^=streetAddress_]").each(function (index){
			$(this).attr("id", "streetAddress_" + index);
			$(this).prop("name", "collateralDto.ownerData[" + index + "].contactDetailDto.address.streetAddress");
		});

		$("[id^=city_]").each(function (index){
			$(this).attr("id", "city_" + index);
			$(this).prop("name", "collateralDto.ownerData[" + index + "].contactDetailDto.address.city");
		});

		$("[id^=state_]").each(function (index){
			$(this).attr("id", "state_" + index);
			$(this).prop("name", "collateralDto.ownerData[" + index + "].contactDetailDto.address.state");
		});

		$("[id^=zipCode_]").each(function (index){
			$(this).attr("id", "zipCode_" + index);
			$(this).prop("name", "collateralDto.ownerData[" + index + "].contactDetailDto.address.zipCode");
		});

		//$("[id^=borrowerName_]").each(function (index){
		//	alert($(this).attr("name") + " - " + $(this).prop("name"));
		//});

		event.preventDefault();
		event.stopPropagation();
	});
}

COLLATERAL_DETAILS.getSectionStatusApi = function() {
return CTRAC.root + "api/admin/sectionStatuses/" + CTRAC.collateralRID;
};

COLLATERAL_DETAILS.allowVerification = function() {
    $.post({
        url: COLLATERAL_DETAILS.getSectionStatusApi() + "/allowVerification",
        success: function() { location.reload(); }
    });
};
function setcollapse() {
    // Add minus icon for collapse element which is open by default
    $(".collapse.in").each(function(){
        $(this).siblings(".panel-heading").find(".glyphicon").addClass("glyphicon-minus").removeClass("glyphicon-plus");
    });
    // Toggle plus minus icon on show hide of collapse element
    $(".collapse").on('show.bs.collapse', function () {
        $(this).parent().find(".glyphicon").removeClass("glyphicon-plus").addClass("glyphicon-minus");
    }).on('hide.bs.collapse', function () {
        $(this).parent().find(".glyphicon").removeClass("glyphicon-minus").addClass("glyphicon-plus");
    });
}

COLLATERAL_DETAILS.initializeCollateralDetailsSection = function() {
	setReadonlyMode();
    setcollapse();
    var allowVerificationButton = $("#allow-verification-button");
	if (allowVerificationButton.length) {
        $.get(COLLATERAL_DETAILS.getSectionStatusApi(), function(data) {
            var show = false;
            $(data).each(function(index, element) {
                if (element["statusId"] === "PENDING_VERIFICATION") {
                    show = true;
                }
            });
            if (show) {
                allowVerificationButton.css("display", "inline-block");
                allowVerificationButton.show();
            }
        });
    }

	registerEditCollateralDetailsEvent();
	registerAddCollateralOwnerEvent();
	registerEditCollateralOwnerEvent();
	registerDeleteCollateralOwnerEvent();

	$("#btnEditCollateralDetails").off("click").on("click", function(event){
		$("#saveStatus").text("");
		$("#saveStatus").hide();
		event.preventDefault();
		event.stopPropagation();
	});

	// Start: Collateral Details Section Verification
	// Initial button status
	if ($("#collateralDetailsSectionVerificationStarted").prop("checked")) {
			$("#btnStartVerificationCollateralDetailsSection").hide();
			$("#btnCompleteVerificationCollateralDetailsSection").show();
			$("#btnCancelVerificationCollateralDetailsSection").show();
	} else {
			$("#btnStartVerificationCollateralDetailsSection").show();
			$("#btnCompleteVerificationCollateralDetailsSection").hide();
			$("#btnCancelVerificationCollateralDetailsSection").hide();
	}

	$("#btnStartVerificationCollateralDetailsSection").off("click").on("click",
			function(event) {
				$("#saveStatus").text("");
				$("#saveStatus").hide();
				event.preventDefault();
				event.stopPropagation();
				setVerificationModeForCollateralDetailsSection(true);
			});

	$("#btnCancelVerificationCollateralDetailsSection").off("click").on("click",
			function(event) {
				if (confirm("Are you sure you want to cancel your verification?")) {
					setVerificationModeForCollateralDetailsSection(false);
				}
			});

	$("#btnCompleteVerificationCollateralDetailsSection").off("click").on("click",
			function(event) {
				var cid = $("meta[name='_cid']").attr("content");
                var csrf=$("meta[name='_csrf']").attr("content");
				$.ajax({
					type : "POST",
					url : CTRAC.context+'verifyCollateralSectionInfo?_cid=' + cid+'&_csrf='+csrf,
					data : $('form#collateralSectionForm').serialize(),
					success : function(response) {
						//COLLSCREENAjaxError.reloadThecollateralScreen(null);
						if (response.indexOf("ACCESS DENIED") > -1) {
							alert("CTRAC - Access Denied.");
						}

						// Reload Collateral Details Section
			        	$("#collateralDetailsSection").replaceWith('<div  id="collateralDetailSection">' + response + '</div>');
					},
					error : function(xhr, ajaxOptions, thrownError) {
						COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
					}
		});
	});
	// End: Collateral Details Section Verification


	$("#btnCancelCollateralDetails, #btnVerifyCancelCollateralDetails").off("click").on("click", function(event){
		var resp = confirm("Are you sure you want to cancel the changes you made in this section?");

		if (resp == true) {
			//window.location='/ctrac/admin/collateralDetails?collateralID=' + $("#collateralID").val();
			cancelCollateralSectionInfo();
		}


		event.preventDefault();
		event.stopPropagation();

	});

	$("#btnCollateralDetailCancel").off("click").on("click", function (){
		if(CTRAC.tmParams != null)
			unlockTask();
		else
			closeHelperPopup();
	});

	//TODO handle red x close
	//$(window).on('unload', closeCallBack);

	$("#btnCollateralDrafVerify").off("click").on("click", function() {
	  CTRAC.isBrowserClose = false;
        $("#btnCollateralDrafVerify").attr("disabled", true);
	  var cid= $("meta[name='_cid']").attr("content");
	   var collateralID = $("#collateralID").val();
	   $.ajax({
	        type: "GET",
	        url: CTRAC.context+'changeCollateralDraftToVerify?_cid='+cid,
	        data: $('form#collateralSectionForm').serialize(),
	        success: function(response){
		       	if (response.indexOf("ACCESS DENIED") > -1) {
	        		alert("CTRAC - Access Denied.");
		        } else {
		        	$('#container').replaceWith($($.parseHTML(response)).filter('#container'));
		        	CTRAC.initializeCollateralScreen();
		        	window.scrollTo(0,0);
		        }
	        },
	   		error: function(xhr, ajaxOptions, thrownError) {
	   			alert(xhr.status + " thrownError: " + thrownError);
	   		}
	    });
	});

	$("#btnCollateralDetailReview").off("click").on("click",function(event) {
				CTRAC.isBrowserClose = false;
				var cid = $("meta[name='_cid']").attr("content");
				if ($("#marketEmail").find("span").text() === "") { 
					$("#ctlErrorContainer").show();
					event.preventDefault();
					event.stopPropagation();
				} else {
					$("#ctlErrorContainer").hide();
					$.ajax({
						type : "POST",
						url : CTRAC.context + 'completeCollateralReview?_cid='+ cid,
						data : $('form#collateralSectionForm').serialize(),
						success : function(response) {
							if (response.indexOf("ACCESS DENIED") > -1) {
								alert("CTRAC - Access Denied.");
							} else {
								$('#container').replaceWith($($.parseHTML(response)).filter('#container'));
								CTRAC.initializeCollateralScreen();
								window.scrollTo(0, 0);
							}
						},
						error : function(xhr, ajaxOptions, thrownError) {
							COLLSCREENAjaxError.ajaxErrorProcessing(thrownError);
						}
					});
				}

			});
};
