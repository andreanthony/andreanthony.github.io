package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.SectionStatusDto;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestSectionStatusController {

    private static final Long COLLATERAL_ID = 1L;
    public static final String EXPECTED_EXCEPTION = "Expected Exception";

    @Mock private CollateralDetailsStatusService collateralDetailsStatusService;

    @InjectMocks
    private SectionStatusController testObj;

    private MockMvc mockMvc;
    private List<SectionStatusDto> sectionStatusDtos;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
        sectionStatusDtos = new ArrayList<>();
        SectionStatusDto sectionStatusDto = new SectionStatusDto();
        sectionStatusDto.setCollateralRid(COLLATERAL_ID);
        sectionStatusDtos.add(sectionStatusDto);
    }

    @Test
    public void testGetSectionStatuses() throws Exception {
        when(collateralDetailsStatusService.getSectionStatuses(COLLATERAL_ID)).thenReturn(sectionStatusDtos);

        mockMvc.perform(get("/api/admin/sectionStatuses/" + COLLATERAL_ID)
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$[0].collateralRid").value(COLLATERAL_ID))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetSectionStatusesFailure() throws Exception {
        doThrow(new CtracAjaxException(EXPECTED_EXCEPTION)).when(collateralDetailsStatusService).getSectionStatuses(COLLATERAL_ID);

        mockMvc.perform(get("/api/admin/sectionStatuses/" + COLLATERAL_ID)
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(status().is4xxClientError());
    }

    @Test
    public void testAllowVerification() {
        when(collateralDetailsStatusService.getSectionStatuses(COLLATERAL_ID)).thenReturn(sectionStatusDtos);

        postAndVerify("/api/admin/sectionStatuses/" + COLLATERAL_ID + "/allowVerification");

        verify(collateralDetailsStatusService).allowAnyVerification(COLLATERAL_ID);
    }

    @Test
    public void testAllowVerificationFailure() {
        doThrow(new CtracAjaxException(EXPECTED_EXCEPTION)).when(collateralDetailsStatusService).allowAnyVerification(COLLATERAL_ID);

        postWithException("/api/admin/sectionStatuses/" + COLLATERAL_ID + "/allowVerification");
    }

    private void postAndVerify(String url) {
        try {
            mockMvc.perform(post(url).contentType(APPLICATION_JSON_UTF8))
                    .andExpect(jsonPath("$[0].collateralRid").value(COLLATERAL_ID))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail();
        }
    }

    private void postWithException(String url) {
        try {
            mockMvc.perform(post(url)
                    .contentType(APPLICATION_JSON_UTF8))
                    .andExpect(status().is4xxClientError());
        } catch (Exception e) {
            fail();
        }
    }
}
