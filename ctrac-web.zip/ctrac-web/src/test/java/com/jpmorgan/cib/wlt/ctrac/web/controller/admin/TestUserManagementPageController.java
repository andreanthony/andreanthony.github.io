package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.NoUserFoundException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupMembers;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Groups;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.ManageUserEntitlementRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements.GroupIdentifier;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.mapper.CtracObjectMapper;
import com.jpmorgan.cib.wlt.ctrac.service.validator.UserEntitlementManagementValidator;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by V704662 on 8/21/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestUserManagementPageController {

    @InjectMocks private UserManagementPageController controller;
    @Mock private CtracObjectMapper ctracObjectMapper;
    @Mock private UserEntitlementManagementValidator userEntitlementManagementValidator;
    @Mock private UserEntitlementService userEntitlementService;
    private ModelMap modelMap;
    private HttpServletRequest servletRequest;
    private List<GroupIdentifier> availableGroups = new ArrayList<>();
    protected MockMvc mockMvc;
    private static final String CONST_SID = "SID123";
    private static final String CONST_FIRST_NAME = "testFirst1";
    private static final String CONST_LAST_NAME = "testLast1";
    private static final String CONST_USER_GROUP_ID1 = "233";
    private static final String CONST_USER_GROUP_ID2 = "234";

    @Before
    public void setup(){
        modelMap = new ModelMap();
        servletRequest = mock(HttpServletRequest.class);
        HttpSession session = mock(HttpSession.class);
        given(servletRequest.getSession()).willReturn(session);
        given(session.getAttribute(UserManagementPageController.CONST_SESSION_AVAILABLE_ROLES_LIST)).willReturn(availableGroups);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }


    /**
     * - loadManageUserEntitlementsPage
     * TestCase: verify that for a request to controller to load entitlement manage page the expected view will be returned
     */
    @Test
    public void testLoadManageUserEntitlementsPageSuccess(){
        given(userEntitlementService.getAllAvailableUserGroups()).willReturn(availableGroups);
        assertThat(controller.loadManageUserEntitlementsPage(servletRequest),is("/admin/entitlements/userSearch"));
    }

    /**
     * - searchUser
     * TestCase: Search for a user given an SID and that user was not found -
     * Subview is returned with model attribute the manage request instance with empty values
     */
    @Test
    public void testSearchUserNotFound() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user not found testcase we are mocking an NoUserFoundException
        doThrow(new NoUserFoundException("errorCode", CtracErrorSeverity.TRIVIAL))
                .when(userEntitlementManagementValidator).validateSearchUserValidate(
                argument.capture());

        String page = controller.searchUser(CONST_SID,modelMap,servletRequest);
        assertThat(page,is("/admin/entitlements/userMaintenance :: userMaintenance"));
        //Verify that the SID was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        //Verify that model attribute has been set with empty values
        assertThat(((ManageUserEntitlementRequest)modelMap.get("userEntitlementRequest")).getSid(),is(CONST_SID));
        assertTrue(StringUtils.isEmpty(((ManageUserEntitlementRequest)modelMap.get("userEntitlementRequest")).getFirstName()));
        assertTrue(StringUtils.isEmpty(((ManageUserEntitlementRequest)modelMap.get("userEntitlementRequest")).getLastName()));
        assertTrue(CollectionUtils.isEmpty(((ManageUserEntitlementRequest)modelMap.get("userEntitlementRequest")).getGroups()));
    }

    /**
     * - searchUser
     * TestCase: Search for a user given an SID and an exception occurred in service -
     * Exception handling will be performed and appropriate exception is thrown
     */
    @Test(expected = CTracWebAppException.class)
    public void testSearchUserExceptionHandling() throws Exception {
        //For user not found testcase we are mocking an NoUserFoundException
        doThrow(new RuntimeException("errorCode"))
                .when(userEntitlementManagementValidator).validateSearchUserValidate(
                any(ManageUserEntitlementRequest.class));
        controller.searchUser(CONST_SID,modelMap,servletRequest);
    }

    /**
     * - searchUser
     * TestCase: Search for a user given an SID and that user was found -
     * Subview is returned with model attribute the manage request instance with user populated values
     */
    @Test
    public void testSearchUserFound() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user found we are mocking the validator to not throw an exception
        doNothing().when(userEntitlementManagementValidator).validateSearchUserValidate(
                argument.capture());
        String page = controller.searchUser(CONST_SID,modelMap,servletRequest);
        assertThat(page,is("/admin/entitlements/userMaintenance :: userMaintenance"));
        //Verify that the SID was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        //Verify that results of user are available in the model
        assertThat(((ManageUserEntitlementRequest)modelMap.get("userEntitlementRequest")).getSid(),is(CONST_SID));
    }
}
