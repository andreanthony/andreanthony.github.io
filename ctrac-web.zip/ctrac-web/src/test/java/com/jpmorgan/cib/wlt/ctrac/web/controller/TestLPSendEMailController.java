package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EmailTemplateRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralWorkflowService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.LoanManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.helper.CtracEmailSender;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;

@RunWith(MockitoJUnitRunner.class)
public class TestLPSendEMailController extends AbstractTestFloodRemapController{
	@Mock private CollateralDetailsService collateralDetailsService;
	@Mock private LoanManagementService loanManagementService;
	@Mock private CollateralWorkflowService collateralWorkflowService;
	@Mock private CollateralManagementService collateralManagementService;
	@Mock private CollateralDetailsStatusService collateralStatusService;
	@Mock private CollateralDocumentService collateralDocumentService;
	@Mock private LenderPlaceService lenderPlaceService;
	@Mock private PerfectionTaskRepository perfectionTaskRepository;
	@Mock private EmailTemplateRepository emailTemplateRepository;
	@Mock private CtracEmailSender ctracEmailSender;
	
	@InjectMocks private LPSendEMailController lPSendEMailController;
	
	@Before
	public void setUp(){
		Mockito.reset(collateralDetailsService);
		Mockito.reset(loanManagementService);
		Mockito.reset(collateralWorkflowService);
		Mockito.reset(collateralManagementService);
		Mockito.reset(collateralStatusService);
		Mockito.reset(collateralDocumentService);
		Mockito.reset(lenderPlaceService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				lPSendEMailController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
	}
	
	@Test
	public void testSendLPPremiumEMail() throws Exception{
		doNothing().when(lenderPlaceService).processLpPremiumPaidLOBEmail();
		mockMvc.perform(get("/admin/sendLPPremiumEMail"))
		.andExpect(status().isOk())
		.andExpect(view().name("admin/sendLPPremiumEMailStatus"));
	}

}
