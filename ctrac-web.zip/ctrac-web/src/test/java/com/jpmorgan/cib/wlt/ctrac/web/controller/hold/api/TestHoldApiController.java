package com.jpmorgan.cib.wlt.ctrac.web.controller.hold.api;

import com.jpmorgan.cib.wlt.ctrac.service.dto.view.HoldHistoryViewDto;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.HoldService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doThrow;

@RunWith(MockitoJUnitRunner.class)
public class TestHoldApiController {

    @InjectMocks private HoldApiController holdApiController;
    @Mock private HoldService holdService;

    @Before
    public void setup(){
        //Setup for collateral 1 there will be a list of hold returned
        List<HoldHistoryViewDto> holdHistoryList = new ArrayList<>();
        holdHistoryList.add(new HoldHistoryViewDto());
        given(holdService.getHoldHistory(1L)).willReturn(holdHistoryList);

        //Setup for collateral 2 there will be an exception thrown from service
        doThrow( new RuntimeException("this is an exception"))
                .when(holdService).getHoldHistory(2L);
    }


    /**
     * - getAllHolds
     * TestCase: for collateral 1 there is a hold history known and
     * will be returned in a list form with status code of 200
     */
    @Test
    public void testGetAllHolds_Success(){
        ResponseEntity responseEntity = holdApiController.getAllHolds(1L);
        assertNotNull(responseEntity);
        assertThat(responseEntity.getStatusCode(),is(HttpStatus.OK));
        assertThat(((List)responseEntity.getBody()).size(),is(1));
    }

    /**
     * - getAllHolds
     * TestCase: for collateral 2 there is a service failure so we expect to handle the exception
     * and return Internal server error
     */
    @Test
    public void testGetAllHolds_Failure(){
        ResponseEntity responseEntity = holdApiController.getAllHolds(2L);
        assertNotNull(responseEntity);
        assertThat(responseEntity.getStatusCode(),is(HttpStatus.INTERNAL_SERVER_ERROR));
        assertNull(responseEntity.getBody());
    }
}
