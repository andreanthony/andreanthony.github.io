
package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRCollateralDetailsDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;

import org.springframework.context.MessageSource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;

import com.jpmorgan.cib.wlt.ctrac.service.bir.BIRMode;
import com.jpmorgan.cib.wlt.ctrac.service.bir.BorrowerInsuranceReviewService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AgentResponseData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BIRRuleConclusionMap;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ReferenceValues;
import com.jpmorgan.cib.wlt.ctrac.web.controller.bir.BorrowerInsuranceReviewController;

import java.util.Locale;

import javax.servlet.http.HttpSession;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.hamcrest.Matchers.nullValue;

@RunWith(MockitoJUnitRunner.class)
public class TestBorrowerInsuranceReviewController extends AbstractTestFloodRemapController  {
	
	@InjectMocks
	protected BorrowerInsuranceReviewController borrowerInsuranceReviewController;
	
	@Mock
	BIRRuleConclusionMap bIRRuleConclusionMap;

	@Mock
	BorrowerInsuranceReviewService borrowerInsuranceReviewService;

    @Mock
    private MessageSource messageSource;

    @Mock
	BorrowerInsuranceReviewDTO borrowerInsuranceReviewData;
	@Mock
	AgentResponseData agentResponseData;
	@Mock
	ReferenceValues referenceValues;
	@Mock
	BindingResult errors;
	@Mock
	GenericProofOfCoverageDTO proofOfCoverageData;
	
	private HttpSession httpSession;
	
	@Before
	public void setUp() {
		Mockito.reset(borrowerInsuranceReviewService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				borrowerInsuranceReviewController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		messageSource = mock(MessageSource.class);
		ReflectionTestUtils.setField(borrowerInsuranceReviewController, "messageSource", messageSource);
		 httpSession = mock(HttpSession.class);
	}	

	@Test
	public void testLaunchLogPIAReview() throws Exception {
		TMParams tmParams = mockTmParams();
		 AgentResponseData  agentResponseData = new  AgentResponseData();
		agentResponseData.setProofOfCoverageRid(1L);
		agentResponseData.setCollateralRid(1L);
		doReturn(  agentResponseData ).when(borrowerInsuranceReviewService).getAgentResponse(any(TMParams.class));
		String launchBIR= "/bir/launchBIROverlay?policyRid="+agentResponseData.getProofOfCoverageRid()+"&"+ "collateralRid="+agentResponseData.getCollateralRid()+"&"+"mode=1";
		mockMvc.perform( get("/bir/launchLogPIAReview")
				.sessionAttr("tmParams", tmParams)
				.sessionAttr("borrowerInsuranceReviewData", borrowerInsuranceReviewData))
		        .andExpect(status().isOk())
                 .andExpect(forwardedUrl(launchBIR));
		}

	@Test
	public void reviewBorrowerInsurance() throws Exception {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = new BorrowerInsuranceReviewDTO();
		setMockDataOnBorrowerInsuranceReviewDTO(borrowerInsuranceReviewData);
		doNothing().when(borrowerInsuranceReviewService).reviewBorrowerInsurance(borrowerInsuranceReviewData, false);
		given(borrowerInsuranceReviewService.
				getBorrowerInsuranceReviewReferenceValues(borrowerInsuranceReviewData.getBirMode())).willReturn(referenceValues);

	   	mockMvc.perform(post("/bir/submitBorrowerInsuranceReview")
				.param("review", "review")
				.sessionAttr("referenceValues", referenceValues)
				.sessionAttr("borrowerInsuranceReviewData", borrowerInsuranceReviewData))
				.andExpect(status().isOk())
		        .andExpect(view().name("/bir/borrowerInsuranceReview"));
	}

	@Test
	public void submitBorrowerInsuranceReview() throws Exception {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = new BorrowerInsuranceReviewDTO();
		setMockDataOnBorrowerInsuranceReviewDTO(borrowerInsuranceReviewData );
		doNothing().when(borrowerInsuranceReviewService).submitBorrowerInsuranceReview(any(BorrowerInsuranceReviewDTO.class));

	   	mockMvc.perform(post("/bir/submitBorrowerInsuranceReview")
				.param("save", "save")
				.sessionAttr("referenceValues", referenceValues)
				.sessionAttr("borrowerInsuranceReviewData", borrowerInsuranceReviewData))
				.andExpect(status().isOk())
		        .andExpect(view().name("/bir/borrowerInsuranceReview"));
	}

	@Test
	public void deleteBorrowerInsuranceReview() throws Exception {
		String url ="/admin/collateralDetails?collateralID="+borrowerInsuranceReviewData.getCollateralRid();
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = new BorrowerInsuranceReviewDTO();
		borrowerInsuranceReviewData.setCollateralRid(0L);
		borrowerInsuranceReviewData.setBirMode(BIRMode.EDIT);
		proofOfCoverageData = new GenericProofOfCoverageDTO();
		proofOfCoverageData.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
		proofOfCoverageData.setRid(0L);
		borrowerInsuranceReviewData.setProofOfCoverageData(proofOfCoverageData);
		given(borrowerInsuranceReviewService.validateBorrowerInsurancePolicyDeletion(0L,0L,true)).willReturn(true);
		mockMvc.perform(post("/bir/deleteBorrowerInsuranceReview")
				.sessionAttr("borrowerInsuranceReviewData", borrowerInsuranceReviewData))
				.andExpect(redirectedUrl(url));
	}

	@Test
	public void removeCollateralFromBIR() throws Exception {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = new BorrowerInsuranceReviewDTO();
		borrowerInsuranceReviewData.setCollateralRid(0L);
		borrowerInsuranceReviewData.setProofOfCoverageData(proofOfCoverageData);
		doNothing().when(borrowerInsuranceReviewService).removeCollateralFromBIR(any(Long.class),any(BorrowerInsuranceReviewDTO.class));
    	mockMvc.perform(post("/bir/removeCollateralFromBIR")
    			.param("collateralId", "1")
				.sessionAttr("borrowerInsuranceReviewData", borrowerInsuranceReviewData))
				.andExpect(view().name("/bir/borrowerInsuranceReview"))
				.andExpect(status().isOk())	;
	}

	@Test
	public void addCollateralToBIR() throws Exception {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = new BorrowerInsuranceReviewDTO();
		borrowerInsuranceReviewData.setCollateralRid(0L);
		borrowerInsuranceReviewData.setProofOfCoverageData(proofOfCoverageData);
		doNothing().when(borrowerInsuranceReviewService).addCollateralToBIR(any(Long.class),any(BorrowerInsuranceReviewDTO.class));
    	mockMvc.perform(post("/bir/addCollateralToBIR")
    			.param("collateralId", "1")
				.sessionAttr("borrowerInsuranceReviewData", borrowerInsuranceReviewData))
    	        .andExpect(view().name("/bir/borrowerInsuranceReview"))
				.andExpect(status().isOk())	;
    	}




	/**
	 * - launchBIRModal
	 * TestCase: Verify that when BIR Model is launched in BIRMode Replace -
	 * the expected calls are being made to the service to prepare a new BIR DTO Form and values are set in the Model And View
	 */
	@Test
	public void testLaunchBIRModalWhenReplaceBIRMode(){
		Long testPolicyRid = 1L;
		Long testCollateralRid = 2L;

		//Expected DTO
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewDTO = new BorrowerInsuranceReviewDTO();
		borrowerInsuranceReviewDTO.setCollateralRid(testCollateralRid);
		borrowerInsuranceReviewDTO.setBirMode(BIRMode.EDIT);
		proofOfCoverageData = new GenericProofOfCoverageDTO();
		proofOfCoverageData.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
		proofOfCoverageData.setRid(testPolicyRid);
		borrowerInsuranceReviewDTO.setProofOfCoverageData(proofOfCoverageData);
		given(borrowerInsuranceReviewService.prepareBIRByBIRMode(testPolicyRid, testCollateralRid, BIRMode.REPLACE))
				.willReturn(borrowerInsuranceReviewDTO);
		//Expected Reference values
		ReferenceValues referenceValues = new ReferenceValues();
		given(borrowerInsuranceReviewService.getBorrowerInsuranceReviewReferenceValues(BIRMode.REPLACE)).willReturn(referenceValues);

		//Method to test
		
		ModelAndView modelAndView = borrowerInsuranceReviewController.launchBIRModal(testPolicyRid,testCollateralRid, BIRMode.REPLACE.mode,httpSession);

		//Verify that the service was called to prepare an instance BorrowerInsuranceReviewDTO with expected params
		verify(borrowerInsuranceReviewService,times(1))
				.prepareBIRByBIRMode(testPolicyRid, testCollateralRid, BIRMode.REPLACE);


		BorrowerInsuranceReviewDTO dtoInModel = (BorrowerInsuranceReviewDTO) modelAndView.getModel().get("borrowerInsuranceReviewData");
		ReferenceValues referenceValuesInModel = (ReferenceValues) modelAndView.getModel().get("referenceValues");
		assertThat(dtoInModel,is(borrowerInsuranceReviewDTO));
		assertThat(dtoInModel.getBirMode(),is(BIRMode.REPLACE));
		assertThat(dtoInModel.getCollateralRid(),is(testCollateralRid));
		assertThat(referenceValuesInModel,is(referenceValues));

	}

	/**
	 * - launchBIRModal
	 * TestCase: Verify that when BIR Model is launched in BIRMode Renew -
	 * the expected calls are being made to the service to prepare a new BIR DTO Form and values are set in the Model And View
	 */
	@Test
	public void testLaunchBIRModalWhenRenewBIRMode(){
		Long testPolicyRid = 1L;
		Long testCollateralRid = 2L;

		
		//Expected DTO
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewDTO = new BorrowerInsuranceReviewDTO();
		borrowerInsuranceReviewDTO.setCollateralRid(testCollateralRid);
		borrowerInsuranceReviewDTO.setBirMode(BIRMode.EDIT);
		proofOfCoverageData = new GenericProofOfCoverageDTO();
		proofOfCoverageData.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
		proofOfCoverageData.setRid(testPolicyRid);
		borrowerInsuranceReviewDTO.setProofOfCoverageData(proofOfCoverageData);
		given(borrowerInsuranceReviewService.prepareBIRByBIRMode(testPolicyRid, testCollateralRid, BIRMode.RENEWAL))
				.willReturn(borrowerInsuranceReviewDTO);
		//Expected Reference values
		ReferenceValues referenceValues = new ReferenceValues();
		LoanData loanData = new LoanData();
		loanData.setRid(1L);
		loanData.setPrimaryFlag("Yes");
		loanData.setLoanType("FNMA");
		given(borrowerInsuranceReviewService.getBorrowerInsuranceReviewReferenceValues(BIRMode.RENEWAL)).willReturn(referenceValues);
		given(borrowerInsuranceReviewService.getPrimaryLoanOfBorrowerInsurance(testCollateralRid)).willReturn(loanData);
		given(messageSource.getMessage("primaryLoanTypeAsFNMA.borrowInsurance.Mortgage.Payee.label",null,"", Locale.getDefault()))
				.willReturn("Fannie Mae ISAOA/ATIMA C/O JPM Listed as Mortgagee Payee");

		//Method to test
		ModelAndView modelAndView = borrowerInsuranceReviewController.launchBIRModal(testPolicyRid,testCollateralRid, BIRMode.RENEWAL.mode,httpSession);

		//Verify that the service was called to prepare an instance BorrowerInsuranceReviewDTO with expected params
		verify(borrowerInsuranceReviewService,times(1))
				.prepareBIRByBIRMode(testPolicyRid, testCollateralRid, BIRMode.RENEWAL);


		BorrowerInsuranceReviewDTO dtoInModel = (BorrowerInsuranceReviewDTO) modelAndView.getModel().get("borrowerInsuranceReviewData");
		ReferenceValues referenceValuesInModel = (ReferenceValues) modelAndView.getModel().get("referenceValues");
		assertThat(dtoInModel,is(borrowerInsuranceReviewDTO));
		assertThat(dtoInModel.getBirMode(),is(BIRMode.RENEWAL));
		assertThat(dtoInModel.getCollateralRid(),is(testCollateralRid));
		assertThat(referenceValuesInModel,is(referenceValues));
		assertEquals("Fannie Mae "
				+ "ISAOA/ATIMA C/O JPM Listed as Mortgagee Payee",modelAndView.getModel()
				.get("borrowInsuranceMortgagePayeeLabel"));
		assertEquals(false, modelAndView.getModel().get("deleteBorrowerInsurancePolicyValidation"));

	}

	
	

	private TMParams mockTmParams(){
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("O641754");
		return tmParams;
	}
	
	/**
	 * Test method for {@link com.jpmorgan.cib.wlt.ctrac.web.controller.bir.BorrowerInsuranceReviewController#reviewBorrowerInsurance(com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO, org.springframework.validation.BindingResult, com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ReferenceValues)}.
	 */
	@Test
	public void testReviewBorrowerInsuranceSignedByAgentReset() throws Exception {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewDTO = new BorrowerInsuranceReviewDTO();
		borrowerInsuranceReviewDTO.setProofOfCoverageData(proofOfCoverageData);
		borrowerInsuranceReviewDTO.setEoiType("AWP");
		borrowerInsuranceReviewDTO.setSignedByAgent("Yes");
		setMockDataOnBorrowerInsuranceReviewDTO(borrowerInsuranceReviewDTO);
		borrowerInsuranceReviewController.reviewBorrowerInsurance(borrowerInsuranceReviewDTO, errors, referenceValues);
		assertThat(borrowerInsuranceReviewDTO.getSignedByAgent(), is("Yes"));
		
		borrowerInsuranceReviewDTO.setEoiType("PPTCRA");
		borrowerInsuranceReviewDTO.setSignedByAgent("Yes");
		borrowerInsuranceReviewController.reviewBorrowerInsurance(borrowerInsuranceReviewDTO, errors, referenceValues);
		assertThat(borrowerInsuranceReviewDTO.getSignedByAgent(), is(nullValue()));	
	}
	
	/**
	 * Test method for {@link com.jpmorgan.cib.wlt.ctrac.web.controller.bir.BorrowerInsuranceReviewController#submitBorrowerInsuranceReview(com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO, org.springframework.validation.BindingResult, com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ReferenceValues)}.
	 */
	@Test
	public void testSubmitBorrowerInsuranceReviewSignedByAgentReset() throws Exception {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewDTO = new BorrowerInsuranceReviewDTO();
		borrowerInsuranceReviewDTO.setProofOfCoverageData(proofOfCoverageData);
		borrowerInsuranceReviewDTO.setEoiType("AWP");
		borrowerInsuranceReviewDTO.setSignedByAgent("Yes");
		setMockDataOnBorrowerInsuranceReviewDTO(borrowerInsuranceReviewDTO);
		borrowerInsuranceReviewController.submitBorrowerInsuranceReview(borrowerInsuranceReviewDTO, errors, referenceValues);
		assertThat(borrowerInsuranceReviewDTO.getSignedByAgent(), is("Yes"));
		
		borrowerInsuranceReviewDTO.setEoiType("PPTCRA");
		borrowerInsuranceReviewDTO.setSignedByAgent("Yes");
		borrowerInsuranceReviewController.submitBorrowerInsuranceReview(borrowerInsuranceReviewDTO, errors, referenceValues);
		assertThat(borrowerInsuranceReviewDTO.getSignedByAgent(), is(nullValue()));	
	}


	/**
	 * - reviewBorrowerInsurance
	 * TestCase: When review BIR has been triggered , verify that the reference values used on the form for BIR are reloaded from DB
	 * cause the BIR is opened in separate window and need also to make sure it has all BIR Reference values
	 * in it that is not getting loaded on other screens in application
	 */
	@Test
	public void testReviewBorrowerInsuranceReloadReferenceValues() throws Exception {
		ReferenceValues newCopyFromDb = new ReferenceValues();
		given(borrowerInsuranceReviewService.getBorrowerInsuranceReviewReferenceValues(BIRMode.VERIFY)).willReturn(newCopyFromDb);

		BorrowerInsuranceReviewDTO borrowerInsuranceReviewDTO = new BorrowerInsuranceReviewDTO();
		setMockDataOnBorrowerInsuranceReviewDTO(borrowerInsuranceReviewDTO);
		borrowerInsuranceReviewDTO.setBirMode(BIRMode.VERIFY);
		ModelAndView response = borrowerInsuranceReviewController.reviewBorrowerInsurance(borrowerInsuranceReviewDTO, errors, referenceValues);
		verify(borrowerInsuranceReviewService).getBorrowerInsuranceReviewReferenceValues(BIRMode.VERIFY);
		assertThat((ReferenceValues)response.getModel().get("referenceValues"),is(newCopyFromDb));
	}

	private void setMockDataOnBorrowerInsuranceReviewDTO(BorrowerInsuranceReviewDTO borrowerInsuranceReviewDTO)
	{
		borrowerInsuranceReviewDTO.setCollateralRid(2L);
		borrowerInsuranceReviewDTO.setBirMode(BIRMode.EDIT);
		proofOfCoverageData = new GenericProofOfCoverageDTO();
		proofOfCoverageData.setPolicyStatus(PolicyStatus.PENDING_VERIFICATION);
		proofOfCoverageData.setRid(1L);
		borrowerInsuranceReviewDTO.setProofOfCoverageData(proofOfCoverageData);
		LoanData loanData = new LoanData();
		loanData.setRid(1L);
		loanData.setPrimaryFlag("Yes");
		loanData.setLoanType("FNMA");
		given(borrowerInsuranceReviewService.validateBorrowerInsurancePolicyDeletion(1L,2L, true)).willReturn(false);
	}
	@Test
	public void testOverrideAdmin() throws Exception {
		BorrowerInsuranceReviewDTO borrowerInsuranceReviewData = new BorrowerInsuranceReviewDTO();
		BIRCollateralDetailsDTO birCollateralDetailsDTO =  new BIRCollateralDetailsDTO();
		borrowerInsuranceReviewData.setProofOfCoverageData(proofOfCoverageData);
		borrowerInsuranceReviewData.setCollateralRid(1L);
		borrowerInsuranceReviewData.getCollateralDetailsMap().put(borrowerInsuranceReviewData.getCollateralRid(), birCollateralDetailsDTO);
		mockMvc.perform(post("/bir/overrideAdmin")
				.sessionAttr("borrowerInsuranceReviewData", borrowerInsuranceReviewData))
				.andExpect(view().name("/bir/borrowerInsuranceReview"))
				.andExpect(status().isOk());
		assertThat(borrowerInsuranceReviewData.isAdminOverride(),is(true));
	}
}



