package com.jpmorgan.cib.wlt.ctrac.audit;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@RunWith(MockitoJUnitRunner.class)
public class TestAuditPageController {

    @InjectMocks private AuditPageController controller;
    @Mock protected MockHttpSession session;
    private MockMvc mockMvc;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }


    /**
     * - loadAuditPage
     * TestCase: Verify that the Audit page controller will return the expected view back with a success response when feature is enabled
     * @throws Exception - Any Exception
     */
    @Test
    public void testLoadAuditPage() throws Exception {
        mockMvc.perform( get("/audit").session(session))
                .andExpect(status().isOk()).andExpect(view().name("/audit/index"));
    }

}
