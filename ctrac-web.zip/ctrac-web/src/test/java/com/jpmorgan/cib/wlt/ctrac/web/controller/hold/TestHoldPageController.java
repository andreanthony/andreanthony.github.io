package com.jpmorgan.cib.wlt.ctrac.web.controller.hold;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class TestHoldPageController {

    @InjectMocks private HoldPageController holdPageController;

    /**
     * - loadHoldHistoryPage
     * TestCase: Load of Holds history page will return the expected view name
     */
    @Test
    public void testLoadHistoryPage(){
        assertNotNull(holdPageController.loadHoldHistoryPage());
        assertThat(holdPageController.loadHoldHistoryPage().getViewName(),is("/hold/holdHistory"));
    }
}
