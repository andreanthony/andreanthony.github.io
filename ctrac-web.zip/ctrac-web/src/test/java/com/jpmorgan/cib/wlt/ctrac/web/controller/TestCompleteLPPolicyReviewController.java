package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.PolicyReviewData;

import javax.servlet.http.Cookie;


@RunWith(MockitoJUnitRunner.class)
public class TestCompleteLPPolicyReviewController extends AbstractTestFloodRemapController{

	@Rule
    public ExpectedException thrown= ExpectedException.none();
	
	@InjectMocks
	@Spy
	private CompleteLPPolicyReviewController completeLPPolicyReviewController;
	
	@Before
	public void setUp(){
		Mockito.reset(floodInsurancePolicyService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				completeLPPolicyReviewController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	@Test
	@Ignore
	public void testLaunchCompleteLPPolicyReviewHelper() throws Exception{
		mockStaticCreateTMHelperMethod(completeLPPolicyReviewController);
		PolicyReviewData policyData=getMockPolicyReviewData();
		doReturn(policyData).when(floodInsurancePolicyService).prepareCompleteLPPolicyReviewData(any(TMParams.class));
		mockMvc.perform( get("/floodRemap/launchCompleteLPPolicyReviewHelper").param("id_task", "1L").param("tmReturn", "testUrl").param("workflowStep", "testWorkflowStep").session(session))
		.andExpect(status().isOk()).andExpect(view().name("floodRemapCompleteLPPolicyReviewPage"))
		.andExpect(model().attribute("completeLPPolicyReviewData",policyData ) );		
		
	}
	
	@Test
	@Ignore
	public void testUnLockTMTask() throws Exception{
		mockStaticCreateTMHelperMethod(completeLPPolicyReviewController);
		PolicyReviewData policyData=getMockPolicyReviewData();
		mockMvc.perform(
				get("/floodRemap/completeLPPolicyReviewPage/unLockTMTask")
						.sessionAttr("completeLPPolicyReviewData", policyData))
				.andExpect(status().isOk())
				.andExpect(view().name("floodRemapCompleteLPPolicyReviewPage"));
	}
	
	@Test
	public void testSaveCompleteLPPolicyReview() throws Exception{
		PolicyReviewData policyData=getMockPolicyReviewData();
		String resultMessage="Lender Placed Policy Completed Successfully.";
		doNothing().when(floodInsurancePolicyService).processCompleteLPPolicyReview(any(PolicyReviewData.class));
		when(messageSource.getMessage("lenderplaced.policy.review.confirmation", null, null)).thenReturn(resultMessage);
		mockMvc.perform(post("/floodRemap/saveCompleteLPPolicyReview/{taskId}", 1L).param("save", "save").sessionAttr("completeLPPolicyReviewData", policyData).sessionAttr("JANUS_USER_ID", "testUUID")
				.cookie(new Cookie("cookie","test")))
		.andExpect(status().isOk())		
		.andExpect(view().name("floodRemapConfirmation"))
		.andExpect(model().attribute("confirmation", is(resultMessage)) );
	}
	
	private PolicyReviewData getMockPolicyReviewData(){
		PolicyReviewData policyData=new PolicyReviewData();
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("O641754");
		policyData.setTmParams(tmParams);
		return policyData;
	}
	
	
}
