package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.UserEntitlementAction;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.NoUserFoundException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Groups;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.service.dto.entitlements.ManageUserEntitlementRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements.GetAvailableGroupsResponse;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.entitlements.GroupIdentifier;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.validator.UserEntitlementManagementValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by V704662 on 8/21/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestUserManagementController {

    @InjectMocks private UserManagementController controller;
    protected MockMvc mockMvc;
    @Mock private UserEntitlementService userEntitlementService;
    @Mock private UserEntitlementManagementValidator userEntitlementManagementValidator;
    private static final String CONST_SID = "SID123";
    private static final String CONST_FIRST_NAME = "testFirst1";
    private static final String CONST_LAST_NAME = "testLast1";
    private static final String CONST_USER_GROUP_ID1 = "233";
    private static final String CONST_USER_GROUP_ID2 = "234";

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    /*Helper function to generate a Users instance with default values and default group*/
    private Users generateDefaultUserInstance(){
        Users user = new Users();
        user.setSid(CONST_SID);
        user.setFirstName(CONST_FIRST_NAME);
        user.setLastName(CONST_LAST_NAME);
        user.addGroups(generateGroupsInstance(CONST_USER_GROUP_ID1));
        user.addGroups(generateGroupsInstance(CONST_USER_GROUP_ID2));
        return user;
    }

    /*Helper function to generate a group instance*/
    private Groups generateGroupsInstance(String groupId){
        Groups group = new Groups();
        group.setId(Long.valueOf(groupId));
        group.setGroupName(groupId);
        return group;
    }

    /*Helper function to generate a new GroupIdentifier Instance for given values*/
    private GroupIdentifier generateGroupIdentifierInstance(Long groupId, String groupName){
        Groups groupObject =  new Groups();
        groupObject.setId(groupId);
        groupObject.setGroupName(groupName);
        return new GroupIdentifier(groupObject);
    }

    /**
     * - getAllAvailableUserGroups
     * TestCase: verify that for a request to controller to get all the available
     * groups for a user to have it will return a response with list of all of these
     */
    @Test
    public void testGetAllAvailableUserGroups(){
        //Mock the expected groups to be returned from the service
        List<GroupIdentifier> expectedGroups = new ArrayList<>();
        expectedGroups.add(generateGroupIdentifierInstance(1L,"group 1"));
        expectedGroups.add(generateGroupIdentifierInstance(2L,"group 2"));
        given(userEntitlementService.getAllAvailableUserGroups()).willReturn(expectedGroups);

        ResponseEntity<BaseApiResponse> response = controller.getAllAvailableUserGroups();
        assertTrue(response.getBody().isSuccess());
        assertTrue(((GetAvailableGroupsResponse)response.getBody()).getAvailableGroups().contains(expectedGroups.get(0)));
        assertTrue(((GetAvailableGroupsResponse)response.getBody()).getAvailableGroups().contains(expectedGroups.get(1)));
    }

    /**
     * - getAllAvailableUserGroups
     * TestCase: verify that for a request to controller to get all the available
     * groups for a user to have it will return a response with list of all of these
     */
    @Test
    public void testGetAllAvailableUserGroupsExceptionHandling(){
        //Mock an exception happened calling service
        doThrow(new RuntimeException("exception")).when(userEntitlementService).getAllAvailableUserGroups();

        ResponseEntity<BaseApiResponse> response = controller.getAllAvailableUserGroups();
        assertFalse(response.getBody().isSuccess());
        assertThat(response.getBody().getValidationErrors().get(0).getMessage(),is("exception"));
    }

    /**
     * - updateUser
     * TestCase: Update the entitlements for a given user where all validation is success
     * Success message is expected to be returned
     */
    @Test
    public void testUpdateUserSuccess() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user found we are mocking the validator to return a user record
        Users user = generateDefaultUserInstance();
        doReturn(user).when(userEntitlementManagementValidator).validateUserEntitlementRequest(
                argument.capture(),eq(UserEntitlementAction.UPDATE),any(BindingResult.class));

        mockMvc.perform(post("/admin/entitlements/user/"+CONST_SID+"/update")
                .param("sid", CONST_SID)
                .param("lastName", CONST_LAST_NAME + "updated")
                .param("firstName", CONST_FIRST_NAME + "updated")
                .param("groups", String.valueOf(4L))
                .param("groups", String.valueOf(5L)))
                .andExpect(jsonPath("$.success").value("true"))
                .andExpect(status().isOk());
        //Verify that the right request params was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        assertThat(argument.getValue().getFirstName(),is(CONST_FIRST_NAME + "updated"));
        assertThat(argument.getValue().getLastName(),is(CONST_LAST_NAME + "updated"));
        assertThat(argument.getValue().getGroups(),hasItem(4L));
        assertThat(argument.getValue().getGroups(),hasItem(5L));
        //verify that the service is being called to perform an update of the user record
        verify(userEntitlementService).processUserEntitlementRequest(argument.getValue(),UserEntitlementAction.UPDATE);
    }

    /**
     * - updateUser
     * TestCase: Update the entitlements for a given user but NoUserFoundException occurred
     * Error message is expected to be returned
     */
    @Test
    public void testUpdateUserNoUserFound() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user found we are mocking the validator to return a user record
        Users user = generateDefaultUserInstance();
        doThrow(new NoUserFoundException("test",CtracErrorSeverity.APPLICATION))
                .when(userEntitlementManagementValidator).validateUserEntitlementRequest(
                argument.capture(),eq(UserEntitlementAction.UPDATE),any(BindingResult.class));

        mockMvc.perform(post("/admin/entitlements/user/"+CONST_SID+"/update")
                .param("sid", CONST_SID)
                .param("lastName", CONST_LAST_NAME + "updated")
                .param("firstName", CONST_FIRST_NAME + "updated")
                .param("groups", String.valueOf(4L))
                .param("groups", String.valueOf(5L)))
                .andExpect(jsonPath("$.success").value("false"))
                .andExpect(jsonPath("$.validationErrors").isArray())
                .andExpect(jsonPath("$.validationErrors[0].message").exists())
                .andExpect(status().is4xxClientError());
        //Verify that the right request params was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        assertThat(argument.getValue().getFirstName(),is(CONST_FIRST_NAME + "updated"));
        assertThat(argument.getValue().getLastName(),is(CONST_LAST_NAME + "updated"));
        assertThat(argument.getValue().getGroups(),hasItem(4L));
        assertThat(argument.getValue().getGroups(),hasItem(5L));
        //verify that no update of user record will be happening
        verify(userEntitlementService,never()).processUserEntitlementRequest(argument.getValue(),UserEntitlementAction.UPDATE);
    }

    /**
     * - updateUser
     * TestCase: Update the entitlements for a given user where a field validation error occurred , so no update will be performed
     * Error message is expected to be returned
     */
    @Test
    public void testUpdateUserValidationError() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user found we are mocking the validator to return a user record and that the validator found a field validation error for first name
        final Users user = generateDefaultUserInstance();
        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                BindingResult bindingResult = (BindingResult) invocation.getArguments()[2];
                bindingResult.rejectValue("firstName","code","defaultMessage");
                return user;
            }
        }).when(userEntitlementManagementValidator).validateUserEntitlementRequest(
                argument.capture(),eq(UserEntitlementAction.UPDATE),any(BindingResult.class));

        mockMvc.perform(post("/admin/entitlements/user/"+CONST_SID+"/update")
                .param("sid", CONST_SID)
                .param("lastName", CONST_LAST_NAME + "updated")
                .param("groups", String.valueOf(4L))
                .param("groups", String.valueOf(5L)))
                .andExpect(jsonPath("$.success").value("false"))
                .andExpect(jsonPath("$.validationErrors").isArray())
                .andExpect(jsonPath("$.validationErrors[0].message").exists())
                .andExpect(status().is4xxClientError());
        //Verify that the right request params was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        assertThat(argument.getValue().getLastName(),is(CONST_LAST_NAME + "updated"));
        assertThat(argument.getValue().getGroups(),hasItem(4L));
        assertThat(argument.getValue().getGroups(),hasItem(5L));
        //verify that the service is being called to perform an update of the user record
        verify(userEntitlementService,never()).processUserEntitlementRequest(argument.getValue(),UserEntitlementAction.UPDATE);
    }

    /**
     * - updateUser
     * TestCase: Update the entitlements for a given user but an Exception occurred
     * Error message is expected to be returned
     */
    @Test
    public void testUpdateUserExceptionHandling() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user found we are mocking the validator to return a user record
        Users user = generateDefaultUserInstance();
        doThrow(new RuntimeException("test"))
                .when(userEntitlementManagementValidator).validateUserEntitlementRequest(
                argument.capture(),eq(UserEntitlementAction.UPDATE),any(BindingResult.class));

        mockMvc.perform(post("/admin/entitlements/user/"+CONST_SID+"/update")
                .param("sid", CONST_SID)
                .param("lastName", CONST_LAST_NAME + "updated")
                .param("firstName", CONST_FIRST_NAME + "updated")
                .param("groups", String.valueOf(4L))
                .param("groups", String.valueOf(5L)))
                .andExpect(jsonPath("$.success").value("false"))
                .andExpect(jsonPath("$.validationErrors").isArray())
                .andExpect(jsonPath("$.validationErrors[0].message").exists())
                .andExpect(status().is4xxClientError());
        //Verify that the right request params was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        assertThat(argument.getValue().getFirstName(),is(CONST_FIRST_NAME + "updated"));
        assertThat(argument.getValue().getLastName(),is(CONST_LAST_NAME + "updated"));
        assertThat(argument.getValue().getGroups(),hasItem(4L));
        assertThat(argument.getValue().getGroups(),hasItem(5L));
        //verify that no update of user record will be happening
        verify(userEntitlementService,never()).processUserEntitlementRequest(argument.getValue(),UserEntitlementAction.UPDATE);
    }

    /**
     * - addUser
     * TestCase: Add a new user where all validation is success
     * Success message is expected to be returned
     */
    @Test
    public void testAddUserSuccess() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user to be added we mock that validator returns null (no user was found and validation was success)
        doReturn(null).when(userEntitlementManagementValidator).validateUserEntitlementRequest(
                argument.capture(),eq(UserEntitlementAction.ADD),any(BindingResult.class));

        mockMvc.perform(post("/admin/entitlements/user/"+CONST_SID+"/add")
                .param("sid", CONST_SID)
                .param("lastName", CONST_LAST_NAME)
                .param("firstName", CONST_FIRST_NAME)
                .param("groups", String.valueOf(4L))
                .param("groups", String.valueOf(5L)))
                .andExpect(jsonPath("$.success").value("true"))
                .andExpect(status().isOk());
        //Verify that the right request params was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        assertThat(argument.getValue().getFirstName(),is(CONST_FIRST_NAME ));
        assertThat(argument.getValue().getLastName(),is(CONST_LAST_NAME));
        assertThat(argument.getValue().getGroups(),hasItem(4L));
        assertThat(argument.getValue().getGroups(),hasItem(5L));
        //verify that the service is being called to perform the creation of the user record
        verify(userEntitlementService).processUserEntitlementRequest(argument.getValue(),UserEntitlementAction.ADD);
    }

    /**
     * - deleteUser
     * TestCase: Delete the given user with all his assigned groupMembers too where all validation is success
     * Success message is expected to be returned
     */
    @Test
    public void testDeleteUserSuccess() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user found we are mocking the validator to return a user record
        Users user = generateDefaultUserInstance();
        doReturn(user).when(userEntitlementManagementValidator).validateUserEntitlementRequest(
                argument.capture(),eq(UserEntitlementAction.DELETE),any(BindingResult.class));

        mockMvc.perform(post("/admin/entitlements/user/"+CONST_SID+"/delete")
                .param("sid", CONST_SID)
                .param("lastName", CONST_LAST_NAME)
                .param("firstName", CONST_FIRST_NAME)
                .param("groups", String.valueOf(4L))
                .param("groups", String.valueOf(5L)))
                .andExpect(jsonPath("$.success").value("true"))
                .andExpect(status().isOk());
        //Verify that the right request params was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        assertThat(argument.getValue().getFirstName(),is(CONST_FIRST_NAME));
        assertThat(argument.getValue().getLastName(),is(CONST_LAST_NAME));
        assertThat(argument.getValue().getGroups(),hasItem(4L));
        assertThat(argument.getValue().getGroups(),hasItem(5L));
        //verify that the service is being called to perform an update of the user record
        verify(userEntitlementService).processUserEntitlementRequest(argument.getValue(),UserEntitlementAction.DELETE);
    }

    /**
     * - disableUser
     * TestCase: Disable the given user where all validation is success
     * Success message is expected to be returned
     */
    @Test
    public void testDisableUserSuccess() throws Exception {
        ArgumentCaptor<ManageUserEntitlementRequest> argument = ArgumentCaptor.forClass(ManageUserEntitlementRequest.class);
        //For user found we are mocking the validator to return a user record
        Users user = generateDefaultUserInstance();
        doReturn(user).when(userEntitlementManagementValidator).validateUserEntitlementRequest(
                argument.capture(),eq(UserEntitlementAction.DISABLE),any(BindingResult.class));

        mockMvc.perform(post("/admin/entitlements/user/"+CONST_SID+"/disable")
                .param("sid", CONST_SID)
                .param("lastName", CONST_LAST_NAME)
                .param("firstName", CONST_FIRST_NAME)
                .param("groups", String.valueOf(4L))
                .param("groups", String.valueOf(5L)))
                .andExpect(jsonPath("$.success").value("true"))
                .andExpect(status().isOk());
        //Verify that the right request params was passed into the validator
        assertThat(argument.getValue().getSid(),is(CONST_SID));
        assertThat(argument.getValue().getFirstName(),is(CONST_FIRST_NAME));
        assertThat(argument.getValue().getLastName(),is(CONST_LAST_NAME));
        assertThat(argument.getValue().getGroups(),hasItem(4L));
        assertThat(argument.getValue().getGroups(),hasItem(5L));
        //verify that the service is being called to perform an update of the user record
        verify(userEntitlementService).processUserEntitlementRequest(argument.getValue(),UserEntitlementAction.DISABLE);
    }
}
