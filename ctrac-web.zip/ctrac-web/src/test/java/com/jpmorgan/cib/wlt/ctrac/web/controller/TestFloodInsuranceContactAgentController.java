package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import com.jpmorgan.cib.wlt.ctrac.service.FloodInsuranceRenewalService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ContactAgentDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;

@RunWith(MockitoJUnitRunner.class)
public class TestFloodInsuranceContactAgentController extends AbstractTestFloodRemapController{
	@Mock
	private FloodInsuranceRenewalService floodInsuranceRenewalService;

	@InjectMocks
	FloodInsuranceContactAgentController floodInsuranceContactAgentController;
	
	@Rule
    public ExpectedException thrown= ExpectedException.none();
	
	@Before
	public void setUp(){
		Mockito.reset(floodInsuranceRenewalService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				floodInsuranceContactAgentController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	@Test
	public void testLaunchContactAgentHelper() throws Exception{
		TMParams tmParams = mockTmParams();
		ContactAgentDto contactAgentDto = prepareContactAgentDto();
		doReturn(contactAgentDto).when(floodInsuranceRenewalService).prepareContactAgentDto(tmParams);
		
		mockMvc.perform( get("/floodInsurance/launchContactAgentHelper")
			.sessionAttr("tmParams", tmParams))
		.andExpect(status().isOk()).andExpect(view().name("floodInsuranceContactAgent"))
		.andExpect(model().attribute("contactAgentDto",contactAgentDto));
	}
		
	
	@Test
	public void testProcessContactAgent() throws Exception{
		ContactAgentDto contactAgentDto = prepareContactAgentDto();
		TMParams tmParams = mockTmParams();
		doNothing().when(floodInsuranceRenewalService).processContactAgentDto(contactAgentDto);
		
		mockMvc.perform(post("/floodInsurance/submtiContactAgent", 1L)
				.param("save", "save")
				.sessionAttr("contactAgentDto", contactAgentDto)
				.sessionAttr("tmParams",tmParams))
		.andExpect(status().isOk())		
		.andExpect(view().name("floodRemapConfirmation"))
		.andExpect(model()
				.attribute("confirmation", messageSource.getMessage("contactAgent.confirmation.message", null, null)));

	}	
	
	private ContactAgentDto prepareContactAgentDto(){
		ContactAgentDto contactAgentDto = new ContactAgentDto();
		
		return contactAgentDto;
	}
	
	private TMParams mockTmParams(){
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("O641754");
		return tmParams;
	}
}
