package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import javax.servlet.http.Cookie;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VendorInvoiceData;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;

@RunWith(MockitoJUnitRunner.class)
public class TestVendorPaymentMethodController extends AbstractTestFloodRemapController{

	@Rule
    public ExpectedException thrown= ExpectedException.none();
	
	@InjectMocks
	@Spy
	private VendorPaymentMethodController vendorPaymentMethodController;

	@Mock
	LenderPlaceService lenderPlaceService;

	@Before
	public void setUp(){
		Mockito.reset(floodInsurancePolicyService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				vendorPaymentMethodController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
		
	@Test
	public void testSaveAndContinuePaymentMethod() throws Exception{
		VendorInvoiceData vendorInvoiceData=getMockVendorInvoiceData(null,null);
		doNothing().when(lenderPlaceService).processSubmitVendorInvoiceVerification(any(VendorInvoiceData.class));	
		
		mockMvc.perform(post("/floodRemap/savePaymentMethod/{taskId}", 1L)
				.param("saveAndContinue", "saveAndContinue").sessionAttr("floodRemapVendorInvoiceVerificationData", vendorInvoiceData)
				.sessionAttr("JANUS_USER_ID", "testUUID").cookie(new Cookie("cookie","test")))
		.andExpect(status().isOk())		
		.andExpect(view().name("floodRemapConfirmation"));
	}
	
		
	private VendorInvoiceData getMockVendorInvoiceData(String screenId,String workFlowStep){
		VendorInvoiceData vendorInvoiceData=new VendorInvoiceData();
		if(screenId!=null){
			vendorInvoiceData.setScreenId(screenId);
		}
		if(workFlowStep!=null){
			vendorInvoiceData.setCurrentWorkflowStep(workFlowStep);
		}
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("R534840");
		vendorInvoiceData.setTmParams(tmParams);
		return vendorInvoiceData;
	}
	
}
