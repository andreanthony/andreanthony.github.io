package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.batch.scheduler.TaskOnDemandScheduler;
import com.jpmorgan.cib.wlt.ctrac.service.batch.FloodRemapBatchService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.Date;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@RunWith(MockitoJUnitRunner.class)
public class TestFloodRemapCommonController {

    private static final String CONTROLLER_URL = "/floodRemap";
    private static final Date AUGUST_31_2018 = new DateTime().withDate(2018, 8, 31).toDate();
    private static final Date SEPTEMBER_1_2018 = new DateTime().withDate(2018, 9, 1).toDate();
    private static final String AUGUST_31_STR = "Friday, August 31, 2018";
    private static final String SEPTEMBER_1_STR = "Saturday, September 1, 2018";

	@Mock
	private FloodRemapBatchService floodRemapBatchService;

	@Mock
	private DateCalculator dateCalculator;

	@Mock
	private TaskOnDemandScheduler taskOnDemandScheduler;

	@InjectMocks
	protected FloodRemapCommonController testObj;

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        when(dateCalculator.isBusinessDay(AUGUST_31_2018)).thenReturn(true);
        when(dateCalculator.isBusinessDay(SEPTEMBER_1_2018)).thenReturn(false);
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

	@Test
	public void testRunRSAMWeeklyCertification() throws Exception {
		mockMvc.perform(get(CONTROLLER_URL + "/runRSAMWeeklyCertification"))
		        .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
		verify(taskOnDemandScheduler).runRSAMWeeklyCertification(true);
	}

    @Test
    public void testRunUserInactivityJob() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runUserInactivityJob"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runUserInactivityJob(true);
    }

    @Test
    public void testRunJanusCtracEntitlementSync() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runJanusCtracEntitlementSync"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runJanusCtracEntitlementSync(true);
    }

    @Test
    public void testRunSendRequestToInsuranceVendor() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runSendRequestToInsuranceVendor"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runSendRequestToInsuranceVendorJob(true);
    }

    @Test
    public void testRunSendRequestToInsuranceVendorAlthans() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runSendRequestToInsuranceVendorAlthans"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runSendRequestToInsuranceVendorAlthansJob(true);
    }

    @Test
    public void testRunProcessAlthansResponseFile() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runProcessAlthansResponseFile"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runProcessAlthansResponseFile(true);
    }

    @Test
    public void testRunProcessAlthansCertificateFile() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runProcessAlthansCertificateFile"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runProcessAlthansCertificateFile(true);
    }

    @Test
    public void testRunEntireEODProcess() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runEntireEODProcess"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runEndOfTheDayJob(true);
    }

    @Test
    public void testRunSendCoverageGapReport() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runSendCoverageGapReport"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runSendCoverageGapReportEmail(true);
    }

    @Test
    public void testRunEODC3Process() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runEODC3Process"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runEndOfTheDayC3Job(true);
    }

    @Test
    public void testRunServiceLinkDataExtract() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runServiceLinkDataExtract"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runServiceLinkJob(true);
    }

    @Test
    public void testRunCoreLogicDataExtract() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runCoreLogicDataExtract"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runCoreLogicDataJob(true);
    }

    @Test
    public void testRunProcessGDSImageSuccess() throws Exception {
        when(taskOnDemandScheduler.runProcessGDSImageJob(true)).thenReturn(true);
        mockMvc.perform(get(CONTROLLER_URL + "/runProcessGDSImage"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"))
                .andExpect(model().attribute("confirmation", "GDS Image processed successfully."));
        verify(taskOnDemandScheduler).runProcessGDSImageJob(true);
    }

    @Test
    public void testRunProcessGDSImageFail() throws Exception {
        when(taskOnDemandScheduler.runProcessGDSImageJob(true)).thenReturn(false);
        mockMvc.perform(get(CONTROLLER_URL + "/runProcessGDSImage"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"))
                .andExpect(model().attribute("confirmation", "GDS Image not processed successfully."));
        verify(taskOnDemandScheduler).runProcessGDSImageJob(true);
    }

    @Test
    public void testRunCheckRemapFileLastUpdateJob() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runCheckRemapFileLastUpdateJob"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runCheckRemapFileLastUpdateJob(true);
    }

    @Test
    public void testRunUpdateReferenceDate() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runUpdateReferenceDate"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runUpdateReferenceDateJob(true);
    }

    @Test
    public void testRunProcessToRenewPolicy() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runProcessToRenewPolicy"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runProcessToReviewPolicyJob(true);
    }

    @Test
    public void testRunProcessWireRequest() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runProcessWireRequest"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runProcessWireRequestJob(true);
    }

    @Test
    public void testRunEntirePostEODProcess() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runEntirePostEODProcess"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(taskOnDemandScheduler).runPostFullEodJob(true);
    }

    @Test
    public void testRemapTaskList() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/remapTaskList"))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapTaskList"));
    }

    @Test
    public void testRunStarWarsProcess() throws Exception {
        mockMvc.perform(get(CONTROLLER_URL + "/runStarWarsProcess"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/starWars"));
    }

    @Test
    public void testRunUpdateReferenceDateAjaxAug() throws Exception {
        when(dateCalculator.getCurrentReferenceDate()).thenReturn(AUGUST_31_2018);
        mockMvc.perform(get(CONTROLLER_URL + "/runUpdateReferenceDateAjax"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.referenceDate").value(AUGUST_31_STR))
                .andExpect(jsonPath("$.isWorkingDay").value("Yes"));
        verify(taskOnDemandScheduler).runUpdateReferenceDateJob(true);
    }

    @Test
    public void testRunUpdateReferenceDateAjaxSep() throws Exception {
        when(dateCalculator.getCurrentReferenceDate()).thenReturn(SEPTEMBER_1_2018);
        mockMvc.perform(get(CONTROLLER_URL + "/runUpdateReferenceDateAjax"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.referenceDate").value(SEPTEMBER_1_STR))
                .andExpect(jsonPath("$.isWorkingDay").value("No"));
        verify(taskOnDemandScheduler).runUpdateReferenceDateJob(true);
    }
}
