package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.DateCalculator;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.ReferenceDateService;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.Date;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestReferenceDateController {

    private static final Date REFERENCE_DATE = new DateTime().withDate(2018, 5, 31).withTimeAtStartOfDay().toDate();
    private static final Date NEW_REFERENCE_DATE = new DateTime().withDate(2018, 6, 1).withTimeAtStartOfDay().toDate();
    private static final ObjectMapper mapper;
    private static final ObjectWriter writer;
    public static final String EXPECTED_EXCEPTION = "Expected Exception";

    static {
        mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        writer = mapper.writer().withDefaultPrettyPrinter();
    }

    @Mock private ReferenceDateService referenceDateService;
    @Mock private DateCalculator dateCalculator;

    @InjectMocks
    private ReferenceDateController testObj;

    private MockMvc mockMvc;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
        when(dateCalculator.isBusinessDay(REFERENCE_DATE)).thenReturn(true);
        when(dateCalculator.isBusinessDay(NEW_REFERENCE_DATE)).thenReturn(true);
    }

    @Test
    public void testGetReferenceDate() throws Exception {
        when(dateCalculator.getCurrentReferenceDate()).thenReturn(REFERENCE_DATE);

        mockMvc.perform(get("/api/admin/referenceDate")
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.referenceDate").value("2018-05-31"))
                .andExpect(jsonPath("$.longDate").value("Thursday, May 31, 2018"))
                .andExpect(jsonPath("$.workingDay").value(true))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetReferenceDateFailure() throws Exception {
        doThrow(new CtracAjaxException(EXPECTED_EXCEPTION)).when(dateCalculator).getCurrentReferenceDate();

        mockMvc.perform(get("/api/admin/referenceDate")
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.errorMessage").value("Cannot get reference date"))
                .andExpect(status().is4xxClientError());
    }

    @Test
    public void testUpdateReferenceDateHTML() {
        testUpdateReferenceDate("2018-06-01");
    }

    @Test
    public void testUpdateReferenceDateDefault() {
        testUpdateReferenceDate("06/01/2018");
    }

    private void testUpdateReferenceDate(String referenceDate) {
        String requestJson = getRequestJson(referenceDate);
        when(dateCalculator.getCurrentReferenceDate()).thenReturn(NEW_REFERENCE_DATE);

        postAndVerify("/api/admin/referenceDate", requestJson);

        verify(referenceDateService).updateReferenceDate(NEW_REFERENCE_DATE);
    }

    @Test
    public void testUpdateReferenceDateFailure() {
        String requestJson = getRequestJson("2018-06-01");
        doThrow(new CtracAjaxException(EXPECTED_EXCEPTION)).when(referenceDateService).updateReferenceDate(NEW_REFERENCE_DATE);

        postWithException("/api/admin/referenceDate", requestJson, "Reference date not updated");
    }

    private String getRequestJson(String referenceDate) {
        try {
            ReferenceDateDTO referenceDateDTO = new ReferenceDateDTO();
            referenceDateDTO.setReferenceDate(referenceDate);
            return writer.writeValueAsString(referenceDateDTO);
        } catch (Exception e) {
            fail();
        }
        return null;
    }

    @Test
    public void testAdvanceReferenceDate() {
        when(dateCalculator.getCurrentReferenceDate()).thenReturn(NEW_REFERENCE_DATE);

        postAndVerify("/api/admin/referenceDate/advance");

        verify(referenceDateService).advanceReferenceDate();
    }

    @Test
    public void testAdvanceReferenceDateFailure() {
        doThrow(new CtracAjaxException(EXPECTED_EXCEPTION)).when(referenceDateService).advanceReferenceDate();

        postWithException("/api/admin/referenceDate/advance", "Reference date not updated");
    }

    @Test
    public void testAdvanceReferenceDateToDay() {
        when(dateCalculator.getCurrentReferenceDate()).thenReturn(NEW_REFERENCE_DATE);

        postAndVerify("/api/admin/referenceDate/advance/friday");

        verify(referenceDateService).advanceReferenceDate("friday");
    }

    @Test
    public void testAdvanceReferenceDateToDayFailure() {
        doThrow(new CtracAjaxException(EXPECTED_EXCEPTION)).when(referenceDateService).advanceReferenceDate("friday");

        postWithException("/api/admin/referenceDate/advance/friday", "Reference date not updated");
    }

    private void postAndVerify(String url, String requestJson) {
        try {
            verifyActions(mockMvc.perform(post(url)
                    .contentType(APPLICATION_JSON_UTF8)
                    .content(requestJson)));
        } catch (Exception e) {
            fail();
        }
    }

    private void postAndVerify(String url) {
        try {
            verifyActions(mockMvc.perform(post(url)
                    .contentType(APPLICATION_JSON_UTF8)));
        } catch (Exception e) {
            fail();
        }
    }

    private void verifyActions(ResultActions resultActions) throws Exception{
        resultActions.andExpect(jsonPath("$.referenceDate").value("2018-06-01"))
                .andExpect(jsonPath("$.longDate").value("Friday, June 1, 2018"))
                .andExpect(jsonPath("$.workingDay").value(true))
                .andExpect(status().isOk());
    }

    private void postWithException(String url, String errorMessage) {
        try {
            mockMvc.perform(post(url)
                    .contentType(APPLICATION_JSON_UTF8))
                    .andExpect(jsonPath("$.errorMessage").value(errorMessage))
                    .andExpect(status().is4xxClientError());
        } catch (Exception e) {
            fail();
        }
    }

    private void postWithException(String url, String requestJson, String errorMessage) {
        try {
            verifyExceptions(mockMvc.perform(post(url)
                            .contentType(APPLICATION_JSON_UTF8)
                            .content(requestJson)), errorMessage);
        } catch (Exception e) {
            fail();
        }
    }

    private void verifyExceptions(ResultActions resultActions, String errorMessage) throws Exception {
        resultActions.andExpect(jsonPath("$.errorMessage").value(errorMessage))
                .andExpect(status().is4xxClientError());
    }
}
