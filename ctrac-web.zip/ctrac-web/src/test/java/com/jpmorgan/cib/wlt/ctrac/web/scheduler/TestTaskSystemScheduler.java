package com.jpmorgan.cib.wlt.ctrac.web.scheduler;


import com.jpmorgan.cib.wlt.ctrac.batch.scheduler.SchedulerMngtService;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.*;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestTaskSystemScheduler {

    @Mock
    private BatchCtrlRepository batchCtrlRepository;
    @Mock
    private CalendarDayUtil calendarDayUtil;
    @Mock
    private FloodRemapBatchService floodRemapBatchService;
    @Mock
    private LPRequestToVendorService lpRequestToVendorService;
    @Mock
    private SchedulerMngtService schedulerMngtService;
    @Mock
    private UserEntitlementService userEntitlementService;
    @Mock
    private EmailNotificationService emailNotificationService;
    @Mock(name = "coreLogicDataExtract")
    private FloodRemapDataExtract coreLogicDataExtract;
    @Mock(name = "serviceLinkDataExtract")
    private FloodRemapDataExtract serviceLinkDataExtract;
    @Mock(name = "althansResponseDataExtract")
    private FloodRemapDataExtract althansResponseDataExtract;
    @Mock(name = "althansCertificateDataExtract")
    private FloodRemapDataExtract althansCertificateDataExtract;
    @Mock(name = "policyRenewalBatchService")
    private PolicyRenewalBatchService policyRenewalBatchService;
    @Mock(name = "processGDSImage")
    private ProcessGDSImage processGDSImage;
    @Mock
    private BatchCtrl testBatchCtrl;

    @Spy
    @InjectMocks
    TaskSystemScheduler testObj;

    @Before
    public void setup() {
        when(batchCtrlRepository.save(testBatchCtrl)).thenReturn(testBatchCtrl);
        when(calendarDayUtil.getCurrentReferenceDate()).thenReturn(new Date());
    }

    private void setupCommonEnabled(SchedulerJob job) {
        setupCommonEnabled(job, true);
    }

    private void setupCommonEnabled(SchedulerJob job, boolean isWorkingDay) {
        when(batchCtrlRepository.findByBatchType(job.getName())).thenReturn(Arrays.asList(testBatchCtrl));
        when(schedulerMngtService.isJobEnabled(job)).thenReturn(true);
        when(calendarDayUtil.isWorkingDay()).thenReturn(isWorkingDay);
    }

    private void verifyCommonEnabled(SchedulerJob job, int expectedSaveCount) {
        verifyCommonEnabled(job, expectedSaveCount, false);
    }

    private void verifyCommonEnabled(SchedulerJob job, int expectedSaveCount, boolean verifyWorkingDay) {
        verify(schedulerMngtService).isJobEnabled(job);
        verify(batchCtrlRepository, times(expectedSaveCount)).save(testBatchCtrl);
        verify(calendarDayUtil).getCurrentReferenceDate();
        if (verifyWorkingDay) {
            verify(calendarDayUtil, times(1)).isWorkingDay();
        }
    }

    private void setupCommonDisabled(SchedulerJob job) {
        when(schedulerMngtService.isJobEnabled(job)).thenReturn(false);
    }

    private void verifyCommonDisabled(SchedulerJob job) {
        verifyCommonDisabled(job, false);
    }

    private void verifyCommonDisabled(SchedulerJob job, boolean validateWorkingDay) {
        verify(schedulerMngtService).isJobEnabled(job);
        verifyZeroInteractions(batchCtrlRepository);
        if (validateWorkingDay) {
            verify(calendarDayUtil).isWorkingDay();
        } else {
            verifyZeroInteractions(calendarDayUtil);
        }
    }

    // BEGIN runRSAMWeeklyCertification tests
    @Test
    public void test_runRSAMWeeklyCertification_Enabled() throws Exception {
        setupEnabled_runRSAMWeeklyCertification();
        testObj.runRSAMWeeklyCertification();
        verifyEnabled_runRSAMWeeklyCertification();
    }

    private void setupEnabled_runRSAMWeeklyCertification() throws Exception {
        doNothing().when(userEntitlementService).processWeeklyCertification();
        setupCommonEnabled(RSAM_WEEKLY_CERTIFICATION_JOB);
    }

    private void verifyEnabled_runRSAMWeeklyCertification() throws Exception {
        verify(userEntitlementService).processWeeklyCertification();
        verifyCommonEnabled(RSAM_WEEKLY_CERTIFICATION_JOB, 2);
    }

    @Test
    public void test_runRSAMWeeklyCertification_NotEnabled() {
        setupCommonDisabled(RSAM_WEEKLY_CERTIFICATION_JOB);
        testObj.runRSAMWeeklyCertification();
        verifyZeroInteractions(userEntitlementService);
        verifyCommonDisabled(RSAM_WEEKLY_CERTIFICATION_JOB);
    }
    // END runRSAMWeeklyCertification tests

    // BEGIN runUserInactivityJob tests
    @Test
    public void test_runUserInactivityJob_Enabled() throws Exception {
        setupEnabled_runUserInactivityJob();
        testObj.runUserInactivityJob();
        verifyEnabled_runUserInactivityJob();
    }

    private void setupEnabled_runUserInactivityJob() throws Exception {
        doNothing().when(userEntitlementService).performUserInactivityActions();
        setupCommonEnabled(USER_INACTIVITY_JOB);
    }

    private void verifyEnabled_runUserInactivityJob() throws Exception {
        verify(userEntitlementService).performUserInactivityActions();
        verifyCommonEnabled(USER_INACTIVITY_JOB, 2);
    }

    @Test
    public void test_runUserInactivityJob_NotEnabled() {
        setupCommonDisabled(USER_INACTIVITY_JOB);
        testObj.runUserInactivityJob();
        verifyZeroInteractions(userEntitlementService);
        verifyCommonDisabled(USER_INACTIVITY_JOB);
    }
    // END runUserInactivityJob tests

    // BEGIN runJanusCtracEntitlementSync tests
    @Test
    public void test_runJanusCtracEntitlementSync_Enabled() throws Exception {
        List<Users> mockedUserList = setupEnabled_runJanusCtracEntitlementSync();
        testObj.runJanusCtracEntitlementSync();
        verifyEnabled_runJanusCtracEntitlementSync(mockedUserList);
    }

    private List<Users> setupEnabled_runJanusCtracEntitlementSync() throws Exception {
        List<Users> mockedUserList = new ArrayList();
        when(userEntitlementService.getJanusUserList()).thenReturn(mockedUserList);
        when(userEntitlementService.getCTRACUserList()).thenReturn(mockedUserList);
        doNothing().when(userEntitlementService).performSyncOfUsersBetweenJanusAndCtrac(mockedUserList, mockedUserList);
        setupCommonEnabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB);
        return mockedUserList;
    }

    private void verifyEnabled_runJanusCtracEntitlementSync(List<Users> mockedUserList) throws Exception {
        verify(userEntitlementService).getJanusUserList();
        verify(userEntitlementService).getCTRACUserList();
        verify(userEntitlementService).performSyncOfUsersBetweenJanusAndCtrac(mockedUserList, mockedUserList);
        verifyCommonEnabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB, 2);
    }

    @Test
    public void test_runJanusCtracEntitlementSync_NotEnabled() {
        setupCommonDisabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB);
        testObj.runJanusCtracEntitlementSync();
        verifyZeroInteractions(userEntitlementService);
        verifyCommonDisabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB);
    }
    // END runJanusCtracEntitlementSync tests

    // BEGIN runServiceLinkJob tests
    @Test
    public void test_runServiceLinkJob_Enabled() {
        setupEnabled_runServiceLinkJob();
        testObj.runServiceLinkJob();
        verifyEnabled_runServiceLinkJob();
    }

    private void setupEnabled_runServiceLinkJob() {
        doNothing().when(serviceLinkDataExtract).processRemapFiles();
        setupCommonEnabled(SERVICE_lINK_DATA_EXTRACT);
    }

    private void verifyEnabled_runServiceLinkJob() {
        verify(serviceLinkDataExtract).processRemapFiles();
        verifyCommonEnabled(SERVICE_lINK_DATA_EXTRACT, 3);
    }

    @Test
    public void test_runServiceLinkJob_NotEnabled() {
        setupCommonDisabled(SERVICE_lINK_DATA_EXTRACT);
        testObj.runServiceLinkJob();
        verifyZeroInteractions(serviceLinkDataExtract);
        verifyCommonDisabled(SERVICE_lINK_DATA_EXTRACT);
    }
    // END runServiceLinkJob tests

    // BEGIN runCoreLogicDataJob tests
    @Test
    public void test_runCoreLogicDataJob_Enabled() {
        setupEnabled_runCoreLogicDataJob();
        testObj.runCoreLogicDataJob();
        verifyEnabled_runCoreLogicDataJob();
    }

    private void setupEnabled_runCoreLogicDataJob() {
        doNothing().when(coreLogicDataExtract).processRemapFiles();
        setupCommonEnabled(CORELOGIC_DATA_EXTRACT);
    }

    private void verifyEnabled_runCoreLogicDataJob() {
        verify(coreLogicDataExtract).processRemapFiles();
        verifyCommonEnabled(CORELOGIC_DATA_EXTRACT, 3);
    }

    @Test
    public void test_runCoreLogicDataJob_NotEnabled() {
        setupCommonDisabled(CORELOGIC_DATA_EXTRACT);
        testObj.runCoreLogicDataJob();
        verifyZeroInteractions(coreLogicDataExtract);
        verifyCommonDisabled(CORELOGIC_DATA_EXTRACT);
    }
    // END runCoreLogicDataJob tests

    // BEGIN runCheckRemapFileLastUpdateJob tests
    @Test
    public void test_runCheckRemapFileLastUpdate_Enabled() throws Exception {
        setupEnabled_runCheckRemapFileLastUpdate();
        testObj.runCheckRemapFileLastUpdate();
        verifyEnabled_runCheckRemapFileLastUpdate();
    }

    private void setupEnabled_runCheckRemapFileLastUpdate() throws Exception {
        doNothing().when(floodRemapBatchService).checkSLLastRemapFileReceivedDateAndNotify();
        doNothing().when(floodRemapBatchService).checkCLLastRemapFileReceivedDateAndNotify();
        setupCommonEnabled(LAST_RECEIVED_REMAP_NOTIFY);
    }

    private void verifyEnabled_runCheckRemapFileLastUpdate() throws Exception {
        verify(floodRemapBatchService).checkSLLastRemapFileReceivedDateAndNotify();
        verify(floodRemapBatchService).checkCLLastRemapFileReceivedDateAndNotify();
        verifyCommonEnabled(LAST_RECEIVED_REMAP_NOTIFY, 3);
    }

    @Test
    public void test_runCheckRemapFileLastUpdate_NotEnabled() {
        setupCommonDisabled(LAST_RECEIVED_REMAP_NOTIFY);
        testObj.runCheckRemapFileLastUpdate();
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(LAST_RECEIVED_REMAP_NOTIFY);
    }
    // END runCheckRemapFileLastUpdateJob tests

    // BEGIN runEndOfTheDayJob tests
    @Test
    public void test_runEndOfTheDayJob_Enabled() {
        setupEnabled_runEndOfTheDayJob();
        testObj.runEndOfTheDayJob();
        verifyEnabled_runEndOfTheDayJob();
    }

    private void setupEnabled_runEndOfTheDayJob() {
        doNothing().when(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        doNothing().when(testObj).createAggregateItemsForPropertyTasks(true);
        doNothing().when(testObj).runSendLPPremiumEMail(true);
        doNothing().when(testObj).runNewTaskCreationJobSL(true);
        doNothing().when(testObj).runNewTaskCreationJobCL(true);
        doNothing().when(testObj).runNewTaskCreationJob(true);
        doNothing().when(testObj).placeValidGDSLetterFile();
        setupCommonEnabled(FULL_EOD_JOB);
    }

    private void verifyEnabled_runEndOfTheDayJob() {
        verify(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        verify(testObj).createAggregateItemsForPropertyTasks(true);
        verify(testObj).runSendLPPremiumEMail(true);
        verify(testObj).runNewTaskCreationJobSL(true);
        verify(testObj).runNewTaskCreationJobCL(true);
        verify(testObj).runNewTaskCreationJob(true);
        verify(testObj).placeValidGDSLetterFile();
        verifyCommonEnabled(FULL_EOD_JOB, 3);
    }

    @Test
    public void test_runEndOfTheDayJob_NotEnabled() {
        setupCommonDisabled(FULL_EOD_JOB);
        testObj.runEndOfTheDayJob();
        verify(testObj, times(0)).runStatesAndSLAUpdateEndOfTheDayJob(true);
        verify(testObj, times(0)).createAggregateItemsForPropertyTasks(true);
        verify(testObj, times(0)).runSendLPPremiumEMail(true);
        verify(testObj, times(0)).runNewTaskCreationJobSL(true);
        verify(testObj, times(0)).runNewTaskCreationJobCL(true);
        verify(testObj, times(0)).runNewTaskCreationJob(true);
        verify(testObj, times(0)).placeValidGDSLetterFile();
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(FULL_EOD_JOB);
    }

    @Test
    public void test_runEndOfTheDayJob_WithException() {
        setupCommonEnabled(FULL_EOD_JOB);
        doThrow(NullPointerException.class).when(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        testObj.runEndOfTheDayJob();
        verify(floodRemapBatchService).archiveInValidLetterFile();
        verifyCommonEnabled(FULL_EOD_JOB, 3);
    }
    // END runEndOfTheDayJob tests

    // BEGIN runSendCoverageGapReportEmail tests
    @Test
    public void test_runSendCoverageGapReportEmail_Enabled() {
        setupEnabled_runSendCoverageGapReportEmail();
        testObj.runSendCoverageGapReportEmail();
        verifyEnabled_runSendCoverageGapReportEmail();
    }

    private void setupEnabled_runSendCoverageGapReportEmail() {
        doNothing().when(emailNotificationService).sendCoverageGapReportEmail();
        setupCommonEnabled(COVERAGE_GAP_REPORT_EMAIL);
    }

    private void verifyEnabled_runSendCoverageGapReportEmail() {
        verify(emailNotificationService).sendCoverageGapReportEmail();
        verifyCommonEnabled(COVERAGE_GAP_REPORT_EMAIL, 3);
    }

    @Test
    public void test_runSendCoverageGapReportEmail_NotEnabled() {
        setupCommonDisabled(COVERAGE_GAP_REPORT_EMAIL);
        testObj.runSendCoverageGapReportEmail();
        verifyZeroInteractions(emailNotificationService);
        verifyCommonDisabled(COVERAGE_GAP_REPORT_EMAIL);
    }
    // END runSendCoverageGapReportEmail tests

    // BEGIN runEndOfTheDayC3Job tests
    @Test
    public void test_runEndOfTheDayC3Job_Enabled() {
        setupEnabled_runEndOfTheDayC3Job();
        testObj.runEndOfTheDayC3Job();
        verifyEnabled_runEndOfTheDayC3Job();
    }

    private void setupEnabled_runEndOfTheDayC3Job() {
        doNothing().when(emailNotificationService).sendLettersReviewEmail();
        doNothing().when(testObj).runInsurancePolicyC3Jobs(true);
        setupCommonEnabled(EOD_C3_JOB);
    }

    private void verifyEnabled_runEndOfTheDayC3Job() {
        verify(emailNotificationService).sendLettersReviewEmail();
        verify(testObj).runInsurancePolicyC3Jobs(true);
        verifyCommonEnabled(EOD_C3_JOB, 3);
    }

    @Test
    public void test_runEndOfTheDayC3Job_NotEnabled() {
        setupCommonDisabled(EOD_C3_JOB);
        testObj.runEndOfTheDayC3Job();
        verify(testObj, times(0)).runInsurancePolicyC3Jobs(true);
        verifyZeroInteractions(emailNotificationService);
        verifyCommonDisabled(EOD_C3_JOB);
    }
    // END runEndOfTheDayC3Job tests

    // BEGIN runSendRequestToInsuranceVendorJob tests
    @Test
    public void test_runSendRequestToInsuranceVendorJob_Enabled() {
        setupEnabled_runSendRequestToInsuranceVendorJob();
        testObj.runSendRequestToInsuranceVendorJob();
        verifyEnabled_runSendRequestToInsuranceVendorJob();
    }

    private void setupEnabled_runSendRequestToInsuranceVendorJob() {
        doNothing().when(lpRequestToVendorService).sendRequestToInsuranceVendor();
        setupCommonEnabled(SEND_LP_REQUEST, true);
    }

    private void verifyEnabled_runSendRequestToInsuranceVendorJob() {
        verify(lpRequestToVendorService).sendRequestToInsuranceVendor();
        verifyCommonEnabled(SEND_LP_REQUEST, 3, true);
    }

    @Test
    public void test_runSendRequestToInsuranceVendorJob_NotEnabled() {
        setupCommonDisabled(SEND_LP_REQUEST);
        testDisabled_runSendRequestToInsuranceVendorJob();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorJob_NotWorkingDay() {
        setupCommonEnabled(SEND_LP_REQUEST, false);
        testDisabled_runSendRequestToInsuranceVendorJob();
    }

    private void testDisabled_runSendRequestToInsuranceVendorJob() {
        testObj.runSendRequestToInsuranceVendorJob();
        verifyZeroInteractions(lpRequestToVendorService);
        verifyCommonDisabled(SEND_LP_REQUEST, true);
    }

    @Test(expected = NullPointerException.class)
    public void test_runSendRequestToInsuranceVendorJob_WithException() {
        setupEnabled_runSendRequestToInsuranceVendorJob();
        doThrow(NullPointerException.class).when(lpRequestToVendorService).sendRequestToInsuranceVendor();
        testObj.runSendRequestToInsuranceVendorJob();
        verify(batchCtrlRepository, times(3)).save(testBatchCtrl);
        verify(calendarDayUtil, times(1)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }
    // END runSendRequestToInsuranceVendorJob tests

    // BEGIN runSendRequestToInsuranceVendorAlthansJob tests
    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_Enabled() {
        setupEnabled_runSendRequestToInsuranceVendorAlthansJob();
        testObj.runSendRequestToInsuranceVendorAlthansJob();
        verifyEnabled_runSendRequestToInsuranceVendorAlthansJob();
    }

    private void setupEnabled_runSendRequestToInsuranceVendorAlthansJob() {
        doNothing().when(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        doNothing().when(lpRequestToVendorService).sendRequestToInsuranceVendorAlthans();
        when(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS)).thenReturn(false);
        setupCommonEnabled(SEND_LP_REQUEST_ALTHANS, true);
    }

    private void verifyEnabled_runSendRequestToInsuranceVendorAlthansJob() {
        verify(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        verify(lpRequestToVendorService).sendRequestToInsuranceVendorAlthans();
        verify(batchCtrlRepository, times(4)).save(testBatchCtrl);
        verify(calendarDayUtil, times(2)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_NotEnabled() {
        setupCommonDisabled(SEND_LP_REQUEST_ALTHANS);
        testDisabled_runSendRequestToInsuranceVendorAlthansJob();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_NotWorkingDay() {
        setupCommonEnabled(SEND_LP_REQUEST_ALTHANS, false);
        testDisabled_runSendRequestToInsuranceVendorAlthansJob();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_AlreadyRan() {
        setupCommonEnabled(SEND_LP_REQUEST_ALTHANS, true);
        when(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS)).thenReturn(true);
        testDisabled_runSendRequestToInsuranceVendorAlthansJob();
    }

    private void testDisabled_runSendRequestToInsuranceVendorAlthansJob() {
        testObj.runSendRequestToInsuranceVendorAlthansJob();
        verifyZeroInteractions(lpRequestToVendorService);
        verifyCommonDisabled(SEND_LP_REQUEST_ALTHANS, true);
    }

    @Test(expected = NullPointerException.class)
    public void test_runSendRequestToInsuranceVendorAlthansJob_WithException() {
        setupEnabled_runSendRequestToInsuranceVendorAlthansJob();
        doThrow(NullPointerException.class).when(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        testObj.runSendRequestToInsuranceVendorAlthansJob();
        verify(batchCtrlRepository, times(3)).save(testBatchCtrl);
        verify(calendarDayUtil, times(1)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }
    // END runSendRequestToInsuranceVendorAlthansJob tests

    // BEGIN runUpdateReferenceDateJob tests
    @Test
    public void test_runUpdateReferenceDateJob_Enabled() {
        setupEnabled_runUpdateReferenceDateJob();
        testObj.runUpdateReferenceDateJob();
        verifyEnabled_runUpdateReferenceDateJob();
    }

    private void setupEnabled_runUpdateReferenceDateJob() {
        doNothing().when(floodRemapBatchService).updateReferenceDate();
        setupCommonEnabled(UPDATE_REFERENCE_DATE);
    }

    private void verifyEnabled_runUpdateReferenceDateJob() {
        verify(floodRemapBatchService).updateReferenceDate();
        verifyCommonEnabled(UPDATE_REFERENCE_DATE, 3);
    }

    @Test
    public void test_runUpdateReferenceDateJob_NotEnabled() {
        setupCommonDisabled(UPDATE_REFERENCE_DATE);
        testObj.runUpdateReferenceDateJob();
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(UPDATE_REFERENCE_DATE);
    }
    // END runUpdateReferenceDateJob tests

    // BEGIN runSendRequestToInsuranceVendorJob tests
    @Test
    public void test_runProcessToReviewPolicyJob_Enabled() {
        setupEnabled_runProcessToReviewPolicyJob();
        testObj.runProcessToReviewPolicyJob();
        verifyEnabled_runProcessToReviewPolicyJob();
    }

    private void setupEnabled_runProcessToReviewPolicyJob() {
        doNothing().when(policyRenewalBatchService).initiatePolicyRenewalReviewProcess();
        setupCommonEnabled(PROCESS_INS_POLICY_TO_REVIEW, true);
    }

    private void verifyEnabled_runProcessToReviewPolicyJob() {
        verify(policyRenewalBatchService).initiatePolicyRenewalReviewProcess();
        verifyCommonEnabled(PROCESS_INS_POLICY_TO_REVIEW, 3, true);
    }

    @Test
    public void test_runProcessToReviewPolicyJob_NotEnabled() {
        setupCommonDisabled(PROCESS_INS_POLICY_TO_REVIEW);
        testDisabled_runProcessToReviewPolicyJob();
    }

    @Test
    public void test_runProcessToReviewPolicyJob_NotWorkingDay() {
        setupCommonEnabled(PROCESS_INS_POLICY_TO_REVIEW, false);
        testDisabled_runProcessToReviewPolicyJob();
    }

    private void testDisabled_runProcessToReviewPolicyJob() {
        testObj.runProcessToReviewPolicyJob();
        verifyZeroInteractions(policyRenewalBatchService);
        verifyCommonDisabled(PROCESS_INS_POLICY_TO_REVIEW, true);
    }
    // END runSendRequestToInsuranceVendorJob tests

    // BEGIN runProcessWireRequestJob tests
    @Test
    public void test_runProcessWireRequestJob_Enabled() {
        setupEnabled_runProcessWireRequestJob();
        testObj.runProcessWireRequestJob();
        verifyEnabled_runProcessWireRequestJob();
    }

    private void setupEnabled_runProcessWireRequestJob() {
        doNothing().when(floodRemapBatchService).processWiredPolicy();
        setupCommonEnabled(PROCESS_WIRE_REQUEST);
    }

    private void verifyEnabled_runProcessWireRequestJob() {
        verify(floodRemapBatchService).processWiredPolicy();
        verifyCommonEnabled(PROCESS_WIRE_REQUEST, 3);
    }

    @Test
    public void test_runProcessWireRequestJob_NotEnabled() {
        setupCommonDisabled(PROCESS_WIRE_REQUEST);
        testObj.runProcessWireRequestJob();
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(PROCESS_WIRE_REQUEST);
    }
    // END runProcessWireRequestJob tests

    // BEGIN runProcessAlthansResponseFile tests
    @Test
    public void test_runProcessAlthansResponseFile_Enabled() {
        setupEnabled_runProcessAlthansResponseFile();
        testObj.runProcessAlthansResponseFile();
        verifyEnabled_runProcessAlthansResponseFile();
    }

    private void setupEnabled_runProcessAlthansResponseFile() {
        doNothing().when(althansResponseDataExtract).processAlthansResponse();
        setupCommonEnabled(PROCESS_ALTHANS_RESPONSE_FILE);
    }

    private void verifyEnabled_runProcessAlthansResponseFile() {
        verify(althansResponseDataExtract).processAlthansResponse();
        verify(schedulerMngtService).isJobEnabled(PROCESS_ALTHANS_RESPONSE_FILE);
    }

    @Test
    public void test_runProcessAlthansResponseFile_NotEnabled() {
        setupCommonDisabled(PROCESS_ALTHANS_RESPONSE_FILE);
        testObj.runProcessAlthansResponseFile();
        verifyZeroInteractions(althansResponseDataExtract);
        verifyCommonDisabled(PROCESS_ALTHANS_RESPONSE_FILE);
    }
    // END runProcessAlthansResponseFile tests

    // BEGIN runProcessAlthansCertificateFile tests
    @Test
    public void test_runProcessAlthansCertificateFile_Enabled() {
        setupEnabled_runProcessAlthansCertificateFile();
        testObj.runProcessAlthansCertificateFile();
        verifyEnabled_runProcessAlthansCertificateFile();
    }

    private void setupEnabled_runProcessAlthansCertificateFile() {
        doNothing().when(althansCertificateDataExtract).processAlthansCertificateFile();
        setupCommonEnabled(PROCESS_ALTHANS_CERTIFICATE_FILE);
    }

    private void verifyEnabled_runProcessAlthansCertificateFile() {
        verify(althansCertificateDataExtract).processAlthansCertificateFile();
        verify(schedulerMngtService).isJobEnabled(PROCESS_ALTHANS_CERTIFICATE_FILE);
    }

    @Test
    public void test_runProcessAlthansCertificateFile_NotEnabled() {
        setupCommonDisabled(PROCESS_ALTHANS_CERTIFICATE_FILE);
        testObj.runProcessAlthansCertificateFile();
        verifyZeroInteractions(althansCertificateDataExtract);
        verifyCommonDisabled(PROCESS_ALTHANS_CERTIFICATE_FILE);
    }
    // END runProcessAlthansCertificateFile tests

    // BEGIN runPostFullEodJob tests
    @Test
    public void test_runPostFullEodJob_Enabled() {
        setupEnabled_runPostFullEodJob();
        testObj.runPostFullEodJob();
        verifyEnabled_runPostFullEodJob();
    }

    private void setupEnabled_runPostFullEodJob() {
        doNothing().when(floodRemapBatchService).reconcileCtracAndTM();
        setupCommonEnabled(POST_FULL_EOD_JOB);
    }

    private void verifyEnabled_runPostFullEodJob() {
        verify(floodRemapBatchService).reconcileCtracAndTM();
        verifyCommonEnabled(POST_FULL_EOD_JOB, 3);
    }

    @Test
    public void test_runPostFullEodJob_NotEnabled() {
        setupCommonDisabled(POST_FULL_EOD_JOB);
        testObj.runPostFullEodJob();
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(POST_FULL_EOD_JOB);
    }
    // END runPostFullEodJob tests

    // BEGIN runProcessGDSImageJob tests
    @Test
    public void test_runProcessGDSImageJob_Enabled() {
        setupEnabled_runProcessGDSImageJob();
        testObj.runProcessGDSImageJob();
        verifyEnabled_runProcessGDSImageJob();
    }

    private void setupEnabled_runProcessGDSImageJob() {
        when(processGDSImage.processLetterImages()).thenReturn(true);
        setupCommonEnabled(PROCESS_GDSIMAGE);
    }

    private void verifyEnabled_runProcessGDSImageJob() {
        verify(processGDSImage).processLetterImages();
        verifyCommonEnabled(PROCESS_GDSIMAGE, 3);
    }

    @Test
    public void test_runProcessGDSImageJob_NotEnabled() {
        setupCommonDisabled(PROCESS_GDSIMAGE);
        testObj.runProcessGDSImageJob();
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(PROCESS_GDSIMAGE);
    }
    // END runProcessGDSImageJob tests
}
