package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.BatchJobMaintenanceData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapDto;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import org.hamcrest.core.Is;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.collections.Sets;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class TestFloodRemapAdminController {
    private static final String TM_TASK_ID = "1111-2222-3333-4444";

    @Mock private FloodRemapAdminService floodRemapAdminService;
    @Mock private EmailAttachmentsBucket emailAttachmentsBucket;
    @Mock private BatchCtrlRepository batchCtrlRepository;
    @Mock private Environment env;

    @InjectMocks
    private FloodRemapAdminController testObj;

    private MockMvc mockMvc;

    @Captor
    private ArgumentCaptor<BatchJobMaintenanceData> batchCaptor;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testDisplayCreateFloodRemapRecord() throws Exception {
        FloodRemapDto floodRemapDto = mock(FloodRemapDto.class);
        when(floodRemapAdminService.prepareDisplayCreateNewRemap()).thenReturn(floodRemapDto);
        mockMvc.perform(get("/admin/floodRemap/launchCreate"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("floodRemapDto", floodRemapDto))
                .andExpect(view().name("admin/floodRemapCreateNewRecord"));
    }

    @Test
    public void testProcessCreateFloodRemapRecord() throws Exception {
        FloodRemapDto floodRemapDto = mock(FloodRemapDto.class);
        when(floodRemapDto.getTmTaskId()).thenReturn(TM_TASK_ID);
        EmailAttachments attachments = mock(EmailAttachments.class);
        when(emailAttachmentsBucket.popEmailAttachments(TM_TASK_ID)).thenReturn(attachments);
        List<MultipartFile> files = new ArrayList<>();
        MultipartFile file = mock(MultipartFile.class);
        files.add(file);
        when(attachments.getAllFilesAsList()).thenReturn(files);
        mockMvc.perform(post("/admin/floodRemap/createRecord")
                .sessionAttr("floodRemapDto", floodRemapDto))
                .andExpect(status().is3xxRedirection())
                .andExpect(view().name("redirect:/admin/confirmation"));
        verify(floodRemapDto).setSFHDF(file);
        verify(floodRemapAdminService).processCreateNewRemap(floodRemapDto);
    }

    @Test
    public void testLaunchAdminHomeNonProd() throws Exception {
        when(env.getActiveProfiles()).thenReturn(new String[] { "LOCAL" });
        mockMvc.perform(get("/admin"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/index"));
    }

    @Test
    public void testLaunchAdminHomeProd() throws Exception {
        when(env.getActiveProfiles()).thenReturn(new String[] { "PROD" });
        mockMvc.perform(get("/admin"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/prod-admin-index"));
    }

    @Test
    public void testLaunchOperateAdminPageNonProd() throws Exception {
        when(env.getActiveProfiles()).thenReturn(new String[] { "LOCAL" });
        mockMvc.perform(get("/admin2"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/operateadmin"));
    }

    @Test
    public void testLaunchOperateAdminPageProd() throws Exception {
        when(env.getActiveProfiles()).thenReturn(new String[] { "PROD" });
        mockMvc.perform(get("/admin2"))
                .andExpect(status().isOk())
                .andExpect(view().name("/index"));
    }

    @Test
    public void testGetFloodZoneOptions() throws Exception {
        FloodRemapDto floodRemapDto = mock(FloodRemapDto.class);
        Set<String> floodZoneOptions = Sets.newSet("A", "V");
        when(floodRemapDto.getRevisedFloodZoneOptions("IN")).thenReturn(floodZoneOptions);
        mockMvc.perform(get("/admin/floodRemap/getFloodZoneOptions")
                .param("remapType", "IN")
                .sessionAttr("floodRemapDto", floodRemapDto))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("[0].floodZone").value("A"))
                .andExpect(jsonPath("[1].floodZone").value("V"));
    }

    @Test
    public void testLaunchAdminConfirmation() throws Exception {
        mockMvc.perform(get("/admin/confirmation"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/confirmation"));
    }

    @Test
    public void testManageBatchJobs() throws Exception {
        List<BatchCtrl> batches = new ArrayList<>();
        when(batchCtrlRepository.findByCanHoldReleaseFlag('Y')).thenReturn(batches);
        mockMvc.perform(get("/admin/manageBatchJobs"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/manageBatchJobs"))
                .andExpect(model().attributeExists("batchJobMaintenanceData"));
    }

    @Test
    public void testUpdateBatchJobHold() throws Exception {
        BatchJobMaintenanceData batchJobMaintenanceData = mock(BatchJobMaintenanceData.class);
        List<BatchCtrl> batches = new ArrayList<>();
        BatchCtrl batchCtrl1 = new BatchCtrl();
        batchCtrl1.setRid(1L);
        batchCtrl1.setCtrlFlag('Y');
        batches.add(batchCtrl1);
        BatchCtrl batchCtrl2 = new BatchCtrl();
        batchCtrl2.setRid(2L);
        batchCtrl2.setCtrlFlag('Y');
        batches.add(batchCtrl2);
        when(batchJobMaintenanceData.getBatchCtrl()).thenReturn(batches);
        mockMvc.perform(post("/admin/updateBatchJob")
                .sessionAttr("batchJobMaintenanceData", batchJobMaintenanceData)
                .param("batchId", "1")
                .param("action", "hold"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/manageBatchJobs"))
                .andExpect(model().attributeExists("batchJobMaintenanceData"));
        ArgumentCaptor<BatchCtrl> batchCtrlCaptor = ArgumentCaptor.forClass(BatchCtrl.class);
        verify(batchCtrlRepository).save(batchCtrlCaptor.capture());
        assertThat(batchCtrlCaptor.getValue().getRid(), Is.is(1L));
        assertThat(batchCtrlCaptor.getValue().getCtrlFlag(), Is.is('N'));
    }

    @Test
    public void testUpdateBatchJobRelease() throws Exception {
        BatchJobMaintenanceData batchJobMaintenanceData = mock(BatchJobMaintenanceData.class);
        List<BatchCtrl> batches = new ArrayList<>();
        BatchCtrl batchCtrl1 = new BatchCtrl();
        batchCtrl1.setRid(1L);
        batchCtrl1.setCtrlFlag('Y');
        batches.add(batchCtrl1);
        BatchCtrl batchCtrl2 = new BatchCtrl();
        batchCtrl2.setRid(2L);
        batchCtrl2.setCtrlFlag('N');
        batches.add(batchCtrl2);
        when(batchJobMaintenanceData.getBatchCtrl()).thenReturn(batches);
        mockMvc.perform(post("/admin/updateBatchJob")
                .sessionAttr("batchJobMaintenanceData", batchJobMaintenanceData)
                .param("batchId", "2")
                .param("action", "release"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/manageBatchJobs"))
                .andExpect(model().attributeExists("batchJobMaintenanceData"));
        ArgumentCaptor<BatchCtrl> batchCtrlCaptor = ArgumentCaptor.forClass(BatchCtrl.class);
        verify(batchCtrlRepository).save(batchCtrlCaptor.capture());
        assertThat(batchCtrlCaptor.getValue().getRid(), Is.is(2L));
        assertThat(batchCtrlCaptor.getValue().getCtrlFlag(), Is.is('Y'));
    }
}
