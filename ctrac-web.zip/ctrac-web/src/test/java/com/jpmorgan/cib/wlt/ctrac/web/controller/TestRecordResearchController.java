package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EntitlementRoles;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.UsersRepository;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import com.jpmorgan.cib.wlt.ctrac.rules.CtracJUnitTestRule;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapResearchDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.impl.UserEntitlementsImpl;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import com.jpmorgan.cib.wlt.ctrac.service.security.CtracGrantedAuthority;
import com.jpmorgan.cib.wlt.ctrac.service.security.CtracUserDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import org.springframework.web.util.NestedServletException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class TestRecordResearchController extends AbstractTestFloodRemapController{
	@InjectMocks
	//@Spy
	RecordResearchController recordResearchController;
	
	@Mock private FloodRemapService floodRemapService;
	
	@Mock private EmailAttachmentsBucket emailAttachmentsBucket;
	
	@Mock private CollateralManagementService collateralManagementService;
	
	@Mock private CollateralDetailsStatusService collateralDetailsStatusService;

	@Mock private UserEntitlementService userEntitlementService;
	
	private MessageSource messageSource = CTRAC_JUNIT_TEST_RULE.getErrorMessageSource();

	@Mock private MockHttpSession session;
	
	@Mock private MockHttpServletRequest request;

	@Rule
	public ExpectedException thrown= ExpectedException.none();

	@ClassRule
	public static CtracJUnitTestRule CTRAC_JUNIT_TEST_RULE = new CtracJUnitTestRule();

	private static final String VERIFIER_AUTHORITY = EntitlementRoles.VERIFER_ROLE;
	private static final String READER_AUTHORITY = EntitlementRoles.READER_ROLE;
	private static final String LOB = "BB";
	private static final String CONST_SID = "sid";
	private static final String CONST_FIRST_NAME = "firstName";
	private static final String CONST_LAST_NAME = "lastName";
	@InjectMocks private UserEntitlementsImpl userEntitlementsImpl;
	@Mock private CtracUserDetailsService ctracUserDetailsService;
	@Mock private UsersRepository usersRepository;
	@Mock private Environment env;
	@Before
	public void setUp(){
		Mockito.reset(floodRemapService);
		Mockito.reset(collateralManagementService);
		Mockito.reset(collateralDetailsStatusService);
		Mockito.reset(userEntitlementService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				recordResearchController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		ReflectionTestUtils.setField(recordResearchController,"messageSource",CTRAC_JUNIT_TEST_RULE.getErrorMessageSource());
		//setupSessionRequest();
	}
	
	@Test
	public void testLaunchResearchItemHelper() throws Exception{
		FloodRemapResearchDto floodRemapResearchDto=mockFloodRemapDto();
		doReturn(floodRemapResearchDto).when(floodRemapService).populateResearchItemData(any(TMParams.class));

		mockMvc.perform(
				get("/floodRemap/launchResearchItemHelper")
						.sessionAttr("tmParams", floodRemapResearchDto.getTmParams()))
				.andExpect(status().isOk())
				.andExpect(view().name("workflows/floodremap/researchItem"))
				.andExpect(model().attribute("floodRemapResearchDto",floodRemapResearchDto ));
	}
	
	@Test
	public void testResearchItemSubmit() throws Exception{
		FloodRemapResearchDto floodRemapResearchDto=mockFloodRemapDto();
		EmailAttachments attachments=new EmailAttachments("abcd");
		doNothing().when(floodRemapService).processResearchResponse(floodRemapResearchDto);
		String url ="/displayconfirmationItem/?confirmation=researchitem.save.confirmation";
		Users user = Mockito.mock(Users.class);
		when(user.getSid()).thenReturn(CONST_SID);
		when(user.getFirstName()).thenReturn(CONST_FIRST_NAME);
		when(user.getLastName()).thenReturn(CONST_LAST_NAME);
		when(usersRepository.findByUsernameIgnoreCaseAndEnabled(CONST_SID, true)).thenReturn(user);
		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new CtracGrantedAuthority("TEST", VERIFIER_AUTHORITY, LOB));
		when(ctracUserDetailsService.loadMyUserAuthorities(CONST_SID)).thenReturn(authorities);
		UserEntitlementsDTO actual = userEntitlementsImpl.getByJanusUsername(CONST_SID);
		when(userEntitlementService.getByJanusUsername(any(String.class))).thenReturn(actual);
		when(messageSource.getMessage(eq("researchitem.save.confirmation"), isNull(),isNull())).thenReturn("researchitem.save.confirmation");
		mockMvc.perform(
				post("/floodRemap/recordResearchItemResponse/{taskId}",1L)
						.sessionAttr("floodRemapResearchDto",floodRemapResearchDto)
						.sessionAttr("tmParams", floodRemapResearchDto.getTmParams()))
				.andExpect(status().is3xxRedirection())
				.andExpect(redirectedUrl(url));
	}
	@Test
	public void testResearchItemSubmitForNonVerifier() throws Exception{
		FloodRemapResearchDto floodRemapResearchDto=mockFloodRemapDto();
		EmailAttachments attachments=new EmailAttachments("abcd");
		String url ="/displayconfirmationItem/?confirmation=researchitem.save.confirmation";
		Users user = Mockito.mock(Users.class);
		when(user.getSid()).thenReturn(CONST_SID);
		when(user.getFirstName()).thenReturn(CONST_FIRST_NAME);
		when(user.getLastName()).thenReturn(CONST_LAST_NAME);
		when(usersRepository.findByUsernameIgnoreCaseAndEnabled(CONST_SID, true)).thenReturn(user);
		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new CtracGrantedAuthority("TEST", READER_AUTHORITY, LOB));
		when(ctracUserDetailsService.loadMyUserAuthorities(CONST_SID)).thenReturn(authorities);
		UserEntitlementsDTO actual = userEntitlementsImpl.getByJanusUsername(CONST_SID);
		when(userEntitlementService.getByJanusUsername(any(String.class))).thenReturn(actual);
		when(messageSource.getMessage(eq("E0360"), isNull(), any(Locale.class))).thenReturn("You are not authorized to verify the data.");
		thrown.expect(NestedServletException.class);
		thrown.expectMessage("CTRAC_APPLICATION ERROR:  You are not authorized to verify the data.");
		mockMvc.perform(
				post("/floodRemap/recordResearchItemResponse/{taskId}",1L)
						.sessionAttr("floodRemapResearchDto",floodRemapResearchDto)
						.sessionAttr("tmParams", floodRemapResearchDto.getTmParams()))
				.andExpect(status().is3xxRedirection())
				.andExpect(redirectedUrl(url));
	}
	public void testIsValidForLinking(){
		//need to work
	}
	
	@Test
	public void testGetCollateralDescription() throws Exception{
		FloodRemapResearchDto floodRemapResearchDto=mockFloodRemapDto();
		
		mockMvc.perform(
				post("/floodRemap/getCollateralDescription")
						.sessionAttr("floodRemapResearchDto",floodRemapResearchDto)
						.sessionAttr("tmParams", floodRemapResearchDto.getTmParams()))
				.andExpect(status().isOk());
		
	}
	
	private FloodRemapResearchDto mockFloodRemapDto(){
		FloodRemapResearchDto floodRemapDto=new FloodRemapResearchDto();
		floodRemapDto.setCurrentWorkflowStep(WorkflowStateDefinition.VERIFY_RESEARCH.getName());
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("O641754");
		floodRemapDto.setTmParams(tmParams);
		return floodRemapDto;
	}
}
