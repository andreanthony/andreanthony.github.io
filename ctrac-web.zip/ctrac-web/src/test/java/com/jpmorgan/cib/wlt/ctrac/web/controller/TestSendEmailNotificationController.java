package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;

import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.GenericEmailData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;

@RunWith(MockitoJUnitRunner.class)
public class TestSendEmailNotificationController extends AbstractTestFloodRemapController{
	@Mock private LenderPlaceService lenderPlaceService;
	@Mock private FloodRemapService floodRemapService;
	
	@InjectMocks
	@Spy
	SendEmailNotifcationController sendEmailNotificationController;
	
	@Before
	public void setUp(){
		Mockito.reset(floodRemapService);
		Mockito.reset(lenderPlaceService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				sendEmailNotificationController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();

	}
	
	@Test
	public void testLaunchSendMarketRefundEmailHelper() throws Exception{
		GenericEmailData floodRemapSendEmailData=mockFloodRemapSendEmailData(CtracAppConstants.FLOOD_REMAP_SEND_MARKET_REFUND_EMAIL_SCREEN_ID,"Send Market Refund Email");
		TMParams tmParams=mockTmParams();
		doReturn(floodRemapSendEmailData).when(lenderPlaceService).prepareSendMarketRefundEmail(tmParams);
		mockMvc.perform(
				get("/floodRemap/launchSendMarketRefundEmailHelper")
						.sessionAttr("tmParams", tmParams))
				.andExpect(status().isOk())
				.andExpect(view().name("floodRemapReadOnlyEmail"))
				.andExpect(model().attribute("floodRemapSendEmailData",floodRemapSendEmailData ));
	}
	
	private TMParams mockTmParams(){
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("O641754");
		return tmParams;		
	}
	
	private GenericEmailData mockFloodRemapSendEmailData(String screenID,String pageTitle){
		GenericEmailData floodRemapSendEmailData=new GenericEmailData();
		floodRemapSendEmailData.setScreenId(screenID);
		floodRemapSendEmailData.setPageTitle(pageTitle);
		return floodRemapSendEmailData;
	}
}
