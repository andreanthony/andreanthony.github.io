package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.CommonTaskService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CompleteItemData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;

import javax.servlet.http.Cookie;


@RunWith(MockitoJUnitRunner.class)
public class TestCompleteItemController extends AbstractTestFloodRemapController{

	@Mock
	private CommonTaskService commonTaskService;
	
	@Mock
	private PerfectionTaskRepository perfectionTaskRepository;
	
	@InjectMocks
	@Spy
	CompleteItemController completeItemController;
	
	@Before
	public void setUp(){
		Mockito.reset(commonTaskService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				completeItemController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	//cases where normal complete item will not be shown for the workflow step
	@Test
	public void launchCompleteItemHelper_FloodRemap() throws Exception{
		mockMvc.perform( get("/floodRemap/launchCompleteItemHelper").param("id_task", "1L").param("tmReturn", "testUrl").param("workflowStep", "testWorkflowStep").session(session))
		.andExpect(status().isOk()).andExpect(view().name("floodRemapConfirmation"))
		.andExpect(model().attribute("confirmation",messageSource.getMessage("completeItem.generic.alternate.message", null, null)));
	}
	
	//cases where normal complete item will not be shown for the workflow step
	@Test
	public void launchCompleteItemHelper_FloodInsurance() throws Exception{
		mockMvc.perform( get("/floodInsurance/launchCompleteItemHelper").param("id_task", "1L").param("tmReturn", "testUrl").param("workflowStep", "testWorkflowStep").session(session))
		.andExpect(status().isOk()).andExpect(view().name("floodRemapConfirmation"))
		.andExpect(model().attribute("confirmation",messageSource.getMessage("completeItem.generic.alternate.message", null, null)));
	}

	@Test
	public void testCompleteRemapTasks() throws Exception{
		CompleteItemData completeItemData = mockCompleteItemData();
		doNothing().when(commonTaskService).processCompleteItem(any(CompleteItemData.class));
		mockMvc.perform(post("/floodRemap/completeItem/{taskId}", 1L).param("save", "save")
				.sessionAttr("completeItemData", completeItemData)
				.sessionAttr("tmParams",completeItemData.getTmParams())
				.sessionAttr("JANUS_USER_ID", "testUUID")
				.cookie(new Cookie("cookie","test")))
		.andExpect(status().isOk())		
		.andExpect(view().name("floodRemapConfirmation"))
		.andExpect(model()
				.attribute("confirmation", messageSource.getMessage("completeitem.submit.OtherConfirmation", null, null)));
	}
	
	private CompleteItemData mockCompleteItemData(){
		CompleteItemData completeItemData = new CompleteItemData();
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("O641754");
		completeItemData.setTmParams(tmParams);
		return completeItemData;
	}
}
