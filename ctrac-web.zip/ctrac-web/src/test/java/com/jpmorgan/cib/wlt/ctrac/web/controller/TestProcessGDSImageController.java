package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.jpmorgan.cib.wlt.ctrac.batch.scheduler.TaskOnDemandScheduler;


@RunWith(MockitoJUnitRunner.class)
public class TestProcessGDSImageController extends AbstractTestFloodRemapController {
	
	@InjectMocks
	@Spy
	protected FloodRemapCommonController floodRemapCommonController;
	
	@Mock
	TaskOnDemandScheduler taskOnDemandScheduler;
	
	@Before
	public void setUp() {
		Mockito.reset(taskOnDemandScheduler);	
		mockMvc = MockMvcBuilders.standaloneSetup(floodRemapCommonController).build();
		setupSessionRequest();		
	}

	@Test
	@Ignore
	public void testRunProcessWireRequest() throws Exception {		
		doNothing().when(taskOnDemandScheduler).runProcessWireRequestJob(any(Boolean.class));		
		mockMvc.perform( get("/floodRemap/runProcessGDSImage").session(session))
		.andExpect(status().isOk()).andExpect(view().name("floodRemapConfirmation"));		
	}
}
