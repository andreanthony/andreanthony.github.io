/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.web.controller;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.WireRequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AccountWireReferenceDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;



/**
 * @author q003321
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TestCreateWireRequestController extends
		AbstractTestFloodRemapController {
	

	@InjectMocks
	protected CreateWireRequestController createWireRequestController;
	
	@Mock
	WireProcessingService wireProcessingService;

	@Rule
    public ExpectedException thrown= ExpectedException.none();

	@Before
	public void setUp() {				
		
		Mockito.reset(wireProcessingService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				createWireRequestController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		setupSessionRequest();		
	}

	/**
	 * This method is  to test Create Wire Request Helper page
	 * 
	 * 
	 */
	@Test
	@Ignore
	public void testCreateWireRequestHelper() throws Exception {
		mockStaticCreateTMHelperMethod(createWireRequestController);
		WireRequestData wireRequestData  = new 	WireRequestData();
		doReturn( wireRequestData ).when(wireProcessingService).prepareCreateWireRequestPage(any(TMParams.class));
		
		mockMvc.perform( get("/floodRemap/launchCreateWireRequestHelper")
				.param("id_task", "1L").param("tmReturn", "testUrl").param("workflowStep", "testWorkflowStep").session(session))
		.andExpect(status().isOk())
		.andExpect(view().name("createWireRequest"))
		.andExpect(model().attribute("wireRequestData", hasProperty("screenId", is(CtracAppConstants.WIRE_CREATE_REQUEST_SCREEN_ID))) );		
		wireRequestData.setTmParams(null);
		
	
	}
	
	/**
	 * This method is  to test Unlock TM from Wire Request Helper page
	 * 
	 * 
	 */
	@Test 
	@Ignore
	public void testUnLockTMTask() throws Exception{
		mockStaticCreateTMHelperMethod(createWireRequestController);
		WireRequestData wireRequestData = getDummyWireRequestData();
		mockMvc.perform(
				get("/floodRemap/createWireRequest/unLockTMTask")
						.sessionAttr("wireRequestData", wireRequestData))
				.andExpect(status().isOk())
				.andExpect(view().name("createWireRequest"));
		}
		
	/**
	 * This method is  to test Saving Create Wire Request Helper page
	 * 
	 * 
	 */
	@Test
	@Ignore
	public void testsubmitWireRequest() throws Exception {
		mockStaticCreateTMHelperMethod(createWireRequestController);
		WireRequestData wireRequestData = getDummyWireRequestData();		
		String resultMessage = "Wire request is saved.";			
		doNothing().when(wireProcessingService).processWireRequestInformation(any(WireRequestData.class));
		when(messageSource.getMessage("create.wire.request.submit.confirmation", null, null)).thenReturn(resultMessage);
		mockMvc.perform(post("/floodRemap/submitWireRequest/{taskId}", 1L).sessionAttr("wireRequestData", wireRequestData).sessionAttr("JANUS_USER_ID", "testUUID"))
		.andExpect(status().isOk())		
		.andExpect(view().name("floodRemapConfirmation"))
		.andExpect(model().attribute("confirmation", is(resultMessage)) );		
		
		wireRequestData.setTmParams(null);
		thrown.expectMessage("CTRAC_APPLICATION ERROR:  no message found");
		mockMvc.perform(post("/floodRemap/submitWireRequest/{taskId}", 1L).sessionAttr("wireRequestData", wireRequestData).sessionAttr("JANUS_USER_ID", "testUUID")).andExpect(status().isOk());

		
	}	
	
	//@Test 
	public void testRequiredFieldValidationErrors() throws Exception{
		
		mockStaticCreateTMHelperMethod(createWireRequestController);
		WireRequestData wireRequestData = getDummyWireRequestData();	//test mandatory fields  errors  	
		List <AccountWireReferenceDto>accountWireRef = new ArrayList<AccountWireReferenceDto>();
		AccountWireReferenceDto accountWireReferenceDto = new AccountWireReferenceDto();
		accountWireReferenceDto.setRequestNumber("    ");
		accountWireRef.add(accountWireReferenceDto);
		wireRequestData.setAccountWireReferences(accountWireRef);
		mockMvc.perform(post("/floodRemap/submitWireRequest/{taskId}", 1L).sessionAttr("wireRequestData", wireRequestData).sessionAttr("JANUS_USER_ID", "testUUID"))
		.andExpect(status().isOk())
		.andExpect(model().attributeHasFieldErrors("wireRequestData", "requestNumber"))
		.andExpect(view().name("createWireRequest"));
		
	}	
	/**
	 * This method is  to populate the WireRequestData object to test the class
	 * 
	 * 
	 */
	private WireRequestData getDummyWireRequestData()
	{
		WireRequestData wireRequestData = new WireRequestData();
		wireRequestData.setPerfectionTaskId(1L);		
		wireRequestData.setScreenId(CtracAppConstants.WIRE_CREATE_REQUEST_SCREEN_ID);
		wireRequestData.setNextWorkFlowStep("createWireRequest");		
		TMParams params = new TMParams();
		params.setId_task("1L");
		params.setUserId("R534840");
		// this is supposed to be populated in the controller
		params.setTmTransactionId("testTransactionId");
		params.setWorkflowStep("testWorkflowStep");
		wireRequestData.setTmParams(params);
		wireRequestData.setAccountWireReferences(getDummyAccountWireReferenceDto());
		return wireRequestData;
		
	}
	/**
	 * This method is  to populate the AccountWireReferenceDto object to test the class
	 * 
	 * 
	 */
	private List<AccountWireReferenceDto> getDummyAccountWireReferenceDto()
	{
	List <AccountWireReferenceDto>accountWireRef = new ArrayList<AccountWireReferenceDto>();
		AccountWireReferenceDto dto = new AccountWireReferenceDto();
		dto.setAccountingSystem("AXB");
		dto.setAccountWireReferenceId(1L);		
		dto.setCreatedDate(new Date());
		dto.setFilename("test");
		dto.setRequestNumber("asdf");	
		accountWireRef.add(dto);
		return accountWireRef;
	}


}
