package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VerifyLetterData;

@RunWith(MockitoJUnitRunner.class)
public class TestFloodRemapVendorInsuranceController extends AbstractTestFloodRemapController{
	@Rule
    public ExpectedException thrown= ExpectedException.none();
	
	@InjectMocks
	@Spy
	private FloodRemapVendorInsuranceController floodRemapVendorInsuranceController;
	
	@Before
	public void setUp(){
		Mockito.reset(floodInsurancePolicyService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				floodRemapVendorInsuranceController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	@Test
	@Ignore
	public void testLaunchVerifyVendorInsuranceHelper() throws Exception{
		mockStaticCreateTMHelperMethod(floodRemapVendorInsuranceController);
		VerifyLetterData verifyLetterData=getMockVerifyLetterData();
		verifyLetterData.setScreenId("verifyVendorInsurance");
		doReturn(verifyLetterData).when(floodInsurancePolicyService).preparePolicyVerifyLetterDates(any(TMParams.class));
		mockMvc.perform( get("/floodRemap/launchVerifyVendorInsuranceHelper")
				.param("id_task", "1L").param("tmReturn", "testUrl").param("workflowStep", "testWorkflowStep").session(session))
		.andExpect(status().isOk())
		.andExpect(view().name("floodRemapVerifyVendorInsuranceInfo"))
		.andExpect(model().attribute("floodRemapVendorInsuranceData", hasProperty("screenId", is(CtracAppConstants.FLOOD_REMAP_VERIFY_VENDOR_INSURANCE))) );
	}
	
	//@Test
	public void testLaunchVerifyVendorCancellationHelper() throws Exception{
		mockStaticCreateTMHelperMethod(floodRemapVendorInsuranceController);
		VerifyLetterData verifyLetterData=getMockVerifyLetterData();
		verifyLetterData.setScreenId("FLOOD_INSURANCE_VERIFY_VENDOR_CANCELATION_LETTER");
		doReturn(verifyLetterData).when(floodInsurancePolicyService).preparePolicyVerifyLetterDates(any(TMParams.class));
		mockMvc.perform( get("/floodRemap/launchVerifyVendorCancellationHelper")
				.param("id_task", "1L").param("tmReturn", "testUrl").param("workflowStep", "testWorkflowStep").session(session))
		.andExpect(status().isOk())
		.andExpect(view().name("floodRemapVerifyVendorInsuranceInfo"))
		.andExpect(model().attribute("floodRemapVendorInsuranceData", hasProperty("screenId", is(CtracAppConstants.FLOOD_INSURANCE_VERIFY_VENDOR_CANCELATION_LETTER))) );
	}
	
	@Test
	public void testRecordVendorInsuranceDateofLetter() throws Exception {
		String resultMessage="Vendor letter date has been successfully confirmed";
		VerifyLetterData verifyLetterData=getMockVerifyLetterData();
		doNothing().when(floodInsurancePolicyService).processSaveDateOfLetter(any(VerifyLetterData.class),any(HttpServletRequest.class));
		when(messageSource.getMessage("vendor.insurance.submit.confirmation", null, null)).thenReturn(resultMessage);
		
		mockMvc.perform(post("/floodRemap/submitVerificationOfLetter/{taskId}", 1L).sessionAttr("floodRemapVendorInsuranceData", verifyLetterData).sessionAttr("JANUS_USER_ID", "testUUID")
				.cookie(new Cookie("cookie","test")))
		.andExpect(status().isOk())		
		.andExpect(view().name("floodRemapConfirmation"))
		.andExpect(model().attribute("confirmation", is(resultMessage)) );	

	}
	
	private VerifyLetterData getMockVerifyLetterData(){
		VerifyLetterData verifyLetterData=new VerifyLetterData();
		TMParams params = new TMParams();
		params.setId_task("1L");
		params.setUserId("R534840");
		verifyLetterData.setTmParams(params);
		return verifyLetterData;
	}
}
