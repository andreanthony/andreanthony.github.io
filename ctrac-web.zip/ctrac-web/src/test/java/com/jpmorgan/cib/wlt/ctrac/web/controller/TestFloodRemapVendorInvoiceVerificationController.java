package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition.AWAITING_REFUND_CONFIRMATION;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.lenderPlacement.VendorInvoiceData;

import javax.servlet.http.Cookie;

@RunWith(MockitoJUnitRunner.class)
public class TestFloodRemapVendorInvoiceVerificationController extends AbstractTestFloodRemapController{

	@Rule
    public ExpectedException thrown= ExpectedException.none();
	
	@InjectMocks
	@Spy
	private FloodRemapVendorInvoiceVerificationController floodRemapVendorInvoiceVerificationController;
	
	@Before
	public void setUp(){
		Mockito.reset(floodInsurancePolicyService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				floodRemapVendorInvoiceVerificationController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	//@Test
	public void testLaunchFloodVendorInvoiceHelper_CANCELLATION_COLLECT_VENDOR_REFUND() throws Exception{
		mockStaticCreateTMHelperMethod(floodRemapVendorInvoiceVerificationController);
		VendorInvoiceData vendorInvoiceData=getMockVendorInvoiceData(CtracAppConstants.FLOOD_REMAP_VENDOR_REFUND_CONFIRMATION_SCREEN_ID,AWAITING_REFUND_CONFIRMATION.getName());
		doReturn(vendorInvoiceData).when(floodInsurancePolicyService).prepareVendorInvoiceVerificationData(any(TMParams.class));
		
		mockMvc.perform( get("/floodRemap/launchFloodVendorInvoiceHelper")
				//.param("id_task", "1L")
				//.param("tmReturn", "testUrl")
				//.param("workflowStep", "testWorkflowStep")
				.sessionAttr("tmParams", vendorInvoiceData.getTmParams()))
		.andExpect(status().isOk()).andExpect(view().name("floodRemapVendorInvoiceVerification"))
		.andExpect(model().attribute("floodRemapVendorInvoiceVerificationData",hasProperty("screenId", is(CtracAppConstants.FLOOD_REMAP_VENDOR_REFUND_CONFIRMATION_SCREEN_ID)) ) );
	}
	
	@Test
	@Ignore
	public void testFloodRemapVendorInvoiceVerificationSaveAndContinue() throws Exception{
		mockStaticCreateTMHelperMethod(floodRemapVendorInvoiceVerificationController);
		VendorInvoiceData vendorInvoiceData=getMockVendorInvoiceData(null,null);
		doNothing().when(floodInsurancePolicyService).processSubmitVendorInvoiceVerification(any(VendorInvoiceData.class));
		
		String viewName="redirect:/floodRemap/launchSendMarketRefundEmailHelper"+vendorInvoiceData.getTmParams().toUrlParams();
		mockMvc.perform(post("/floodRemap/floodRemapVendorInvoice/{taskId}", 1L)
				.param("saveAndContinue", "saveAndContinue").sessionAttr("floodRemapVendorInvoiceVerificationData", vendorInvoiceData)
				.sessionAttr("JANUS_USER_ID", "testUUID"))
		//.andExpect(status().isOk())		
		.andExpect(view().name(viewName));
	}
	
	@Test
	public void testFloodRemapVendorInvoiceVerificationSubmit() throws Exception{
		VendorInvoiceData vendorInvoiceData=getMockVendorInvoiceData(null,null);
		String resultMessage="Vendor invoice verification information has been submitted successfully!";
		
		doNothing().when(floodInsurancePolicyService).processSubmitVendorInvoiceVerification(any(VendorInvoiceData.class));
		when(messageSource.getMessage("invoiceVerification.submit.confirmation", null, null)).thenReturn(resultMessage);
		
		mockMvc.perform(post("/floodRemap/floodRemapVendorInvoice/{taskId}", 1L)
				.param("process", "process").sessionAttr("floodRemapVendorInvoiceVerificationData", vendorInvoiceData)
				.sessionAttr("JANUS_USER_ID", "testUUID").cookie(new Cookie("cookie","test")))
		.andExpect(status().isOk())		
		.andExpect(view().name("floodRemapConfirmation"));
		
	}
		
	private VendorInvoiceData getMockVendorInvoiceData(String screenId,String workFlowStep){
		VendorInvoiceData vendorInvoiceData=new VendorInvoiceData();
		if(screenId!=null){
			vendorInvoiceData.setScreenId(screenId);
		}
		if(workFlowStep!=null){
			vendorInvoiceData.setCurrentWorkflowStep(workFlowStep);
		}
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("R534840");
		vendorInvoiceData.setTmParams(tmParams);
		return vendorInvoiceData;
	}
	
}
