package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.service.insurance.NfipProgramService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.servlet.ModelAndView;

import static org.junit.Assert.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.doReturn;

@RunWith(MockitoJUnitRunner.class)
public class TestNfipOperationController {

    @InjectMocks private NfipOperationController controller;
    @Mock private NfipProgramService nfipProgramService;

    @Before
    public void setup(){
    }

    @Test
    public void testLaunchOperationsAdministrationTrue(){
        doReturn(true).when(nfipProgramService).isNfipProgramActive();
        ModelAndView mav = controller.launchOperationsAdministration();
        assertEquals("/admin/nfipProgramOperation", mav.getViewName());
        assertEquals(true, mav.getModelMap().get("isNfip"));
        //Verify the service will get called to save the model
        verify(nfipProgramService, times(1)).isNfipProgramActive();
    }
    @Test
    public void testLaunchOperationsAdministrationFalse(){
        doReturn(false).when(nfipProgramService).isNfipProgramActive();
        ModelAndView mav = controller.launchOperationsAdministration();
        assertEquals("/admin/nfipProgramOperation", mav.getViewName());
        assertEquals(false, mav.getModelMap().get("isNfip"));
        //Verify the service will get called to save the model
        verify(nfipProgramService, times(1)).isNfipProgramActive();
    }
    @Test
    public void testSubmitOperationsAdministrationTrue(){
        doNothing().when(nfipProgramService).setNfipProgramActive(true);
        ModelAndView mav = controller.submitOperationsAdministration(true);
        assertEquals("NFIP Program status successfully updated to <strong>Active</strong>", mav.getModelMap().get("confirmation"));
        assertEquals("floodRemapConfirmation", mav.getViewName());
        //Verify the service will get called to save the model
        verify(nfipProgramService, times(1)).setNfipProgramActive(true);
    }
    @Test
    public void testSubmitOperationsAdministrationFalse(){
        doNothing().when(nfipProgramService).setNfipProgramActive(false);
        ModelAndView mav = controller.submitOperationsAdministration(false);
        assertEquals("NFIP Program status successfully updated to <strong>Expired</strong>", mav.getModelMap().get("confirmation"));
        assertEquals("floodRemapConfirmation", mav.getViewName());
        //Verify the service will get called to save the model
        verify(nfipProgramService, times(1)).setNfipProgramActive(false);
    }

 }
