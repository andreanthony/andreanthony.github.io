package com.jpmorgan.cib.wlt.ctrac.web.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;


@RunWith(MockitoJUnitRunner.class)
public class TestOperationsAdminController extends AbstractTestFloodRemapController{
	private static final String OPERATIONS_ADMINISTRATION_URL = "/admin/operationsAdministration";
	private static final String TASK_ADMINISTRATION_URL = "/admin/taskAdministration";
	private static final String RESTART_LETTER_CYCLE_URL = "/admin/restartLetterCycle";
	
	@InjectMocks
	OperationsAdminController operationsAdminController;
	
	@Before
	public void setUp(){
		mockMvc = MockMvcBuilders.standaloneSetup(
				operationsAdminController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	@Test
	public void testLaunchOperationsAdministration() throws Exception{
//		OperationsAdminDTO operationsAdminData = new OperationsAdminDTO();
//		mockMvc.perform( get("/admin/operationsAdministration")
//				.session(session))
//		.andExpect(status().isOk()).andExpect(view().name(OPERATIONS_ADMINISTRATION_URL))
//		.andExpect(model().attribute("operationsAdminData",operationsAdminData));
	}
}
