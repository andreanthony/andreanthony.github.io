package com.jpmorgan.cib.wlt.ctrac.web.init;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.DispatcherServlet;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * Created by V704662 on 9/13/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestWebAppStartupInitializer {

    @InjectMocks private WebAppStartupInitializer webAppStartupInitializer;
    @Mock private ServletContext servletContext;

    @Before
    public void setup(){
        ServletRegistration.Dynamic mockedServletRegistration = mock(ServletRegistration.Dynamic.class);
        given(servletContext.addServlet(eq("dispatcher"), any(DispatcherServlet.class))).willReturn(mockedServletRegistration);
    }

    /**
     * - onStartup
     * TestCase: Verify that on web application startup the Spring Character Encoding filter
     * is registered on the context with UTF-8 Encoding
     * @throws ServletException
     */
    @Test
    public void testOnStartupUTF8CharacterEncodingFilterRegistered() throws ServletException {
        //Captor the encoding filter that will be registered on the context
        ArgumentCaptor<CharacterEncodingFilter> charEncodingFilterArg = ArgumentCaptor.forClass(CharacterEncodingFilter.class);
        FilterRegistration.Dynamic testFilterRegistration = mock(FilterRegistration.Dynamic.class);
        given(servletContext.addFilter(eq("characterEncoding"), charEncodingFilterArg.capture())).willReturn(testFilterRegistration);

        //run app initializer
        webAppStartupInitializer.onStartup(servletContext);
        //Verify encoding is set
        verify(servletContext).addFilter(eq("characterEncoding"),any(CharacterEncodingFilter.class));
        assertNotNull(charEncodingFilterArg.getValue());
        assertThat(charEncodingFilterArg.getValue().getEncoding(),is("UTF-8"));
    }



}
