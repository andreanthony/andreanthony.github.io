package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanSystem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FileContent;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.aggregate.WireRequestData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AccountWireReferenceDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralDoc;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapResearchDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.bir.BorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.FloodDeterminationDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.InsurancePolicyRequirementDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.GenericProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ProofOfCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.hamcrest.core.Is;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by V704662 on 9/20/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestGenericAttachmentController {
    private static final String FILE_NAME = "file.pdf";

    @InjectMocks @Spy private GenericAttachmentController genericAttachmentController;
    @Mock private HttpServletRequest request;
    @Mock private HttpServletResponse response;
    @Mock private WireProcessingService wireProcessingService;
    private ServletOutputStream servletOutputStream;
    private MockMvc mockMvc;

    @Mock private CollateralDocumentRepository collateralDocumentRepository;
    @Mock private CollateralDetailsMainDto collateralDetailsData;
    @Mock private CollateralSectionDto collateralSectionDto;
    @Mock private List<CollateralDoc> mortgageDocs;
    @Mock private CollateralDoc collateralDoc;
    @Mock private CollateralDocument collateralDocument;
    @Mock private FileContent fileContent;
    @Mock private InsurancePolicyRequirementDto insurancePolicyRequirementDto;
    @Mock private FloodDeterminationDto floodHazardDeterminationDto;
    @Mock private ProofOfCoverageDTO proofOfCoverageData;
    @Mock private List<CollateralDocument> collateralDocuments;
    @Mock private BorrowerInsuranceReviewDTO borrowerInsuranceReviewData;
    @Mock private GenericProofOfCoverageDTO genericProofOfCoverageDTO;
    @Mock private FloodRemapResearchDto floodRemapResearchDto;
    @Mock private MultipartFile multipartFile;
    private byte[] fileContentBytes = "fileContentBytes".getBytes();

    @Before
    public void setup() throws IOException {
        //setup output stream mock on response
        servletOutputStream = mock(ServletOutputStream.class);
        given(response.getOutputStream()).willReturn(servletOutputStream);
        mockMvc = MockMvcBuilders.standaloneSetup(genericAttachmentController)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
        doNothing().when(genericAttachmentController).validatePdf(fileContentBytes);
    }

    /*Helper function to generate WireRequestData instance for given work flow step and has DTO object of accountWireReference*/
    private WireRequestData generateWireRequestDataInstance(String workFlowStep, AccountWireReferenceDto accountWireReferenceDto){
        WireRequestData wireRequestData = new WireRequestData();
        wireRequestData.setWorkFlowStep(workFlowStep);
        List<AccountWireReferenceDto> accountWireReferenceDtoList = new ArrayList<>();
        accountWireReferenceDtoList.add(accountWireReferenceDto);
        wireRequestData.setAccountWireReferences(accountWireReferenceDtoList);
        return wireRequestData;
    }

    /*Helper function to generate a AccountWireReferenceDto instance for given loan system*/
    private AccountWireReferenceDto generateAccountWireReferenceDtoInstance(String accountingSystem){
        AccountWireReferenceDto accountWireReferenceDto = new AccountWireReferenceDto();
        accountWireReferenceDto.setCreatedDate(new Date());
        accountWireReferenceDto.setAccountingSystem(accountingSystem);
        return accountWireReferenceDto;
    }

    /**
     * - getWireRequestDocument
     * TestCase: Verify that when controller endpoint /floodRemap/getCollectWireConfirmationDocument/{index}
     * has been called the service will be invoked to stream excel file for wire refund request
     */
    @Test
    public void testGetWireRequestDocumentRefundWire() throws IOException {
        byte[] expectedBytes = new byte[]{};
        AccountWireReferenceDto accountWireReferenceDTO = generateAccountWireReferenceDtoInstance(LoanSystem.ABLE.name());
        WireRequestData requestData = generateWireRequestDataInstance(WorkflowStateDefinition.CREATE_REFUND_REQUEST.getName()
                ,accountWireReferenceDTO);
        given(wireProcessingService.generateWireDocumentByAccountWireReference(accountWireReferenceDTO,
                WorkflowStateDefinition.CREATE_REFUND_REQUEST.getName())).willReturn(expectedBytes);

        genericAttachmentController.getWireRequestDocument(requestData,0,request, response);
        //verify expected bytes are written in the response
        verify(servletOutputStream).write(expectedBytes);
    }

    /**
     * - getWireRequestDocument
     * TestCase: Verify that when controller endpoint /floodRemap/getCollectWireConfirmationDocument/{index}
     * has been called the service will be invoked to stream excel file for wire request
     */
    @Test
    public void testGetWireRequestDocumentCreateWire() throws IOException {
        byte[] expectedBytes = new byte[]{};
        AccountWireReferenceDto accountWireReferenceDTO = generateAccountWireReferenceDtoInstance(LoanSystem.ABLE.name());
        WireRequestData requestData = generateWireRequestDataInstance(WorkflowStateDefinition.CREATE_WIRE_REQUEST.getName()
                ,accountWireReferenceDTO);
        given(wireProcessingService.generateWireDocumentByAccountWireReference(accountWireReferenceDTO,
                WorkflowStateDefinition.CREATE_WIRE_REQUEST.getName())).willReturn(expectedBytes);

        genericAttachmentController.getWireRequestDocument(requestData,0,request, response);
        //verify expected bytes are written in the response
        verify(servletOutputStream).write(expectedBytes);
    }

    @Test
    public void testGetMortgageDocumentForCollateral() throws Exception {
        when(collateralDetailsData.getCollateralSectionDto()).thenReturn(collateralSectionDto);
        when(collateralSectionDto.getMortgageDocs()).thenReturn(mortgageDocs);
        when(mortgageDocs.get(1)).thenReturn(collateralDoc);
        when(collateralDoc.getFileName()).thenReturn(FILE_NAME);
        when(collateralDoc.getFileContent()).thenReturn(fileContentBytes);
        mockMvc.perform(get("/collateralDetails/getMortgageDocument/1")
                .sessionAttr("collateralDetailsData", collateralDetailsData))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
        verify(genericAttachmentController).streamCollateralDocument(
                Mockito.eq(FILE_NAME), Mockito.eq(fileContentBytes), any(HttpServletResponse.class));
    }

    @Test
    public void testStreamFiatDocuments() throws Exception {
        when(collateralDocument.getFileName()).thenReturn(FILE_NAME);
        when(collateralDocument.getFileContent()).thenReturn(fileContent);
        when(fileContent.getFileContent()).thenReturn(fileContentBytes);
        when(collateralDocumentRepository.findOne(1L)).thenReturn(collateralDocument);
        mockMvc.perform(get("/collateralDetails/streamFiatDocuments/1")
                .sessionAttr("insurancePolicyRequirementDto", insurancePolicyRequirementDto))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
        verify(genericAttachmentController).streamCollateralDocument(
                Mockito.eq(FILE_NAME), Mockito.eq(fileContentBytes), any(HttpServletResponse.class));
    }

    @Test
    public void testStreamFloodDeterminationDocuments() throws Exception {
        when(collateralDoc.getDocRid()).thenReturn(1L);
        when(floodHazardDeterminationDto.getDeterminationDocument()).thenReturn(collateralDoc);
        when(collateralDocumentRepository.findOne(1L)).thenReturn(collateralDocument);
        when(collateralDocument.getFileName()).thenReturn(FILE_NAME);
        when(collateralDocument.getFileContent()).thenReturn(fileContent);
        when(fileContent.getFileContent()).thenReturn(fileContentBytes);
        mockMvc.perform(get("/collateralDetails/streamFloodDeterminationDocuments/")
                .sessionAttr("floodHazardDeterminationDto", floodHazardDeterminationDto))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
        verify(genericAttachmentController).streamCollateralDocument(
                Mockito.eq(FILE_NAME), Mockito.eq(fileContentBytes), any(HttpServletResponse.class));
    }

    @Test
    public void testGetInsuranceDocument() throws Exception {
        when(proofOfCoverageData.getPolicyDocuments()).thenReturn(collateralDocuments);
        when(collateralDocuments.get(1)).thenReturn(collateralDocument);
        when(collateralDocument.getFileName()).thenReturn(FILE_NAME);
        when(collateralDocument.getFileContent()).thenReturn(fileContent);
        when(fileContent.getFileContent()).thenReturn(fileContentBytes);
        mockMvc.perform(get("/admin/getInsuranceDocument/1")
                .sessionAttr("proofOfCoverageData", proofOfCoverageData))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
        verify(genericAttachmentController).streamCollateralDocument(
                Mockito.eq(FILE_NAME), Mockito.eq(fileContentBytes), any(HttpServletResponse.class));
    }

    @Test
    public void testGetBorrowerInsuranceDocument() throws Exception {
        when(borrowerInsuranceReviewData.getProofOfCoverageData()).thenReturn(genericProofOfCoverageDTO);
        when(genericProofOfCoverageDTO.getPolicyDocuments()).thenReturn(collateralDocuments);
        when(collateralDocuments.get(1)).thenReturn(collateralDocument);
        when(collateralDocument.getFileName()).thenReturn(FILE_NAME);
        when(collateralDocument.getFileContent()).thenReturn(fileContent);
        when(fileContent.getFileContent()).thenReturn(fileContentBytes);
        mockMvc.perform(get("/admin/getBorrowerInsuranceDocument/1")
                .sessionAttr("borrowerInsuranceReviewData", borrowerInsuranceReviewData))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
        verify(genericAttachmentController).streamCollateralDocument(
                Mockito.eq(FILE_NAME), Mockito.eq(fileContentBytes), any(HttpServletResponse.class));
    }

    @Test
    public void testStreamSFHDF() throws Exception {
        when(floodRemapResearchDto.getSFHDF()).thenReturn(multipartFile);
        when(multipartFile.getName()).thenReturn(FILE_NAME);
        when(multipartFile.getBytes()).thenReturn(fileContentBytes);
        mockMvc.perform(get("/researchItem/streamSFHDF")
                .sessionAttr("floodRemapResearchDto", floodRemapResearchDto))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
        verify(genericAttachmentController).streamCollateralDocument(
                Mockito.eq(FILE_NAME), Mockito.eq(fileContentBytes), any(HttpServletResponse.class));
    }

    @Test
    public void testGetCollateralDocument() throws Exception {
        when(collateralDocument.getFileName()).thenReturn(FILE_NAME);
        when(collateralDocument.getFileContent()).thenReturn(fileContent);
        when(fileContent.getFileContent()).thenReturn(fileContentBytes);
        when(collateralDocumentRepository.findOne(1L)).thenReturn(collateralDocument);
        mockMvc.perform(get("/getCollateralDocument")
                .param("collateralDocumentRid", "1"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
        verify(genericAttachmentController).streamCollateralDocument(
                Mockito.eq(FILE_NAME), Mockito.eq(fileContentBytes), any(HttpServletResponse.class));
    }
}
