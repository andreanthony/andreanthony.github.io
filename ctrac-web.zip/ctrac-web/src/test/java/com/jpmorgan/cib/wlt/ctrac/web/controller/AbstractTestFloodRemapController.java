package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import org.mockito.ArgumentMatcher;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.context.MessageSource;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.multipart.MultipartFile;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FileItem;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FloodRemapData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.email.EmailDataDto;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.tm.utils.TMUtility;

public abstract class AbstractTestFloodRemapController {
	protected MockMvc mockMvc;
	
	@Mock
	protected EmailAttachmentsBucket emailAttachmentsBucket;
	
	@Mock
	protected LenderPlaceService floodInsurancePolicyService;
	
	@Mock
	protected LookupCodeRepository lookupCodeRepository;

	@Mock
	protected TMUtility tmUtility;

	@Mock
	protected MessageSource messageSource;

	@Mock
	protected MockHttpSession session;

	@Mock
	protected MockHttpServletRequest request;

	@Mock
	protected List<LookUpCode> closeReasons;

	@Mock
	protected EmailDataDto emailDataDto;
	
	TMParams mockTmParams;

	//TODO mock setup in super class
	protected FloodRemapData floodRemapTask ;
	
	protected String staticTextTransationID ="someTransactionID"; 

	
	protected TMParams getDummyTMParams (String uuid, String returnUrl, String wfStep) {
		TMParams tmParams = new TMParams();
		tmParams.setId_task( uuid );  //"1L"//"testUUID"
		tmParams.setWorkflowStep( wfStep ); //
		//tmParams.setUserId("testUUID");
		//tmParams.setTmTransactionId(tmTransactionId);
		//tmParams.setScreenId(screenId);
		return tmParams ;
	}
	
	protected TMParams getDummyTMParams(){
		return getDummyTMParams("testUUID","testUrl", "Dummy_Workflow_Name") ;
	}
	

	
	protected void setupSessionRequest(){
		session.setAttribute("JANUS_USER_ID", "testUUID");
	}



	protected void mockStaticCreateTMHelperMethod(BaseController controller) {
		doAnswer(new Answer() {
			@Override
			public Object answer(InvocationOnMock invocationOnMock) throws Throwable {
				Object[] args = invocationOnMock.getArguments();
				TMParams tmParams1 = (TMParams) args[1];
				tmParams1.setTmTransactionId(staticTextTransationID);
				return tmParams1;
			}
		}).when(controller).lockTMTask(any(HttpServletRequest.class), any(TMParams.class));
	}

	
}
