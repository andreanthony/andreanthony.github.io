package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.RealEstateCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.web.controller.AbstractTestFloodRemapController;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import javax.servlet.http.Cookie;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertFalse;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by V704662 on 8/9/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestCollateralOwnerController extends AbstractTestFloodRemapController {

    @InjectMocks private CollateralOwnerController controller;
    @Mock private CollateralDetailsService collateralDetailsService;
    private Long ownerRid = 1L;
    private CustomerData customerData;
    private BindingResult bindingResult;

    @Before
    public void setup(){
            bindingResult = mock(BindingResult.class);
            customerData = mock(CustomerData.class);
        mockMvc = MockMvcBuilders.standaloneSetup(
                controller)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    /*Helper function to generate a CollateralDetailsMainDto instance for a given collateral*/
    private CollateralDetailsMainDto generateCollateralDetailsMainDtoInstance(Long collateralRid,boolean multipleCollateralOwners){
        CollateralDetailsMainDto collateralDetailsMainDto = new CollateralDetailsMainDto();
        CollateralDto collateralDto = new RealEstateCollateralDto();
        collateralDto.setRid(collateralRid);

        collateralDto.addAllOwners(stubCollateralOwner(multipleCollateralOwners));
        collateralDetailsMainDto.setCollateralDto(collateralDto);
        return collateralDetailsMainDto;
    }

    private List<CustomerData> stubCollateralOwner(boolean multipleCollateralOwners) {
        List<CustomerData> customerDataList = new ArrayList<CustomerData>();

        CustomerData ownerData = new CustomerData();
        ownerData.setBorrowerName("Harsha");
        ownerData.setRid(ownerRid);
        customerDataList.add(ownerData);
        if(multipleCollateralOwners) {
            ownerData = new CustomerData();
            ownerData.setBorrowerName("abc");
            customerDataList.add(ownerData);
        }
        return customerDataList;
    }

    /**
     * - saveCollateralOwner
     * TestCase: Verify that when the save collateral owner endpoint is called with no validation errors,
     * the service will get called to save the model in DB and success response is returned
     */
    @Test
    public void testSaveCollateralOwnerSuccess(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(1L,false);
        given(bindingResult.hasErrors()).willReturn(false);

        ResponseEntity<BaseApiResponse> response = controller.saveCollateralOwner
                (customerData,bindingResult,collateralDetailsMainDto);
        //Verify the service will get called to save the model
        verify(collateralDetailsService).saveCollateralSectionInfo(
                eq(collateralDetailsMainDto), eq(CollateralScreenAction.EDIT));

        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());
    }

    /**
     * - saveCollateralOwner
     * TestCase: Verify that when the save collateral owner endpoint is called with no validation errors,
     * the service will get called to save the model in DB and success response is returned
     */
    @Test
    public void testSaveCollateralOwnerValidationError(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(1L,false);
        //Mock an error in bindingResult
        List<ObjectError> errors = new ArrayList<>();
        errors.add(new FieldError("CollateralDetailsMainDto", "collateralDto.ownerData[0].borrowerName",
                "Invalid characters found"));
        given(bindingResult.hasErrors()).willReturn(true);
        given(bindingResult.getAllErrors()).willReturn(errors);

        ResponseEntity<BaseApiResponse> response = controller.saveCollateralOwner
                (customerData,bindingResult,collateralDetailsMainDto);
        //Verify the service will NOT get called to save the model
        verify(collateralDetailsService,never()).saveCollateralSectionInfo(
                any(CollateralDetailsMainDto.class), eq(CollateralScreenAction.EDIT));

        assertThat(response.getStatusCode(),is(HttpStatus.BAD_REQUEST));
        assertThat(response.getBody().getValidationErrors().get(0).getFieldId(),is("collateralDto.ownerData[0].borrowerName"));
        assertThat(response.getBody().getValidationErrors().get(0).getMessage(),is("Invalid characters found"));
        assertFalse(response.getBody().isSuccess());
    }


    @Test(expected = Exception.class)
    public void testDeleteCollateralWithSingleOwner(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(1L,false);

       controller.deleteCollateralOwner(customerData,collateralDetailsMainDto);

    }
    @Test
    public void testDeleteCollateralWithMultipleOwners(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(1L,true);
        String deleteResponse = controller.deleteCollateralOwner(customerData,collateralDetailsMainDto);
        assertEquals("admin/collateralDetailsSection :: collateralDetailsSection", deleteResponse);


    }

    @Test
    public void testLaunchCollateralOwnerForSingleOwner() throws Exception{

        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(1L,false);

        mockMvc.perform(get("/admin/editCollateralOwner?ownerRid="+ownerRid).sessionAttr("collateralDetailsData", collateralDetailsMainDto)
                .cookie(new Cookie("cookie","test")))
                .andExpect(status().isOk())
                .andExpect(model().attribute("collateralDetailsMainDto", collateralDetailsMainDto) );
    }

    @Test
    public void testLaunchCollateralOwnerForMultipleOwners() throws Exception{

        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(1L,true);

        mockMvc.perform(get("/admin/editCollateralOwner?ownerRid="+ownerRid).sessionAttr("collateralDetailsData", collateralDetailsMainDto)
                .cookie(new Cookie("cookie","test")))
                .andExpect(status().isOk())
                .andExpect(model().attribute("collateralDetailsMainDto", collateralDetailsMainDto) );
    }
}
