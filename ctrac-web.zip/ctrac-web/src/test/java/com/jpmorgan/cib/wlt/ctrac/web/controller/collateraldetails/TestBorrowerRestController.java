package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.ContactDetailDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CustomerData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by V704662 on 9/9/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestBorrowerRestController {

    @InjectMocks private BorrowerRestController controller;
    private MockMvc mockMvc;
    private static final String CONST_ADDRESS1="address 1";
    private static final String CONST_CITY="Chicago";
    private static final String CONST_ZIP="60611";
    private static final String CONST_STATE="IL";
    private static final String CONST_UNIT="unit 1";

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    /*Generate CustomerData object with given borrower name and dummy address*/
    private CustomerData generateCustomerData(String borrowerName){
        CustomerData customerData = new CustomerData();
        customerData.setBorrowerName(borrowerName);
        ContactDetailDto contactDetailDto = new ContactDetailDto();
        contactDetailDto.setAddress(generateAddressInstance());
        customerData.setContactDetailDto(contactDetailDto);
        return customerData;
    }

    /*Helper function to generate a dummy address*/
    private AddressDto generateAddressInstance(){
        AddressDto addressDto = new AddressDto();
        addressDto.setStreetAddress(CONST_ADDRESS1);
        addressDto.setCity(CONST_CITY);
        addressDto.setZipCode(CONST_ZIP);
        addressDto.setState(CONST_STATE);
        addressDto.setUnitOrBuilding(CONST_UNIT);
        return addressDto;
    }

    /**
     * - validateBorrower
     * Verify that when the API is called to validate the data entries for a borrower customer
     * the expected success result will be returned when no validation error was detected
     */
    @Test
    public void testValidateBorrowerDataSuccess() throws Exception {
        CustomerData borrower = generateCustomerData("test name");
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(borrower);

        mockMvc.perform(post("/admin/loan/borrower/validate")
                .contentType(APPLICATION_JSON_UTF8)
                .content(requestJson))
                .andExpect(jsonPath("$.success").value("true"))
                .andExpect(status().isOk());
    }

    /**
     * - validateBorrower
     * Verify that when the API is called to validate the data entries for a borrower customer
     * the expected Error result will be returned when validation errors was detected
     */
    @Test
    public void testValidateBorrowerDataFailure() throws Exception {
        //special character in borrower name
        CustomerData borrower = generateCustomerData("test ë");
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(borrower);

        mockMvc.perform(post("/admin/loan/borrower/validate")
                .contentType(APPLICATION_JSON_UTF8)
                .content(requestJson))
                .andExpect(jsonPath("$.success").value("false"))
                .andExpect(jsonPath("$.validationErrors").isArray())
                .andExpect(jsonPath("$.validationErrors[0].message").exists())
                .andExpect(status().is4xxClientError());
    }
}
