package com.jpmorgan.cib.wlt.ctrac.web.spring.dialect;

import com.jpmorgan.cib.wlt.ctrac.web.spring.dialect.CustomSpringDialect;
import com.jpmorgan.cib.wlt.ctrac.web.spring.processor.CustomSpringActionAttrProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.thymeleaf.context.ProcessingContext;
import org.thymeleaf.processor.IProcessor;

import java.util.Map;
import java.util.Set;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Created by V704662 on 7/14/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestCustomSpringDialect{

    private CustomSpringDialect springDialect = new CustomSpringDialect();


    /**
     * - getProcessors
     * TestCase: Verify that the custom spring dialect has only 1 processor assigned to it
     * and it is an instance of CustomSpringActionAttrProcessor
     */
    @Test
    public void test(){
        Set<IProcessor> processors = springDialect.getProcessors();
        assertThat(processors.size(),is(1));
        assertTrue(processors.toArray()[0] instanceof CustomSpringActionAttrProcessor);
    }

    /**
     * - getAdditionalExpressionObjects
     * TestCase: Verify that spring dialect will return "mvc" as additional expression objects
     */
    @Test
    public void testGetAdditionalExpressionObjects(){
        //Set up the context
        ProcessingContext processingContext = mock(ProcessingContext.class);

        Map<String, Object> response = springDialect.getAdditionalExpressionObjects(processingContext);
        assertThat(response.size(),is(1));
        assertTrue(response.containsKey("mvc"));
    }
}
