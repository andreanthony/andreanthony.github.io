package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.FileserverDTO;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class TestFileserverController {

    @Spy @InjectMocks private FileserverController controller;

    @Mock private Environment env;
    private ModelMap modelMock;

    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();


    private static final String CONST_TEST_FILE = "testFile.txt";
    private static final String CONST_TEST_OUTGOING_FOLDER = "testOutgoingFolder";
    private static final String CONST_LETTERS_PATH_KEY = "gdsLetters.xmlfile.outgoing.directory";
    private static final String CONST_LETTERS_PATH_LABEL = "GDS - Outgoing Letter XMLs";

    @Before
    public void setup(){
        modelMock = new ModelMap();
    }

    public void setupFileServerPathReading() throws IOException {
        //Create a temporary test file to read configuration for file server
        File output = temporaryFolder.newFile(CONST_TEST_FILE);
        writeToTestFile(output,CONST_LETTERS_PATH_KEY + ";" + CONST_LETTERS_PATH_LABEL);
        given(env.getRequiredProperty("fileserver.config")).willReturn(CONST_TEST_FILE);
        doReturn(output).when(controller).loadFileFrom(CONST_TEST_FILE);

        //Mock an Empty folder for our test
        File folderMock = mock(File.class);
        given(folderMock.listFiles()).willReturn(new File[]{});
        doReturn(folderMock).when(controller).loadFileFrom(CONST_TEST_OUTGOING_FOLDER);
        given(env.getRequiredProperty(CONST_LETTERS_PATH_KEY)).willReturn(CONST_TEST_OUTGOING_FOLDER);
    }


    private void writeToTestFile(File testFile, String text) throws IOException {
        FileWriter fileWriter = null;
        try{
            fileWriter = new FileWriter(testFile);
            fileWriter.write(text);
        }finally {
            if(fileWriter != null){
                fileWriter.close();
            }
        }
    }

    /**
     * - getFileserver
     * TestCase: When configuration is set that there is 1 available fileserver path,
     * then verify that the right path is present in the model
     * @throws IOException
     */
    @Test
    public void testGetFileserver_OneConfiguredFileServerPath() throws IOException {
        setupFileServerPathReading();
        assertThat(controller.getFileserver(modelMock),is("/admin/fileserver"));
        List<FileserverDTO> fileserverDTOList = (List<FileserverDTO>) modelMock.get("fileserverDTOs");
        assertNotNull(fileserverDTOList);
        assertThat(fileserverDTOList.get(0).getPropertyKey(),is(CONST_LETTERS_PATH_KEY));
        assertThat(fileserverDTOList.get(0).getLabel(),is(CONST_LETTERS_PATH_LABEL));
    }


    /**
     * - uploadFile
     * TestCase: When uploading a new file to an empty folder, we expect that the file will be there after uploading
     */
    @Test
    public void testUploadFile() throws IOException {
        //Create a temporary Test file for uploading
        File testUploadFile = temporaryFolder.newFile("test_File.txt");
        writeToTestFile(testUploadFile,"test");
        FileInputStream fileInputStream = new FileInputStream(testUploadFile);
        //Mock a MultipartFile with input stream of temporary test file
        MultipartFile multipartFile = mock(MultipartFile.class);
        given(multipartFile.getOriginalFilename()).willReturn("test_File.txt");
        given(multipartFile.getInputStream()).willReturn(fileInputStream);
        given(multipartFile.isEmpty()).willReturn(false);

        //Create a mock for a landing folder that does not have any files yet
        List<FileserverDTO> fileserverDTOList = new ArrayList<>();
        File folderMock = mock(File.class);
        given(folderMock.listFiles()).willReturn(new File[]{});
        fileserverDTOList.add(new FileserverDTO(CONST_LETTERS_PATH_KEY,folderMock,CONST_LETTERS_PATH_LABEL));

        File tempFile = temporaryFolder.newFile("test_File_temp.txt");
        doReturn(tempFile).when(controller).loadFileFrom("test_File.txt");

        //Create a temporary Test destination folder for uploading
        File tempDestinationFolder = temporaryFolder.newFolder(CONST_TEST_OUTGOING_FOLDER);
        doReturn(tempDestinationFolder).when(controller).loadFileFrom(CONST_TEST_OUTGOING_FOLDER);
        given(env.getRequiredProperty(CONST_LETTERS_PATH_KEY)).willReturn(CONST_TEST_OUTGOING_FOLDER);

        assertThat(controller.uploadFile(0,multipartFile, fileserverDTOList),is("redirect:/admin/fileserver"));
        assertThat(tempDestinationFolder.listFiles().length,is(1));

    }

}
