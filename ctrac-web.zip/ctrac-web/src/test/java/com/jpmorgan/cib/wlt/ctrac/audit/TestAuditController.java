package com.jpmorgan.cib.wlt.ctrac.audit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.AuditService;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditEntrySearchCriteria;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditRetrieveResult;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.refEq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestAuditController {

    private static final ObjectWriter OBJECT_WRITER =
            new ObjectMapper().configure(SerializationFeature.WRAP_ROOT_VALUE, false).writerWithDefaultPrettyPrinter();

    private static final Long COLLATERAL_ID = 1L;

    @InjectMocks
    private AuditController testObj;

    @Mock
    private AuditService auditService;

    private static final String API = "/api/audit";

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(testObj).build();
    }

    @Test
    public void testRetrieve() throws Exception {
        List<AuditEventDTO> expectedAuditEntries = new ArrayList<>();
        expectedAuditEntries.add(getAuditEventDTO("type1"));
        expectedAuditEntries.add(getAuditEventDTO("type2"));
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setCollateralId(COLLATERAL_ID);
        when(auditService.retrieve(refEq(criteria))).thenReturn(new AuditRetrieveResult(expectedAuditEntries,expectedAuditEntries.size()));
        mockMvc.perform(get(API)
                .contentType(APPLICATION_JSON_UTF8)
                .param("collateralId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("auditData[0].collateralId").value("1"))
                .andExpect(jsonPath("auditData[0].eventType").value("type1"))
                .andExpect(jsonPath("auditData[1].collateralId").value("1"))
                .andExpect(jsonPath("auditData[1].eventType").value("type2"));
        verify(auditService).retrieve(refEq(criteria));
    }

    @Test
    public void testCreate() throws Exception {
        AuditEventDTO auditEventDTO = new AuditEventDTO();
        String requestJson = OBJECT_WRITER.writeValueAsString(auditEventDTO);
        mockMvc.perform(post(API)
                .contentType(APPLICATION_JSON_UTF8)
                .content(requestJson))
                .andExpect(status().isOk());
        verify(auditService).create(refEq(auditEventDTO));
    }

    private AuditEventDTO getAuditEventDTO(String eventType) {
        AuditEventDTO auditEventDTO = new AuditEventDTO();
        auditEventDTO.setCollateralId(COLLATERAL_ID);
        auditEventDTO.setEventType(eventType);
        return auditEventDTO;
    }
}
