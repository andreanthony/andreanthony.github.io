package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.service.admin.TaskAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.TaskAdminDTO;

@RunWith(MockitoJUnitRunner.class)
public class TestTaskAdminController extends AbstractTestFloodRemapController{
	@Mock
	private TaskAdminService taskAdminService;
	
	@InjectMocks
	TaskAdminController taskAdminController;
	
	private static final String TASK_ADMINISTRATION_URL = "/admin/taskAdministration";
	
	@Before
	public void setUp(){
		Mockito.reset(taskAdminService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				taskAdminController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	@Test
	public void testLaunchTaskAdministration() throws Exception{
//		TaskAdminDTO taskAdminData = new TaskAdminDTO();
//		doReturn(taskAdminData).when(taskAdminService).prepareTaskAdminData();
//		mockMvc.perform( get("/admin/taskAdministration")
//				.session(session))
//		.andExpect(status().isOk()).andExpect(view().name(TASK_ADMINISTRATION_URL))
//		.andExpect(model().attribute("taskAdminData",taskAdminData));
	}
	
	@Test
	public void testValidateTaskAdministration(){
		
	}
	
	@Test
	public void testSubmitTaskAdministration(){
		
	}
	
}
