package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.service.admin.LoanBorrowerAddressService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.LoanBorrowerAddressDTO;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.LoanBorrowerSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.SectionStatusDto;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.Collection;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@RunWith(MockitoJUnitRunner.class)
public class TestLoanBorrowerController {

    @InjectMocks
    private LoanBorrowerController testObj;

    @Mock
    private CollateralDetailsService collateralDetailsService;

    @Mock
    private CollateralDetailsStatusService collateralDetailsStatusService;

    @Mock
    private LoanBorrowerAddressService loanBorrowerAddressService;

    private MockMvc mockMvc;

    @Mock private CollateralDetailsMainDto collateralDetailsMainDto;
    @Mock private CollateralDto collateralDto;
    @Mock private LoanBorrowerSectionDto loanSection;
    @Mock private Collection<LoanData> activeLoansData;
    @Mock private LoanData loanData;
    @Mock private SectionStatusDto sectionStatusDto;

    @Before
    public void setup(){
        when(collateralDetailsMainDto.getLoanBorrowerSectionData()).thenReturn(loanSection);
        when(collateralDetailsMainDto.getCollateralDto()).thenReturn(collateralDto);
        when(loanSection.getloanData(10L)).thenReturn(loanData);
        when(loanSection.getSectionStatusDto()).thenReturn(sectionStatusDto);
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testLaunchEditLoanBorrowerEdit() throws Exception {
        when(collateralDto.getCollateralStatus()).thenReturn(CollateralStatus.PLEDGED);
        when(loanData.getStatus()).thenReturn(LoanStatus.PENDING_VERIFICATION);
        when(loanData.getPrimaryFlag()).thenReturn("Yes");
        when(loanSection.getActiveLoansData()).thenReturn(activeLoansData);
        when(activeLoansData.size()).thenReturn(1);
        mockMvc.perform(get( "/admin/editLoanBorrower")
                .param("loanId", "10")
                .param("mode", "1")
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("loanBorrowerModal"))
                .andExpect(model().attribute("loansData", loanData));
        verify(loanData).setDisplayReleaseDate(true);
        verify(loanSection).setVerifyMode(false);
    }

    @Test
    public void testLaunchEditLoanBorrowerVerify() throws Exception {
        when(collateralDto.getCollateralStatus()).thenReturn(CollateralStatus.PLEDGED);
        when(loanData.getStatus()).thenReturn(LoanStatus.PENDING_VERIFICATION);
        when(loanData.getPrimaryFlag()).thenReturn("Yes");
        when(loanSection.getActiveLoansData()).thenReturn(activeLoansData);
        when(activeLoansData.size()).thenReturn(1);
        mockMvc.perform(get( "/admin/editLoanBorrower")
                .param("loanId", "10")
                .param("mode", "2")
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("loanBorrowerModal"))
                .andExpect(model().attribute("loansData", loanData));
        verify(loanData).setDisplayReleaseDate(true);
        verify(loanSection).setVerifyMode(true);
    }

    @Test
    public void testDeleteLoanBorrower() throws Exception {
        mockMvc.perform(post( "/admin/deleteLoanBorrower")
                .param("loanRid", "10")
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/collateralDetails"))
                .andExpect(model().attribute("collateralDetailsData", collateralDetailsMainDto));
        verify(collateralDetailsService).deleteLoanBorrower(collateralDetailsMainDto, 10L);
        verify(collateralDetailsService).refreshLoanBorrowerSection(collateralDetailsMainDto);
    }

    @Test
    public void testSaveLoanBorrowerInfo() throws Exception {
        mockMvc.perform(post( "/admin/saveLoanBorrower")
                .param("isPrimaryLoan", "true")
                .flashAttr("loansData", loanData)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/collateralDetails"))
                .andExpect(model().attribute("collateralDetailsData", collateralDetailsMainDto));
        verify(collateralDetailsService).saveLoanBorrower(collateralDetailsMainDto, loanData, true);
        verify(collateralDetailsService).refreshLoanBorrowerSection(collateralDetailsMainDto);
    }

    @Test
    public void testVerifyLoanBorrowerInfo() throws Exception {
        when(sectionStatusDto.getStatusId()).thenReturn(VerificationStatus.VERIFIED);
        mockMvc.perform(post( "/admin/verifyLoanBorrower")
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/collateralDetails"))
                .andExpect(model().attribute("collateralDetailsData", collateralDetailsMainDto));
        verify(loanSection).setVerifyMode(true);
        verify(collateralDetailsStatusService).updateLoanBorrowerSection(collateralDetailsMainDto);
        verify(collateralDetailsService).refreshLoanBorrowerSection(collateralDetailsMainDto);
        verify(loanSection).setVerifyMode(false);
    }

    @Test
    public void testGetVerifiedPostalAddress() throws Exception {
        mockMvc.perform(get("/admin/getVerifiedPostalAddressForLoanBorrower")
                .param("entityMailingAddress", "10 S Dearborn St")
                .param("entityUnitBuilding", "Fl 33")
                .param("entityCity", "Chicago")
                .param("entityState", "IL")
                .param("entityZip", "60603"))
                .andExpect(status().isOk());
        ArgumentCaptor<LoanBorrowerAddressDTO> captor = ArgumentCaptor.forClass(LoanBorrowerAddressDTO.class);
        verify(loanBorrowerAddressService).setVerifiedPostalAddressFields(captor.capture());
        LoanBorrowerAddressDTO actual = captor.getValue();
        assertThat(actual.getStreetAddress(), Matchers.equalTo("10 S Dearborn St"));
        assertThat(actual.getUnitBuilding(), Matchers.equalTo("Fl 33"));
        assertThat(actual.getCity(), Matchers.equalTo("Chicago"));
        assertThat(actual.getState(), Matchers.equalTo("IL"));
        assertThat(actual.getZipCode(), Matchers.equalTo("60603"));
    }
}
