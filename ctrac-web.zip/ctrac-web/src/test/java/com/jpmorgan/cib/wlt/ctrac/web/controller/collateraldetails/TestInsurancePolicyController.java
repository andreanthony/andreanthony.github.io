package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsStatusService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.RealEstateCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.InsurancePoliciesSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.SectionStatusDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.*;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;
import com.jpmorgan.cib.wlt.ctrac.service.validator.StartLetterCycleWorkflowValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.*;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Created by V704662 on 8/11/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestInsurancePolicyController {

    @InjectMocks private InsurancePolicyController controller;
    @Mock private CollateralDetailsService collateralDetailsService;
    @Mock private CollateralDetailsStatusService collateralDetailsStatusService;
    @Mock private CollateralDocumentService collateralDocumentService;
    @Mock private InsuranceMngtService insuranceMngtService;
    @Mock private StartLetterCycleWorkflowValidator startLetterCycleWorkflowValidator;

    private MockMvc mockMvc;

    private BindingResult bindingResult;

    @Mock private CollateralDetailsMainDto collateralDetailsMainDto;
    @Mock private CollateralDto collateralDto;
    @Mock private InsurancePoliciesSectionDto insurancePoliciesSectionDto;
    @Mock private ProofOfCoverageDTO proofOfCoverageDTO;
    @Mock private InsuranceCoverageMap<ProvidedCoverageDTO> providedCoverageMap;
    @Mock private TreeMap<Long, TreeMap<Integer, InsurableAssetCoverageData<ProvidedCoverageDTO>>> insurableAssetCoverageData;
    @Mock private List<SectionStatusDto> sectionStatusDtos;
    @Mock private TMParams tmParams;

    @Before
    public void setup(){
        bindingResult = mock(BindingResult.class);
        when(collateralDetailsMainDto.getCollateralDto()).thenReturn(collateralDto);
        when(collateralDetailsMainDto.getTmParams()).thenReturn(tmParams);
        when(collateralDto.getRid()).thenReturn(1L);
        when(collateralDetailsMainDto.getInsuranceSectionData()).thenReturn(insurancePoliciesSectionDto);
        when(insurancePoliciesSectionDto.getFloodPolicy(2L, 1L)).thenReturn(proofOfCoverageDTO);
        when(proofOfCoverageDTO.getProvidedCoverageMap()).thenReturn(providedCoverageMap);
        when(providedCoverageMap.getInsurableAssetCoverageData()).thenReturn(insurableAssetCoverageData);
        Set<Long> collateralSet = new HashSet<>();
        collateralSet.add(1L);
        when(insurableAssetCoverageData.keySet()).thenReturn(collateralSet);
        when(collateralDetailsMainDto.getSectionStatusDtos()).thenReturn(sectionStatusDtos);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testGetInsuranceSection() throws Exception {
        mockMvc.perform(get( "/admin/getInsuranceSection")
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/insurancePolicySection"))
                .andExpect(model().attribute("collateralDetailsData", collateralDetailsMainDto));
        verify(collateralDetailsStatusService).loadAllCollateralSectionsStatus(collateralDto, sectionStatusDtos);
        verify(collateralDetailsService).refreshInsurancePoliciesSection(1L, insurancePoliciesSectionDto);
    }

    @Test
    public void testLaunchNewInsurancePolicyEdit() throws Exception {
        testLaunchNewInsurancePolicy(2L, PolicyStatus.PENDING_VERIFICATION,"1", false);
        verify(proofOfCoverageDTO, never()).setMigrated(true);
    }

    @Test
    public void testLaunchNewInsurancePolicyMigrated() throws Exception {
        testLaunchNewInsurancePolicy(null, PolicyStatus.PENDING_VERIFICATION,"1", false);
        verify(proofOfCoverageDTO).setMigrated(true);
    }

    @Test
    public void testLaunchNewInsurancePolicyVerified() throws Exception {
        testLaunchNewInsurancePolicy(2L, PolicyStatus.PENDING_VERIFICATION,"2", true);
        verify(proofOfCoverageDTO, never()).setMigrated(true);
    }

    @Test
    public void testLaunchOverridePolicy() throws Exception {
        mockMvc.perform(get( "/admin/overrideInsurancePolicy")
                .param("policyRid", "2")
                .param("mode", "1")
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("collateralScreenOverrideInsurancePolicy"))
                .andExpect(model().attribute("collateralDetailsData", collateralDetailsMainDto));
    }

    @Test
    public void testAddCollateralToPolicy() throws Exception {
        mockMvc.perform(get( "/admin/addCollateralToPolicy")
                .param("collateralId", "3")
                .flashAttr("proofOfCoverageData", proofOfCoverageDTO)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("collateralScreenNewInsurancePolicy"))
                .andExpect(model().attribute("collateralDetailsData", collateralDetailsMainDto));
        verify(insuranceMngtService).addCollateralToPolicy(proofOfCoverageDTO, 3L);
        verify(collateralDetailsService).putCollateralDescription(collateralDetailsMainDto, 3L);
    }

    @Test
    public void testRemoveCollateralFromPolicy() throws Exception {
        when(insurancePoliciesSectionDto.getFloodPolicy(3L, 2L)).thenReturn(proofOfCoverageDTO);
        mockMvc.perform(post( "/admin/removeCollateralFromPolicy")
                .param("collateralId", "2")
                .param("policyId", "3")
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isNoContent());
        verify(insuranceMngtService).removeInsurancePolicyFromCollateral(2L, proofOfCoverageDTO);
    }

    @Test
    public void testSaveOverrideInsurancePolicy() throws Exception {
        mockMvc.perform(post( "/admin/saveOverrideInsurancePolicy")
                .flashAttr("proofOfCoverageData", proofOfCoverageDTO)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().is3xxRedirection())
                .andExpect(view().name("redirect:/admin/collateralDetails?collateralID=1"));
        verify(providedCoverageMap).addCollateral(1L);
        verify(collateralDetailsService).saveOverridePolicyOnly(collateralDetailsMainDto, proofOfCoverageDTO);
    }

    @Test
    public void testVerifyInsurancePoliciesSection() throws Exception {
        mockMvc.perform(post( "/admin/verifyInsurancePoliciesSection")
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isNoContent());
        verify(collateralDetailsStatusService).updateInsurancePoliciesSection(collateralDto, CollateralScreenAction.VERIFY, tmParams);
    }

    private void testLaunchNewInsurancePolicy(Long policyRid, PolicyStatus policyStatus, String mode, boolean verifyMode) throws Exception {
        when(proofOfCoverageDTO.getRid()).thenReturn(policyRid);
        when(proofOfCoverageDTO.getPolicyStatus()).thenReturn(policyStatus);
        mockMvc.perform(get( "/admin/newInsurancePolicy")
                .param("policyRid", "2")
                .param("mode", mode)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto))
                .andExpect(status().isOk())
                .andExpect(view().name("collateralScreenNewInsurancePolicy"))
                .andExpect(model().attribute("collateralDetailsData", collateralDetailsMainDto));
        verify(insurancePoliciesSectionDto).setVerifyMode(verifyMode);
    }

    /*Helper function to generate a CollateralDetailsMainDto instance for a given collateral*/
    private CollateralDetailsMainDto generateCollateralDetailsMainDtoInstance(Long collateralRid){
        CollateralDetailsMainDto collateralDetailsMainDto = new CollateralDetailsMainDto();
        CollateralDto collateralDto = new RealEstateCollateralDto();
        collateralDto.setRid(collateralRid);
        collateralDetailsMainDto.setCollateralDto(collateralDto);
        return collateralDetailsMainDto;
    }

    /*Helper function to generate a ProofOfCoverageDTO instance for a given collateral*/
    private ProofOfCoverageDTO generateProofOfCoverageDTOInstance(Long rid, Long collateralRid){
        ProofOfCoverageDTO proofOfCoverageDTO = new FloodInsuranceDTO();
        InsuranceCoverageMap<ProvidedCoverageDTO> providedCoverageMap =
                new InsuranceCoverageMap<>(ProvidedCoverageDTO.class);
        //Create a policy on an asset for a given collateral
        ProvidedCoverageDTO providedCoverageDTO = new ProvidedCoverageDTO();
        InsurableAssetDTO insurableAssetDTO = new InsurableAssetDTO(InsurableAssetType.BASE_INSURABLE_ASSET);
        insurableAssetDTO.setCollateralRid(collateralRid);
        providedCoverageDTO.setInsurableAssetDTO(insurableAssetDTO);

        proofOfCoverageDTO.setRid(rid);
        proofOfCoverageDTO.setProvidedCoverageMap(providedCoverageMap);
        return proofOfCoverageDTO;
    }

    /**
     * - saveInsurancePolicy
     * Test that when form validation for policy was good that the appropriate server
     * calls will be made to dave the new policy
     */
    @Test
    public void testSaveInsurancePolicySuccess(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(1L);
        ProofOfCoverageDTO proofOfCoverageDTO = generateProofOfCoverageDTOInstance(2L,1L);
        given(bindingResult.hasErrors()).willReturn(false);
        doNothing().when(startLetterCycleWorkflowValidator).validate(any(ProofOfCoverageDTO.class), any(CollateralDetailsMainDto.class));

        ResponseEntity<BaseApiResponse> response = controller.
                saveInsurancePolicy(proofOfCoverageDTO,bindingResult, collateralDetailsMainDto);

        verify(collateralDocumentService).fetchAttachedDocuments(eq(String.valueOf(2L)));
        verify(collateralDetailsService).savePolicy(eq(collateralDetailsMainDto),
                eq(proofOfCoverageDTO), anyList());
        verify(startLetterCycleWorkflowValidator, times(1)).validate(any(ProofOfCoverageDTO.class), any(CollateralDetailsMainDto.class));

        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());
    }

    /**
     * - saveInsurancePolicy
     * Test that when form validation for policy was good that the appropriate server
     * calls will be made to dave the new policy
     */
    @Test
    public void testSaveInsurancePolicyValidationFailure(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(1L);
        ProofOfCoverageDTO proofOfCoverageDTO = generateProofOfCoverageDTOInstance(2L,1L);
        //Mock an error in bindingResult
        List<ObjectError> errors = new ArrayList<>();
        errors.add(new FieldError("ProofOfCoverageDTO", "policyNumber",
                "Invalid characters found"));
        given(bindingResult.hasErrors()).willReturn(true);
        given(bindingResult.getAllErrors()).willReturn(errors);

        ResponseEntity<BaseApiResponse> response = controller.
                saveInsurancePolicy(proofOfCoverageDTO,bindingResult, collateralDetailsMainDto);

        verify(collateralDetailsService,never()).savePolicy(eq(collateralDetailsMainDto),
                eq(proofOfCoverageDTO), anyList());

        assertThat(response.getStatusCode(),is(HttpStatus.BAD_REQUEST));
        assertFalse(response.getBody().isSuccess());
        assertThat(response.getBody().getValidationErrors().get(0).getFieldId(),is("policyNumber"));
    }
}
