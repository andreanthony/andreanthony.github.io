package com.jpmorgan.cib.wlt.ctrac.web.spring.processor;

import com.jpmorgan.cib.wlt.ctrac.web.spring.extentions.ConversationIdRequestProcessor;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.thymeleaf.*;
import org.thymeleaf.context.IWebContext;
import org.thymeleaf.context.VariablesMap;
import org.thymeleaf.dom.Document;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.attr.AbstractAttributeModifierAttrProcessor;
import org.thymeleaf.resourceresolver.IResourceResolver;
import org.thymeleaf.templateresolver.ITemplateResolutionValidity;
import org.thymeleaf.templateresolver.TemplateResolution;
import javax.servlet.http.HttpServletRequest;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;


/**
 * Created by V704662 on 7/14/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestCustomSpringActionAttrProcessor {

    private CustomSpringActionAttrProcessor customSpringActionAttrProcessor = spy(new CustomSpringActionAttrProcessor());
    private Arguments arguments;
    private Element element;
    private Configuration configuration = new Configuration();
    @Mock private HttpServletRequest request;
    @Mock private ConversationIdRequestProcessor conversationIdRequestProcessor;
    private String attributeName = CustomSpringActionAttrProcessor.ATTR_NAME;
    private String templateName = "TEST_TEMPLATE";

    @Before
    public void setup(){
        generateThymeLeafArguments();
        element = new Element("form");
        doReturn(conversationIdRequestProcessor).when(customSpringActionAttrProcessor).getCidRequestProcessor();
    }

    /*Helper function to generate a Thymeleaf Arguments*/
    private void generateThymeLeafArguments(){
        TemplateEngine templateEngine = new TemplateEngine();
        TemplateProcessingParameters templateProcessingParameters = generateTemplateProcessingParams();
        TemplateResolution templateResolution = generateTemplateResolution();
        TemplateRepository templateRepository = new TemplateRepository(configuration);
        Document document = new Document();
        arguments = new Arguments(templateEngine,templateProcessingParameters,
                templateResolution, templateRepository, document);
    }

    /*Helper function to generate a Thymeleaf TemplateProcessingParameters*/
    private TemplateProcessingParameters generateTemplateProcessingParams(){
        IWebContext webContext = mock(IWebContext.class);
        VariablesMap<String, Object> variablesMap = new VariablesMap<>();
        given(webContext.getVariables()).willReturn(variablesMap);
        given(webContext.getHttpServletRequest()).willReturn(request);
        return new TemplateProcessingParameters(configuration, templateName, webContext);
    }

    /*Helper function to generate a Thymeleaf TemplateResolution*/
    private TemplateResolution generateTemplateResolution(){
        IResourceResolver resourceResolver = mock(IResourceResolver.class);
        ITemplateResolutionValidity templateResolutionValidity = mock(ITemplateResolutionValidity.class);
        String characterEncoding = "ENCODING";
        String resourceName = "TEST_RESOURCE";
        String templateMode = "TEST_MODE";
        return new TemplateResolution(templateName, resourceName, resourceResolver, characterEncoding,
                templateMode, templateResolutionValidity);
    }

    /**
     * - getPrecedence
     * TestCase: Verify that the priority of the processor will be the expected priority
     */
    @Test
    public void testGetPrecedence(){
        assertThat(customSpringActionAttrProcessor.getPrecedence(),
                is(CustomSpringActionAttrProcessor.ATTR_PRECEDENCE));
    }

    /**
     * - getTargetAttributeName
     * TestCase: Verify that the target attribute name of the processor will be the expected attribute name
     */
    @Test
    public void testGetTargetAttributeName(){
        assertThat(customSpringActionAttrProcessor.getTargetAttributeName(arguments,element,attributeName),
                is(CustomSpringActionAttrProcessor.ATTR_NAME));
    }

    /**
     * - getModificationType
     * TestCase: Verify that the Modification Type of the processor will be the expected modification type
     */
    @Test
    public void testGetModificationType(){
        assertThat(customSpringActionAttrProcessor.
                        getModificationType(arguments,element,attributeName,"TEST"),
                is(AbstractAttributeModifierAttrProcessor.ModificationType.SUBSTITUTION));
    }

    /**
     * - removeAttributeIfEmpty
     * TestCase: Verify that the remove attribute if empty is set to false
     */
    @Test
    public void testRemoveAttributeIfEmpty(){
        assertFalse(customSpringActionAttrProcessor.
                removeAttributeIfEmpty(arguments,element,attributeName,"TEST"));
    }

    /**
     * - doAdditionalProcess
     * TestCase: Verify that the additional process  of the processor will execute the
     * Conversation ID Request processor and will populate the form html tag with hidden fields
     */
    @Test
    public void testDoAdditionalProcess(){
        //Expect the cidRequestProcessor to return the number in a map
        Map<String,String> hiddenFields = new HashMap<>();
        hiddenFields.put("_cid","CidTest");
        given(conversationIdRequestProcessor.getExtraHiddenFields(request)).willReturn(hiddenFields);

        customSpringActionAttrProcessor.doAdditionalProcess(arguments,element,attributeName);

        assertThat(element.getChildren().size(),is(1));
        assertThat(((Element)element.getChildren().get(0)).getAttributeValue("value"),is("CidTest"));
        assertThat(((Element)element.getChildren().get(0)).getAttributeValue("name"),is("_cid"));
    }

    /**
     *  - getTargetAttributeName
     *  TestCase: Verify that the target attribute name for
     *  the processor is the expected value and that should be "action"
     */
    @Test
    public void testGetTargetAttributeValue(){
        assertThat(customSpringActionAttrProcessor.
                getTargetAttributeName(arguments,element,attributeName),is(CustomSpringActionAttrProcessor.ATTR_NAME));
    }
}
