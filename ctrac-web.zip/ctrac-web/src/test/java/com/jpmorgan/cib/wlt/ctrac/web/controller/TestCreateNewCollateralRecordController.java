package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralCreationService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.AddressDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CreateNewCollateralRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import javax.servlet.http.HttpServletRequest;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class TestCreateNewCollateralRecordController {

    private static final Long COLLATERAL_ID = 1L;

	protected MockMvc mockMvc;

	@Mock private CollateralCreationService collateralCreationService;
	@Mock private CollateralDetailsService collateralDetailsService;

	@Mock
	protected MockHttpSession session;

	@Mock
	protected MockHttpServletRequest request;

	@InjectMocks
    private CreateNewCollateralRecordController createNewCollateralRecordController;

	@Before
	public void setUp(){
		mockMvc = MockMvcBuilders.standaloneSetup(createNewCollateralRecordController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		setupSessionRequest();
	}

	@Test
    public void testPostEvent() throws Exception {
        CreateNewCollateralRecord createNewCollateralRecord = prepareNewCollateralRecord();
        CollateralDto expected = mock(CollateralDto.class);
        when(expected.getRid()).thenReturn(COLLATERAL_ID);
        when(collateralCreationService.createCollateral(eq(createNewCollateralRecord))).thenReturn(expected);
        mockMvc.perform(post("/admin/processNewCollateralRecord")
                .sessionAttr("createNewCollateralRecord", createNewCollateralRecord))
                .andExpect(view().name("redirect:/admin/collateralDetails?collateralID=1"));
        verify(collateralCreationService).createCollateral(eq(createNewCollateralRecord));
    }

	@Test
	public void testLaunchNewCollateralRecord() throws Exception{
		CreateNewCollateralRecord createNewCollateralRecord=prepareNewCollateralRecord();
		doReturn(createNewCollateralRecord).when(collateralDetailsService).prepareCreateNewCollateralRecord();
		mockMvc.perform(get("/admin/launchNewCollateralRecord"))
		.andExpect(status().isOk())
		.andExpect(view().name("admin/createNewCollateral"))
		.andExpect(model().attribute("createNewCollateralRecord",createNewCollateralRecord));
	}

	private CreateNewCollateralRecord prepareNewCollateralRecord(){
		CreateNewCollateralRecord createNewCollateralRecord = new CreateNewCollateralRecord();
        createNewCollateralRecord.setCollateralType("REL");
        AddressDto address = new AddressDto();
        address.setStreetAddress("123");
        address.setCity("ABC");
        address.setState("IL");
        address.setZipCode("60606");
        createNewCollateralRecord.setAddress(address);
        LoanData loan = new LoanData();
        loan.setLineOfBusiness("BB");
        createNewCollateralRecord.getLoansData().add(loan);
		return createNewCollateralRecord;
	}

	private void setupSessionRequest(){
		session.setAttribute("JANUS_USER_ID", "testUUID");
	}
}
