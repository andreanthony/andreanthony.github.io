package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.service.admin.RestartLetterCycleService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.admin.RestartLetterCycleDTO;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.InsuranceMngtService;

@RunWith(MockitoJUnitRunner.class)
public class TestRestartLetterCycleController extends AbstractTestFloodRemapController{
	private static final String RESTART_LETTER_CYCLE_URL = "admin/restartLetterCycle";

	@Mock
	private InsuranceMngtService insuranceMngtService;
	
	@Mock
	private RestartLetterCycleService restartLetterCycleService;
	
	@InjectMocks
	RestartLetterCycleController restartLetterCycleController;
	
	@Before
	public void setUp(){
		Mockito.reset(insuranceMngtService);
		Mockito.reset(restartLetterCycleService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				restartLetterCycleController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	@Test
	public void testLaunchRestartLetterCycle(){
		
	}
	
	@Test
	public void testGetRestartLetterCycleData() throws Exception{
		RestartLetterCycleDTO restartLetterCycleData = mockRestartLetterCycleDTO();
		doReturn(restartLetterCycleData).when(restartLetterCycleService)
		.prepareRestartLetterCycleData(restartLetterCycleData.getCollateralID());
		mockMvc.perform( post("/admin/getRestartLetterCycleData")
				.sessionAttr("restartLetterCycleData", restartLetterCycleData))
		.andExpect(status().isOk())
		.andExpect(view().name(RESTART_LETTER_CYCLE_URL))
		.andExpect(model().attribute("restartLetterCycleData",restartLetterCycleData));
	}
	
	@Test
	public void testInitiateRestartLetterCycle() throws Exception {
		RestartLetterCycleDTO restartLetterCycleData = mockRestartLetterCycleDTO();
		
		mockMvc.perform( post("/admin/initiateRestartLetterCycle")
				.sessionAttr("restartLetterCycleData", restartLetterCycleData))
		.andExpect(status().isOk())
		.andExpect(view().name(RESTART_LETTER_CYCLE_URL))
		.andExpect(model().attribute("restartLetterCycleData",restartLetterCycleData));
	}
	
	private RestartLetterCycleDTO mockRestartLetterCycleDTO(){
		RestartLetterCycleDTO restartLetterCycleData = new RestartLetterCycleDTO();
		restartLetterCycleData.setCollateralID(1L);
		return restartLetterCycleData;
	}
	
	private List<Long> getProofOfCoverageRids(){
		List<Long> proofOfCoveargeRids = new ArrayList<Long>();
		proofOfCoveargeRids.add(1L);
		return proofOfCoveargeRids;
	}
}
