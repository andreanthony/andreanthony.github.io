package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.service.SearchCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralSearchResultData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.CollateralSearchResultDataTablesRequest;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.SearchCollateralData;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestSearchCollateralController extends AbstractTestFloodRemapController {

	@InjectMocks
	SearchCollateralController searchCollateralController;
	
	@Mock
	SearchCollateralService searchCollateralService;
	
	@Mock
	protected MockHttpServletResponse response;
	
	@Before
	public void setUp() {
	
		
		mockMvc = MockMvcBuilders.standaloneSetup(searchCollateralController).build();		
	}
	
	@Test
	@Ignore
	public void testGetCollatearlSearchResults() throws Exception {
		CollateralSearchResultData collateralSearchResultData = new CollateralSearchResultData();
		collateralSearchResultData.setCollateralId("11111");
		collateralSearchResultData.setCollateralType("TestCollateralType");
		collateralSearchResultData.setPropertyAddress("TestPropertyAddress");
		collateralSearchResultData.setPropertyCity("TestCity");
		collateralSearchResultData.setPropertyState("TestState");
		collateralSearchResultData.setPropertyZipCode("TestZipCode");
		collateralSearchResultData.setLoanNumber("TestLoanNumber");
		collateralSearchResultData.setBorrowerName("TestBorrowerName");
		collateralSearchResultData.setLineOfBusiness("TestLineOfBusiness");

		List<CollateralSearchResultData> resultContent = new ArrayList<CollateralSearchResultData>();
		resultContent.add(collateralSearchResultData);
		when(searchCollateralService.getCollateralSearchResult(any(CollateralSearchResultDataTablesRequest.class))).thenReturn(resultContent);
		
		List<CollateralSearchResultData> result = searchCollateralService.getCollateralSearchResult(any(CollateralSearchResultDataTablesRequest.class));
		CollateralSearchResultData resultData = result.get(0);
		assertEquals(collateralSearchResultData.getCollateralId(), resultData.getCollateralId());
		assertEquals(collateralSearchResultData.getCollateralType(), resultData.getCollateralType());
		assertEquals(collateralSearchResultData.getPropertyAddress(), resultData.getPropertyAddress());
		assertEquals(collateralSearchResultData.getPropertyCity(), resultData.getPropertyCity());
		assertEquals(collateralSearchResultData.getPropertyState(), resultData.getPropertyState());
		assertEquals(collateralSearchResultData.getPropertyZipCode(), resultData.getPropertyZipCode());
		assertEquals(collateralSearchResultData.getLoanNumber(), resultData.getLoanNumber());
		assertEquals(collateralSearchResultData.getBorrowerName(), resultData.getBorrowerName());
	 	assertEquals(collateralSearchResultData.getLineOfBusiness(), resultData.getLineOfBusiness());
	}

}
