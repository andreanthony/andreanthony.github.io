
package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredProvidedCoverageGapViewData;
import com.jpmorgan.cib.wlt.ctrac.service.ReportDataProviderService;
import com.jpmorgan.cib.wlt.ctrac.web.controller.report.ReportDataProviderController;

@RunWith(MockitoJUnitRunner.class)
public class TestReportDataProviderController extends AbstractTestFloodRemapController  {
	
	@InjectMocks
	protected ReportDataProviderController reportDataProviderController;
	
	@Mock
	ReportDataProviderService reportDataProviderService;		

	
	@Before
	public void setUp() {
		Mockito.reset(reportDataProviderService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				reportDataProviderController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
	}	



	@Test
	public void getGapReportData() throws Exception {
		List<RequiredProvidedCoverageGapViewData> resultList = new ArrayList<RequiredProvidedCoverageGapViewData>();
		RequiredProvidedCoverageGapViewData result = new RequiredProvidedCoverageGapViewData();
		result.setBuildingName("New Building");
		result.setGapAmount(new BigDecimal(2000));
		resultList.add(result);
		
		RequiredProvidedCoverageGapViewData result2 = new RequiredProvidedCoverageGapViewData();
		result2.setBuildingName("Old Building");
		result2.setGapAmount(new BigDecimal(3000));
		resultList.add(result2);
		given(reportDataProviderService.getGapReportData()).willReturn(resultList);
		mockMvc.perform(get("/report/getGapReportData").accept(MediaType.APPLICATION_JSON))
		.andExpect(jsonPath("$.[0].buildingName").value("New Building"))
		.andExpect(jsonPath("$.[0].gapAmount").value("2000"))
		.andExpect(jsonPath("$.[1].buildingName").value("Old Building"))
		.andExpect(jsonPath("$.[1].gapAmount").value("3000"));
	}
}



