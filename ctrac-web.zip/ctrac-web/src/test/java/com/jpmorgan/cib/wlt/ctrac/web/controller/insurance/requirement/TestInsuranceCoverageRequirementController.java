package com.jpmorgan.cib.wlt.ctrac.web.controller.insurance.requirement;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageRequirementStatus;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailReqCoverageSectionHelper;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.InsurancePolicyRequirementDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.RequiredCoverageSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.*;
import com.jpmorgan.cib.wlt.ctrac.service.validator.InsuranceCoverageRequirementValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class TestInsuranceCoverageRequirementController {

    @Mock
    private CollateralDetailReqCoverageSectionHelper collateralDetailReqCoverageSectionHelper;

    @Mock
    private InsuranceCoverageRequirementValidator insuranceCoverageRequirementValidator;

    @InjectMocks
    private InsuranceCoverageRequirementController testObj;

    private MockMvc mockMvc;

    @Mock private CollateralDetailsMainDto collateralDetailsMainDto;
    @Mock private CollateralDto collateralDto;
    @Mock private RequiredCoverageSectionDto requiredCoverageSectionDto;
    @Mock private InsurancePolicyRequirementDto insurancePolicyRequirementDto;
    @Mock private InsurancePolicyRequirementDto activeCoverageRequirement;
    @Mock private RequiredCoverageSourceDto requiredCoverageSourceDto;
    @Mock private InsuranceCoverageMap<RequiredCoverageDTO> requiredCoverageMap;
    @Mock private InsurableAssetCoverageData<RequiredCoverageDTO> insurableData;
    @Mock private RequiredCoverageDTO buildingData;
    @Mock private RequiredCoverageDTO contentsData;
    @Mock private RequiredCoverageDTO businessIncomeData;

    @Before
    public void setUp() {
        when(collateralDetailsMainDto.getCollateralDto()).thenReturn(collateralDto);
        when(collateralDto.getRid()).thenReturn(1L);
        when(collateralDetailsMainDto.getRequiredCoverageSectionDto()).thenReturn(requiredCoverageSectionDto);
        when(requiredCoverageSectionDto.getActiveCoverageRequirement()).thenReturn(activeCoverageRequirement);
        when(activeCoverageRequirement.getRequiredCoverageSourceDto()).thenReturn(requiredCoverageSourceDto);
        when(requiredCoverageSourceDto.getStatus()).thenReturn(CoverageRequirementStatus.VERIFIED.name());
        when(collateralDetailReqCoverageSectionHelper.prepareRequiredCoverageOverlayData(
                eq(collateralDto), eq(requiredCoverageSectionDto), any(), eq(1L))).thenReturn(insurancePolicyRequirementDto);
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testLaunchDisplay() throws Exception {
        testLaunch("/admin/displayCoverageRequirement", "new", "display");
    }

    @Test
    public void testLaunchEditCanDelete() throws Exception  {
        when(insurancePolicyRequirementDto.canDelete()).thenReturn(true);
        testLaunch("/admin/editCoverageRequirement", "edit", "edit");
        verify(insurancePolicyRequirementDto).setCanDelete(true);
    }

    @Test
    public void testLaunchEditCannotDelete() throws Exception  {
        when(insurancePolicyRequirementDto.canDelete()).thenReturn(false);
        testLaunch("/admin/editCoverageRequirement", "edit", "edit");
        verify(insurancePolicyRequirementDto, never()).setCanDelete(anyBoolean());
    }

    @Test
    public void testLaunchVerify() throws Exception  {
        testLaunch("/admin/verifyCoverageRequirement", "verify", "verify");
    }

    private void testLaunch(String url, String action, String expectedMode) throws Exception {
        mockMvc.perform(get( url)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto)
                .param("fiatDocID", "1")
                .param("action", action))
                .andExpect(status().isOk())
                .andExpect(view().name("insurancecoverage/coveragerequirements"))
                .andExpect(model().attribute("insurancePolicyRequirementDto", insurancePolicyRequirementDto))
                .andExpect(request().sessionAttribute("mode", expectedMode));
    }

    @Test
    public void testUpdateCoverageDetailsAddRow() throws Exception {
        testUpdateCoverageDetails("addRow");
        verify(collateralDetailReqCoverageSectionHelper).createAndAppendNewCoverageRequiremnetRow(
                collateralDto, insurancePolicyRequirementDto, null, false);
    }

    @Test
    public void testUpdateCoverageDetailsDeleteRow() throws Exception {
        when(insurancePolicyRequirementDto.getRequiredCoverageMap()).thenReturn(requiredCoverageMap);
        when(requiredCoverageMap.pop(1L, 0)).thenReturn(insurableData);
        when(insurableData.getBuildingCoverageData()).thenReturn(buildingData);
        setUpCoverageData(buildingData, 1001L);
        when(insurableData.getContentsCoverageData()).thenReturn(contentsData);
        setUpCoverageData(contentsData, 1002L);
        when(insurableData.getBusinessIncomeCoverageData()).thenReturn(businessIncomeData);
        setUpCoverageData(businessIncomeData, 1003L);
        when(collateralDetailReqCoverageSectionHelper.areInsurableAssetDeletable(anySetOf(Long.class))).thenReturn(true);
        testUpdateCoverageDetails("deleteRow");
        verify(requiredCoverageSectionDto).addInsuableAssetToDelete(1001L);
        verify(requiredCoverageSectionDto).addInsuableAssetToDelete(1002L);
        verify(requiredCoverageSectionDto).addInsuableAssetToDelete(1003L);
    }

    private void setUpCoverageData(RequiredCoverageDTO coverageData, Long insurableAssetId) {
        InsurableAssetDTO insurableAssetDTO = mock(InsurableAssetDTO.class);
        when(insurableAssetDTO.getRid()).thenReturn(insurableAssetId);
        when(coverageData.getInsurableAssetDTO()).thenReturn(insurableAssetDTO);
    }

    private void testUpdateCoverageDetails(String action) throws Exception {
        mockMvc.perform(post("/admin/editCoverageRequirement/update")
                .flashAttr("insurancePolicyRequirementDto", insurancePolicyRequirementDto)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto)
                .sessionAttr("mode", "edit")
                .param("collateralId", "1")
                .param("sortOrder", "0")
                .param("action", action))
                .andExpect(status().isOk())
                .andExpect(view().name("insurancecoverage/coveragerequirements"))
                .andExpect(model().attribute("insurancePolicyRequirementDto", insurancePolicyRequirementDto));
    }

    @Test
    public void testUpdateCoverageDetailsDeleteAll() throws Exception {
        mockMvc.perform(post("/admin/editCoverageRequirement/update")
                .flashAttr("insurancePolicyRequirementDto", insurancePolicyRequirementDto)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto)
                .sessionAttr("mode", "edit")
                .param("collateralId", "1")
                .param("sortOrder", "0")
                .param("action", "deleteAll"))
                .andExpect(status().is3xxRedirection())
                .andExpect(view().name("redirect:/admin/collateralDetails?collateralID=1"))
                .andExpect(flash().attribute("collateralDetailsData", collateralDetailsMainDto));
        verify(collateralDetailReqCoverageSectionHelper).deleteAllRequiredCoverages(insurancePolicyRequirementDto, collateralDetailsMainDto);
    }

    @Test
    public void testUpdateCoverageDetailsDiscardDraft() throws Exception {
        mockMvc.perform(post("/admin/editCoverageRequirement/update")
                .flashAttr("insurancePolicyRequirementDto", insurancePolicyRequirementDto)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto)
                .sessionAttr("mode", "edit")
                .param("collateralId", "1")
                .param("sortOrder", "0")
                .param("action", "discard-draft"))
                .andExpect(status().isOk())
                .andExpect(view().name("insurancecoverage/coveragerequirements"))
                .andExpect(model().attribute("insurancePolicyRequirementDto", insurancePolicyRequirementDto));
    }

    @Test
    public void testSaveRequiredCoverageDetailsEdit() throws Exception {
        testSaveRequiredCoverageDetails("edit");
    }

    @Test
    public void testSaveRequiredCoverageDetailsVerify() throws Exception {
        testSaveRequiredCoverageDetails("verify");
    }

    private void testSaveRequiredCoverageDetails(String action) throws Exception {
        mockMvc.perform(post("/admin/saveCoverageRequirement")
                .flashAttr("insurancePolicyRequirementDto", insurancePolicyRequirementDto)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto)
                .sessionAttr("mode", action))
                .andExpect(status().is3xxRedirection())
                .andExpect(view().name("redirect:/admin/collateralDetails?collateralID=1"))
                .andExpect(flash().attribute("insurancePolicyRequirementDto", insurancePolicyRequirementDto))
                .andExpect(flash().attribute("collateralDetailsData", collateralDetailsMainDto));
        verify(collateralDetailReqCoverageSectionHelper)
                .proccessRequiredCoverageSubmit(insurancePolicyRequirementDto, collateralDetailsMainDto, action);
    }

    @Test
    public void testSaveRequiredCoverageDetailsVerifyMismatch() throws Exception {
        when(insuranceCoverageRequirementValidator.verifyMissMatchingPrimaryExcessCoverage(insurancePolicyRequirementDto)).thenReturn(true);
        mockMvc.perform(post("/admin/saveCoverageRequirement")
                .flashAttr("insurancePolicyRequirementDto", insurancePolicyRequirementDto)
                .flashAttr("collateralDetailsData", collateralDetailsMainDto)
                .sessionAttr("mode", "verify"))
                .andExpect(status().isOk())
                .andExpect(view().name("insurancecoverage/coveragerequirements"))
                .andExpect(request().sessionAttribute("mode", "verify-missmatch"));
    }
}
