package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Mockito.doReturn;
import static org.hamcrest.Matchers.is;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import java.util.Date;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import com.jpmorgan.cib.wlt.ctrac.batch.scheduler.SchedulerMngtService;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.service.FloodRemapAdminService;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.BusinessDayUtil;

@RunWith(MockitoJUnitRunner.class)
public class TestCommonPagesController extends AbstractTestFloodRemapController{
	@Mock private SchedulerMngtService schedulerMngtService;
	@Mock private FloodRemapAdminService floodRemapAdminService;
	@Mock private BusinessDayUtil businessDayUtil;
	
	@InjectMocks private CommonPagesController commonPagesController;
	
	@Before
	public void setUp(){
		Mockito.reset(schedulerMngtService);
		Mockito.reset(floodRemapAdminService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				commonPagesController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
	}
	
	@Test
	public void testGetLoginPage() throws Exception{
		mockMvc.perform(get("/login"))
		.andExpect(status().isOk())
		.andExpect(view().name("loginPage"));
	}
	
	@Test
	public void testLaunchDisplayConfirmHelper() throws Exception{
		String confirmMessage="";
		
		mockMvc.perform(get("/displayconfirmationItem"))
		.andExpect(status().isOk())
		.andExpect(view().name("floodRemapConfirmation"))
		.andExpect(model().attribute("confirmation",confirmMessage));
	}
	
	@Test
	public void testIndex() throws Exception {
		ReferenceDate referenceDate=new ReferenceDate();
		referenceDate.setReferencDate(new Date());
		doReturn(referenceDate).when(floodRemapAdminService).getAppReferenceDate();
		mockMvc.perform(get("/"))
		.andExpect(status().isOk())
		.andExpect(view().name("index"));
	}
	
	@Test
	public void testGetBatchIsRunningPage() throws Exception{
		mockMvc.perform(get("/batchIsRunning"))
		.andExpect(status().isOk())
		.andExpect(view().name("floodRemapConfirmation"));
	}
	
	//@Test
	public void testGetbatchRunTimeCountDown() throws Exception{
		Long countDown=new Long(1L);
		doReturn(countDown).when(schedulerMngtService).getTodayJobScheduledTimeCountDownInMiliSec(SchedulerJob.FULL_EOD_JOB,false);
		mockMvc.perform(get("/batchRunTimeCountDown"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("countDown",is(countDown)));
	}
	
	@Test
	public void testGetbatchRunTimeCountDowv2() throws Exception{
		String viewName="redirect:/batchRunTimeCountDown";
		mockMvc.perform(get("/admin/batchRunTimeCountDown"))
		.andExpect(status().is(302))
		.andExpect(view().name(viewName));		
	}
}
