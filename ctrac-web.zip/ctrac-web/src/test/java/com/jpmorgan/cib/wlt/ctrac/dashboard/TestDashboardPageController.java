package com.jpmorgan.cib.wlt.ctrac.dashboard;

import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureBook;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@RunWith(MockitoJUnitRunner.class)
public class TestDashboardPageController {

    protected MockMvc mockMvc;

    @InjectMocks
    private DashboardPageController controller;

    @Mock private FeatureManager featureManager;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
        given(featureManager.isActive(FeatureBook.GENERAL_INSURANCE)).willReturn(true);
    }

    @Test
    public void testLoadDashBoard() throws Exception {
        mockMvc.perform( get("/dashboard"))
                .andExpect(status().isOk())
                .andExpect(view().name("/ctrac-ui/index"));
    }

    @Test
    public void testLoadDashBoard_Section() throws Exception {
        mockMvc.perform( get("/dashboard/requirement"))
                .andExpect(status().isOk())
                .andExpect(view().name("/ctrac-ui/index"));
    }

    @Test(expected = Exception.class)
    public void testLoadDashBoard_FeatureNotEnabled() throws Exception {
        given(featureManager.isActive(FeatureBook.GENERAL_INSURANCE)).willReturn(false);
        mockMvc.perform( get("/dashboard"))
                .andExpect(status().isFound());
    }
}
