package com.jpmorgan.cib.wlt.ctrac.event.store.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.EventStore;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventSubscriberDTO;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.refEq;
import static org.mockito.Mockito.verify;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestEventController {

    private static final ObjectWriter OBJECT_WRITER =
            new ObjectMapper().configure(SerializationFeature.WRAP_ROOT_VALUE, false).writerWithDefaultPrettyPrinter();
    private static final DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSZ");

    @InjectMocks
    private EventController testObj;

    @Mock
    private EventStore eventStore;

    private static final String API = "/api/event";
    private static final String EVENT_TYPE = "COLLATERAL_CREATED";
    private static final String EVENT_TIME_1 = "2017-12-26T04:05:06.007000-0600";
    private static final String EVENT_TIME_2 = "2017-12-27T05:06:07.008000-0600";
    private static final String EVENT_ATTRIBUTES_1 = "{ ABC }";
    private static final String EVENT_ATTRIBUTES_2 = "{ DEF }";

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(testObj).build();
        List<CtracEventDTO> events = new ArrayList<>();
        events.add(createEvent(EVENT_TIME_1, EVENT_ATTRIBUTES_1));
        events.add(createEvent(EVENT_TIME_2, EVENT_ATTRIBUTES_2));
    }

    private CtracEventDTO createEvent(String eventTime, String eventAttributes) {
        CtracEventDTO event = new CtracEventDTO();
        event.setEventType(EVENT_TYPE);
        event.setEventTime(DATE_TIME_FORMAT.parseDateTime(eventTime).toDate());
        event.setEventJson(eventAttributes);
        return event;
    }

    @Test
    public void testPublish() throws Exception {
        CtracEventDTO eventDTO = new CtracEventDTO();
        String requestJson = OBJECT_WRITER.writeValueAsString(eventDTO);
        mockMvc.perform(post(API)
                .contentType(APPLICATION_JSON_UTF8)
                .content(requestJson))
                .andExpect(status().isOk());
        verify(eventStore).receive(requestJson);
    }

    @Test
    public void testSubscribe() throws Exception {
        List<CtracEventSubscriberDTO> subscriptions = new ArrayList<>();
        CtracEventSubscriberDTO subscription = new CtracEventSubscriberDTO("Collateral Added", "test.jpmchase.net/test");
        subscriptions.add(subscription);
        String requestJson = OBJECT_WRITER.writeValueAsString(subscriptions);
        mockMvc.perform(post(API + "/subscribe")
                .contentType(APPLICATION_JSON_UTF8)
                .content(requestJson))
                .andExpect(status().isOk());
        verify(eventStore).subscribe(refEq(subscriptions));
    }
}
