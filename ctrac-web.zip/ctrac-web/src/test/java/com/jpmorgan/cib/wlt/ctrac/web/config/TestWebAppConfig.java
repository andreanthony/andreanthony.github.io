package com.jpmorgan.cib.wlt.ctrac.web.config;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.thymeleaf.spring4.view.ThymeleafViewResolver;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Created by V704662 on 9/13/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestWebAppConfig {

    @InjectMocks private WebAppConfig webAppConfig;

    /**
     * - getViewResolver
     * TestCase: Verify that the web application configuration is correctly
     * set that The thymeleaf viewResolver has UTF-8 encoding set
     */
    @Test
    public void testGetViewResolver(){
        ThymeleafViewResolver thymeleafViewResolver = webAppConfig.getViewResolver();
        assertThat(thymeleafViewResolver.getCharacterEncoding(),is("UTF-8"));
        assertThat(thymeleafViewResolver.getContentType(),is("text/html;charset=UTF-8"));
    }


    /**
     * - getTemplateResolver
     * TestCase: Verify that the web application configuration is correctly
     * set that The thymeleaf template resolver has UTF-8 encoding set
     */
    @Test
    public void testGetTemplateResolver(){
        ServletContextTemplateResolver servletContextTemplateResolver = webAppConfig.getTemplateResolver();
        servletContextTemplateResolver.initialize();
        assertThat(servletContextTemplateResolver.getCharacterEncoding(),is("UTF-8"));
    }
}
