package com.jpmorgan.cib.wlt.ctrac.web.controller.loan;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.LoanData;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.RealEstateCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.LoanBorrowerSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.SectionStatusDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.coverage.ReferenceValues;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.loan.LoanMaintenanceService;
import com.jpmorgan.cib.wlt.ctrac.service.validator.LoanMaintenanceValidator;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * Created by V704662 on 8/10/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestLoanMaintenanceController {

    @InjectMocks private LoanMaintenanceController controller;
    @Mock private LoanMaintenanceService loanMaintenanceService;
	@Mock private MessageSource messageSource;
    @Mock private CollateralDetailsService collateralDetailsService;
    @Mock private CollateralManagementService collateralManagementService;
    @Mock LoanMaintenanceValidator loanMaintenanceValidator;
    private BindingResult bindingResult;
    private ModelMap model;

    private static final Long COLLATERAL_RID = 1L;
    private static final Long LOAN_RID = 2L;

    @Mock private CollateralDetailsMainDto collateralDetailsMainDto;
    @Mock private LoanBorrowerSectionDto loanSection;
    @Mock private LoanData loanData;
    @Mock private ReferenceValues referenceValues;
    @Mock private ModelMap modelMap;

    @Before
    public void setup(){
        bindingResult = mock(BindingResult.class);
        model = mock(ModelMap.class);
        given(messageSource.getMessage("service.save.success.message",null,null)).willReturn("Test Error");

        when(collateralDetailsMainDto.getLoanBorrowerSectionData()).thenReturn(loanSection);
        when(loanSection.getloanData(LOAN_RID)).thenReturn(loanData);
    }

    @Test
    public void testLaunchNewLoan() {
        when(loanMaintenanceService.getLoanReferenceValues(loanSection)).thenReturn(referenceValues);

        ModelAndView actual = controller.viewLoan(collateralDetailsMainDto, COLLATERAL_RID, null, 1, modelMap, null);

        verify(loanSection).setCollateralRid(COLLATERAL_RID);
        verify(loanSection).setLaunchingNew(true);
        ReferenceValues actualReferenceValues = (ReferenceValues) actual.getModel().get("referenceValues");
        assertThat(actualReferenceValues, is(referenceValues));
    }

    @Test
    public void testLaunchExistingLoan() {
        when(loanMaintenanceService.getLoanReferenceValues(loanSection)).thenReturn(referenceValues);

        ModelAndView actual = controller.viewLoan(collateralDetailsMainDto, COLLATERAL_RID, LOAN_RID.toString(), 1, modelMap, null);

        verify(loanSection).setCollateralRid(COLLATERAL_RID);
        verify(loanSection).setLaunchingNew(false);
        ReferenceValues actualReferenceValues = (ReferenceValues) actual.getModel().get("referenceValues");
        assertThat(actualReferenceValues, is(referenceValues));
    }

    @Test
    public void testDisplayReleaseDatePledged() {
        when(loanMaintenanceService.getLoanReferenceValues(loanSection)).thenReturn(referenceValues);
        when(loanData.getStatus()).thenReturn(LoanStatus.ACTIVE);
        when(collateralDetailsMainDto.getCollateralDto()).thenReturn( generateCollateralDto(COLLATERAL_RID, CollateralStatus.PLEDGED));
        ModelAndView actual = controller.viewLoan(collateralDetailsMainDto, COLLATERAL_RID, LOAN_RID.toString(), 1, modelMap, null);
        verify(loanSection).setCollateralRid(COLLATERAL_RID);
        verify(loanData).setDisplayReleaseDate    (true);
        ReferenceValues actualReferenceValues = (ReferenceValues) actual.getModel().get("referenceValues");
        assertThat(actualReferenceValues, is(referenceValues));
    }

    @Test
    public void testDisplayReleaseDateDraft() {
        when(loanMaintenanceService.getLoanReferenceValues(loanSection)).thenReturn(referenceValues);
        when(loanData.getStatus()).thenReturn(LoanStatus.ACTIVE);
        when(loanData.getRid()).thenReturn(LOAN_RID);
        when(collateralDetailsMainDto.getCollateralDto()).thenReturn( generateCollateralDto(COLLATERAL_RID, CollateralStatus.DRAFT));
        ModelAndView actual = controller.viewLoan(collateralDetailsMainDto, COLLATERAL_RID, LOAN_RID.toString(), 1, modelMap, null);
        verify(loanSection).setCollateralRid(COLLATERAL_RID);
        verify(loanData).setDisplayReleaseDate(false);
        ReferenceValues actualReferenceValues = (ReferenceValues) actual.getModel().get("referenceValues");
        assertThat(actualReferenceValues, is(referenceValues));
    }

    /*Helper function to generate a LoanData instance */
    private LoanData generateLoanData(Long rid){
        LoanData loanData = new LoanData();
        loanData.setRid(rid);
        return loanData;
    }

    /*Helper function to generate a CollateralDetailsMainDto instance*/
    private CollateralDetailsMainDto generateCollateralDetailsMainDto(Long rid){
        CollateralDetailsMainDto collateralDetailsMainDto = new CollateralDetailsMainDto();
        CollateralDto collateralDto = new RealEstateCollateralDto();
        collateralDto.setRid(rid);
        collateralDetailsMainDto.setCollateralDto(collateralDto);

        SectionStatusDto sectionStatusDto = new SectionStatusDto();
        sectionStatusDto.setStatusId(VerificationStatus.PENDING_VERIFICATION);

        LoanBorrowerSectionDto loanBorrowerData = new LoanBorrowerSectionDto();
        loanBorrowerData.setSectionStatusDto(sectionStatusDto);

        collateralDetailsMainDto.setLoanBorrowerSectionData(loanBorrowerData);

        return collateralDetailsMainDto;
    }

    /*Helper function to generate a CollateralDetailsMainDto instance*/
    private CollateralDto generateCollateralDto(Long rid, CollateralStatus collateralStatus){
        CollateralDto collateralDto = new RealEstateCollateralDto();
        collateralDto.setRid(rid);
        collateralDto.setCollateralStatus(collateralStatus);
        return collateralDto;
    }


    /**
     * - saveLoanData
     * TestCase: when submitting a new Loan / Borrower - or editing existing loan,
     * the validation will occur and when valid form the service will get called to save the loan
     */
    @Test
    public void testSaveLoanSuccess(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDto(1L);
        LoanData loanData = generateLoanData(1L);
        given(bindingResult.hasErrors()).willReturn(false);

        given(collateralManagementService.hasMarketEmailChanged(collateralDetailsMainDto)).willReturn(false);

        ResponseEntity<BaseApiResponse> response = controller.
                saveLoan(loanData,bindingResult,collateralDetailsMainDto,model);
        //Verify that the service will be called with expected object
        verify(loanMaintenanceValidator).validatePrimaryLoan(collateralDetailsMainDto, loanData, bindingResult);
        verify(loanMaintenanceService).saveLoanData(loanData, collateralDetailsMainDto);
        assertTrue(StringUtils.isNotEmpty(collateralDetailsMainDto.getSaveStatus()));
        verify(model).addAttribute("collateralDetailsData", collateralDetailsMainDto);

        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());
    }

    /**
     * - saveLoan
     * TestCase: When market email address has changed when saving a loan (When loan switched from LOB
     * where the new LOB requires a market email address the collateral detail section has to switch
     * status to pending verification due to change in market email address)
     */
    @Test
    public void testSaveLoan_MarketEmailChanged(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDto(1L);
        LoanData loanData = generateLoanData(1L);
        //Market email address change detected
        given(collateralManagementService.hasMarketEmailChanged(collateralDetailsMainDto)).willReturn(true);
        given(bindingResult.hasErrors()).willReturn(false);

        ResponseEntity<BaseApiResponse> response = controller.
                saveLoan(loanData,bindingResult,collateralDetailsMainDto,model);

        //Verify that the service will be called with expected object
        verify(collateralDetailsService).saveCollateralSectionInfo(eq(collateralDetailsMainDto), any(CollateralScreenAction.class));

        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());
    }

    /**
     * - saveLoan
     * TestCase: When market email address has Not changed when saving a loan - the collateral detail
     * section status will not get updated to pending verification
     */
    @Test
    public void testSaveLoan_NoMarketEmailChanged(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDto(1L);
        LoanData loanData = generateLoanData(1L);
        //NO Market email address change detected
        given(collateralManagementService.hasMarketEmailChanged(collateralDetailsMainDto)).willReturn(false);
        given(bindingResult.hasErrors()).willReturn(false);

        ResponseEntity<BaseApiResponse> response = controller.
                saveLoan(loanData,bindingResult,collateralDetailsMainDto,model);

        //Verify that the service will not be called with expected object
        verify(collateralDetailsService,never())
                .saveCollateralSectionInfo(eq(collateralDetailsMainDto), any(CollateralScreenAction.class));

        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());
    }


    /**
     * - saveLoanData
     * TestCase: when submitting a new Loan / Borrower - or editing existing loan,
     * the validation will occur and fail - so we expect failure message back
     */
    @Test
    public void testSaveLoanValidationError(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDto(1L);
        LoanData loanData = generateLoanData(1L);

        //Mock an error in bindingResult
        List<ObjectError> errors = new ArrayList<>();
        errors.add(new FieldError("LoanData", "loanNumber","Invalid characters found"));
        given(bindingResult.hasErrors()).willReturn(true);
        given(bindingResult.getAllErrors()).willReturn(errors);

        ResponseEntity<BaseApiResponse> response = controller.
                saveLoan(loanData,bindingResult,collateralDetailsMainDto,model);

        //Verify that the service will not be called with expected object
        verify(loanMaintenanceService,never()).saveLoanData(loanData, collateralDetailsMainDto);

        assertThat(response.getStatusCode(),is(HttpStatus.BAD_REQUEST));
        assertFalse(response.getBody().isSuccess());
    }
}

