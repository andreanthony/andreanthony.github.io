package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.LOB_MAPPING_FOR_DATA_FEED_SECTION;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.service.lob.LOBInclusionExclusionService;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LobMappingDTO;
import com.jpmorgan.cib.wlt.ctrac.service.lob.dto.LobMappingSectionDTO;

@RunWith(MockitoJUnitRunner.class)
public class TestConfigureLOBController extends AbstractTestFloodRemapController {
	@Mock private LOBInclusionExclusionService lobInclusionExclusionService;

	@InjectMocks
	@Spy
	ConfigureLOBController configureLOBController;
	
	@Before
	public void setUp(){
		Mockito.reset(lobInclusionExclusionService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				configureLOBController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	@Test
	public void testLaunchConfigureLOB() throws Exception{
		LobMappingDTO lobMappingData = mockLobMappingDTO();
		doReturn(lobMappingData).when(lobInclusionExclusionService).populateLOBs();
		mockMvc.perform( get("/admin/configureLOB").session(session))
		.andExpect(status().isOk()).andExpect(view().name("admin/lobInclusionExclusion"))
		.andExpect(model().attribute("lobMappingData",lobMappingData));
	}
	
	@Test
	public void testEditLOB() throws Exception{
		LobMappingDTO lobMappingData = mockLobMappingDTO();
		lobMappingData.setTriggeredScreenId(LOB_MAPPING_FOR_DATA_FEED_SECTION);
		doNothing().when(lobInclusionExclusionService).updateLOBListForSection(lobMappingData.getLobMappingForDataFeeds(), createLOBArray(), createLOBArray());
		mockMvc.perform( post("/admin/editLOB")
				.sessionAttr("lobMappingData",lobMappingData)
				.param("availableLobs", createLOBArray())
				.param("configuredLobs", createLOBArray())
				.param("triggeredSectionId", LOB_MAPPING_FOR_DATA_FEED_SECTION))
		.andExpect(status().isOk()).andExpect(view().name("admin/lobInclusionExclusion"))
		.andExpect(model().attribute("lobMappingData",lobMappingData));
		
	}
	
	@Test
	public void testUpdateLOBs() throws Exception{
		LobMappingDTO lobMappingData = mockLobMappingDTO();
		doNothing().when(lobInclusionExclusionService).updateAvailableConfiguredLOBList(lobMappingData);
		mockMvc.perform( post("/admin/updateLOBs")
				.sessionAttr("lobMappingData",lobMappingData))
		.andExpect(status().isOk()).andExpect(view().name("admin/lobInclusionExclusion"))
		.andExpect(model().attribute("lobMappingData",lobMappingData));
	}
	
	private LobMappingDTO mockLobMappingDTO() {
		LobMappingDTO lobMappingDTO = new LobMappingDTO();
		lobMappingDTO.setLobMappingForDataFeeds(mockLobMappingSectionDTO());
		lobMappingDTO.setLobMappingForDropDown(mockLobMappingSectionDTO());
		return lobMappingDTO;
	}

	private LobMappingSectionDTO mockLobMappingSectionDTO() {
		LobMappingSectionDTO lobMappingSectionDto = new LobMappingSectionDTO();
		lobMappingSectionDto.setAvailableLobs(createLOBList());
		lobMappingSectionDto.setConfiguredLobs(createLOBList());
		return lobMappingSectionDto;
	}
	
	private List<String> createLOBList() {
		List<String> lobList = new ArrayList<String>();
		lobList.add("TestLOB1");
		lobList.add("TestLOB2");
		lobList.add("TestLOB3");
		return lobList;
	}
	
	private String[] createLOBArray() {
		String[] lobArr = { "TestLOB4", "TestLOB5", "TestLOB6" };
		return lobArr;
	}
}
