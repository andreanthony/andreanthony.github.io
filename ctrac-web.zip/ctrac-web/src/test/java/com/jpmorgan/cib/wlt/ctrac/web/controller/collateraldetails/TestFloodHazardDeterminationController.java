package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.RealEstateCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.FloodDeterminationDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.insurableasset.FloodDeterminationService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

/**
 * Created by V704662 on 8/11/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestFloodHazardDeterminationController {

    @InjectMocks private FloodHazardDeterminationController controller;
    @Mock private CollateralDetailsService collateralDetailsService;
    @Mock private FloodDeterminationService floodDeterminationService;
    private BindingResult bindingResult;
    private HttpServletRequest httpServletRequest;
    private HttpSession httpSession;
    private ModelMap model;

    @Before
    public void setup(){
        bindingResult = mock(BindingResult.class);
        httpServletRequest = mock(HttpServletRequest.class);
        httpSession = mock(HttpSession.class);
        model = mock(ModelMap.class);
        given(httpServletRequest.getSession()).willReturn(httpSession);
    }

    /*Helper function to generate a CollateralDetailsMainDto instance for a given collateral*/
    private CollateralDetailsMainDto generateCollateralDetailsMainDtoInstance(Long collateralRid){
        CollateralDetailsMainDto collateralDetailsMainDto = new CollateralDetailsMainDto();
        CollateralDto collateralDto = new RealEstateCollateralDto();
        collateralDto.setRid(collateralRid);
        collateralDetailsMainDto.setCollateralDto(collateralDto);
        return collateralDetailsMainDto;
    }

    /*Helper function to generate a FloodDeterminationDto instance for a given collateral*/
    private FloodDeterminationDto generateFloodDeterminationDtoInstance(Long rid){
        FloodDeterminationDto floodDeterminationDto = new FloodDeterminationDto();
        floodDeterminationDto.setRid(rid);
        return floodDeterminationDto;
    }

    /*Helper function to mock an error in the binding result*/
    private void mockErrorInBindingResult(String field){
        //Mock an error in bindingResult
        List<ObjectError> errors = new ArrayList<>();
        errors.add(new FieldError("FloodDeterminationDto", field,
                "Invalid characters found"));
        given(bindingResult.hasErrors()).willReturn(true);
        given(bindingResult.getAllErrors()).willReturn(errors);
    }

    /**
     * - verifyFloodDetermination
     * TestCase:
     *  When verifying a Flood determination form validate that the services will be called and
     *  success response is returned back to client when validation passes
     */
    @Test
    public void testVerifyFloodDeterminationSuccess(){
        FloodDeterminationDto floodDeterminationDto = generateFloodDeterminationDtoInstance(1L);
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);
        given(bindingResult.hasErrors()).willReturn(false);

        ResponseEntity<BaseApiResponse> response = controller.verifyFloodDetermination(floodDeterminationDto,
                bindingResult,collateralDetailsMainDto);

        //Verify that the service will get called with the expected Model
        verify(floodDeterminationService).verifyFloodDeterminationSection(collateralDetailsMainDto);
        verify(collateralDetailsService).refreshFloodDeterminationSection(collateralDetailsMainDto);

        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());
    }

    /**
     * - verifyFloodDetermination
     * TestCase:
     *  When verifying a Flood determination form validate that the services will NOT be called and
     *  failure response is returned back to client when validation errors were present
     */
    @Test
    public void testVerifyFloodDeterminationValidationFailure(){
        FloodDeterminationDto floodDeterminationDto = generateFloodDeterminationDtoInstance(1L);
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);
        mockErrorInBindingResult("floodZone");

        ResponseEntity<BaseApiResponse> response = controller.verifyFloodDetermination(floodDeterminationDto,
                bindingResult,collateralDetailsMainDto);

        //Verify that the service will get called with the expected Model
        verify(floodDeterminationService,never()).verifyFloodDeterminationSection(collateralDetailsMainDto);
        verify(collateralDetailsService,never()).refreshFloodDeterminationSection(collateralDetailsMainDto);

        assertThat(response.getStatusCode(),is(HttpStatus.BAD_REQUEST));
        assertThat(response.getBody().getValidationErrors().get(0).getFieldId(),is("floodZone"));
        assertFalse(response.getBody().isSuccess());
    }

    /**
     * - verifyFloodDetermination
     * TestCase:
     *  Exception handling is done and appropriate Exception will get thrown by controller
     */
    @Test(expected = CtracAjaxException.class)
    public void testVerifyFloodDeterminationDetailsExceptionHandling() {
        FloodDeterminationDto floodDeterminationDto = generateFloodDeterminationDtoInstance(1L);
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);
        given(bindingResult.hasErrors()).willReturn(false);

        doThrow(new JpaSystemException(new RuntimeException("Error"))).when(floodDeterminationService)
                .verifyFloodDeterminationSection(collateralDetailsMainDto);

        controller.verifyFloodDetermination(floodDeterminationDto,
                bindingResult, collateralDetailsMainDto);

        //Verify that the service will get called with the expected Model
        verify(floodDeterminationService).verifyFloodDeterminationSection(collateralDetailsMainDto);
    }

    /**
     * - reloadFloodDeterminationSectionFromSession
     * Controller endpoint that will refresh the flood determination section on the details page
     */
    @Test
    public void testReloadFloodDeterminationSectionFromSession(){
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);
        assertThat(controller.reloadFloodDeterminationSectionFromSession(collateralDetailsMainDto),
                is("admin/floodHazardDeterminationSection :: floodHazardDeterminationSection"));
    }

    /**
     * - saveFloodDeterminationDetails
     * TestCase:
     *  When saving a Flood determination form validate that the services will be called and
     *  success response is returned back to client when validation passes
     */
    @Test
    public void testSaveFloodDeterminationDetailsSuccess(){
        given(httpSession.getAttribute("mode")).willReturn("edit");
        FloodDeterminationDto floodDeterminationDto = generateFloodDeterminationDtoInstance(1L);
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);
        given(bindingResult.hasErrors()).willReturn(false);

        ResponseEntity<BaseApiResponse> response = controller.saveFloodDeterminationDetails(floodDeterminationDto,
                bindingResult,collateralDetailsMainDto, httpServletRequest);

        //Verify that the service will get called with the expected Model
        verify(floodDeterminationService).persistFloodDeterminationSection(collateralDetailsMainDto,
                floodDeterminationDto, "inputDraft");

        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());
    }

    /**
     * - saveFloodDeterminationDetails
     * TestCase:
     *  When saving a Flood determination form validate that the services will NOT be called and
     *  failure response is returned back to client when validation errors were present
     */
    @Test
    public void testSaveFloodDeterminationDetailsValidationFailure(){
        FloodDeterminationDto floodDeterminationDto = generateFloodDeterminationDtoInstance(1L);
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);
        mockErrorInBindingResult("floodZone");

        ResponseEntity<BaseApiResponse> response = controller.saveFloodDeterminationDetails(floodDeterminationDto,
                bindingResult,collateralDetailsMainDto, httpServletRequest);

        //Verify that the service will get called with the expected Model
        verify(floodDeterminationService,never()).persistFloodDeterminationSection(collateralDetailsMainDto,
                floodDeterminationDto, "inputDraft");

        assertThat(response.getStatusCode(),is(HttpStatus.BAD_REQUEST));
        assertThat(response.getBody().getValidationErrors().get(0).getFieldId(),is("floodZone"));
        assertFalse(response.getBody().isSuccess());
    }

    /**
     * - saveFloodDeterminationDetails
     * TestCase:
     *  Exception handling is done and appropriate Exception will get thrown by controller
     */
    @Test(expected = CtracAjaxException.class)
    public void testSaveFloodDeterminationDetailsExceptionHandling() {
        given(httpSession.getAttribute("mode")).willReturn("edit");
        FloodDeterminationDto floodDeterminationDto = generateFloodDeterminationDtoInstance(1L);
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);
        given(bindingResult.hasErrors()).willReturn(false);

        doThrow(new JpaSystemException(new RuntimeException("Error"))).when(floodDeterminationService)
                .persistFloodDeterminationSection(collateralDetailsMainDto,
                        floodDeterminationDto, "inputDraft");

        controller.saveFloodDeterminationDetails(floodDeterminationDto,
                bindingResult, collateralDetailsMainDto, httpServletRequest);

        //Verify that the service will get called with the expected Model
        verify(floodDeterminationService).persistFloodDeterminationSection(collateralDetailsMainDto,
                floodDeterminationDto, "inputDraft");
    }


    /**
     * - updateFloodDetermination
     * TestCase:
     *  When deletion of a Flood determination form is submitted, verify that the service gets called
     **/
    @Test
    public void testUpdateFloodDeterminationSuccess(){
        given(httpSession.getAttribute("mode")).willReturn("edit");
        FloodDeterminationDto floodDeterminationDto = generateFloodDeterminationDtoInstance(1L);
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);

        ResponseEntity<BaseApiResponse> response = controller.updateFloodDetermination(collateralDetailsMainDto,
                floodDeterminationDto ,"delete", model, httpServletRequest);

        //Verify that the service will get called with the expected Model
        verify(floodDeterminationService).persistFloodDeterminationSection(collateralDetailsMainDto,
                floodDeterminationDto, "delete");

        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());
        assertThat(response.getBody().getAction(),is("reload"));
    }

    /**
     * - updateFloodDetermination
     * TestCase:
     *  When deletion of a Flood determination form is submitted,
     *  verify that the exception handling is setup right on the controller
     **/
    @Test(expected = CtracAjaxException.class)
    public void testUpdateFloodDeterminationExceptionHandling(){
        given(httpSession.getAttribute("mode")).willReturn("edit");
        FloodDeterminationDto floodDeterminationDto = generateFloodDeterminationDtoInstance(1L);
        CollateralDetailsMainDto collateralDetailsMainDto = generateCollateralDetailsMainDtoInstance(2L);

        doThrow(new JpaSystemException(new RuntimeException("Error"))).when(floodDeterminationService)
                .persistFloodDeterminationSection(collateralDetailsMainDto,
                        floodDeterminationDto, "delete");

        controller.updateFloodDetermination(collateralDetailsMainDto,
                floodDeterminationDto ,"delete", model, httpServletRequest);

        //Verify that the service will get called with the expected Model
        verify(floodDeterminationService).persistFloodDeterminationSection(collateralDetailsMainDto,
                floodDeterminationDto, "delete");
    }
}
