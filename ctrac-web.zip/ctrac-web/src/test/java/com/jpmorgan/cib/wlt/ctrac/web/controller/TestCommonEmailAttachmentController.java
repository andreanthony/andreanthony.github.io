package com.jpmorgan.cib.wlt.ctrac.web.controller;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockMultipartHttpServletRequest;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.FileItem;




//TODO unfinished

@RunWith(MockitoJUnitRunner.class)
public class TestCommonEmailAttachmentController extends AbstractTestFloodRemapController {


	@InjectMocks
	protected CommonEmailAttachmentController commonEmailAttachmentController;
	
	@Before
	public void setUp() {
		// Process mock annotations
		//MockitoAnnotations.initMocks(this);
//		Mockito.reset(floodRemapService, emailAttachmentsBucket);
		mockMvc = MockMvcBuilders.standaloneSetup(commonEmailAttachmentController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build(); // needed to handle thrown exceptions.build();
		mockTmParams = getDummyTMParams();
	}
	
	@Test
	@Ignore
	public void testUploadEmailAttachments() throws Exception { 
//		mockStaticCreateTMHelperMethod();	
		
		MockMultipartHttpServletRequest multipartRequest = new MockMultipartHttpServletRequest();
		MockHttpServletRequest request = new MockHttpServletRequest();
		
		// EmailAttachments with Fiat file - createMultiPartFile()
		EmailAttachments attachment = new EmailAttachments("key-01");		
		FileItem fileItem = new FileItem(createMultiPartFile(), "MediaCore", "key-01");
		attachment.pushFile(fileItem);
		
		when(emailAttachmentsBucket.popEmailAttachments(any(String.class))).thenReturn(attachment);
		
		String message = "Reseach results has been Saved Successfully!";
		doReturn( message ).when(messageSource).getMessage(any(String.class), any(Object[].class),any(Locale.class) );
		
		Map<String, String> contentTypeParameters = new HashMap<String, String>();
		contentTypeParameters.put("boundary", "265001916915724");
		contentTypeParameters.put("content-type", "multipart");
		MediaType mediaType = new MediaType("multipart", "form-data", contentTypeParameters);
		
		BindingResult binding = null;

		String mv=commonEmailAttachmentController.uploadEmailAttachments(multipartRequest, request, fileItem, binding);
		
//		mockMvc.perform(post("/uploadEmailAttachments/").contentType(mediaType)
//				.sessionAttr("item", fileItem)).andExpect(status().isOk());
/*				.andExpect(view().name("floodRemapConfirmation"))
				.andExpect(model().attribute("floodRemapResearchData", hasProperty("eventType", is(RESEARCH_SAVED.getCode()))) )
				.andExpect(model().attribute("floodRemapResearchData", hasProperty("SFHDF",notNullValue())) ) 
				.andExpect(model().attribute("Success", is(message)) 
				 );*/
	}	
	
	
	//  Fiat file creation
	private MultipartFile createMultiPartFile() {
		return new MockMultipartFile(
			       "testSFDHF.pdf",                //filename
			       "Ctrac Test SFDHF Documents".getBytes()); //content
	}
}
