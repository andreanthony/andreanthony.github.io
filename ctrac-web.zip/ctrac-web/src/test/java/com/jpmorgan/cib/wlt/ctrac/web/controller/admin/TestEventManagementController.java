package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.UUID;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class TestEventManagementController {

	@InjectMocks
	private EventManagementController testObj;

	@Mock
	private PublishEventService publishEventService;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(testObj)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
	}

	@Test
	public void testGet() throws Exception {
		mockMvc.perform(get("/admin/eventManagementPage"))
				.andExpect(status().isOk())
				.andExpect(view().name("/admin/eventManagement"));
	}

	@Test
	public void testRepublishEvent() throws Exception {
		UUID testUuid = UUID.randomUUID();
		mockMvc.perform(post("/api/admin/eventManagement/republish/" + testUuid.toString()))
				.andExpect(status().isOk())
				.andExpect(content().string("Event republished"));
	}

	@Test
	public void testRepublishEventBadUUID() throws Exception {
		mockMvc.perform(post("/api/admin/eventManagement/republish/this-is-not-a-valid"))
				.andExpect(status().isBadRequest())
				.andExpect(content().string("CTRAC_APPLICATION ERROR: Invalid UUID"));
	}

	@Test
	public void testRepublishByDate() throws Exception {
		String contentJson = "{\"fromDate\":\"2018-09-25T01:00:00.000\", \"toDate\":\"2018-09-25T02:00:00.000\"}";
		mockMvc.perform(post("/api/admin/eventManagement/republishByDate")
				.contentType(APPLICATION_JSON_UTF8).content(contentJson))
				.andExpect(status().isOk())
				.andExpect(content().string("Events republished"));
	}

	@Test
	public void testRepublishByDateNoToDate() throws Exception {
		String contentJson = "{\"fromDate\":\"2018-09-25T01:00:00.000\"}";
		mockMvc.perform(post("/api/admin/eventManagement/republishByDate")
				.contentType(APPLICATION_JSON_UTF8).content(contentJson))
				.andExpect(status().isOk())
				.andExpect(content().string("Events republished"));
	}

	@Test
	public void testRepublishByDateNoFromDate() throws Exception {
		String contentJson = "{\"fromDate\":\"\", \"\":\"\"}";
		mockMvc.perform(post("/api/admin/eventManagement/republishByDate")
				.contentType(APPLICATION_JSON_UTF8).content(contentJson))
				.andExpect(status().isBadRequest())
				.andExpect(content().string("From Date is null"));
	}
}
