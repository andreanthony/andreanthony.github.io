package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.mockito.Mockito.doReturn;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TaskStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.PerfectionTaskRepository;
import com.jpmorgan.cib.wlt.ctrac.service.TaskService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralHelperService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;

@RunWith(MockitoJUnitRunner.class)
public class TestFloodRemapGenericHelperController extends AbstractTestFloodRemapController{
	@Mock private PerfectionTaskRepository perfectionTaskRepository;
	@Mock private CollateralHelperService collateralHelperService;
	@Mock private TaskService taskService;
	@InjectMocks private FloodRemapGenericHelperController floodRemapGenericHelperController;

	@Before
	public void setUp(){
		Mockito.reset(collateralHelperService);
		Mockito.reset(taskService);
		mockMvc=MockMvcBuilders.standaloneSetup(
				floodRemapGenericHelperController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
		
		setupSessionRequest();
	}
	
	//@Test
	public void testLaunchRempGenericHelper(){
		mockStaticCreateTMHelperMethod(floodRemapGenericHelperController);
		TMParams tmParams=getMockTMParams();
		boolean isHelperDisabled=false;
		List<TaskStatus> taskStatusList=mockTaskStatus();
		doReturn(isHelperDisabled).when(taskService).isHelperPageDisabled(tmParams,taskStatusList);
	}
	
	@Test
	public void testDisplay404() throws Exception{
		mockMvc.perform(get("/floodRemap/404"))
		.andExpect(status().isOk())		
		.andExpect(view().name("generic/404"));
	}
	
	@Test
	public void testDisplay403() throws Exception{
		mockMvc.perform(get("/floodRemap/permissions"))
		.andExpect(status().isOk())		
		.andExpect(view().name("generic/403"));
	}
	
	private TMParams getMockTMParams(){
		TMParams tmParams=new TMParams();
		tmParams.setId_task("1L");
		tmParams.setUserId("R534840");
		return tmParams;
	}
	
	private List<TaskStatus> mockTaskStatus(){
		List<TaskStatus> taskStatusList=new ArrayList<TaskStatus>();
		taskStatusList.add(TaskStatus.OPEN);
		taskStatusList.add(TaskStatus.CLOSED);
		taskStatusList.add(TaskStatus.SLEEPING);
		taskStatusList.add(TaskStatus.TRANSIENT);
		taskStatusList.add(TaskStatus.TRANSITIONED);
		return taskStatusList;
	}
}
