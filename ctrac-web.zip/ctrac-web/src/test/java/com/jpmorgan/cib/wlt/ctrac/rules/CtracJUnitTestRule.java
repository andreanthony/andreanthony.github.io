package com.jpmorgan.cib.wlt.ctrac.rules;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

public class CtracJUnitTestRule implements TestRule {

    private static ApplicationContext applicationContext = mock(ApplicationContext.class,withSettings().lenient());
    private MessageSource messageSource = mock(MessageSource.class);

    @Override
    public Statement apply(Statement statement, Description description) {
        return new Statement() {
            @Override
            public void evaluate() throws Throwable {
                reset(applicationContext, messageSource);
                addBeanToContext("errorMessageSource",messageSource);
                ApplicationContextProvider.setContext(applicationContext);
                statement.evaluate();
            }
        };
    }

    public <T> void addBeanToContext(Class<T> beanClass, T mockedClass){
        given(applicationContext.getBean(beanClass)).willReturn(mockedClass);
    }

    public <T> void addBeanToContext(String beanClassName, T mockedClass){
        given(applicationContext.getBean(beanClassName)).willReturn(mockedClass);
    }

    public MessageSource getErrorMessageSource(){
        return messageSource;
    }

}
