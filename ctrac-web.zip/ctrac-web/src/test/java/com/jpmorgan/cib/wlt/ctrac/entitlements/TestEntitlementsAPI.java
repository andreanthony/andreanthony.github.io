package com.jpmorgan.cib.wlt.ctrac.entitlements;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestEntitlementsAPI {

    private static final String VALID_USER_ID = "E704298";
    private static final String INVALID_USER_ID = "Z999999";

    @InjectMocks
    private EntitlementsAPI testObj;

    @Mock
    private UserEntitlementService userEntitlementService;

    private static final String API = "/api/entitlements";

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(testObj).build();
    }

    @Test
    public void testRetrieveValid() throws Exception {
        UserEntitlementsDTO userEntitlementsDTO = new UserEntitlementsDTO();
        userEntitlementsDTO.setJanusUsername(VALID_USER_ID);
        userEntitlementsDTO.setSid("E704299");
        userEntitlementsDTO.setFirstName("Collin");
        userEntitlementsDTO.setLastName("Peterson");
        when(userEntitlementService.getByJanusUsername(VALID_USER_ID)).thenReturn(userEntitlementsDTO);
        mockMvc.perform(get(API + "/" + VALID_USER_ID)
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.janusUsername").value(VALID_USER_ID))
                .andExpect(jsonPath("$.sid").value("E704299"))
                .andExpect(jsonPath("$.firstName").value("Collin"))
                .andExpect(jsonPath("$.lastName").value("Peterson"));
        verify(userEntitlementService).getByJanusUsername(VALID_USER_ID);
    }

    @Test
    public void testRetrieveInvalid() throws Exception {
        when(userEntitlementService.getByJanusUsername(INVALID_USER_ID)).thenThrow(new CtracAjaxException("Error"));
        mockMvc.perform(get(API + "/" + INVALID_USER_ID)
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(status().isBadRequest());
        verify(userEntitlementService).getByJanusUsername(INVALID_USER_ID);
    }
}
