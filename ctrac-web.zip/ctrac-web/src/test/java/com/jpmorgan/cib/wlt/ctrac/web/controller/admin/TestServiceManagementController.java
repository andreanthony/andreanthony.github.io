package com.jpmorgan.cib.wlt.ctrac.web.controller.admin;

import com.jpmorgan.cib.wlt.ctrac.enums.ServiceAction;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.EventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.MicroServiceBroadcastEventDTO;
import com.jpmorgan.cib.wlt.ctrac.service.AuditInformationService;
import com.jpmorgan.cib.wlt.ctrac.service.event.service.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureBook;
import com.jpmorgan.cib.wlt.ctrac.service.features.FeatureManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class TestServiceManagementController {

    @Mock private AuditInformationService auditInformationService;
    @Mock private PublishEventService publishEventService;
    @Mock private FeatureManager featureManager;
    private MockMvc mockMvc;
    private static final String CONST_TEST_USER = "testUser";

    @Captor private ArgumentCaptor<MicroServiceBroadcastEventDTO> capturedEvent;

    @Before
    public void setup(){
        given(auditInformationService.getLoggedInUserSid()).willReturn(CONST_TEST_USER);
        given(featureManager.isActive(FeatureBook.MICRO_SERVICES_MANAGEMENT_PAGE)).willReturn(true);
        ServiceManagementController controller = new ServiceManagementController(publishEventService, auditInformationService, featureManager);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testGetPage() throws Exception {
        mockMvc.perform(get("/admin/serviceManagementPage"))
                .andExpect(status().isOk())
                .andExpect(view().name("/admin/serviceManagement"));
    }

    @Test
    public void testGetPageFeatureNotEnabled() throws Exception {
        given(featureManager.isActive(FeatureBook.MICRO_SERVICES_MANAGEMENT_PAGE)).willReturn(false);
        mockMvc.perform(get("/admin/serviceManagementPage"))
                .andExpect(status().isOk())
                .andExpect(view().name("genericErrorPage"));

    }

    @Test
    public void testClearCacheUserEntitlements_Success() throws Exception {
        mockMvc.perform(post("/api/admin/clearCacheUserEntitlements"))
                .andExpect(status().isOk())
                .andExpect(content().string("Clear Cache triggered"));
        verify(publishEventService).publishEvent(capturedEvent.capture());
        assertThat(capturedEvent.getValue().getPerformedBy(),is(CONST_TEST_USER));
        assertThat(capturedEvent.getValue().getActions(),hasItem(ServiceAction.CLEAR_ENTITLEMENTS_CACHE));
    }

    @Test
    public void testClearCacheUserEntitlements_Failure() throws Exception {
        doThrow(new IllegalArgumentException("test Exception")).when(publishEventService)
                .publishEvent(any(EventDTO.class));
        mockMvc.perform(post("/api/admin/clearCacheUserEntitlements"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Sending Clear Cache event failed"));
    }

    @Test
    public void testClearCacheUserEntitlements_Failure_FeatureNotEnabled() throws Exception {
        given(featureManager.isActive(FeatureBook.MICRO_SERVICES_MANAGEMENT_PAGE)).willReturn(false);
        mockMvc.perform(post("/api/admin/clearCacheUserEntitlements"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Feature not enabled"));
    }
}