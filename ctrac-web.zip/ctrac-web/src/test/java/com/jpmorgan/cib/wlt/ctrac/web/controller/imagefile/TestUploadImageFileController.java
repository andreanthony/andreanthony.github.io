package com.jpmorgan.cib.wlt.ctrac.web.controller.imagefile;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FileContent;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.CollateralDocumentRepository;
import com.jpmorgan.cib.wlt.ctrac.service.aggregate.WireProcessingService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.TMParams;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.letterImage.ImageFileData;
import com.jpmorgan.cib.wlt.ctrac.service.letters.LetterImageService;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class TestUploadImageFileController {
    private static final String TM_TASK_ID = "1111-1111-1111-1111";

    @Mock private CollateralDocumentRepository collateralDocumentRepository;
    @Mock private LetterImageService letterImageService;
    @Mock private WireProcessingService wireProcessingService;
    @Mock private MessageSource messageSource;
    @Mock private Environment env;

    @InjectMocks private UploadImageFileController testObj;

    private MockMvc mockMvc;

    @Mock private TMParams tmParams;

    @Before
    public void setup() {
        when(tmParams.getId_task()).thenReturn(TM_TASK_ID);
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testLaunchImageFileHelper() throws Exception {
        ImageFileData imageFileData = mock(ImageFileData.class);
        when(letterImageService.populateImageFileData(tmParams)).thenReturn(imageFileData);
        mockMvc.perform(get("/floodRemap/launchImageFileHelper")
                .sessionAttr("tmParams", tmParams))
                .andExpect(status().isOk())
                .andExpect(view().name("imageLetters"))
                .andExpect(model().attribute("imageFileData", imageFileData));
    }

    @Test
    public void testSubmitImageFileRequest() throws Exception {
        ImageFileData imageFileData = mock(ImageFileData.class);
        when(imageFileData.getTmParams()).thenReturn(tmParams);
        mockMvc.perform(post("/floodRemap/submitImageFileRequest/123")
                .sessionAttr("imageFileData", imageFileData))
                .andExpect(status().isOk())
                .andExpect(view().name("floodRemapConfirmation"));
        verify(letterImageService).processImageFileConfirmation(tmParams);
    }

    @Test
    public void testGetImageFileDetails() throws Exception {
        ImageFileData imageFileData = mock(ImageFileData.class);
        XSSFWorkbook imageFile = mock(XSSFWorkbook.class);
        when(letterImageService.getLetterImageFile(imageFileData)).thenReturn(imageFile);
        mockMvc.perform(get("/floodRemap/getImageFileDetails")
                .sessionAttr("imageFileData", imageFileData))
                .andExpect(status().isOk());
        verify(imageFile).write(any(OutputStream.class));
    }

    @Test
    public void testGetImageFile() throws Exception {
        ImageFileData imageFileData = mock(ImageFileData.class);
        when(imageFileData.getImageFileName()).thenReturn("fileName");
        List<CollateralDocument> imageFiles = new ArrayList<>();
        CollateralDocument imageFile = mock(CollateralDocument.class);
        imageFiles.add(imageFile);
        FileContent fileContent = mock(FileContent.class);
        when(imageFile.getFileContent()).thenReturn(fileContent);
        byte[] fileContentBytes = "fileContent".getBytes();
        when(fileContent.getFileContent()).thenReturn(fileContentBytes);
        when(collateralDocumentRepository.findByFileNameAndDocIdentifier(
                "fileName", CtracAppConstants.IMAGE_FILE_IDENTIFIER)).thenReturn(imageFiles);
        mockMvc.perform(get("/floodRemap/getImageFile")
                .sessionAttr("imageFileData", imageFileData))
                .andExpect(status().isOk());
    }
}
