
package com.jpmorgan.cib.wlt.ctrac.web.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CtracAjaxException;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.CollateralManagementService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.ReviewCollateralService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralDetailsController extends AbstractTestFloodRemapController  {
	
	@InjectMocks
	protected CollateralDetailsController collateralDetailsController;

	@Mock
	ReviewCollateralService reviewCollateralService;	

	@Mock
	CollateralDetailsService collateralDetailsService;	

	@Mock
	CollateralManagementService collateralManagementService;	
	

	@Mock
	CollateralDetailsMainDto collateralDetailsMainDto;
	
	@Mock
	CollateralDto collateralDto;
	
	
	@Before
	public void setUp() {
		Mockito.reset(reviewCollateralService);
		Mockito.reset(collateralManagementService);
		mockMvc = MockMvcBuilders.standaloneSetup(
				collateralDetailsController)
				.setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
	}	

	@Test
	public void deleteBorrowerInsuranceReview() throws Exception {
		String url ="/admin/collateralDetails?collateralID=12345";
		doNothing().when(reviewCollateralService).completeCollateralReview(any(CollateralDetailsMainDto.class));
		doReturn(collateralDto).when(collateralDetailsMainDto).getCollateralDto();
		doReturn(12345L).when(collateralDto).getRid();

	 	mockMvc.perform(post("/admin/completeCollateralReview")
	 			.sessionAttr("collateralDetailsData", collateralDetailsMainDto))
				.andExpect(redirectedUrl(url));

	}

	@Test
	public void testDeleteCollateral() throws Exception {
		doReturn(true).when(collateralDetailsMainDto).isShowDeleteCollateral();
		doReturn(collateralDto).when(collateralDetailsMainDto).getCollateralDto();
		doReturn(12345L).when(collateralDto).getRid();
		doReturn(collateralDetailsMainDto).when(collateralDetailsService).populateCollateralDetailsInformation(any(Long.class));
		doNothing().when(collateralManagementService).deleteCollateral(any(CollateralDto.class));

	 	mockMvc.perform(post("/admin/deleteCollateral")
	 			.sessionAttr("collateralDetailsData", collateralDetailsMainDto));
		verify(collateralDetailsService, times(1)).populateCollateralDetailsInformation(any(Long.class));
		verify(collateralManagementService, times(1)).deleteCollateral(any(CollateralDto.class));
	}

	@Test(expected=Exception.class)
	public void testDeleteCollateralException() throws Exception {
		doReturn(false).when(collateralDetailsMainDto).isShowDeleteCollateral();
		doReturn(collateralDto).when(collateralDetailsMainDto).getCollateralDto();
		doReturn(12345L).when(collateralDto).getRid();
		doReturn(collateralDetailsMainDto).when(collateralDetailsService).populateCollateralDetailsInformation(any(Long.class));

	 	mockMvc.perform(post("/admin/deleteCollateral")
	 			.sessionAttr("collateralDetailsData", collateralDetailsMainDto));
		verify(collateralManagementService, never()).deleteCollateral(any(CollateralDto.class));
	}

}



