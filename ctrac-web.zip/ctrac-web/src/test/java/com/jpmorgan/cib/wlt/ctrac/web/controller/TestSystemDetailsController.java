package com.jpmorgan.cib.wlt.ctrac.web.controller;

import com.jpmorgan.cib.wlt.ctrac.service.dto.base.SystemData;
import com.jpmorgan.cib.wlt.ctrac.web.exception.CTracWebAppException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.*;
import org.springframework.ui.ModelMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * Created by V704662 on 8/18/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestSystemDetailsController {

    @Spy
    @InjectMocks private SystemDetailsController systemDetailsController;
    @Mock private AbstractEnvironment env;
    @Mock private HttpServletRequest request;
    @Mock private HttpServletResponse response;
    @Mock private HttpSession session;
    @Mock private ModelMap map;

    private static final Map<String,String> testSystemProperties = new HashMap<String,String>(){
        {
            put("project-name","test project");
            put("project-version","1.0.0");
            put("build-number","222");
            put("subversion-url","testurl");
            put("subversion-revision","revision1");
            put("unknown","1.0.0");
            put("db-url","jdbc:oracle:thin:@x22t-scan.svr.us.jpmchase.net:6135/LOAND02");
            put("db-user","testUser");
            put("jms-queue","testqueue");
            put("cron.renewal.loaniq.poller.expression","0 00 6 ? * MON-FRI");
            put("cron.althans.response.expression","0 10 10-18 ? * MON-FRI");
            put("cron.serviceLink.poller.expression","0 45 12,16 ? * MON-FRI");
        }
    };

    private Attributes generateManifestAttributes(){
        Attributes attributes  = new Attributes();
        attributes.put(new Attributes.Name("Project-Name"),testSystemProperties.get("project-name"));
        attributes.put(new Attributes.Name("Project-Version"),testSystemProperties.get("project-version"));
        attributes.put(new Attributes.Name("Build-Number"),testSystemProperties.get("build-number"));
        attributes.put(new Attributes.Name("Subversion-URL"),testSystemProperties.get("subversion-url"));
        attributes.put(new Attributes.Name("Subversion-Revision"),testSystemProperties.get("subversion-revision"));
        attributes.put(new Attributes.Name("unKnown"),testSystemProperties.get("unknown"));
        return attributes;
    }

    private Map<String,Object> generateSystemProperties(){
        Map<String,Object> testProperties = new HashMap<>();
        testProperties.put("cron.renewal.loaniq.poller.expression",testSystemProperties.get("cron.renewal.loaniq.poller.expression"));
        testProperties.put("cron.althans.response.expression",testSystemProperties.get("cron.althans.response.expression"));
        testProperties.put("cron.serviceLink.poller.expression",testSystemProperties.get("cron.serviceLink.poller.expression"));
        return testProperties;
    }

    private void mockExpectedProperties(){
        MutablePropertySources propertySources = mock(MutablePropertySources.class);
        List<PropertySource<?>> propertySourceList = new ArrayList<>();
        MapPropertySource propertySource = new MapPropertySource("testProperties", generateSystemProperties());
        propertySourceList.add(propertySource);
        given(propertySources.iterator()).willReturn(propertySourceList.iterator());
        given(env.getPropertySources()).willReturn(propertySources);
    }

    @Before
    public void setup() throws IOException {
        //Mock the manifest input stream on the servlet context in the request
        Manifest testManifest = mock(Manifest.class);
        doReturn(generateManifestAttributes()).when(testManifest).getMainAttributes();
        ServletContext servletContext = mock(ServletContext.class);
        InputStream manifestStream = mock(InputStream.class);
        given(servletContext.getResourceAsStream("/META-INF/MANIFEST.MF")).willReturn(manifestStream);
        given(request.getServletContext()).willReturn(servletContext);
        doReturn(testManifest).when(systemDetailsController).loadManifestFromStream(manifestStream);

        given(request.getRequestURL()).willReturn(new StringBuffer("test url"));

        //Mock the required properties in the environment
        given(env.getRequiredProperty("db.url")).willReturn(testSystemProperties.get("db-url"));
        given(env.getRequiredProperty("db.username")).willReturn(testSystemProperties.get("db-user"));
        given(env.getRequiredProperty("jms.mq.outbound.queue")).willReturn(testSystemProperties.get("jms-queue"));

        mockExpectedProperties();
    }

    private void verifyManifestResults(ArgumentCaptor<SystemData> systemDataArgument){
        assertThat(systemDataArgument.getValue().getProjectName(),is(testSystemProperties.get("project-name")));
        assertThat(systemDataArgument.getValue().getProjectVersion(),is(testSystemProperties.get("project-version")));
        assertThat(systemDataArgument.getValue().getBuildNumber(),is(testSystemProperties.get("build-number")));
        assertThat(systemDataArgument.getValue().getSvnURL(),is(testSystemProperties.get("subversion-url")));
        assertThat(systemDataArgument.getValue().getSvnRevision(),is(testSystemProperties.get("subversion-revision")));
    }


    /**
     * - getSystemDetails
     * TestCase: To Display system properties on admin screen - properties will be put
     * in session and on the model so the view can display them
     */
    @Test
    public void testGetSystemDetailsSuccess(){
        ArgumentCaptor<SystemData> systemDataArgument = ArgumentCaptor.forClass(SystemData.class);
        doNothing().when(session).setAttribute(eq("systemData"), systemDataArgument.capture());

        String result = systemDetailsController.getSystemDetails(request, response, session, map);
        assertThat(result,is("systemDetails"));
        verifyManifestResults(systemDataArgument);
    }

    /**
     * - getSystemDetails
     * TestCase: To Display system properties on admin screen - verify that when an exception is
     * happening the handling is done correctly and appropriate exception is been thrown
     */
    @Test(expected = CTracWebAppException.class)
    public void testGetSystemDetailsExceptionHandling(){
        doThrow(new RuntimeException("Test")).when(session).setAttribute(eq("systemData"), any());

        systemDetailsController.getSystemDetails(request, response, session, map);
    }
}
