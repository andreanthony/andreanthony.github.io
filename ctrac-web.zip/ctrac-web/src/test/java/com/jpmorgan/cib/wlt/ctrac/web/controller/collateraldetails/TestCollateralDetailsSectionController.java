package com.jpmorgan.cib.wlt.ctrac.web.controller.collateraldetails;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.service.collateral.details.CollateralDetailsService;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.EmailAttachments;
import com.jpmorgan.cib.wlt.ctrac.service.dto.base.RealEstateCollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDetailsMainDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.CollateralSectionDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.collateral.dashboard.SectionStatusDto;
import com.jpmorgan.cib.wlt.ctrac.service.dto.json.BaseApiResponse;
import com.jpmorgan.cib.wlt.ctrac.service.filebucket.EmailAttachmentsBucket;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * Created by V704662 on 8/9/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestCollateralDetailsSectionController {

    @InjectMocks private CollateralDetailsSectionController controller;
    private BindingResult bindingResult;
    private HttpSession mockSession;
    private ModelMap mockModelMap;

    private EmailAttachments emailAttachments;
    private static String TASK_UID = "45454";
    @Mock private MessageSource messageSource;
    @Mock private EmailAttachmentsBucket emailAttachmentsBucket;
    @Mock private CollateralDetailsService collateralDetailsService;

    @Before
    public void setup(){
        bindingResult = mock(BindingResult.class);
        mockSession = mock(HttpSession.class);
        mockModelMap = mock(ModelMap.class);

        //Mock the email attachment  to return pre-defined attachment for tests
        emailAttachments = new EmailAttachments(TASK_UID);
        given(messageSource.getMessage("service.save.success.message",null,null)).willReturn("Test Error");
    }


    private CollateralDetailsMainDto generateCollateralDetailsMainDtoInstance(Long collateralRid, boolean inVerify){
        CollateralDetailsMainDto collateralDetailsMainDto = new CollateralDetailsMainDto();
        CollateralSectionDto collateralSectionDto = new CollateralSectionDto();
        SectionStatusDto sectionStatusDto = new SectionStatusDto();
        sectionStatusDto.setCollateralRid(collateralRid);
        sectionStatusDto.setStatusId(inVerify ? VerificationStatus.VERIFIED: VerificationStatus.PENDING_VERIFICATION);
        sectionStatusDto.setShowVerify(inVerify);
        collateralSectionDto.setSectionStatusDto(sectionStatusDto);
        CollateralDto collateralDto = new RealEstateCollateralDto();
        collateralDto.setRid(collateralRid);

        collateralDetailsMainDto.setCollateralDto(collateralDto);
        collateralDetailsMainDto.setCollateralSectionDto(collateralSectionDto);
        return collateralDetailsMainDto;
    }

    /**
     * - saveCollateralSectionInfo
     * TestCase: For saving the collateral details the server side does validation and when validation error
     * found in the Form submission DTO the API will return a response Entity of JSON format with error message
     */
    @Test
    public void testSaveCollateralSectionInfoValidationErrorHandling(){
        //Mock an error in bindingResult
        List<ObjectError> errors = new ArrayList<>();
        errors.add(new FieldError("CollateralDetailsMainDto", "collateralDto.marketEmailAddress","Invalid characters found"));
        given(bindingResult.hasErrors()).willReturn(true);
        given(bindingResult.getAllErrors()).willReturn(errors);

        ResponseEntity<BaseApiResponse> response = controller.saveCollateralSectionInfo(
                generateCollateralDetailsMainDtoInstance(1L, false), bindingResult, mockSession, mockModelMap);
        assertThat(response.getStatusCode(),is(HttpStatus.BAD_REQUEST));
        assertFalse(response.getBody().isSuccess());
        assertThat(response.getBody().getValidationErrors().get(0).getFieldId(),is("collateralDto.marketEmailAddress"));
        assertThat(response.getBody().getValidationErrors().get(0).getMessage(),is("Invalid characters found"));
    }

    /**
     * - saveCollateralSectionInfo
     * TestCase: For saving the collateral details the server side does validation and when no validation error
     * found in the Form submission DTO the API will return a response Entity of JSON format with success message
     */
    @Test
    public void testSaveCollateralSectionInfoValidationOK(){
        given(bindingResult.hasErrors()).willReturn(false);
        //Set a model object in session
        CollateralDetailsMainDto detailsMainDtoInSession = generateCollateralDetailsMainDtoInstance(1L,false);
        given(mockSession.getAttribute("collateralDetailsData")).willReturn(detailsMainDtoInSession);

        CollateralDetailsMainDto detailsMainDto = generateCollateralDetailsMainDtoInstance(1L, false);
        //Mock the behavior when object gets reloaded from DB
        given(collateralDetailsService.populateCollateralDetailsInformation(detailsMainDto.getCollateralDto().getRid()))
                .willReturn(detailsMainDto);

        //Fetch the model attribute that we expect to be set for the form
        ArgumentCaptor<CollateralDetailsMainDto> modelAttrForm =ArgumentCaptor.forClass(CollateralDetailsMainDto.class);
        doReturn(null).when(mockModelMap).addAttribute(eq("collateralDetailsData"), modelAttrForm.capture());

        ResponseEntity<BaseApiResponse> response = controller.saveCollateralSectionInfo(
                detailsMainDto, bindingResult, mockSession, mockModelMap);
        verifyDetailSectionWillGetSaved(modelAttrForm, detailsMainDto,CollateralScreenAction.EDIT);
        assertThat(response.getStatusCode(),is(HttpStatus.OK));
        assertTrue(response.getBody().isSuccess());

    }

    /*Helper function to verify result of a success save / verify collateral details*/
    private void verifyDetailSectionWillGetSaved(ArgumentCaptor<CollateralDetailsMainDto> argumentCaptor ,
                                                 CollateralDetailsMainDto collateralDetailsMainDto, CollateralScreenAction action){
        verify(collateralDetailsService).saveCollateralSectionInfo(eq(collateralDetailsMainDto), eq(action));
        assertThat(argumentCaptor.getValue().getCollateralDto().getRid(),is(collateralDetailsMainDto.getCollateralDto().getRid()));
    }

    /**
     * - verifyCollateralSectionInfo
     * TestCase: For verifying the collateral details the server side does validation and when no validation error
     * found in the Form submission DTO the API will return a response Entity of JSON format with success message
     */
    @Test
    public void testVerifyCollateralSectionInfoValidationOK(){
        given(bindingResult.hasErrors()).willReturn(false);
        //Set a model object in session
        CollateralDetailsMainDto detailsMainDtoInSession = generateCollateralDetailsMainDtoInstance(1L,true);
        given(mockSession.getAttribute("collateralDetailsData")).willReturn(detailsMainDtoInSession);

        CollateralDetailsMainDto detailsMainDto = generateCollateralDetailsMainDtoInstance(1L, true);
        //Mock the behavior when object gets reloaded from DB
        given(collateralDetailsService.populateCollateralDetailsInformation(detailsMainDto.getCollateralDto().getRid()))
                .willReturn(detailsMainDto);

        //Fetch the model attribute that we expect to be set for the form
        ArgumentCaptor<CollateralDetailsMainDto> modelAttrForm =ArgumentCaptor.forClass(CollateralDetailsMainDto.class);
        doReturn(null).when(mockModelMap).addAttribute(eq("collateralDetailsData"), modelAttrForm.capture());

        String response = controller.verifyCollateralSectionInfo(
                detailsMainDto, bindingResult, mockSession, mockModelMap);
        verifyDetailSectionWillGetSaved(modelAttrForm, detailsMainDto,CollateralScreenAction.VERIFY);
        assertThat(response,is("admin/collateralDetailsSection :: collateralDetailsSection"));

    }
}
