package com.jpmorgan.cib.wlt.ctrac.auth;

import com.jpmorgan.cib.wlt.ctrac.auth.janus.JanusAuthenticationRequest;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.janus.client.JanusClientCredential;
import com.jpmorgan.janus.client.JanusClientSession;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManagerImpl.*;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestCtracAuthenticationManagerImpl {

    private static final String COOKIE_CACHE = "COOKIE_CACHE";

    @Spy
    @InjectMocks
    private CtracAuthenticationManagerImpl  ctracAuthenticationManager;
    @Mock private AuthenticationProtocol authenticationProtocol;
    @Mock private Environment env;

    private static final String TEST_CONST_JANUS_SSO_URL = "https://janus-sso-uat.jpmchase.net";
    private static final String TEST_CONST_JANUS_LICENSE_KEY = "LICENSE_KEY";
    private static final String TEST_CONST_JANUS_SSO_F_ACCOUNT = "user";
    private static final String TEST_CONST_JANUS_SSO_PWD = "pwd";

    @Before
    public void setup(){
        ReflectionTestUtils.setField(ctracAuthenticationManager, "authenticationProtocol", authenticationProtocol);
        given(env.getProperty(CONST_JANUS_SSO_URL_KEY)).willReturn(TEST_CONST_JANUS_SSO_URL);
        given(env.getProperty(CONST_JANUS_LICENSE_KEY)).willReturn(TEST_CONST_JANUS_LICENSE_KEY);
        given(env.getProperty(CONST_JANUS_SSO_F_ACCOUNT)).willReturn(TEST_CONST_JANUS_SSO_F_ACCOUNT);
        given(env.getProperty(CONST_JANUS_SSO_P_KEY)).willReturn(TEST_CONST_JANUS_SSO_PWD);
        doReturn(TEST_CONST_JANUS_SSO_F_ACCOUNT).when(ctracAuthenticationManager).decryptValue(TEST_CONST_JANUS_SSO_F_ACCOUNT);
        doReturn(TEST_CONST_JANUS_LICENSE_KEY).when(ctracAuthenticationManager).decryptValue(TEST_CONST_JANUS_LICENSE_KEY);
        doReturn(TEST_CONST_JANUS_SSO_PWD).when(ctracAuthenticationManager).decryptValue(TEST_CONST_JANUS_SSO_PWD);
    }

    @Test
    public void testPostInit(){
        ctracAuthenticationManager.init();
        assertThat(ReflectionTestUtils.getField(ctracAuthenticationManager,"licenseKey"),
                is(TEST_CONST_JANUS_LICENSE_KEY));
        assertThat(ReflectionTestUtils.getField(ctracAuthenticationManager,"janusUser"),
                is(TEST_CONST_JANUS_SSO_F_ACCOUNT));
        assertThat(((AuthenticationProtocol)ReflectionTestUtils.getField(ctracAuthenticationManager,"authenticationProtocol")).config.getSsoUrl(),
                is(TEST_CONST_JANUS_SSO_URL));
    }

    @Test
    public void testCreateAuthenticationRequest(){
        JanusAuthenticationRequest request1 = ctracAuthenticationManager.createAuthenticationRequest();

        assertThat(request1.getId(),is(TEST_CONST_JANUS_SSO_F_ACCOUNT));
        assertThat(String.valueOf(request1.getPassword()),is(TEST_CONST_JANUS_SSO_PWD));
    }



    /**
     * - authenticate
     * TestCase: Validate that when manager is called to get the token, the authentication protocol
     * that was configured will be called to authenticate the call and expecting to return a valid response.
     * @throws CtracAuthenticationException
     */
    @Test
    public void testAuthenticate_Success() throws CtracAuthenticationException {
        AuthenticationResponse expectedResponse = mock(AuthenticationResponse.class);
        given(authenticationProtocol.authenticate(any(JanusAuthenticationRequest.class))).willReturn(expectedResponse);
        assertThat(ctracAuthenticationManager.getAuthenticationToken(),is(expectedResponse));
    }

    /**
     * - authenticate
     * TestCase: Validate that when manager is called to get the token, the authentication protocol
     * that was configured will throw exception for the call and verify that CTracApplicationException exception is thrown back
     * @throws CtracAuthenticationException
     */
    @Test(expected = CTracApplicationException.class)
    public void testAuthenticate_Failure() throws CtracAuthenticationException {
        doThrow(new CtracAuthenticationException(AuthExceptionType.NOT_AUTHORIZED,"error"))
                .when(authenticationProtocol).authenticate(any(AuthenticationRequest.class));
        ctracAuthenticationManager.getAuthenticationToken();
    }


    /**
     * - reAuthenticate
     * TestCase: Validate that when reAuthentication is called the existing connection
     * will get closed and a new token will get created
     * @throws CtracAuthenticationException
     */
    @Test
    public void testReAuthenticate_Success() throws CtracAuthenticationException {
        AuthenticationResponse expectedResponse = mock(AuthenticationResponse.class);
        given(authenticationProtocol.authenticate(any(JanusAuthenticationRequest.class))).willReturn(expectedResponse);

        assertThat(ctracAuthenticationManager.reAuthenticate(),is(expectedResponse));

        //Verify a new request will be made to get a new token
        verify(ctracAuthenticationManager,times(1)).getAuthenticationToken();
        verify(authenticationProtocol,times(1)).closeSession();
    }

    /**
     * - reAuthenticate
     * TestCase: Validate that when manager is called to get the token, the authentication protocol
     * that was configured will throw exception for the call and verify that CTracApplicationException exception is thrown back
     * @throws CtracAuthenticationException
     */
    @Test
    public void testReAuthenticate_Failure() throws CtracAuthenticationException {
        doThrow(new CtracAuthenticationException(AuthExceptionType.NOT_AUTHORIZED,"error"))
                .when(authenticationProtocol).closeSession();
        ctracAuthenticationManager.reAuthenticate();
        verify(ctracAuthenticationManager).getAuthenticationToken();
    }

    /**
     * - authConnectionIsTimedOut
     * TestCase: Validate that it will return correct flag when time out exception is passed
     * @throws CtracAuthenticationException
     */
    @Test
    public void testAuthConnectionIsTimedOut(){
        assertTrue(ctracAuthenticationManager.authConnectionIsTimedOut(new CtracAuthenticationException(AuthExceptionType.SESSION_TIME_OUT,302)));
        assertFalse(ctracAuthenticationManager.authConnectionIsTimedOut(new CtracAuthenticationException(AuthExceptionType.NOT_AUTHORIZED,302)));
        assertFalse(ctracAuthenticationManager.authConnectionIsTimedOut(new CtracAuthenticationException(AuthExceptionType.SESSION_NOT_CLOSED,302)));
        assertFalse(ctracAuthenticationManager.authConnectionIsTimedOut(new CtracAuthenticationException(AuthExceptionType.OTHER,302)));
    }

    @Test
    public void testClearCookieCache(){
        ((Map<String, Object>) ReflectionTestUtils.getField(ctracAuthenticationManager, COOKIE_CACHE)).put("cookie1","value");
        assertThat(((Map<String, Object>) ReflectionTestUtils.getField(ctracAuthenticationManager, COOKIE_CACHE)).size(),
                is(1));
        ctracAuthenticationManager.clearCookieCache();
        assertThat(((Map<String, Object>) ReflectionTestUtils.getField(ctracAuthenticationManager, COOKIE_CACHE)).size(),
                is(0));
    }

    @Test
    public void testGetUserFromRequest_System(){
        String outcome = ctracAuthenticationManager.getUserFromRequest(null);
        assertThat(outcome,is(SYSTEM_USER));
    }

    @Test
    public void testGetUserFromRequest_SIDHeader(){
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);

        List<String> headerNames = new ArrayList<>();
        headerNames.add(JANUS_SID_HEADER);
        List<String> headerValues = new ArrayList<>();
        headerValues.add("TestUser");
        given(httpServletRequest.getHeaderNames()).willReturn(Collections.enumeration(headerNames));
        given(httpServletRequest.getHeaders(JANUS_SID_HEADER)).willReturn(Collections.enumeration(headerValues));
        given(httpServletRequest.getHeader(JANUS_SID_HEADER)).willReturn(headerValues.get(0));
        doReturn(true).when(ctracAuthenticationManager).isTraceLogEnabled();

        String outcome = ctracAuthenticationManager.getUserFromRequest(httpServletRequest);
        assertThat(outcome,is("TestUser"));
    }

    @Test
    public void testGetUserFromRequest_UserHeader(){
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);

        List<String> headerNames = new ArrayList<>();
        headerNames.add(JANUS_USER_HEADER);
        List<String> headerValues = new ArrayList<>();
        headerValues.add("TestUser");
        given(httpServletRequest.getHeaderNames()).willReturn(Collections.enumeration(headerNames));
        given(httpServletRequest.getHeaders(JANUS_USER_HEADER)).willReturn(Collections.enumeration(headerValues));
        given(httpServletRequest.getHeader(JANUS_USER_HEADER)).willReturn(headerValues.get(0));
        doReturn(true).when(ctracAuthenticationManager).isTraceLogEnabled();

        String outcome = ctracAuthenticationManager.getUserFromRequest(httpServletRequest);
        assertThat(outcome,is("TestUser"));
    }

    @Test
    public void testGetUserFromRequest_Cookie(){
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);

        Cookie[] cookies = new Cookie[]{new Cookie(JANUS_SID_HEADER, "TestUser")};
        given(httpServletRequest.getCookies()).willReturn(cookies);

        String outcome = ctracAuthenticationManager.getUserFromRequest(httpServletRequest);
        assertThat(outcome,is("TestUser"));
    }

    @Test
    public void testGetUserFromRequest_NoHeaderAndCookie(){
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        String outcome = ctracAuthenticationManager.getUserFromRequest(httpServletRequest);
        assertThat(outcome,is(SYSTEM_USER));
    }

    @Test
    public void testGetJanusAuthenicationAndCookies_TokenWithCookies(){
        ((Map<String, Object>) ReflectionTestUtils.getField(ctracAuthenticationManager, COOKIE_CACHE)).clear();
        JanusClientSession mockedJanusSession = mock(JanusClientSession.class);
        JanusClientCredential mockedJanusCredentials = mock(JanusClientCredential.class);

        given(mockedJanusSession.getSecurityToken(JanusClientSession.TRUST_LEVEL_HIGH)).willReturn("HighLevel=abc;secure;domain=.net;path=/;");
        given(mockedJanusSession.getSecurityToken(JanusClientSession.TRUST_LEVEL_MEDIUM)).willReturn("MediumLevel=abcd;secure;domain=.net;path=/;;");
        given(mockedJanusSession.getSecurityToken(JanusClientSession.TRUST_LEVEL_LOW)).willReturn("LowLevel=abcde;secure;domain=.net;path=/;;");
        given(mockedJanusSession.getSessionToken()).willReturn("sessionToken=abcdef;");

        doReturn(mockedJanusSession).when(ctracAuthenticationManager).getJanusSession();
        doReturn(mockedJanusCredentials).when(ctracAuthenticationManager).getJanusCredentials();
        doReturn(JanusClientSession.AUTHN_OK).when(mockedJanusSession).authenticate(
                any(URL.class), eq(true), eq(mockedJanusCredentials));

        Cookie[] cookies = ctracAuthenticationManager.getJanusAuthenicationAndCookies();
        assertThat(cookies.length,is(4));
        assertThat(cookies[0].getName(),is("HighLevel"));
        assertThat(cookies[0].getValue(),is("abc"));

        assertThat(cookies[1].getName(),is("MediumLevel"));
        assertThat(cookies[1].getValue(),is("abcd"));

        assertThat(cookies[2].getName(),is("LowLevel"));
        assertThat(cookies[2].getValue(),is("abcde"));

        assertThat(cookies[3].getName(),is("sessionToken"));
        assertThat(cookies[3].getValue(),is("abcdef"));
    }

    @Test
    public void testGetJanusAuthenicationAndCookies_TokenNoCookies(){
        ((Map<String, Object>) ReflectionTestUtils.getField(ctracAuthenticationManager, COOKIE_CACHE)).clear();
        JanusClientSession mockedJanusSession = mock(JanusClientSession.class);
        JanusClientCredential mockedJanusCredentials = mock(JanusClientCredential.class);

        given(mockedJanusSession.getSecurityToken(JanusClientSession.TRUST_LEVEL_HIGH)).willReturn("");
        given(mockedJanusSession.getSecurityToken(JanusClientSession.TRUST_LEVEL_MEDIUM)).willReturn("");
        given(mockedJanusSession.getSecurityToken(JanusClientSession.TRUST_LEVEL_LOW)).willReturn("");
        given(mockedJanusSession.getSessionToken()).willReturn("");

        doReturn(mockedJanusSession).when(ctracAuthenticationManager).getJanusSession();
        doReturn(mockedJanusCredentials).when(ctracAuthenticationManager).getJanusCredentials();
        doReturn(JanusClientSession.AUTHN_OK).when(mockedJanusSession).authenticate(
                any(URL.class), eq(true), eq(mockedJanusCredentials));

        Cookie[] cookies = ctracAuthenticationManager.getJanusAuthenicationAndCookies();
        assertThat(cookies.length,is(0));
    }

    @Test(expected = RuntimeException.class)
    public void testGetJanusAuthenicationAndCookies_FailureJanusResponse(){
        ((Map<String, Object>) ReflectionTestUtils.getField(ctracAuthenticationManager, COOKIE_CACHE)).clear();
        JanusClientSession mockedJanusSession = mock(JanusClientSession.class);
        JanusClientCredential mockedJanusCredentials = mock(JanusClientCredential.class);
        doReturn(mockedJanusSession).when(ctracAuthenticationManager).getJanusSession();
        doReturn(mockedJanusCredentials).when(ctracAuthenticationManager).getJanusCredentials();
        doReturn(JanusClientSession.AUTHN_FAILED).when(mockedJanusSession).authenticate(
                any(URL.class), eq(true), eq(mockedJanusCredentials));

        ctracAuthenticationManager.getJanusAuthenicationAndCookies();
    }

}
