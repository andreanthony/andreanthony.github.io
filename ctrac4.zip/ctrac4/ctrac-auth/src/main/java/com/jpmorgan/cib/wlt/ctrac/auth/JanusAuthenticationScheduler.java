package com.jpmorgan.cib.wlt.ctrac.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * @author N664895
 *
 */
@Service
public class JanusAuthenticationScheduler {

	@Qualifier("ctracAuthenticationManager")
	@Autowired private CtracAuthenticationManager ctracAuthenticationManager;

	private static final Logger LOGGER = LoggerFactory.getLogger(JanusAuthenticationScheduler.class);

	@Scheduled(fixedRate = 1740000)
	public void executeScheduledTask(){
		LOGGER.debug("clearing janus cookies");
		ctracAuthenticationManager.clearCookieCache();
		LOGGER.debug("janus cookies cleared");
	}

}
