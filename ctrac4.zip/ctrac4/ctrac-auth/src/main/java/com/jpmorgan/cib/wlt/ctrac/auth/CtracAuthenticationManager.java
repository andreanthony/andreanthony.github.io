package com.jpmorgan.cib.wlt.ctrac.auth;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public interface CtracAuthenticationManager {

	AuthenticationResponse getAuthenticationToken();

	AuthenticationResponse reAuthenticate();

	boolean authConnectionIsTimedOut(CtracAuthenticationException ex);

	Cookie[] getJanusAuthenicationAndCookies();

	void clearCookieCache();

	String getJanusUserCredentials(HttpServletRequest request);
}
