package com.jpmorgan.cib.wlt.ctrac.auth;

import com.jpmorgan.cib.wlt.ctrac.auth.janus.DefaultJanusLogger;
import com.jpmorgan.cib.wlt.ctrac.auth.janus.JanusAuthProtocolInitConfig;
import com.jpmorgan.cib.wlt.ctrac.auth.janus.JanusAuthenticationRequest;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EncryptionUtil;
import com.jpmorgan.janus.client.JanusClient;
import com.jpmorgan.janus.client.JanusClientCredential;
import com.jpmorgan.janus.client.JanusClientSession;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service(value = "ctracAuthenticationManager")
public class CtracAuthenticationManagerImpl implements CtracAuthenticationManager, AuthenticationManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(CtracAuthenticationManagerImpl.class);
	static final String CONST_JANUS_SSO_F_ACCOUNT = "janus.api.sso.account";
	static final String CONST_JANUS_SSO_P_KEY = "janus.api.sso.pwd";
	static final String CONST_JANUS_SSO_URL_KEY = "janus.api.sso.url";
	static final String CONST_JANUS_LICENSE_KEY = "janus.api.key";

	static final String SYSTEM_USER = "LOCAL";
	static final String JANUS_SID_HEADER = "JANUS_sid";
	static final String JANUS_USER_HEADER = "JANUS_USER";
	private String licenseKey = null;
	private String janusUser = null;
	private static final Map<String, Object> COOKIE_CACHE = new ConcurrentHashMap<String, Object>();

	public static final String COOKIE_AS_STRING = "1";

	static final String COOKIE_AS_ARRAY = "2";
	@Resource
	private Environment env;

	private AuthenticationProtocol authenticationProtocol;

	@PostConstruct
	void init() {
		JanusAuthProtocolInitConfig authProtocolInitConfig = new JanusAuthProtocolInitConfig(
				env.getProperty(CONST_JANUS_SSO_URL_KEY),
				decryptValue(env.getProperty(CONST_JANUS_LICENSE_KEY)));
		this.authenticationProtocol = AuthenticationFactory.createAuthenticationProtocol(authProtocolInitConfig);
		licenseKey = authProtocolInitConfig.getLicenseKey();
		janusUser = decryptValue(env.getProperty(CONST_JANUS_SSO_F_ACCOUNT));
	}


	String decryptValue(String value){
		return EncryptionUtil.decrypt(value);
	}


	@Override
	public JanusAuthenticationRequest createAuthenticationRequest() {
		return new JanusAuthenticationRequest(decryptValue(env.getProperty(CONST_JANUS_SSO_F_ACCOUNT)),
				decryptValue(env.getProperty(CONST_JANUS_SSO_P_KEY)).toCharArray());
	}

	@Override
	public AuthenticationResponse getAuthenticationToken() {
		// Make new authentication request
		try {
			return this.authenticationProtocol.authenticate(createAuthenticationRequest());
		} catch (CtracAuthenticationException ex) {
			LOGGER.error("Get Authentication Token Error", ex);
			throw new CTracApplicationException("E0346", CtracErrorSeverity.APPLICATION);
		}
	}

	@Override
	public AuthenticationResponse reAuthenticate() {
		// Make new authentication request
		try {
			this.authenticationProtocol.closeSession();
		} catch (CtracAuthenticationException ex) {
			LOGGER.error("Closing auth connection Error", ex);
		}
		return getAuthenticationToken();
	}

	@Override
	public boolean authConnectionIsTimedOut(CtracAuthenticationException ex) {
		return AuthExceptionType.SESSION_TIME_OUT == ex.getAuthExceptionType();
	}

	JanusClientSession getJanusSession(){
		return JanusClient.createSession(licenseKey, null, new DefaultJanusLogger());
	}

	JanusClientCredential getJanusCredentials(){
		return JanusClient.createJanusCredential(this.janusUser, decryptValue(env.getProperty(CONST_JANUS_SSO_P_KEY)).toCharArray());
	}

	@Override
	public Cookie[] getJanusAuthenicationAndCookies() {
		LOGGER.debug("getJanusAuthenicationAndCookies::Begin()");
		JanusClientSession session = null;
		try {
			if (COOKIE_CACHE.get(COOKIE_AS_ARRAY) == null) {
				session = getJanusSession();
				JanusClientCredential credential = getJanusCredentials();
				session.setIncludeSessionCookieInResponse(true);
				int authResult = session.authenticate(getInAuthURL(), true, credential);

				if (authResult != JanusClientSession.AUTHN_OK) {
					LOGGER.error("Janus Connection Error/ Authentication Failed.");
					throw new RuntimeException("AURORA_ERROR Janus Authentication Failed for authResult=" + authResult);
				}

				List<Cookie> cookieList = new ArrayList<>();

				String tokenTLH = session.getSecurityToken(JanusClientSession.TRUST_LEVEL_HIGH).replace(".jpmorgan.com", ".jpmchase.net");
				if (!StringUtils.isEmpty(tokenTLH)) {
					cookieList.add(buildCookie(tokenTLH));
				}
				String tokenTLM = session.getSecurityToken(JanusClientSession.TRUST_LEVEL_MEDIUM).replace(".jpmorgan.com", ".jpmchase.net");
				if (!StringUtils.isEmpty(tokenTLM)) {
					cookieList.add(buildCookie(tokenTLM));
				}
				String tokenTLL = session.getSecurityToken(JanusClientSession.TRUST_LEVEL_LOW).replace(".jpmorgan.com", ".jpmchase.net");
				if (!StringUtils.isEmpty(tokenTLL)) {
					cookieList.add(buildCookie(tokenTLL));
				}
				String sessionToken = session.getSessionToken();
				if (!StringUtils.isEmpty(sessionToken)) {
					cookieList.add(buildCookie(sessionToken));
				}

				Cookie[] cookieArray = cookieList.toArray(new Cookie[cookieList.size()]);
				COOKIE_CACHE.put(COOKIE_AS_ARRAY, cookieArray);
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
		LOGGER.debug("getJanusAuthenicationAndCookies::End()");
		return (Cookie[]) COOKIE_CACHE.get(COOKIE_AS_ARRAY);
	}

	private URL getInAuthURL() {
		LOGGER.trace("Inside getInAuthURL()");
		try {
			return new URL(env.getProperty(CONST_JANUS_SSO_URL_KEY));
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}

	private Cookie buildCookie(String cookieStr) {
		if (StringUtils.isEmpty(cookieStr)) {
			throw new IllegalArgumentException("Cookie String must present");
		}
		String[] cookieFields = cookieStr.split(";\\s*");

		if (ArrayUtils.isEmpty(cookieFields)) {
			return null;
		}

		Cookie cookie = createCookie(cookieFields[0]);
		// Only Namevalue is present
		if (cookieFields.length == 1) {
			return cookie;
		}

		for (int j = 1; j < cookieFields.length; j++) {
			if ("secure".equalsIgnoreCase(cookieFields[j])) {
				cookie.setSecure(true);
				continue;
			}

			if (cookieFields[j].indexOf('=') > 0) {
				String[] field = cookieFields[j].split("=");

				if ("domain".equalsIgnoreCase(field[0])) {
					cookie.setDomain(field[1]);
				} else if ("path".equalsIgnoreCase(field[0])) {
					cookie.setPath(field[1]);
				}
			}
		}
		return cookie;

	}

	private Cookie createCookie(String cookieNameVal) {
		String keyValuePair[] = cookieNameVal.split("=");
		if (ArrayUtils.isEmpty(keyValuePair) || keyValuePair.length != 2) {
			LOGGER.error("createCookie() : Cookie NameValue is not correct");
			throw new RuntimeException("Cookie NameValue is not correct");
		}
		return new Cookie(keyValuePair[0], keyValuePair[1]);
	}

	@Override
	public void clearCookieCache() {
		COOKIE_CACHE.clear();
	}

	@Override
	public String getUserFromRequest(HttpServletRequest request) {
		return getJanusUserCredentials(request);
	}

	@Override
	public String getJanusUserCredentials(HttpServletRequest request) {
		if (request == null) {
			return SYSTEM_USER;
		}
		printHeaderRequest(request);

		Cookie[] cookies = null;
		String id_user = request.getHeader(JANUS_SID_HEADER);
		id_user = (id_user != null) ? id_user : request.getHeader(JANUS_USER_HEADER);
		if (id_user == null || id_user.isEmpty()) {
			cookies = request.getCookies();
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					if (cookie.getName().equalsIgnoreCase(JANUS_SID_HEADER)) {
						id_user = cookie.getValue();
						break;
					}
				}
			}
		}
		if (id_user == null) {
			id_user = SYSTEM_USER;
		}
		return id_user;
	}

	private void printHeaderRequest(HttpServletRequest req) {
		if (req != null && req.getHeaderNames() != null && isTraceLogEnabled()) {
			Enumeration names = req.getHeaderNames();
			while (names.hasMoreElements()) {
				String name = (String) names.nextElement();
				// support multiple values
				Enumeration values = req.getHeaders(name);
				if (values != null) {
					while (values.hasMoreElements()) {
						String value = (String) values.nextElement();
						LOGGER.trace("header name: {} value: {}", name, value);
					}
				}
			}
		}
	}

	boolean isTraceLogEnabled(){
		return LOGGER.isTraceEnabled();
	}
}
