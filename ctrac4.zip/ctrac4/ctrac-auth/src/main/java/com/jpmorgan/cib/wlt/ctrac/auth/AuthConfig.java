package com.jpmorgan.cib.wlt.ctrac.auth;

import com.jpmorgan.cib.wlt.ctrac.commons.config.BaseAppConfig;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan(basePackages = {"com.jpmorgan.cib.wlt.ctrac.auth"})
@Import({BaseAppConfig.class})
public class AuthConfig {


}
