package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum CollateralType {

	REAL_ESTATE("Real Estate", "REL", "REAL_ESTATE_SUB_TYPE"),
	CASH("Cash", "CSH", "CASH_SUB_TYPE"),
	SECURITIES("Securities", "SEC", "SECURITIES_SUB_TYPE"),
	TITLED_COLLATERAL("Titled Collateral", "TTL", "TITLED_COLLATERAL_SUB_TYPE"),
	LIFE_INSURANCE("Life Insurance", "LIN", "LIFE_INSURANCE_SUB_TYPE"),
	OTHER("Other", "OTH", "OTHER_SUB_TYPE"),
	BUSINESS_ASSETS("Business Assets/UCC", "BUS",	"BA_UCC_SUB_TYPE");

	private final String description;

	private final String code;

	private final String subTypeCodeSet;

	private CollateralType(String description, String code, String subTypeCodeSet) {
		this.description = description;
		this.code = code;
		this.subTypeCodeSet = subTypeCodeSet;
	}

	public String getDescription() {
		return description;
	}

	public String getCode() {
		return code;
	}

	public String getSubTypeCodeSet() {
		return subTypeCodeSet;
	}

	public static CollateralType findByCode(String code) {
		for (CollateralType type : CollateralType.values()) {
			if (type.getCode().equalsIgnoreCase(code)) {
				return type;
			}
		}
		return null;
	}

	public static CollateralType findByDescription(String description) {
		for (CollateralType type : CollateralType.values()) {
			if (type.getDescription().equalsIgnoreCase(description)) {
				return type;
			}
		}
		return null;
	}
}
