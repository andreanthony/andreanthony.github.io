package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum TMTaskType {
	COLLATERAL,
	FLOOD_REMAP,
	FLOOD_INSURANCE;
	
}
