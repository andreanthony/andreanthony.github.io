package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum CollateralScreenAction {
	EDIT("edit"), VERIFY("verify");
	private String value;

	CollateralScreenAction(String value) {
		this.value = value;
	}
	
	public static CollateralScreenAction getCollateralScreenAction(String value) {
		for (CollateralScreenAction e : CollateralScreenAction.values()) {
			if (e.getValue().equals(value)) {
				return e;
			}
		}
		return null;
	}

	public String getValue() {
		return value;
	}
	
	
}
