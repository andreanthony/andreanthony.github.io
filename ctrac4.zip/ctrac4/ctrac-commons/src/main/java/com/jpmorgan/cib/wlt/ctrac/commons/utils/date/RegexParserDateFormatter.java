package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by E704298 on 8/4/2017.
 */
public class RegexParserDateFormatter extends SimplePatternDateFormatter {
    private final Pattern datePattern;

    public RegexParserDateFormatter(String dateFormat, String patternRegex) {
        super(dateFormat);
        this.datePattern = Pattern.compile(patternRegex);
    }

    @Override
    public Date parse(String fileName) {
        Matcher matcher = datePattern.matcher(fileName);
        if (matcher.find()) {
            return super.parse(fileName.substring(matcher.start(), matcher.end()));
        }
        return null;
    }
}
