package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum LPActions {
	
	NEW_LP("NEW_LP"), 
	RENEW_LP ("RENEW_LP"),	
	CANCEL_LP("CANCEL_LP"),
	CANCEL_BP("CANCEL_BP"),
	NEW_BP("NEW_BP"),
	PENDING_C3("PENDING_C3"), //this status is used to remember to reply-apply C3 to a proof of coverage if it effective day is in the future
	NO_ACTION("NO_ACTION");
	
	private String displayName;
	
	private LPActions(String displayName){ 
		this.displayName = displayName; 
	}
	
	public String getDisplayName() {
		return displayName;
	}
}
