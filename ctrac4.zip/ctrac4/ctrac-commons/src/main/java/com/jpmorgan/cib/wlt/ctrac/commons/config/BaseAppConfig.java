package com.jpmorgan.cib.wlt.ctrac.commons.config;

import javax.annotation.Resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;

@Configuration
@ComponentScan(basePackages = "com.jpmorgan.cib.wlt.ctrac.commons", excludeFilters = { @ComponentScan.Filter(Configuration.class) })
@Import({ DevConfig.class, LocalConfig.class, ProdConfig.class, SitConfig.class, UatConfig.class})
//@EnableAspectJAutoProxy
public class BaseAppConfig {

	@Resource
	private Environment env;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
	@Bean
	public ResourceBundleMessageSource errorMessageSource() {
		ResourceBundleMessageSource source = new ResourceBundleMessageSource();
		source.setBasename(env.getRequiredProperty("error.message.source.basename"));
		source.setUseCodeAsDefaultMessage(true);
		return source;
	}
	
	

}
