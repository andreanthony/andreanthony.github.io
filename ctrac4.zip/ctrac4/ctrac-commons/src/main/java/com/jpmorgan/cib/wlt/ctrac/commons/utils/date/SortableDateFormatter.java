package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

/**
 * Created by E704298 on 8/4/2017.
 */
public class SortableDateFormatter extends SimplePatternDateFormatter {
    private static final String DATE_FORMAT = "yyyyMMdd";

    public SortableDateFormatter() {
        super(DATE_FORMAT);
    }
}
