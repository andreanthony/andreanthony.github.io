package com.jpmorgan.cib.wlt.ctrac.commons.enums;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


public enum CollateralDetailsSection {
	COLLATERAL_BASIC_DETAILS,
	LOAN_BORROWER,
	FLOOD_HAZARD_DETERMINATION_FORM,
	REQUIRED_INSURANCE_COVERAGE,
	INSURANCE_POLICIES,
	WORKFLOW_DETAILS;
	
	public static Set<CollateralDetailsSection> getBasicCollateralSections(){
		return new HashSet<CollateralDetailsSection>(
			Arrays.asList(COLLATERAL_BASIC_DETAILS, LOAN_BORROWER)	
		);  
	}
	
	public static Set<CollateralDetailsSection> getCheckForReleaseCollateralSections(){
		return new HashSet<CollateralDetailsSection>(
			Arrays.asList(COLLATERAL_BASIC_DETAILS, LOAN_BORROWER)	
		);  
	}

	public static Set<CollateralDetailsSection> getAllCollateralSections() {
		return new HashSet<CollateralDetailsSection>(Arrays.asList(values()));
	}
	
	public static Set<CollateralDetailsSection> getSectionsVerifiedAllAtOnce() {
		return new HashSet<CollateralDetailsSection>(
			Arrays.asList(COLLATERAL_BASIC_DETAILS, FLOOD_HAZARD_DETERMINATION_FORM, REQUIRED_INSURANCE_COVERAGE, WORKFLOW_DETAILS)
		);
	}

}
