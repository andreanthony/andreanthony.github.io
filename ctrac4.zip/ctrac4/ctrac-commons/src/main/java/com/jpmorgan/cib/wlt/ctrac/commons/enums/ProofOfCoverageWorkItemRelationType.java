package com.jpmorgan.cib.wlt.ctrac.commons.enums;



public enum ProofOfCoverageWorkItemRelationType {
	
    COLLATERAL_TO_POLICY("COLLATERAL_TO_POLICY"),  		//workflow to make a collateral ready for LP because of expiring policy //review col; ask for fiat ...
    LENDERPLACEMENT_TO_POLICY("LENDERPLACEMENT_TO_POLICY"), 	//workflow to actually track the lender placement completion process to replace //1st/2nd letter ..
	RENEWAL_TO_POLICY("RENEWAL_TO_POLICY"),          //workflow for preparing a proof of coverage for renewal  // contact agent ...
	REMAP_TO_POLICY("REMAP_TO_POLICY"),
	AGENT_RESPONSE_TO_POLICY("AGENT_RESPONSE_TO_POLICY");     		// workflow to process a remap and acquired policy if needed; likely not needed //research?
	
	private String name;
	
	private ProofOfCoverageWorkItemRelationType(String name) {
		this.name = name;
	}
	public String getName(){
		return name;
	}
	
	@Override
	public String toString() {
		return name;
	}
}
