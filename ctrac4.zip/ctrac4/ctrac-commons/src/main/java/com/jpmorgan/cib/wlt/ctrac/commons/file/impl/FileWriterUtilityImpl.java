package com.jpmorgan.cib.wlt.ctrac.commons.file.impl;

import com.jpmorgan.cib.wlt.ctrac.commons.file.FileWriterUtility;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Component
public class FileWriterUtilityImpl implements FileWriterUtility {

	private static final Logger logger = Logger.getLogger(FileWriterUtilityImpl.class);
	
	@Override
	public File write(String directory, String fileName, byte[] content) {
		File file = null;
		FileOutputStream fos = null;
		try {
			file = new File(getPathname(directory, fileName));
			fos = new FileOutputStream(file);
			fos.write(content);
		} catch (IOException e) {
			logger.debug(e.getMessage(), e);
		} finally {
			if (fos != null) {
				try { fos.close(); } catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
		return file;
	}

	@Override
	public File write(String directory, File file) {
		logger.debug("Directory to write: " + directory);
		File destinationDirectory = new File(directory);
		if (!destinationDirectory.exists()) {
			throw new RuntimeException("Directory does not exist: " + directory);
		}
		String fileName = file.getName();
		String destination = getPathname(directory, fileName);
		File destinationFile = new File(destination);
		if (destinationFile.exists()) {
			destinationFile.delete();
		}
		logger.debug("File destination:"+destinationFile.getAbsolutePath());
		try {
			FileUtils.moveFile(file, destinationFile);
		} catch (IOException e) {
			throw new RuntimeException("File was not moved successfully from absolute path:"+file.getAbsolutePath());
		}
		return destinationFile;
	}
	
	private String getPathname(String directory, String fileName) {
		StringBuilder sb = new StringBuilder(directory);
		if (!directory.endsWith("/")) {
			sb.append("/");
		}
		return sb.append(fileName).toString();
	}

}
