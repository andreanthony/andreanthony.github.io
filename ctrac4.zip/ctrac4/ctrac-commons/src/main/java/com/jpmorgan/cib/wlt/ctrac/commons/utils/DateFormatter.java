package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.joda.time.DateTime;

/***
 * @deprecated use appropriate implementation utils.date.DateFormatter interface instead
 */
@Deprecated
public class DateFormatter {
    
    static final String JAVA_SCRIPT_FORMAT = "MMM d YYYY";
    
    static final String SORTABLE_FORMAT = "yyyyMMdd";
    
    private static final String DEFAUL_FORMATTER= CtracAppConstants.DATE_FORMAT_US;
    
	public static Date parseDate(String date, String format) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.parse(date);
	}
	
	public static Date parseDate(String date) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(DEFAUL_FORMATTER);
		return formatter.parse(date);
	}
	
	public static String toJavaScriptDate(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat(JAVA_SCRIPT_FORMAT);
        return formatter.format(date);
    }
	
	public static String toSortableDate(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat(SORTABLE_FORMAT);
        return formatter.format(date);
    }
	
	public static String toString(String format, Date date){
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		String s = formatter.format(date);
		return s;
	}
	
	public static String toString(Date date){
        SimpleDateFormat formatter = new SimpleDateFormat(DEFAUL_FORMATTER);
        String s = formatter.format(date);
        return s;
    }
	

	public static Calendar getMMDDYYDate(Date date, int addDays) {
		Calendar updatedDate = new GregorianCalendar();
		updatedDate.setTime(date);
		if(addDays != 0) {
			updatedDate.add(Calendar.DAY_OF_MONTH, addDays);
		}
		updatedDate.set(Calendar.HOUR_OF_DAY, 0);
		updatedDate.set(Calendar.MINUTE, 0);
		updatedDate.set(Calendar.SECOND, 0);
		updatedDate.set(Calendar.MILLISECOND, 0);
		return updatedDate;
	}
	
	public static Date parseDateTime(String str_date) throws ParseException{
		DateTime referenceDateTime = new DateTime(str_date);
		DateTime returnDate = new DateTime();
		returnDate = returnDate.withDate(referenceDateTime.getYear(), referenceDateTime.getMonthOfYear(), referenceDateTime.getDayOfMonth());
		return returnDate.toDate();
	}
	
}
