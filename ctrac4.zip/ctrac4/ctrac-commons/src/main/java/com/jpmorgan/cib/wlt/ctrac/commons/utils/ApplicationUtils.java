package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import org.apache.log4j.Logger;

//import com.jpmorgan.cib.wlt.ctrac.dto.FloodRemapCoverageInputData;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;

public class ApplicationUtils {

	private static final Logger logger = Logger.getLogger(ApplicationUtils.class);

	public static String setScreenTitle(String taskType) {
		if (TMTaskType.FLOOD_INSURANCE.name().equalsIgnoreCase(taskType)) {
			return "Flood Insurance";
		} else {
			return "Flood Remap";
		}
	}

}
