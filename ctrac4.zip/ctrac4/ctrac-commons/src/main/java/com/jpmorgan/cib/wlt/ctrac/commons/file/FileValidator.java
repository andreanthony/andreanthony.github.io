package com.jpmorgan.cib.wlt.ctrac.commons.file;

import java.io.File;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.FileType;

public interface FileValidator {
	
	boolean isFileType(File file, FileType fileType);
	
	boolean isFileType(String fileName, FileType fileType);

}
