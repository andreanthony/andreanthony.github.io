package com.jpmorgan.cib.wlt.ctrac.commons.enums.propertytype;

/**
 * 
 * This has property types for Althans as well as a mapping between Assurant and Althans property types
 * map: key - Assurant property types; value - Althans property types
 * 
 * @author O586350
 *
 */
public enum AlthansPropertyType {

	DWELLING_RESIDENTIAL("DW", "Dwelling (1-4 Unit) Residential"), 
	MULTI_FAMILY("MF", "5+ Multi Family"), 
	COMMERCIAL("COMM", "Commercial"), 
	CONDO_ASSOC("CA", "Condo Association");
		
	private final String code;
	private final String desc;

	AlthansPropertyType(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	
	
}
