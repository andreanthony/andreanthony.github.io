package com.jpmorgan.cib.wlt.ctrac.commons.file.impl;

import java.io.File;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.FileType;
import com.jpmorgan.cib.wlt.ctrac.commons.file.FileValidator;

@Component
public class FileValidatorImpl implements FileValidator {

	@Override
	public boolean isFileType(File file, FileType fileType) {
		return isFileType(file.getName(), fileType);
	}

	@Override
	public boolean isFileType(String fileName, FileType fileType) {
		return fileType != null && fileType.getExtension().equalsIgnoreCase(FilenameUtils.getExtension(fileName));
	}

}
