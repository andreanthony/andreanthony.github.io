package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import org.apache.commons.io.FilenameUtils;

public class FileProcessingUtil {
	
	public static boolean isZipFile(File file) {
		String extension = FilenameUtils.getExtension(file.getName());
		return "zip".equalsIgnoreCase(extension);
	}
	
	public static void extractZipFile(File file, String destPath) throws ZipException {
		ZipFile zipFile = new ZipFile(file);
		zipFile.extractAll(destPath);
	}
	
	public static void moveAndOverwrite(File file, String destPath) {
		String fileName = file.getName();
		String destination = destPath + CtracAppConstants.PATH_SEPERATOR + fileName;
		if ((new File(destination)).exists()) {
			(new File(destination)).delete();
		}
		file.renameTo(new File(destination));
	}

	public static void moveAndOverwrite(String sourcePath, String destPath) {
		File directory = new File(sourcePath);
		File[] files = directory.listFiles();
		for (File file : files) {
			String destination = destPath + CtracAppConstants.PATH_SEPERATOR +
					 file.getName();
			file.renameTo(new File(destination));
		}
	}

	public static void archiveEntireDirectory(String sourcePath, String destPath) {
		File directory = new File(sourcePath);
		File[] files = directory.listFiles();
		for (File file : files) {
			archiveSingleFile(file, destPath);
		}
	}
	
	public static void archiveSingleFile(File file, String destPath) {
		String timestamp = new SimpleDateFormat("dd-MM-yyyy-hh-mm-").format(new Date());
		String destination = destPath + CtracAppConstants.PATH_SEPERATOR +
				timestamp + file.getName();
		file.renameTo(new File(destination));
	}
	
	
	public static String extractFileName(String filePathName) {
		if (filePathName == null)
			return null;

		int dotPos = filePathName.lastIndexOf('.');
		int slashPos = filePathName.lastIndexOf('\\');
		if (slashPos == -1)
			slashPos = filePathName.lastIndexOf('/');

		if (dotPos > slashPos) {
			return filePathName.substring(slashPos > 0 ? slashPos + 1 : 0, dotPos);
		}
		return filePathName.substring(slashPos > 0 ? slashPos + 1 : 0);
	}

	public static File getPath(String path) {
		File file = new File(path);
		File absolutePath = null;
		if (file != null && file.exists()) {
			File[] listOfFiles = file.listFiles();

			if (listOfFiles != null) {

				for (int i = 0; i < listOfFiles.length; i++) {
					if (listOfFiles[i].isFile()) {
						absolutePath = listOfFiles[i];
					}
				}
			}
		}
		return absolutePath;
	}
	public static void archiveGDSImageEntireDirectory(String sourcePath, String destPath) {
		File directory = new File(sourcePath);
		File[] files = directory.listFiles();
		for (File file : files) {
			archiveFile(file, destPath);
		}
	}
	public static void archiveFile(File file, String destPath) {
		String destination = destPath + CtracAppConstants.PATH_SEPERATOR + file.getName();
		file.renameTo(new File(destination));
	}
	
}
