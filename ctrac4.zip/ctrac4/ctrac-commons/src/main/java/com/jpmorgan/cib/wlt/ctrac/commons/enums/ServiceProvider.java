package com.jpmorgan.cib.wlt.ctrac.commons.enums;

/**
 * Created by I569445 on 3/2/2016.
 */
public enum ServiceProvider {

    TM("TM"),
    RSAM("RSAM");

    private ServiceProvider(String name) {
        this.name = name;
    }

    private String name;

    public String getName() {
        return name;
    }

}
