package com.jpmorgan.cib.wlt.ctrac.commons.enums;

import java.math.BigDecimal;

/**
 * Created by V704662 on 10/4/2017.
 */
public enum PendingPaymentChangeTerm {

    ONE_MONTH("1 month"),
    THREE_MONTHS("3 months"),
    FIVE_MONTHS("5 months"),
    NINE_MONTHS("9 months");

    private String desc;

    private PendingPaymentChangeTerm(String desc){
        this.desc = desc;
    }

    public static PendingPaymentChangeTerm calcForShortageAmount(BigDecimal shortageAmount) {
        if(shortageAmount == null || shortageAmount.compareTo(BigDecimal.ZERO) == 0){
            return null;
        }
        if(shortageAmount.compareTo(BigDecimal.valueOf(999.99d)) <= 0){
            return ONE_MONTH;
        }else if(shortageAmount.compareTo(BigDecimal.valueOf(1999.99d)) <= 0){
            return THREE_MONTHS;
        }else if(shortageAmount.compareTo(BigDecimal.valueOf(4999.99d)) <= 0){
            return FIVE_MONTHS;
        }else{
            return NINE_MONTHS;
        }
    }

    public String getDesc() {
        return desc;
    }
}
