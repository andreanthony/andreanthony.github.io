package com.jpmorgan.cib.wlt.ctrac.commons.exception;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracTMErrorCodeEnum;

/**
 * 
 * This class handles exceptions for LTM client
 * 
 */
public class CtracTMApplicationException extends CtracTMBaseException {
	/**
	 * Serial version id for this serializable object.
	 */
	private static final long serialVersionUID = -3540105672014887971L;

	public CtracTMApplicationException(String errorMessage) {
		super(errorMessage);
	}

	public CtracTMApplicationException(String errorMessage, Object[] attributes, Throwable throwable) {
		super(errorMessage, attributes, throwable);
	}

	public CtracTMApplicationException(String errorCode, String errorMessage, Object[] attributes,
			Throwable throwable) {
		super(errorMessage, attributes, throwable);
	}
	
	   public CtracTMApplicationException(String errorCode, CtracErrorSeverity severity, Throwable throwable)
	    {
	    	super(errorCode);
	    }
	
	/*public CtracTMApplicationException(String errorCode, CtracErrorSeverity severity, Throwable throwable) {
		super(severity, throwable);
	}*/


	public CtracTMApplicationException(CtracTMErrorCodeEnum errorCodeEnum, String errorMessage, Object[] attributes, Throwable throwable) {
		super(errorCodeEnum, errorMessage, attributes, throwable);
	}

	@Override
	public String getMessage() {
		return super.getErrorMessage();
	}

}
