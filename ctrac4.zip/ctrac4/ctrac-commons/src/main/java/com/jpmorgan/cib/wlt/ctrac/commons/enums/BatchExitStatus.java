package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum BatchExitStatus {

	ALL_SUCCESSFUL ("All tasks where completed successfully"),
	
	PARTIALLY_FAIL ("Some Of the tasks failled"),
	
	ALL_FAIL ("All tasks failled"),
	
	FAILLED_TO_RECONCILE ("tasks were completed successfully but the reconciliation didn't match"),
	
	NO_ACTION_TAKEN ("Nothing was done, the active job queue was empty"),
	
	RECON_PARTIALLY_FAIL ("Reconcilation failed for some of the records."),
	
	RECON_NO_ACTION_TAKEN ("Nothing was done, no record is available for reconcilation."),
	
	RECON_FAILLED_TO_RECONCILE ("Reconcilation process has not reconciled all the records."),
	
	RECON_ALL_SUCCESSFUL ("Reconcilation completed successfully");
	
	
	private final String description;
	
	BatchExitStatus(String description){
		this.description = description;
	}
	
	public String getStatusDescription(){
		return description;
	}
}
