package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

import java.util.Date;

/**
 * Created by E704298 on 8/2/2017.
 */
public interface DateFormatter {

    Date parse(String date);

    String print(Date date);

}
