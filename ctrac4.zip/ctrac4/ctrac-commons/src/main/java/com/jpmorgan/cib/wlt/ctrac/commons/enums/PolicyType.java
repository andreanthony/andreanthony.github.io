package com.jpmorgan.cib.wlt.ctrac.commons.enums;

import org.apache.log4j.Logger;

import java.util.HashSet;
import java.util.Set;

public enum PolicyType {
	
    APPLICATION("Application"),
	BINDER("Binder"),
	ACCORD("Accord"),
	NFIP("NFIP"),
	PRIVATE("Private"),
	LP("Primary Flood"),
	LP_GAP("Flood Gap"),
	LP_EXCESS("Excess/DIC Flood");

    private static final Logger logger = Logger.getLogger(PolicyType.class);

	private String displayName;
	
	PolicyType(String displayName){
		this.displayName = displayName; 
	}
	
	public String getDisplayName() {
		return displayName;
	}

    /**
     * @return true if this is a borrower provided policy, including application or binder
     */
	public boolean isBorrowerPolicy() {
	    return isPolicy() || isApplicationOrBinder();
	}
	
	public boolean isLenderPlaced() {
	    return this == LP || this == LP_GAP || this == LP_EXCESS;
	}
	
	public static Set<PolicyType> lpPolicyTypes(){
		return new HashSet<PolicyType>(){{
			add(LP);
			add(LP_GAP);
			add(LP_EXCESS);
		}};
	}
	
	public static Set<PolicyType> borrowerPolicyTypes(){
		return new HashSet<PolicyType>(){{
			add(ACCORD);
			add(NFIP);
			add(PRIVATE);
			add(APPLICATION);
			add(BINDER);
		}};
	}
	
	public boolean isPolicy(){
		return this ==  ACCORD || this == NFIP || this == PRIVATE;
	}
	
	public boolean isApplicationOrBinder() {
		return this == APPLICATION || this == BINDER;
	}
	
	public static boolean isLenderPlace(String policyType) {
		try {
			return PolicyType.valueOf(policyType).isLenderPlaced();
		} catch (Exception e) {
            logger.error("PolicyType cannot be converted=" + policyType, e);
        }
	    return false;
	}

	public boolean isLpExcessCoverageOnly(){
		return this == PolicyType.LP_EXCESS;
	}

	public boolean isLpPrimaryCoverageOnly(){
		return this == LP || this == LP_GAP;
	}
	
}
