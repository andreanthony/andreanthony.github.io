package com.jpmorgan.cib.wlt.ctrac.commons.enums;

/**
 * Created by V704662 on 8/18/2017.
 */
public enum UserEntitlementAction {

    ADD("Add new User to System"),
    DELETE("Delete user from System"),
    UPDATE("Update existing user from System"),
    DISABLE("Disable the account of a user from System"),
    SEARCH("Search for a user in system");

    private String description;

    UserEntitlementAction(String value) {
        this.description = value;
    }

    public String getDescription() {
        return description;
    }
}
