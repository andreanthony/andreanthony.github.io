package com.jpmorgan.cib.wlt.ctrac.commons.file;

import java.io.File;

public interface FileWriterUtility {

	File write(String directory, String fileName, byte[] content);
	
	File write(String directory, File file);
	
}
