package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum TaskSynchAction {

	CREATE_NEW_TM, //any wfsids that are prior to Assurant Batch
	UPDATE, // any wfsids after Assurant upto awaiting vendor..
	CLOSE_TM; // any wfsids after awaiting vendor..
	
	/*
	 * TO BE ADDED IN FUTURE:
	 * CTRAC_LETTER_CYCLE
	 * ALTHENS_LP_POLICY
	 */
	
}
