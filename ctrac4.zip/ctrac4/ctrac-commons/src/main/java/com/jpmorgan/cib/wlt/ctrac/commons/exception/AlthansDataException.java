package com.jpmorgan.cib.wlt.ctrac.commons.exception;

public class AlthansDataException extends RuntimeException {
	public AlthansDataException(String message) {
		super(message);
	}
}
