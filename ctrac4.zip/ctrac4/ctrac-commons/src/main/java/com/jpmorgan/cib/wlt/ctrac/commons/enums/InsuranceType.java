package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum InsuranceType {
	FLOOD("Flood"),
	HAZARD("Hazard");
	
	private String displayValue;
    
    private InsuranceType(String displayValue) {
        this.displayValue = displayValue;
    }
    
    public String getDisplayValue() {
        return displayValue;
    }
}
