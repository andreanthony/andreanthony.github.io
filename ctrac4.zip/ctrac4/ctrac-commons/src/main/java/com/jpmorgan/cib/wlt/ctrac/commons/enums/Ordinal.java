package com.jpmorgan.cib.wlt.ctrac.commons.enums;
public enum Ordinal {
	FIRST("First", "1st"), SECOND("Second", "2nd"), THIRD("Third", "3rd");
	
	private String ordinalword;
	private String OrdinalInst;

	private Ordinal(String ordinalword, String ordinalInst) {
		this.ordinalword = ordinalword;
		this.OrdinalInst = ordinalInst;
	}

	public String getOrdinalword() {
		return ordinalword;
	}

	public String getOrdinalInst() {
		return OrdinalInst;
	}

}
