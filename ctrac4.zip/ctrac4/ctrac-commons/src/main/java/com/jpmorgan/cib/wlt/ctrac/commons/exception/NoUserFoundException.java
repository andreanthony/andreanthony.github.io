package com.jpmorgan.cib.wlt.ctrac.commons.exception;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;

/**
 * Created by V704662 on 8/21/2017.
 */
public class NoUserFoundException extends CTracBaseException{

    public NoUserFoundException(String errorCode, CtracErrorSeverity severity){
        super(errorCode, severity);
    }
}
