package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum PaymentType {
	
	MARKET_COST_CENTER("MCC", "Market Cost Center"),
	DEPOSIT_ACCOUNT_NUMBER("CA", "Deposit Account Number"), 
	APPLY_TO_LOAN("ATL", "Apply to Loan"),
	CASHIERS_CHECK("CC", "Cashiers Check");
	
	private String code;
	private String name;
	
	private PaymentType(String code, String paymentType){
		this.code = code;
		this.name = paymentType;
	}

	public String getCode() {
		return code;
	}
	
	public String getName() {
		return name;
	}

	public static PaymentType getPaymentType(String sought){
		for(PaymentType pt: PaymentType.values()){
			if(sought.trim().equalsIgnoreCase(pt.getName()))
				return pt;
		}
		return null;
	}
	
}
