package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;

/**
 * Created by E704298 on 8/4/2017.
 */
public class DefaultDateFormatter extends SimplePatternDateFormatter {
    private static final String DATE_FORMAT = CtracAppConstants.DATE_FORMAT_US;

    public DefaultDateFormatter() {
        super(DATE_FORMAT);
    }
}
