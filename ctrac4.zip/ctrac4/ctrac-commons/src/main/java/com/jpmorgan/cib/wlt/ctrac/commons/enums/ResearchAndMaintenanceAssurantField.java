package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum ResearchAndMaintenanceAssurantField {
	
	POLICY_RID(0),
	METHOD_OF_PAYMENT(1),
	LOAN_NUMBER(2),
	COST_CENTER(3),
	GENERAL_LEDGER(4),
	DDA_NUMBER(5),
	LENDER_BRANCH(6),
	POLICY_CLIENT_NAME(7),
	POLICY_EFFECTIVE_DATE(8),
	POLICY_NUMBER(9),
	PREMIUM_AMOUNT(10),
	WIRE_DATE(11),
	FED_REF_NUMBER(12);
	
	private int column;
	
	private ResearchAndMaintenanceAssurantField(int column) {
		this.column = column;
	}
	
	public int getColumn() {
		return column;
	}	

}
