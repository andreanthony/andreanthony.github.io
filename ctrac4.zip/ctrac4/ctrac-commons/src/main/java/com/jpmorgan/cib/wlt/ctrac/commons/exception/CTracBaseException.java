package com.jpmorgan.cib.wlt.ctrac.commons.exception;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ERR_SEVERITY_APPLICATION_MESSAGE;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ERR_SEVERITY_CRITICAL_MESSAGE;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ERR_SEVERITY_TRIVIAL_MESSAGE;

import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;

public class CTracBaseException extends RuntimeException {

	/**
	 * Serial version id for this serializable object.
	 */
	private static final long serialVersionUID = 2348153845933784001L;

	/**
	 * An identifier that uniquely identifies the message id associated with this exception instance.
	 * This message Id can be used to look up for message associated with
	 * this exception in message.properties file.
	 */
	private String errorCode = null;

	private String errorMessage = null;
	
	private CtracErrorSeverity severity = null;

	private static Logger logger = Logger.getLogger(CTracBaseException.class);

	/**
	 * Map of model and view which is setup in ModelAndView object for an error page
	 */
	private Map<String, Object> modelViewObject = null;

	/**
	 * Error page definition  to redirect and display the message according to message id 
	 */
	private String strErrorPage = null;

	/**
	 * Constructor for the LCPException  class that creates an exception instance with an
	 * associated message Id.
	 */
	public CTracBaseException() {
		super();
		setExceptionParameters(null, null, null, null);
	}

	/**
	 * Constructor for the LCPException  class that creates an exception instance with an
	 * associated message Id.
	 */
	public CTracBaseException(String errorCode, CtracErrorSeverity severity) {
		super();
		setExceptionParameters(errorCode,severity, null, null);
	}

	/**
	 * Constructor for the LCPException class that creates an exception instance with an
	 * associated message Id, model view objects and error page definition
	 * @param strMsgId Message identifier configured in message.properties file
	 * @param modelViewObject Map for model view objects
	 * @param strErrorPage error page definition configured in tiles-def.xml
	 */
	public CTracBaseException(String errorCode, CtracErrorSeverity severity, Map<String, Object> modelViewObject, String strErrorPage) {
		super();
		setExceptionParameters(errorCode, severity, modelViewObject, strErrorPage);
	}

	/**
	 * Constructor for the LCPException class that creates an exception instance with an
	 * associated message Id,  model view objects, error page definition and throwable objects
	 * @param strMsgId Message identifier configured in message.properties file
	 * @param modelViewObject Map for model view objects
	 * @param strErrorPage error page defination configured in tiles-def.xml
	 * @param throwable Throwable instance of exception
	 */
	public CTracBaseException(String errorCode, CtracErrorSeverity severity, Map<String, Object> modelViewObject, String strErrorPage,
			Throwable throwable) {
		super(throwable);
		logger.error("exception reached in base ctrac base application exception"); 
		logger.error(ExceptionUtils.getFullStackTrace(throwable)); 
		setExceptionParameters(errorCode,severity, modelViewObject, strErrorPage);
	}

	/**
	 * Constructor for the LCPException class that creates an exception instance with an
	 * associated message Id and error page definition
	 * @param strMsgId Message identifier configured in message.properties file
	 * @param strErrorPage error page definition configured in tiles-def.xml
	 */
	public CTracBaseException(String errorCode, CtracErrorSeverity severity,  String strErrorPage) {
		super();
		setExceptionParameters(errorCode, severity, null, strErrorPage);

	}

	/**
	 * Constructor for the LCPException class that creates an exception instance with an
	 * associated message Id, error page definition and throwable instance
	 * @param strMessageId Message identifier configured in message.properties file
	 * @param errorPageStr error page definition configured in tiles-def.xml
	 * @param throwableObject Throwable instance of exception
	 */
	public CTracBaseException(String errorCode, CtracErrorSeverity severity,  String errorPageStr, Throwable throwableObject) {
		super(throwableObject);
		logger.error("exception reached in base ctrac base application exception"); 
		logger.error(ExceptionUtils.getFullStackTrace(throwableObject)); 
		setExceptionParameters(errorCode, severity,  null, errorPageStr);

	}

	/**
	 * Constructor for the LCPException class that creates an exception instance with an
	 * associated message Id and Throwable objects
	 * @param strMsgId Message identifier configured in message.properties file
	 * @param throwable Throwable instance of exception
	 */
	public CTracBaseException(String errorCode, CtracErrorSeverity severity,  Throwable throwable) {
		super(throwable);
		logger.error("exception reached in base ctrac base application exception"); 
		logger.error(ExceptionUtils.getFullStackTrace(throwable)); 
		setExceptionParameters(errorCode, severity,  null, null);

	}

	/**
	 * getter to retrieve the message id 
	 * @param return String message id
	 */
	public String getErrorMessage() {
		
		return this.errorMessage;
		
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}


	/**
	 * getter to retrieve the map of model view objects 
	 * @param return Map<String, Object> model view objects
	 */
	public Map<String, Object> getModelViewObject() {
		return this.modelViewObject;
	}

	/**
	 * getter to retrieve the error page definition 
	 * @param return String error page definition
	 */
	public String getStrErrorPage() {
		return this.strErrorPage;
	}

	/**
	 * private method use the set the message id, model view object and error page 
	 * to respective instance variable
	 * @param strMsgId Message identifier configured in message.properties file
	 * @param modelViewObject Map for model view objects
	 * @param strErrorPage error page definition configured in tiles-def.xml
	 */
	private void setExceptionParameters(String errorCodeNew, CtracErrorSeverity severity, Map<String, Object> modelViewObjectNew,
			String strErrorPageNew) {
		this.errorCode = errorCodeNew;
		this.severity = severity;
		this.modelViewObject = modelViewObjectNew;
		this.strErrorPage = strErrorPageNew;

//Set Error Message based on severity. 		
		
		StringBuffer errMessage = new StringBuffer();
		
		switch(this.severity){
		case CRITICAL:
			errMessage.append(ERR_SEVERITY_CRITICAL_MESSAGE);
			break;
		case APPLICATION:
			errMessage.append(ERR_SEVERITY_APPLICATION_MESSAGE);
			break;
		case TRIVIAL:
			errMessage.append(ERR_SEVERITY_TRIVIAL_MESSAGE);
			break;
		default:
			break;
		}

		MessageSource errorMsgSource = null;
		String message = null;
		try {
			errorMsgSource = (MessageSource) ApplicationContextProvider.getContext().getBean(
					"errorMessageSource");
			message = errorMsgSource.getMessage(errorCode, null, Locale.getDefault());
		} catch (IllegalStateException e) {
			logger.error(ERR_SEVERITY_CRITICAL_MESSAGE + " Application Context not set for Exception Handling");
			message = "no message found";
		}
		
		setErrorMessage(errorMessage = errMessage.toString() + " " +  message);
		
		if(this.severity==CtracErrorSeverity.CRITICAL){
			logger.error(this.errorMessage);
		}
		
		
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public CtracErrorSeverity getSeverity() {
		return severity;
	}

}