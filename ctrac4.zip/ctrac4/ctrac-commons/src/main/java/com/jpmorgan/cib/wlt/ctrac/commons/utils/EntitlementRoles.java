package com.jpmorgan.cib.wlt.ctrac.commons.utils;

/**
 * Created by i569445 on 4/27/2016.
 */
public class EntitlementRoles {

    //System Roles
    public static final String READER_ROLE = "ROLE_READER";
    public static final String WRITER_ROLE = "ROLE_WRITER";
    public static final String PROCESSOR_ROLE = "ROLE_PROCESSOR";
    public static final String VERIFER_ROLE = "ROLE_VERIFIER";
    public static final String IDNOW_AUTO_PROVISION = "ROLE_AUTO_PROVISION";
    public static final String L3_READERS = "ROLE_L3_READER";
    public static final String L3_WRITERS = "ROLE_L3_WRITER";
    public static final String OPERATE_WRITERS = "ROLE_OPERATE_WRITERS";
     public static final String EAA_WRITER_ROLE = "ROLE_EAA_WRITER";
    //IDNow only role
    public static final String ENTITLEMENTS_PROCESSOR = "Auto Provisioning Processor";

    //Processor Roles
    public static final String CWLO_PROCESSOR = "CWLO Processor";
    public static final String CTL_PROCESSOR = "Commercial Term Lending Processor";

    //Edit Roles
  //  public static final String OPERATE_WRITERS = "Operate Writers";
   // public static final String L3_WRITERS = "L3 Writers";

    //Verify Roles
    public static final String CWLO_VERIFIER = "CWLO Verifier";

    //Admin Roles
    public static final String ADMIN_ROLE = "ROLE_ADMIN";

    //Read Only Roles
    public static final String CWLO_READERS = "CWLO Readers";
    public static final String CTL_READERS = "Commercial Term Lending Readers";
    public static final String CB_READERS = "Commercial Bank Readers";
    public static final String BB_READERS = "Business Banking Readers";
    public static final String GWM_READERS = "Wealth Management Readers";
  //  public static final String L3_READERS = "L3 Readers";
    public static final String OPERATE_READERS = "Operate Readers";

    public static final String[] READ_ACCESS = {CWLO_READERS, CTL_READERS, CB_READERS, BB_READERS, GWM_READERS, L3_READERS, OPERATE_READERS};
 //   public static final String[] WRITE_ACCESS = {L3_WRITERS, OPERATE_WRITERS};
    public static final String[] VERIFY_ACCESS = {CWLO_VERIFIER};
    public static final String[] PROCESSOR_ACCESS = {CWLO_PROCESSOR, CTL_PROCESSOR};
    public static final String[] ENTITLEMENT_ACCESS = {ENTITLEMENTS_PROCESSOR};

    // API Roles
    public static final String API_ROLE = "ROLE_API";
    public static final String API_PROCESSES = "API Processes";
}
