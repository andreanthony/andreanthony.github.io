package com.jpmorgan.cib.wlt.ctrac.commons.enums;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public enum CoverageType {

    PRIMARY("Primary"),
    EXCESS("Excess"),
	PRIMARY_AND_EXCESS("Primary and Excess");
    
    private String displayValue;
    
    private CoverageType(String displayValue) {
        this.displayValue = displayValue;
    }
    
    public String getDisplayValue() {
        return displayValue;
    }

	public static Collection<CoverageType> getRelatedTypes(CoverageType coverageType) {
		List<CoverageType> relatedTypes = new ArrayList<CoverageType>();
		if(PRIMARY.equals(coverageType) || PRIMARY_AND_EXCESS.equals(coverageType)){
			relatedTypes.add(PRIMARY);
			relatedTypes.add(PRIMARY_AND_EXCESS);
		}
		else if(EXCESS.equals(coverageType)) {
			relatedTypes.add(EXCESS);
		}
		return relatedTypes;
	}

    public boolean isMatching(CoverageType coverageType) {
        return this.equals(coverageType) || PRIMARY_AND_EXCESS.equals(this) || PRIMARY_AND_EXCESS.equals(coverageType);
    }

}
