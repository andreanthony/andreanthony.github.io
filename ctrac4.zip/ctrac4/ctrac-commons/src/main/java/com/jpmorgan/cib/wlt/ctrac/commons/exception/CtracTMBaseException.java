package com.jpmorgan.cib.wlt.ctrac.commons.exception;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracTMErrorCodeEnum;

/**
 * 
 * This class is the base exception handler class for LTM client
 *
 */
public class CtracTMBaseException extends Exception {

	/**
	 * Serial version id for this serializable object.
	 */
	private static final long serialVersionUID = -9117789065871468620L;

	/**
	 * An identifier that uniquely identifies the message id associated with
	 * this exception instance. This message Id can be used to look up for
	 * message associated with this exception in message.properties file.
	 */
	private String errorCode = null;

	private String errorMessage = null;
	
	private static Logger logger = Logger.getLogger(CtracTMBaseException.class);

	/**
	 * Constructor for the CtracTMBaseException class that creates an exception instance
	 * with an associated message Id.
	 */
	public CtracTMBaseException() {
		super();
		formStatusObject(null, null, null, null);
	}

	/**
	 * Constructor for the LCPException class that creates an exception instance
	 * with an associated message Id.
	 */
	public CtracTMBaseException(String errorMessage) {
		super();
		formStatusObject(null, errorMessage, null, null);
	}

	/**
	 * Constructor for the CtracTMBaseException class that creates an exception instance
	 * @param strMsgId Message identifier configured in message.properties file
	 * @param throwable Throwable instance of exception
	 */
	public CtracTMBaseException(String errorMessage, Object[] attributes, Throwable throwable) {
		super(throwable);
		formStatusObject(null, errorMessage, attributes, throwable);
	}
	
	public CtracTMBaseException(String errorMessage, Throwable throwable) {
		super(throwable);
		formStatusObject(null, errorMessage, null, throwable);
	}
	
	/**
	 * Constructor for the CtracTMBaseException class that creates an exception instance
	 * @param errorCode
	 * @param errorMessage
	 * @param attributes
	 * @param throwable
	 */
	public CtracTMBaseException(CtracTMErrorCodeEnum errorCodeEnum, String errorMessage, Object[] attributes, Throwable throwable) {
		super(throwable);
		formStatusObject(errorCodeEnum, errorMessage, attributes, throwable);
	}

	/**
	 * Constructor for the CtracTMBaseException class that creates an exception instance
	 * @param errorMsg
	 * @param taskId
	 * @param throwable
	 */
	private void formStatusObject(CtracTMErrorCodeEnum errorCodeEnum, String errorMessage, Object[] attributes, Throwable throwable) {
		this.errorMessage = String.format(errorCodeEnum == null ?  errorMessage : errorCodeEnum.getErrorDescription(), attributes);
		this.errorCode = errorCodeEnum == null ? null : errorCodeEnum.getErrorCode();
		logger.error(this.errorMessage, throwable);
	}

	/**
	 * Getter to retrieve the message id 
	 * @param return String message id
	 */
	public String getErrorMessage() {
		return this.errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}