package com.jpmorgan.cib.wlt.ctrac.commons.enums;

/**
 * 
 * This enum contains the application error codes/description of the LTM client
 *
 */
public enum CtracTMErrorCodeEnum {
	//TODO confirm on the error codes
	E0003("E0003", "An exception occured in create task [%s], when connecting to TM client. Exception: %s"); 
	

	private String errorDescription;
	private String errorCode;

	private CtracTMErrorCodeEnum(String errorCode, String errorDescription) {
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
	}

	public String getErrorDescription() {
		return this.errorDescription;
	}

	public String getErrorCode() {
		return errorCode;
	}

}
