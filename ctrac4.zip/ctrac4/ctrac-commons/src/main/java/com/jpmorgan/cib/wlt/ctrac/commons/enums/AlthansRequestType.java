package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum AlthansRequestType {
	
	NEW_ISSUE("New Issue"), 
	CANCELLATION("Cancellation Notification"),
	RENEWAL("Renewal"),
	REVISIONS("Revisions to Supplmental Dec");
	
	private String desc;
	
	AlthansRequestType(String desc){
		this.desc = desc;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public static AlthansRequestType fromString(String desc) {
		for (AlthansRequestType b : AlthansRequestType.values()) {
			if (b.desc.equalsIgnoreCase(desc)) {
				return b;
			}
		}
		return null;
	}
}
