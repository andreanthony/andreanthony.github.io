package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum AlthansLPFileFieldPositions {
	
	SERVICING_TEAM(0),
	POLICY_RID(1),
	REQUEST_TYPE(3),
	/*METHOD_OF_PAYMENT(1),
	LOAN_NUMBER(2),
	COST_CENTER(3),
	GENERAL_LEDGER(4),
	DDA_NUMBER(5),
	LENDER_BRANCH(6),
	POLICY_CLIENT_NAME(7),
	POLICY_EFFECTIVE_DATE(8),
	POLICY_NUMBER(9),
	PREMIUM_AMOUNT(10),
	WIRE_DATE(11),*/
	BLND_COVERAGE_AMT(23),
	CNT_COVERAGE_AMT(24),
	BI_COVERAGE_AMT(25), 
	PRIMIUM_AMOUNT(27),
	REFUND_AMOUNT(28);
	
	private int column;
	
	private AlthansLPFileFieldPositions(int column) {
		this.column = column;
	}
	
	public int getColumn() {
		return column;
	}	

}
