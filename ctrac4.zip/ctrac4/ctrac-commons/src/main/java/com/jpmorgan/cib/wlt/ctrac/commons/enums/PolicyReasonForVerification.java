package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum PolicyReasonForVerification {
	OTHER,
	CANCELATION_DATE_ENTERED;	
}
