package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FilenameValidator {

	private static final String FILENAME_REGEX = "^[\\w\\-.+@ ]+$";
	
	private static final Pattern FILENAME_PATTERN = Pattern.compile(FILENAME_REGEX);
	
	public static boolean isValidFilename(String filename) {
		Matcher matcher = FILENAME_PATTERN.matcher(filename);
		return matcher.matches();
	}
	
}
