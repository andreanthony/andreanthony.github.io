package com.jpmorgan.cib.wlt.ctrac.commons.exception;

/**
 * Created by V704662 on 8/21/2017.
 */
public class MissingDataValidationException extends RuntimeException{

    public MissingDataValidationException(String errorMessage) {
        super(errorMessage);
    }
}
