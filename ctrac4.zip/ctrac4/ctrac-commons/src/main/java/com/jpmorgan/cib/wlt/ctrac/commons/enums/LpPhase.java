package com.jpmorgan.cib.wlt.ctrac.commons.enums;


public enum LpPhase {

	PRE_LETTER_CYCLE, //any wfsids that are prior to Assurant Batch
	ASSURANT_LETTER_CYCLE, // any wfsids after Assurant upto awaiting vendor..
	ASSURANT_LP_POLICY,
	LP_CANCELLATION,
	PRE_RENEWAL
	; // any wfsids after awaiting vendor..
	
	/*
	 * TO BE ADDED IN FUTURE:
	 * CTRAC_LETTER_CYCLE
	 * ALTHENS_LP_POLICY
	 */
	
}
