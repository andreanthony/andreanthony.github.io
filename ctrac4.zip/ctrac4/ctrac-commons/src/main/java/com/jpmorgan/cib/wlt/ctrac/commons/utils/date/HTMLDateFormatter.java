package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

public class HTMLDateFormatter extends SimplePatternDateFormatter {
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    public HTMLDateFormatter() {
        super(DATE_FORMAT);
    }
}
