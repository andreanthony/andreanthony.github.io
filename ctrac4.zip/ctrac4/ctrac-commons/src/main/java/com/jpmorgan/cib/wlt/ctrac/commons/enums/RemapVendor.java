package com.jpmorgan.cib.wlt.ctrac.commons.enums;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.date.RegexParserDateFormatter;

import java.util.Date;

/**
 * Created by E704298 on 8/1/2017.
 */
public enum RemapVendor {
    SERVICE_LINK("ServiceLink", new RegexParserDateFormatter("YYYY_MMdd", "\\d{4}_\\d{4}")),
    CORE_LOGIC("CoreLogic", new RegexParserDateFormatter("YYYY_MMdd", "\\d{4}_\\d{4}"));

    private final String displayName;
    private final DateFormatter dateParser;

    RemapVendor(String displayName, DateFormatter dateParser) {
        this.displayName = displayName;
        this.dateParser = dateParser;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static RemapVendor getFromDisplayName(String displayName) {
        for (RemapVendor remapVendor : RemapVendor.values()) {
            if (remapVendor.getDisplayName().equals(displayName)) {
                return remapVendor;
            }
        }
        return null;
    }

    public Date parseDateFromFileName(String fileName) {
        return dateParser.parse(fileName);
    }
}
