package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

/**
 * Created by E704298 on 8/4/2017.
 */
public class JavaScriptDateFormatter extends SimplePatternDateFormatter {
    private static final String DATE_FORMAT = "MMM d YYYY";

    public JavaScriptDateFormatter() {
        super(DATE_FORMAT);
    }
}
