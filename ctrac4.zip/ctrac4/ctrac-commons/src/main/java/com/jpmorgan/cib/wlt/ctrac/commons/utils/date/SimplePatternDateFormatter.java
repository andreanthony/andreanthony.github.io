package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.Date;

/**
 * Created by E704298 on 8/4/2017.
 */
public class SimplePatternDateFormatter implements DateFormatter {
    private final DateTimeFormatter dateFormatter;

    public SimplePatternDateFormatter(String dateFormat) {
        this.dateFormatter = DateTimeFormat.forPattern(dateFormat);
    }

    @Override
    public Date parse(String date) {
        return dateFormatter.parseDateTime(date).toDate();
    }

    @Override
    public String print(Date date) {
        return dateFormatter.print(date.getTime());
    }
}
