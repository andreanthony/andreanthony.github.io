package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum LoanStatus {
	
	PENDING_VERIFICATION("Pending Verification"),
	ACTIVE("Active"),
	RELEASED("Released");
	
	private final String displayName;
	
	private LoanStatus(String displayName) {
		this.displayName = displayName;
	}
	
	public String getDisplayName() {
		return displayName;
	}
	
	public boolean isActive() {
		return this == PENDING_VERIFICATION || this == ACTIVE;
	}
	
	public boolean isInactive() {
		return !isActive();
	}
	
}
