package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum TaskType {
	EMAIL("EMAIL"),
	TMTASKSYNCH("TMTASKSYNCH"),
	OTHER("???");//TODO- define more task types
	
	private String code;
	
	TaskType(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return code;
	}	
}