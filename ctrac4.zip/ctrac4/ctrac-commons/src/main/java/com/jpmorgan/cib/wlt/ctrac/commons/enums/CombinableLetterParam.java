package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum CombinableLetterParam {
    LETTER_TEMPLATE,
    SKIP_LETTER_GENERATION,
    PRIMARY_LOAN_DATA,
    RECIPIENT_RID,
    ASSET_PROPERTY_MAP,
    ASSET_OPTIONS_MAP,
    BORROWERS,
    PROOF_OF_COVERAGE_RID,
    PERFECTION_TASK_RID,
    LETTER_DATE,
    ESCROW_AMOUNT
}
