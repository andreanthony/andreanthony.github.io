package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum EscrowType {
    ESCROW,
    NON_ESCROW;
}