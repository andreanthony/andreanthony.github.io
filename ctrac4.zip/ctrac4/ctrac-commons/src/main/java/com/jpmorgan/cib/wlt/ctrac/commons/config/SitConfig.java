package com.jpmorgan.cib.wlt.ctrac.commons.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;

@Configuration
@Profile("sit")
@PropertySource({"classpath:sit_application.properties", "file:${ctrac.app.properties.path}"})
public class SitConfig {
	
}
