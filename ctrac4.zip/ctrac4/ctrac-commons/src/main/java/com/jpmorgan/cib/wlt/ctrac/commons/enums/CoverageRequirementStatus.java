package com.jpmorgan.cib.wlt.ctrac.commons.enums;
public enum CoverageRequirementStatus {
	   
    PENDING_VERIFICATION ("Pending Verification"),
    VERIFIED("Verified"),
    INACTIVE("Inactive");
    
    private String displayName;
    
    private CoverageRequirementStatus(String displayName){
    	this.displayName =displayName ;
    }

	public String getDisplayName() {
		return displayName;
	}
	
	public static CoverageRequirementStatus findByDisplayName(String displayName){
		
		for(CoverageRequirementStatus cov : CoverageRequirementStatus.values()){
			
			if(cov.getDisplayName().equals(displayName)){
				return cov;
			}
		}
		
		return null;
	}

}
