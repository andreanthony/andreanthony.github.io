package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

public class LongDateFormatter extends SimplePatternDateFormatter {
    private static final String DATE_FORMAT = "EEEE, MMMM d, yyyy";

    public LongDateFormatter() {
        super(DATE_FORMAT);
    }
}
