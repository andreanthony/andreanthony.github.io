package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

import org.joda.time.DateTime;

import java.util.Date;

public class DateRange {
    private Date startDate;
    private Date endDate;

    public DateRange() {
    }

    public DateRange(Date startDate) {
        this.startDate = startDate == null? null : new DateTime(startDate).withTimeAtStartOfDay().toDate();
    }

    public DateRange(Date startDate, Date endDate) {
        this.startDate = startDate == null? null : new DateTime(startDate).withTimeAtStartOfDay().toDate();
        this.endDate = endDate == null? null : new DateTime(endDate).withTimeAtStartOfDay().toDate();
    }

    public boolean isWithinDateRange(Date date) {
        if (startDate == null || date == null) {
            return false;
        }
        return !date.before(startDate)  && (endDate == null || date.before(endDate));
    }

    public boolean isBeforeStartDate(Date date) {
        if (startDate == null || date == null) {
            return false;
        }
        return date.before(startDate);
    }

    public DateRange setStartDate(Date startDate) {
        this.startDate = startDate == null? null : new DateTime(startDate).withTimeAtStartOfDay().toDate();
        return this;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public DateRange setEndDate(Date endDate) {
        this.endDate = endDate == null? null : new DateTime(endDate).withTimeAtStartOfDay().toDate();
        return this;
    }

}
