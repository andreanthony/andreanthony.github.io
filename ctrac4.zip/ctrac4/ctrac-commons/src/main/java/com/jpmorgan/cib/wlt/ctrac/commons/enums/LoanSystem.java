package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum LoanSystem {

	VLS("VLS"), LIQ("Loan IQ"), ACBS("ACBS"), ABLE("ABLE"),STRATEGY("STRATEGY") ;
	private String desc;
	
	 LoanSystem(String desc){
		this.desc = desc;
	}

	public static LoanSystem fromString(String desc) {
		for (LoanSystem loanSystem : LoanSystem.values()) {
			if (loanSystem.desc.equals(desc)) {
				return loanSystem;
			}
		}
		return null;
	}
	public String getDescription() {
		return desc;
	}
}
