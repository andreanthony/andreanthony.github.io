package com.jpmorgan.cib.wlt.ctrac.commons.utils;



public interface CtracAppConstants {

	String TEXT_PLAIN = "text/plain";
	String UTF_8 = "UTF-8";
	String X_UA_COMPATIBLE = "X-UA-Compatible";
	String IE_EDGE = "IE=edge";

	/**
	 * Constant for specifying the value of source system name
	 */
	String SOURCE_SYSTEM_NAME = "SOURCE_SYSTEM_NAME";
	/**
	 * Constant for specifying the loan accounting system
	 */
	String LOAN_ACCOUNTING_SYSTEM = "LOAN_ACCOUNTING_SYSTEM";

	/**
	 * Constant for specifying the value of code set for flood remap in the
	 * TLCP_LOOKUP_CODES table.
	 */
	String CODE_SET_REMAP = "FLOOD_REMAP_STATUS_CHANGE";
	
	String ADDITIONAL_INFO = "REMAP";
	
	String CODE_SET_LOB_ASSURANT_BRANCH_CODE = "FLOOD_REMAP_ASSURANT_BRANCH_CODE";
	
	String CODE_SET_BRW_INS_REVIEW_EVIDENCE = "BRW_INS_REVIEW_EVIDENCE_OF_INSURANCE";
	
	String CODE_SET_PROOF_OF_PAYMENT = "BRW_INS_REVIEW_PROOF_OF_PAYMENT";
	
	String CODE_SET_COLLATERAL_TYPES = "COLLATERAL_TYPES";
	
	String CODE_SET_COLLATERAL_STATUSES = "COLLATERAL_STATUSES";
	
	String FLOOD_ZONE_CODE_SET = "FLOOD_REMAP_REVISED_ZONE";
	
	String CODE_SET_APPLICATION_VARIABLE = "APPLICATION_VARIABLE";

	String CODE_NFIP_PROGRAM = "NFIPPROGRAM";

	/**
	 * Constant type of bacth job
	 */
	
	Character ENABLED_FLAG='Y';
	
	String BATCH_IS_RUNNING_URI = "batchIsRunning";

	String FLOOD_TASK_CLOSE_REASON = "FLOOD_TASK_CLOSE_REASON";
	
	String UI_FLAG_TRUE = "true";
	
	String UI_FLAG_FALSE = "false";
	
	Character DB_FLAG_YES = 'Y';
	
	Character DB_FLAG_NO = 'N';
	
	String FLOOD_REMAP_RESEARCH_ITEM_SCREEN_ID = "researchItem";
	
	String FLOOD_INSURANCE_CONTACT_AGENT_SCREEN_ID = "contactAgent";
	
	String FLOOD_REMAP_NEW_RECORD_SCREEN_ID = "newRecord";
	
	String FLOOD_REMAP_VERIFY_VENDOR_INSURANCE = "verifyVendorInsurance";
	
	String FLOOD_INSURANCE_VERIFY_VENDOR_CANCELATION_LETTER = "FLOOD_INSURANCE_VERIFY_VENDOR_CANCELATION_LETTER";
	
	String FLOOD_REMAP_RENWAL_SEND_BANKER_EMAIL_SCREEN_ID = "sendBankerEmailItem";
	
	String FLOOD_INSURANCE_SEND_LENDER_PLACE_EMAIL_SCREEN_ID = "sendLenderPlacedLOBEmailItem";
	
	String FLOOD_INSURANCE_SEND_LENDER_PLACE_CANCELLATION_EMAIL_SCREEN_ID = "sendLenderPlacedCancellationLOBEmailItem";
	
	String FLOOD_INSURANCE_VERIFY_RENEWAL_LETTER_SCREEN_ID = "verifyRenewalLetter";
	
	String FLOOD_REMAP_SEND_MARKET_REFUND_EMAIL_SCREEN_ID = "sendMarketRefundEmailItem";

	String STATES_CODES = "STATE_CODES";
	
	String REMINDER_TYPES = "REMINDER_TYPES";
	
	String PROPERTY_TYPE_CODES = "PROPERTY_TYPE";
	
	String BALANCE_TYPE_CODES = "BALANCE_TYPE";
	
	String COLLATERAL_TYPE_CODES = "COLLATERAL_TYPES";
	
	String LOAN_TYPES = "LOAN_TYPE";

	String ESCROW_TYPES = "ESCROW_TYPES";
	
	String LETTER_CYCLE_WORKFLOW_STEPS="LETTER_CYCLE_WORKFLOW_STEPS";

	String LENDER_PLACE_REASONS="LENDER_PLACE_REASONS";

	String HOLD_TYPES= "HOLD_TYPE";
	String HOLD_PERIODS = "HOLD_PERIOD";
	
	/*
	 * User ID for database records which are automatically
	 * created by CTRAC application
	 */
	String SYSTEM_USER = "SYSTEM";
	
	/**
	 * Remap Type Constants added to check whether "SendAndContinue" button should be enabled or not. 
	 */	
	String O2I = "O2I";
	String P2I = "P2I";
	String O2P = "O2P";
	String I2P = "I2P";
	String I2O = "I2O";
	String P2O = "P2O";
	String FLOOD_ZONE_STATUS_IN = "IN";
	String FLOOD_ZONE_STATUS_OUT = "OUT";
	String[] FLOOD_REMAP_TYPES = {O2I,P2I,O2P,I2P,I2O,P2O,"NC"};
	String EMAIL_TYPE_PREMIUM_PAID_EMAIL = "PREMIUM_PAID_EMAIL";

	String	ZIP_FILE_EXTENSION = "zip";
	String	PDF_FILE_EXTENSION = "pdf";
	String  TXT_FILE_EXTENSION = "txt";

	/* calendar of reference to determine the business day */
	String USA_CALENDAR ="US";

	/* Flood Remap input file extension */
	String  FLOOD_REMAP_FILE_XLSX = "xlsx";
	String  FLOOD_REMAP_FILE_XLS = "xls";
	String  FLOOD_REMAP_FILE_XML = "xml";

    //[ 1024 * 1024 ]
	int SQUARE1024 = 1048576;
	
	int MAX_SFHDF_FILE_SIZE = 10;

	String ENCRYPTION_ALGORITHM = "PBEWITHMD5ANDDES";
	
	String PATH_SEPERATOR = "/";
	String EMAIL_ADDR_SEPERATOR = ";";
	String FIAT_DOCUMENT_IDENTIFIER = "FIAT";
	String SFHDF_DOCUMENT_IDENTIFIER = "SFHDF";
	String HOLD_DOCUMENT_IDENTIFIER = "HOLD";
	String EMAIL_DOCUMENT_IDENTIFIER = "EMAIL";
	String POLICY_DOCUMENT_IDENTIFIER = "POLICY";
	String MORTGAGE_DOT_IDENTIFIER = "MORTGAGE/DOT";
	String IMAGE_FILE_IDENTIFIER = "IMAGE";
	String PREMIUM_CERTIFICATE = "PREMIUM_CERTIFICATE";
	String REFUND_CERTIFICATE = "REFUND_CERTIFICATE";

	String COLLECT_WIRE_CONFIRMATION_SCREEN_ID = "collectWireConfirmation";
	String FLOOD_REMAP_VENDOR_INVOICE_VERIFICATION_CANCELLATION_SCREEN_ID = "floodRemapVendorInvoiceVerificationCancellation";
	String FLOOD_REMAP_VENDOR_REFUND_CONFIRMATION_SCREEN_ID = "floodRemapVendorRefundConfirmation";

	String EMAIL_TEMPLATE_LP_PREMIUM_PAID = "E10";
	
	String DEFAULT_AMOUNT = "0.00";
	String DEFAULT_VALUE = "0.00";
	
	//CTrac db vs TM db Reconciliation metadata details.
	String TM_TASK_ID = "TM TASK ID";
	String RECONCILE_STRING_DATA_TYPE = "STRING";
	String[][] RECONCILE_FIELD_METADATA = {{"TM TASK ID","tmTaskId","taskId",RECONCILE_STRING_DATA_TYPE}
			,{"FLOOD ZONE CHANGE STATUS","statusChange","tmStatusChange",RECONCILE_STRING_DATA_TYPE}
			,{"PROPERTY ADDRESS","propertyAddress","tmAddress",RECONCILE_STRING_DATA_TYPE}
			,{"PROPERTY CITY","city","tmPropertyCity",RECONCILE_STRING_DATA_TYPE}
			,{"PROPERTY STATE","state","tmPropertyState",RECONCILE_STRING_DATA_TYPE}
			,{"PROPERTY ZIP CODE","zipcode","tmPropertyZip",RECONCILE_STRING_DATA_TYPE}
			,{"LOAN NUMBER","loanNumber","tmLoanNumber",RECONCILE_STRING_DATA_TYPE}
			,{"SLA DAYS REMAINING","strSlaDaysRemaining","tmSLADaysRemaining",RECONCILE_STRING_DATA_TYPE}
			,{"BORROWER NAME","borrowerName","tmBorrowerName",RECONCILE_STRING_DATA_TYPE}
			,{"LINE OF BUSINESS","lineOfBusiness","tmLOB",RECONCILE_STRING_DATA_TYPE}
			,{"SOURCE SYSTEM","sourceSystem","sourceSysId",RECONCILE_STRING_DATA_TYPE}
			,{"REQUEST NUMBER","requestNumber","requestNumber",RECONCILE_STRING_DATA_TYPE}
			,{"PARTICIPATING COMMUNITY","participatingCommunity","tmPartCommunity",RECONCILE_STRING_DATA_TYPE}
			,{"REVISED FLOOD ZONE","floodZone","tmFLoodZone",RECONCILE_STRING_DATA_TYPE}
			,{"CORRELATION ID","ctracUniqueId","tmReferenceId",RECONCILE_STRING_DATA_TYPE}
			,{"WORKFLOW STEP ID","workFlowStep","tmWorkflowStep",RECONCILE_STRING_DATA_TYPE}
			,{"TASK STATUS","taskStatus","taskState",RECONCILE_STRING_DATA_TYPE}//TODO
	};
	String[] RECONCILE_XLXS_HEADER = {"TM TASK ID","FIELD NAME","CTRAC VALUE","TM VALUE"};
	String RECONCILE_REPORT_FILENAME = "CTRAC_TM_RECON_MISMATCHES.xlsx";
	
	String DATE_FORMAT = "dd-MM-yyyy";
	String DATE_FORMAT_US = "MM/dd/yyyy";
	String DATE_FORMAT_FILENAME = "MMddyyyy";

	String PRIMARY_BUILDING = "Primary";
	String INSURABLE_ASSET_CONTENT = "Business Asset - Content";
	
	String FLOOD_REMAP_ASSURANT_PAYMENT_LIST = "FLOOD_REMAP_ASSURANT_PAYMENT_LIST";
	
	int DAYS_BETWEEN_FIRST_LETTER_AND_EFFECTIVE_DATE = 46;
	int DAYS_FOR_BORROWER_POLICY_RENEWAL = 50;
	int DAYS_FOR_LENDER_PLACED_POLICY_RENEWAL = 75;
	int DAYS_FOR_PRE_RENEWAL_LETTER = 50;
	
	String REFERENCE_DATE = "APP_REFERENCE_DATE";
	String LINE_SEPERATOR_WINDOWS = "\r\n";
	String LINE_SEPERATOR_UNIX = "\n";
	String[] INSURANCE_REQ_XLXS_HEADER = {"Report Date",
						"Requestor Name",
						"Requestor Email Address",
						"Major Number-Lender Info",
						"Loan Number",
						"Trans Code",
						"Status_ID",
						"Effective Date",
						"Mortgagor Name & Co-Borrower",
						"Mailing Address",
						"Property Address",
						"Property Type",
						"Building/ Contents Coverage",
						"Special Processing",
						"Cov Type",
						"Building Coverage Amount",
						"Contents Coverage Amount (if applicable)",
						"Flood Zone",
						"Comments",
						"Status_ID"
						};

	String POLICY_INSURANCE_REQ_EMAIL_SUBJECT="policy.insurance.request.subject";
	String POLICY_INSURANCE_REQ_TOEMAIL="policy.insurance.request.toemail";
	String POLICY_INSURANCE_REQ_FROMEMAIL="from.email.address.ctrac.system";
	String POLICY_INSURANCE_REQ_EMAILBODY="policy.insurance.request.emailbody";
	String POLICY_INSURANCE_REQ_EMAIL_ALERTSUBJECT="policy.insurance.request.alertsubject";
	String POLICY_INSURANCE_REQ_ALERTEMAILBODY = "policy.insurance.request.alertemailbody";
	String POLICY_INSURANCE_LP_FILENAME = "policy.insurance.request.lpfilename";
	String POLICY_INSURANCE_LP_FILESHEET = "policy.insurance.request.lpfilesheet";
	String POLICY_INSURANCE_REQ_TOALERTEMAIL="policy.insurance.request.toalertemail";
	String ERR_SEVERITY_CRITICAL_MESSAGE = "CRITICAL_CTRAC_ERROR: ";
	String ERR_SEVERITY_APPLICATION_MESSAGE = "CTRAC_APPLICATION ERROR: ";
	String ERR_SEVERITY_TRIVIAL_MESSAGE = "";

	String CANCEL_COVERAGE_TRANS_CODE = "CH - Cancel Coverage";
	String LP_REQUEST_STATUS_ID="4";

	//TODO: Refactor this.
	int MAX_FED_REF_LENGTH = 30;

    String WIRE_CREATE_REQUEST_SCREEN_ID = "wireCreateRequest";
		
    String DASHBOARD_WORKABLE_STATUS = "DASHBOARD_WORKABLE_STATUS";

    //use BorrowerPolicyConclusion
    @Deprecated
    String BORROWER_POLICY_ACCEPTABLE = "Acceptable";
    @Deprecated
    String BORROWER_POLICY_ACTION_REQUIRED = "Action Required";
    @Deprecated
    String BORROWER_POLICY_REJECTED = "Policy Rejected";
    @Deprecated
    String BORROWER_POLICY_GAP_IN_COV_AMOUNT_REJECTED = "Policy Rejected; Coverage amount has gap compare to prior coverage";
    @Deprecated
    String BORROWER_POLICY_GAP_IN_COV_DATE_REJECTED = "Policy Rejected; Effective Date after Prior policy Expitation Date";
		
    int AWVI_ADDITIONAL_THREE_BUSINESS_DAYS = 3;
    int AWVI_ADDITIONAL_TWO_BUSINESS_DAYS = 2;
		
    String BRW_INS_REVIEW_COVERAGE_TYPE = "BRW_INS_REVIEW_COVERAGE_TYPE";

    int MAX_SL_FILE_NOT_RECEIVED_DATE = 7;
    int MAX_CL_FILE_NOT_RECEIVED_DATE = 7;

    String CL_LAST_REMAP_FILE_RECEIVED_DATE = "CL_LAST_REMAP_FILE_RECEIVED_DATE";
    String SL_LAST_REMAP_FILE_RECEIVED_DATE= "SL_LAST_REMAP_FILE_RECEIVED_DATE";
    String LIQ_LAST_RENEWAL_FILE_RECEIVED_DATE= "LIQ_LAST_RENEWAL_FILE_RECEIVED_DATE";

    String SL_XML_SCHEMA = "/xml-schemas/serviceLinkFloodRemap.xsd";

    String SERVICE_LINK_RECORD_COUNT = "totalCount";

    String OPTIONAL_WORD_RENEWAL = "renewal";

    String LP_POLICY_TYPES = "LP_POLICY_TYPES";
    String GDSIMAGE_XML_SCHEMA = "/xml-schemas/ctracAcknowledgement.xsd";
    String CTRAC_LETTERS_XML_SCHEMA = "/xml-schemas/ctracLetterFile.xsd";
    String IMAGE_FILE_RECEIVED_DATE = "SL_LAST_IMAGE_FILE_RECEIVED_DATE";
    String COUNTRY_CODE= "1";

    String LOB_MAPPING_FOR_DATA_FEED_SECTION = "lobMappingForDataFeed";
    String LOB_MAPPING_FOR_DROP_DOWN_SECTION = "lobMappingForDropDown";

    String ACTIVE_FLAG_Y = "Y";
    String ACTIVE_FLAG_N = "N";

    String PARAM_MAX_RECIPIENT_NAME_LENGTH = "ctrac.letter.recipient.name.length.max";
}


