package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum LineOfBusiness {
	CTL("CTL");
	 
	private String code;
    
    private LineOfBusiness(String code) {
        this.code = code;
    }
    
    public String getCode() {
        return code;
    }
    public static boolean isCTL(String code) {
    	return CTL.code.equals(code);
    }
}