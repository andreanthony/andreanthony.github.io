package com.jpmorgan.cib.wlt.ctrac.commons.exception;


public class CtracAjaxException extends RuntimeException {

	/**
	 * Serial version id for this serializable object.
	 */
	private static final long serialVersionUID = 2348153845933784001L;

	
	public  CtracAjaxException(String msg){
		super(msg);
	}
	
	public  CtracAjaxException(Throwable ex){
		super(ex);
	}

	//TODO add properties

}