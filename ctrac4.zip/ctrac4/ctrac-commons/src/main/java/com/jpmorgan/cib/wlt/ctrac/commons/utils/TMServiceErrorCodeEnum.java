package com.jpmorgan.cib.wlt.ctrac.commons.utils;

public enum TMServiceErrorCodeEnum {
	E0003("E0003", "An exception occured in create task [%s], when connecting to TM client. Exception: %s"), 
	E0003_REST("E0003",	"An RestClientException occured in create task [%s], when connecting to TM client. Exception: %s"), 
	E0004_LOCK("E0004", "An exception occured in lock task [%s], when connecting to TM client. Exception: %s"), 
	E0004_LOCK_REST("E0004", "An RestClientException occured in lock task [%s], when connecting to TM client. Exception: %s"), 
	E0146("E0146", "An exception occured in update task [%s], when connecting to TM client. Exception: %s"), 
	E0146_REST("E0146", "An RestClientException occured in update task [%s], when connecting to TM client. Exception: %s"), 
	E0004_UNLOCK("E0004", "An exception occured in unlock task [%s], when connecting to TM client. Exception: %s"), 
	E0005("E0005", "Task Manager is down, Please contact TM Team."), 
	E0004_UNLOCK_REST("E0004", "An RestClientException occured in unlock task [%s], when connecting to TM client. Exception: %s");

	private String errorDescription;
	private String errorCode;

	private TMServiceErrorCodeEnum(String errorCode, String errorDescription) {
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
	}

	public String getErrorDescription() {
		return this.errorDescription;
	}

	public String getErrorCode() {
		return errorCode;
	}
}
