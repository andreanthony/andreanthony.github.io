package com.jpmorgan.cib.wlt.ctrac.commons.exception;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;


public class CurrentUpdateException extends CTracBaseException  {

	 /**
	 * 
	 */
	private static final long serialVersionUID = -6687518503635666652L;

	public CurrentUpdateException(String errorCode, CtracErrorSeverity severity) {
		super(errorCode, severity);
	}
	
	public CurrentUpdateException(String errorMessage) {
		this.setErrorMessage(errorMessage);
	}

	    
}
