package com.jpmorgan.cib.wlt.ctrac.commons.enums;

/**
 * Created by I569445 on 3/2/2016.
 */
public enum MessageType {

    REQUEST("REQUEST"),
    RESPONSE("RESPONSE");

    MessageType(String name) {
        this.name = name;
    }

    public String name;

    public String getName() {
        return this.name;
    }
}
