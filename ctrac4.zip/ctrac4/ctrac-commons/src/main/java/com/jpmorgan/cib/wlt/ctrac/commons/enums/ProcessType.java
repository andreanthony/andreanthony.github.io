package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum ProcessType {//WorkflowTransitionProcess
	BATCH_PROCESS("Batch"),
	MANUAL_PROCESS("Manual");
	
	private String name;
	
	private ProcessType(String name) {
		this.name = name;
	}
	public String getName(){
		return name;
	}
	
	@Override
	public String toString() {
		return name;
	}
}
