package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum SchedulerJob { 
	FULL_EOD_JOB("EOD"),
	EOD_C3_JOB("C3"),
	STATE_AND_SLA_JOB("StateAndSlaEOD"),
	NEW_TASK_JOB("NewTask"),
	SEND_LP_PREMIUM_EMAIL("SendLPPremiumEMail"),
	COVERAGE_GAP_REPORT_EMAIL("CoverageGapReportEmail"),
	NEW_TASK_JOB_SL("NewTaskSL"),
	NEW_TASK_JOB_CL("NewTaskCL"),
	NEW_TASK_JOB_RENEWAL("NewTaskRenewal"),
	EMAIL_POLLER_JOB("EmailPoller"),
	POST_FULL_EOD_JOB("PostEOD"),
	SEND_LP_REQUEST("SendLPRequest"),
	COMPLETE_EOD_BATCH_OPERATIONS("CompleteEODBatchOperations"),
	SEND_LP_REQUEST_ALTHANS("SendLPRequestAlthans"),
	UPDATE_REFERENCE_DATE("UpdateReferenceDate"),
	PROCESS_WIRE_REQUEST("ProcessWireRequest"),
	PROCESS_CONFIRMED_WIRE_REQUEST("ProcessConfirmedWiredRequest"),
	WIRE_CONFIRMATION_EMAIL_POLLER("WireConfirmationEmailPoller"),
	SERVICE_lINK_DATA_EXTRACT("ServiceLinkDataExtract"),
	CORELOGIC_DATA_EXTRACT("CoreLogicDataExtract"),
	PROCESS_GDSIMAGE("ProcessGDSImage"),
	ENTIRE_RENEWAL_DATA_EXTRACT_AND_NEW_TASK_CREATION("RenewalDataExtractAndNewTaskCreation"),
	RENEWAL_LOANIQ_DATA_EXTRACT("RenewalLoanIQDataExtract"),
	RENEWAL_ACBS_DATA_EXTRACT("RenewalACBSDataExtract"),
	RENEWAL_ABLE_DATA_EXTRACT("RenewalABLEDataExtract"),
	RENEWAL_RLOTS_DATA_EXTRACT("RenewalRlotsDataExtract"),
	LAST_RECEIVED_REMAP_NOTIFY("LastReceivedRemapFileNotify"),
	PROCESS_INS_POLICY_TO_REVIEW("ProcessBarrowerInsPolicyToInReview"),
	RSAM_WEEKLY_CERTIFICATION_JOB("RSAMWeeklyCertification"),
	USER_INACTIVITY_JOB("UserInactivityJob"),
	POLICY_RENEWAL("PolicyRenewal"),
	INSURANCE_POLICY_C3("InsurancePolicyC3"),
	SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB("SyncJanusCtracEntitlements"),
	PROCESS_ALTHANS_RESPONSE_FILE("ProcessAlthansResponseFile"),
	PROCESS_ALTHANS_CERTIFICATE_FILE("ProcessAlthansCertificateFile"),
	PLACE_VALID_GDS_XML("PlaceValidGDSXML");

	
	private String name;
	
	SchedulerJob(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return name;
	}
}
