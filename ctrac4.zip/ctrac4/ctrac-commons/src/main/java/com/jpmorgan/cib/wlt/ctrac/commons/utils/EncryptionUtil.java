package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity.CRITICAL;

import java.io.FileInputStream;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;

public class EncryptionUtil {
	private static final Logger logger = Logger.getLogger(EncryptionUtil.class);
	
	private static final String PROPERTY_NAME_PATH_TO_KEY = "ctrac.encrypt.keyfile.path";
	
	private static StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
	
	public static String encrypt(String message) {
		initialize();
		try {
			return encryptor.encrypt(message);
		} catch (Exception e) {}
		logger.error("Error encrypting message: " + message);
		throw new CTracApplicationException("E0148", CRITICAL);
	}

	public static String decrypt(String encryptedMessage) {
		initialize();
		try {
			return encryptor.decrypt(encryptedMessage);
		} catch (Exception e) {}
		logger.error("Error decrypting message: " + encryptedMessage);
		throw new CTracApplicationException("E0148", CRITICAL );
	}	
	
	public static void main(String[] args) {
		String method = args[0];
		String outcome = "";
		if (method.equals("encrypt")) {
			try {
				outcome = encrypt(args[1]);
			}catch (Exception e) { System.out.println(e.getMessage()); }
		} else if (method.equals("decrypt")) {
			try {
				outcome = decrypt(args[1]);
			}
			catch (Exception e) { System.out.println(e.getMessage()); }
		} else {
			System.out.println("usage: <encrypt or decrypt> <message>");
		}
		System.out.println("debug through here if you want to find out the outcome for variable 'outcome'");
	}

	private static void initialize() {
		if (!encryptor.isInitialized()) {
			encryptor.setPassword(getKeyFromFile(System.getProperty(PROPERTY_NAME_PATH_TO_KEY)));
			encryptor.setAlgorithm(CtracAppConstants.ENCRYPTION_ALGORITHM);
		}
	}
	
	private static String getKeyFromFile(String pathToKey) {
		if (pathToKey == null || pathToKey.isEmpty()) {
			logger.error("No path to key provided.");
			throw new CTracApplicationException("E0148", CRITICAL);
		}
		
		String key = null;
		Scanner scanner = null;
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(pathToKey);
			scanner = new Scanner(fileInputStream);
			key = scanner.next().trim();
			if (key == null || key.isEmpty()) {
				logger.error("No key in file.");
				throw new CTracApplicationException("E0148",CRITICAL);
			}
		} catch (Exception e) {
			throw new CTracApplicationException("E0148", CRITICAL);
		} finally {
			StreamManagementUtil.handleClosingStream(fileInputStream,"Encryption key File input Stream");
			StreamManagementUtil.handleClosingStream(scanner,"Encryption key Scanner");
		}
		return key;
	}

	
	
	
	
}
