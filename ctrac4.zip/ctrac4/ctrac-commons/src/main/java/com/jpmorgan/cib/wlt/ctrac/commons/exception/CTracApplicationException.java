package com.jpmorgan.cib.wlt.ctrac.commons.exception;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;

public class CTracApplicationException extends CTracBaseException {

    /**
     * Serial version id for this serializable object.
     */
    private static final long serialVersionUID = 234815384593378400L;
    
    public CTracApplicationException(String errorCode, CtracErrorSeverity severity)
    {
    	super(errorCode, severity);
    }
    
    public CTracApplicationException(String errorCode, CtracErrorSeverity severity, Throwable throwable)
    {
    	super(errorCode, severity, throwable);
    }
    
    @Override
    public String getMessage(){
    	return super.getErrorMessage();
    }
    
}
