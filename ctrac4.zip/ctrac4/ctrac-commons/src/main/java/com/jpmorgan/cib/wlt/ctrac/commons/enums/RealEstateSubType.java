package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum RealEstateSubType {

	DWELLING_RESIDENTIAL("DR"),
	MULTI_FAMILY("MF"),
	COMMERCIAL("C"),
	COMMERCIAL_CONDO_ASSOCIATION("CCA"),
	RESIDENTIAL_CONDO_ASSOCIATION("RCA");

	private final String code;

	private RealEstateSubType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
