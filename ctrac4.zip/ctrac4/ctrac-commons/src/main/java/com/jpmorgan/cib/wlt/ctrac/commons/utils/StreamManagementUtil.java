package com.jpmorgan.cib.wlt.ctrac.commons.utils;


import org.apache.log4j.Logger;
import java.io.Closeable;
import java.io.IOException;

/**
 * Created by V704662 on 9/28/2017.
 */
public class StreamManagementUtil {
    private static final Logger LOG = Logger.getLogger(StreamManagementUtil.class);
    private StreamManagementUtil(){}

    public static void handleClosingStream(Closeable stream, String context){
        if(stream != null){
            try {
                stream.close();
            } catch (IOException e) {
                LOG.error("Something went wrong closing following stream element - " + context,e);
            }
        }
    }
}
