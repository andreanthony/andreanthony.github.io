package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Currency;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;

public class AmountFormatter {
	
	private static final Logger logger = Logger.getLogger(AmountFormatter.class);
	private static DecimalFormat formatter = new DecimalFormat("#0.00");
	
	static {
		formatter.setCurrency(Currency.getInstance(Locale.US));
		formatter.setMinimumIntegerDigits(1);
		formatter.setMinimumFractionDigits(2);
		formatter.setMaximumFractionDigits(2);
		formatter.setGroupingUsed(true);
		formatter.setGroupingSize(3);
		formatter.setParseBigDecimal(true);		
	}
	
	public static String format(BigDecimal amount) {
		if (amount == null) {
			return CtracAppConstants.DEFAULT_AMOUNT;
		}
		return formatter.format(amount);
	}
	
	public static String format(String amount) {
		if (amount == null) {
			return CtracAppConstants.DEFAULT_AMOUNT;
		}
		return formatter.format(parse(amount));
	}
	
	/**
	 * 
	 * @param formattedAmount: must be validated prior to calling parse
	 * @return BigDecimal that represents the string
	 */
	public static BigDecimal parse(String formattedAmount) {
		try {
			if (formattedAmount == null || formattedAmount.isEmpty()) {
				return new BigDecimal(CtracAppConstants.DEFAULT_AMOUNT);
			}
			return new BigDecimal(formattedAmount.replaceAll(",", "").replace("$", ""));
		} catch (Exception e) {
			logger.error("Parsing failed on String: \"" + formattedAmount + "\"");
			throw new CTracApplicationException("E0158", CtracErrorSeverity.APPLICATION);
		}
	}
	
	
	
}
