package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum StateParameterType {
	
	PROOF_OF_COVERAGE("proofOfCoverage"),
	WORK_ITEM("perfectionItem"),                   // the work item of the current task; workflow holder.
	PERFECTION_TASK("perfectionTask"),             // the current perfection task 
	HELPER_DATA("helperData"),                     // mostly a wrapper around the data input by the Users
	TM_PARAMS("tmParams"),                       // attributes of the tasks needed to communicate with TM
	COLLATERAL_LIST("collateralList"),             // a list of collateral the current task is supposed to perfect.
	                                               // In most case this in not needed because of the 1=>1 relation from workItem=>collateral
	AWAITING_TASK_LIST("awaitingTaskList"),        // list of perfection tasks//parallel tasks waiting on the completion of this task
	WORKFLOW_STATE_ATTRIBUTES("workflowStateAttributes"),
	CURRENT_TASK_STATE("currentTaskState"),
	BORROWER_INSURANCE_REVIEW_DATA("borrowerInsuranceReviewData"),
	LETTERS ("conbinedLetters"),
	USER_ID("userId"),
	LETTER_DATE("letterDate"),
	HOLD_END_DATE("holdEndDate"),
	;

	private final String name;

	StateParameterType(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

}
