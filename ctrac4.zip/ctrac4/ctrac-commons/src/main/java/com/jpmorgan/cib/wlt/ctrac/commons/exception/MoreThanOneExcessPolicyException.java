package com.jpmorgan.cib.wlt.ctrac.commons.exception;

public class MoreThanOneExcessPolicyException extends CtracCheckedException {

	private static final long serialVersionUID = 5771773104733931740L;

	public MoreThanOneExcessPolicyException(Long collateralRid) {
		super("Alert: " + collateralRid + ": Multiple Excess Policies - Update collateral record");
	}
	
}
