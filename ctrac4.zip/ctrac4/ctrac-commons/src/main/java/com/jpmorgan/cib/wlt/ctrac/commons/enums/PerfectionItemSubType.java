package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum PerfectionItemSubType {
	COLLATERAL,
	
	REMAP, FLOOD_RENEWAL,
	
	POLICY,
	
	BORROWER_REVIEW, BORROWER_CANCEL,
	
	AGENT, INSURANCE_EXCEPTION, ZONE_VARIANCE,
	
	WIRE, REFUND, PROPERTY,IMAGE, HOLD;
}