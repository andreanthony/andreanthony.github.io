package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum InsurableAssetType {

	BASE_INSURABLE_ASSET("Contents"),
	STRUCTURE("Building"),
	BUSINESS_INCOME("Business Income");
	
	
	private final String displayName;
	
	private InsurableAssetType(String buildingContentsOrBusinessIncome) {
		this.displayName = buildingContentsOrBusinessIncome;
	}

	public String getDisplayName() {
		return displayName;
	}

	public static InsurableAssetType findByName(String name) {
        for(InsurableAssetType insurableAssetType : values() ){
            if(insurableAssetType.name().equals(name) || insurableAssetType.displayName.equals(name)){
                return insurableAssetType;
            }
        }
        return null;
    }
}
