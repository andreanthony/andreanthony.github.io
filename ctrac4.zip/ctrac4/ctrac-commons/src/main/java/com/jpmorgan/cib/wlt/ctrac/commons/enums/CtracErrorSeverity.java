package com.jpmorgan.cib.wlt.ctrac.commons.enums;

/*
 * An error severity must be set for all CTRAC exceptions.
 * CRITICAL - This exception requires the immediate attention of the CTRAC team. 
 * 				A Geneos alert will be triggered and an email generated.
 * 
 * APPLICATION - These exceptions are user-impacting, such as user-caused errors. 
 * 				Immediate action is not needed.
 * 
 * TRIVIAL - As the name implies, these are inconsequential errors that we don't care about.
 */
public enum CtracErrorSeverity {
	CRITICAL, APPLICATION, TRIVIAL;
	
	
}
