package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum PropertyScheduleType {
	OUT, EXP, GAP, PRE, CXL, NONE, IN;
}
