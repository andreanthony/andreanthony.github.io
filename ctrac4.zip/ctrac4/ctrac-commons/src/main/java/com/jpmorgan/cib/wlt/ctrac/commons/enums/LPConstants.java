package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum LPConstants {
	
	SPECIAL_PROCESSING_ZONE_IN ("Zone In"),
	SPECIAL_PROCESSING_DEFAULT ("NA"),
	FLOOD_ZONE_IN_BUILDING("Flood Zone In Building"),
	FLOOD_ZONE_IN_CONTENT("Flood Zone In Commercial Contents"),
	BUILDING("Building"),
	CONTENTS("Contents"),
    BUSINESS_INCOME("Business Income");

	private String displayName;
	
	private LPConstants(String displayName){
		this.displayName = displayName;
	}
	
	public static LPConstants findByDisplayName( String displayName){
		for(LPConstants candidate : LPConstants.values()){
			if(candidate.getDisplayName().equals(displayName)){
				return candidate;
			}
		}
		return null;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

    public static LPConstants findByInsurableAssetType(String assetType) {
        return findByDisplayName(InsurableAssetType.valueOf(assetType).getDisplayName());
	}
}
