package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum CancellationReason {

	BORROWER_POLICY_RECEIVED("Borrower's Insurance Received"),
	BORROWER_POLICY_RECEIVED_AMOUNT_GAP("Borrower's Insurance Received"),
	BORROWER_POLICY_RECEIVED_DATE_LAPSE("Borrower's Insurance Received"),
	DATE_LAPSE(""),
	//COVERAGE_REQUIREMENT_CHANGED("The Required Coverage amount have changed"),//TODO review
	COLLATERAL_RELEASED("Collateral Released"),
	LOAN_PAID_OFF("Loan Paid Off"),
	INSURANCE_NOT_NEEDED("Insurance No Longer Needed");

	private final String text;
	
	private CancellationReason(String text) {
		this.text = text;
	}
	
	public String getText() {
		return text;
	}

	public boolean isBorrowerPolicyRecieved() {
		return this.equals(BORROWER_POLICY_RECEIVED) || this.equals(BORROWER_POLICY_RECEIVED_AMOUNT_GAP) 
				|| this.equals(BORROWER_POLICY_RECEIVED_DATE_LAPSE);
	}

	public boolean isDateLapse() {
		// TODO Auto-generated method stub
		return this.equals(BORROWER_POLICY_RECEIVED_DATE_LAPSE) || this.equals(DATE_LAPSE);
	}
	
}
