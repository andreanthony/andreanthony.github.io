package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ERR_SEVERITY_APPLICATION_MESSAGE;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ERR_SEVERITY_CRITICAL_MESSAGE;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.ERR_SEVERITY_TRIVIAL_MESSAGE;

import java.util.Locale;

import org.springframework.context.MessageSource;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;

public class ErrorCodeToMessageConverter {

	public static String convertToMessage(String errorCode, CtracErrorSeverity severity)
	{
		
		StringBuffer errMessage = new StringBuffer();
		
		switch(severity){
		case CRITICAL:
			errMessage.append(ERR_SEVERITY_CRITICAL_MESSAGE);
			break;
		case APPLICATION:
			errMessage.append(ERR_SEVERITY_APPLICATION_MESSAGE);
			break;
		case TRIVIAL:
			errMessage.append(ERR_SEVERITY_TRIVIAL_MESSAGE);
			break;
		default:
			break;
		}

		MessageSource errorMsgSource = null;
		String message = null;
		try {
			errorMsgSource = (MessageSource) ApplicationContextProvider.getContext().getBean(
					"errorMessageSource");
			message = errorMsgSource.getMessage(errorCode, null, Locale.getDefault());
		} catch (IllegalStateException e) {
	
			message = "no message found";
		}
		
		String errorMessage = errMessage.toString() + " " +  message;
		
		return errorMessage.trim();
	}
}
