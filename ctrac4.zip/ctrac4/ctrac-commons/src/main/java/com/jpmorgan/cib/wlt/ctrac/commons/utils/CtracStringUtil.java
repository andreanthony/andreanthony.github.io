package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CtracStringUtil {

	private CtracStringUtil(){}

	public static String[] split(String string) {
		return split(new String[] { string });
	}
	
	public static String[] split(String[] array) {
		List<String> list = new ArrayList<String>();
		if (array != null && array.length > 0) {
			for (int i=0; i<array.length; i++) {
				if (array[i] != null) {
					list.addAll(Arrays.asList(array[i].trim().replaceAll(",", ";").split(";")));
				}
			}			
		}
		
		array = new String[list.size()];
		array = list.toArray(array);	
		return array;
	}
	
	public static void addValueWithSeparator(StringBuffer sb, String value, String separator) {
		if (StringUtils.isBlank(value)) {
			return;
		}
		if (sb.length() > 0) {
			sb.append(separator);
		}
		sb.append(value.trim());
	}
	
	public static void addValueWithSeparator(StringBuffer sb, StringBuffer value, String separator) {
		if (value == null || value.length() == 0) {
			return;
		}
		if (sb.length() > 0) {
			sb.append(separator);
		}
		sb.append(value);
	}
	
	public static String simplify(String complex) {
		if (complex == null) {
			return null;
		}
		return complex.trim().replaceAll(" +", " ");
	}

	/**
	 * This will truncate a string to the <code>delimiter</code> at or before <code>maxLengthOfString</code>.
	 * Will trim before using <code>maxLengthOfString</code>.
	 * @param stringToTruncate
	 * @param maxLengthOfString
	 * @param delimiter
	 * @return
	 */
	public static String truncateString(String stringToTruncate, int maxLengthOfString, String delimiter) {
		if (stringToTruncate == null) {
			return null;
		}

		StringBuilder sb = new StringBuilder(stringToTruncate.trim());
		if (sb.length() > maxLengthOfString) {
			sb.setLength(maxLengthOfString + 1);
			int indexLastDelimeter = sb.lastIndexOf(delimiter);
			if (indexLastDelimeter > 0) {
				sb.setLength(indexLastDelimeter);
			} else {
				sb.setLength(maxLengthOfString);
			}
		}
		return sb.toString().trim();
	}
}
