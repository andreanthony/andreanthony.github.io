package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum CollateralStatus {
    DRAFT("Draft", "label-warning"), 
    PLEDGED("Pledged", "label-success"),
    RELEASED("Released", "label-default");

    
    private CollateralStatus(String name, String cssClass) {
        this.name = name;
        this.cssClass = cssClass;
    }
    
    private String name;
    private String cssClass;
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getCssClass() {
        return cssClass;
    }
    
    public void setCssClass(String cssClass) {
        this.cssClass = cssClass;
    }
    
    
    public static CollateralStatus findByName(String name){
    	for(CollateralStatus colStatus : values() ){
    		if(colStatus.name.equals(name)){
    			return colStatus;
    		}
    	}
    	return null;
    }
    
    

}
