package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum ReadyForLpCode {

	//inserted into ReadyForLP table when policy renewal workflow starts
	LP_RENEWAL_STARTED(0),

    // set when both are true: (requested fiat is verified and Collateral Review is complete)
	LP_READY(1),

    // set after C3 processed LP_READY expiring policy on the expiration date
	LP_COMPLETED(-1),

    // set when CTRAC cancels an expiring policy which is in ReadyForLP table
	LP_CANCELLED(-2),

    // set when user from Admin screen cancels an expiring policy which iss in ReadyForLP table
	LP_ADMIN_CANCELLED(-3);

	private final Integer code;

	private ReadyForLpCode(Integer code) {
		this.code = code;
	}

	public Integer getCode() {
		return code;
	}

}
