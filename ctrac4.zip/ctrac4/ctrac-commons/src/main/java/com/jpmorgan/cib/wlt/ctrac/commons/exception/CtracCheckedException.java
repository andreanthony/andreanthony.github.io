package com.jpmorgan.cib.wlt.ctrac.commons.exception;

public class CtracCheckedException extends Exception {

	private static final long serialVersionUID = 2357537488375348607L;

	public CtracCheckedException() {
		super();
	}
	
	public CtracCheckedException(String message) {
		super(message);
	}
	
}
