package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum PolicyStatus {

	/* TICKLER MIGRATION */
	PENDING_VERIFICATION("Pending Verification"),

    /* BORROWER PROVIDED */
    ACCEPTED("Accepted"),
    REJECTED("Rejected"),

    /* LENDER_PLACED */
    /* ASSURANT FILE */
    PENDING_LETTER_CYCLE("Pending Letter Cycle"),
    /* then transition to letter cycle */
	LETTER_CYCLE("Letter Cycle"),
	PRE_INVOICED("Pre-Invoiced"),
	INVOICED("Invoiced"),
	PAID("Paid"),

	/* COMMON */
	EXPIRING("Expiring"),
	EXPIRING_FIAT_NR("Expiring FIAT NR"),
	EXPIRING_SBA_COVERAGE_NR("Expiring- SBA Coverage NR"),
	EXPIRING_EA("Expiring-EA"),
	EXPIRED("Expired"),
	CANCELLED("Cancelled"),
	REPLACED("Replaced"),

	// Invalid (LCP-)
	/* TICKLER MIGRATION */
	INVALID_PENDING_VERIFICATION("Invalid Pending Verification"),

    /* BORROWER PROVIDED */
    INVALID_ACCEPTED("Invalid Accepted"),
    INVALID_REJECTED("Invalid Rejected"),

    /* LENDER_PLACED */
    /* ASSURANT FILE */
    INVALID_PENDING_LETTER_CYCLE("Invalid Pending Letter Cycle"),
    /* then transition to letter cycle */
	INVALID_LETTER_CYCLE("Invalid Letter Cycle"),
	INVALID_PRE_INVOICED("Invalid Pre-Invoiced"),
	INVALID_INVOICED("Invalid Invoiced"),
	INVALID_PAID("Invalid Paid"),

	/* COMMON */
	INVALID_EXPIRING("Invalid Expiring"),
	INVALID_EXPIRING_FIAT_NR("Invalid Expiring FIAT NR"),
	INVALID_EXPIRING_SBA_COVERAGE_NR("Invalid Expiring- SBA Coverage NR"),
	INVALID_EXPIRED("Invalid Expired"),
	INVALID_CANCELLED("Invalid Cancelled");

	private String displayName;

	private PolicyStatus(String displayName){
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public static PolicyStatus findByDisplayName(String displayName){
		for(PolicyStatus candidate : PolicyStatus.values()){
			if(candidate.getDisplayName().equalsIgnoreCase(displayName)){
				return candidate;
			}
		}
		return null;
	}

	public boolean isPendingVerification() {
	    return this == PolicyStatus.PENDING_VERIFICATION;
	}

	public boolean isActive(boolean includePendingVerification) {
	    return !isInvalid() && !isInactive() && (this != PolicyStatus.PENDING_VERIFICATION || includePendingVerification);
	}

	public boolean isInactive() {
	    return this == EXPIRED || this.isCancelled() || this == REJECTED || this == REPLACED;
	}

	public boolean isInvalid() {
	    return this.getDisplayName().startsWith("Invalid ");
	}

	public boolean isExpiring() {
		return this == EXPIRING || this == EXPIRING_FIAT_NR || this == EXPIRING_SBA_COVERAGE_NR || this == EXPIRING_EA;
	}

	public boolean requiresInvoicePaymentMethod() {
		return this == PENDING_LETTER_CYCLE || this == LETTER_CYCLE || this == PRE_INVOICED || this == INVOICED || isCancelled();
	}

	public boolean updateOnInvoicePaymentMethodAllowed() {
		return this == PENDING_LETTER_CYCLE || this == LETTER_CYCLE || this == PRE_INVOICED || this == INVOICED ;
	}

	public boolean isBeforeLpRequestSent() {
		return this == PENDING_LETTER_CYCLE || this == LETTER_CYCLE || this == PRE_INVOICED;
	}

	public boolean isCancelled() {
		return this == CANCELLED;
	}
}
