package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum LenderPlaceReason {


	BORROWER_POLICY_CANCELLED("", null),
	BORROWER_POLICY_EXPIRED("", null),
	BORROWER_POLICY_RECEIVED("", null),
	BORROWER_POLICY_RECEIVED_DATE_LAPSE("Date Lapse", "Date Lapse"),
	BORROWER_POLICY_RECEIVED_AMOUNT_GAP("Amount Gap", "Amount Gap"),
    DATE_LAPSE("Date Lapse", "Date Lapse"),
    LP_POLICY_EXPIRED("", null),
	ZONE_IN("", "Zone In"),
	BUILDING_DESCOPED("", null),
	NONE("", "Other");

	private final String comment; //Althans LP request comment
	private final String displayName; 

	private LenderPlaceReason(String comment, String displayName) {
		this.comment = comment;
		this.displayName = displayName;
	}
		
	public String getComment() {
		return comment;
	}

	public String getDisplayName() {
		return this.displayName;
	}

	private LenderPlaceReason() {
		this("", "");
	}

}
