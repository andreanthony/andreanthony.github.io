package com.jpmorgan.cib.wlt.ctrac.commons.enums;
public enum FloodCoverageType {
	FLOOD,
	FLOOD_GAP;
}

