package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum FileType {

	COMMA_SEPARATED("csv"),
	PDF("pdf"),
	PIPE_DELIMITED("txt"),
	EXCEL("xlsx"),
	ZIP("zip");
	
	private final String extension;
	
	private FileType(String extension) {
		this.extension = extension;
	}
	
	public String getExtension() {
		return extension;
	}
	
}
