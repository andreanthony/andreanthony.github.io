package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum RenewalWorkflowType {
	DAYS_50,
	DAYS_75;

	@Override
	public String toString() {
		return this.name();
	}
	
	public static RenewalWorkflowType findByPolicyType(PolicyType policyType) {
		if(policyType.isLenderPlaced()) {
			return DAYS_75;
		}
		return DAYS_50;
	}
}
