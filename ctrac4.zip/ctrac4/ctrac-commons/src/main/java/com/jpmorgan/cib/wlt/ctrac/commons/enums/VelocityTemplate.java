package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum VelocityTemplate {
	FLOOD_REMAP_CREATE_MESSAGE("floodRemapTMTaskCreated.vm"), 
	FLOOD_REMAP_AMEND_MESSAGE("floodRemapTMTaskAmended.vm"), 
	FLOOD_REMAP_COMPLETE_MESSAGE("floodRemapTMTaskCancelled.vm"),
	FLOOD_REMAP_IMPORT_RECONCILIATION_EMAIL("remapTaskReconcilationEmail.vm"),
	DATAQUICK_FILE_NOT_RECEIVED_FOR_THIRTY_DAYS("tooLongSinceLastRemapFileReceived.vm");
	
	private String filename;
	
	VelocityTemplate(String filename) {
		this.filename = filename;
	}
	
	public String getFilename() {
		return filename;
	}
		
}
