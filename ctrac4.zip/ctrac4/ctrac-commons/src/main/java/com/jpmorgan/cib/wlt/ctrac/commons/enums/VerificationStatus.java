package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum VerificationStatus {
	VERIFIED("VERIFIED"),
	PENDING_VERIFICATION("PENDING_VERIFICATION"),
	DRAFT("DRAFT");
	
    private VerificationStatus(String name) {
        this.name = name;
    }
    
    private String name;

    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
}
