package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum BalanceType {

	ACV, RCV;
	
}
