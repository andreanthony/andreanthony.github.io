package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum LpInsuranceVendor {

	ALTHANS("Althans"),
	ASSURANT("Assurant");
	
	private final String displayName;
	
	private LpInsuranceVendor(String displayName) {
		this.displayName = displayName;
	}
	
	public String getDisplayName() {
		return displayName;
	}
	
	public static LpInsuranceVendor findByDisplayName(String displayName) {
		for (LpInsuranceVendor vendor : LpInsuranceVendor.values()) {
			if (vendor.getDisplayName().equals(displayName)) {
				return vendor;
			}
		}
		return null;
	}
	
}
