package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum LPIType {


	SBA_CONTENTS_ONLY("SBA Contents Only","SBA"),
	OTHERS("Others","OTHERS");
	
	private String description;
	
	private String shortDescription;
	
	private LPIType(String description, String shortDescription){
		this.description = description;
		this.shortDescription = shortDescription;
	}
		
	public String getDescription(){
		return description;
	}

	public String getShortDescription() {
		return shortDescription;
	}

}
