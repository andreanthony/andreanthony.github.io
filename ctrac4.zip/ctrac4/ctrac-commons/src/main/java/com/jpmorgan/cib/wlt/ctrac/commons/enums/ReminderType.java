package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum ReminderType {


	BORROWER("Policy", "policy", 50),
	BINDER("Binder", "binder", 30),
	APPLICATION("Application", "application", 90),
	LENDER_PLACED("Lender_Placed", "lender placed", 50),
	SBA_CONTENTS("SBA_Contents", "SBA contents policy", 30);
	
	private  String taskSubType;
	private String description;
	private Integer expiringDays;
	private ReminderType(String taskSubType, String description, Integer expiringDays){
		this.taskSubType = taskSubType;
		this.description = description;
		this.expiringDays = expiringDays;
	}
	
	/**
	 * @return the subTask
	 */
	public String getTaskSubType() {
		return taskSubType;
	}
	
	public String getDescription(){
		return description;
	}

	public String getTaskSubTypeWithoutUnderScore(){
		return taskSubType.replace('_', ' ');
	}

	public Integer getExpiringDays() {
		return expiringDays;
	}

	public void setExpiringDays(Integer expiringDays) {
		this.expiringDays = expiringDays;
	}
}
