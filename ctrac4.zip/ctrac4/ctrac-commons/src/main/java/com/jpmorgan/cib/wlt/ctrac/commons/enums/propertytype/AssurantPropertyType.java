package com.jpmorgan.cib.wlt.ctrac.commons.enums.propertytype;

/**
 * Created by E704298 on 7/11/2017.
 */
public enum AssurantPropertyType {

    NON_RESIDENTIAL_CONDOMINIUM("Non-Residential Condominium", false),
    SINGLE_FAMILY_DWELLING("Single Family Dwelling - Residential", true),
    TWO_UNIT_DWELLING("2 unit dwelling - Residential", true),
    THREE_UNIT_DWELLING("3 unit dwelling - Residential", true),
    FOUR_UNIT_DWELLING("4 unit dwelling - Residential", true),
    FIVE_UNIT_DWELLING("5 unit dwelling - Commercial", false),
    COOPERATIVE_DWELLING("Co-operative dwelling - Residential", false),
    CONDOMINIUM("Condominium - Residential", false),
    MOBILE_HOME("Mobile Home - Residential", false),
    COMMERCIAL_PROPERTY("Commercial property - Commercial", false),
    APARTMENT("Apartment - Commercial", false),
    TOWNHOME("Townhome - Residential", false);

    AssurantPropertyType(String displayName, Boolean isResidential) {
        this.displayName = displayName;
        this.isResidential = isResidential;
    }

    private final String displayName;
    private final Boolean isResidential;

    public String getDisplayName() {
        return displayName;
    }
    
    public Boolean isResidential() {
        return isResidential;
    }

    public static AssurantPropertyType findByDisplayName(String description) {
        for (AssurantPropertyType value : values()) {
            if (value.getDisplayName().equalsIgnoreCase(description)) {
                return value;
            }
        }
        return null;
    }
}
