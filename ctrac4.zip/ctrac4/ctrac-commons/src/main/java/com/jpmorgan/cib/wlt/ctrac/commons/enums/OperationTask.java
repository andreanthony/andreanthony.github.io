package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum OperationTask {
	RESTART_LETETR_CYCLE("Restart Letter Cycle", "/admin/restartLetterCycle"),
	TASK_ADMINISTRATION("Task Administration", "/admin/taskAdministration"),
	AUTO_ADDRESS_VERIFICATION("Auto Address Verification", "/admin/loanBorrowerAddressAuto"),
	MANUAL_ADDRESS_VERIFICATION("Manual Address Verification", "/admin/loanBorrowerAddress"),
	ENTITY_MERGE("Merge Entities", "/admin/merge"),
	ACTIVATE_INACTIVATE_LOBS("Activate Inactivate LOBs","/admin/configureLOB"),
	NFIP_PROGRAM("NFIP Program","/admin/nfipProgramOperation"),
	COVERAGE_GAP_REPORT("Coverage Gap Report", "/floodRemap/runSendCoverageGapReport"),
	COPY_OPEN_TASKS_TO_TM("CTRAC(OPEN) -> TM", "/floodRemap/runMigrateOpenTasksToTMProcess");

	private final String displayName;
	private final String pageURL;
	
	private OperationTask(String displayName, String pageURL) {
		this.displayName = displayName;
		this.pageURL = pageURL;
	}
	
	public String getDisplayName() {
		return displayName;
	}	
	
	public String getPageURL() {
		return pageURL;
	}	
}
