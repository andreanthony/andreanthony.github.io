package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum PerfectionItemType {
    
	COLLATERAL,//the only possible value for subclass CollateralItem
	FLOOD_REMAP,//the only possible value for subclass FloodRemapItem
	FLOOD_POLICY,//the only possible value for subclass LPItem
	AGGREGATE_ITEM,//the only possible value for subclass WireProcessItem
	LETTER_ITEM,//the only possible value for subclass WireProcessItem
	BORROWER_POLICY_REVIEW,//the only possible value for subclass BorrowerInsReviewItem
	BORROWER_AGENT_RESPONSE;//the only possible value for subclass AgentResponseItem
	
}