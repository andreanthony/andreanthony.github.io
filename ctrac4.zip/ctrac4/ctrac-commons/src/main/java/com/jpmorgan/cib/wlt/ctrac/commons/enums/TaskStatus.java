package com.jpmorgan.cib.wlt.ctrac.commons.enums;

import java.util.ArrayList;
import java.util.List;

public enum TaskStatus {
	OPEN("Active"),
	CLOSED("Completed"),
	SLEEPING("Dormant"),
	TRANSIENT("Transient"),
	TRANSITIONED("Transitioned"); //this is a final state saying that the operation was performed and the task has transitioned;
									//This state is used for logging purposes only;
	
	
	TaskStatus(String displayValue){
		this.displayValue =displayValue;
	}
	private String displayValue;
	
	public String getDisplayValue(){
		return displayValue;
	}
	
	public static TaskStatus findByName(String name){
		try {
			TaskStatus result = TaskStatus.valueOf(name);
			return result;
		} catch (Exception swallow) {
			return null;
		}
	}
	
	public static TaskStatus findByDisplayValue(String displayValue){
		for(TaskStatus candidate : TaskStatus.values()){
			if(candidate.getDisplayValue().equalsIgnoreCase(displayValue)){
				return candidate;
			}
		}
		return null;
	}
	
	public static TaskStatus findByDisplayValueLike(String displayValue){
		for(TaskStatus candidate : TaskStatus.values()){
			if(candidate.getDisplayValue().toLowerCase().startsWith(displayValue.toLowerCase())){
				return candidate;
			}
		}
		return null;
	}
	
	public static List<String> getActiveStatus(){
		List<String> taskStatuses = new ArrayList<String>();
		taskStatuses.add(OPEN.name());
		taskStatuses.add(SLEEPING.name());
		taskStatuses.add(TRANSIENT.name());
		return taskStatuses;
	}
	
}
