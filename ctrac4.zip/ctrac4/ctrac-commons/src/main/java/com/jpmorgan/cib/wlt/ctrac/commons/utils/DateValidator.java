package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashSet;

public class DateValidator {

	public static Date validateDate(String userEnteredDate){
		
		SimpleDateFormat oracleUSFormat = new SimpleDateFormat("dd-MMM-yyyy");
		SimpleDateFormat euroWithSlashes2Digit = new SimpleDateFormat("dd/MM/yy");
		SimpleDateFormat euroWithSlashes4Digit = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat euroWithDashes2Digit = new SimpleDateFormat("dd-MM-yy");
		SimpleDateFormat euroWithDashes4Digit = new SimpleDateFormat("dd-MM-yyyy");
		SimpleDateFormat euroWithDashes4DigitYearFront = new SimpleDateFormat("yyyy-MM-dd");
				
		LinkedHashSet<SimpleDateFormat> acceptableDateFormats = new LinkedHashSet<SimpleDateFormat>();
		
		acceptableDateFormats.add(oracleUSFormat);
		acceptableDateFormats.add(euroWithSlashes2Digit);
		acceptableDateFormats.add(euroWithSlashes4Digit);
		acceptableDateFormats.add(euroWithDashes2Digit);
		acceptableDateFormats.add(euroWithDashes4Digit);
		acceptableDateFormats.add(euroWithDashes4DigitYearFront);
		
		Date retVal = null;
		boolean valid = false;
		
		for(SimpleDateFormat format:acceptableDateFormats){
			if(!valid){
				try {
					retVal = format.parse(userEnteredDate);
					valid = true;
				} catch (ParseException e) {
				
				}
			}
	
		}
		
		return retVal;
	}
	
}
