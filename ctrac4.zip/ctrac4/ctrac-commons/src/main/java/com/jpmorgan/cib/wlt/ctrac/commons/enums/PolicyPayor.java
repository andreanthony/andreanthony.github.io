package com.jpmorgan.cib.wlt.ctrac.commons.enums;

public enum PolicyPayor {

	BORROWER("Borrower Portion"), BANK("Bank Portion");
	private String desc;

	private PolicyPayor(String desc){
		this.desc = desc;
	}

	public static PolicyPayor fromString(String desc) {
		for (PolicyPayor payor : PolicyPayor.values()) {
			if (payor.desc.equals(desc)) {
				return payor;
			}
		}
		return null;
	}

	public String getDesc() {
		return desc;
	}
}
