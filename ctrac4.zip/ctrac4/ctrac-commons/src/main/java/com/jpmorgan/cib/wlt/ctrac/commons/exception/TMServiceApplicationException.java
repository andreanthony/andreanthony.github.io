package com.jpmorgan.cib.wlt.ctrac.commons.exception;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.TMServiceErrorCodeEnum;

/**
 * 
 * This class handles exceptions for Task Manager Service
 * 
 */
public class TMServiceApplicationException extends TMServiceBaseException {

	/**
	 * Serial version id for this serializable object.
	 */
	private static final long serialVersionUID = -3540105672014887971L;

	/*public TMServiceApplicationException(String errorMessage) {
		super(errorMessage);
	}

	public TMServiceApplicationException(String errorMessage, Object[] attributes, Throwable throwable) {
		super(errorMessage, attributes, throwable);
	}

	public TMServiceApplicationException(String errorCode, String errorMessage, Object[] attributes,Throwable throwable) {
		super(errorMessage, attributes, throwable);
	}

	public TMServiceApplicationException(TMServiceErrorCodeEnum errorCodeEnum, String errorMessage, Object[] attributes, Throwable throwable) {
		super(errorCodeEnum, errorMessage, attributes, throwable);
	}
	public TMServiceApplicationException(TMServiceErrorCodeEnum errorCodeEnum, String errorMessage,Throwable throwable) {
		super(errorCodeEnum, errorMessage, throwable);
	}

	@Override
	public String getMessage() {
		return super.getErrorMessage();
	}*/
	public TMServiceApplicationException(String errorCode, CtracErrorSeverity severity)
    {
    	super(errorCode, severity);
    }
    
    public TMServiceApplicationException(String errorCode, CtracErrorSeverity severity, Throwable throwable)
    {
    	super(errorCode, severity, throwable);
    }
    
    @Override
    public String getMessage(){
    	return super.getErrorMessage();
    }

}