package com.jpmorgan.cib.wlt.ctrac.commons.exception;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;

public class ExceptionMessageProvider {
	
	private MessageSource messageSource = (MessageSource) ApplicationContextProvider.getContext().getBean(
			"errorMessageSource");
			
	public String getErrorMessage(String errorCode){
		try {
			return messageSource.getMessage(errorCode, null, Locale.getDefault());
		} catch (NoSuchMessageException e) {
			
			return "Error Code " + errorCode + " not found.";
		}
	}

}
