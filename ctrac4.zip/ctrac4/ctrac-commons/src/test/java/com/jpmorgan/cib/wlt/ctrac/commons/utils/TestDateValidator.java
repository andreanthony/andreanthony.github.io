package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

public class TestDateValidator {
	private static final String INPUT_DATE="26/05/2016";
	private static final String INPUT_DATE1="26-05-2016";
	private static final String INPUT_DATE2="26-05-16";
	private static final String INPUT_DATE3="26/05/16";
	private static final String INPUT_DATE4="2016-05-26";
	private static final SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
	
	
	@Test
	public void testValidateDate(){
		Date date=prepareDate(INPUT_DATE);
		assertEquals(date,DateValidator.validateDate(INPUT_DATE));
		assertEquals(date,DateValidator.validateDate(INPUT_DATE1));
		assertEquals(date,DateValidator.validateDate(INPUT_DATE2));
		assertEquals(date,DateValidator.validateDate(INPUT_DATE3));
		//WIP
	}
	
	public static void main(String[] args){
		Date dt=DateValidator.validateDate(INPUT_DATE4);
		System.out.println(dt);
	}
	
	private Date prepareDate(String dateStr){
		Date date=null;
		try {
			date=sdf.parse(dateStr);			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
