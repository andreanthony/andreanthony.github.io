package com.jpmorgan.cib.wlt.ctrac.commons.enums;

import org.junit.Test;

import static org.junit.Assert.*;

public class TestInsurableAssetType {
    @Test
    public void getBuildingContentsOrBusinessIncome() throws Exception {
        assertEquals("Building", InsurableAssetType.STRUCTURE.getDisplayName());
        assertEquals("Contents", InsurableAssetType.BASE_INSURABLE_ASSET.getDisplayName());
        assertEquals("Business Income", InsurableAssetType.BUSINESS_INCOME.getDisplayName());
    }

    @Test
    public void findByName() throws Exception {
        assertEquals(InsurableAssetType.STRUCTURE, InsurableAssetType.findByName("STRUCTURE"));
        assertEquals(InsurableAssetType.STRUCTURE, InsurableAssetType.findByName("Building"));

        assertEquals(InsurableAssetType.BASE_INSURABLE_ASSET, InsurableAssetType.findByName("BASE_INSURABLE_ASSET"));
        assertEquals(InsurableAssetType.BASE_INSURABLE_ASSET, InsurableAssetType.findByName("Contents"));

        assertEquals(InsurableAssetType.BUSINESS_INCOME, InsurableAssetType.findByName("BUSINESS_INCOME"));
        assertEquals(InsurableAssetType.BUSINESS_INCOME, InsurableAssetType.findByName("Business Income"));
    }

}