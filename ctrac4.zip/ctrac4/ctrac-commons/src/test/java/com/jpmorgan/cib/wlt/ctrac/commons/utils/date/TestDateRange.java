package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

import org.joda.time.DateTime;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class TestDateRange {
    public static final DateTime TODAY_DATETIME = new DateTime(new Date());
    public static final Date TODAY = TODAY_DATETIME.toDate();
    public static final Date TODAY_0_TIME = TODAY_DATETIME.withTimeAtStartOfDay().toDate();
    public static final Date _1_DAY_AFTER = TODAY_DATETIME.plusDays(1).toDate();
    public static final Date _1_DAY_AFTER_0_TIME = TODAY_DATETIME.plusDays(1).withTimeAtStartOfDay().toDate();
    public static final Date _1_DAY_BEFORE = TODAY_DATETIME.plusDays(-1).withTimeAtStartOfDay().toDate();
    public static final Date _1_DAY_BEFORE_0_TIME = TODAY_DATETIME.plusDays(-1).withTimeAtStartOfDay().toDate();

    @Test
    public void isWithinDateRange() {
        assertTrue(new DateRange(_1_DAY_BEFORE, null).isWithinDateRange(TODAY));
        assertTrue(new DateRange(_1_DAY_BEFORE, _1_DAY_AFTER).isWithinDateRange(TODAY));
        assertTrue(new DateRange(_1_DAY_BEFORE, null).isWithinDateRange(_1_DAY_BEFORE));
        assertTrue(new DateRange(_1_DAY_BEFORE, _1_DAY_AFTER).isWithinDateRange(_1_DAY_BEFORE));

        assertFalse(new DateRange(TODAY, null).isWithinDateRange(_1_DAY_BEFORE));
        assertFalse(new DateRange(TODAY, _1_DAY_AFTER).isWithinDateRange(_1_DAY_BEFORE));
        assertFalse(new DateRange(_1_DAY_BEFORE, TODAY).isWithinDateRange(_1_DAY_AFTER));
        assertFalse(new DateRange(_1_DAY_BEFORE, _1_DAY_AFTER).isWithinDateRange(_1_DAY_AFTER));
    }
    @Test
    public void isBeforeStartDate() {
        assertTrue(new DateRange(TODAY, null).isBeforeStartDate(_1_DAY_BEFORE));
        assertTrue(new DateRange(TODAY, _1_DAY_AFTER).isBeforeStartDate(_1_DAY_BEFORE));
        assertFalse(new DateRange(TODAY, _1_DAY_AFTER).isBeforeStartDate(TODAY));
    }

    @Test
    public void setStartDate() {
        assertEquals(TODAY_0_TIME, new DateRange().setStartDate(TODAY).getStartDate());
    }

    @Test
    public void getStartDate() {
        assertEquals(TODAY_0_TIME, new DateRange(TODAY).getStartDate());
    }

    @Test
    public void getEndDate() {
        assertEquals(TODAY_0_TIME, new DateRange(_1_DAY_BEFORE, TODAY).getEndDate());
    }

    @Test
    public void setEndDate() {
        assertEquals(TODAY_0_TIME, new DateRange().setEndDate(TODAY).getEndDate());
    }

}