package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Created by E704298 on 8/4/2017.
 */
public class TestSimplePatternDateFormatter {
    private static final String DATE_FORMAT = "MMM-d-YY";

    private Class<? extends DateFormatter> dateFormatterClass;
    private DateTime date;
    private String text;

    private DateFormatter testObj;

    public TestSimplePatternDateFormatter() {
        init(null, 2017, 8, 4, "Aug-4-17");
    }

    protected void init(Class<? extends DateFormatter> dateFormatterClass,
                                      int year, int month, int day, String text) {
        this.dateFormatterClass = dateFormatterClass;
        this.date = new DateTime().withDate(year, month, day);
        this.text = text;
    }

    @Before
    public void setUp() {
        try {
            if (dateFormatterClass != null) {
                testObj = dateFormatterClass.getConstructor().newInstance();
            } else {
                testObj = new SimplePatternDateFormatter(DATE_FORMAT);
            }
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void testParse() {
        assertEquals(date.withTimeAtStartOfDay().toDate(), testObj.parse(text));
    }

    @Test
    public void testPrint() {
        assertEquals(text, testObj.print(date.toDate()));
    }
}
