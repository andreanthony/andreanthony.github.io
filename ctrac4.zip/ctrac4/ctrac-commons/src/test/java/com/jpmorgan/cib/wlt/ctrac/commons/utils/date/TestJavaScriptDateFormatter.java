package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

/**
 * Created by E704298 on 8/4/2017.
 */
public class TestJavaScriptDateFormatter extends TestSimplePatternDateFormatter {
    public TestJavaScriptDateFormatter() {
        init(JavaScriptDateFormatter.class, 2017, 8, 4, "Aug 4 2017");
    }
}
