package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import com.jpmorgan.cib.wlt.ctrac.rules.CtracJUnitTestRule;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;

import java.util.Locale;

@RunWith(MockitoJUnitRunner.class)
public class TestErrorCodeToMessageConverter{
	private static final String ERROR_CODE="E0153";
	private static final String EXPECTED_MESSAGE="TM DataSource bean configuration initialization fails.";

	@ClassRule
	public static CtracJUnitTestRule CTRAC_JUNIT_TEST_RULE = new CtracJUnitTestRule();

	@Test
	public void testConvertToMessage(){
		when(CTRAC_JUNIT_TEST_RULE.getErrorMessageSource()
				.getMessage(ERROR_CODE, null, Locale.getDefault())).thenReturn(EXPECTED_MESSAGE);
		String msg=ErrorCodeToMessageConverter.convertToMessage(ERROR_CODE, CtracErrorSeverity.CRITICAL);
		assertEquals("CRITICAL_CTRAC_ERROR:  " + EXPECTED_MESSAGE,msg);
	}
}
