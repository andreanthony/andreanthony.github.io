package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

public class TestHTMLDateFormatter extends TestSimplePatternDateFormatter {
    public TestHTMLDateFormatter() {
        init(HTMLDateFormatter.class, 2017, 8, 4, "2017-08-04");
    }
}
