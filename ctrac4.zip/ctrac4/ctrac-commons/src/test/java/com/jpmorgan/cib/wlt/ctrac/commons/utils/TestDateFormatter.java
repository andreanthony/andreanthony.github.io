package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

public class TestDateFormatter {
	private static final String DATE_STR="26/05/2016";
	private static final SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
	
	private static final String FORMATTED_JAVASCRIPT_DATE_STR="May 26 2016";
	private static final String FORMATTED_DATE_STR="26-05-2016";
	private static final String FORMATTER="dd/MM/yyyy";
	private static final String FORMATTER1="dd-MM-yyyy";
	private static final String CALENDAR_DATE_STR="05/06/2016";
	private static final int NUMBER_OF_DAYS=10;
	
	@Test
	public void testParseDate(){		
		try {
			Date date=prepareDate(DATE_STR);
			assertEquals(date,DateFormatter.parseDate(DATE_STR, FORMATTER));
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testToJavaScriptDate(){
		Date date=prepareDate(DATE_STR);
		assertEquals(FORMATTED_JAVASCRIPT_DATE_STR,DateFormatter.toJavaScriptDate(date));
	}
	
	@Test
	public void testToString(){
		Date date=prepareDate(DATE_STR);
		assertEquals(FORMATTED_DATE_STR,DateFormatter.toString(FORMATTER1, date));
	}
	
	@Test
	public void testGetMMDDYYDate(){
		Date expectedDate=prepareDate(CALENDAR_DATE_STR);
		Date date=prepareDate(DATE_STR);
		assertEquals(expectedDate,DateFormatter.getMMDDYYDate(date, NUMBER_OF_DAYS).getTime());
	}
	
	private Date prepareDate(String dateStr){
		Date date=null;
		try {
			date=sdf.parse(dateStr);			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
