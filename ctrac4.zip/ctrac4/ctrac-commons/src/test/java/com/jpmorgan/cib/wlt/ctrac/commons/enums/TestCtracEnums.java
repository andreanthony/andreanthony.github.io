package com.jpmorgan.cib.wlt.ctrac.commons.enums;

import org.junit.Test;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertFalse;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

public class TestCtracEnums {

	@Test
	public void testCollateralDetailsSections(){
		assertEquals(2, CollateralDetailsSection.getBasicCollateralSections().size());
	}

	@Test
	public void testCollateralScreenAction(){
		CollateralScreenAction test = CollateralScreenAction.VERIFY;
		assertEquals(test, CollateralScreenAction.getCollateralScreenAction("verify"));
	}

	@Test
	public void testCollateralStatus(){
		CollateralStatus c = CollateralStatus.RELEASED;
		assertEquals("Released",c.getName());
		assertEquals("label-default",c.getCssClass());
	}

	@Test
	public void testCollateralType(){
		assertEquals(CollateralType.BUSINESS_ASSETS, CollateralType.findByCode("BUS"));
		assertEquals(null, CollateralType.findByCode("test"));
		assertEquals(CollateralType.OTHER, CollateralType.findByDescription("Other"));
		assertEquals(null, CollateralType.findByDescription("test"));
	}

	@Test
	public void testCoverageREquirementStatus(){
		assertEquals(CoverageRequirementStatus.PENDING_VERIFICATION, CoverageRequirementStatus.findByDisplayName("Pending Verification"));
		assertEquals(null, CoverageRequirementStatus.findByDisplayName("test"));
		assertEquals("Pending Verification", CoverageRequirementStatus.PENDING_VERIFICATION.getDisplayName());
	}

	@Test
	public void testLPConstants(){
		assertEquals(LPConstants.FLOOD_ZONE_IN_CONTENT, LPConstants.findByDisplayName("Flood Zone In Commercial Contents"));
		assertEquals(null, LPConstants.findByDisplayName("test"));
		assertEquals("Zone In", LPConstants.SPECIAL_PROCESSING_ZONE_IN.getDisplayName());

		assertEquals(LPConstants.BUILDING, LPConstants.findByDisplayName("Building"));
        assertEquals(LPConstants.BUILDING, LPConstants.findByDisplayName(InsurableAssetType.STRUCTURE.getDisplayName()));

        assertEquals(LPConstants.CONTENTS, LPConstants.findByDisplayName("Contents"));
        assertEquals(LPConstants.CONTENTS, LPConstants.findByDisplayName(InsurableAssetType.BASE_INSURABLE_ASSET.getDisplayName()));

        assertEquals(LPConstants.BUSINESS_INCOME, LPConstants.findByDisplayName("Business Income"));
        assertEquals(LPConstants.BUSINESS_INCOME, LPConstants.findByDisplayName(InsurableAssetType.BUSINESS_INCOME.getDisplayName()));

        assertEquals(LPConstants.BUILDING, LPConstants.findByInsurableAssetType("STRUCTURE"));
        assertEquals(LPConstants.CONTENTS, LPConstants.findByInsurableAssetType("BASE_INSURABLE_ASSET"));
        assertEquals(LPConstants.BUSINESS_INCOME, LPConstants.findByInsurableAssetType("BUSINESS_INCOME"));
    }

    @Test
	public void testPaymentType(){
		assertEquals(PaymentType.CASHIERS_CHECK, PaymentType.getPaymentType("Cashiers Check"));
		assertEquals(null, PaymentType.getPaymentType("test"));
	}

	@Test
    public void testPolicyStatus(){
		assertTrue(PolicyStatus.CANCELLED.isCancelled());
		assertFalse(PolicyStatus.REJECTED.isCancelled());
		assertFalse(PolicyStatus.ACCEPTED.isCancelled());
		assertFalse(PolicyStatus.LETTER_CYCLE.isCancelled());
		assertFalse(PolicyStatus.INVOICED.isCancelled());
		assertFalse(PolicyStatus.PAID.isCancelled());
		assertFalse(PolicyStatus.PENDING_LETTER_CYCLE.isCancelled());
		assertFalse(PolicyStatus.PENDING_VERIFICATION.isCancelled());
		assertFalse(PolicyStatus.EXPIRING.isCancelled());
		assertFalse(PolicyStatus.EXPIRED.isCancelled());
		assertFalse(PolicyStatus.REJECTED.isBeforeLpRequestSent());
		assertFalse(PolicyStatus.ACCEPTED.isBeforeLpRequestSent());
		assertTrue(PolicyStatus.LETTER_CYCLE.isBeforeLpRequestSent());
		assertFalse(PolicyStatus.INVOICED.isBeforeLpRequestSent());
		assertFalse(PolicyStatus.PAID.isBeforeLpRequestSent());
		assertTrue(PolicyStatus.PENDING_LETTER_CYCLE.isBeforeLpRequestSent());
		assertFalse(PolicyStatus.PENDING_VERIFICATION.isBeforeLpRequestSent());
		assertFalse(PolicyStatus.EXPIRING.isBeforeLpRequestSent());
		assertFalse(PolicyStatus.EXPIRED.isBeforeLpRequestSent());
		assertFalse(PolicyStatus.CANCELLED.isBeforeLpRequestSent());
		assertFalse(PolicyStatus.ACCEPTED.isPendingVerification());
		assertFalse(PolicyStatus.CANCELLED.isPendingVerification());
		assertFalse(PolicyStatus.EXPIRED.isPendingVerification());
		assertFalse(PolicyStatus.EXPIRING.isPendingVerification());
		assertFalse(PolicyStatus.INVALID_ACCEPTED.isPendingVerification());
		assertFalse(PolicyStatus.INVOICED.isPendingVerification());
		assertFalse(PolicyStatus.PENDING_LETTER_CYCLE.isPendingVerification());
		assertTrue(PolicyStatus.PENDING_VERIFICATION.isPendingVerification());
		assertFalse(PolicyStatus.PRE_INVOICED.isPendingVerification());
	}

	/**
	 * - {@link PolicyStatus} - isInactive
	 * TestCase: Validate that the enumeration PolicyStatus will return the appropriate answer back that the expected invalid status is invalid
	 */
	@Test
	public void testPolicyIsInactive(){
		List<PolicyStatus> expectedInActivePolicyStatus = new ArrayList<>();
		expectedInActivePolicyStatus.add(PolicyStatus.EXPIRED);
		expectedInActivePolicyStatus.add(PolicyStatus.CANCELLED);
		expectedInActivePolicyStatus.add(PolicyStatus.REJECTED);
		expectedInActivePolicyStatus.add(PolicyStatus.REPLACED);

		for(PolicyStatus status: PolicyStatus.values()){
			if(CollectionUtils.containsInstance(expectedInActivePolicyStatus, status)){
				assertTrue(status.isInactive());
			}else{
				assertFalse(status.isInactive());
			}
		}
	}

	@Test
	public void testPolicyType(){
		assertFalse(PolicyType.APPLICATION.isLenderPlaced());
		assertFalse(PolicyType.BINDER.isLenderPlaced());
		assertFalse(PolicyType.ACCORD.isLenderPlaced());
		assertFalse(PolicyType.NFIP.isLenderPlaced());
		assertFalse(PolicyType.PRIVATE.isLenderPlaced());
		assertTrue(PolicyType.LP_GAP.isLenderPlaced());
		assertTrue(PolicyType.LP.isLenderPlaced());
		assertTrue(PolicyType.LP_EXCESS.isLenderPlaced());

		assertTrue(PolicyType.APPLICATION.isBorrowerPolicy());
		assertTrue(PolicyType.BINDER.isBorrowerPolicy());
		assertTrue(PolicyType.ACCORD.isBorrowerPolicy());
		assertTrue(PolicyType.NFIP.isBorrowerPolicy());
		assertTrue(PolicyType.PRIVATE.isBorrowerPolicy());
		assertFalse(PolicyType.LP_GAP.isBorrowerPolicy());
		assertFalse(PolicyType.LP.isBorrowerPolicy());
		assertFalse(PolicyType.LP_EXCESS.isBorrowerPolicy());

		assertTrue(PolicyType.LP_GAP.isLpPrimaryCoverageOnly());
		assertTrue(PolicyType.LP.isLpPrimaryCoverageOnly());
		assertFalse(PolicyType.LP_EXCESS.isLpPrimaryCoverageOnly());

		assertFalse(PolicyType.LP_GAP.isLpExcessCoverageOnly());
		assertFalse(PolicyType.LP.isLpExcessCoverageOnly());
		assertTrue(PolicyType.LP_EXCESS.isLpExcessCoverageOnly());

	}

	@Test
	public void testReminderType(){
		assertEquals(ReminderType.BORROWER.getTaskSubType(), ReminderType.BORROWER.getTaskSubTypeWithoutUnderScore());
		assertEquals(ReminderType.BINDER.getTaskSubType(), ReminderType.BINDER.getTaskSubTypeWithoutUnderScore());
		assertEquals(ReminderType.APPLICATION.getTaskSubType(), ReminderType.APPLICATION.getTaskSubTypeWithoutUnderScore());
		assertEquals("Lender Placed", ReminderType.LENDER_PLACED.getTaskSubTypeWithoutUnderScore());
		assertEquals("SBA Contents", ReminderType.SBA_CONTENTS.getTaskSubTypeWithoutUnderScore());
	}


	@Test
	public void testTaskStatus(){
		assertEquals(TaskStatus.OPEN, TaskStatus.findByName("OPEN"));
		assertEquals(TaskStatus.OPEN, TaskStatus.findByDisplayValue("Active"));
		assertEquals(TaskStatus.OPEN, TaskStatus.findByDisplayValue("active"));
	}

	@Test
	public void testEnumGetterSetter(){
		assertEquals("Reconcilation completed successfully", BatchExitStatus.RECON_ALL_SUCCESSFUL.getStatusDescription());
		//assertEquals("FIAT", CoverageInputSource.FIAT.getName());
		assertEquals("Primary", CoverageType.PRIMARY.getDisplayValue());
		assertEquals("Flood", InsuranceType.FLOOD.getDisplayValue());
		assertEquals("SBA Contents Only", LPIType.SBA_CONTENTS_ONLY.getDescription());
		assertEquals("SBA", LPIType.SBA_CONTENTS_ONLY.getShortDescription());
		assertEquals("RESPONSE", MessageType.RESPONSE.getName());
		assertEquals(8, ResearchAndMaintenanceAssurantField.POLICY_EFFECTIVE_DATE.getColumn());
		assertEquals("EOD", SchedulerJob.FULL_EOD_JOB.getName());
		assertEquals("EOD",  SchedulerJob.FULL_EOD_JOB.toString());
		assertEquals("Manual",  ProcessType.MANUAL_PROCESS.toString());
		assertEquals("Manual", ProcessType.MANUAL_PROCESS.getName());
		assertEquals("TM", ServiceProvider.TM.getName());
		assertEquals("perfectionTask", StateParameterType.PERFECTION_TASK.getName());
		assertEquals("floodRemapTMTaskCreated.vm", VelocityTemplate.FLOOD_REMAP_CREATE_MESSAGE.getFilename());


		assertEquals("CRITICAL",CtracErrorSeverity.CRITICAL.toString());
		assertEquals("FLOOD",FloodCoverageType.FLOOD.toString());
		assertEquals("BASE_INSURABLE_ASSET",InsurableAssetType.BASE_INSURABLE_ASSET.toString());
		assertEquals("BUSINESS_INCOME",InsurableAssetType.BUSINESS_INCOME.toString());
		assertEquals("PRE_LETTER_CYCLE",LpPhase.PRE_LETTER_CYCLE.toString());
		assertEquals("FLOOD_RENEWAL",PerfectionItemSubType.FLOOD_RENEWAL.toString());
		assertEquals("COLLATERAL",PerfectionItemType.COLLATERAL.toString());
		assertEquals("PROPERTYTOPOLICY",TaskRelationType.PROPERTYTOPOLICY.toString());
		assertEquals("PENDING_VERIFICATION",VerificationStatus.PENDING_VERIFICATION.toString());

	}

	/**
	 * - RealEstateSubType
	 * TestCase: Verify that all enum codes of the Collateral Sub type
	 * has the expected code as String value
	 */
	@Test
	public void testCollateralSubType(){
		assertThat(RealEstateSubType.COMMERCIAL.getCode(),is("C"));
		assertThat(RealEstateSubType.DWELLING_RESIDENTIAL.getCode(),is("DR"));
		assertThat(RealEstateSubType.MULTI_FAMILY.getCode(),is("MF"));
		assertThat(RealEstateSubType.COMMERCIAL_CONDO_ASSOCIATION.getCode(),is("CCA"));
		assertThat(RealEstateSubType.RESIDENTIAL_CONDO_ASSOCIATION.getCode(),is("RCA"));
	}

	@Test
	public void testReadyForLpCode(){
		assertThat(ReadyForLpCode.LP_RENEWAL_STARTED.getCode(),is(0));
		assertThat(ReadyForLpCode.LP_READY.getCode(),is(1));
		assertThat(ReadyForLpCode.LP_COMPLETED.getCode(),is(-1));
		assertThat(ReadyForLpCode.LP_CANCELLED.getCode(),is(-2));
		assertThat(ReadyForLpCode.LP_ADMIN_CANCELLED.getCode(),is(-3));
	}

	@Test
	public void testLenderPlaceReason(){
		assertThat(LenderPlaceReason.BORROWER_POLICY_RECEIVED_AMOUNT_GAP.getDisplayName(),is("Amount Gap"));
		assertThat(LenderPlaceReason.BORROWER_POLICY_RECEIVED_DATE_LAPSE.getDisplayName(),is("Date Lapse"));
		assertThat(LenderPlaceReason.ZONE_IN.getDisplayName(),is("Zone In"));
		assertThat(LenderPlaceReason.NONE.getDisplayName(),is("Other"));
	}


	/**
	 * - LoanSystem
	 * TestCase: Verify that all enum codes of the Loan accounting system
	 * has the expected code as String value
	 */
	@Test
	public void testLoanSystem(){
		assertThat(LoanSystem.ABLE.getDescription(),is("ABLE"));
		assertThat(LoanSystem.ACBS.getDescription(),is("ACBS"));
		assertThat(LoanSystem.LIQ.getDescription(),is("Loan IQ"));
		assertThat(LoanSystem.STRATEGY.getDescription(),is("STRATEGY"));
	}

	/**
	 * - LoanType
	 * TestCase: Verify that all enum codes of the Loan Type
	 * has the expected code as String value
	 */
	@Test
	public void testLoanType(){
		assertThat(LoanType.values().length, is(6));
		assertThat(LoanType.STANDARD.getDisplayName(),is("Standard"));
		assertThat(LoanType.SBA.getDisplayName(),is("SBA"));
		assertThat(LoanType.CHARGED_OFF.getDisplayName(),is("Charged Off"));
		assertThat(LoanType.FHMC.getDisplayName(),is("FHMC"));
		assertThat(LoanType.FNMA.getDisplayName(),is("FNMA"));
		assertThat(LoanType.EXTERNALLY_AGENTED.getDisplayName(),is("Externally Agented"));
	}

    /**
     * PendingPaymentChangeTerm
     * TestCases: Test that for each possible shortageAmount the appropriate PendingPaymentChangeTerm instance will return
     */
    @Test
    public void testPendingPaymentChangeTerm(){
        assertNull(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(0.00d)));
        assertNull(PendingPaymentChangeTerm.calcForShortageAmount(null));

        assertThat(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(0.01d)),is(PendingPaymentChangeTerm.ONE_MONTH));
        assertThat(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(999.99d)),is(PendingPaymentChangeTerm.ONE_MONTH));

        assertThat(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(1000.00d)),is(PendingPaymentChangeTerm.THREE_MONTHS));
        assertThat(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(1999.99d)),is(PendingPaymentChangeTerm.THREE_MONTHS));

        assertThat(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(2000.00d)),is(PendingPaymentChangeTerm.FIVE_MONTHS));
        assertThat(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(4999.99d)),is(PendingPaymentChangeTerm.FIVE_MONTHS));

        assertThat(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(5000.00d)),is(PendingPaymentChangeTerm.NINE_MONTHS));
        assertThat(PendingPaymentChangeTerm.calcForShortageAmount(BigDecimal.valueOf(999555.00d)),is(PendingPaymentChangeTerm.NINE_MONTHS));
    }

	/**
	 * - TestCase: Given policy with status PENDING LETTER CYCLE / LETTER CYCLE / PRE- INVOICED / INVOICED,
	 * those policies will require an update on the invoice payment method
	 */
	@Test
	public void PolicyStatusAllowedInvoicePaymentMethodUpdate(){
		List<PolicyStatus> expectedInvoicePaymentMethodUpdate = new ArrayList<>();
		expectedInvoicePaymentMethodUpdate.add(PolicyStatus.PENDING_LETTER_CYCLE);
		expectedInvoicePaymentMethodUpdate.add(PolicyStatus.LETTER_CYCLE);
		expectedInvoicePaymentMethodUpdate.add(PolicyStatus.PRE_INVOICED);
		expectedInvoicePaymentMethodUpdate.add(PolicyStatus.INVOICED);

		for(PolicyStatus status: PolicyStatus.values()){
			if(CollectionUtils.containsInstance(expectedInvoicePaymentMethodUpdate, status)){
				assertTrue(status.updateOnInvoicePaymentMethodAllowed());
			}else{
				assertFalse(status.updateOnInvoicePaymentMethodAllowed());
			}
		}
	}

	@Test
	public void testRenewalWorkflowType(){
		for(PolicyType policyType: PolicyType.values()){
			if(PolicyType.lpPolicyTypes().contains(policyType)){
				assertEquals(RenewalWorkflowType.DAYS_75, RenewalWorkflowType.findByPolicyType(policyType));
			}else if(PolicyType.borrowerPolicyTypes().contains(policyType)){
				assertEquals(RenewalWorkflowType.DAYS_50, RenewalWorkflowType.findByPolicyType(policyType));
			}
		}
	}


	/**
	 * - LoanSystem
	 * TestCase: Verify that all enum codes of the Loan accounting system
	 * has the expected code as String value
	 */
	@Test
	public void testEscrowTypes(){
		assertThat(EscrowType.ESCROW.name(),is("ESCROW"));
		assertThat(EscrowType.NON_ESCROW.name(),is("NON_ESCROW"));
    }

    @Test
    public void testCoverageTypeGetRelatedTypes() {
        List<CoverageType> result = (List)CoverageType.getRelatedTypes(CoverageType.PRIMARY);
        assertTrue(result.contains(CoverageType.PRIMARY));
        assertTrue(result.contains(CoverageType.PRIMARY_AND_EXCESS));
        assertFalse(result.contains(CoverageType.EXCESS));

        result = (List)CoverageType.getRelatedTypes(CoverageType.PRIMARY_AND_EXCESS);
        assertTrue(result.contains(CoverageType.PRIMARY));
        assertTrue(result.contains(CoverageType.PRIMARY_AND_EXCESS));
        assertFalse(result.contains(CoverageType.EXCESS));

        result = (List)CoverageType.getRelatedTypes(CoverageType.EXCESS);
        assertFalse(result.contains(CoverageType.PRIMARY));
        assertFalse(result.contains(CoverageType.PRIMARY_AND_EXCESS));
        assertTrue(result.contains(CoverageType.EXCESS));
    }


    @Test
    public void testCoverageTypeIsMatching() {
        assertTrue(CoverageType.PRIMARY.isMatching(CoverageType.PRIMARY));
        assertTrue(CoverageType.PRIMARY.isMatching(CoverageType.PRIMARY_AND_EXCESS));
        assertFalse(CoverageType.PRIMARY.isMatching(CoverageType.EXCESS));
        assertTrue(CoverageType.PRIMARY_AND_EXCESS.isMatching(CoverageType.PRIMARY_AND_EXCESS));
        assertTrue(CoverageType.PRIMARY_AND_EXCESS.isMatching(CoverageType.EXCESS));
        assertTrue(CoverageType.PRIMARY_AND_EXCESS.isMatching(CoverageType.PRIMARY));
        assertFalse(CoverageType.EXCESS.isMatching(CoverageType.PRIMARY));
        assertTrue(CoverageType.EXCESS.isMatching(CoverageType.PRIMARY_AND_EXCESS));
        assertTrue(CoverageType.EXCESS.isMatching(CoverageType.EXCESS));
    }

}
