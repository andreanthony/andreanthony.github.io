package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

public class TestLongDateFormatter extends TestSimplePatternDateFormatter {
    public TestLongDateFormatter() {
        init(LongDateFormatter.class, 2017, 8, 4, "Friday, August 4, 2017");
    }
}
