package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestApplicationUtils {
	private static final String TASK_TYPE="FLOOD_INSURANCE";
	
	@Test
	public void testSetScreenTitle(){
		assertEquals("Flood Insurance",ApplicationUtils.setScreenTitle(TASK_TYPE));
	}
}
