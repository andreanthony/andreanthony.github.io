package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import org.junit.Test;

public class TestFilenameValidator {

	@Test
	public void test1() {
		assertTrue(FilenameValidator.isValidFilename("abc"));
	}
	
	@Test
	public void test2() {
		assertTrue(FilenameValidator.isValidFilename("abc.def"));
	}
	
	@Test
	public void test3() {
		assertTrue(FilenameValidator.isValidFilename("abc.def.ghi"));
	}
	
	@Test
	public void test4() {
		assertTrue(FilenameValidator.isValidFilename("abc-123.def"));
	}
	
	@Test
	public void test7() {
		assertTrue(FilenameValidator.isValidFilename("abc@123.def"));
	}
	
	@Test
	public void test8() {
		assertTrue(FilenameValidator.isValidFilename("abc+123.def"));
	}
	
	@Test
	public void test5() {
		assertFalse(FilenameValidator.isValidFilename("a/b"));
	}
	
	@Test
	public void test6() {
		assertFalse(FilenameValidator.isValidFilename("a\\b"));
	}

}
