package com.jpmorgan.cib.wlt.ctrac.commons.config;

import org.junit.Test;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;

import static junit.framework.TestCase.fail;
import static org.junit.Assert.assertEquals;

/**
 * Created by E704298 on 7/14/2017.
 */
public class TestProdConfig {

    private static final String ALTHANS_RECON_EMAIL_ADDRESS = "althan_lpi_nrs@chase.com";
    private static final String ALTHANS_RECON_EMAIL_PROPERTY = "cls.proof.and.control.email.address";
    private Properties testObj;

    private void loadProdConfig() {
        loadConfig("external_resource/prod/ctrac_application.properties");
    }

    private void loadDrConfig() {
        loadConfig("external_resource/dr/ctrac_application.properties");
    }

    private void loadConfig(String propertiesPath) {
        try {
            testObj = new Properties();
            ClassLoader classLoader = getClass().getClassLoader();
            File file = new File(classLoader.getResource(propertiesPath).getFile());
            testObj.load(new FileReader(file));
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testReconEmailAddressProd() {
        loadProdConfig();
        assertEquals(ALTHANS_RECON_EMAIL_ADDRESS, testObj.getProperty(ALTHANS_RECON_EMAIL_PROPERTY));
    }

    @Test
    public void testReconEmailAddressDr() {
        loadDrConfig();
        assertEquals(ALTHANS_RECON_EMAIL_ADDRESS, testObj.getProperty(ALTHANS_RECON_EMAIL_PROPERTY));
    }

}
