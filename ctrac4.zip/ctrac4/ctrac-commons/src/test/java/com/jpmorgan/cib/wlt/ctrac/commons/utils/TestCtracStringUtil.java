package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TestCtracStringUtil {
	private static final String[] INPUT_ARR={"string1,string111","string2,string222","string3,string333","string4,string444","string5,string555"};
	private static final String[] FINAL_ARR={"string1","string111","string2","string222","string3","string333","string4","string444","string5","string555"};

	private static String STRING_TO_TRUNCATE;
	private static String EXPECTED_STRING;
	private static int STRING_MAX_LENGTH;
	private static String DELIMITER;

	@Before
	public void setUp() {
		STRING_TO_TRUNCATE = "";
		EXPECTED_STRING = "";
		STRING_MAX_LENGTH = 60;
		DELIMITER = " ";
	}
	
	@Test
	public void testSplit(){
		assertArrayEquals(FINAL_ARR,CtracStringUtil.split(INPUT_ARR));
	}

	@Test
	public void testTruncateEndOfWord() {
		STRING_TO_TRUNCATE = "This is a really long test with spaces that should be broken at the last space on or before X characters";
		EXPECTED_STRING = "This is a really long test with spaces that should be broken";
		testTruncate();
	}

	@Test
	public void testTruncateMiddleOfWord() {
		STRING_TO_TRUNCATE = "This is a really long test with spaces that should not be partially broken";
		EXPECTED_STRING = "This is a really long test with spaces that should not be";
		testTruncate();
	}

	@Test
	public void testTruncateWordEndsWithSpace() {
		STRING_TO_TRUNCATE = "This is a test with spaces that has a space at the limit of the string";
		EXPECTED_STRING = "This is a test with spaces that has a space at the limit of";
		testTruncate();
	}

	@Test
	public void testShortenNameNoChange() {
		STRING_TO_TRUNCATE = "This test is short enough";
		EXPECTED_STRING = STRING_TO_TRUNCATE;
		testTruncate();
	}

	@Test
	public void testShortenNameSpacePadded() {
		STRING_TO_TRUNCATE = "  This is a test padded with spaces that should not lose chars";
		EXPECTED_STRING = "This is a test padded with spaces that should not lose chars";
		testTruncate();
	}

	@Test
	public void testTruncatePipeDelimiter() {
		STRING_TO_TRUNCATE = "This is a really long test with pipes | that should not be partially | broken";
		EXPECTED_STRING = "This is a really long test with pipes";
		DELIMITER = "|";
		testTruncate();
	}

	@Test
	public void testTruncateDelimiterNotFound() {
		STRING_TO_TRUNCATE = "This is a really long test with a delimiter that does not exist in the string.";
		EXPECTED_STRING = "This is a really long test with a delimiter that does not ex";
		DELIMITER = "|";
		testTruncate();
	}

	private void testTruncate() {
		assertEquals(EXPECTED_STRING, CtracStringUtil.truncateString(STRING_TO_TRUNCATE, STRING_MAX_LENGTH, DELIMITER));
	}

	@Test
	public void testTruncateNull() {
		assertNull(CtracStringUtil.truncateString(null,1," "));
	}
}
