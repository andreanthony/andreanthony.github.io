package com.jpmorgan.cib.wlt.ctrac.commons.enums.propertytype;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by E704298 on 7/11/2017.
 */
public class TestAssurantPropertyType {

    @Test
    public void testSize() {
        assertEquals(12, AssurantPropertyType.values().length);
    }

    @Test
    public void testNonResidentialCondominium() {
        assertEquals("Non-Residential Condominium", AssurantPropertyType.NON_RESIDENTIAL_CONDOMINIUM.getDisplayName());
    }

    @Test
    public void testSingleFamilyDwelling() {
        assertEquals("Single Family Dwelling - Residential", AssurantPropertyType.SINGLE_FAMILY_DWELLING.getDisplayName());
    }

    @Test
    public void testTwoUnitDwelling() {
        assertEquals("2 unit dwelling - Residential", AssurantPropertyType.TWO_UNIT_DWELLING.getDisplayName());
    }

    @Test
    public void testThreeUnitDwelling() {
        assertEquals("3 unit dwelling - Residential", AssurantPropertyType.THREE_UNIT_DWELLING.getDisplayName());
    }

    @Test
    public void testFourUnitDwelling() {
        assertEquals("4 unit dwelling - Residential", AssurantPropertyType.FOUR_UNIT_DWELLING.getDisplayName());
    }

    @Test
    public void testFiveUnitDwelling() {
        assertEquals("5 unit dwelling - Commercial", AssurantPropertyType.FIVE_UNIT_DWELLING.getDisplayName());
    }

    @Test
    public void testCooperativeDwelling() {
        assertEquals("Co-operative dwelling - Residential", AssurantPropertyType.COOPERATIVE_DWELLING.getDisplayName());
    }

    @Test
    public void testCondominium() {
        assertEquals("Condominium - Residential", AssurantPropertyType.CONDOMINIUM.getDisplayName());
    }

    @Test
    public void testMobileHome() {
        assertEquals("Mobile Home - Residential", AssurantPropertyType.MOBILE_HOME.getDisplayName());
    }

    @Test
    public void testCommercialProperty() {
        assertEquals("Commercial property - Commercial", AssurantPropertyType.COMMERCIAL_PROPERTY.getDisplayName());
    }

    @Test
    public void testApartment() {
        assertEquals("Apartment - Commercial", AssurantPropertyType.APARTMENT.getDisplayName());
    }

    @Test
    public void testTownhome() {
        assertEquals("Townhome - Residential", AssurantPropertyType.TOWNHOME.getDisplayName());
    }

}
