package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

/**
 * Created by E704298 on 8/4/2017.
 */
public class TestSortableDateFormatter extends TestSimplePatternDateFormatter {
    public TestSortableDateFormatter() {
        init(SortableDateFormatter.class, 2017, 8, 4, "20170804");
    }
}
