package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

public class TestAmountFormatter {
	
	private static final String FORMATTED_100_00 = "100.00";
	private static final String FORMATTED_1_000_00 = "1,000.00";
	private static final String FORMATTED_1_000_000_00 = "1,000,000.00";
	private static final String FORMATTED_1_000_000_89 = "1,000,000.89";	
	
	private static final BigDecimal BIG_DECIMAL_100_00 = new BigDecimal("100.00");
	private static final BigDecimal BIG_DECIMAL_1_000_00 = new BigDecimal("1000.00");
	private static final BigDecimal BIG_DECIMAL_1_000_000_00 = new BigDecimal("1000000.00");
	private static final BigDecimal BIG_DECIMAL_1_000_000_89 = new BigDecimal("1000000.89");

	private static final BigDecimal BIG_DECIMAL_DEFAULT = new BigDecimal(CtracAppConstants.DEFAULT_AMOUNT);
	
	@Test
	public void testAmountFormatting() {
		assertEquals(FORMATTED_100_00, AmountFormatter.format(BIG_DECIMAL_100_00));
		assertEquals(FORMATTED_1_000_00, AmountFormatter.format(BIG_DECIMAL_1_000_00));
		assertEquals(FORMATTED_1_000_000_00, AmountFormatter.format(BIG_DECIMAL_1_000_000_00));
		assertEquals(FORMATTED_1_000_000_89, AmountFormatter.format(BIG_DECIMAL_1_000_000_89));
	}
	
	@Test
	public void testAmountParsing() {
		assertEquals(BIG_DECIMAL_100_00, AmountFormatter.parse(FORMATTED_100_00));
		assertEquals(BIG_DECIMAL_1_000_00, AmountFormatter.parse(FORMATTED_1_000_00));
		assertEquals(BIG_DECIMAL_1_000_000_00, AmountFormatter.parse(FORMATTED_1_000_000_00));
		assertEquals(BIG_DECIMAL_1_000_000_89, AmountFormatter.parse(FORMATTED_1_000_000_89));
	}
	
	@Test
	public void testParsingExceptions() {
		assertEquals(BIG_DECIMAL_DEFAULT, AmountFormatter.parse(null));
		assertEquals(BIG_DECIMAL_DEFAULT, AmountFormatter.parse(""));
	}

}
