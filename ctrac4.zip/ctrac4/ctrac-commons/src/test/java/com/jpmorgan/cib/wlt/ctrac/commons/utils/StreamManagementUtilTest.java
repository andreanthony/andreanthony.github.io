package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.InputStream;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * Created by V704662 on 9/28/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class StreamManagementUtilTest {


    /**
     * - handleClosingStream
     * TestCase: Verifies that when input stream is given this method will close the stream
     * @throws Exception
     */
    @Test
    public void handleClosingStream() throws Exception {
        InputStream mockInstance = mock(InputStream.class);
        StreamManagementUtil.handleClosingStream(mockInstance,"test");
        verify(mockInstance).close();
    }

}