package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static junit.framework.TestCase.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by E704298 on 8/2/2017.
 */
public class TestRegexParserDateFormatter {

    private static final String VALID_SL_FILE_NAME = "LOL_SL_2017_0731_04_00.zip";
    private static final DateTime JUL_31 = new DateTime().withDate(2017, 7, 31).withTimeAtStartOfDay();
    private static final String INVALID_SL_FILE_NAME = "LOL_SL_2017_07_31_04_00.zip";

    private RegexParserDateFormatter testObj;

    @Before
    public void setUp() {
        testObj = new RegexParserDateFormatter("YYYY_MMdd", "\\d{4}_\\d{4}");
    }

    @Test
    public void testValidDate() {
        Date actual = testObj.parse(VALID_SL_FILE_NAME);
        assertEquals(JUL_31.toDate(), actual);
    }

    @Test
    public void testInvalidDate() {
        Date actual = testObj.parse(INVALID_SL_FILE_NAME);
        assertNull(actual);
    }

}
