package com.jpmorgan.cib.wlt.ctrac.commons.exceptions;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.NoUserFoundException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Created by V704662 on 8/21/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestNoUserFoundException {

    @Test
    public void testNoUserFoundExceptionInitialization(){
        NoUserFoundException exception = new NoUserFoundException("code1", CtracErrorSeverity.APPLICATION);
        assertThat(exception.getErrorCode(),is("code1"));
        assertThat(exception.getSeverity(),is(CtracErrorSeverity.APPLICATION));
    }
}
