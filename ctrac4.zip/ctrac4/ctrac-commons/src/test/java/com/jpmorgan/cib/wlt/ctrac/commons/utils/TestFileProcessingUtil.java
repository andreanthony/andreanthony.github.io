package com.jpmorgan.cib.wlt.ctrac.commons.utils;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.io.IOException;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import static org.hamcrest.Matchers.hasItem;

public class TestFileProcessingUtil {
	private static final String ZIP_FILE_NAME="file1.zip";
	private static final String TEST_FILE_NAME="C:"+CtracAppConstants.PATH_SEPERATOR+"file1.txt";
	private static final String DEST_PATH=".."+CtracAppConstants.PATH_SEPERATOR+".."+CtracAppConstants.PATH_SEPERATOR+".."+CtracAppConstants.PATH_SEPERATOR+"logs";

	@InjectMocks
	FileProcessingUtil fileProcessingUtil;

	@Rule
	public TemporaryFolder temporarySourceFolder = new TemporaryFolder();

	@Rule
	public TemporaryFolder temporaryDestinationFolder = new TemporaryFolder();

	@Test
	public void testIsZipFile(){
		File file=new File(ZIP_FILE_NAME);
		assertEquals(true,FileProcessingUtil.isZipFile(file));
	}

	@Test
	public void testMoveOrRewrite(){
		File file=new File(TEST_FILE_NAME);
		FileProcessingUtil.moveAndOverwrite(file, DEST_PATH);
	}

	@Test
	public void testMoveOrRewriteLetterFile() throws IOException {

		File file = temporarySourceFolder.newFile("test.txt");
		String SOURCE_PATH=temporarySourceFolder.getRoot().getAbsolutePath().toString();
		String DESTINATION_PATH=temporaryDestinationFolder.getRoot().getAbsolutePath().toString();
		FileProcessingUtil.moveAndOverwrite(SOURCE_PATH, DESTINATION_PATH);
		assertThat(temporaryDestinationFolder.getRoot().listFiles()[0].getName(),is(file.getName()));
	}
}
