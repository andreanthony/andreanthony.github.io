package com.jpmorgan.cib.wlt.ctrac.commons.utils.date;

/**
 * Created by E704298 on 8/4/2017.
 */
public class TestDefaultDateFormatter extends TestSimplePatternDateFormatter {
    public TestDefaultDateFormatter() {
        init(DefaultDateFormatter.class, 2017, 8, 4, "08/04/2017");
    }
}
