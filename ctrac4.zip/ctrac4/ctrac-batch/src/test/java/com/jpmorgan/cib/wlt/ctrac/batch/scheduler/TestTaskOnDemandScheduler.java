package com.jpmorgan.cib.wlt.ctrac.batch.scheduler;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.CoreLogicFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.ServiceLinkFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.*;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataMoverAdaptor;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.*;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestTaskOnDemandScheduler {

    @Mock
    private BatchCtrlRepository batchCtrlRepository;
    @Mock
    private CalendarDayUtil calendarDayUtil;
    @Mock
    private FloodRemapBatchService floodRemapBatchService;
    @Mock
    private InsurancePolicyBatchService insurancePolicyBatchService;
    @Mock
    private LenderPlaceService lenderPlaceService;
    @Mock
    private LPRequestToVendorService lpRequestToVendorService;
    @Mock
    private SchedulerMngtService schedulerMngtService;
    @Mock
    private UserEntitlementService userEntitlementService;
    @Mock
    private EmailNotificationService emailNotificationService;
    @Mock(name = "coreLogicDataExtract")
    private FloodRemapDataExtract coreLogicDataExtract;
    @Mock(name = "coreLogicDataMoverAdapter")
    private DataMoverAdaptor<CoreLogicFloodRemap, FloodRemap> coreLogicDataMoverAdapter;
    @Mock(name = "serviceLinkDataExtract")
    private FloodRemapDataExtract serviceLinkDataExtract;
    @Mock(name = "althansResponseDataExtract")
    private FloodRemapDataExtract althansResponseDataExtract;
    @Mock(name = "althansCertificateDataExtract")
    private FloodRemapDataExtract althansCertificateDataExtract;
    @Mock(name = "policyRenewalBatchService")
    private PolicyRenewalBatchService policyRenewalBatchService;
    @Mock(name = "processGDSImage")
    private ProcessGDSImage processGDSImage;
    @Mock(name = "serviceLinkDataMoverAdapter")
    private DataMoverAdaptor<ServiceLinkFloodRemap, FloodRemap> serviceLinkDataMoverAdapter;
    @Mock
    private BatchCtrl testBatchCtrl;

    @Spy
    @InjectMocks
    TaskOnDemandScheduler testObj;

    @Before
    public void setup() {
        when(batchCtrlRepository.save(testBatchCtrl)).thenReturn(testBatchCtrl);
        when(calendarDayUtil.getCurrentReferenceDate()).thenReturn(new Date());
    }

    private void setupCommonEnabled(SchedulerJob job) {
        setupCommonEnabled(job, true);
    }

    private void setupCommonEnabled(SchedulerJob job, boolean isWorkingDay) {
        when(batchCtrlRepository.findByBatchType(job.getName())).thenReturn(Arrays.asList(testBatchCtrl));
    }

    private void verifyCommonEnabled(SchedulerJob job, boolean skipEnabledCheck, int expectedSaveCount) {
        verifyCommonEnabled(job, skipEnabledCheck, expectedSaveCount, false);
    }

    private void verifyCommonEnabled(SchedulerJob job, boolean skipEnabledCheck, int expectedSaveCount, boolean verifyWorkingDay) {
        verifySchedulerService(job, skipEnabledCheck);

        verify(batchCtrlRepository, times(expectedSaveCount)).save(testBatchCtrl);
        if (expectedSaveCount > 2) {
            verify(testObj).turnOnRunningFlag(job);
        }

        verify(testObj).turnOffRunningFlag(job);
        verify(calendarDayUtil).getCurrentReferenceDate();
        if (verifyWorkingDay) {
            verify(calendarDayUtil, times(1)).isWorkingDay();
        }
    }

    private void verifySchedulerService(SchedulerJob job, boolean skipEnabledCheck) {
        if (skipEnabledCheck) {
            verifyZeroInteractions(schedulerMngtService);
        } else {
            verify(schedulerMngtService).isJobEnabled(job);
        }
    }

    private void verifyCommonDisabled(SchedulerJob job, boolean validateWorkingDay) {
        verify(schedulerMngtService).isJobEnabled(job);
        verifyZeroInteractions(batchCtrlRepository);
        if (validateWorkingDay) {
            verify(calendarDayUtil).isWorkingDay();
        } else {
            verifyZeroInteractions(calendarDayUtil);
        }
    }

    // BEGIN runRSAMWeeklyCertification tests
    @Test
    public void test_runRSAMWeeklyCertification_SkipEnabledCheck() throws Exception {
        test_runRSAMWeeklyCertification(true);
    }

    private void test_runRSAMWeeklyCertification(boolean skipEnabledCheck) throws Exception {
        setupEnabled_runRSAMWeeklyCertification();
        testObj.runRSAMWeeklyCertification(skipEnabledCheck);
        verifyEnabled_runRSAMWeeklyCertification(skipEnabledCheck);
    }

    private void setupEnabled_runRSAMWeeklyCertification() throws Exception {
        doNothing().when(userEntitlementService).processWeeklyCertification();
        setupCommonEnabled(RSAM_WEEKLY_CERTIFICATION_JOB);
    }

    private void verifyEnabled_runRSAMWeeklyCertification(boolean skipEnabledCheck) throws Exception {
        verify(userEntitlementService).processWeeklyCertification();
        verifyCommonEnabled(RSAM_WEEKLY_CERTIFICATION_JOB, skipEnabledCheck, 2);
    }
    // END runRSAMWeeklyCertification tests

    // BEGIN runUserInactivityJob tests
    @Test
    public void test_runUserInactivityJob_SkipEnabledCheck() throws Exception {
        test_runUserInactivityJob(true);
    }

    private void test_runUserInactivityJob(boolean skipEnabledCheck) throws Exception {
        setupEnabled_runUserInactivityJob();
        testObj.runUserInactivityJob(skipEnabledCheck);
        verifyEnabled_runUserInactivityJob(skipEnabledCheck);
    }

    private void setupEnabled_runUserInactivityJob() throws Exception {
        doNothing().when(userEntitlementService).performUserInactivityActions();
        setupCommonEnabled(USER_INACTIVITY_JOB);
    }

    private void verifyEnabled_runUserInactivityJob(boolean skipEnabledCheck) throws Exception {
        verify(userEntitlementService).performUserInactivityActions();
        verifyCommonEnabled(USER_INACTIVITY_JOB, skipEnabledCheck, 2);
    }
    // END runUserInactivityJob tests

    // BEGIN runJanusCtracEntitlementSync tests
    @Test
    public void test_runJanusCtracEntitlementSync_SkipEnabledCheck() throws Exception {
        test_runJanusCtracEntitlementSync(true);
    }

    private void test_runJanusCtracEntitlementSync(boolean skipEnabledCheck) throws Exception {
        List<Users> mockedUserList = setupEnabled_runJanusCtracEntitlementSync();
        testObj.runJanusCtracEntitlementSync(skipEnabledCheck);
        verifyEnabled_runJanusCtracEntitlementSync(mockedUserList, skipEnabledCheck);
    }

    private List<Users> setupEnabled_runJanusCtracEntitlementSync() throws Exception {
        List<Users> mockedUserList = new ArrayList();
        when(userEntitlementService.getJanusUserList()).thenReturn(mockedUserList);
        when(userEntitlementService.getCTRACUserList()).thenReturn(mockedUserList);
        doNothing().when(userEntitlementService).performSyncOfUsersBetweenJanusAndCtrac(mockedUserList, mockedUserList);
        setupCommonEnabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB);
        return mockedUserList;
    }

    private void verifyEnabled_runJanusCtracEntitlementSync(List<Users> mockedUserList, boolean skipEnabledCheck) throws Exception {
        verify(userEntitlementService).getJanusUserList();
        verify(userEntitlementService).getCTRACUserList();
        verify(userEntitlementService).performSyncOfUsersBetweenJanusAndCtrac(mockedUserList, mockedUserList);
        verifyCommonEnabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB, skipEnabledCheck, 2);
    }
    // END runJanusCtracEntitlementSync tests

    // BEGIN runServiceLinkJob tests
    @Test
    public void test_runServiceLinkJob_SkipEnabledCheck() {
        test_runServiceLinkJob(true);
    }

    private void test_runServiceLinkJob(boolean skipEnabledCheck) {
        setupEnabled_runServiceLinkJob();
        testObj.runServiceLinkJob(skipEnabledCheck);
        verifyEnabled_runServiceLinkJob(skipEnabledCheck);
    }

    private void setupEnabled_runServiceLinkJob() {
        doNothing().when(serviceLinkDataExtract).processRemapFiles();
        setupCommonEnabled(SERVICE_lINK_DATA_EXTRACT);
    }

    private void verifyEnabled_runServiceLinkJob(boolean skipEnabledCheck) {
        verify(serviceLinkDataExtract).processRemapFiles();
        verifyCommonEnabled(SERVICE_lINK_DATA_EXTRACT, skipEnabledCheck, 3);
    }
    // END runServiceLinkJob tests

    // BEGIN runCoreLogicDataJob tests
    @Test
    public void test_runCoreLogicDataJob_SkipEnabledCheck() {
        test_runCoreLogicDataJob(true);
    }

    private void test_runCoreLogicDataJob(boolean skipEnabledCheck) {
        setupEnabled_runCoreLogicDataJob();
        testObj.runCoreLogicDataJob(skipEnabledCheck);
        verifyEnabled_runCoreLogicDataJob(skipEnabledCheck);
    }

    private void setupEnabled_runCoreLogicDataJob() {
        doNothing().when(coreLogicDataExtract).processRemapFiles();
        setupCommonEnabled(CORELOGIC_DATA_EXTRACT);
    }

    private void verifyEnabled_runCoreLogicDataJob(boolean skipEnabledCheck) {
        verify(coreLogicDataExtract).processRemapFiles();
        verifyCommonEnabled(CORELOGIC_DATA_EXTRACT, skipEnabledCheck, 3);
    }
    // END runCoreLogicDataJob tests

    // BEGIN runCheckRemapFileLastUpdateJob tests
    @Test
    public void test_runCheckRemapFileLastUpdateJob_SkipEnabledCheck() throws Exception {
        test_runCheckRemapFileLastUpdateJob(true);
    }

    private void test_runCheckRemapFileLastUpdateJob(boolean skipEnabledCheck) throws Exception {
        setupEnabled_runCheckRemapFileLastUpdateJob();
        testObj.runCheckRemapFileLastUpdateJob(skipEnabledCheck);
        verifyEnabled_runCheckRemapFileLastUpdateJob(skipEnabledCheck);
    }

    private void setupEnabled_runCheckRemapFileLastUpdateJob() throws Exception {
        doNothing().when(floodRemapBatchService).checkSLLastRemapFileReceivedDateAndNotify();
        doNothing().when(floodRemapBatchService).checkCLLastRemapFileReceivedDateAndNotify();
        setupCommonEnabled(LAST_RECEIVED_REMAP_NOTIFY);
    }

    private void verifyEnabled_runCheckRemapFileLastUpdateJob(boolean skipEnabledCheck) throws Exception {
        verify(floodRemapBatchService).checkSLLastRemapFileReceivedDateAndNotify();
        verify(floodRemapBatchService).checkCLLastRemapFileReceivedDateAndNotify();
        verifyCommonEnabled(LAST_RECEIVED_REMAP_NOTIFY, skipEnabledCheck, 3);
    }
    // END runCheckRemapFileLastUpdateJob tests

    // BEGIN runEndOfTheDayJob tests
    @Test
    public void test_runEndOfTheDayJob_SkipEnabledCheck() {
        test_runEndOfTheDayJob(true);
    }

    private void test_runEndOfTheDayJob(boolean skipEnabledCheck) {
        setupEnabled_runEndOfTheDayJob();
        testObj.runEndOfTheDayJob(skipEnabledCheck);
        verifyEnabled_runEndOfTheDayJob(skipEnabledCheck);
    }

    private void setupEnabled_runEndOfTheDayJob() {
        doNothing().when(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        doNothing().when(testObj).createAggregateItemsForPropertyTasks(true);
        doNothing().when(testObj).runSendLPPremiumEMail(true);
        doNothing().when(testObj).runNewTaskCreationJobSL(true);
        doNothing().when(testObj).runNewTaskCreationJobCL(true);
        doNothing().when(testObj).runNewTaskCreationJob(true);
        doNothing().when(testObj).placeValidGDSLetterFile();
        setupCommonEnabled(FULL_EOD_JOB);
    }

    private void verifyEnabled_runEndOfTheDayJob(boolean skipEnabledCheck) {
        verify(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        verify(testObj).createAggregateItemsForPropertyTasks(true);
        verify(testObj).runSendLPPremiumEMail(true);
        verify(testObj).runNewTaskCreationJobSL(true);
        verify(testObj).runNewTaskCreationJobCL(true);
        verify(testObj).runNewTaskCreationJob(true);
        verify(testObj).placeValidGDSLetterFile();
        verifyCommonEnabled(FULL_EOD_JOB, skipEnabledCheck, 3);
    }

    @Test
    public void test_runEndOfTheDayJob_WithException() {
        setupCommonEnabled(FULL_EOD_JOB);
        doThrow(NullPointerException.class).when(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        boolean skipEnabledCheck = true;
        testObj.runEndOfTheDayJob(skipEnabledCheck);
        verify(floodRemapBatchService).archiveInValidLetterFile();
        verifyCommonEnabled(FULL_EOD_JOB, skipEnabledCheck, 3);
    }
    // END runEndOfTheDayJob tests

    // BEGIN runSendCoverageGapReportEmail tests
    @Test
    public void test_runSendCoverageGapReportEmail_SkipEnabledCheck() {
        test_runSendCoverageGapReportEmail(true);
    }

    private void test_runSendCoverageGapReportEmail(boolean skipEnabledCheck) {
        setupEnabled_runSendCoverageGapReportEmail();
        testObj.runSendCoverageGapReportEmail(skipEnabledCheck);
        verifyEnabled_runSendCoverageGapReportEmail(skipEnabledCheck);
    }

    private void setupEnabled_runSendCoverageGapReportEmail() {
        doNothing().when(emailNotificationService).sendCoverageGapReportEmail();
        setupCommonEnabled(COVERAGE_GAP_REPORT_EMAIL);
    }

    private void verifyEnabled_runSendCoverageGapReportEmail(boolean skipEnabledCheck) {
        verify(emailNotificationService).sendCoverageGapReportEmail();
        verifyCommonEnabled(COVERAGE_GAP_REPORT_EMAIL, skipEnabledCheck, 3);
    }
    // END runSendCoverageGapReportEmail tests

    // BEGIN runEndOfTheDayC3Job tests
    @Test
    public void test_runEndOfTheDayC3Job_SkipEnabledCheck() {
        test_runEndOfTheDayC3Job(true);
    }

    private void test_runEndOfTheDayC3Job(boolean skipEnabledCheck) {
        setupEnabled_runEndOfTheDayC3Job();
        testObj.runEndOfTheDayC3Job(skipEnabledCheck);
        verifyEnabled_runEndOfTheDayC3Job(skipEnabledCheck);
    }

    private void setupEnabled_runEndOfTheDayC3Job() {
        doNothing().when(emailNotificationService).sendLettersReviewEmail();
        doNothing().when(testObj).runInsurancePolicyC3Jobs(true);
        setupCommonEnabled(EOD_C3_JOB);
    }

    private void verifyEnabled_runEndOfTheDayC3Job(boolean skipEnabledCheck) {
        verify(emailNotificationService).sendLettersReviewEmail();
        verify(testObj).runInsurancePolicyC3Jobs(true);
        verifyCommonEnabled(EOD_C3_JOB, skipEnabledCheck, 3);
    }
    // END runEndOfTheDayC3Job tests

    // BEGIN runInsurancePolicyC3Jobs tests
    @Test
    public void test_runInsurancePolicyC3Jobs_SkipEnabledCheck() {
        test_runInsurancePolicyC3Jobs(true);
    }

    private void test_runInsurancePolicyC3Jobs(boolean skipEnabledCheck) {
        Set<Long> mockedCollateralsProcessedSet = setupEnabled_runInsurancePolicyC3Jobs();
        testObj.runInsurancePolicyC3Jobs(skipEnabledCheck);
        verifyEnabled_runInsurancePolicyC3Jobs(mockedCollateralsProcessedSet, skipEnabledCheck);
    }

    private Set<Long> setupEnabled_runInsurancePolicyC3Jobs() {
        Set<Long> mockedCollateralsProcessedSet = new HashSet<>();
        when(insurancePolicyBatchService.processExpiringPolicies()).thenReturn(mockedCollateralsProcessedSet);
        when(insurancePolicyBatchService.processNewlyEffectivePolicies(mockedCollateralsProcessedSet)).thenReturn(mockedCollateralsProcessedSet);
        setupCommonEnabled(INSURANCE_POLICY_C3);
        return mockedCollateralsProcessedSet;
    }

    private void verifyEnabled_runInsurancePolicyC3Jobs(Set<Long> mockedCollateralsProcessedSet, boolean skipEnabledCheck) {
        verify(insurancePolicyBatchService).processExpiringPolicies();
        verify(insurancePolicyBatchService).processNewlyEffectivePolicies(mockedCollateralsProcessedSet);
        verifySchedulerService(INSURANCE_POLICY_C3, skipEnabledCheck);
    }
    // END runInsurancePolicyC3Jobs tests

    // BEGIN runStatesAndSLAUpdateEndOfTheDayJob tests
    @Test
    public void test_runStatesAndSLAUpdateEndOfTheDayJob_SkipEnabledCheck() {
        test_runStatesAndSLAUpdateEndOfTheDayJob(true);
    }

    private void test_runStatesAndSLAUpdateEndOfTheDayJob(boolean skipEnabledCheck) {
        setupEnabled_runStatesAndSLAUpdateEndOfTheDayJob();
        testObj.runStatesAndSLAUpdateEndOfTheDayJob(skipEnabledCheck);
        verifyEnabled_runStatesAndSLAUpdateEndOfTheDayJob(skipEnabledCheck);
    }

    private void setupEnabled_runStatesAndSLAUpdateEndOfTheDayJob() {
        doNothing().when(floodRemapBatchService).calculateSLAandMoveTaskToNextWFStep();
        setupCommonEnabled(STATE_AND_SLA_JOB);
    }

    private void verifyEnabled_runStatesAndSLAUpdateEndOfTheDayJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).calculateSLAandMoveTaskToNextWFStep();
        verifySchedulerService(STATE_AND_SLA_JOB, skipEnabledCheck);
    }

    @Test
    public void test_runStatesAndSLAUpdateEndOfTheDayJob_WithException() {
        setupCommonEnabled(STATE_AND_SLA_JOB);
        doThrow(NullPointerException.class).when(floodRemapBatchService).calculateSLAandMoveTaskToNextWFStep();
        boolean skipEnabledCheck = true;
        testObj.runStatesAndSLAUpdateEndOfTheDayJob(skipEnabledCheck);
        verify(floodRemapBatchService).archiveInValidLetterFile();
        verifySchedulerService(STATE_AND_SLA_JOB, skipEnabledCheck);
    }
    // END runStatesAndSLAUpdateEndOfTheDayJob tests

    // BEGIN runNewTaskCreationJobSL tests
    @Test
    public void test_runNewTaskCreationJobSL_SkipEnabledCheck() {
        test_runNewTaskCreationJobSL(true);
    }

    private void test_runNewTaskCreationJobSL(boolean skipEnabledCheck) {
        setupEnabled_runNewTaskCreationJobSL();
        testObj.runNewTaskCreationJobSL(skipEnabledCheck);
        verifyEnabled_runNewTaskCreationJobSL(skipEnabledCheck);
    }

    private void setupEnabled_runNewTaskCreationJobSL() {
        doNothing().when(serviceLinkDataMoverAdapter).runDataMover();
        setupCommonEnabled(NEW_TASK_JOB_SL);
    }

    private void verifyEnabled_runNewTaskCreationJobSL(boolean skipEnabledCheck) {
        verify(serviceLinkDataMoverAdapter).runDataMover();
        verifySchedulerService(NEW_TASK_JOB_SL, skipEnabledCheck);
    }
    // END runNewTaskCreationJobSL tests

    // BEGIN runNewTaskCreationJobCL tests
    @Test
    public void test_runNewTaskCreationJobCL_SkipEnabledCheck() {
        test_runNewTaskCreationJobCL(true);
    }

    private void test_runNewTaskCreationJobCL(boolean skipEnabledCheck) {
        setupEnabled_runNewTaskCreationJobCL();
        testObj.runNewTaskCreationJobCL(skipEnabledCheck);
        verifyEnabled_runNewTaskCreationJobCL(skipEnabledCheck);
    }

    private void setupEnabled_runNewTaskCreationJobCL() {
        doNothing().when(coreLogicDataMoverAdapter).runDataMover();
        setupCommonEnabled(NEW_TASK_JOB_CL);
    }

    private void verifyEnabled_runNewTaskCreationJobCL(boolean skipEnabledCheck) {
        verify(coreLogicDataMoverAdapter).runDataMover();
        verifySchedulerService(NEW_TASK_JOB_CL, skipEnabledCheck);
    }
    // END runNewTaskCreationJobCL tests

    // BEGIN runNewTaskCreationJob tests
    @Test
    public void test_runNewTaskCreationJob_SkipEnabledCheck() {
        test_runNewTaskCreationJob(true);
    }

    private void test_runNewTaskCreationJob(boolean skipEnabledCheck) {
        setupEnabled_runNewTaskCreationJob();
        testObj.runNewTaskCreationJob(skipEnabledCheck);
        verifyEnabled_runNewTaskCreationJob(skipEnabledCheck);
    }

    private void setupEnabled_runNewTaskCreationJob() {
        doNothing().when(floodRemapBatchService).createNewFloodRemapTasks();
        setupCommonEnabled(NEW_TASK_JOB);
    }

    private void verifyEnabled_runNewTaskCreationJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).createNewFloodRemapTasks();
        verifySchedulerService(NEW_TASK_JOB, skipEnabledCheck);
    }
    // END runNewTaskCreationJob tests

    // BEGIN runSendLPPremiumEMail tests
    @Test
    public void test_runSendLPPremiumEMail_SkipEnabledCheck() {
        test_runSendLPPremiumEMail(true);
    }

    private void test_runSendLPPremiumEMail(boolean skipEnabledCheck) {
        setupEnabled_runSendLPPremiumEMail();
        testObj.runSendLPPremiumEMail(skipEnabledCheck);
        verifyEnabled_runSendLPPremiumEMail();
    }

    private void setupEnabled_runSendLPPremiumEMail() {
        doNothing().when(lenderPlaceService).processLpPremiumPaidLOBEmail();
    }

    private void verifyEnabled_runSendLPPremiumEMail() {
        verify(lenderPlaceService).processLpPremiumPaidLOBEmail();
    }
    // END runSendLPPremiumEMail tests

    // BEGIN runSendRequestToInsuranceVendorJob tests
    @Test
    public void test_runSendRequestToInsuranceVendorJob_SkipEnabledCheck() {
        test_runSendRequestToInsuranceVendorJob(true);
    }

    private void test_runSendRequestToInsuranceVendorJob(boolean skipEnabledCheck) {
        setupEnabled_runSendRequestToInsuranceVendorJob();
        testObj.runSendRequestToInsuranceVendorJob(skipEnabledCheck);
        verifyEnabled_runSendRequestToInsuranceVendorJob(skipEnabledCheck);
    }

    private void setupEnabled_runSendRequestToInsuranceVendorJob() {
        doNothing().when(lpRequestToVendorService).sendRequestToInsuranceVendor();
        setupCommonEnabled(SEND_LP_REQUEST, true);
    }

    private void verifyEnabled_runSendRequestToInsuranceVendorJob(boolean skipEnabledCheck) {
        verify(lpRequestToVendorService).sendRequestToInsuranceVendor();
        verifyCommonEnabled(SEND_LP_REQUEST, skipEnabledCheck, 3, true);
    }

    private void testDisabled_runSendRequestToInsuranceVendorJob(boolean validateWorkingDay) {
        testObj.runSendRequestToInsuranceVendorJob(false);
        verifyZeroInteractions(lpRequestToVendorService);
        verifyCommonDisabled(SEND_LP_REQUEST, validateWorkingDay);
    }

    @Test(expected = NullPointerException.class)
    public void test_runSendRequestToInsuranceVendorJob_WithException() {
        setupEnabled_runSendRequestToInsuranceVendorJob();
        doThrow(NullPointerException.class).when(lpRequestToVendorService).sendRequestToInsuranceVendor();
        testObj.runSendRequestToInsuranceVendorJob(true);
        verify(batchCtrlRepository, times(3)).save(testBatchCtrl);
        verify(testObj).turnOnRunningFlag(SEND_LP_REQUEST);
        verify(testObj).turnOffRunningFlag(SEND_LP_REQUEST);
        verify(calendarDayUtil, times(1)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }
    // END runSendRequestToInsuranceVendorJob tests

    // BEGIN runSendRequestToInsuranceVendorAlthansJob tests
    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_SkipEnabledCheck() {
        test_runSendRequestToInsuranceVendorAlthansJob(true);
    }

    private void test_runSendRequestToInsuranceVendorAlthansJob(boolean skipEnabledCheck) {
        setupEnabled_runSendRequestToInsuranceVendorAlthansJob();
        testObj.runSendRequestToInsuranceVendorAlthansJob(skipEnabledCheck);
        verifyEnabled_runSendRequestToInsuranceVendorAlthansJob(skipEnabledCheck);
    }

    private void setupEnabled_runSendRequestToInsuranceVendorAlthansJob() {
        doNothing().when(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        doNothing().when(lpRequestToVendorService).sendRequestToInsuranceVendorAlthans();
        when(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS)).thenReturn(false);
        setupCommonEnabled(SEND_LP_REQUEST_ALTHANS, true);
    }

    private void verifyEnabled_runSendRequestToInsuranceVendorAlthansJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        verify(lpRequestToVendorService).sendRequestToInsuranceVendorAlthans();
        verify(batchCtrlRepository, times(4)).save(testBatchCtrl);
        verify(testObj).turnOnRunningFlag(SEND_LP_REQUEST_ALTHANS);
        verify(testObj).turnOffRunningFlag(SEND_LP_REQUEST_ALTHANS);
        verify(calendarDayUtil, times(2)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_AlreadyRan() {
        setupCommonEnabled(SEND_LP_REQUEST_ALTHANS, true);
        when(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS)).thenReturn(true);
        testObj.runSendRequestToInsuranceVendorAlthansJob(true);
        verifyZeroInteractions(lpRequestToVendorService);
        verify(schedulerMngtService).hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS);
    }

    @Test(expected = NullPointerException.class)
    public void test_runSendRequestToInsuranceVendorAlthansJob_WithException() {
        setupEnabled_runSendRequestToInsuranceVendorAlthansJob();
        doThrow(NullPointerException.class).when(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        testObj.runSendRequestToInsuranceVendorAlthansJob(true);
        verify(batchCtrlRepository, times(3)).save(testBatchCtrl);
        verify(testObj).turnOnRunningFlag(SEND_LP_REQUEST_ALTHANS);
        verify(testObj).turnOffRunningFlag(SEND_LP_REQUEST_ALTHANS);
        verify(calendarDayUtil, times(1)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }
    // END runSendRequestToInsuranceVendorAlthansJob tests

    // BEGIN runUpdateReferenceDateJob tests
    @Test
    public void test_runUpdateReferenceDateJob_SkipEnabledCheck() {
        test_runUpdateReferenceDateJob(true);
    }

    private void test_runUpdateReferenceDateJob(boolean skipEnabledCheck) {
        setupEnabled_runUpdateReferenceDateJob();
        testObj.runUpdateReferenceDateJob(skipEnabledCheck);
        verifyEnabled_runUpdateReferenceDateJob(skipEnabledCheck);
    }

    private void setupEnabled_runUpdateReferenceDateJob() {
        doNothing().when(floodRemapBatchService).updateReferenceDate();
        setupCommonEnabled(UPDATE_REFERENCE_DATE);
    }

    private void verifyEnabled_runUpdateReferenceDateJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).updateReferenceDate();
        verifyCommonEnabled(UPDATE_REFERENCE_DATE, skipEnabledCheck, 3);
    }
    // END runUpdateReferenceDateJob tests

    // BEGIN runSendRequestToInsuranceVendorJob tests
    @Test
    public void test_runProcessToReviewPolicyJob_SkipEnabledCheck() {
        test_runProcessToReviewPolicyJob(true);
    }

    private void test_runProcessToReviewPolicyJob(boolean skipEnabledCheck) {
        setupEnabled_runProcessToReviewPolicyJob();
        testObj.runProcessToReviewPolicyJob(skipEnabledCheck);
        verifyEnabled_runProcessToReviewPolicyJob(skipEnabledCheck);
    }

    private void setupEnabled_runProcessToReviewPolicyJob() {
        doNothing().when(policyRenewalBatchService).initiatePolicyRenewalReviewProcess();
        setupCommonEnabled(PROCESS_INS_POLICY_TO_REVIEW, true);
    }

    private void verifyEnabled_runProcessToReviewPolicyJob(boolean skipEnabledCheck) {
        verify(policyRenewalBatchService).initiatePolicyRenewalReviewProcess();
        verifyCommonEnabled(PROCESS_INS_POLICY_TO_REVIEW, skipEnabledCheck, 3, true);
    }

    private void testDisabled_runProcessToReviewPolicyJob(boolean validateWorkingDay) {
        testObj.runProcessToReviewPolicyJob(false);
        verifyZeroInteractions(policyRenewalBatchService);
        verifyCommonDisabled(PROCESS_INS_POLICY_TO_REVIEW, validateWorkingDay);
    }
    // END runSendRequestToInsuranceVendorJob tests

    // BEGIN runProcessWireRequestJob tests
    @Test
    public void test_runProcessWireRequestJob_SkipEnabledCheck() {
        test_runProcessWireRequestJob(true);
    }

    private void test_runProcessWireRequestJob(boolean skipEnabledCheck) {
        setupEnabled_runProcessWireRequestJob();
        testObj.runProcessWireRequestJob(skipEnabledCheck);
        verifyEnabled_runProcessWireRequestJob(skipEnabledCheck);
    }

    private void setupEnabled_runProcessWireRequestJob() {
        doNothing().when(floodRemapBatchService).processWiredPolicy();
        setupCommonEnabled(PROCESS_WIRE_REQUEST);
    }

    private void verifyEnabled_runProcessWireRequestJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).processWiredPolicy();
        verifyCommonEnabled(PROCESS_WIRE_REQUEST, skipEnabledCheck, 3);
    }
    // END runProcessWireRequestJob tests

    // BEGIN createAggregateItemsForPropertyTasks tests
    @Test
    public void test_createAggregateItemsForPropertyTasks_SkipEnabledCheck() {
        test_createAggregateItemsForPropertyTasks(true);
    }

    private void test_createAggregateItemsForPropertyTasks(boolean skipEnabledCheck) {
        setupEnabled_createAggregateItemsForPropertyTasks();
        testObj.createAggregateItemsForPropertyTasks(skipEnabledCheck);
        verifyEnabled_createAggregateItemsForPropertyTasks(skipEnabledCheck);
    }

    private void setupEnabled_createAggregateItemsForPropertyTasks() {
        doNothing().when(floodRemapBatchService).processConfirmedWiredRequest();
        doNothing().when(floodRemapBatchService).processPendingSendLOBEmailForAlthans();
        setupCommonEnabled(PROCESS_CONFIRMED_WIRE_REQUEST);
    }

    private void verifyEnabled_createAggregateItemsForPropertyTasks(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).processConfirmedWiredRequest();
        verify(floodRemapBatchService).processPendingSendLOBEmailForAlthans();
        verifySchedulerService(PROCESS_CONFIRMED_WIRE_REQUEST, skipEnabledCheck);
    }
    // END createAggregateItemsForPropertyTasks tests

    // BEGIN runProcessAlthansResponseFile tests
    @Test
    public void test_runProcessAlthansResponseFile_SkipEnabledCheck() {
        test_runProcessAlthansResponseFile(true);
    }

    private void test_runProcessAlthansResponseFile(boolean skipEnabledCheck) {
        setupEnabled_runProcessAlthansResponseFile();
        testObj.runProcessAlthansResponseFile(skipEnabledCheck);
        verifyEnabled_runProcessAlthansResponseFile(skipEnabledCheck);
    }

    private void setupEnabled_runProcessAlthansResponseFile() {
        doNothing().when(althansResponseDataExtract).processAlthansResponse();
        setupCommonEnabled(PROCESS_ALTHANS_RESPONSE_FILE);
    }

    private void verifyEnabled_runProcessAlthansResponseFile(boolean skipEnabledCheck) {
        verify(althansResponseDataExtract).processAlthansResponse();
        verifySchedulerService(PROCESS_ALTHANS_RESPONSE_FILE, skipEnabledCheck);
    }
    // END runProcessAlthansResponseFile tests

    // BEGIN runProcessAlthansCertificateFile tests
    @Test
    public void test_runProcessAlthansCertificateFile_SkipEnabledCheck() {
        test_runProcessAlthansCertificateFile(true);
    }

    private void test_runProcessAlthansCertificateFile(boolean skipEnabledCheck) {
        setupEnabled_runProcessAlthansCertificateFile();
        testObj.runProcessAlthansCertificateFile(skipEnabledCheck);
        verifyEnabled_runProcessAlthansCertificateFile(skipEnabledCheck);
    }

    private void setupEnabled_runProcessAlthansCertificateFile() {
        doNothing().when(althansCertificateDataExtract).processAlthansCertificateFile();
        setupCommonEnabled(PROCESS_ALTHANS_CERTIFICATE_FILE);
    }

    private void verifyEnabled_runProcessAlthansCertificateFile(boolean skipEnabledCheck) {
        verify(althansCertificateDataExtract).processAlthansCertificateFile();
        verifySchedulerService(PROCESS_ALTHANS_CERTIFICATE_FILE, skipEnabledCheck);
    }
    // END runProcessAlthansCertificateFile tests

    // BEGIN runPostFullEodJob tests
    @Test
    public void test_runPostFullEodJob_SkipEnabledCheck() {
        test_runPostFullEodJob(true);
    }

    private void test_runPostFullEodJob(boolean skipEnabledCheck) {
        setupEnabled_runPostFullEodJob();
        testObj.runPostFullEodJob(skipEnabledCheck);
        verifyEnabled_runPostFullEodJob(skipEnabledCheck);
    }

    private void setupEnabled_runPostFullEodJob() {
        doNothing().when(floodRemapBatchService).reconcileCtracAndTM();
        setupCommonEnabled(POST_FULL_EOD_JOB);
    }

    private void verifyEnabled_runPostFullEodJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).reconcileCtracAndTM();
        verifyCommonEnabled(POST_FULL_EOD_JOB, skipEnabledCheck, 3);
    }
    // END runPostFullEodJob tests

    // BEGIN runProcessGDSImageJob tests
    @Test
    public void test_runProcessGDSImageJob_SkipEnabledCheck() {
        test_runProcessGDSImageJob(true);
    }

    private void test_runProcessGDSImageJob(boolean skipEnabledCheck) {
        setupEnabled_runProcessGDSImageJob();
        assertTrue(testObj.runProcessGDSImageJob(skipEnabledCheck));
        verifyEnabled_runProcessGDSImageJob(skipEnabledCheck);
    }

    private void setupEnabled_runProcessGDSImageJob() {
        when(processGDSImage.processLetterImages()).thenReturn(true);
        setupCommonEnabled(PROCESS_GDSIMAGE);
    }

    private void verifyEnabled_runProcessGDSImageJob(boolean skipEnabledCheck) {
        verify(processGDSImage).processLetterImages();
        verifyCommonEnabled(PROCESS_GDSIMAGE, skipEnabledCheck, 3);
    }
    // END runProcessGDSImageJob tests
}
