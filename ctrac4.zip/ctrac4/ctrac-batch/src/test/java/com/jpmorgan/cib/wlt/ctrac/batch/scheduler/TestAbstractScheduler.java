package com.jpmorgan.cib.wlt.ctrac.batch.scheduler;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.CoreLogicFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.ServiceLinkFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.*;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataMoverAdaptor;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestAbstractScheduler {

    @Mock
    private BatchCtrlRepository batchCtrlRepository;
    @Mock
    private CalendarDayUtil calendarDayUtil;
    @Mock
    private FloodRemapBatchService floodRemapBatchService;
    @Mock
    private InsurancePolicyBatchService insurancePolicyBatchService;
    @Mock
    private LenderPlaceService lenderPlaceService;
    @Mock
    private LPRequestToVendorService lpRequestToVendorService;
    @Mock
    private SchedulerMngtService schedulerMngtService;
    @Mock
    private UserEntitlementService userEntitlementService;
    @Mock
    private EmailNotificationService emailNotificationService;
    @Mock(name = "coreLogicDataExtract")
    private FloodRemapDataExtract coreLogicDataExtract;
    @Mock(name = "coreLogicDataMoverAdapter")
    private DataMoverAdaptor<CoreLogicFloodRemap, FloodRemap> coreLogicDataMoverAdapter;
    @Mock(name = "serviceLinkDataExtract")
    private FloodRemapDataExtract serviceLinkDataExtract;
    @Mock(name = "althansResponseDataExtract")
    private FloodRemapDataExtract althansResponseDataExtract;
    @Mock(name = "althansCertificateDataExtract")
    private FloodRemapDataExtract althansCertificateDataExtract;
    @Mock(name = "policyRenewalBatchService")
    private PolicyRenewalBatchService policyRenewalBatchService;
    @Mock(name = "processGDSImage")
    private ProcessGDSImage processGDSImage;
    @Mock(name = "serviceLinkDataMoverAdapter")
    private DataMoverAdaptor<ServiceLinkFloodRemap, FloodRemap> serviceLinkDataMoverAdapter;
    @Mock
    private BatchCtrl testBatchCtrl;

    @Spy
    @InjectMocks
    TestScheduler testObj;

    @Before
    public void setup() {
        when(batchCtrlRepository.save(testBatchCtrl)).thenReturn(testBatchCtrl);
        when(calendarDayUtil.getCurrentReferenceDate()).thenReturn(new Date());
    }

    private void setupCommonEnabled(SchedulerJob job) {
        setupCommonEnabled(job, true);
    }

    private void setupCommonEnabled(SchedulerJob job, boolean isWorkingDay) {
        when(batchCtrlRepository.findByBatchType(job.getName())).thenReturn(Arrays.asList(testBatchCtrl));
        when(schedulerMngtService.isJobEnabled(job)).thenReturn(true);
        when(calendarDayUtil.isWorkingDay()).thenReturn(isWorkingDay);
    }

    private void verifyCommonEnabled(SchedulerJob job, boolean skipEnabledCheck, int expectedSaveCount) {
        verifyCommonEnabled(job, skipEnabledCheck, expectedSaveCount, false);
    }

    private void verifyCommonEnabled(SchedulerJob job, boolean skipEnabledCheck, int expectedSaveCount, boolean verifyWorkingDay) {
        verifySchedulerService(job, skipEnabledCheck);

        verify(batchCtrlRepository, times(expectedSaveCount)).save(testBatchCtrl);
        if (expectedSaveCount > 2) {
            verify(testObj).turnOnRunningFlag(job);
        }

        verify(testObj).turnOffRunningFlag(job);
        verify(calendarDayUtil).getCurrentReferenceDate();
        if (verifyWorkingDay) {
            verify(calendarDayUtil, times(1)).isWorkingDay();
        }
    }

    private void verifySchedulerService(SchedulerJob job, boolean skipEnabledCheck) {
        if (skipEnabledCheck) {
            verifyZeroInteractions(schedulerMngtService);
        } else {
            verify(schedulerMngtService).isJobEnabled(job);
        }
    }

    private void setupCommonDisabled(SchedulerJob job) {
        when(schedulerMngtService.isJobEnabled(job)).thenReturn(false);
    }

    private void verifyCommonDisabled(SchedulerJob job) {
        verifyCommonDisabled(job, false);
    }

    private void verifyCommonDisabled(SchedulerJob job, boolean validateWorkingDay) {
        verify(schedulerMngtService).isJobEnabled(job);
        verifyZeroInteractions(batchCtrlRepository);
        if (validateWorkingDay) {
            verify(calendarDayUtil).isWorkingDay();
        } else {
            verifyZeroInteractions(calendarDayUtil);
        }
    }

    // BEGIN runRSAMWeeklyCertification tests
    @Test
    public void test_runRSAMWeeklyCertification_SkipEnabledCheck() throws Exception {
        test_runRSAMWeeklyCertification(true);
    }

    @Test
    public void test_runRSAMWeeklyCertification_Enabled() throws Exception {
        test_runRSAMWeeklyCertification(false);
    }

    private void test_runRSAMWeeklyCertification(boolean skipEnabledCheck) throws Exception {
        setupEnabled_runRSAMWeeklyCertification();
        testObj.runRSAMWeeklyCertification(skipEnabledCheck);
        verifyEnabled_runRSAMWeeklyCertification(skipEnabledCheck);
    }

    private void setupEnabled_runRSAMWeeklyCertification() throws Exception {
        doNothing().when(userEntitlementService).processWeeklyCertification();
        setupCommonEnabled(RSAM_WEEKLY_CERTIFICATION_JOB);
    }

    private void verifyEnabled_runRSAMWeeklyCertification(boolean skipEnabledCheck) throws Exception {
        verify(userEntitlementService).processWeeklyCertification();
        verifyCommonEnabled(RSAM_WEEKLY_CERTIFICATION_JOB, skipEnabledCheck, 2);
    }

    @Test
    public void test_runRSAMWeeklyCertification_NotEnabled() {
        setupCommonDisabled(RSAM_WEEKLY_CERTIFICATION_JOB);
        testObj.runRSAMWeeklyCertification(false);
        verifyZeroInteractions(userEntitlementService);
        verifyCommonDisabled(RSAM_WEEKLY_CERTIFICATION_JOB);
    }
    // END runRSAMWeeklyCertification tests

    // BEGIN runUserInactivityJob tests
    @Test
    public void test_runUserInactivityJob_SkipEnabledCheck() throws Exception {
        test_runUserInactivityJob(true);
    }

    @Test
    public void test_runUserInactivityJob_Enabled() throws Exception {
        test_runUserInactivityJob(false);
    }

    private void test_runUserInactivityJob(boolean skipEnabledCheck) throws Exception {
        setupEnabled_runUserInactivityJob();
        testObj.runUserInactivityJob(skipEnabledCheck);
        verifyEnabled_runUserInactivityJob(skipEnabledCheck);
    }

    private void setupEnabled_runUserInactivityJob() throws Exception {
        doNothing().when(userEntitlementService).performUserInactivityActions();
        setupCommonEnabled(USER_INACTIVITY_JOB);
    }

    private void verifyEnabled_runUserInactivityJob(boolean skipEnabledCheck) throws Exception {
        verify(userEntitlementService).performUserInactivityActions();
        verifyCommonEnabled(USER_INACTIVITY_JOB, skipEnabledCheck, 2);
    }

    @Test
    public void test_runUserInactivityJob_NotEnabled() {
        setupCommonDisabled(USER_INACTIVITY_JOB);
        testObj.runUserInactivityJob(false);
        verifyZeroInteractions(userEntitlementService);
        verifyCommonDisabled(USER_INACTIVITY_JOB);
    }
    // END runUserInactivityJob tests

    // BEGIN runJanusCtracEntitlementSync tests
    @Test
    public void test_runJanusCtracEntitlementSync_SkipEnabledCheck() throws Exception {
        test_runJanusCtracEntitlementSync(true);
    }

    @Test
    public void test_runJanusCtracEntitlementSync_Enabled() throws Exception {
        test_runJanusCtracEntitlementSync(false);
    }

    private void test_runJanusCtracEntitlementSync(boolean skipEnabledCheck) throws Exception {
        List<Users> mockedUserList = setupEnabled_runJanusCtracEntitlementSync();
        testObj.runJanusCtracEntitlementSync(skipEnabledCheck);
        verifyEnabled_runJanusCtracEntitlementSync(mockedUserList, skipEnabledCheck);
    }

    private List<Users> setupEnabled_runJanusCtracEntitlementSync() throws Exception {
        List<Users> mockedUserList = new ArrayList();
        when(userEntitlementService.getJanusUserList()).thenReturn(mockedUserList);
        when(userEntitlementService.getCTRACUserList()).thenReturn(mockedUserList);
        doNothing().when(userEntitlementService).performSyncOfUsersBetweenJanusAndCtrac(mockedUserList, mockedUserList);
        setupCommonEnabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB);
        return mockedUserList;
    }

    private void verifyEnabled_runJanusCtracEntitlementSync(List<Users> mockedUserList, boolean skipEnabledCheck) throws Exception {
        verify(userEntitlementService).getJanusUserList();
        verify(userEntitlementService).getCTRACUserList();
        verify(userEntitlementService).performSyncOfUsersBetweenJanusAndCtrac(mockedUserList, mockedUserList);
        verifyCommonEnabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB, skipEnabledCheck, 2);
    }

    @Test
    public void test_runJanusCtracEntitlementSync_NotEnabled() {
        setupCommonDisabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB);
        testObj.runJanusCtracEntitlementSync(false);
        verifyZeroInteractions(userEntitlementService);
        verifyCommonDisabled(SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB);
    }
    // END runJanusCtracEntitlementSync tests

    // BEGIN runServiceLinkJob tests
    @Test
    public void test_runServiceLinkJob_SkipEnabledCheck() {
        test_runServiceLinkJob(true);
    }

    @Test
    public void test_runServiceLinkJob_Enabled() {
        test_runServiceLinkJob(false);
    }

    private void test_runServiceLinkJob(boolean skipEnabledCheck) {
        setupEnabled_runServiceLinkJob();
        testObj.runServiceLinkJob(skipEnabledCheck);
        verifyEnabled_runServiceLinkJob(skipEnabledCheck);
    }

    private void setupEnabled_runServiceLinkJob() {
        doNothing().when(serviceLinkDataExtract).processRemapFiles();
        setupCommonEnabled(SERVICE_lINK_DATA_EXTRACT);
    }

    private void verifyEnabled_runServiceLinkJob(boolean skipEnabledCheck) {
        verify(serviceLinkDataExtract).processRemapFiles();
        verifyCommonEnabled(SERVICE_lINK_DATA_EXTRACT, skipEnabledCheck, 3);
    }

    @Test
    public void test_runServiceLinkJob_NotEnabled() {
        setupCommonDisabled(SERVICE_lINK_DATA_EXTRACT);
        testObj.runServiceLinkJob(false);
        verifyZeroInteractions(serviceLinkDataExtract);
        verifyCommonDisabled(SERVICE_lINK_DATA_EXTRACT);
    }
    // END runServiceLinkJob tests

    // BEGIN runCoreLogicDataJob tests
    @Test
    public void test_runCoreLogicDataJob_SkipEnabledCheck() {
        test_runCoreLogicDataJob(true);
    }

    @Test
    public void test_runCoreLogicDataJob_Enabled() {
        test_runCoreLogicDataJob(false);
    }

    private void test_runCoreLogicDataJob(boolean skipEnabledCheck) {
        setupEnabled_runCoreLogicDataJob();
        testObj.runCoreLogicDataJob(skipEnabledCheck);
        verifyEnabled_runCoreLogicDataJob(skipEnabledCheck);
    }

    private void setupEnabled_runCoreLogicDataJob() {
        doNothing().when(coreLogicDataExtract).processRemapFiles();
        setupCommonEnabled(CORELOGIC_DATA_EXTRACT);
    }

    private void verifyEnabled_runCoreLogicDataJob(boolean skipEnabledCheck) {
        verify(coreLogicDataExtract).processRemapFiles();
        verifyCommonEnabled(CORELOGIC_DATA_EXTRACT, skipEnabledCheck, 3);
    }

    @Test
    public void test_runCoreLogicDataJob_NotEnabled() {
        setupCommonDisabled(CORELOGIC_DATA_EXTRACT);
        testObj.runCoreLogicDataJob(false);
        verifyZeroInteractions(coreLogicDataExtract);
        verifyCommonDisabled(CORELOGIC_DATA_EXTRACT);
    }
    // END runCoreLogicDataJob tests

    // BEGIN runCheckRemapFileLastUpdateJob tests
    @Test
    public void test_runCheckRemapFileLastUpdateJob_SkipEnabledCheck() throws Exception {
        test_runCheckRemapFileLastUpdateJob(true);
    }

    @Test
    public void test_runCheckRemapFileLastUpdateJob_Enabled() throws Exception {
        test_runCheckRemapFileLastUpdateJob(false);
    }

    private void test_runCheckRemapFileLastUpdateJob(boolean skipEnabledCheck) throws Exception {
        setupEnabled_runCheckRemapFileLastUpdateJob();
        testObj.runCheckRemapFileLastUpdateJob(skipEnabledCheck);
        verifyEnabled_runCheckRemapFileLastUpdateJob(skipEnabledCheck);
    }

    private void setupEnabled_runCheckRemapFileLastUpdateJob() throws Exception {
        doNothing().when(floodRemapBatchService).checkSLLastRemapFileReceivedDateAndNotify();
        doNothing().when(floodRemapBatchService).checkCLLastRemapFileReceivedDateAndNotify();
        setupCommonEnabled(LAST_RECEIVED_REMAP_NOTIFY);
    }

    private void verifyEnabled_runCheckRemapFileLastUpdateJob(boolean skipEnabledCheck) throws Exception {
        verify(floodRemapBatchService).checkSLLastRemapFileReceivedDateAndNotify();
        verify(floodRemapBatchService).checkCLLastRemapFileReceivedDateAndNotify();
        verifyCommonEnabled(LAST_RECEIVED_REMAP_NOTIFY, skipEnabledCheck, 3);
    }

    @Test
    public void test_runCheckRemapFileLastUpdateJob_NotEnabled() {
        setupCommonDisabled(LAST_RECEIVED_REMAP_NOTIFY);
        testObj.runCheckRemapFileLastUpdateJob(false);
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(LAST_RECEIVED_REMAP_NOTIFY);
    }
    // END runCheckRemapFileLastUpdateJob tests

    // BEGIN runEndOfTheDayJob tests
    @Test
    public void test_runEndOfTheDayJob_SkipEnabledCheck() {
        test_runEndOfTheDayJob(true);
    }

    @Test
    public void test_runEndOfTheDayJob_Enabled() {
        test_runEndOfTheDayJob(false);
    }

    private void test_runEndOfTheDayJob(boolean skipEnabledCheck) {
        setupEnabled_runEndOfTheDayJob();
        testObj.runEndOfTheDayJob(skipEnabledCheck);
        verifyEnabled_runEndOfTheDayJob(skipEnabledCheck);
    }

    private void setupEnabled_runEndOfTheDayJob() {
        doNothing().when(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        doNothing().when(testObj).createAggregateItemsForPropertyTasks(true);
        doNothing().when(testObj).runSendLPPremiumEMail(true);
        doNothing().when(testObj).runNewTaskCreationJobSL(true);
        doNothing().when(testObj).runNewTaskCreationJobCL(true);
        doNothing().when(testObj).runNewTaskCreationJob(true);
        doNothing().when(testObj).placeValidGDSLetterFile();
        setupCommonEnabled(FULL_EOD_JOB);
    }

    private void verifyEnabled_runEndOfTheDayJob(boolean skipEnabledCheck) {
        verify(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        verify(testObj).createAggregateItemsForPropertyTasks(true);
        verify(testObj).runSendLPPremiumEMail(true);
        verify(testObj).runNewTaskCreationJobSL(true);
        verify(testObj).runNewTaskCreationJobCL(true);
        verify(testObj).runNewTaskCreationJob(true);
        verify(testObj).placeValidGDSLetterFile();
        verifyCommonEnabled(FULL_EOD_JOB, skipEnabledCheck, 3);
    }

    @Test
    public void test_runEndOfTheDayJob_NotEnabled() {
        setupCommonDisabled(FULL_EOD_JOB);
        testObj.runEndOfTheDayJob(false);
        verify(testObj, times(0)).runStatesAndSLAUpdateEndOfTheDayJob(true);
        verify(testObj, times(0)).createAggregateItemsForPropertyTasks(true);
        verify(testObj, times(0)).runSendLPPremiumEMail(true);
        verify(testObj, times(0)).runNewTaskCreationJobSL(true);
        verify(testObj, times(0)).runNewTaskCreationJobCL(true);
        verify(testObj, times(0)).runNewTaskCreationJob(true);
        verify(testObj, times(0)).placeValidGDSLetterFile();
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(FULL_EOD_JOB);
    }

    @Test
    public void test_runEndOfTheDayJob_WithException() {
        setupCommonEnabled(FULL_EOD_JOB);
        doThrow(NullPointerException.class).when(testObj).runStatesAndSLAUpdateEndOfTheDayJob(true);
        boolean skipEnabledCheck = true;
        testObj.runEndOfTheDayJob(skipEnabledCheck);
        verify(floodRemapBatchService).archiveInValidLetterFile();
        verifyCommonEnabled(FULL_EOD_JOB, skipEnabledCheck, 3);
    }
    // END runEndOfTheDayJob tests

    // BEGIN runSendCoverageGapReportEmail tests
    @Test
    public void test_runSendCoverageGapReportEmail_SkipEnabledCheck() {
        test_runSendCoverageGapReportEmail(true);
    }

    @Test
    public void test_runSendCoverageGapReportEmail_Enabled() {
        test_runSendCoverageGapReportEmail(false);
    }

    private void test_runSendCoverageGapReportEmail(boolean skipEnabledCheck) {
        setupEnabled_runSendCoverageGapReportEmail();
        testObj.runSendCoverageGapReportEmail(skipEnabledCheck);
        verifyEnabled_runSendCoverageGapReportEmail(skipEnabledCheck);
    }

    private void setupEnabled_runSendCoverageGapReportEmail() {
        doNothing().when(emailNotificationService).sendCoverageGapReportEmail();
        setupCommonEnabled(COVERAGE_GAP_REPORT_EMAIL);
    }

    private void verifyEnabled_runSendCoverageGapReportEmail(boolean skipEnabledCheck) {
        verify(emailNotificationService).sendCoverageGapReportEmail();
        verifyCommonEnabled(COVERAGE_GAP_REPORT_EMAIL, skipEnabledCheck, 3);
    }

    @Test
    public void test_runSendCoverageGapReportEmail_NotEnabled() {
        setupCommonDisabled(COVERAGE_GAP_REPORT_EMAIL);
        testObj.runSendCoverageGapReportEmail(false);
        verifyZeroInteractions(emailNotificationService);
        verifyCommonDisabled(COVERAGE_GAP_REPORT_EMAIL);
    }
    // END runSendCoverageGapReportEmail tests

    // BEGIN runEndOfTheDayC3Job tests
    @Test
    public void test_runEndOfTheDayC3Job_SkipEnabledCheck() {
        test_runEndOfTheDayC3Job(true);
    }

    @Test
    public void test_runEndOfTheDayC3Job_Enabled() {
        test_runEndOfTheDayC3Job(false);
    }

    private void test_runEndOfTheDayC3Job(boolean skipEnabledCheck) {
        setupEnabled_runEndOfTheDayC3Job();
        testObj.runEndOfTheDayC3Job(skipEnabledCheck);
        verifyEnabled_runEndOfTheDayC3Job(skipEnabledCheck);
    }

    private void setupEnabled_runEndOfTheDayC3Job() {
        doNothing().when(emailNotificationService).sendLettersReviewEmail();
        doNothing().when(testObj).runInsurancePolicyC3Jobs(true);
        setupCommonEnabled(EOD_C3_JOB);
    }

    private void verifyEnabled_runEndOfTheDayC3Job(boolean skipEnabledCheck) {
        verify(emailNotificationService).sendLettersReviewEmail();
        verify(testObj).runInsurancePolicyC3Jobs(true);
        verifyCommonEnabled(EOD_C3_JOB, skipEnabledCheck, 3);
    }

    @Test
    public void test_runEndOfTheDayC3Job_NotEnabled() {
        setupCommonDisabled(EOD_C3_JOB);
        testObj.runEndOfTheDayC3Job(false);
        verify(testObj, times(0)).runInsurancePolicyC3Jobs(true);
        verifyZeroInteractions(emailNotificationService);
        verifyCommonDisabled(EOD_C3_JOB);
    }
    // END runEndOfTheDayC3Job tests

    // BEGIN runInsurancePolicyC3Jobs tests
    @Test
    public void test_runInsurancePolicyC3Jobs_SkipEnabledCheck() {
        test_runInsurancePolicyC3Jobs(true);
    }

    @Test
    public void test_runInsurancePolicyC3Jobs_Enabled() {
        test_runInsurancePolicyC3Jobs(false);
    }

    private void test_runInsurancePolicyC3Jobs(boolean skipEnabledCheck) {
        Set<Long> mockedCollateralsProcessedSet = setupEnabled_runInsurancePolicyC3Jobs();
        testObj.runInsurancePolicyC3Jobs(skipEnabledCheck);
        verifyEnabled_runInsurancePolicyC3Jobs(mockedCollateralsProcessedSet, skipEnabledCheck);
    }

    private Set<Long> setupEnabled_runInsurancePolicyC3Jobs() {
        Set<Long> mockedCollateralsProcessedSet = new HashSet<>();
        when(insurancePolicyBatchService.processExpiringPolicies()).thenReturn(mockedCollateralsProcessedSet);
        when(insurancePolicyBatchService.processNewlyEffectivePolicies(mockedCollateralsProcessedSet)).thenReturn(mockedCollateralsProcessedSet);
        setupCommonEnabled(INSURANCE_POLICY_C3);
        return mockedCollateralsProcessedSet;
    }

    private void verifyEnabled_runInsurancePolicyC3Jobs(Set<Long> mockedCollateralsProcessedSet, boolean skipEnabledCheck) {
        verify(insurancePolicyBatchService).processExpiringPolicies();
        verify(insurancePolicyBatchService).processNewlyEffectivePolicies(mockedCollateralsProcessedSet);
        verifySchedulerService(INSURANCE_POLICY_C3, skipEnabledCheck);
    }

    @Test
    public void test_runInsurancePolicyC3Jobs_NotEnabled() {
        setupCommonDisabled(INSURANCE_POLICY_C3);
        testObj.runInsurancePolicyC3Jobs(false);
        verifyZeroInteractions(insurancePolicyBatchService);
        verifyCommonDisabled(INSURANCE_POLICY_C3);
    }
    // END runInsurancePolicyC3Jobs tests

    // BEGIN runStatesAndSLAUpdateEndOfTheDayJob tests
    @Test
    public void test_runStatesAndSLAUpdateEndOfTheDayJob_SkipEnabledCheck() {
        test_runStatesAndSLAUpdateEndOfTheDayJob(true);
    }

    @Test
    public void test_runStatesAndSLAUpdateEndOfTheDayJob_Enabled() {
        test_runStatesAndSLAUpdateEndOfTheDayJob(false);
    }

    private void test_runStatesAndSLAUpdateEndOfTheDayJob(boolean skipEnabledCheck) {
        setupEnabled_runStatesAndSLAUpdateEndOfTheDayJob();
        testObj.runStatesAndSLAUpdateEndOfTheDayJob(skipEnabledCheck);
        verifyEnabled_runStatesAndSLAUpdateEndOfTheDayJob(skipEnabledCheck);
    }

    private void setupEnabled_runStatesAndSLAUpdateEndOfTheDayJob() {
        doNothing().when(floodRemapBatchService).calculateSLAandMoveTaskToNextWFStep();
        setupCommonEnabled(STATE_AND_SLA_JOB);
    }

    private void verifyEnabled_runStatesAndSLAUpdateEndOfTheDayJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).calculateSLAandMoveTaskToNextWFStep();
        verifySchedulerService(STATE_AND_SLA_JOB, skipEnabledCheck);
    }

    @Test
    public void test_runStatesAndSLAUpdateEndOfTheDayJob_NotEnabled() {
        setupCommonDisabled(STATE_AND_SLA_JOB);
        testObj.runStatesAndSLAUpdateEndOfTheDayJob(false);
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(STATE_AND_SLA_JOB);
    }

    @Test
    public void test_runStatesAndSLAUpdateEndOfTheDayJob_WithException() {
        setupCommonEnabled(STATE_AND_SLA_JOB);
        doThrow(NullPointerException.class).when(floodRemapBatchService).calculateSLAandMoveTaskToNextWFStep();
        boolean skipEnabledCheck = true;
        testObj.runStatesAndSLAUpdateEndOfTheDayJob(skipEnabledCheck);
        verify(floodRemapBatchService).archiveInValidLetterFile();
        verifySchedulerService(STATE_AND_SLA_JOB, skipEnabledCheck);
    }
    // END runStatesAndSLAUpdateEndOfTheDayJob tests

    // BEGIN runNewTaskCreationJobSL tests
    @Test
    public void test_runNewTaskCreationJobSL_SkipEnabledCheck() {
        test_runNewTaskCreationJobSL(true);
    }

    @Test
    public void test_runNewTaskCreationJobSL_Enabled() {
        test_runNewTaskCreationJobSL(false);
    }

    private void test_runNewTaskCreationJobSL(boolean skipEnabledCheck) {
        setupEnabled_runNewTaskCreationJobSL();
        testObj.runNewTaskCreationJobSL(skipEnabledCheck);
        verifyEnabled_runNewTaskCreationJobSL(skipEnabledCheck);
    }

    private void setupEnabled_runNewTaskCreationJobSL() {
        doNothing().when(serviceLinkDataMoverAdapter).runDataMover();
        setupCommonEnabled(NEW_TASK_JOB_SL);
    }

    private void verifyEnabled_runNewTaskCreationJobSL(boolean skipEnabledCheck) {
        verify(serviceLinkDataMoverAdapter).runDataMover();
        verifySchedulerService(NEW_TASK_JOB_SL, skipEnabledCheck);
    }

    @Test
    public void test_runNewTaskCreationJobSL_NotEnabled() {
        setupCommonDisabled(NEW_TASK_JOB_SL);
        testObj.runNewTaskCreationJobSL(false);
        verifyZeroInteractions(serviceLinkDataMoverAdapter);
        verifyCommonDisabled(NEW_TASK_JOB_SL);
    }
    // END runNewTaskCreationJobSL tests

    // BEGIN runNewTaskCreationJobCL tests
    @Test
    public void test_runNewTaskCreationJobCL_SkipEnabledCheck() {
        test_runNewTaskCreationJobCL(true);
    }

    @Test
    public void test_runNewTaskCreationJobCL_Enabled() {
        test_runNewTaskCreationJobCL(false);
    }

    private void test_runNewTaskCreationJobCL(boolean skipEnabledCheck) {
        setupEnabled_runNewTaskCreationJobCL();
        testObj.runNewTaskCreationJobCL(skipEnabledCheck);
        verifyEnabled_runNewTaskCreationJobCL(skipEnabledCheck);
    }

    private void setupEnabled_runNewTaskCreationJobCL() {
        doNothing().when(coreLogicDataMoverAdapter).runDataMover();
        setupCommonEnabled(NEW_TASK_JOB_CL);
    }

    private void verifyEnabled_runNewTaskCreationJobCL(boolean skipEnabledCheck) {
        verify(coreLogicDataMoverAdapter).runDataMover();
        verifySchedulerService(NEW_TASK_JOB_CL, skipEnabledCheck);
    }

    @Test
    public void test_runNewTaskCreationJobCL_NotEnabled() {
        setupCommonDisabled(NEW_TASK_JOB_CL);
        testObj.runNewTaskCreationJobCL(false);
        verifyZeroInteractions(coreLogicDataMoverAdapter);
        verifyCommonDisabled(NEW_TASK_JOB_CL);
    }
    // END runNewTaskCreationJobCL tests

    // BEGIN runNewTaskCreationJob tests
    @Test
    public void test_runNewTaskCreationJob_SkipEnabledCheck() {
        test_runNewTaskCreationJob(true);
    }

    @Test
    public void test_runNewTaskCreationJob_Enabled() {
        test_runNewTaskCreationJob(false);
    }

    private void test_runNewTaskCreationJob(boolean skipEnabledCheck) {
        setupEnabled_runNewTaskCreationJob();
        testObj.runNewTaskCreationJob(skipEnabledCheck);
        verifyEnabled_runNewTaskCreationJob(skipEnabledCheck);
    }

    private void setupEnabled_runNewTaskCreationJob() {
        doNothing().when(floodRemapBatchService).createNewFloodRemapTasks();
        setupCommonEnabled(NEW_TASK_JOB);
    }

    private void verifyEnabled_runNewTaskCreationJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).createNewFloodRemapTasks();
        verifySchedulerService(NEW_TASK_JOB, skipEnabledCheck);
    }

    @Test
    public void test_runNewTaskCreationJob_NotEnabled() {
        setupCommonDisabled(NEW_TASK_JOB);
        testObj.runNewTaskCreationJob(false);
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(NEW_TASK_JOB);
    }
    // END runNewTaskCreationJob tests

    // BEGIN runSendLPPremiumEMail tests
    @Test
    public void test_runSendLPPremiumEMail_SkipEnabledCheck() {
        test_runSendLPPremiumEMail(true);
    }

    @Test
    public void test_runSendLPPremiumEMail_Enabled() {
        test_runSendLPPremiumEMail(false);
    }

    private void test_runSendLPPremiumEMail(boolean skipEnabledCheck) {
        setupEnabled_runSendLPPremiumEMail();
        testObj.runSendLPPremiumEMail(skipEnabledCheck);
        verifyEnabled_runSendLPPremiumEMail();
    }

    private void setupEnabled_runSendLPPremiumEMail() {
        doNothing().when(lenderPlaceService).processLpPremiumPaidLOBEmail();
    }

    private void verifyEnabled_runSendLPPremiumEMail() {
        verify(lenderPlaceService).processLpPremiumPaidLOBEmail();
    }
    // END runSendLPPremiumEMail tests

    // BEGIN runSendRequestToInsuranceVendorJob tests
    @Test
    public void test_runSendRequestToInsuranceVendorJob_SkipEnabledCheck() {
        test_runSendRequestToInsuranceVendorJob(true);
    }

    @Test
    public void test_runSendRequestToInsuranceVendorJob_Enabled() {
        test_runSendRequestToInsuranceVendorJob(false);
    }

    private void test_runSendRequestToInsuranceVendorJob(boolean skipEnabledCheck) {
        setupEnabled_runSendRequestToInsuranceVendorJob();
        testObj.runSendRequestToInsuranceVendorJob(skipEnabledCheck);
        verifyEnabled_runSendRequestToInsuranceVendorJob(skipEnabledCheck);
    }

    private void setupEnabled_runSendRequestToInsuranceVendorJob() {
        doNothing().when(lpRequestToVendorService).sendRequestToInsuranceVendor();
        setupCommonEnabled(SEND_LP_REQUEST, true);
    }

    private void verifyEnabled_runSendRequestToInsuranceVendorJob(boolean skipEnabledCheck) {
        verify(lpRequestToVendorService).sendRequestToInsuranceVendor();
        verifyCommonEnabled(SEND_LP_REQUEST, skipEnabledCheck, 3, true);
    }

    @Test
    public void test_runSendRequestToInsuranceVendorJob_NotEnabled() {
        setupCommonDisabled(SEND_LP_REQUEST);
        testDisabled_runSendRequestToInsuranceVendorJob();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorJob_NotWorkingDay() {
        setupCommonEnabled(SEND_LP_REQUEST, false);
        testDisabled_runSendRequestToInsuranceVendorJob();
    }

    private void testDisabled_runSendRequestToInsuranceVendorJob() {
        testObj.runSendRequestToInsuranceVendorJob(false);
        verifyZeroInteractions(lpRequestToVendorService);
        verifyCommonDisabled(SEND_LP_REQUEST, true);
    }

    @Test(expected = NullPointerException.class)
    public void test_runSendRequestToInsuranceVendorJob_WithException() {
        setupEnabled_runSendRequestToInsuranceVendorJob();
        doThrow(NullPointerException.class).when(lpRequestToVendorService).sendRequestToInsuranceVendor();
        testObj.runSendRequestToInsuranceVendorJob(true);
        verify(batchCtrlRepository, times(3)).save(testBatchCtrl);
        verify(testObj).turnOnRunningFlag(SEND_LP_REQUEST);
        verify(testObj).turnOffRunningFlag(SEND_LP_REQUEST);
        verify(calendarDayUtil, times(1)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }
    // END runSendRequestToInsuranceVendorJob tests

    // BEGIN runSendRequestToInsuranceVendorAlthansJob tests
    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_SkipEnabledCheck() {
        test_runSendRequestToInsuranceVendorAlthansJob(true);
    }

    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_Enabled() {
        test_runSendRequestToInsuranceVendorAlthansJob(false);
    }

    private void test_runSendRequestToInsuranceVendorAlthansJob(boolean skipEnabledCheck) {
        setupEnabled_runSendRequestToInsuranceVendorAlthansJob();
        testObj.runSendRequestToInsuranceVendorAlthansJob(skipEnabledCheck);
        verifyEnabled_runSendRequestToInsuranceVendorAlthansJob(skipEnabledCheck);
    }

    private void setupEnabled_runSendRequestToInsuranceVendorAlthansJob() {
        doNothing().when(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        doNothing().when(lpRequestToVendorService).sendRequestToInsuranceVendorAlthans();
        when(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS)).thenReturn(false);
        setupCommonEnabled(SEND_LP_REQUEST_ALTHANS, true);
    }

    private void verifyEnabled_runSendRequestToInsuranceVendorAlthansJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        verify(lpRequestToVendorService).sendRequestToInsuranceVendorAlthans();
        verify(batchCtrlRepository, times(4)).save(testBatchCtrl);
        verify(testObj).turnOnRunningFlag(SEND_LP_REQUEST_ALTHANS);
        verify(testObj).turnOffRunningFlag(SEND_LP_REQUEST_ALTHANS);
        verify(calendarDayUtil, times(2)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_NotEnabled() {
        setupCommonDisabled(SEND_LP_REQUEST_ALTHANS);
        testDisabled_runSendRequestToInsuranceVendorAlthansJob();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_NotWorkingDay() {
        setupCommonEnabled(SEND_LP_REQUEST_ALTHANS, false);
        testDisabled_runSendRequestToInsuranceVendorAlthansJob();
    }

    @Test
    public void test_runSendRequestToInsuranceVendorAlthansJob_AlreadyRan() {
        setupCommonEnabled(SEND_LP_REQUEST_ALTHANS, true);
        when(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS)).thenReturn(true);
        testDisabled_runSendRequestToInsuranceVendorAlthansJob();
    }

    private void testDisabled_runSendRequestToInsuranceVendorAlthansJob() {
        testObj.runSendRequestToInsuranceVendorAlthansJob(false);
        verifyZeroInteractions(lpRequestToVendorService);
        verifyCommonDisabled(SEND_LP_REQUEST_ALTHANS, true);
    }

    @Test(expected = NullPointerException.class)
    public void test_runSendRequestToInsuranceVendorAlthansJob_WithException() {
        setupEnabled_runSendRequestToInsuranceVendorAlthansJob();
        doThrow(NullPointerException.class).when(floodRemapBatchService).completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
        testObj.runSendRequestToInsuranceVendorAlthansJob(true);
        verify(batchCtrlRepository, times(3)).save(testBatchCtrl);
        verify(testObj).turnOnRunningFlag(SEND_LP_REQUEST_ALTHANS);
        verify(testObj).turnOffRunningFlag(SEND_LP_REQUEST_ALTHANS);
        verify(calendarDayUtil, times(1)).getCurrentReferenceDate();
        verify(calendarDayUtil, times(1)).isWorkingDay();
    }
    // END runSendRequestToInsuranceVendorAlthansJob tests

    // BEGIN runUpdateReferenceDateJob tests
    @Test
    public void test_runUpdateReferenceDateJob_SkipEnabledCheck() {
        test_runUpdateReferenceDateJob(true);
    }

    @Test
    public void test_runUpdateReferenceDateJob_Enabled() {
        test_runUpdateReferenceDateJob(false);
    }

    private void test_runUpdateReferenceDateJob(boolean skipEnabledCheck) {
        setupEnabled_runUpdateReferenceDateJob();
        testObj.runUpdateReferenceDateJob(skipEnabledCheck);
        verifyEnabled_runUpdateReferenceDateJob(skipEnabledCheck);
    }

    private void setupEnabled_runUpdateReferenceDateJob() {
        doNothing().when(floodRemapBatchService).updateReferenceDate();
        setupCommonEnabled(UPDATE_REFERENCE_DATE);
    }

    private void verifyEnabled_runUpdateReferenceDateJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).updateReferenceDate();
        verifyCommonEnabled(UPDATE_REFERENCE_DATE, skipEnabledCheck, 3);
    }

    @Test
    public void test_runUpdateReferenceDateJob_NotEnabled() {
        setupCommonDisabled(UPDATE_REFERENCE_DATE);
        testObj.runUpdateReferenceDateJob(false);
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(UPDATE_REFERENCE_DATE);
    }
    // END runUpdateReferenceDateJob tests

    // BEGIN runSendRequestToInsuranceVendorJob tests
    @Test
    public void test_runProcessToReviewPolicyJob_SkipEnabledCheck() {
        test_runProcessToReviewPolicyJob(true);
    }

    @Test
    public void test_runProcessToReviewPolicyJob_Enabled() {
        test_runProcessToReviewPolicyJob(false);
    }

    private void test_runProcessToReviewPolicyJob(boolean skipEnabledCheck) {
        setupEnabled_runProcessToReviewPolicyJob();
        testObj.runProcessToReviewPolicyJob(skipEnabledCheck);
        verifyEnabled_runProcessToReviewPolicyJob(skipEnabledCheck);
    }

    private void setupEnabled_runProcessToReviewPolicyJob() {
        doNothing().when(policyRenewalBatchService).initiatePolicyRenewalReviewProcess();
        setupCommonEnabled(PROCESS_INS_POLICY_TO_REVIEW, true);
    }

    private void verifyEnabled_runProcessToReviewPolicyJob(boolean skipEnabledCheck) {
        verify(policyRenewalBatchService).initiatePolicyRenewalReviewProcess();
        verifyCommonEnabled(PROCESS_INS_POLICY_TO_REVIEW, skipEnabledCheck, 3, true);
    }

    @Test
    public void test_runProcessToReviewPolicyJob_NotEnabled() {
        setupCommonDisabled(PROCESS_INS_POLICY_TO_REVIEW);
        testDisabled_runProcessToReviewPolicyJob();
    }

    @Test
    public void test_runProcessToReviewPolicyJob_NotWorkingDay() {
        setupCommonEnabled(PROCESS_INS_POLICY_TO_REVIEW, false);
        testDisabled_runProcessToReviewPolicyJob();
    }

    private void testDisabled_runProcessToReviewPolicyJob() {
        testObj.runProcessToReviewPolicyJob(false);
        verifyZeroInteractions(policyRenewalBatchService);
        verifyCommonDisabled(PROCESS_INS_POLICY_TO_REVIEW, true);
    }
    // END runSendRequestToInsuranceVendorJob tests

    // BEGIN runProcessWireRequestJob tests
    @Test
    public void test_runProcessWireRequestJob_SkipEnabledCheck() {
        test_runProcessWireRequestJob(true);
    }

    @Test
    public void test_runProcessWireRequestJob_Enabled() {
        test_runProcessWireRequestJob(false);
    }

    private void test_runProcessWireRequestJob(boolean skipEnabledCheck) {
        setupEnabled_runProcessWireRequestJob();
        testObj.runProcessWireRequestJob(skipEnabledCheck);
        verifyEnabled_runProcessWireRequestJob(skipEnabledCheck);
    }

    private void setupEnabled_runProcessWireRequestJob() {
        doNothing().when(floodRemapBatchService).processWiredPolicy();
        setupCommonEnabled(PROCESS_WIRE_REQUEST);
    }

    private void verifyEnabled_runProcessWireRequestJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).processWiredPolicy();
        verifyCommonEnabled(PROCESS_WIRE_REQUEST, skipEnabledCheck, 3);
    }

    @Test
    public void test_runProcessWireRequestJob_NotEnabled() {
        setupCommonDisabled(PROCESS_WIRE_REQUEST);
        testObj.runProcessWireRequestJob(false);
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(PROCESS_WIRE_REQUEST);
    }
    // END runProcessWireRequestJob tests

    // BEGIN createAggregateItemsForPropertyTasks tests
    @Test
    public void test_createAggregateItemsForPropertyTasks_SkipEnabledCheck() {
        test_createAggregateItemsForPropertyTasks(true);
    }

    @Test
    public void test_createAggregateItemsForPropertyTasks_Enabled() {
        test_createAggregateItemsForPropertyTasks(false);
    }

    private void test_createAggregateItemsForPropertyTasks(boolean skipEnabledCheck) {
        setupEnabled_createAggregateItemsForPropertyTasks();
        testObj.createAggregateItemsForPropertyTasks(skipEnabledCheck);
        verifyEnabled_createAggregateItemsForPropertyTasks(skipEnabledCheck);
    }

    private void setupEnabled_createAggregateItemsForPropertyTasks() {
        doNothing().when(floodRemapBatchService).processConfirmedWiredRequest();
        doNothing().when(floodRemapBatchService).processPendingSendLOBEmailForAlthans();
        setupCommonEnabled(PROCESS_CONFIRMED_WIRE_REQUEST);
    }

    private void verifyEnabled_createAggregateItemsForPropertyTasks(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).processConfirmedWiredRequest();
        verify(floodRemapBatchService).processPendingSendLOBEmailForAlthans();
        verifySchedulerService(PROCESS_CONFIRMED_WIRE_REQUEST, skipEnabledCheck);
    }

    @Test
    public void test_createAggregateItemsForPropertyTasks_NotEnabled() {
        setupCommonDisabled(PROCESS_CONFIRMED_WIRE_REQUEST);
        testObj.createAggregateItemsForPropertyTasks(false);
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(PROCESS_CONFIRMED_WIRE_REQUEST);
    }
    // END createAggregateItemsForPropertyTasks tests

    // BEGIN runProcessAlthansResponseFile tests
    @Test
    public void test_runProcessAlthansResponseFile_SkipEnabledCheck() {
        test_runProcessAlthansResponseFile(true);
    }

    @Test
    public void test_runProcessAlthansResponseFile_Enabled() {
        test_runProcessAlthansResponseFile(false);
    }

    private void test_runProcessAlthansResponseFile(boolean skipEnabledCheck) {
        setupEnabled_runProcessAlthansResponseFile();
        testObj.runProcessAlthansResponseFile(skipEnabledCheck);
        verifyEnabled_runProcessAlthansResponseFile(skipEnabledCheck);
    }

    private void setupEnabled_runProcessAlthansResponseFile() {
        doNothing().when(althansResponseDataExtract).processAlthansResponse();
        setupCommonEnabled(PROCESS_ALTHANS_RESPONSE_FILE);
    }

    private void verifyEnabled_runProcessAlthansResponseFile(boolean skipEnabledCheck) {
        verify(althansResponseDataExtract).processAlthansResponse();
        verifySchedulerService(PROCESS_ALTHANS_RESPONSE_FILE, skipEnabledCheck);
    }

    @Test
    public void test_runProcessAlthansResponseFile_NotEnabled() {
        setupCommonDisabled(PROCESS_ALTHANS_RESPONSE_FILE);
        testObj.runProcessAlthansResponseFile(false);
        verifyZeroInteractions(althansResponseDataExtract);
        verifyCommonDisabled(PROCESS_ALTHANS_RESPONSE_FILE);
    }
    // END runProcessAlthansResponseFile tests

    // BEGIN runProcessAlthansCertificateFile tests
    @Test
    public void test_runProcessAlthansCertificateFile_SkipEnabledCheck() {
        test_runProcessAlthansCertificateFile(true);
    }

    @Test
    public void test_runProcessAlthansCertificateFile_Enabled() {
        test_runProcessAlthansCertificateFile(false);
    }

    private void test_runProcessAlthansCertificateFile(boolean skipEnabledCheck) {
        setupEnabled_runProcessAlthansCertificateFile();
        testObj.runProcessAlthansCertificateFile(skipEnabledCheck);
        verifyEnabled_runProcessAlthansCertificateFile(skipEnabledCheck);
    }

    private void setupEnabled_runProcessAlthansCertificateFile() {
        doNothing().when(althansCertificateDataExtract).processAlthansCertificateFile();
        setupCommonEnabled(PROCESS_ALTHANS_CERTIFICATE_FILE);
    }

    private void verifyEnabled_runProcessAlthansCertificateFile(boolean skipEnabledCheck) {
        verify(althansCertificateDataExtract).processAlthansCertificateFile();
        verifySchedulerService(PROCESS_ALTHANS_CERTIFICATE_FILE, skipEnabledCheck);
    }

    @Test
    public void test_runProcessAlthansCertificateFile_NotEnabled() {
        setupCommonDisabled(PROCESS_ALTHANS_CERTIFICATE_FILE);
        testObj.runProcessAlthansCertificateFile(false);
        verifyZeroInteractions(althansCertificateDataExtract);
        verifyCommonDisabled(PROCESS_ALTHANS_CERTIFICATE_FILE);
    }
    // END runProcessAlthansCertificateFile tests

    // BEGIN runPostFullEodJob tests
    @Test
    public void test_runPostFullEodJob_SkipEnabledCheck() {
        test_runPostFullEodJob(true);
    }

    @Test
    public void test_runPostFullEodJob_Enabled() {
        test_runPostFullEodJob(false);
    }

    private void test_runPostFullEodJob(boolean skipEnabledCheck) {
        setupEnabled_runPostFullEodJob();
        testObj.runPostFullEodJob(skipEnabledCheck);
        verifyEnabled_runPostFullEodJob(skipEnabledCheck);
    }

    private void setupEnabled_runPostFullEodJob() {
        doNothing().when(floodRemapBatchService).reconcileCtracAndTM();
        setupCommonEnabled(POST_FULL_EOD_JOB);
    }

    private void verifyEnabled_runPostFullEodJob(boolean skipEnabledCheck) {
        verify(floodRemapBatchService).reconcileCtracAndTM();
        verifyCommonEnabled(POST_FULL_EOD_JOB, skipEnabledCheck, 3);
    }

    @Test
    public void test_runPostFullEodJob_NotEnabled() {
        setupCommonDisabled(POST_FULL_EOD_JOB);
        testObj.runPostFullEodJob(false);
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(POST_FULL_EOD_JOB);
    }
    // END runPostFullEodJob tests

    // BEGIN runProcessGDSImageJob tests
    @Test
    public void test_runProcessGDSImageJob_SkipEnabledCheck() {
        test_runProcessGDSImageJob(true);
    }

    @Test
    public void test_runProcessGDSImageJob_Enabled() {
        test_runProcessGDSImageJob(false);
    }

    private void test_runProcessGDSImageJob(boolean skipEnabledCheck) {
        setupEnabled_runProcessGDSImageJob();
        assertTrue(testObj.runProcessGDSImageJob(skipEnabledCheck));
        verifyEnabled_runProcessGDSImageJob(skipEnabledCheck);
    }

    private void setupEnabled_runProcessGDSImageJob() {
        when(processGDSImage.processLetterImages()).thenReturn(true);
        setupCommonEnabled(PROCESS_GDSIMAGE);
    }

    private void verifyEnabled_runProcessGDSImageJob(boolean skipEnabledCheck) {
        verify(processGDSImage).processLetterImages();
        verifyCommonEnabled(PROCESS_GDSIMAGE, skipEnabledCheck, 3);
    }

    @Test
    public void test_runProcessGDSImageJob_NotEnabled() {
        setupCommonDisabled(PROCESS_GDSIMAGE);
        assertFalse(testObj.runProcessGDSImageJob(false));
        verifyZeroInteractions(floodRemapBatchService);
        verifyCommonDisabled(PROCESS_GDSIMAGE);
    }
    // END runProcessGDSImageJob tests

    // BEGIN placeValidGDSLetterFile tests
    @Test
    public void test_placeValidGDSLetterFile() {
        doNothing().when(floodRemapBatchService).placeValidLetterFile();
        testObj.placeValidGDSLetterFile();
        verify(floodRemapBatchService).placeValidLetterFile();
        verify(floodRemapBatchService, times(0)).archiveInValidLetterFile();
    }

    @Test
    public void test_placeValidGDSLetterFile_WithException() {
        doThrow(NullPointerException.class).when(floodRemapBatchService).placeValidLetterFile();
        testObj.placeValidGDSLetterFile();
        verify(floodRemapBatchService).placeValidLetterFile();
        verify(floodRemapBatchService).archiveInValidLetterFile();
    }
    // END placeValidGDSLetterFile tests

    private static class TestScheduler extends AbstractScheduler {
        @Override
        protected String getSchedulerName() {
            return "Test Scheduler";
        }
    }
}
