package com.jpmorgan.cib.wlt.ctrac.batch.scheduler;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BankHolidays;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestSchedulerMngtService {

    @Mock
    private BatchCtrlRepository batchCtrlRepository;

    @Mock
    private CalendarDayUtil calendarDayUtil;

    @Mock
    private BatchCtrl batchCtrl;

    @Mock
    private BatchCtrl althansBatchCtrl;

    @InjectMocks
    @Spy
    SchedulerMngtService schedulerMngtService;

    private List<BatchCtrl> batchList;

    private List<BatchCtrl> althansBatchList;

    private List<BankHolidays> holidayList;

    @Mock
    private BankHolidays holiday;

    @Mock
    private Calendar mockUpCal;

    @Before
    public void setup() {
        when(batchCtrl.getSchedulerHost()).thenReturn(currentIp());
        holidayList = new ArrayList<BankHolidays>(1);
        holidayList.add(holiday);
        batchList = new ArrayList<BatchCtrl>(1);
        batchList.add(batchCtrl);

        althansBatchList = new ArrayList<BatchCtrl>(1);
        althansBatchList.add(althansBatchCtrl);
    }

    @Test
    public void test_workingDayJobs() {
        getWorkingDayJobs().forEach(job -> testIsJobEnabled(job, true, true));
    }

    @Test
    public void test_workingDayJobs_Weekend() {
        getWorkingDayJobs().forEach(job -> testIsJobEnabled(job, false, false));
    }

    @Test
    public void test_nonWorkingDayJobs() {
        getNonWorkingDayJobs().forEach(job -> testIsJobEnabled(job, true, true));
    }

    @Test
    public void test_nonWorkingDayJobs_Weekend() {
        getNonWorkingDayJobs().forEach(job -> testIsJobEnabled(job, false, true));
    }

    private void testIsJobEnabled(SchedulerJob job, boolean isWorkingDay, boolean isJobEnabled) {
        int[] timeArray = {00, 00, 00};
        when(batchCtrlRepository.findByBatchTypeAndCtrlFlag(job.getName(), CtracAppConstants.ENABLED_FLAG)).thenReturn(batchList);
        when(calendarDayUtil.populateTodayCalendar(timeArray)).thenReturn(mockUpCal);
        when(calendarDayUtil.isWorkingDay()).thenReturn(isWorkingDay);
        schedulerMngtService.setSchedulerStatus("ON");

        assertEquals(isJobEnabled, schedulerMngtService.isJobEnabled(job));
    }

    @Test
    public void testIsJobEnabled_SchedulerOff() {
        schedulerMngtService.setSchedulerStatus(null);
        assertFalse(schedulerMngtService.isJobEnabled(STATE_AND_SLA_JOB));
    }

    @Test
    public void testIsJobEnabled_NoBatch() {
        when(batchCtrlRepository.findByBatchTypeAndCtrlFlag(STATE_AND_SLA_JOB.getName(), CtracAppConstants.ENABLED_FLAG)).thenReturn(null);
        schedulerMngtService.setSchedulerStatus("ON");
        verifyZeroInteractions(calendarDayUtil);
        assertFalse(schedulerMngtService.isJobEnabled(STATE_AND_SLA_JOB));
    }

    @Test
    public void testIsJobEnabled_NoIPMatch() {
        when(batchCtrlRepository.findByBatchTypeAndCtrlFlag(STATE_AND_SLA_JOB.getName(), CtracAppConstants.ENABLED_FLAG)).thenReturn(batchList);
        schedulerMngtService.setSchedulerStatus("ON");
        when(batchCtrl.getSchedulerHost()).thenReturn(null);
        verifyZeroInteractions(calendarDayUtil);
        assertFalse(schedulerMngtService.isJobEnabled(STATE_AND_SLA_JOB));
    }

    @Test
    public void testHasSuccessfullyRunThisWeek_true() {
        when(batchCtrlRepository.findByBatchType(SEND_LP_REQUEST_ALTHANS.getName())).thenReturn(batchList);

        Date date = new GregorianCalendar(2018, 11, 5, 12, 0).getTime();
        when(batchCtrl.getLastSuccessfulCompleteDate()).thenReturn(date);
        when(calendarDayUtil.getCurrentReferenceDate()).thenReturn(date);
        assertTrue(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS));

        date = new GregorianCalendar(2018, 11, 6, 12, 0).getTime();
        when(batchCtrl.getLastSuccessfulCompleteDate()).thenReturn(date);
        when(calendarDayUtil.getCurrentReferenceDate()).thenReturn(date);
        verify(calendarDayUtil, times(1)).getCurrentReferenceDate();
        assertTrue(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS));
    }

    @Test
    public void testHasSuccessfullyRunThisWeek_NoBatch() {
        when(batchCtrlRepository.findByBatchType(SEND_LP_REQUEST_ALTHANS.getName())).thenReturn(null);
        verifyZeroInteractions(calendarDayUtil);
        assertFalse(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS));
    }

    @Test
    public void testHasSuccessfullyRunThisWeek_NoLastRun() {
        when(batchCtrlRepository.findByBatchType(SEND_LP_REQUEST_ALTHANS.getName())).thenReturn(batchList);
        when(batchCtrl.getLastSuccessfulCompleteDate()).thenReturn(null);
        verifyZeroInteractions(calendarDayUtil);
        assertFalse(schedulerMngtService.hasSuccessfullyRunThisWeek(SEND_LP_REQUEST_ALTHANS));
    }

    @Test
    public void testGetTodayJobScheduledTimeCountDownInMiliSec() {
        assertNull(schedulerMngtService.getTodayJobScheduledTimeCountDownInMiliSec(FULL_EOD_JOB, true));
    }

    private String currentIp() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
        }
        return null;
    }

    private List<SchedulerJob> getWorkingDayJobs() {
        return Arrays.asList(STATE_AND_SLA_JOB,
                FULL_EOD_JOB,
                EOD_C3_JOB,
                PROCESS_ALTHANS_RESPONSE_FILE,
                PROCESS_WIRE_REQUEST);
    }

    private List<SchedulerJob> getNonWorkingDayJobs() {
        return Arrays.asList(UPDATE_REFERENCE_DATE,
                PROCESS_GDSIMAGE,
                LAST_RECEIVED_REMAP_NOTIFY,
                PROCESS_INS_POLICY_TO_REVIEW,
                USER_INACTIVITY_JOB);
    }
}
