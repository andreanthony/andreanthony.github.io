package com.jpmorgan.cib.wlt.ctrac.batch.scheduler;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.NEW_TASK_JOB;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.STATE_AND_SLA_JOB;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jpmorgan.cib.wlt.ctrac.batch.config.BaseBatchConfig;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BankHolidaysRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;






/**
 * This is more of and integration testing rather than unit testing
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { BaseBatchConfig.class })
public class SchedulerMngtServiceIT {
	
	
    //TODO remove after debug
//	static{
//		System.setProperty("spring.profiles.active","local");
//	}
	
	@Autowired
	private BankHolidaysRepository bankHolidaysRepository;
	
	@Autowired
	private BatchCtrlRepository  batchCtrlRepository;
	
	
	@Autowired
	@InjectMocks
	SchedulerMngtService schedulerMngtService;
	
	@Ignore
	@Test
	public  void testIsJobEnabled(){
		
		boolean rep =  schedulerMngtService.isJobEnabled(STATE_AND_SLA_JOB ) ;
		assertFalse(rep);
		
		rep =  schedulerMngtService.isJobEnabled(NEW_TASK_JOB) ;		
		assertTrue(rep);
	}
	
}
