package com.jpmorgan.cib.wlt.ctrac.batch.scheduler;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.FULL_EOD_JOB;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.EOD_C3_JOB;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.PROCESS_WIRE_REQUEST;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.STATE_AND_SLA_JOB;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.PROCESS_ALTHANS_RESPONSE_FILE;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.springframework.stereotype.Component;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BankHolidaysRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;


@Component
public class SchedulerMngtService {

	private static final Logger logger = Logger.getLogger(SchedulerMngtService.class);

	@Resource private BankHolidaysRepository bankHolidaysRepository;
	@Resource private BatchCtrlRepository batchCtrlRepository;
	@Resource private CalendarDayUtil calendarUtil;

	private String schedulerStatus = System.getProperty("scheduler.status");

	//@Value("${cron.eod.expression}") private String endOfTheDayExpression;
	private String endOfTheDayExpression;

	/**
	 * This method is called to determine if a given task is enabled on the DB
	 * and can run on the current day. In particular, the system scheduler use
	 * this method to decide whether or not a job can run. The on-demand
	 * scheduler is not supposed to call this method.
	 * 
	 * @return true if the job is enabled on the DB and the current day is a
	 *         business day., false otherwise.
	 * */
	public boolean isJobEnabled(SchedulerJob job) {
		// scheduler host is identified by a system property named 'scheduler.status'
		if (!"ON".equalsIgnoreCase(schedulerStatus)) {
			logger.info("\n  scheduler Job not enabled on this host. system property 'scheduler.status' not set ");
			return false;
		}
		return isJobEnabled(job, false);

	}
	
	public boolean hasSuccessfullyRunThisWeek(SchedulerJob job) {
		BatchCtrl batchCtrl = getBatchCtrlBySchedulerJob(job);
		if (batchCtrl == null) {
			return false;
		}
		Date lastSuccessfulRunDate = batchCtrl.getLastSuccessfulCompleteDate();
		if (lastSuccessfulRunDate == null) {
			return false;
		}
		
		DateTime lastRunDateTime = new DateTime(lastSuccessfulRunDate);
		DateTime testDate = new DateTime(calendarUtil.getCurrentReferenceDate()).withTimeAtStartOfDay();
		while (testDate.getDayOfWeek() != DateTimeConstants.MONDAY) {
			testDate = testDate.minusDays(1);
		}
		return lastRunDateTime.isAfter(testDate);
	}

	/**
	 * This method is called to determine if a given task is enabled on the DB.
	 * 
	 * The system scheduler and the on-demand scheduler is not supposed to call
	 * this method directly.
	 * 
	 * @return true if the job is enabled on the DB and the current day is a
	 *         business day.
	 * */
	public boolean isJobEnabled(SchedulerJob job, boolean skipIPCheck) {

		BatchCtrl batchCtrl = getEnabledBatchCtrl(job);
		if (batchCtrl == null) {
			return false;
		}

		boolean ipTestSucess = (skipIPCheck || getHostAddress().equalsIgnoreCase(batchCtrl.getSchedulerHost()));

		if (ipTestSucess) {
			if (STATE_AND_SLA_JOB.getName().equals(job.getName()) ||
					FULL_EOD_JOB.getName().equals(job.getName()) ||
					EOD_C3_JOB.getName().equals(job.getName()) ||
					PROCESS_ALTHANS_RESPONSE_FILE.getName().equals(job.getName()) ||
					PROCESS_WIRE_REQUEST.getName().equals(job.getName())) {
				if (!calendarUtil.isWorkingDay()) {
					return false;
				}
			}
			return true;
		}

		return false;
	}

	private BatchCtrl getEnabledBatchCtrl(SchedulerJob job) {
		List<BatchCtrl> batchCtrlList = batchCtrlRepository.findByBatchTypeAndCtrlFlag(job.getName(), CtracAppConstants.ENABLED_FLAG);
		if (batchCtrlList == null || batchCtrlList.size() != 1) {
			return null;
		}
		return batchCtrlList.get(0);
	}
	
	private BatchCtrl getBatchCtrlBySchedulerJob(SchedulerJob job) {
		List<BatchCtrl> batchCtrlList = batchCtrlRepository.findByBatchType(job.getName());
		if (batchCtrlList == null || batchCtrlList.size() != 1) {
			return null;
		}
		return batchCtrlList.get(0);
	}

	/**
	 * 
	 * */

	public String getHostAddress() {

		InetAddress ip;
		try {
			ip = InetAddress.getLocalHost();
			logger.info("Current host IP address : " + ip.getHostAddress());
			return ip.getHostAddress();
		} catch (UnknownHostException e) {
			logger.error("Error while getting Host address",e);
		}
		return "unknown";

	}

	/**
	 * Read the scheduler Cron expression to determine if the job @jobName is
	 * scheduled to run today Read the DB to see if the job is activated today,
	 * no IP check is performed.
	 * 
	 * @return Calendar retCal holding the time the job must run (
	 *         retCal.get(Calendar
	 *         .HOUR_OF_DAY);retCal.get(Calendar.MINUTE);retCal
	 *         .get(Calendar.SECOND));
	 * @return NULL if the Job is not scheduled to run today or if the task had
	 *         already ran
	 * */

	public Calendar getTodayJobScheduledTime(SchedulerJob job, boolean skipEnableCheck) {

		boolean isJobEnabled = skipEnableCheck || isJobEnabled(job, true);

		// Is the job disabled today? (holiday/weekend?)
		if (!isJobEnabled) {
			return null;
		}

		Calendar timeToRun = null;

		// We are assuming that the cron expression in the property file will be
		// of the form ss mm hh ? *
		// If the parsing of the cron expression fail, hard code the time to
		// what ever default value the PO team decide

		// TODO can we improve the choice of the default time in case of
		// irregular cron expression ?

		if (FULL_EOD_JOB.getName().equals(job.getName())) {
			timeToRun = parseCronExpression(endOfTheDayExpression, null);
		}
		
		if (timeToRun != null && calendarUtil.getCurrentReferenceDate().after(timeToRun.getTime())) {
			timeToRun = null;
		}

		return timeToRun;
	}

	/**
	 * Read the scheduler Cron expression to determine if the job @jobName is
	 * scheduled to run today Read the DB to see if the job is activated today,
	 * no IP check is performed.
	 * 
	 * @return the number of millisecond before the job run;
	 * @return NULL if the Job is not scheduled to run today or if the task had
	 *         already ran
	 * */
	public Long getTodayJobScheduledTimeCountDownInMiliSec(SchedulerJob job, boolean skipEnabledCheck) {
		Calendar timeToRun = getTodayJobScheduledTime(job, skipEnabledCheck);
		if (timeToRun == null) {
			return null;
		}
		Calendar tmpCal = Calendar.getInstance();
		tmpCal.setTime(calendarUtil.getCurrentReferenceDate());
		return timeToRun.getTimeInMillis() - tmpCal.getTimeInMillis();
	}
		

	/**
	 * pase a cron expression passed as input and return a calendar set to time
	 * in the cron if it matches ss mm hh or default time int the time array
	 * 
	 * @param cronExpr
	 *            cron expression representing the time;
	 * @param defaultTimeArray
	 *            default time array int the format [ss, mm,hh]
	 * @return a calendar holding the time passed in the cron expression if the
	 *         cron expression is on the form ss mm hh * otherwise set to the
	 *         default time the default time array.
	 */
	private Calendar parseCronExpression(String cronExpr, int[] defaultTimeArray) {
		Calendar ret = null;

		if (!StringUtils.isBlank(cronExpr)) {

			try {
				String[] tempTime = cronExpr.trim().replaceAll(" +", " ").split(" ");
				ret = calendarUtil.populateTodayCalendar(tempTime);
			} catch (Exception invalidCron) {
				logger.warn("A ttempt to parse and unsupported cron expression: " + cronExpr);

				if (defaultTimeArray != null && defaultTimeArray.length > 2) {
					ret = calendarUtil.populateTodayCalendar(defaultTimeArray);
				} else {
					ret = null;
				}

			}
		}
		return ret;
	}

	// Used for testing purpose only
	/* private */void setSchedulerStatus(String status) {
		schedulerStatus = status;
	}

}
