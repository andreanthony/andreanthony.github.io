package com.jpmorgan.cib.wlt.ctrac.batch.scheduler;

import org.springframework.stereotype.Service;

@Service(value = "taskOnDemandScheduler")
public class TaskOnDemandScheduler extends AbstractScheduler {

	@Override
	public void runRSAMWeeklyCertification(boolean skipEnabilityAndIPCheck) {
		super.runRSAMWeeklyCertification(true);
	}

	@Override
	public void runUserInactivityJob(boolean skipEnabilityAndIPCheck) {
		super.runUserInactivityJob(true);
	}

	@Override
	public void runSendRequestToInsuranceVendorJob(boolean skipEnabilityAndIPCheck) {
		super.runSendRequestToInsuranceVendorJob(true);
	}

	@Override
	public void runSendRequestToInsuranceVendorAlthansJob(boolean skipEnabilityAndIPCheck) {
		super.runSendRequestToInsuranceVendorAlthansJob(true);
	}

	@Override
	public void runEndOfTheDayJob(boolean skipEnabilityAndIPCheck) {
		super.runEndOfTheDayJob(true);
	}

	@Override
	public void runEndOfTheDayC3Job(boolean skipEnabilityAndIPCheck) {
		super.runEndOfTheDayC3Job(true);
	}

	@Override
	public void runNewTaskCreationJob(boolean skipEnabilityAndIPCheck) {
		super.runNewTaskCreationJob(true);
	}

	@Override
	public void runSendLPPremiumEMail(boolean skipEnabilityAndIPCheck) {
		super.runSendLPPremiumEMail(true);
	}

	@Override
	public void runServiceLinkJob(boolean skipEnabilityAndIPCheck) {
		super.runServiceLinkJob(true);
	}

	@Override
	public void runCoreLogicDataJob(boolean skipEnabilityAndIPCheck) {
		super.runCoreLogicDataJob(true);
	}

	@Override
	public boolean runProcessGDSImageJob(boolean skipEnabilityAndIPCheck) {
        return super.runProcessGDSImageJob(true);
	}

	@Override
	public void runStatesAndSLAUpdateEndOfTheDayJob(boolean skipEnabilityAndIPCheck) {
		super.runStatesAndSLAUpdateEndOfTheDayJob(true);
	}

	@Override
	public void runUpdateReferenceDateJob(boolean skipEnabilityAndIPCheck) {
		super.runUpdateReferenceDateJob(true);
	}

	@Override
	public void runProcessToReviewPolicyJob(boolean skipEnabilityAndIPCheck) {
		super.runProcessToReviewPolicyJob(true);
	}

	@Override
	public void runProcessWireRequestJob(boolean skipEnabilityAndIPCheck) {
		super.runProcessWireRequestJob(true);
	}

	@Override
	public void runJanusCtracEntitlementSync(boolean skipEnabilityAndIPCheck) {
		super.runJanusCtracEntitlementSync(true);
	}

	@Override
	public void runPostFullEodJob(boolean skipEnabilityAndIPCheck) {
		super.runPostFullEodJob(true);
	}

	@Override
	public void runProcessAlthansResponseFile(boolean skipEnabilityAndIPCheck) {
		super.runProcessAlthansResponseFile(true);
	}

	@Override
	public void runProcessAlthansCertificateFile(boolean skipEnabilityAndIPCheck) {
		super.runProcessAlthansCertificateFile(true);
	}

	@Override
	public void runSendCoverageGapReportEmail(boolean skipEnabilityAndIPCheck) {
		super.runSendCoverageGapReportEmail(true);
	}

	@Override
	protected String getSchedulerName(){
		return "Task On-Demand";
	}
}
