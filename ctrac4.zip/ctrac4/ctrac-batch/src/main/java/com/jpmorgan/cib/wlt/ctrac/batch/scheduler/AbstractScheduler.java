package com.jpmorgan.cib.wlt.ctrac.batch.scheduler;


import com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.CoreLogicFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.ServiceLinkFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;
import com.jpmorgan.cib.wlt.ctrac.service.batch.*;
import com.jpmorgan.cib.wlt.ctrac.service.datamover.DataMoverAdaptor;
import com.jpmorgan.cib.wlt.ctrac.service.dateCalculator.CalendarDayUtil;
import com.jpmorgan.cib.wlt.ctrac.service.email.EmailNotificationService;
import com.jpmorgan.cib.wlt.ctrac.service.entitlements.UserEntitlementService;
import com.jpmorgan.cib.wlt.ctrac.service.insurance.LenderPlaceService;
import com.jpmorgan.cib.wlt.ctrac.service.statemachine.WorkflowStateDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.StopWatch;

import java.util.List;
import java.util.Set;

import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.*;
import static com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracAppConstants.*;

public abstract class AbstractScheduler {

    private static final Logger logger = LoggerFactory.getLogger(AbstractScheduler.class);

    @Autowired
    private BatchCtrlRepository batchCtrlRepository;
    @Autowired
    private CalendarDayUtil calendarDayUtil;
    @Autowired
    private FloodRemapBatchService floodRemapBatchService;
    @Autowired
    private InsurancePolicyBatchService insurancePolicyBatchService;
    @Autowired
    private LenderPlaceService lenderPlaceService;
    @Autowired
    private LPRequestToVendorService lpRequestToVendorService;
    @Autowired
    private SchedulerMngtService schedulerMngtService;
    @Autowired
    private UserEntitlementService userEntitlementService;
    @Autowired
    private EmailNotificationService emailNotificationService;

    @Qualifier("coreLogicDataExtract")
    @Autowired
    private FloodRemapDataExtract coreLogicDataExtract;

    @Qualifier("coreLogicDataMoverAdapter")
    @Autowired
    private DataMoverAdaptor<CoreLogicFloodRemap, FloodRemap> coreLogicDataMoverAdapter;

    @Qualifier("serviceLinkDataExtract")
    @Autowired
    private FloodRemapDataExtract serviceLinkDataExtract;

    @Qualifier("althansResponseDataExtract")
    @Autowired
    private FloodRemapDataExtract althansResponseDataExtract;

    @Qualifier("althansCertificateDataExtract")
    @Autowired
    private FloodRemapDataExtract althansCertificateDataExtract;

    @Qualifier("policyRenewalBatchService")
    @Autowired
    private PolicyRenewalBatchService policyRenewalBatchService;

    @Qualifier("processGDSImage")
    @Autowired
    private ProcessGDSImage processGDSImage;

    @Qualifier("serviceLinkDataMoverAdapter")
    @Autowired
    private DataMoverAdaptor<ServiceLinkFloodRemap, FloodRemap> serviceLinkDataMoverAdapter;

    public void runRSAMWeeklyCertification(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = RSAM_WEEKLY_CERTIFICATION_JOB;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            userEntitlementService.processWeeklyCertification();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runUserInactivityJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = USER_INACTIVITY_JOB;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            userEntitlementService.performUserInactivityActions();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runJanusCtracEntitlementSync(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = SYNC_JANUS_CTRAC_ENTITLEMENTS_JOB;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            List<Users> janusUserList = userEntitlementService.getJanusUserList();
            List<Users> ctracUserList = userEntitlementService.getCTRACUserList();
            userEntitlementService.performSyncOfUsersBetweenJanusAndCtrac(janusUserList, ctracUserList);
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    /**
     * Method to process CoreLogic files and create Flood Remap Records
     * in CTrac database.
     * Once the CoreLogic input files are processed,input files will be archived.
     *
     * @param skipEnabilityAndIPCheck
     */
    public void runServiceLinkJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = SERVICE_lINK_DATA_EXTRACT;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            serviceLinkDataExtract.processRemapFiles();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    /**
     * Method to process CoreLogic files and create Flood Remap Records
     * in CTrac database.
     * Once the CoreLogic input files are processed,input files will be archived.
     *
     * @param skipEnabilityAndIPCheck
     */
    public void runCoreLogicDataJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = CORELOGIC_DATA_EXTRACT;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            coreLogicDataExtract.processRemapFiles();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runCheckRemapFileLastUpdateJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = LAST_RECEIVED_REMAP_NOTIFY;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            floodRemapBatchService.checkSLLastRemapFileReceivedDateAndNotify();
            floodRemapBatchService.checkCLLastRemapFileReceivedDateAndNotify();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runEndOfTheDayJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = FULL_EOD_JOB;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            runStatesAndSLAUpdateEndOfTheDayJob(true);
            createAggregateItemsForPropertyTasks(true);
            runSendLPPremiumEMail(true);
            runNewTaskCreationJobSL(true);
            runNewTaskCreationJobCL(true);
            runNewTaskCreationJob(true);
            placeValidGDSLetterFile();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
            floodRemapBatchService.archiveInValidLetterFile();
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runSendCoverageGapReportEmail(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = COVERAGE_GAP_REPORT_EMAIL;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            emailNotificationService.sendCoverageGapReportEmail();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runEndOfTheDayC3Job(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = EOD_C3_JOB;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            runInsurancePolicyC3Jobs(true);
            emailNotificationService.sendLettersReviewEmail();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runInsurancePolicyC3Jobs(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = INSURANCE_POLICY_C3;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            Set<Long> collateralsProcessed = insurancePolicyBatchService.processExpiringPolicies();
            insurancePolicyBatchService.processNewlyEffectivePolicies(collateralsProcessed);
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        }
    }

    public void runStatesAndSLAUpdateEndOfTheDayJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = STATE_AND_SLA_JOB;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            floodRemapBatchService.calculateSLAandMoveTaskToNextWFStep();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
            floodRemapBatchService.archiveInValidLetterFile();
        }
    }

    public void runNewTaskCreationJobSL(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = NEW_TASK_JOB_SL;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            serviceLinkDataMoverAdapter.runDataMover();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        }
    }

    public void runNewTaskCreationJobCL(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = NEW_TASK_JOB_CL;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            coreLogicDataMoverAdapter.runDataMover();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        }
    }

    public void runNewTaskCreationJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = NEW_TASK_JOB;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            floodRemapBatchService.createNewFloodRemapTasks();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        }
    }

    public void runSendLPPremiumEMail(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = SEND_LP_PREMIUM_EMAIL;
        try {
            StopWatch watch = logJobStart(job);
            lenderPlaceService.processLpPremiumPaidLOBEmail();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        }
    }

    public void runSendRequestToInsuranceVendorJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = SEND_LP_REQUEST;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job, calendarDayUtil.isWorkingDay())) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(SEND_LP_REQUEST);
            lpRequestToVendorService.sendRequestToInsuranceVendor();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
            throw e;
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }

    }

    public void runSendRequestToInsuranceVendorAlthansJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = SEND_LP_REQUEST_ALTHANS;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job, calendarDayUtil.isWorkingDay())) {
            return;
        }
        if (schedulerMngtService.hasSuccessfullyRunThisWeek(job)) {
            logger.debug("\n task already ran this week: {}", job);
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            floodRemapBatchService.completeEODBatchOperationsByWFStep(WorkflowStateDefinition.PENDING_FOR_ALTHANS);
            lpRequestToVendorService.sendRequestToInsuranceVendorAlthans();
            setLastSuccessfulCompleteDate(job);
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
            throw e;
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }

    }

    public void runUpdateReferenceDateJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = UPDATE_REFERENCE_DATE;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            floodRemapBatchService.updateReferenceDate();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runProcessToReviewPolicyJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = PROCESS_INS_POLICY_TO_REVIEW;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job, calendarDayUtil.isWorkingDay())) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            policyRenewalBatchService.initiatePolicyRenewalReviewProcess();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void runProcessWireRequestJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = PROCESS_WIRE_REQUEST;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            floodRemapBatchService.processWiredPolicy();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    public void createAggregateItemsForPropertyTasks(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = PROCESS_CONFIRMED_WIRE_REQUEST;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            floodRemapBatchService.processConfirmedWiredRequest();
            floodRemapBatchService.processPendingSendLOBEmailForAlthans();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        }
    }

    public void runProcessAlthansResponseFile(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = PROCESS_ALTHANS_RESPONSE_FILE;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            althansResponseDataExtract.processAlthansResponse();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        }
    }

    public void runProcessAlthansCertificateFile(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = PROCESS_ALTHANS_CERTIFICATE_FILE;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            althansCertificateDataExtract.processAlthansCertificateFile();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        }
    }

    public void runPostFullEodJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = POST_FULL_EOD_JOB;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            floodRemapBatchService.reconcileCtracAndTM();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
    }

    /**
     * Method to process CoreLogic files and create Flood Remap Records
     * in CTrac database.
     * Once the CoreLogic input files are processed,input files will be archived.
     *
     * @param skipEnabilityAndIPCheck
     */
    public boolean runProcessGDSImageJob(boolean skipEnabilityAndIPCheck) {
        SchedulerJob job = PROCESS_GDSIMAGE;
        boolean status = false;
        if (checkJobNotEnabled(skipEnabilityAndIPCheck, job)) {
            return skipEnabilityAndIPCheck;
        }
        try {
            StopWatch watch = logJobStart(job);
            turnOnRunningFlag(job);
            status = processGDSImage.processLetterImages();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
        } finally {
            turnOffRunningFlag(job);
            setLastRunDate(job);
        }
        return status;
    }

    public void placeValidGDSLetterFile() {
        SchedulerJob job = PLACE_VALID_GDS_XML;
        try {
            StopWatch watch = logJobStart(job);
            floodRemapBatchService.placeValidLetterFile();
            logJobStop(job, watch);
        } catch (Exception e) {
            logJobException(ERR_SEVERITY_CRITICAL_MESSAGE, job, e);
            floodRemapBatchService.archiveInValidLetterFile();
        }
    }

    protected BatchCtrl getBatchCtrl(SchedulerJob schedulerJob) {
        List<BatchCtrl> batchCtrlList = batchCtrlRepository.findByBatchType(schedulerJob.getName());
        if (batchCtrlList == null || batchCtrlList.isEmpty()) {
            logger.error("cannot find batch ctrl for {}", schedulerJob);
            return null;
        }
        return batchCtrlList.get(0);
    }

    protected void turnOnRunningFlag(SchedulerJob schedulerJob) {
        logger.debug("turning {} batch ctrl running flag on", schedulerJob);
        setRunningFlag(DB_FLAG_YES, schedulerJob);
    }

    protected void turnOffRunningFlag(SchedulerJob schedulerJob) {
        logger.debug("turning {} batch ctrl running flag off", schedulerJob);
        setRunningFlag(DB_FLAG_NO, schedulerJob);
    }

    private void setRunningFlag(Character flag, SchedulerJob schedulerJob) {
        BatchCtrl batch = getBatchCtrl(schedulerJob);
        if (batch == null) {
            logger.error("cannot find batch ctrl for {}", schedulerJob);
            return;
        }
        batch.setRunning(flag);
        batchCtrlRepository.save(batch);
    }

    private void setLastRunDate(SchedulerJob schedulerJob) {
        BatchCtrl batchCtrl = getBatchCtrl(schedulerJob);
        batchCtrl.setLastRunDate(calendarDayUtil.getCurrentReferenceDate());
        batchCtrlRepository.save(batchCtrl);
    }

    private void setLastSuccessfulCompleteDate(SchedulerJob schedulerJob) {
        BatchCtrl batchCtrl = getBatchCtrl(schedulerJob);
        batchCtrl.setLastSuccessfulCompleteDate(calendarDayUtil.getCurrentReferenceDate());
        batchCtrlRepository.save(batchCtrl);
    }

    protected abstract String getSchedulerName();

    protected boolean checkJobNotEnabled(boolean skipEnabledAndIPCheck, SchedulerJob job) {
        return checkJobNotEnabled(skipEnabledAndIPCheck, job, true);
    }

    protected boolean checkJobNotEnabled(boolean skipEnabledAndIPCheck, SchedulerJob job, boolean isWorkingDay) {
        boolean jobNotEnabled = !(skipEnabledAndIPCheck || (schedulerMngtService.isJobEnabled(job) && isWorkingDay));
        if (jobNotEnabled) {
            logger.info("{} {} is not enabled", getSchedulerName(), job);
        }
        return jobNotEnabled;
    }

    protected StopWatch logJobStart(SchedulerJob job) {
        StopWatch watch = new StopWatch();
        watch.start();
        logger.info("{} starting {}", getSchedulerName(), job);
        return watch;
    }

    protected void logJobStop(SchedulerJob job, StopWatch watch) {
        watch.stop();
        logger.info("{} finished {} - execution time: {} seconds", getSchedulerName(), job, watch.getTotalTimeSeconds());
    }

    protected void logJobException(String severity, SchedulerJob job, Exception e) {
        logger.error("{}{} {} completed with exception", severity, getSchedulerName(), job);
        logger.error(e.getMessage(), e);
    }
}
