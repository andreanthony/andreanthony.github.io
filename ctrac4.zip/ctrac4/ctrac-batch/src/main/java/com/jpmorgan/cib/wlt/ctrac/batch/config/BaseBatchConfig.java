package com.jpmorgan.cib.wlt.ctrac.batch.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;

import com.jpmorgan.cib.wlt.ctrac.service.config.BaseServiceConfig;


@Configuration
@ComponentScan(basePackages = "com.jpmorgan.cib.wlt.ctrac.batch", excludeFilters = {@ComponentScan.Filter(Configuration.class) })
@Import({BaseServiceConfig.class})
@EnableAspectJAutoProxy
public class BaseBatchConfig {

	
}
