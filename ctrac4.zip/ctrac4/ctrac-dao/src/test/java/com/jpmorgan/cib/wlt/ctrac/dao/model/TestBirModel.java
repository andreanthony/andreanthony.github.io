package com.jpmorgan.cib.wlt.ctrac.dao.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRCollateralDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRInsurableAssetDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRRuleConclusion;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BorrowerInsuranceReviewDetails;


@RunWith(MockitoJUnitRunner.class)
public class TestBirModel {

	@Test
	public void testBIRCollateralDetails() {
		GetterSetterHelper.testClass(BIRCollateralDetails.class);
	}
	@Test
	public void testBIRInsurableAssetDetails() {
		GetterSetterHelper.testClass(BIRInsurableAssetDetails.class);
	}
	@Test
	public void testBIRRuleConclusion() {
		GetterSetterHelper.testClass(BIRRuleConclusion.class);
	}
	@Test
	public void testBIRViewData() {
		GetterSetterHelper.testClass(BIRViewData.class);
	}
	@Test
	public void testBorrowerInsuranceReviewDetails() {
		GetterSetterHelper.testClass(BorrowerInsuranceReviewDetails.class);
	}
	//model base ends
}
