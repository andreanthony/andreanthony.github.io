package com.jpmorgan.cib.wlt.ctrac.dao.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AccountWireReference;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AgentResponseItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AggregateItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralWorkItemPk;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ContactAgent;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PreLenderPlaceDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItemPk;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.Renewal;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WiredPolicy;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItemRelation;

@RunWith(MockitoJUnitRunner.class)
public class TestWorkflowModel {
	@Test
	public void testAccountWireReference() {
		GetterSetterHelper.testClass(AccountWireReference.class);
	}

	@Test
	public void testAgentResponseItem() {
		GetterSetterHelper.testClass(AgentResponseItem.class);
	}

	@Test
	public void testAggregateItem() {
		GetterSetterHelper.testClass(AggregateItem.class);
	}

	@Test
	public void testCollateralItem() {
		GetterSetterHelper.testClass(CollateralItem.class);
	}

	@Test
	public void testCollateralWorkItem() {
		GetterSetterHelper.testClass(CollateralWorkItem.class);
	}

	@Test
	public void testCollateralWorkItemPk() {
		GetterSetterHelper.testClass(CollateralWorkItemPk.class);
	}

	@Test
	public void testContactAgent() {
		GetterSetterHelper.testClass(ContactAgent.class);
	}

	@Test
	public void testFloodRemapItem() {
		GetterSetterHelper.testClass(FloodRemapItem.class);
	}

	@Test
	public void testLenderPlaceItem() {
		GetterSetterHelper.testClass(LenderPlaceItem.class);
	}

	@Test
	public void testPerfectionTask() {
		GetterSetterHelper.testClass(PerfectionTask.class);
	}

	@Test
	public void testPreLenderPlaceDetails() {
		GetterSetterHelper.testClass(PreLenderPlaceDetails.class);
	}

	@Test
	public void testProofOfCovWorkItem() {
		GetterSetterHelper.testClass(ProofOfCovWorkItem.class);
	}

	@Test
	public void testProofOfCovWorkItemPk() {
		GetterSetterHelper.testClass(ProofOfCovWorkItemPk.class);
	}

	@Test
	public void testRenewal() {
		GetterSetterHelper.testClass(Renewal.class);
	}

	@Test
	public void testWiredPolicy() {
		GetterSetterHelper.testClass(WiredPolicy.class);
	}

	@Test
	public void testWorkItem() {
		GetterSetterHelper.testClass(WorkItem.class);
	}

	@Test
	public void testWorkItemRelation() {
		GetterSetterHelper.testClass(WorkItemRelation.class);
	}

}
