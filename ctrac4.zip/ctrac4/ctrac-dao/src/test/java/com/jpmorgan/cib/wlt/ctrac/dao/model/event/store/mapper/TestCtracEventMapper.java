package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CtracEvent;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventDTO;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestCtracEventMapper {

    private static final String EVENT_TYPE = "COLLATERAL_CREATED";
    private static final DateTime EVENT_TIME = new DateTime().
            withDate(2017, 12, 26).
            withTime(16, 40, 5, 20);
    private static final String EVENT_ATTRIBUTES = "{ EVENT_ATTRIBUTES }";
    private static final String PERFORMED_BY = "PERFORMED_BY";

    private CtracEventMapper testObj;

    private CtracEvent event;
    private CtracEventDTO eventDTO;

    @Before
    public void setUp() throws JsonProcessingException {
        testObj = new CtracEventMapper();
        mockEvent();
        mockEventDTO();
    }

    @Test
    public void testEventToEventDTO() {
        CtracEventDTO actual = testObj.map(event, CtracEventDTO.class);
        assertEquals(EVENT_TIME.toDate(), actual.getEventTime());
        assertEquals(EVENT_TYPE, actual.getEventType());
        assertEquals(EVENT_ATTRIBUTES, actual.getEventJson());
        assertEquals(PERFORMED_BY, actual.getPerformedBy());
    }

    @Test
    public void testEventDTOToEvent() {
        CtracEvent actual = testObj.map(eventDTO, CtracEvent.class);
        assertEquals(EVENT_TIME.toDate(), actual.getEventTime());
        assertEquals(EVENT_TYPE, actual.getEventType());
        assertEquals(EVENT_ATTRIBUTES, actual.getEventJson());
        assertEquals(PERFORMED_BY, actual.getPerformedBy());
    }

    private void mockEvent() {
        event = new CtracEvent();
        event.setEventType(EVENT_TYPE);
        event.setEventTime(EVENT_TIME.toDate());
        event.setEventJson(EVENT_ATTRIBUTES);
        event.setPerformedBy(PERFORMED_BY);
    }

    private void mockEventDTO() {
        eventDTO = new CtracEventDTO();
        eventDTO.setEventType(EVENT_TYPE);
        eventDTO.setEventTime(EVENT_TIME.toDate());
        eventDTO.setEventJson(EVENT_ATTRIBUTES);
        eventDTO.setPerformedBy(PERFORMED_BY);
    }
}
