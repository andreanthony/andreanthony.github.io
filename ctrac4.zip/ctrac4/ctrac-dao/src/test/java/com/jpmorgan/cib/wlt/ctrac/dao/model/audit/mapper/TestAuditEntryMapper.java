package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.AuditEntry;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestAuditEntryMapper {

    private static final String EVENT_TYPE = "COLLATERAL_CREATED";
    private static final DateTime EVENT_TIME = new DateTime().
            withDate(2017, 12, 26).
            withTime(16, 40, 5, 20);
    private static final Long COLLATERAL_ID = 1L;
    private static final String IDENTIFIER = "IDENTIFIER";
    private static final String LINE_OF_BUSINESS = "LINE_OF_BUSINESS";
    private static final String COLLATERAL_SECTION = "COLLATERAL_SECTION";
    private static final String DESCRIPTION = "DESCRIPTION";
    private static final String PERFORMED_BY = "PERFORMED_BY";
    private static final String TASK_NAME = "TASK_NAME";
    private static final String USERFULLENAME = "CTRAC_USER";
    private AuditEntryMapper testObj;

    private AuditEntry event;
    private AuditEventDTO eventDTO;

    @Before
    public void setUp() throws JsonProcessingException {
        testObj = new AuditEntryMapper();
        mockEvent();
        mockEventDTO();
    }

    @Test
    public void testEventToEventDTO() {
        AuditEventDTO actual = testObj.map(event, AuditEventDTO.class);
        assertEquals(EVENT_TIME.toDate(), actual.getEventTime());
        assertEquals(EVENT_TYPE, actual.getEventType());
        assertEquals(COLLATERAL_ID, actual.getCollateralId());
        assertEquals(IDENTIFIER, actual.getIdentifier());
        assertEquals(LINE_OF_BUSINESS, actual.getLineOfBusiness());
        assertEquals(COLLATERAL_SECTION, actual.getCollateralSection());
        assertEquals(DESCRIPTION, actual.getDescription());
        assertEquals(PERFORMED_BY, actual.getPerformedBy());
        assertEquals(TASK_NAME, actual.getTaskName());
        assertEquals(USERFULLENAME, actual.getUserFullName());
    }

    @Test
    public void testEventDTOToEvent() {
        AuditEntry actual = testObj.map(eventDTO, AuditEntry.class);
        assertEquals(EVENT_TIME.toDate(), actual.getEventTime());
        assertEquals(EVENT_TYPE, actual.getEventType());
        assertEquals(COLLATERAL_ID, actual.getCollateralId());
        assertEquals(IDENTIFIER, actual.getIdentifier());
        assertEquals(LINE_OF_BUSINESS, actual.getLineOfBusiness());
        assertEquals(COLLATERAL_SECTION, actual.getCollateralSection());
        assertEquals(DESCRIPTION, actual.getDescription());
        assertEquals(PERFORMED_BY, actual.getPerformedBy());
        assertEquals(TASK_NAME, actual.getTaskName());
        assertEquals(USERFULLENAME, actual.getUserFullName());
    }

    private void mockEvent() {
        event = new AuditEntry();
        event.setEventType(EVENT_TYPE);
        event.setEventTime(EVENT_TIME.toDate());
        event.setCollateralId(COLLATERAL_ID);
        event.setIdentifier(IDENTIFIER);
        event.setLineOfBusiness(LINE_OF_BUSINESS);
        event.setCollateralSection(COLLATERAL_SECTION);
        event.setDescription(DESCRIPTION);
        event.setPerformedBy(PERFORMED_BY);
        event.setTaskName(TASK_NAME);
        event.setUserFullName(USERFULLENAME);
    }

    private void mockEventDTO() {
        eventDTO = new AuditEventDTO();
        eventDTO.setEventType(EVENT_TYPE);
        eventDTO.setEventTime(EVENT_TIME.toDate());
        eventDTO.setCollateralId(COLLATERAL_ID);
        eventDTO.setIdentifier(IDENTIFIER);
        eventDTO.setLineOfBusiness(LINE_OF_BUSINESS);
        eventDTO.setCollateralSection(COLLATERAL_SECTION);
        eventDTO.setDescription(DESCRIPTION);
        eventDTO.setPerformedBy(PERFORMED_BY);
        eventDTO.setTaskName(TASK_NAME);
        eventDTO.setUserFullName(USERFULLENAME);
    }
}
