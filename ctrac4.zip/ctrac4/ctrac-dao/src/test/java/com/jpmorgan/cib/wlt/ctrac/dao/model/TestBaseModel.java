package com.jpmorgan.cib.wlt.ctrac.dao.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BankHolidays;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracReconcilable;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailDetails;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplateRule;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplateRule_;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FileContent;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReconciliationLog;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReferenceDate;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.SearchCollateralViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.SearchCollateralViewData_;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.XmlMessageLog;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupAuthorities;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupAuthoritiesPK;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupMembers;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Groups;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.FloodRemapViewData;

@RunWith(MockitoJUnitRunner.class)
public class TestBaseModel {

	@Test
	public void testBankHolidays() {
		GetterSetterHelper.testClass(BankHolidays.class);
	}

	@Test
	public void testBatchCtrl() {
		GetterSetterHelper.testClass(BatchCtrl.class);
	}

	@Test
	public void testCollateralDocument() {
		GetterSetterHelper.testClass(CollateralDocument.class);
	}

	/*@Test
	public void testDocPerfectionItemRelation() {
		GetterSetterHelper.testClass(DocPerfectionItemRelation.class);
	}*/

	@Test
	public void testEmailDetails() {
		GetterSetterHelper.testClass(EmailDetails.class);
	}

	@Test
	public void testEmailTemplate() {
		GetterSetterHelper.testClass(EmailTemplate.class);
	}

	@Test
	public void testFloodRemapViewData() {
		GetterSetterHelper.testClass(FloodRemapViewData.class);
	}

	@Test
	public void testGroupAuthorities() {
		GetterSetterHelper.testClass(GroupAuthorities.class);
	}

	@Test
	public void testGroupAuthoritiesPK() {
		GetterSetterHelper.testClass(GroupAuthoritiesPK.class);
	}

	@Test
	public void testGroupMembers() {
		GetterSetterHelper.testClass(GroupMembers.class);
	}

	@Test
	public void testGroups() {
		GetterSetterHelper.testClass(Groups.class);
	}

	@Test
	public void testLookUpCode() {
		GetterSetterHelper.testClass(LookUpCode.class);
	}

	@Test
	public void testReferenceDate() {
		GetterSetterHelper.testClass(ReferenceDate.class);
	}

	@Test
	public void testSearchCollateralViewData_() {
		GetterSetterHelper.testClass(SearchCollateralViewData_.class);
	}

	@Test
	public void testSearchCollateralViewData() {
		GetterSetterHelper.testClass(SearchCollateralViewData.class);
	}


	@Test
	public void testEntitlementsUsers() {
		GetterSetterHelper.testClass(Users.class);
	}

	@Test
	public void testEntitlementsGroup() {
		GetterSetterHelper.testClass(Groups.class);
	}

	@Test
	public void testEntitlemetnsGroupMembers() {
		GetterSetterHelper.testClass(GroupMembers.class);
	}

	//below for model base
	@Test
	public void testCtracBaseEntity() {
		GetterSetterHelper.testClass(CtracBaseEntity.class);
	}

	@Test
	public void testCtracReconcilable() {
		GetterSetterHelper.testClass(CtracReconcilable.class);
	}

	@Test
	public void testEmailTemplateRule_() {
		GetterSetterHelper.testClass(EmailTemplateRule_.class);
	}

	@Test
	public void testEmailTemplateRule() {
		GetterSetterHelper.testClass(EmailTemplateRule.class);
	}

	@Test
	public void testFileContent() {
		GetterSetterHelper.testClass(FileContent.class);
	}

	@Test
	public void testFloodRemap() {
		GetterSetterHelper.testClass(FloodRemap.class);
	}

	@Test
	public void testLPPolicyRequest() {
		GetterSetterHelper.testClass(LPPolicyRequest.class);
	}

	@Test
	public void testReconciliationLog() {
		GetterSetterHelper.testClass(ReconciliationLog.class);
	}

	@Test
	public void testXmlMessageLog() {
		GetterSetterHelper.testClass(XmlMessageLog.class);
	}
	//model base ends

}
