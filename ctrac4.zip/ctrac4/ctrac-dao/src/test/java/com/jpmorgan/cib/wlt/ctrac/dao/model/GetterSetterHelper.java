package com.jpmorgan.cib.wlt.ctrac.dao.model;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;

public class GetterSetterHelper {

	private static final Logger logger = Logger.getLogger(GetterSetterHelper.class);

	public static void testClass(Class<?> classToTest) {

		try {

			Constructor<?> classConstructor = classToTest.getConstructor();
			Object classObject = classConstructor.newInstance();

			for (Field field : classToTest.getDeclaredFields()) {

				try {

					// Create getter and setter methods
					Class<?> fieldClass = field.getType();
					Method setter = classToTest.getMethod(getMethodName("set", field), fieldClass);
					Method getter = classToTest.getMethod(getMethodName("get", field));

					// Create object to test getter and setter
					Constructor<?> fieldConstructor = fieldClass.getConstructor();
					Object fieldValue = fieldConstructor.newInstance();

					// Invoke getters and setters and assert upon result
					setter.invoke(classObject, fieldValue);
					Object actual = getter.invoke(classObject);
					assertEquals(fieldValue, actual);

				} catch (Exception e) {
					//logger.debug(e.getMessage(), e);
				}

			}

		} catch (Exception e) {
			//logger.debug(e.getMessage(), e);
		}
	}

	private static String getMethodName(String prefix, Field field) {
		StringBuffer stringBuffer = new StringBuffer(prefix);

		String fieldName = field.getName();

		if (fieldName.length() > 0) {
			stringBuffer.append(field.getName().substring(0, 1).toUpperCase());
		}

		if (fieldName.length() > 1) {
			stringBuffer.append(field.getName().substring(1, fieldName.length()));
		}

		return stringBuffer.toString();
	}
	
}
