package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.mapper;

import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.metadata.TypeBuilder;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNull;
import static org.mockito.Mockito.mock;

public class TestDateConverter {

    private static final Date DATE = new DateTime()
            .withDate(2017, 12, 27)
            .withTime(1, 2, 3, 4).toDate();
    private static final String STRING = "2017-12-27T01:02:03.004000";

    private DateConverter testObj;

    @Before
    public void setUp() {
        testObj = new DateConverter();
    }

    @Test
    public void testDateToString() {
        assertEquals(STRING, testObj.convertTo(DATE, new TypeBuilder<String>() {}.build(),mock(MappingContext.class)));
    }

    @Test
    public void testStringToDate() {
        assertEquals(DATE, testObj.convertFrom(STRING, new TypeBuilder<Date>() {}.build(), mock(MappingContext.class)));
    }

    @Test
    public void testNullToString() {
        assertNull(testObj.convertTo(null, new TypeBuilder<String>() {}.build(),mock(MappingContext.class)));
    }

    @Test
    public void testNullToDate() {
        assertNull(testObj.convertFrom(null, new TypeBuilder<Date>() {}.build(),mock(MappingContext.class)));
    }
}
