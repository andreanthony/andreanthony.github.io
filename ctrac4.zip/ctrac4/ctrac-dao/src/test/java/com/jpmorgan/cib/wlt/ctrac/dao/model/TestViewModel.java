package com.jpmorgan.cib.wlt.ctrac.dao.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ActiveCollateralWorkflowRelation;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewDataPK;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralMainDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralOwnerViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ProvidedCoverageViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralSearchViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralSearchViewData_;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.FloodRemapRuleEngine;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.FloodRemapRuleEngine_;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.FloodRemapViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LPPolicyRequestViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.PrimaryLoanBorrowerViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ProofOfCoverageDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.TaskDetailsData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.WorkflowMainDetailsViewData;

@RunWith(MockitoJUnitRunner.class)
public class TestViewModel {
	@Test
	public void testActiveCollateralWorkflowRelation() {
		GetterSetterHelper.testClass(ActiveCollateralWorkflowRelation.class);
	}

	@Test
	public void testCollateralInsuranceViewData() {
		GetterSetterHelper.testClass(CollateralInsuranceViewData.class);
	}

	@Test
	public void testCollateralInsuranceViewDataPK() {
		GetterSetterHelper.testClass(CollateralInsuranceViewDataPK.class);
	}


	@Test
	public void testCollateralMainDetailsViewData() {
		GetterSetterHelper.testClass(CollateralMainDetailsViewData.class);
	}

	@Test
	public void testCollateralOwnerViewData() {
		GetterSetterHelper.testClass(CollateralOwnerViewData.class);
	}

	@Test
	public void testCollateralProveOfCoverageViewData() {
		GetterSetterHelper.testClass(ProvidedCoverageViewData.class);
	}

	@Test
	public void testCollateralSearchViewData_() {
		GetterSetterHelper.testClass(CollateralSearchViewData_.class);
	}

	@Test
	public void testCollateralSearchViewData() {
		GetterSetterHelper.testClass(CollateralSearchViewData.class);
	}

	@Test
	public void testFloodRemapRuleEngine_() {
		GetterSetterHelper.testClass(FloodRemapRuleEngine_.class);
	}

	@Test
	public void testFloodRemapRuleEngine() {
		GetterSetterHelper.testClass(FloodRemapRuleEngine.class);
	}

	@Test
	public void testFloodRemapViewData() {
		GetterSetterHelper.testClass(FloodRemapViewData.class);
	}

	@Test
	public void testLPPolicyRequestViewData() {
		GetterSetterHelper.testClass(LPPolicyRequestViewData.class);
	}

	@Test
	public void testPrimaryLoanBorrowerViewData() {
		GetterSetterHelper.testClass(PrimaryLoanBorrowerViewData.class);
	}

	@Test
	public void testProofOfCoverageDetailsViewData() {
		GetterSetterHelper.testClass(ProofOfCoverageDetailsViewData.class);
	}

	@Test
	public void testTaskDetailsData() {
		GetterSetterHelper.testClass(TaskDetailsData.class);
	}

	@Test
	public void testWorkflowMainDetailsViewData() {
		GetterSetterHelper.testClass(WorkflowMainDetailsViewData.class);
	}

}
