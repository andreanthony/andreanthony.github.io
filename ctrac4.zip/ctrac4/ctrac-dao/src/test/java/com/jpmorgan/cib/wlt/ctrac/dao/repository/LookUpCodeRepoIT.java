package com.jpmorgan.cib.wlt.ctrac.dao.repository;

import static org.junit.Assert.assertEquals;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.dao.config.DataSourceConfig;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={DataSourceConfig.class})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
public class LookUpCodeRepoIT {

	private static final Logger logger = Logger.getLogger(LookUpCodeRepoIT.class);
	
	@Autowired
	LookupCodeRepository lookUpCodeRepo;
	
	@Before
	public void init() {
		
	}
	

	@Test
	@Transactional("transactionManager")
	public void lookupCodeCacheTest() throws Exception
	{
		logger.debug("Attempting to Retrieving from DB...");
		List<LookUpCode> codeList = lookUpCodeRepo.findByCodeSet("FLOOD_TASK_CLOSE_REASON");
		int codeListSize = codeList.size();		
		
		Iterator<LookUpCode> iter = codeList.iterator();
		while(iter.hasNext())
		{
			LookUpCode code = (LookUpCode) iter.next();
			logger.debug(code.getCodeSet()+" | "+code.getCode()+" | "+code.getDescription());
		}
		
		logger.debug("Attempting to Retrieving from Cache...");
		List<LookUpCode> codeList2 = lookUpCodeRepo.findByCodeSet("FLOOD_TASK_CLOSE_REASON");
		int codeListSize2 = codeList2.size();		
		
		Iterator<LookUpCode> iter2 = codeList2.iterator();
		while(iter2.hasNext())
		{
			LookUpCode code2 = (LookUpCode) iter2.next();
			logger.debug(code2.getCodeSet()+" | "+code2.getCode()+" | "+code2.getDescription());
		}		
		
		assertEquals(codeListSize, codeListSize2);
		
		/*
		System.out.println("Adding new value to test cache eviction..");
		LookUpCode lookUpCode = new LookUpCode();
		lookUpCode.setCodeSet("FLOOD_TASK_CLOSE_REASON");
		lookUpCode.setCode("FL.102");
		lookUpCode.setDescription("Generic Float Poc Error Message");	
		lookUpCodeRepo.save(lookUpCode);
		
		System.out.println("Attempting to Retrieving from DB...");
		List<LookUpCode> codeList3 = lookUpCodeRepo.findByCodeSet("FLOOD_TASK_CLOSE_REASON");
		//assertEquals(codeList2.size(), 4);		
		
		Iterator iter3 = codeList3.iterator();
		while(iter3.hasNext())
		{
			LookUpCode code3 = (LookUpCode) iter3.next();
			System.out.println(code3.getCodeSet()+" | "+code3.getCode()+" | "+code3.getDescription());
		}		

		System.out.println("Attempting to Retrieving from Cache...");
		List<LookUpCode> codeList4 = lookUpCodeRepo.findByCodeSet("FLOOD_TASK_CLOSE_REASON");
		//assertEquals(codeList2.size(), 4);		
		
		Iterator iter4 = codeList4.iterator();
		while(iter4.hasNext())
		{
			LookUpCode code4 = (LookUpCode) iter4.next();
			System.out.println(code4.getCodeSet()+" | "+code4.getCode()+" | "+code4.getDescription());
		}		
		*/
	}
	
}
