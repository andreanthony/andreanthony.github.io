package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search;

import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.AuditEntry;
import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.persistence.criteria.*;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestAuditEntrySpecification {

    private static final String KEY = "key";
    private static final String VALUE = "value";
    private static final Date DATE = new DateTime()
            .withDate(2018, 1, 12)
            .withTime(14, 30, 29, 28).toDate();

    @Mock private Root<AuditEntry> root;
    @Mock private CriteriaQuery<?> criteriaQuery;
    @Mock private CriteriaBuilder builder;

    @Mock private Path<String> stringPath;
    @Mock private Path<Date> datePath;
    @Mock private Predicate equalPredicate;
    @Mock private Predicate isNullPredicate;
    @Mock private Predicate lessThanOrEqualToPredicate;
    @Mock private Predicate greaterThanOrEqualToPredicate;
    @Mock private Predicate likePredicate;

    private AuditEntrySpecification testObj;

    @Test
    public void testEqual() {
        when(root.<String> get(KEY)).thenReturn(stringPath);
        when(builder.equal(stringPath, VALUE)).thenReturn(equalPredicate);
        testAndVerify(SearchOperation.EQUAL, VALUE, equalPredicate);
    }

    @Test
    public void testNull() {
        when(root.<String> get(KEY)).thenReturn(stringPath);
        when(builder.isNull(stringPath)).thenReturn(isNullPredicate);
        testAndVerify(SearchOperation.NULL, null, isNullPredicate);
    }

    @Test
    public void testLessThan() {
        when(root.<Date> get(KEY)).thenReturn(datePath);
        when(builder.lessThanOrEqualTo(datePath, DATE)).thenReturn(lessThanOrEqualToPredicate);
        testAndVerify(SearchOperation.LESS_THAN, DATE, lessThanOrEqualToPredicate);
    }

    @Test
    public void testGreaterThan() {
        when(root.<Date> get(KEY)).thenReturn(datePath);
        when(builder.greaterThanOrEqualTo(datePath, DATE)).thenReturn(greaterThanOrEqualToPredicate);
        testAndVerify(SearchOperation.GREATER_THAN, DATE, greaterThanOrEqualToPredicate);
    }

    @Test
    public void testLike() {
        when(root.<String> get(KEY)).thenReturn(stringPath);
        when(builder.lower(stringPath)).thenReturn(stringPath);
        when(builder.like(stringPath, VALUE)).thenReturn(likePredicate);
        testAndVerify(SearchOperation.LIKE, VALUE, likePredicate);
    }

    private AuditEntrySpecification createSearchCriteria(SearchOperation operation, Object value) {
        return new AuditEntrySpecification(new SearchCriteria(KEY, operation, value));
    }

    private void testAndVerify(SearchOperation operation, Object value, Predicate expected) {
        testObj = createSearchCriteria(operation, value);
        assertEquals(expected, testObj.toPredicate(root, criteriaQuery, builder));
    }
}
