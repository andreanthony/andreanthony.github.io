package com.jpmorgan.cib.wlt.ctrac.dao.model.audit;

import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.mapper.AuditEntryMapper;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditEntrySearchCriteria;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditEntrySpecificationsBuilder;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.audit.AuditEntryRepository;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestAuditServiceImpl {

    private static final Long ID = 1L;
    private static final String VALUE = "value";
    private static final Date DATE = new DateTime()
            .withDate(2018, 1, 12)
            .withTime(14, 30, 0, 0).toDate();
    private static final String DATE_STR = "2018-01-12T14:30";

    @Mock private AuditEntryMapper auditEntryMapper;
    @Mock private AuditEntryRepository auditEntryRepository;

    @Mock private AuditEventDTO auditEventDTO;
    @Mock private AuditEntry auditEntry;
    @Mock private List<AuditEventDTO> auditEventDTOs;
    @Mock private List<AuditEntry> auditEntries;
    @Mock private Page<AuditEntry> page;

    @Mock private AuditEntrySpecificationsBuilder auditEntrySpecificationsBuilder;
    @Mock private Specification<AuditEntry> specs;

    @Spy
    @InjectMocks
    private AuditServiceImpl testObj;

    @Before
    public void setUp() {
        when(auditEntryMapper.map(auditEventDTO, AuditEntry.class)).thenReturn(auditEntry);
        when(auditEntryMapper.mapAsList(auditEntries, AuditEventDTO.class)).thenReturn(auditEventDTOs);
        when(auditEntryRepository.findAll(eq(specs), any(PageRequest.class))).thenReturn(page);
        when(page.hasContent()).thenReturn(true);
        when(page.getContent()).thenReturn(auditEntries);
    }

    @Test
    public void testRetrieveCollateralId() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setCollateralId(ID);
        testAndVerify(criteria);
        verify(auditEntrySpecificationsBuilder).collateralId(ID);
    }

    @Test
    public void testRetrieveMinEventTime() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setMinEventTime(DATE_STR);
        testAndVerify(criteria);
        verify(auditEntrySpecificationsBuilder).minEventTime(DATE);
    }

    @Test
    public void testRetrieveMaxEventTime() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setMaxEventTime(DATE_STR);
        testAndVerify(criteria);
        verify(auditEntrySpecificationsBuilder).maxEventTime(DATE);
    }

    @Test
    public void testRetrieveCollateralSection() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setCollateralSection(VALUE);
        testAndVerify(criteria);
        verify(auditEntrySpecificationsBuilder).collateralSection(VALUE);
    }

    @Test
    public void testRetrieveCollateralIdLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setCollateralIdLike(VALUE);
        testRetrieveWithLike(criteria, "collateralIdStr");
    }

    @Test
    public void testRetrieveCollateralSectionLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setCollateralSectionLike(VALUE);
        testRetrieveWithLike(criteria, "collateralSection");
    }

    @Test
    public void testRetrieveEventTypeLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setEventTypeLike(VALUE);
        testRetrieveWithLike(criteria, "eventType");
    }

    @Test
    public void testRetrievePerformedByLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setPerformedByLike(VALUE);
        testRetrieveWithLike(criteria, "performedBy");
    }

    @Test
    public void testRetrieveIdentifierLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setIdentifierLike(VALUE);
        testRetrieveWithLike(criteria, "identifier");
    }

    @Test
    public void testRetrieveLineOfBusinessLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setLineOfBusinessLike(VALUE);
        testRetrieveWithLike(criteria, "lineOfBusiness");
    }

    @Test
    public void testRetrieveDescriptionLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setDescriptionLike(VALUE);
        testRetrieveWithLike(criteria, "description");
    }

    @Test
    public void testRetrieveTaskNameLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setTaskNameLike(VALUE);
        testRetrieveWithLike(criteria, "taskName");
    }

    @Test
    public void testRetrieveUserFullNameLike() {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        criteria.setUserFullNameLike(VALUE);
        testRetrieveWithLike(criteria, "userFullName");
    }
    @Test
    public void testCreate() {
        testObj.create(auditEventDTO);
        verify(auditEntryRepository).save(auditEntry);
    }

    @Test
    public void testPagingDefaults() {
        testAndVerifyPaging(null, null, null, null);
    }

    @Test
    public void testPagingPageNum() {
        testAndVerifyPaging(1, null, null, null);
    }

    @Test
    public void testPagingPageSize() {
        testAndVerifyPaging(null, 25, null, null);
    }

    @Test
    public void testPagingSortDir() {
        testAndVerifyPaging(null, null, Sort.Direction.ASC.name(), null);
    }

    @Test
    public void testPagingSortCol() {
        testAndVerifyPaging(null, null, null, "collateralId");
    }

    @Test
    public void testPagingPageNumInvalid() {
        testAndVerifyPagingInvalid(-1, null, null, null, "pageNum must be positive");
    }

    @Test
    public void testPagingPageSizeInvalid() {
        testAndVerifyPagingInvalid(null, -1, null, null, "pageSize must be positive");
    }

    @Test
    public void testPagingSortDirInvalid() {
        testAndVerifyPagingInvalid(null, null, "INVALID", null, "sortDir must be ASC or DESC");
    }

    @Test
    public void testPagingSortColInvalid() {
        testAndVerifyPagingInvalid(null, null, null, "invalid", "sortCol must be a valid column name");
    }

    private void testAndVerify(AuditEntrySearchCriteria criteria) {
        mockSpecificationsBuilder();
        List<AuditEventDTO> actual = testObj.retrieve(criteria).getAuditData();
        assertEquals(auditEventDTOs, actual);
    }

    private void testAndVerifyPaging(Integer pageNum, Integer pageSize, String sortDir, String sortCol) {
        AuditEntrySearchCriteria criteria = new AuditEntrySearchCriteria();
        if (pageNum != null) {
            criteria.setPageNum(pageNum);
        }
        if (pageSize != null) {
            criteria.setPageSize(pageSize);
        }
        if (sortDir != null) {
            criteria.setSortDir(sortDir);
        }
        if (sortCol != null) {
            criteria.setSortCol(sortCol);
        }
        testAndVerify(criteria);
        ArgumentCaptor<PageRequest> pageRequestArgumentCaptor = ArgumentCaptor.forClass(PageRequest.class);
        verify(auditEntryRepository).findAll(eq(specs), pageRequestArgumentCaptor.capture());
        PageRequest pageRequest = pageRequestArgumentCaptor.getValue();
        assertEquals(pageNum != null ? pageNum : 0, pageRequest.getPageNumber());
        assertEquals(pageSize != null ? pageSize : 100, pageRequest.getPageSize());
        Iterator<Sort.Order> orderIterator = pageRequest.getSort().iterator();
        Sort.Order order = orderIterator.next();
        assertEquals(sortDir != null ? Sort.Direction.fromString(sortDir) : Sort.Direction.DESC, order.getDirection());
        assertEquals(sortCol != null ? sortCol : "eventTime", order.getProperty());
        assertFalse(orderIterator.hasNext());
    }

    private void testAndVerifyPagingInvalid(Integer pageNum, Integer pageSize, String sortDir, String sortCol, String message) {
        try {
            testAndVerifyPaging(pageNum, pageSize, sortDir, sortCol);
        } catch (IllegalArgumentException e) {
            assertEquals(message, e.getMessage());
        }
    }

    private void mockSpecificationsBuilder() {
        when(testObj.createAuditEntrySpecificationsBuilder()).thenReturn(auditEntrySpecificationsBuilder);
        when(auditEntrySpecificationsBuilder.collateralId(anyLong())).thenReturn(auditEntrySpecificationsBuilder);
        when(auditEntrySpecificationsBuilder.collateralSection(anyString())).thenReturn(auditEntrySpecificationsBuilder);
        when(auditEntrySpecificationsBuilder.minEventTime(any(Date.class))).thenReturn(auditEntrySpecificationsBuilder);
        when(auditEntrySpecificationsBuilder.maxEventTime(any(Date.class))).thenReturn(auditEntrySpecificationsBuilder);
        when(auditEntrySpecificationsBuilder.withAttrLike(anyString(),nullable(String.class))).thenReturn(auditEntrySpecificationsBuilder);
        when(auditEntrySpecificationsBuilder.build()).thenReturn(specs);
    }

    private void testRetrieveWithLike(AuditEntrySearchCriteria criteria, String key) {
        testAndVerify(criteria);
        verify(auditEntrySpecificationsBuilder).withAttrLike(key, VALUE);
    }

}
