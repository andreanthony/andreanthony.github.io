package com.jpmorgan.cib.wlt.ctrac.dao.model;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TestBusinessEntityModel {

	@Test
	public void testAddress() {
		GetterSetterHelper.testClass(Address.class);
	}

	@Test
	public void testAgent() {
		GetterSetterHelper.testClass(Agent.class);
	}

	@Test
	public void testBusinessAssets() {
		GetterSetterHelper.testClass(BusinessAssets.class);
	}

	@Test
	public void testCollateral() {
		GetterSetterHelper.testClass(Collateral.class);
	}

	@Test
	public void testCollateralOwner() {
		GetterSetterHelper.testClass(CollateralOwner.class);
	}

	@Test
	public void testCollateralOwnerPk() {
		GetterSetterHelper.testClass(CollateralOwnerPk.class);
	}

	@Test
	public void testContactDetails() {
		GetterSetterHelper.testClass(ContactDetails.class);
	}

	@Test
	public void testCoverageDetails() {
		GetterSetterHelper.testClass(CoverageDetails.class);
	}

	@Test
	public void testCustomer() {
		GetterSetterHelper.testClass(Customer.class);
	}

	@Test
	public void testFloodDetermination() {
		GetterSetterHelper.testClass(FloodDetermination.class);
	}

	@Test
	public void testFloodInsurance() {
		GetterSetterHelper.testClass(FloodInsurance.class);
	}

	@Test
	public void testInsurableAsset() {
		GetterSetterHelper.testClass(InsurableAsset.class);
	}

	@Test
	public void testLoan() {
		GetterSetterHelper.testClass(Loan.class);
	}

	@Test
	public void testLoanBorrower() {
		GetterSetterHelper.testClass(LoanBorrower.class);
	}

	@Test
	public void testLoanBorrowerPk() {
		GetterSetterHelper.testClass(LoanBorrowerPk.class);
	}

	@Test
	public void testLoanCollateral() {
		GetterSetterHelper.testClass(LoanCollateral.class);
	}

	@Test
	public void testLoanCollateralPk() {
		GetterSetterHelper.testClass(LoanCollateralPk.class);
	}

	@Test
	public void testPaymentMethod() {
		GetterSetterHelper.testClass(PaymentMethod.class);
	}

	@Test
	public void testProofOfCoverage() {
		GetterSetterHelper.testClass(ProofOfCoverage.class);
	}

	@Test
	public void testProvidedCoverage() {
		GetterSetterHelper.testClass(ProvidedCoverage.class);
	}

	@Test
	public void testRealEstate() {
		GetterSetterHelper.testClass(RealEstate.class);
	}

	@Test
	public void testRequiredCoverage() {
		GetterSetterHelper.testClass(RequiredCoverage.class);
	}

	@Test
	public void testSectionStatus() {
		GetterSetterHelper.testClass(SectionStatus.class);
	}

	@Test
	public void testHold() {
		GetterSetterHelper.testClass(Hold.class);
	}



}
