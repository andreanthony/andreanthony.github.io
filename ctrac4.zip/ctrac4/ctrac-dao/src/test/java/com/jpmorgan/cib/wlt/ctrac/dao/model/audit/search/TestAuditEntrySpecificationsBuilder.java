package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search;

import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class TestAuditEntrySpecificationsBuilder {

    private static final String KEY = "key";
    private static final String VALUE = "value";
    private static final Date DATE = new DateTime()
            .withDate(2018, 1, 12)
            .withTime(14, 30, 29, 28).toDate();

    private AuditEntrySpecificationsBuilder testObj;

    @Before
    public void setUp() {
        testObj = new AuditEntrySpecificationsBuilder(new ArrayList<AuditEntrySpecification>());
    }

    @Test
    public void testCollateralIdZero() {
        verifySpecs(testObj.collateralId(0L).getSpecs(), "collateralId", SearchOperation.NULL, null);
    }

    @Test
    public void testCollateralIdNonZero() {
        verifySpecs(testObj.collateralId(1L).getSpecs(), "collateralId", SearchOperation.EQUAL, 1L);
    }

    @Test
    public void testCollateralSection() {
        verifySpecs(testObj.collateralSection(VALUE).getSpecs(), "collateralSection", SearchOperation.EQUAL, VALUE);
    }

    @Test
    public void testMinEventTime() {
        verifySpecs(testObj.minEventTime(DATE).getSpecs(), "eventTime", SearchOperation.GREATER_THAN, DATE);
    }

    @Test
    public void testMaxEventTime() {
        verifySpecs(testObj.maxEventTime(DATE).getSpecs(), "eventTime", SearchOperation.LESS_THAN, DATE);
    }

    @Test
    public void testLike() {
        verifySpecs(testObj.withAttrLike(KEY, VALUE).getSpecs(), KEY, SearchOperation.LIKE, "%" + VALUE + "%");
    }

    @Test
    public void testBuild() {
        assertNotNull(testObj.collateralId(1L).withAttrLike(KEY, VALUE).build());
    }

    private void verifySpecs(List<AuditEntrySpecification> actualSpecs, String key, SearchOperation operation, Object value) {
        assertEquals(1, actualSpecs.size());
        SearchCriteria actual = actualSpecs.get(0).getSearchCriteria();
        assertEquals(key, actual.getKey());
        assertEquals(operation, actual.getOperation());
        if (value == null) {
            assertNull(actual.getValue());
        } else {
            assertEquals(value, actual.getValue());
        }
    }
}
