package com.jpmorgan.cib.wlt.ctrac.dao.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.tm.model.TMReconciliationView;

@RunWith(MockitoJUnitRunner.class)
public class TestTmModel {
	@Test
	 public void testTMReconciliationView() {
	  GetterSetterHelper.testClass(TMReconciliationView.class);
	 }
}
