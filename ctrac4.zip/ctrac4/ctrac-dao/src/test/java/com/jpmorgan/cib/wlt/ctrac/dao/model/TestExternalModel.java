package com.jpmorgan.cib.wlt.ctrac.dao.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.model.external.CoreLogicFloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.external.ServiceLinkFloodRemap;

@RunWith(MockitoJUnitRunner.class)
public class TestExternalModel {
	@Test
	 public void testCoreLogicFloodRemap() {
	  GetterSetterHelper.testClass(CoreLogicFloodRemap.class);
	 }
	@Test
	 public void testServiceLinkFloodRemap() {
	  GetterSetterHelper.testClass(ServiceLinkFloodRemap.class);
	 }

}
