package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralEvent;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.mapper.CtracEventMapper;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.event.store.CtracEventRepository;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.EventStoreException;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventSubscriberDTO;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestEventStoreImpl {
    private static final DateTime EVENT_TIME = new DateTime().
            withDate(2017, 12, 26).
            withTime(16, 40, 5, 20);
    private static final String EVENT_STR = "{\"eventUuid\":\"d2e03637-ab86-466c-9f13-830a609f521f\",\"eventTime\":"+EVENT_TIME.toDate().getTime()+",\"eventType\":\"value2\",\"performedBy\":\"value3\"}";
    private static final String INVALID_EVENT_STR = "INVALID_EVENT_STR";
    private static final String EVENT_TYPE_1 = "COLLATERAL_CREATED";
    private static final String EVENT_TYPE_2 = "COLLATERAL_EDITED";
    private static final String API_URL = "http://localhost:8080/ctrac/api/audit";
    private static final String API_1 = "www.api1.jpmchase.net";
    private static final String API_2 = "www.api1.jpmchase.net";

    @Mock private CtracEventMapper eventMapper;
    @Mock private CtracEventRepository eventRepository;
    @Mock private TrustStoreManagerServiceImpl trustStoreManagerService;

    @Spy
    @InjectMocks
    private EventStoreImpl testObj;

    @Mock private CtracEvent event;
    @Mock private CtracEventDTO eventDTO;
    @Mock private List<CollateralEvent> events;
    @Mock private List<CtracEventDTO> eventDTOs;

    @Before
    public void setUp() throws IOException {
        testObj.setAuditApiUrl(API_URL);
        testObj.init();
        when(eventMapper.map(any(CtracEventDTO.class), eq(CtracEvent.class))).thenReturn(event);
    }

    @Test
    public void testPublishWithParseError() {
        try {
            testObj.receive(INVALID_EVENT_STR);
        } catch(EventStoreException e) {
            assertEquals("Error parsing JSON", e.getMessage());
            return;
        }
        fail();
    }

    @Test
    public void testReceiveWithoutSubscribers() {
        testReceiveEvent(EVENT_STR);
    }

    @Test
    public void testReceiveWithSubscribers() {
        Map<String, List<String>> subscriptions = new HashMap<>();
        List<String> apis = new ArrayList<>();
        apis.add(API_1);
        subscriptions.put(EVENT_TYPE_1, apis);
        testObj.setSubscriptions(subscriptions);
        testReceiveEvent(EVENT_STR);
    }

    private void testReceiveEvent(String eventStr) {
        when(eventRepository.findByEventUuid(any(UUID.class))).thenReturn(event);
        testObj.receive(eventStr);
        verify(eventRepository).save(any(CtracEvent.class));
    }

    @Test
    public void testReceiveNewEvent() {
        when(eventRepository.findByEventUuid(any(UUID.class))).thenReturn(null);
        testObj.receive(EVENT_STR);
        verify(eventRepository).save(any(CtracEvent.class));
    }

    @Test
    public void testSubscribe() {
        List<CtracEventSubscriberDTO> subscriptions = new ArrayList<>();
        subscriptions.add(mockSubscriber(EVENT_TYPE_1, API_1));
        subscriptions.add(mockSubscriber(EVENT_TYPE_2, API_2));
        testObj.subscribe(subscriptions);
        Map<String, List<String>> subscriptionsByEventType = testObj.getSubscriptions();
        assertEquals(CollateralEventType.getAllSubscriberEvents().size()+2, subscriptionsByEventType.size());
        assertApi(subscriptionsByEventType, "Collateral Created", "http://localhost:8080/ctrac/api/audit");
        assertApi(subscriptionsByEventType, "Added", "http://localhost:8080/ctrac/api/audit");
        assertApi(subscriptionsByEventType, EVENT_TYPE_1, API_1);
        assertApi(subscriptionsByEventType, EVENT_TYPE_2, API_2);
    }

    private CtracEventSubscriberDTO mockSubscriber(String eventType, String api) {
        return new CtracEventSubscriberDTO(eventType, api);
    }

    private void assertApi(Map<String, List<String>> subscriptionsByEventType, String eventType, String api) {
        List<String> apis = subscriptionsByEventType.get(eventType);
        assertEquals(1, apis.size());
        assertEquals(api, apis.get(0));
    }
}
