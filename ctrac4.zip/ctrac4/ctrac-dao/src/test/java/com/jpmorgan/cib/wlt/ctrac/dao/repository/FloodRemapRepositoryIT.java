package com.jpmorgan.cib.wlt.ctrac.dao.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.dao.config.DataSourceConfig;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.FloodRemapRepository;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { DataSourceConfig.class })
public class FloodRemapRepositoryIT {
	
	@Autowired
	FloodRemapRepository floodRemapRepository;
	
	FloodRemap floodRemap;
	
	Map<String,String> loanNumStatusMap ;	
	
	
	@Before
	public void setUp(){
		loanNumStatusMap = new HashMap<String,String>();
		loanNumStatusMap.put("P2I_LOAN_NUM", "P2I");
		loanNumStatusMap.put("O2I_LOAN_NUM", "O2I");	
		loanNumStatusMap.put("O2P_LOAN_NUM", "O2P");	
		loanNumStatusMap.put("I2P_LOAN_NUM", "I2P");	
		loanNumStatusMap.put("I2O_LOAN_NUM", "I2O");	
		loanNumStatusMap.put("P2O_LOAN_NUM", "P2O");
		loanNumStatusMap.put("NC_LOAN_NUM", "NC");
		loanNumStatusMap.put("INVALID_LOAN_NUM", "O");		
	}
	
	@Test
	@Transactional("transactionManager")
	public void testGetNewFloodRemaps() {		
		prepareP2IFloodRemap();
		prepareO2IFloodRemap();
		prepareO2PFloodRemap();
		prepareI2PFloodRemap();
		prepareI2OFloodRemap();
		prepareP2OFloodRemap();
		List<FloodRemap> remaps = floodRemapRepository.getNewFloodRemaps();		
		for(FloodRemap remap : remaps) {
			if(loanNumStatusMap.containsKey(remap.getLoanNumber())){
				assertEquals(loanNumStatusMap.get(remap.getLoanNumber()), remap.getStatusChange());
			}
		}
	}
	
	@Test
	@Transactional("transactionManager")
	public void testGetNewFloodRemapsNotNC(){
		prepareNCFloodRemap();
		List<FloodRemap> remaps = floodRemapRepository.getNewFloodRemaps();		
		for(FloodRemap remap : remaps) {
			if(loanNumStatusMap.containsKey(remap.getLoanNumber())){
				fail("NC status flood remap should not be processed,hence failed.");
			}
		}
	}
	
	/* Below code may be superficial - However testing Remap table with Status change with Invalid value such as NULL*/
	@Test
	@Transactional("transactionManager")
	public void testGetNewFloodRemapsInvalid(){
		prepareInvalidFloodRemap();
		List<FloodRemap> remaps = floodRemapRepository.getNewFloodRemaps();		
		for(FloodRemap remap : remaps) {
			if(loanNumStatusMap.containsKey(remap.getLoanNumber())){
				fail("Invalid status flood remap should not be processed,hence failed.");
			}
		}
	}

	private void prepareInvalidFloodRemap() {
		floodRemap = new FloodRemap();
		floodRemap.setReqNum("Request Invalid");
		floodRemap.setBorrowerName("Borrower 1");
		floodRemap.setLoanNumber("INVALID_LOAN_NUM");
		floodRemap.setAddress("123 ABC St. Invalid");
		floodRemap.setStatusChange("");
		floodRemap.setProcessingStatus("N");
		floodRemapRepository.save(floodRemap);
	}

	private void prepareNCFloodRemap() {
		// insert a record into flood remap..
		// entity class cannot be mocked using mockito hence using 'new'
		floodRemap = new FloodRemap();
		floodRemap.setReqNum("Request 1");
		floodRemap.setBorrowerName("Borrower 1");
		floodRemap.setLoanNumber("NC_LOAN_NUM");
		floodRemap.setAddress("123 ABC St.");
		floodRemap.setStatusChange("NC");
		floodRemap.setProcessingStatus("N");
		floodRemapRepository.save(floodRemap);		
	}

	private void prepareP2OFloodRemap() {		
		floodRemap = new FloodRemap();
		floodRemap.setReqNum("Request 1");
		floodRemap.setBorrowerName("Borrower 1");
		floodRemap.setLoanNumber("O2I_LOAN_NUM");
		floodRemap.setAddress("123 ABC St.");
		floodRemap.setStatusChange("O2I");
		floodRemap.setProcessingStatus("N");
		floodRemapRepository.save(floodRemap);
	}

	private void prepareI2OFloodRemap() {
		floodRemap = new FloodRemap();
		floodRemap.setReqNum("Request 1");
		floodRemap.setBorrowerName("Borrower 1");
		floodRemap.setLoanNumber("I2O_LOAN_NUM");
		floodRemap.setAddress("123 ABC St.");
		floodRemap.setStatusChange("I2O");
		floodRemap.setProcessingStatus("N");
		floodRemapRepository.save(floodRemap);
	}

	private void prepareI2PFloodRemap() {
		floodRemap = new FloodRemap();
		floodRemap.setReqNum("Request 1");
		floodRemap.setBorrowerName("Borrower 1");
		floodRemap.setLoanNumber("I2P_LOAN_NUM");
		floodRemap.setAddress("123 ABC St.");
		floodRemap.setStatusChange("I2P");
		floodRemap.setProcessingStatus("N");
		floodRemapRepository.save(floodRemap);
	}

	private void prepareO2PFloodRemap() {
		floodRemap = new FloodRemap();
		floodRemap.setReqNum("Request 1");
		floodRemap.setBorrowerName("Borrower 1");
		floodRemap.setLoanNumber("O2P_LOAN_NUM");
		floodRemap.setAddress("123 ABC St.");
		floodRemap.setStatusChange("O2P");
		floodRemap.setProcessingStatus("N");
		floodRemapRepository.save(floodRemap);
	}

	private void prepareO2IFloodRemap() {		
		floodRemap = new FloodRemap();
		floodRemap.setBorrowerName("Borrower 1");
		floodRemap.setReqNum("Request 1");
		floodRemap.setLoanNumber("O2I_LOAN_NUM");
		floodRemap.setAddress("123 ABC St.");
		floodRemap.setStatusChange("O2I");
		floodRemap.setProcessingStatus("N");
		floodRemapRepository.save(floodRemap);
	}
	
	private void prepareP2IFloodRemap() {
		floodRemap = new FloodRemap();
		floodRemap.setReqNum("Request 1");
		floodRemap.setBorrowerName("Borrower 1");
		floodRemap.setLoanNumber("P2I_LOAN_NUM");
		floodRemap.setAddress("123 ABC St.");
		floodRemap.setStatusChange("P2I");
		floodRemap.setProcessingStatus("N");
		floodRemapRepository.save(floodRemap);
	}

}
