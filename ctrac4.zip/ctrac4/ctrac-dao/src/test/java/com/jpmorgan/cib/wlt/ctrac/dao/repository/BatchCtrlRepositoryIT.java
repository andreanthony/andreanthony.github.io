package com.jpmorgan.cib.wlt.ctrac.dao.repository;
import static com.jpmorgan.cib.wlt.ctrac.commons.enums.SchedulerJob.FULL_EOD_JOB;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.jpmorgan.cib.wlt.ctrac.dao.config.DataSourceConfig;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.BatchCtrlRepository;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { DataSourceConfig.class })
public class BatchCtrlRepositoryIT {

	@Autowired
	BatchCtrlRepository batchCtrlRepository;
	
	@Test
	public void testFindByBatchType() {
		List<BatchCtrl> batchCtrlList = 
				batchCtrlRepository.findByBatchType(FULL_EOD_JOB.getName());
		BatchCtrl batchCtrl = batchCtrlList.get(0);
		assertNotNull(batchCtrl);
	}
	
	@Test
	public void testFindByBatchTypeAndCtrlFlag() {
		List<BatchCtrl> batchCtrlList = 
				batchCtrlRepository.findByBatchTypeAndCtrlFlag(FULL_EOD_JOB.getName(), 'Y');
		if(CollectionUtils.isEmpty(batchCtrlList)){
			batchCtrlList = batchCtrlRepository.findByBatchTypeAndCtrlFlag(FULL_EOD_JOB.getName(), 'N');
		}
		BatchCtrl batchCtrl = batchCtrlList.get(0);
		assertNotNull(batchCtrl);
	}
	
	@Test
	public void testFindByRunning() {
		List<BatchCtrl> batchCtrlList = batchCtrlRepository.findByRunning('N');
		if(CollectionUtils.isEmpty(batchCtrlList)){
			batchCtrlList = batchCtrlRepository.findByRunning('Y');
		}
		BatchCtrl batchCtrl = batchCtrlList.get(0);
		assertNotNull(batchCtrl);
	}

}
