package com.jpmorgan.cib.wlt.ctrac.dao.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.model.letters.CoverLetterSection;
import com.jpmorgan.cib.wlt.ctrac.dao.model.letters.LetterData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.letters.LetterFile;

@RunWith(MockitoJUnitRunner.class)
public class TestLettersModel {
	@Test
	 public void testCoverLetterSection() {
	  GetterSetterHelper.testClass(CoverLetterSection.class);
	 }
	@Test
	 public void testLetterData() {
	  GetterSetterHelper.testClass(LetterData.class);
	 }
	@Test
	 public void testLetterFile() {
	  GetterSetterHelper.testClass(LetterFile.class);
	 }
}
