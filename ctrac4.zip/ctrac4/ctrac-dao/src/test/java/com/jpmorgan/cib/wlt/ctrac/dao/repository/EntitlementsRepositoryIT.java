package com.jpmorgan.cib.wlt.ctrac.dao.repository;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgan.cib.wlt.ctrac.dao.config.DataSourceConfig;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Groups;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.GroupMembersRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.GroupsRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.LookupCodeRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.base.UsersRepository;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { DataSourceConfig.class })
public class EntitlementsRepositoryIT {

	@Autowired
	GroupsRepository groupsRepository;

	@Autowired
	UsersRepository usersRepository;

	@Autowired
	LookupCodeRepository lookUpCodeRepository;

	@Autowired
	GroupMembersRepository groupMembersRepository;

	private final static String testUsername = "testUsername";
	private final static String testLastName = "testLastName";
	private final static String testFirstName = "testFirstName";
	private final static String testSid = "s123456";
	private final static Long groupAId = new Long(6);
	private final static Long groupBId = new Long(1);
	@Test
	@Transactional(value="transactionManager")
	public void testUsersRepository(){
		Groups dummyGroupA = groupsRepository.findOne(groupAId);
		Groups dummyGroupB = groupsRepository.findOne(groupBId);

		Users dummyUser = new Users();
		dummyUser.setFirstName(testFirstName);
		dummyUser.setLastName(testLastName);
		dummyUser.setUsername(testUsername);
		dummyUser.setSid(testSid);
		dummyUser.setEnabled(true);
        dummyUser.addGroups(dummyGroupA);
        //save duplicates
        dummyUser.addGroups(dummyGroupA);
        dummyUser.addGroups(dummyGroupB);
        dummyUser = usersRepository.save(dummyUser);

		Users savedUsers = new Users();
		savedUsers = usersRepository.findByUsernameIgnoreCaseAndEnabled(testUsername, true);
		int groupsRelation = savedUsers.getGroupMembers().size();
		Groups groupA = savedUsers.getGroupMembers().get(0).getGroups();
		Groups groupB = savedUsers.getGroupMembers().get(1).getGroups();
		assertEquals(testLastName, savedUsers.getLastName());
		assertEquals(testUsername, savedUsers.getUsername());
		assertEquals(testFirstName, savedUsers.getFirstName());
		assertEquals(testSid, savedUsers.getSid());
		assertEquals(2, groupsRelation);
        assertEquals(groupAId, groupA.getId());
        assertEquals(groupBId, groupB.getId());
        assertEquals(testUsername, savedUsers.getGroupMembers().get(0).getUsername());
        assertEquals(testUsername, savedUsers.getGroupMembers().get(1).getUsername());
	}


}
