package com.jpmorgan.cib.wlt.ctrac.dao.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.config.DataSourceConfig;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel.EmailTemplateRepository;


//@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { DataSourceConfig.class })
public class EmailTemplateRepositoryIT {
	
	@Autowired 
	EmailTemplateRepository emailTemplateRepository;
	public static final String E2_EMAIL_TEMPLATE = "E2";
	public static final String E3_EMAIL_TEMPLATE = "E3";
	public static final String EMAIL_TEMPLATE_NAME_E2 = "REMAP - I2O - COLLATERAL AND EXPOSURE";
	public static final String EMAIL_TEMPLATE_NAME_E3 = "REMAP - I2O - COLLATERAL AND NO EXPOSURE";	
	
	//The E2 and E3 email templates no longer exist in ctrac2. therefore they are removed.
	//select * from TLCP_EMAIL_TEMPLATE where email_template_code in ('E2', 'E3', 'E5');
}
