package com.jpmorgan.cib.wlt.ctrac.dao.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupAuthorities;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupAuthoritiesPK;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupMembers;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupMemebersPK;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Groups;
import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;

@RunWith(MockitoJUnitRunner.class)
public class TestEntitlmentsModel {
	@Test
	public void testGroupAuthorities() {
		GetterSetterHelper.testClass(GroupAuthorities.class);
	}

	@Test
	public void testGroupAuthoritiesPK() {
		GetterSetterHelper.testClass(GroupAuthoritiesPK.class);
	}

	@Test
	public void testGroupMembers() {
		GetterSetterHelper.testClass(GroupMembers.class);
	}

	@Test
	public void testGroupMemebersPK() {
		GetterSetterHelper.testClass(GroupMemebersPK.class);
	}

	@Test
	public void testGroups() {
		GetterSetterHelper.testClass(Groups.class);
	}

	@Test
	public void testUsers() {
		GetterSetterHelper.testClass(Users.class);
	}

}
