package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProofOfCoverageWorkItemRelationType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import org.apache.log4j.Logger;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "TLCP_WORK_ITEM")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class WorkItem extends CtracBaseEntity {

    private static final Logger logger = Logger.getLogger(WorkItem.class);

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "workItemSeqGenerator")
	@TableGenerator(name = "workItemSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_WORK_ITEM", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "WORKFLOW_ID")
	private String workFlowID;
	
	@Column(name = "INITIATION_DATE")
	private Date initiationDate;

	@Column(name = "PERFECTION_TYPE")
	private String perfectionType;
	
	@Column(name = "PERFECTION_SUB_TYPE")
	private String perfectionSubType;
	
	@OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, mappedBy = "workItem")
	private List<CollateralWorkItem> collateralWorkItems = new ArrayList<>();
	
	@OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL},  mappedBy = "workItem")
	protected List<ProofOfCovWorkItem> proofOfCovWorkItems = new ArrayList<>();

	public WorkItem(){
		
	}

	public WorkItem(String perfectionType, String perfectionSubType) {
        this.perfectionType = perfectionType;
        this.perfectionSubType = perfectionSubType;
    }
	
	public WorkItem(String workFlowID, Date initiationDate, String perfectionType, String perfectionSubType){
		this.workFlowID = workFlowID;
		this.initiationDate = initiationDate;
		this.perfectionType = perfectionType;
		this.perfectionSubType = perfectionSubType;
	}
	
	public void addCollateral(Collateral collateral) {
		CollateralWorkItem collateralWorkItem = new CollateralWorkItem();
		collateralWorkItem.setCollateral(collateral);
		collateralWorkItem.setWorkItem(this);
		if (!collateralWorkItems.contains(collateralWorkItem)) {
            collateralWorkItems.add(collateralWorkItem);
        }
	}
	
	public void removeCollateral(Collateral collateral) {
		for (CollateralWorkItem collateralWorkItem : collateralWorkItems) {
			if (collateralWorkItem.getCollateral().equals(collateral)) {
				collateralWorkItem.setWorkItem(null);
				collateralWorkItems.remove(collateralWorkItem);
				break;
			}
		}
	}
	
	public CollateralWorkItem getCollateralWorkItem(Long collateralRid) {
		for (CollateralWorkItem collateralWorkItem : collateralWorkItems) {
			if (collateralWorkItem.getCollateral().getRid().equals(collateralRid)) {
				return collateralWorkItem;
			}
		}
		return null;
	}
	
	public List<CollateralWorkItem> getCollateralWorkItems() {
		return collateralWorkItems;
	}
	
	public Collateral getPreferredCollateral() {
		// min RID for now
		Collateral preferredCollateral = null;
		Long minRid = Long.MAX_VALUE;
		for (CollateralWorkItem collateralWorkItem : collateralWorkItems) {
			if (collateralWorkItem.getCollateral().getRid() < minRid) {
				preferredCollateral = collateralWorkItem.getCollateral();
			}
		}
		return preferredCollateral;
	}

	public Long getRid() {
		return rid;
	}
	public void setRid(Long rid) {
		this.rid = rid;
	}
	public String getWorkFlowID() {
		return workFlowID;
	}
	public void setWorkFlowID(String workFlowID) {
		this.workFlowID = workFlowID;
	}
	public Date getInitiationDate() {
		return initiationDate;
	}
	public void setInitiationDate(Date initiationDate) {
		this.initiationDate = initiationDate;
	}
	public String getPerfectionType() {
		return perfectionType;
	}
	public void setPerfectionType(String perfectionType) {
		this.perfectionType = perfectionType;
	}
	public String getPerfectionSubType() {
		return perfectionSubType;
	}

	public PerfectionItemSubType getPerfectionSubType_() {
		PerfectionItemSubType temp= null;
		try {
			temp = PerfectionItemSubType.valueOf(this.perfectionSubType);
		} catch (Exception e) {
		    logger.error(e.getMessage(), e);
		}
		return temp;
	}
	
	public void setPerfectionSubType(String perfectionSubType) {
		this.perfectionSubType = perfectionSubType;
	}

	public void setProofOfCovWorkItems(List<ProofOfCovWorkItem> proofOfCovWorkItems) {
		this.proofOfCovWorkItems = proofOfCovWorkItems;
	}

	public List<ProofOfCovWorkItem> getProofOfCovWorkItems() {
		return proofOfCovWorkItems;
	}
	
	public ProofOfCoverage getProofOfCoverageForItemType(ProofOfCoverageWorkItemRelationType itemType) {
		for (ProofOfCovWorkItem proofOfCoverageWorkItem : proofOfCovWorkItems) {
			if (itemType.getName().equals(proofOfCoverageWorkItem.getItemType())) {
				return proofOfCoverageWorkItem.getProofOfCoverage();
			}
		}
		return null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WorkItem other = (WorkItem) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}
}
