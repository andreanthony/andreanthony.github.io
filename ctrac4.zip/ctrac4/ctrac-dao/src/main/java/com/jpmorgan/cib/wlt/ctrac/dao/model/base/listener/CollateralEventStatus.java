package com.jpmorgan.cib.wlt.ctrac.dao.model.base.listener;

public enum CollateralEventStatus {
    PENDING, PUBLISHED
}
