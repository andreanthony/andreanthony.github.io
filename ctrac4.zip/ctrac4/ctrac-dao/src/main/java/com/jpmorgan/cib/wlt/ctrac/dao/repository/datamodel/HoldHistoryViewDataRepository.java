package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.HoldHistoryViewData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HoldHistoryViewDataRepository  extends JpaRepository<HoldHistoryViewData, Long> {
    List<HoldHistoryViewData> findByCollateralRid(Long collateralRid);
}
