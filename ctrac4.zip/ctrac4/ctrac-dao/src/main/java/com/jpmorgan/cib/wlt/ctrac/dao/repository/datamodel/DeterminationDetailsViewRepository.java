package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.DeterminationDetailsViewData;

public interface DeterminationDetailsViewRepository extends JpaRepository<DeterminationDetailsViewData, Long> {
	
	List<DeterminationDetailsViewData> findByCollateralRidAndStatus(Long collateralRid, String status);

}
