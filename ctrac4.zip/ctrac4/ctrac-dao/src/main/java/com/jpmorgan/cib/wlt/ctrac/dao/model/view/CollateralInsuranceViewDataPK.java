package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

public class CollateralInsuranceViewDataPK implements Serializable {

    private static final long serialVersionUID = -5503954904172446559L;

    public CollateralInsuranceViewDataPK() {}
    
    private Collateral collateral;
    
    private ProofOfCoverage proofOfCoverage;

    public ProofOfCoverage getProofOfCoverage() {
        return proofOfCoverage;
    }

    public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
        this.proofOfCoverage = proofOfCoverage;
    }
    
	public Collateral getCollateral() {
		return collateral;
	}

	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((collateral == null) ? 0 : collateral.hashCode());
		result = prime * result + ((proofOfCoverage == null) ? 0 : proofOfCoverage.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollateralInsuranceViewDataPK other = (CollateralInsuranceViewDataPK) obj;
		if (collateral == null) {
			if (other.collateral != null)
				return false;
		}
		else if (!collateral.equals(other.collateral))
			return false;
		if (proofOfCoverage == null) {
			if (other.proofOfCoverage != null)
				return false;
		}
		else if (!proofOfCoverage.equals(other.proofOfCoverage))
			return false;
		return true;
	}

 

}
