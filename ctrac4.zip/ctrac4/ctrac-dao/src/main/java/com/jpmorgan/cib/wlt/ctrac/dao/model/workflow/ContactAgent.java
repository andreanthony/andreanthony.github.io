package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailDetails;

@Entity
@Table(name = "TLCP_CONTACT_AGENT")
public class ContactAgent extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "contactAgentSeqGenerator")
	@TableGenerator(name = "contactAgentSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_CONTACT_AGENT", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "CALLS_PLACED")
	private String callPlaced;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "PERFECTION_TASK_RID", referencedColumnName="RID")
	private PerfectionTask perfectionTask;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "EMAIL_DETAILS_RID", referencedColumnName="RID")
	private EmailDetails emailDetails;

	public Long getRid() {
		return rid;
	}
	public void setRid(Long rid) {
		this.rid = rid;
	}
	public String getCallPlaced() {
		return callPlaced;
	}
	public void setCallPlaced(String callPlaced) {
		this.callPlaced = callPlaced;
	}
	public PerfectionTask getPerfectionTask() {
		return perfectionTask;
	}
	public void setPerfectionTask(PerfectionTask perfectionTask) {
		this.perfectionTask = perfectionTask;
	}
	public EmailDetails getEmailDetails() {
		return emailDetails;
	}
	public void setEmailDetails(EmailDetails emailDetails) {
		this.emailDetails = emailDetails;
	}

}
