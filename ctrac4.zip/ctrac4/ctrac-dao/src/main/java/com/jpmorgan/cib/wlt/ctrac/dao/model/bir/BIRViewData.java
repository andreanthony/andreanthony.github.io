package com.jpmorgan.cib.wlt.ctrac.dao.model.bir;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "VLCP_BORROWER_INSURANCE_REVIEW")
public class BIRViewData {

	@Id
	@Column(name = "RID")
	private Long rid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BIR_PROOF_OF_COV_DETAILS_RID")
	private BorrowerInsuranceReviewDetails borrowerInsuranceReviewDetails;
	
	@Column(name = "PROOF_OF_COVERAGE_RID")
	private Long proofOfCoverageRid;
	
	@Column(name = "BIR_COLLATERAL_DETAILS_RID")
	private Long birCollateralDetailsRid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "BIR_INS_ASSET_DETAILS_RID")
	private Long birInsAssetDetailsRid;
	
	@Column(name = "INSURABLE_ASSET_SORT_ORDER")
	private Long insurableAssetSortOrder;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public BorrowerInsuranceReviewDetails getBorrowerInsuranceReviewDetails() {
		return borrowerInsuranceReviewDetails;
	}

	public void setBorrowerInsuranceReviewDetails(BorrowerInsuranceReviewDetails borrowerInsuranceReviewDetails) {
		this.borrowerInsuranceReviewDetails = borrowerInsuranceReviewDetails;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public Long getBirCollateralDetailsRid() {
		return birCollateralDetailsRid;
	}

	public void setBirCollateralDetailsRid(Long birCollateralDetailsRid) {
		this.birCollateralDetailsRid = birCollateralDetailsRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getBirInsAssetDetailsRid() {
		return birInsAssetDetailsRid;
	}

	public void setBirInsAssetDetailsRid(Long birInsAssetDetailsRid) {
		this.birInsAssetDetailsRid = birInsAssetDetailsRid;
	}

	public Long getInsurableAssetSortOrder() {
		return insurableAssetSortOrder;
	}

	public void setInsurableAssetSortOrder(Long insurableAssetSortOrder) {
		this.insurableAssetSortOrder = insurableAssetSortOrder;
	}
	
}
