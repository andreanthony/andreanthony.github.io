package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralSearchViewData;

public interface CollateralSearchViewDataRepository extends
		JpaRepository<CollateralSearchViewData, Long>,
		JpaSpecificationExecutor<CollateralSearchViewData> {
	
	public List<CollateralSearchViewData> findByCollateralRid(Long collateralRid);
}
