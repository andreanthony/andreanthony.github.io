package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracReconcilable;

import javax.persistence.Id;

@Entity
@Table(name="VLCP_HOLD_DETAILS_BY_WORKITEM")
public class HoldDetailsViewData {
	@Id
	@Column(name = "HOLD_RID")
	private Long holdRid;

	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "PARENT_WORK_ITEM_RID")
	private Long parentWorkItemRid;

	@Column(name = "COVERAGE_TYPE")
	private String coverageType;
	
	@Column(name = "BUILDING_NAME")
	private String buildingName;

	@Column(name = "PARENT_HOLD_RID")
	private Long parentHoldRid;
	
	@Column(name = "HOLD_TYPE")
	private String holdType;	

	@Column(name = "START_DATE")
	private Date startDate;	

	@Column(name = "HOLD_PERIOD")
	private String holdPeriod;
	
	@Column(name = "LPI_DATE")
	private Date lpiDate;

	@Column(name = "INSURABLE_ASSET_RID")
	private Long insurableAssetRid;

	@Column(name = "INSURABLE_ASSET_TYPE")
	private String insurableAssetType;

	public Long getHoldRid() {
		return holdRid;
	}

	public void setHoldRid(Long holdRid) {
		this.holdRid = holdRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getParentWorkItemRid() {
		return parentWorkItemRid;
	}

	public void setParentWorkItemRid(Long parentWorkItemRid) {
		this.parentWorkItemRid = parentWorkItemRid;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public Long getParentHoldRid() {
		return parentHoldRid;
	}

	public void setParentHoldRid(Long parentHoldRid) {
		this.parentHoldRid = parentHoldRid;
	}

	public String getHoldType() {
		return holdType;
	}

	public void setHoldType(String holdType) {
		this.holdType = holdType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getHoldPeriod() {
		return holdPeriod;
	}

	public void setHoldPeriod(String holdPeriod) {
		this.holdPeriod = holdPeriod;
	}

	public Date getLpiDate() {
		return lpiDate;
	}

	public void setLpiDate(Date lpiDate) {
		this.lpiDate = lpiDate;
	}


	public Long getInsurableAssetRid() { return insurableAssetRid; }

	public void setInsurableAssetRid(Long assetRid) { this.insurableAssetRid = assetRid; }

	public String getInsurableAssetType() { return insurableAssetType; }

	public void setInsurableAssetType(String assetType) { this.insurableAssetType = assetType; }

}
