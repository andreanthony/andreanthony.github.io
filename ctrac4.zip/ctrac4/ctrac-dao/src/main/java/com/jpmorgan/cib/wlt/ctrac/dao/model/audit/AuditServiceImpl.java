package com.jpmorgan.cib.wlt.ctrac.dao.model.audit;

import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.mapper.AuditEntryMapper;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditEntryColumn;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditEntrySearchCriteria;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditEntrySpecificationsBuilder;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditRetrieveResult;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.audit.AuditEntryRepository;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;

@Service
public class AuditServiceImpl implements AuditService {

    private static final DateTimeFormatter FORMATTER = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm");
    private static final int DEFAULT_PAGE_SIZE = 100;

    private final AuditEntryMapper auditEntryMapper;
    private final AuditEntryRepository auditEntryRepository;

    @Autowired
    public AuditServiceImpl(AuditEntryMapper auditEntryMapper,
                            AuditEntryRepository auditEntryRepository) {
        assert(auditEntryMapper != null);
        this.auditEntryMapper = auditEntryMapper;
        assert(auditEntryRepository != null);
        this.auditEntryRepository = auditEntryRepository;
    }

    @Override
    public AuditRetrieveResult retrieve(AuditEntrySearchCriteria criteria) {
        Specification<AuditEntry> spec = createAuditEntrySpecification(criteria);
        PageRequest pageRequest = createPageRequest(criteria);
        Page<AuditEntry> page = auditEntryRepository.findAll(spec, pageRequest);
        if (page.hasContent()) {
            return new AuditRetrieveResult(auditEntryMapper.mapAsList(page.getContent(), AuditEventDTO.class)
                    ,page.getTotalElements());
        }
        return new AuditRetrieveResult(new ArrayList<AuditEventDTO>(),0);
    }

    @Override
    public void create(AuditEventDTO auditEventDTO) {
        AuditEntry auditEntry = auditEntryRepository.findByEventUuid(auditEventDTO.getEventUuid());
        if(auditEntry == null) {
            auditEntry = auditEntryMapper.map(auditEventDTO, AuditEntry.class);
        } else {
            auditEntryMapper.map(auditEventDTO, auditEntry);
        }
        auditEntry.setLastPublishTime(new Date());
        auditEntryRepository.save(auditEntry);
    }

    private Specification<AuditEntry> createAuditEntrySpecification(AuditEntrySearchCriteria criteria) {
        AuditEntrySpecificationsBuilder builder = createAuditEntrySpecificationsBuilder();
        if (criteria.getCollateralId() != null) {
            builder = builder.collateralId(criteria.getCollateralId());
        }
        if (StringUtils.isNotBlank(criteria.getCollateralSection())) {
            builder = builder.collateralSection(criteria.getCollateralSection());
        }
        if (StringUtils.isNotBlank(criteria.getMinEventTime())) {
            builder = builder.minEventTime(FORMATTER.parseDateTime(criteria.getMinEventTime()).toDate());
        }
        if (StringUtils.isNotBlank(criteria.getMaxEventTime())) {
            builder = builder.maxEventTime(FORMATTER.parseDateTime(criteria.getMaxEventTime()).toDate());
        }
        builder = builder
                .withAttrLike("collateralIdStr", criteria.getCollateralIdLike())
                .withAttrLike("eventType", criteria.getEventTypeLike())
                .withAttrLike("performedBy", criteria.getPerformedByLike())
                .withAttrLike("identifier", criteria.getIdentifierLike())
                .withAttrLike("lineOfBusiness", criteria.getLineOfBusinessLike())
                .withAttrLike("collateralSection", criteria.getCollateralSectionLike())
                .withAttrLike("description", criteria.getDescriptionLike())
                .withAttrLike("taskName", criteria.getTaskNameLike())
                .withAttrLike("userFullName", criteria.getUserFullNameLike());
        return builder.build();
    }

    AuditEntrySpecificationsBuilder createAuditEntrySpecificationsBuilder() {
        return new AuditEntrySpecificationsBuilder();
    }

    private PageRequest createPageRequest(AuditEntrySearchCriteria criteria) {
        int pageNum = getPageNumber(criteria);
        int pageSize = getPageSize(criteria);
        Sort.Direction sortDir = getSortDirection(criteria);
        String sortCol = getSortColumn(criteria);
        return new PageRequest(pageNum, pageSize, sortDir,sortCol);
    }

    private int getPageNumber(AuditEntrySearchCriteria criteria) {
        return getNumber(criteria.getPageNum(), 0, "pageNum");
    }

    private int getPageSize(AuditEntrySearchCriteria criteria) {
        return getNumber(criteria.getPageSize(), DEFAULT_PAGE_SIZE, "pageSize");
    }

    private int getNumber(int inputValue, int defaultValue, String columnName) {
        int validatedValue = defaultValue;
        if (inputValue > 0) {
            validatedValue = inputValue;
        } else if (inputValue < 0) {
            throw new IllegalArgumentException(columnName + " must be positive");
        }
        return validatedValue;
    }

    private Sort.Direction getSortDirection(AuditEntrySearchCriteria criteria) {
        Sort.Direction sortDir = Sort.Direction.DESC;
        if ("asc".equalsIgnoreCase(criteria.getSortDir())) {
            sortDir = Sort.Direction.ASC;
        } else if (StringUtils.isNotBlank(criteria.getSortDir()) && !"desc".equalsIgnoreCase(criteria.getSortDir())) {
            throw new IllegalArgumentException("sortDir must be ASC or DESC");
        }
        return sortDir;
    }

    private String getSortColumn(AuditEntrySearchCriteria criteria) {
        String sortCol = AuditEntryColumn.EVENT_TIME.getColumnName();
        if (ArrayUtils.contains(AuditEntryColumn.COLUMN_NAMES, criteria.getSortCol())) {
            sortCol = criteria.getSortCol();
        } else if (StringUtils.isNotBlank(criteria.getSortCol())) {
            throw new IllegalArgumentException("sortCol must be a valid column name");
        }
        return sortCol;
    }
}
