package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;

public interface PerfectionTaskRepository extends JpaRepository<PerfectionTask, Long> {
	
	PerfectionTask findByTmTaskId(String tmTaskId);
	
	PerfectionTask findByTmTaskIdAndTaskStatus(String tmTaskId,String taskStatus);
	
	PerfectionTask findByTmTaskIdAndTaskStatusIn(String tmTaskId, List<String> taskStatus);
	
	List<PerfectionTask> findByWorkItemRid(Long rid);
	
	@Query("select pftTask.workflowStep from PerfectionTask pftTask where pftTask.tmTaskId=?1 and taskStatus='OPEN'")
	String getWorkFlowStepForTmTaskId(String tmTaskId);
	
	List<PerfectionTask> findByWorkflowStepAndTaskStatusIn(String workFlowStep,List<String> taskStatus);
	
	List<PerfectionTask> findByWorkflowStepAndTaskStatus(String workFlowStep, String taskStatus);
	
	List<PerfectionTask> findByWorkItemAndTaskStatus(WorkItem workItem, String taskStatus);
	
	List<PerfectionTask> findByWorkItemAndTaskStatusIn(WorkItem workItem, List<String> taskStatus);
	
	List<PerfectionTask> findByWorkItemAndWorkflowStepAndTaskStatusIn(WorkItem workItem , String workflowStep, List<String> taskStatus);   
	
	List<PerfectionTask> findByWorkItemAndWorkflowStepInAndTaskStatusIn(WorkItem workItem , List<String> workFlowSteps, List<String> taskStatus);   

	List<PerfectionTask> findByWorkItemAndWorkflowStepAndTaskStatus(WorkItem workItem , String workFlowStep, String taskStatus);	                            
	
	Long countByWorkItemInAndWorkflowStepAndTaskStatus(Collection<WorkItem> workItem , String workFlowStep, String taskStatus);

	@Query("select perfectionTask from PerfectionTask perfectionTask where perfectionTask.workflowStep not in('Completed') and perfectionTask.taskStatus not in ('CLOSED') and ((perfectionTask.eodJobLastUpdated is null or trunc(perfectionTask.eodJobLastUpdated) < (select trunc(referencDate) from ReferenceDate where name='APP_REFERENCE_DATE')))")
	List<PerfectionTask> findAllActivePerfectionTasks();

	@Query("select perfectionTask from PerfectionTask perfectionTask where perfectionTask.taskStatus='TRANSIENT' and trunc(perfectionTask.wakeUpDate) <= (select trunc(referencDate) from ReferenceDate where name='APP_REFERENCE_DATE') and perfectionTask.workflowStep=?1")
	List<PerfectionTask> findTransientTasksWakeUpDateBeforeToday(String workflowStep);
	
	@Query("select perfectionTask from PerfectionTask perfectionTask where perfectionTask.workflowStep not in('Completed') and perfectionTask.taskStatus not in ('CLOSED') and trunc(perfectionTask.wakeUpDate) <= (select trunc(referencDate) from ReferenceDate where name='APP_REFERENCE_DATE') and perfectionTask.workflowStep=?1")
	List<PerfectionTask> findAllActivePerfectionTasksByWorkflowStep(String workflowStep);
}
