package com.jpmorgan.cib.wlt.ctrac.dao.model;

import java.util.Date;

public interface SortableByDocumentDate {

    public Date getDocumentDate();
}
