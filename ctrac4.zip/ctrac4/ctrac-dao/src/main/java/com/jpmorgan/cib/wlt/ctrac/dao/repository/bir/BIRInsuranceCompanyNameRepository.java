package com.jpmorgan.cib.wlt.ctrac.dao.repository.bir;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRInsuranceCompanyName;

public interface BIRInsuranceCompanyNameRepository extends JpaRepository<BIRInsuranceCompanyName, Long> {

	@Cacheable(value = "insuranceCompanyNamesCache")
	List<BIRInsuranceCompanyName> findByActiveOrderByApprovedInsuranceCompanyNameAsc(String active);
	
}
