package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AlthansBatchItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;

@Entity
@Table(name="TLCP_LP_POLICY_REQUEST")
public class LPPolicyRequest extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "lpPolicyReqSeqGenerator")
	@TableGenerator(name = "lpPolicyReqSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", 
	pkColumnValue = "TLCP_LP_POLICY_REQUEST", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name="RID")
	private Long rid;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PROOF_OF_COVERAGE_RID", referencedColumnName = "RID", nullable = true)
	private ProofOfCoverage proofOfCoverage;
	
	@OneToOne(fetch = FetchType.LAZY, cascade=CascadeType.PERSIST)
	@JoinColumn(name = "LENDER_PLACE_ITEM_RID", referencedColumnName = "RID", nullable = true)
	private LenderPlaceItem lenderPlaceItem;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ALTHANS_BATCH_ITEM_RID", referencedColumnName = "RID", nullable = true)
	private AlthansBatchItem althansBatchItem;
	
	@Column(name="REPORT_DATE")
	private Date reportDate;
		
	@Column(name="REQUESTOR_NAME")
	private String requestorName;
	
	@Column(name="REQUESTOR_EMAIL_ADDRESS")
	private String requestorEmailAddress;
	
	@Column(name="LENDER_BRANCH_CODE")
	private String lenderBranchCode;
	
	@Column(name="LOAN_NUMBER")
	private String loanNumber;	
	
	@Column(name="TRANS_CODE")
	private String transCode;	
	
	@Column(name="STATUS_ID")
	private String statusId;
	
	@Column(name="EFFECTIVE_DATE")
	private Date effectiveDate;	
	
	@Column(name="EXPIRATION_DATE")
	private Date expirationDate;	
	
	@Column(name="CANCELLATION_EFFECTIVE_DATE")
	private Date cancellationEffectiveDate;	
	
	@Column(name="MORT_BORROWER_NAME")
	private String mortgagorAndBorrowerName;
	
	@Column(name="MAILING_ADDRESS")
	private String mailingAddress;
	
	@Column(name="MAILING_UNIT_BLDG")
	private String mailingUnitBldg;
	
	@Column(name="MAILING_CITY")
	private String mailingCity;
	
	@Column(name="MAILING_STATE")
	private String mailingState;
	
	@Column(name="MAILING_ZIPCODE")
	private String mailingZipCode;
	
	@Column(name="ADDL_BORROWERS_AND_OWNERS")
	private String addlBorrowersAndOwners;
	
	@Column(name="BUILDING_NAME")
	private String buildingName;
	
	@Column(name="PROPERTY_ADDRESS")
	private String propertyAddress;

	@Column(name = "PROPERTY_CITY")
	private String propertyCity;
	
	@Column(name = "PROPERTY_STATE")
	private String propertyState;
	
	@Column(name = "PROPERTY_ZIPCODE")
	private String propertyZipCode;
	
	@Column(name = "PROPERTY_UNIT_BLDG")
	private String propertyUnitBldg;

	@Column(name="PROPERTY_TYPE")
	private String propertyType;
	
	@Column(name="BUILDING_CONTENTS_COV")
	private String buildingContentsCoverage;
	
	@Column(name="SPECIAL_PROCESSING")
	private String specialProcessing;
	
	@Column(name="COVERAGE_TYPE")
	private String coverageType;
	
	@Column(name="BUILDING_COVERAGE_AMT")
	private String buildingCoverageAmount;
	
	@Column(name="CONTENT_COVERAGE_AMT")
	private String contentsCoverageAmount;
	
	@Column(name = "BUSINESS_INC_COVERAGE_AMT")
	private String businessCoverageAmount;
	
	@Column(name="VALUE_BASED_ON")
	private String valueBasedOn;
	
	@Column(name="FLOOD_ZONE")
	private String floodZone;
	
	@Column(name="COMMENTS")
	private String comments;
	
	@Column(name="ITEM_SENT_DATE")
	private Date itemSentDate;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}

	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	public LenderPlaceItem getLenderPlaceItem() {
		return lenderPlaceItem;
	}

	public void setLenderPlaceItem(LenderPlaceItem lenderPlaceItem) {
		this.lenderPlaceItem = lenderPlaceItem;
	}

	public AlthansBatchItem getAlthansBatchItem() {
		return althansBatchItem;
	}

	public void setAlthansBatchItem(AlthansBatchItem althansBatchItem) {
		this.althansBatchItem = althansBatchItem;
	}

	public Date getReportDate() {
		return reportDate;
	}

	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public String getRequestorEmailAddress() {
		return requestorEmailAddress;
	}

	public void setRequestorEmailAddress(String requestorEmailAddress) {
		this.requestorEmailAddress = requestorEmailAddress;
	}

	public String getLenderBranchCode() {
		return lenderBranchCode;
	}

	public void setLenderBranchCode(String lenderBranchCode) {
		this.lenderBranchCode = lenderBranchCode;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	public String getStatusId() {
		return statusId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Date getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}

	public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}

	public String getMortgagorAndBorrowerName() {
		return mortgagorAndBorrowerName;
	}

	public void setMortgagorAndBorrowerName(String mortgagorAndBorrowerName) {
		this.mortgagorAndBorrowerName = mortgagorAndBorrowerName;
	}

	public String getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	public String getMailingUnitBldg() {
		return mailingUnitBldg;
	}

	public void setMailingUnitBldg(String mailingUnitBldg) {
		this.mailingUnitBldg = mailingUnitBldg;
	}

	public String getMailingCity() {
		return mailingCity;
	}

	public void setMailingCity(String mailingCity) {
		this.mailingCity = mailingCity;
	}

	public String getMailingState() {
		return mailingState;
	}

	public void setMailingState(String mailingState) {
		this.mailingState = mailingState;
	}

	public String getMailingZipCode() {
		return mailingZipCode;
	}

	public void setMailingZipCode(String mailingZipCode) {
		this.mailingZipCode = mailingZipCode;
	}

	public String getAddlBorrowersAndOwners() {
		return addlBorrowersAndOwners;
	}

	public void setAddlBorrowersAndOwners(String addlBorrowersAndOwners) {
		this.addlBorrowersAndOwners = addlBorrowersAndOwners;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public String getPropertyCity() {
		return propertyCity;
	}

	public void setPropertyCity(String propertyCity) {
		this.propertyCity = propertyCity;
	}

	public String getPropertyState() {
		return propertyState;
	}

	public void setPropertyState(String propertyState) {
		this.propertyState = propertyState;
	}

	public String getPropertyZipCode() {
		return propertyZipCode;
	}

	public void setPropertyZipCode(String propertyZipCode) {
		this.propertyZipCode = propertyZipCode;
	}

	public String getPropertyUnitBldg() {
		return propertyUnitBldg;
	}

	public void setPropertyUnitBldg(String propertyUnitBldg) {
		this.propertyUnitBldg = propertyUnitBldg;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public String getBuildingContentsCoverage() {
		return buildingContentsCoverage;
	}

	public void setBuildingContentsCoverage(String buildingContentsCoverage) {
		this.buildingContentsCoverage = buildingContentsCoverage;
	}

	public String getSpecialProcessing() {
		return specialProcessing;
	}

	public void setSpecialProcessing(String specialProcessing) {
		this.specialProcessing = specialProcessing;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getBuildingCoverageAmount() {
		return buildingCoverageAmount;
	}

	public void setBuildingCoverageAmount(String buildingCoverageAmount) {
		this.buildingCoverageAmount = buildingCoverageAmount;
	}

	public String getContentsCoverageAmount() {
		return contentsCoverageAmount;
	}

	public void setContentsCoverageAmount(String contentsCoverageAmount) {
		this.contentsCoverageAmount = contentsCoverageAmount;
	}

	public String getValueBasedOn() {
		return valueBasedOn;
	}

	public void setValueBasedOn(String valueBasedOn) {
		this.valueBasedOn = valueBasedOn;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getItemSentDate() {
		return itemSentDate;
	}

	public void setItemSentDate(Date itemSentDate) {
		this.itemSentDate = itemSentDate;
	}

	public String getBusinessCoverageAmount() {
		return businessCoverageAmount;
	}

	public void setBusinessCoverageAmount(String businessCoverageAmount) {
		this.businessCoverageAmount = businessCoverageAmount;
	}
	
}
