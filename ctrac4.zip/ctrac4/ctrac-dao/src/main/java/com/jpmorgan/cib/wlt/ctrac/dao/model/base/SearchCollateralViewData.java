package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name = "VLCP_COLLATERAL_DETAILS_NEW")
public class SearchCollateralViewData {
	@Id
	@OrderBy("COLLATERAL_RID ASC")
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "COLLATERAL_ID")
	private String collateralId;

	@Column(name = "COLLATERAL_TYPE_DESC")
	private String collateralType;

	@Column(name = "PROPERTY_ADDRESS")
	private String propertyAddress;

	@Column(name = "PROPERTY_CITY")
	private String propertyCity;
	
	@Column(name = "PROPERTY_ZIP_CODE")
	private String propertyZipCode;
	
	@Column(name = "PROPERTY_STATE")
	private String propertyState;
	
	@Column(name = "PROPERTY_COUNTY")
	private String propertyCounty;

	@Column(name = "PROPERTY_FLOOD_ZONE")
	private String floodZone;
	
	@Column(name = "REMAP_CATEGORY")
	private String remapCategory;
	
	@Column(name = "PROPERTY_OWNER_NAME")
	private String ownerName;
	
	@Column(name = "PROPERTY_TYPE")
	private String propertyType;
	
	@Column(name = "LOAN_NUMBER")
	private String loanNumber;
	
	@Column(name = "LINE_OF_BUSINESS")
	private String lineOfBusiness;
	
	@Column(name = "LOAN_ACCOUNTING_SYSTEM")
	private String loanAccountingSystem;
	
	@Column(name = "BORROWER_NAME")
	private String borrowerName;
	
	@Column(name = "INSURED_NAME")
	private String insuredName;
	
	/***
	@Column(name = "BORROWER_NUMBER")
	private String borrowerNumber;
	
	@Column(name = "BORROWER_ADDRESS")
	private String borrowerAddress;
	
	@Column(name = "BORROWER_CITY")
	private String borrowerCity;
	
	@Column(name = "BORROWER_ZIP_CODE")
	private String borrowerZipCode;
	
	@Column(name = "BORROWER_STATE")
	private String borrowerState;
	***/
	
	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public String getPropertyCity() {
		return propertyCity;
	}

	public void setPropertyCity(String propertyCity) {
		this.propertyCity = propertyCity;
	}

	public String getPropertyZipCode() {
		return propertyZipCode;
	}

	public void setPropertyZipCode(String propertyZipCode) {
		this.propertyZipCode = propertyZipCode;
	}

	public String getPropertyState() {
		return propertyState;
	}

	public void setPropertyState(String propertyState) {
		this.propertyState = propertyState;
	}

	public String getPropertyCounty() {
		return propertyCounty;
	}

	public void setPropertyCounty(String propertyCounty) {
		this.propertyCounty = propertyCounty;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getRemapCategory() {
		return remapCategory;
	}

	public void setRemapCategory(String remapCategory) {
		this.remapCategory = remapCategory;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getLoanAccountingSystem() {
		return loanAccountingSystem;
	}

	public void setLoanAccountingSystem(String loanAccountingSystem) {
		this.loanAccountingSystem = loanAccountingSystem;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	/***
	public String getBorrowerNumber() {
		return borrowerNumber;
	}

	public void setBorrowerNumber(String borrowerNumber) {
		this.borrowerNumber = borrowerNumber;
	}

	public String getBorrowerAddress() {
		return borrowerAddress;
	}

	public void setBorrowerAddress(String borrowerAddress) {
		this.borrowerAddress = borrowerAddress;
	}

	public String getBorrowerCity() {
		return borrowerCity;
	}

	public void setBorrowerCity(String borrowerCity) {
		this.borrowerCity = borrowerCity;
	}

	public String getBorrowerZipCode() {
		return borrowerZipCode;
	}

	public void setBorrowerZipCode(String borrowerZipCode) {
		this.borrowerZipCode = borrowerZipCode;
	}

	public String getBorrowerState() {
		return borrowerState;
	}

	public void setBorrowerState(String borrowerState) {
		this.borrowerState = borrowerState;
	}
***/
	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getCollateralId() {
		return collateralId;
	}

	public void setCollateralId(String collateralId) {
		this.collateralId = collateralId;
	}
	

}
