package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_SEARCH_ENTITIES")
public class EntitySearchViewData {

	@Id
	@Column(name="ROW_NUM")
	private Long id;

	@Column(name = "RID")
	private Long rid;

	@Column(name="NAME")
	private String name;

	@Column(name="ADDRESS")
	private String address;

	@Column(name="COUNTY")
	private String county;

	@Column(name="CITY")
	private String city;

	@Column(name="STATE_ABBR")
	private String state;

	@Column(name="ZIP_CODE")
	private String zipcode;

	@Column(name="UNIT_BLNG")
	private String unitBlng;

	@Column(name="COLLATERAL_RIDS")
	private String collateralRids;



	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getUnitBlng() {
		return unitBlng;
	}

	public void setUnitBlng(String unitBlng) {
		this.unitBlng = unitBlng;
	}

	public String getCollateralRids() {
		return collateralRids;
	}

	public void setCollateralRids(String collateralRids) {
		this.collateralRids = collateralRids;
	}

	

}
