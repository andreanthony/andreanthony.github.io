package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ParentPolicyDetailsViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ParentPolicyDetailsViewDataPK;

public interface ParentPolicyDetailsRepository extends JpaRepository<ParentPolicyDetailsViewData, ParentPolicyDetailsViewDataPK> {
	
	@Query("select pol from ParentPolicyDetailsViewData pol where pol.parentPolicyRid=?1")
	List<ParentPolicyDetailsViewData> findAllByParentPolicyRid(Long parentPolicyRid);
	
}
