package com.jpmorgan.cib.wlt.ctrac.dao.model.bir;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Address;

@Entity
@Table(name = "TLCP_BIR_COLLATERAL_DETAILS")
public class BIRCollateralDetails {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "birCollateralDetailsSeqGenerator")
	@TableGenerator(name = "birCollateralDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BIR_COLLATERAL_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "BIR_PROOF_OF_COV_DETAILS_RID")
	private Long borrowerInsuranceReviewDetailsRid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "POLICY_STATUS")
	private String policyStatus;
	
	@OneToOne
	@JoinColumn(name = "POLICY_ADDRESS_RID")
	private Address policyAddress;
	
	@Column(name = "POLICY_FLOOD_ZONE")
	private String policyFloodZone;
	
	@Column(name = "GRANDFATHERED")
	private String grandfathered;
	
	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "birCollateralDetailsRid")
	private List<BIRInsurableAssetDetails> allBIRInsurableAssetDetails = new ArrayList<BIRInsurableAssetDetails>();

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getBorrowerInsuranceReviewDetailsRid() {
		return borrowerInsuranceReviewDetailsRid;
	}

	public void setBorrowerInsuranceReviewDetailsRid(Long borrowerInsuranceReviewDetailsRid) {
		this.borrowerInsuranceReviewDetailsRid = borrowerInsuranceReviewDetailsRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public Address getPolicyAddress() {
		return policyAddress;
	}

	public void setPolicyAddress(Address policyAddress) {
		this.policyAddress = policyAddress;
	}

	public String getPolicyFloodZone() {
		return policyFloodZone;
	}

	public void setPolicyFloodZone(String policyFloodZone) {
		this.policyFloodZone = policyFloodZone;
	}

	public String getGrandfathered() {
		return grandfathered;
	}

	public void setGrandfathered(String grandfathered) {
		this.grandfathered = grandfathered;
	}
	
	public List<BIRInsurableAssetDetails> getAllBIRInsurableAssetDetails() {
		return allBIRInsurableAssetDetails;
	}

	public void setAllBIRInsurableAssetDetails(List<BIRInsurableAssetDetails> allBIRInsurableAssetDetails) {
		this.allBIRInsurableAssetDetails = allBIRInsurableAssetDetails;
	}
	
}
