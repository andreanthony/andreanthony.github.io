package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LPPolicyRequest;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AlthansBatchItem;


public interface LPPolicyRequestRepository extends JpaRepository<LPPolicyRequest, Long>{
	
	List<LPPolicyRequest> findByItemSentDate(Date itemSendDate);
	
	List<LPPolicyRequest> findByProofOfCoverage(ProofOfCoverage proofOfCoverage);
	
	List<LPPolicyRequest> findByAlthansBatchItem(AlthansBatchItem item);
	
	List<LPPolicyRequest> findByAlthansBatchItemRid(Long rid);
	
	List<LPPolicyRequest> findByAlthansBatchItemRidAndProofOfCoverage(Long batchItemRid, ProofOfCoverage proofOfCoverage);
	
}
