package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CollateralOwner;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;

public interface CollateralOwnerRepository extends JpaRepository<CollateralOwner, Long> {

	
	public List<CollateralOwner> findByCollateralRid(Long rid);
	public List<CollateralOwner> findByOwnerRid(Long rid);
	public List<CollateralOwner> findByOwner(Customer owner);
	public CollateralOwner findByCollateralAndOwner(Collateral collateral, Customer owner);
	
	
}
