package com.jpmorgan.cib.wlt.ctrac.dao.repository.event.store;

import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.CtracEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface CtracEventRepository extends JpaRepository<CtracEvent, Long> {

	CtracEvent findByEventUuid(UUID eventUuid);

}
