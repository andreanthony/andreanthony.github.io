package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AccountWireReference;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;



public interface AccountWireReferenceRepository extends JpaRepository<AccountWireReference, Long> {

	public List <AccountWireReference> findAllAccountWireReferenceByWorkItem(WorkItem workItem);
	
	public List <AccountWireReference> findByWorkItemAndAccountingSysRef(WorkItem workItem, String accountingSysRef);

}



