package com.jpmorgan.cib.wlt.ctrac.dao.repository.bir;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRInsurableAssetDetails;

public interface BIRInsurableAssetDetailsRepository extends JpaRepository<BIRInsurableAssetDetails, Long> {
	
	List<BIRInsurableAssetDetails> findByBirCollateralDetailsRid(Long birCollateralDetailsRid);
	
}
