package com.jpmorgan.cib.wlt.ctrac.dao.repository.external;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.external.ServiceLinkFloodRemap;

public interface ServiceLinkFloodRemapRepository extends JpaRepository<ServiceLinkFloodRemap, Long>{	
	public List<ServiceLinkFloodRemap> findByDataProcessingStatus(String datapProcessingStatus);
	
	@Query("select MAX(insertedDate) from ServiceLinkFloodRemap")
    public Date findMaxInsertedDate();
}