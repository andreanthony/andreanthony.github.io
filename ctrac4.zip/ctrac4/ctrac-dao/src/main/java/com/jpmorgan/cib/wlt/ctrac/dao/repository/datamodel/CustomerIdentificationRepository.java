package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CustomerIdentificationViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CustomerIdentificationViewDataPK;

public interface CustomerIdentificationRepository extends JpaRepository<CustomerIdentificationViewData, CustomerIdentificationViewDataPK> {
	
	List<CustomerIdentificationViewData> findByCollateralRid(Long collateralRid);
    
}
