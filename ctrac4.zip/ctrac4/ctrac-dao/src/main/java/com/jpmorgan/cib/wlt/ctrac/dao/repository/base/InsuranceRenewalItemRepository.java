package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.InsuranceRenewalItem;

public interface InsuranceRenewalItemRepository extends JpaRepository<InsuranceRenewalItem, Long> {
	
	public InsuranceRenewalItem findByRid(Long rid);

}
