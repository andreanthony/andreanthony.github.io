package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store;

import com.jpmorgan.cib.wlt.ctrac.auth.AuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.mapper.CtracEventMapper;
import com.jpmorgan.cib.wlt.ctrac.dao.repository.event.store.CtracEventRepository;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.EventStoreException;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventSubscriberDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonParser;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonPoster;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonPosterFactory;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.net.ssl.SSLContext;
import java.util.*;

@Service
public class EventStoreImpl implements EventStore {

	private static final Logger logger = LoggerFactory.getLogger(EventStoreImpl.class);

	@Value("${ctrac.audit.api.url}")
	private String auditApiUrl;

	private final Map<String, List<String>> subscriptionsByEventType;

	private AuthenticationManager authManager;
	private CtracEventMapper eventMapper;
	private CtracEventRepository eventRepository;
	private TrustStoreManagerService trustStoreManagerService;

	@Autowired
	public EventStoreImpl(CtracEventMapper eventMapper, CtracEventRepository eventRepository,
	                      TrustStoreManagerService trustStoreManagerService, AuthenticationManager authManager) {
		assert(eventMapper != null);
		this.eventMapper = eventMapper;
		assert(eventRepository != null);
		this.eventRepository = eventRepository;
		subscriptionsByEventType = new HashMap<>();
		this.trustStoreManagerService = trustStoreManagerService;
		this.authManager = authManager;
	}

	@PostConstruct
	void init() {
		internalSubscribe(Collections.singletonList(new CtracEventSubscriberDTO(
				CollateralEventType.getAllSubscriberEvents(), auditApiUrl)));
	}

	@Override
	public void subscribe(List<CtracEventSubscriberDTO> subscriptions) {
		internalSubscribe(subscriptions);
	}

	private void internalSubscribe(List<CtracEventSubscriberDTO> subscriptions) {
		logger.debug("adding subscription: {}", StringUtils.join(subscriptions, ", "));
		for (CtracEventSubscriberDTO subscription : subscriptions) {
			List<String> eventTypes = subscription.getEventTypes();
			for (String eventType : eventTypes) {
				List<String> apisForEventType = subscriptionsByEventType.get(eventType);
				if (apisForEventType == null) {
					apisForEventType = new ArrayList<>();
					subscriptionsByEventType.put(eventType, apisForEventType);
				}
				apisForEventType.add(subscription.getApi());
			}
		}
	}

	@Override
	public void receive(String eventAttributes) {
		logger.debug("received event; reading and saving: {}", eventAttributes);
		CtracEventDTO eventDTO = EventJsonParser.parseCtracEvent(eventAttributes);
		EventJsonParser.validateCtracEvent(eventDTO);
		CtracEvent ctracEvent = eventRepository.findByEventUuid(eventDTO.getEventUuid());
		if (ctracEvent == null) {
			ctracEvent = eventMapper.map(eventDTO, CtracEvent.class);
		} else {
			eventMapper.map(eventDTO, ctracEvent);
		}
		ctracEvent.setLastPublishTime(new Date());
		eventRepository.save(ctracEvent);
		logger.debug("saved");
	}

	@Override
	public void publish(CtracEvent event) {
		List<String> subscribers = subscriptionsByEventType.get(event.getEventType());
		if (subscribers == null) {
			logger.debug("publishing skipped: No subscribers");
			return;
		}
		logger.debug("publishing to: {}", StringUtils.join(subscribers, ", "));
		SSLContext sslContext = trustStoreManagerService.getTrustStoreManager().getSSLContext();
		for (String subscriber : subscribers) {
			EventJsonPoster poster = EventJsonPosterFactory.create(subscriber, sslContext, authManager);
			try {
				boolean isAsyncPost = false;
				poster.post(event.getEventJson(), authManager.getAuthenticationToken(), isAsyncPost);
			} catch (EventStoreException ex) {
				logger.error("Publishing to subscriber {} failed", subscriber, ex);
			}
		}
	}

	Map<String, List<String>> getSubscriptions() {
		Map<String, List<String>> immutableSubscriptions = new HashMap<>();
		for (Map.Entry<String, List<String>> entry : subscriptionsByEventType.entrySet()) {
			immutableSubscriptions.put(entry.getKey(), Collections.unmodifiableList(entry.getValue()));
		}
		return Collections.unmodifiableMap(immutableSubscriptions);
	}

	void setSubscriptions(Map<String, List<String>> subscriptions) {
		subscriptionsByEventType.clear();
		for (Map.Entry<String, List<String>> entry : subscriptions.entrySet()) {
			List<String> apis = new ArrayList<>();
			apis.addAll(entry.getValue());
			subscriptionsByEventType.put(entry.getKey(), apis);
		}
	}

	void setAuditApiUrl(String auditApiUrl) {
		this.auditApiUrl = auditApiUrl;
	}
}
