package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.io.Serializable;

public class ParentPolicyDetailsViewDataPK implements Serializable {

    private static final long serialVersionUID = -5503954904172446559L;

    public ParentPolicyDetailsViewDataPK() {}
    
    private Long parentPolicyRid;
    
    private Long insurableAssetRid;

	public Long getParentPolicyRid() {
		return parentPolicyRid;
	}

	public void setParentPolicyRid(Long parentPolicyRid) {
		this.parentPolicyRid = parentPolicyRid;
	}

	public Long getInsurableAssetRid() {
		return insurableAssetRid;
	}

	public void setInsurableAssetRid(Long insurableAssetRid) {
		this.insurableAssetRid = insurableAssetRid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((insurableAssetRid == null) ? 0 : insurableAssetRid.hashCode());
		result = prime * result + ((parentPolicyRid == null) ? 0 : parentPolicyRid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParentPolicyDetailsViewDataPK other = (ParentPolicyDetailsViewDataPK) obj;
		if (insurableAssetRid == null) {
			if (other.insurableAssetRid != null)
				return false;
		} else if (!insurableAssetRid.equals(other.insurableAssetRid))
			return false;
		if (parentPolicyRid == null) {
			if (other.parentPolicyRid != null)
				return false;
		} else if (!parentPolicyRid.equals(other.parentPolicyRid))
			return false;
		return true;
	}

}
