package com.jpmorgan.cib.wlt.ctrac.dao.repository.audit;

import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.AuditEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.UUID;

public interface AuditEntryRepository extends JpaRepository<AuditEntry, Long>, JpaSpecificationExecutor<AuditEntry> {

	AuditEntry findByEventUuid(UUID eventUuid);

}
