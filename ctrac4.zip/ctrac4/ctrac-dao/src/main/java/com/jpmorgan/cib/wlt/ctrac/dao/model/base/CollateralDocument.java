package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.io.File;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.apache.commons.io.FilenameUtils;
import org.springframework.web.multipart.MultipartFile;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.RequiredCoverageSource;



/**
 * This is a JPA entity class to hold new Collateral Documents i.e SFHDF,FIAT Input file,etc . Remap Data fetched from TLCP_COLLATERAL_DOCUMENTS table.
 * @date 24-Feb-2014
 */

@Entity
@Table(name = "TLCP_COLLATERAL_DOCUMENTS")
public class CollateralDocument extends CtracBaseEntity implements Serializable {

	private static final long serialVersionUID = 3953244370852597669L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "collateralActivityDocSeqGenerator")
	@TableGenerator(name = "collateralActivityDocSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_COLLATERAL_DOCUMENTS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "FILE_NAME")
	private String fileName;
	
	@Column(name = "FILE_NAME_WITH_EXT")
	private String fileNameWithExt;

	@Column(name = "DOC_IDENTIFIER")
	private String docIdentifier;

	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "DOCUMENT_DATE")
	private Date documentDate;

	@Column(name = "PROOF_OF_COVERAGE_RID")
	private Long proofOfCoverageRid;
	
	@ManyToOne //( targetEntity =RequiredCoverageSource.class)
	@JoinColumn(name = "REQUIRED_COVERAGE_SOURCE_RID")
	private RequiredCoverageSource requiredCoverageSource;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "FILE_CONTENT_RID")
	private FileContent fileContent;

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileNameWithExt() {
		return fileNameWithExt;
	}

	public void setFileNameWithExt(String fileNameWithExt) {
		this.fileNameWithExt = fileNameWithExt;
	}
	
	public String getDocIdentifier() {
		return docIdentifier;
	}

	public void setDocIdentifier(String docIdentifier) {
		this.docIdentifier = docIdentifier;
	}

	public Date getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}
	
	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}
	
	/**
	 * @return the requiredCoverageSource
	 */
	public RequiredCoverageSource getRequiredCoverageSource() {
		return requiredCoverageSource;
	}

	/**
	 * @param requiredCoverageSource the requiredCoverageSource to set
	 */
	public void setRequiredCoverageSource(RequiredCoverageSource requiredCoverageSource) {
		this.requiredCoverageSource = requiredCoverageSource;
	}

	public FileContent getFileContent() {
		return fileContent;
	}

	public void setFileContent(FileContent fileContent) {
		this.fileContent = fileContent;
	}

	public void parse(File file) {
		this.setFileNameWithExt(file.getName());
		this.setFileName(FilenameUtils.removeExtension(file.getName()));
	}
	
	public void parse(MultipartFile file) {
		this.setFileNameWithExt(file.getOriginalFilename());
		this.setFileName(FilenameUtils.removeExtension(file.getOriginalFilename()));
	}

}
