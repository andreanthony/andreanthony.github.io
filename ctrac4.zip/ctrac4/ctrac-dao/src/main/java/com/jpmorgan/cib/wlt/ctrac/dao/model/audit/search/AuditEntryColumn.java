package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search;

import java.util.ArrayList;
import java.util.List;

public enum AuditEntryColumn {
    EVENT_TYPE("eventType"),
    EVENT_TIME("eventTime"),
    PERFORMED_BY("performedBy"),
    COLLATERAL_ID("collateralId"),
    IDENTIFIER("identifier"),
    LINE_OF_BUSINESS("lineOfBusiness"),
    COLLATERAL_SECTION("collateralSection"),
    DESCRIPTION("description"),
    TASK_NAME("taskName");

    private String columnName;

    AuditEntryColumn(String columnName) {
        this.columnName = columnName;
    }

    public static final String[] COLUMN_NAMES = new String[AuditEntryColumn.values().length];
    static {
        List<String> columnNames = new ArrayList<>();
        for (AuditEntryColumn column : AuditEntryColumn.values()) {
            columnNames.add(column.columnName);
        }
        columnNames.toArray(COLUMN_NAMES);
    }

    public String getColumnName() {
        return columnName;
    }
}
