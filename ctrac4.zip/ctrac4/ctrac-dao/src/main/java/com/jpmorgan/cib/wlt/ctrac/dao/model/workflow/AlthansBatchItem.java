package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_ALTHANS_BATCH_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class AlthansBatchItem extends WorkItem {
		
	@Column(name = "FILE_NAME")
	private String fileName;
	
	@Column(name = "REQUEST_SENT_DATE")
	private Date requestSentDate;
	
	@Column(name = "RESPONSE_PROCESSED_DATE")
	private Date responseProcessedDate;
	
	@Column(name = "CERTIFICATES_PROCESSED_DATE")
	private Date certificatesProcessedDate;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Date getRequestSentDate() {
		return requestSentDate;
	}

	public void setRequestSentDate(Date requestSentDate) {
		this.requestSentDate = requestSentDate;
	}

	public Date getResponseProcessedDate() {
		return responseProcessedDate;
	}

	public void setResponseProcessedDate(Date responseProcessedDate) {
		this.responseProcessedDate = responseProcessedDate;
	}

	public Date getCertificatesProcessedDate() {
		return certificatesProcessedDate;
	}

	public void setCertificatesProcessedDate(Date certificatesProcessedDate) {
		this.certificatesProcessedDate = certificatesProcessedDate;
	}

}
