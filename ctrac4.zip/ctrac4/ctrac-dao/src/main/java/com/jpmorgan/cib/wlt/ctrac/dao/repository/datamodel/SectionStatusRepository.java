package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.SectionStatus;

public interface SectionStatusRepository extends JpaRepository<SectionStatus, Long>{
	
	List<SectionStatus> findByCollateral(Collateral collateral);
	
	List<SectionStatus> findByCollateralRid(Long rid);
		
	SectionStatus findByCollateralRidAndSectionId(Long collateralRid, String sectionId);
	
	List<SectionStatus> findByCollateralRidAndSectionIdIn(Long collateralRid, Set<String> sectionIds);
	
}
