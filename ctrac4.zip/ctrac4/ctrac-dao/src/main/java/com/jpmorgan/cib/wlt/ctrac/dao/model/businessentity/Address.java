package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.CtracStringUtil;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

@Entity
@Table(name = "TLCP_ADDRESS")
public class Address extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "addressSeqGenerator")
	@TableGenerator(name = "addressSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_ADDRESS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "UNIT_BLNG")
	private String unitOrBuilding;
	
	@Column(name = "ADDRESS")
	private String address;
	
	@Column(name = "CITY")
	private String city;
	
	@Column(name = "ZIP_CODE")
	private String zipCode;
	
	@Column(name = "STATE_ABBR")
	private String state;
	
	@Column(name = "COUNTY")
	private String county;
	
	@Column(name = "VERIFIED_DATE")
	private Date verifiedDate;

	public String getStreetAddressAndUnit() {
		StringBuffer sb = new StringBuffer();
		CtracStringUtil.addValueWithSeparator(sb, address, "");
		CtracStringUtil.addValueWithSeparator(sb, unitOrBuilding, ", ");
		return sb.toString();
	}
	
	public String getCityStateZipCode() {
		StringBuffer sb = new StringBuffer();
		CtracStringUtil.addValueWithSeparator(sb, city, "");
		CtracStringUtil.addValueWithSeparator(sb, state, ", ");
		CtracStringUtil.addValueWithSeparator(sb, zipCode, " ");
		return sb.toString();
	}
	
	public String getFormattedFullAddress() {
		StringBuffer sb = new StringBuffer();
		CtracStringUtil.addValueWithSeparator(sb, getStreetAddressAndUnit(), "");
		CtracStringUtil.addValueWithSeparator(sb, getCityStateZipCode(), ", ");
		return sb.toString();
	}
	
	public Long getRid() {
		return rid;
	}
	
	public void setRid(Long rid) {
		this.rid = rid;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getZipCode() {
		return zipCode;
	}
	
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	public String getCounty() {
		return county;
	}
	
	public void setCounty(String county) {
		this.county = county;
	}

	public String getUnitOrBuilding() {
		return unitOrBuilding;
	}
	
	public void setUnitOrBuilding(String unitOrBuilding) {
		this.unitOrBuilding = unitOrBuilding;
	}

	public String toHTML() {
		StringBuffer sb = new StringBuffer();
		CtracStringUtil.addValueWithSeparator(sb, getStreetAddressAndUnit(), "<br/>");
		CtracStringUtil.addValueWithSeparator(sb, getCityStateZipCode(), "<br/>");
		return sb.toString();
	}

	public Date getVerifiedDate() {
		return verifiedDate;
	}

	public void setVerifiedDate(Date verifiedDate) {
		this.verifiedDate = verifiedDate;
	}
	
}
