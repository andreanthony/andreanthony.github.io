package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.RequiredCoverageViewData;

public interface RequiredCoverageViewRepository extends JpaRepository<RequiredCoverageViewData,Long>{
	
	RequiredCoverageViewData findByCollateralRidAndInsurableAssetRidAndStatus(Long collateralRid,Long insurableAssetRid, String status);
	
	@Query("from RequiredCoverageViewData where collateralRid=? and assetSortOrder=? and assetType='STRUCTURE' and status='VERIFIED'")
	RequiredCoverageViewData findBuildingByCollateralRidAndAssetSortOrder(Long collateralRid, Long assetSortOrder);
	
	List<RequiredCoverageViewData> findByCollateralRidAndStatus(Long collateralRid, String status);

	List<RequiredCoverageViewData> getRequiredCoverageViewDataByRequiredCoverageRid(Long requiredCoverageRid);

}
