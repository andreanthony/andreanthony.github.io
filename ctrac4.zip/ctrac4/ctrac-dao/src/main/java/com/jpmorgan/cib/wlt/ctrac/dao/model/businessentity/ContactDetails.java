package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

/**
 * This is a JPA entity class to hold address  table.
 *  @author I031731
 */
@Entity
@Table(name = "TLCP_CONTACT_DETAILS")
public class ContactDetails extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "contactDetailsSeqGenerator")
	@TableGenerator(name = "contactDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_CONTACT_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@OneToOne(cascade = {CascadeType.PERSIST}, orphanRemoval=true)
	@JoinColumn(name = "ADDRESS_ID")
	private Address mailingAddress;   //TODO @Chrs rename to just address; could be mailing or physical 
	
	@Column(name = "PHONE_NUMBER")
	private String phoneNumber;
	
	@Column(name = "EMAIL_ADDRESS")
	private String emailAddress;
	
	@Column(name = "FAX_NUMBER")
	private String faxNumber;
	
	public Long getRid() {
		return rid;
	}
	
	public void setRid(Long rid) {
		this.rid = rid;
	}
	
	public Address getMailingAddress() {
		return mailingAddress;
	}
	
	public void setMailingAddress(Address mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getEmailAddress() {
		return emailAddress;
	}
	
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	
}
