package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;


import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Groups;


public interface GroupsRepository extends JpaRepository<Groups, Long>{

    public Groups findByGroupNameAndCategoryName(String groupName, String category);
	
}



