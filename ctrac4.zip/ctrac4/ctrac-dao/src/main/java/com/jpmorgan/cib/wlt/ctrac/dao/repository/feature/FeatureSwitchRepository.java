package com.jpmorgan.cib.wlt.ctrac.dao.repository.feature;

import com.jpmorgan.cib.wlt.ctrac.dao.model.feature.FeatureSwitch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeatureSwitchRepository extends JpaRepository<FeatureSwitch, Long> {

}
