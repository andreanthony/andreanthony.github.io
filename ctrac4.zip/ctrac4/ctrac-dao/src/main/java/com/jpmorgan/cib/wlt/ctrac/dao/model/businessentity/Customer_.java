package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;


@StaticMetamodel(Customer.class)
public class Customer_ {

	public static volatile SingularAttribute<Customer, String> name;
	
}
