package com.jpmorgan.cib.wlt.ctrac.dao.repository.bir;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BorrowerInsuranceReviewDetails;

public interface BorrowerInsuranceReviewDetailsRepository extends JpaRepository<BorrowerInsuranceReviewDetails, Long> {

	BorrowerInsuranceReviewDetails findByProofOfCoverageRid(Long proofOfCoverageRid);
	
	List<BorrowerInsuranceReviewDetails> findDistinctByAllBIRCollateralDetailsCollateralRid(Long collateralRid);
	
}
