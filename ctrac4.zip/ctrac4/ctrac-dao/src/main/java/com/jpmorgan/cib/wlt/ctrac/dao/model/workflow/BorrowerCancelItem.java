package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_BORROWER_CANCEL_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class BorrowerCancelItem extends WorkItem {

	@Column(name = "COVERAGE_REQUEST_TASK_RID")
	private Long coverageRequestTaskRid;
	    
    
    public Long getCoverageRequestTaskRid() {
		return coverageRequestTaskRid;
	}

	public void setCoverageRequestTaskRid(Long coverageRequestTaskRid) {
		this.coverageRequestTaskRid = coverageRequestTaskRid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((coverageRequestTaskRid == null) ? 0 : coverageRequestTaskRid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		BorrowerCancelItem other = (BorrowerCancelItem) obj;
		if (coverageRequestTaskRid == null) {
			if (other.coverageRequestTaskRid != null)
				return false;
		} else if (!coverageRequestTaskRid.equals(other.coverageRequestTaskRid))
			return false;
		return true;
	}

}
