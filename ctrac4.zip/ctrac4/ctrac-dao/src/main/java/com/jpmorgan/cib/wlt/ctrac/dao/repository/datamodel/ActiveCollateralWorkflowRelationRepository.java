package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ActiveCollateralWorkflowRelation;

public interface ActiveCollateralWorkflowRelationRepository extends JpaRepository<ActiveCollateralWorkflowRelation, Long> {

	public List<ActiveCollateralWorkflowRelation> findByTaskId(String taskId);
	public List<ActiveCollateralWorkflowRelation> findByCollateral(Collateral collateral);
	public List<ActiveCollateralWorkflowRelation> findByCollateralRid(Long collateralRid);
	public List<ActiveCollateralWorkflowRelation> findByCollateralRidAndTaskWorkflowStepIn(Long collateralRid, Collection<String> workflowStep);
	public List<ActiveCollateralWorkflowRelation> findByCollateralRidAndWorkItemPerfectionType(Long collateralRid, String perfectionType);
	public List<ActiveCollateralWorkflowRelation> findByCollateralAndTaskWorkflowStep(Collateral collateral, String taskWorkflowStep);
}
