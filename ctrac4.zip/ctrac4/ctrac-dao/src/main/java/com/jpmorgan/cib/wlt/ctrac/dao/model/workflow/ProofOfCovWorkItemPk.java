package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

public class ProofOfCovWorkItemPk implements Serializable {

    private static final long serialVersionUID = -609075605348561700L;

    private ProofOfCoverage proofOfCoverage;
   
    private WorkItem workItem;
   
    
    public ProofOfCovWorkItemPk() {
        super();
    }

	/**
	 * @return the proofOfCoverage
	 */
	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((proofOfCoverage == null) ? 0 : proofOfCoverage.hashCode());
		result = prime * result + ((workItem == null) ? 0 : workItem.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProofOfCovWorkItemPk other = (ProofOfCovWorkItemPk) obj;
		if (proofOfCoverage == null) {
			if (other.proofOfCoverage != null)
				return false;
		} else if (!proofOfCoverage.equals(other.proofOfCoverage))
			return false;
		if (workItem == null) {
			if (other.workItem != null)
				return false;
		} else if (!workItem.equals(other.workItem))
			return false;
		return true;
	}

	/**
	 * @return the workItem
	 */
	public WorkItem getWorkItem() {
		return workItem;
	}

	/**
	 * @param proofOfCoverage the proofOfCoverage to set
	 */
	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	/**
	 * @param workItem the workItem to set
	 */
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

}
