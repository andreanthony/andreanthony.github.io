package com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity @Table(name="GROUP_MEMBERS")
@IdClass(value=GroupMemebersPK.class)
public class GroupMembers {

	@Id
	@OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "USER_ID")
	private Users users;

	@Column(name = "USERNAME")
	private String username;
	@Id
	@OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "GROUP_ID")
	private Groups groups;

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
		this.username = users.getUsername();
	}
	
	public String getUsername() {
		return username;
	}

//	public void setUsername(String username) {
//		this.username = username;
//	}

	public Groups getGroups() {
		return groups;
	}

	public void setGroups(Groups groups) {
		this.groups = groups;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupMembers other = (GroupMembers) obj;
		if (users == null) {
			if (other.users != null)
				return false;
		} else if (!users.equals(other.users))
			return false;
		if (groups == null) {
			if (other.groups != null)
				return false;
		} else if (!groups.equals(other.groups))
			return false;
		return true;
	}

	public String getRSAMProfileName() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.getGroups().getCategoryName()).append(" - ").append(this.getGroups().getGroupName());
		return sb.toString();
	}
}
