package com.jpmorgan.cib.wlt.ctrac.dao.repository.bir;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRViewData;

public interface BIRViewDataRepository extends JpaRepository<BIRViewData, Long> {

	@Query("select bir from BIRViewData bir where proofOfCoverageRid=?1 and collateralRid=?2 and rownum=1")
	BIRViewData findTopByPolicyRidAndCollateralRid(Long proofOfCoverageRid, Long collateralRid);
	
}
