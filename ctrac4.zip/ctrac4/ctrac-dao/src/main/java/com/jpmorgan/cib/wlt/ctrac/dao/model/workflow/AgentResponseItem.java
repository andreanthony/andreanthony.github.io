package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemSubType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PerfectionItemType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "TLCP_AGENT_RESPONSE_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class AgentResponseItem extends WorkItem {

	AgentResponseItem(){
		super();
	}

	public AgentResponseItem(PerfectionItemSubType perfectionSubType) {
		super(PerfectionItemType.BORROWER_AGENT_RESPONSE.name(), perfectionSubType.name());
	}
	
	@Column(name = "ITEM_CREATED_DATE")
	private Date itemCreatedDate;
	
	@Column(name = "PROOF_OF_COVERAGE_RID")
	private Long proofOfCoverageRid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "OTM_TASK_REF_ID")
	private String tmTaskRererenceId;
	
	
	public String getTmTaskRererenceId() {
		return tmTaskRererenceId;
	}

	public void setTmTaskRererenceId(String tmTaskRererenceId) {
		this.tmTaskRererenceId = tmTaskRererenceId;
	}

	public Date getItemCreatedDate() {
		return itemCreatedDate;
	}
	
	
	
	public void setItemCreatedDate(Date itemCreatedDate) {
		this.itemCreatedDate = itemCreatedDate;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}
	
	public void addProofOfCoverage(ProofOfCoverage proofOfCoverage, String itemRelType){
		ProofOfCovWorkItem proofOfCovWorkItem = null;
		if(this.proofOfCovWorkItems.isEmpty()){
			proofOfCovWorkItem = new ProofOfCovWorkItem();
			proofOfCovWorkItems.add(proofOfCovWorkItem);
		}
		proofOfCovWorkItem = proofOfCovWorkItems.get(0);
		proofOfCovWorkItem.setWorkItem(this);
		proofOfCovWorkItem.setProofOfCoverage(proofOfCoverage);
		proofOfCovWorkItem.setItemType(itemRelType);
	}	
}