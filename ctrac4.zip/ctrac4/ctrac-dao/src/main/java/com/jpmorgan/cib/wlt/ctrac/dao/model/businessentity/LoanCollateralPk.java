package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;

public class LoanCollateralPk implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Collateral collateral;
	private Loan loan;
	
	public LoanCollateralPk(){}
	
	
	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}


	public Collateral getCollateral() {
		return collateral;
	}


	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}
	

}
