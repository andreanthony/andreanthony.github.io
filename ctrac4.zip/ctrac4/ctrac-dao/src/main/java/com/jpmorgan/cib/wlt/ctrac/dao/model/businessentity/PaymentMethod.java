package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.apache.commons.lang.StringUtils;

@Entity
@Table(name = "TLCP_PAYMENT_METHOD")
public class PaymentMethod {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "paymentMethodSeqGenerator")
	@TableGenerator(name = "paymentMethodSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_PAYMENT_METHOD", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "PAYMENT_METHOD")
	private String paymentMethod;
	
	@Column(name = "PAYMENT_ACCOUNT")
	private String paymentAccount;
	
	@ManyToOne
	@JoinColumn(name = "ADDRESS_RID")
	private Address address;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
    
    public boolean isBlank() {
    	return StringUtils.isBlank(paymentMethod) || (StringUtils.isBlank(paymentAccount) && address == null);
    }

}
