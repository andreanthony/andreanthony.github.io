package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(EntitySearchViewData.class)
public class EntitySearchViewData_ {
	
	public static volatile SingularAttribute<EntitySearchViewData, String> name;
}
