package com.jpmorgan.cib.wlt.ctrac.dao.model.letters;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

/**
 * @author N664895
 *
 */
@Entity
@Table(name = "TLCP_LETTER_FILE")
public class LetterFile extends CtracBaseEntity implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5347829321342180527L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "letterFileSeqGenerator")
	@TableGenerator(name = "letterFileSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_LETTER_FILE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)

		@Id
		@Column(name = "RID")
		private Long rid;		
	
		@Column(name = "ZIP_FILE_NAME")
		private String zipFileName;	
		
		@Column(name = "PERFECTION_TASK_RID")
		private Long perfectionTaskRid;	
		
		@Column(name = "STATUS")
		private String status;	
		
		@Column(name = "ACK_DATE")
		private Date ackDate;

		@Column(name = "SENT_DATE")
		private Date sentDate;
		
		public Long getRid() {
			return rid;
		}

		public void setRid(Long rid) {
			this.rid = rid;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public Date getAckDate() {
			return ackDate;
		}

		public void setAckDate(Date ackDate) {
			this.ackDate = ackDate;
		}
		public Long getPerfectionTaskRid() {
			return perfectionTaskRid;
		}

		public void setPerfectionTaskRid(Long perfectionTaskRid) {
			this.perfectionTaskRid = perfectionTaskRid;
		}

		public String getZipFileName() {
			return zipFileName;
		}

		public void setZipFileName(String zipFileName) {
			this.zipFileName = zipFileName;
		}

		public Date getSentDate() {
			return sentDate;
		}

		public void setSentDate(Date sentDate) {
			this.sentDate = sentDate;
		}
	 

}
