package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

/**
 * 
 * @author n446693
/**
 * This is just a meta model used to create safe query on the FloodRemapRuleEngine model object
 */
@StaticMetamodel(FloodRemapRuleEngine.class)
public class FloodRemapRuleEngine_ {

	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,Long> rid;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> ruleName;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> remapCategory;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> remapType;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> clientFoundFlag;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> propertyPledgedFlag;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> exposureExists;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> completeFlag;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> slaDaysRemaining;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> currentWorkFlowStep;
	/**
	 */	
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> transitionValue;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> nextWorkFlowStep;
	
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> nextTaskStatus;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> trackingType;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> tmTaskType;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> perfectionType;
	/**
	 */
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> perfectionSubType;
	/**
	 */
	
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> reminderType;
	/**
	 */
	
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> loanActiveFlag;
	/**
	 */
	
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> comments;
	
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> policyType;
	
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> loanType;
	
	public static volatile SingularAttribute<FloodRemapRuleEngine,String> collateralType;
}
