package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_PRO_COVERAGE_DETAILS")
public class ProvidedCoverageViewData {
	
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name="PROOF_OF_COVERAGE_ID")
	private Long proofOfCoverageRid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "INSURABLE_ASSET_RID")
	private Long insurableAssetRid;
	
	@Column(name="ASSET_TYPE")
	private String assetType;
	
	@Column(name="ASSET_FLOOD_ZONE")
	private String assetFloodZone;
	
	@Column(name="ASSET_SORT_ORDER")
	private Integer assetSortOrder;
	
	@Column(name="COVERAGE_CREATED_BY")
	private String coverageCreatedBy;
	
	@Column(name="COVERAGE_CREATED_DATE")
	private Date coverageCreatedDate;
	
	@Column(name="COVERAGE_LAST_UPDATED_BY")
	private String coverageLastUpdateddBy;
	
	@Column(name="COVERAGE_LAST_UPDATED_DATE")
	private Date coverageLastUpdatedDate;
	
	@Column(name="BUILDING_NAME")
	private String buildingName;
	
	@Column(name="COVERAGE_AMOUNT")
	//private Long coverageAmount;
	private BigDecimal coverageAmount;
	
	@Column(name="IS_COVERAGE_VERIFIED")
	private Integer isCoverageVerified;
	
	@Column(name="COVERAGE_TYPE")
	private String coverageType;

	@Column(name="BALANCE_TYPE")
	private String balanceType;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}


	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getInsurableAssetRid() {
		return insurableAssetRid;
	}

	public void setInsurableAssetRid(Long insurableAssetRid) {
		this.insurableAssetRid = insurableAssetRid;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getAssetFloodZone() {
		return assetFloodZone;
	}

	public void setAssetFloodZone(String assetFloodZone) {
		this.assetFloodZone = assetFloodZone;
	}

	public Integer getAssetSortOrder() {
		return assetSortOrder;
	}

	public void setAssetSortOrder(Integer assetSortOrder) {
		this.assetSortOrder = assetSortOrder;
	}

	public String getCoverageCreatedBy() {
		return coverageCreatedBy;
	}

	public void setCoverageCreatedBy(String coverageCreatedBy) {
		this.coverageCreatedBy = coverageCreatedBy;
	}

	public Date getCoverageCreatedDate() {
		return coverageCreatedDate;
	}

	public void setCoverageCreatedDate(Date coverageCreatedDate) {
		this.coverageCreatedDate = coverageCreatedDate;
	}

	public String getCoverageLastUpdateddBy() {
		return coverageLastUpdateddBy;
	}

	public void setCoverageLastUpdateddBy(String coverageLastUpdateddBy) {
		this.coverageLastUpdateddBy = coverageLastUpdateddBy;
	}

	public Date getCoverageLastUpdatedDate() {
		return coverageLastUpdatedDate;
	}

	public void setCoverageLastUpdatedDate(Date coverageLastUpdatedDate) {
		this.coverageLastUpdatedDate = coverageLastUpdatedDate;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public BigDecimal getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(BigDecimal coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public Integer getIsCoverageVerified() {
		return isCoverageVerified;
	}

	public void setIsCoverageVerified(Integer isCoverageVerified) {
		this.isCoverageVerified = isCoverageVerified;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getBalanceType() {
		return balanceType;
	}

	public void setBalanceType(String balanceType) {
		this.balanceType = balanceType;
	}
	
}
