package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.FloodRemapItem;

public interface FloodRemapItemRepository extends JpaRepository<FloodRemapItem, Long> {
	
	/*public List<FloodRemapItem> findByPerfectionTaskWorkflowStep(String workflowStep);*/
	@Query("select items from FloodRemapItem items where collateral.rid=?1")
	public List<FloodRemapItem> getFloodRemapItems(Long collateralRid);	
	
	public List<FloodRemapItem> findByCollateralRid(Long collateralRid);
	
	public List<FloodRemapItem> findByCoverageRequestTaskRid(Long coveragerequestTaskRid);
	
	public List<FloodRemapItem> findByCollateralRidOrderByRidDesc(Long collateralRid);
	
}
