package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LookupCodeRepository extends JpaRepository<LookUpCode, Long>{

	@Cacheable(value = "lookUpCodeDataCache")
	LookUpCode findByCodeAndCodeSet(String code, String codeSet);

	@Cacheable(value = "lookUpCodeDataCache")
	List<LookUpCode> findByCodeSet(String codeSet);

	@Cacheable(value = "lookUpCodeDataCache")
	List<LookUpCode> findByCodeSetOrderBySortOrderAsc(String codeSet);

	List<LookUpCode> findByCodeSetAndActiveOrderBySortOrderAsc(String codeSet, String active);

	List<LookUpCode> findByCodeSetAndActiveOrderByDescriptionAsc(String codeSet, String active);

	@Cacheable(value = "lookUpCodeDataCache")
	List<LookUpCode> findByCodeSetOrderByDescriptionAsc(String codeSet);

	@Cacheable(value = "lookUpCodeDataCache")
	LookUpCode findByCodeSetAndDescription(String codeSet, String description);

	@Cacheable(value = "lookUpCodeDataCache")
	List<LookUpCode> findByCodeSetAndDescriptionOrderBySortOrderAsc(String codeSet, String description);

	@Cacheable(value = "lookUpCodeDataCache")
	List<LookUpCode> findByRidIn(List<Long> rids);

}
