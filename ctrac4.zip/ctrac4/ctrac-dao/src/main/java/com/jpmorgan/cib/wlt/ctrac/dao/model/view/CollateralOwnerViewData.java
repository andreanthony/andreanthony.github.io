package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name="VLCP_COLLATERAL_OWNER_DETAILS")
public class CollateralOwnerViewData {
	
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name="BORROWER_SAME_AS_OWNER")
	private String borrowerSameAsOwner;

	@Column(name="OWNER_NAME")
	private String ownerName;
	
	@Column(name="UNIQUE_OWNER_NUMBER")
	private String uniqueOwnerNumber;
	
	@Column(name="OWNER_MAILING_ADDR")
	private String ownerMailingAddress;
	
	@Column(name="OWNER_CITY")
	private String ownerCity;
	
	@Column(name="OWNER_STATE")
	private String ownerState;

	@Column(name="OWNER_ZIPCODE")
	private String ownerZipCode;
	
	@Column(name="OWNER_UNIT_BLDG")
	private String ownerUnitBuilding;
	
	@Column(name="OWNER_CREATED_BY")
	private String ownerCreatedBy;
	
	@Column(name="OWNER_CREATED_DATE")
	private Date ownerCreatedDate;
	
	@Column(name="OWNER_LAST_UPDATED_BY")
	private String ownerLastUpdatedBy;
	
	@Column(name="OWNER_LAST_UPDATED_DATE")
	private Date ownerUpdatedDate;

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getBorrowerSameAsOwner() {
		return borrowerSameAsOwner;
	}

	public void setBorrowerSameAsOwner(String borrowerSameAsOwner) {
		this.borrowerSameAsOwner = borrowerSameAsOwner;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getUniqueOwnerNumber() {
		return uniqueOwnerNumber;
	}

	public void setUniqueOwnerNumber(String uniqueOwnerNumber) {
		this.uniqueOwnerNumber = uniqueOwnerNumber;
	}

	public String getOwnerCreatedBy() {
		return ownerCreatedBy;
	}

	public void setOwnerCreatedBy(String ownerCreatedBy) {
		this.ownerCreatedBy = ownerCreatedBy;
	}

	public Date getOwnerCreatedDate() {
		return ownerCreatedDate;
	}

	public void setOwnerCreatedDate(Date ownerCreatedDate) {
		this.ownerCreatedDate = ownerCreatedDate;
	}

	public String getOwnerLastUpdatedBy() {
		return ownerLastUpdatedBy;
	}

	public void setOwnerLastUpdatedBy(String ownerLastUpdatedBy) {
		this.ownerLastUpdatedBy = ownerLastUpdatedBy;
	}

	public Date getOwnerUpdatedDate() {
		return ownerUpdatedDate;
	}

	public void setOwnerUpdatedDate(Date ownerUpdatedDate) {
		this.ownerUpdatedDate = ownerUpdatedDate;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getOwnerMailingAddress() {
		return ownerMailingAddress;
	}

	public void setOwnerMailingAddress(String ownerMailingAddress) {
		this.ownerMailingAddress = ownerMailingAddress;
	}

	public String getOwnerCity() {
		return ownerCity;
	}

	public void setOwnerCity(String ownerCity) {
		this.ownerCity = ownerCity;
	}

	public String getOwnerState() {
		return ownerState;
	}

	public void setOwnerState(String ownerState) {
		this.ownerState = ownerState;
	}

	public String getOwnerZipCode() {
		return ownerZipCode;
	}

	public void setOwnerZipCode(String ownerZipCode) {
		this.ownerZipCode = ownerZipCode;
	}

	public String getOwnerUnitBuilding() {
		return ownerUnitBuilding;
	}

	public void setOwnerUnitBuilding(String ownerUnitBuilding) {
		this.ownerUnitBuilding = ownerUnitBuilding;
	}
	
}
