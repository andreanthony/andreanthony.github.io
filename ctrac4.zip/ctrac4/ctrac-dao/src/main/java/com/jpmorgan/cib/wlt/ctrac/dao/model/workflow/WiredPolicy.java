package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyPayor;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProofOfCoverageWorkItemRelationType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import org.apache.commons.lang.StringUtils;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


@Entity
@Table(name = "TLCP_WIRED_POLICY")
public class WiredPolicy extends CtracBaseEntity implements Cloneable{
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "wirePolicyGenerator")
	@TableGenerator(name = "wirePolicyGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_WIRED_POLICY", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ACCT_WIRE_REF_RID", referencedColumnName="RID", nullable=true)
	private AccountWireReference accountWireReference;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name = "LP_ITEM_RID", referencedColumnName="RID", nullable=true)
	private WorkItem workItem;	

	@Column(name = "METHOD_OF_PAYMENT")
	private String methodOfPayment;
	
	@Column(name = "LOAN_NUMBER")
	private String loanNumber;
	
	@Column(name = "COST_CENTER")
	private String costCenter;
	
	@Column(name = "GENERAL_LEDGER")
	private String generalLedger;
	
	@Column(name = "DDA_NUMBER")
	private String ddaNumber;
	
	@Column(name = "LENDER_BRANCH")
	private String lenderBranch;
	
	@Column(name = "CLIENT_NAME")
	private String clientName;
	
	@Column(name = "POLICY_EFFECTIVE_DATE")
	private Date policyEffectiveDay;
	
	@Column(name = "POLICY_NUMBER")
	private String policyNumber;
	
	@Column(name = "PREMIUM_AMOUNT", precision = 18)
	private BigDecimal premiumAmount;
	
	@Column(name = "DATE_WIRE_SENT")
	private Date dateWireSent;
	
	@Column(name = "FED_REF_NUMBER")
	private String fedReferenceNumber;
	
	@Column(name = "LOAN_ACCOUNTING_SYSTEM")
	private String loanAcctSystem;

	@Column(name = "REFUND_MAILING_ADDRESS")
	private String refundMailingAddress;
	
	@Column(name = "REFUND_AMT")
	private BigDecimal refundAmount;
	
	@Column(name = "POLICY_CANCELLATION_DATE")
	private Date policyCancellationDate;

	@Column(name = "PAYOR")
	private String payor;

	//NEW COLUMNS
	@Column(name = "COLLATERAL_ADDRESS")
	private String collateralAddress;

	@Column(name = "COLLATERAL_UNIT")
	private String collateralUnit;

	@Column(name = "COLLATERAL_CITY")
	private String collateralCity;

	@Column(name = "COLLATERAL_STATE")
	private String collateralState;

	@Column(name = "COLLATERAL_ZIP")
	private String collateralZip;

	@Column(name = "BUILDING_NAME")
	private String buildingName;

	@Column(name = "POLICY_EXPIRATION_DATE")
	private Date policyExpirationDay;

	@Column(name = "COVERAGE_TYPE")
	private String coverageType;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public AccountWireReference getAccountWireReference() {
		return accountWireReference;
	}

	public void setAccountWireReference(AccountWireReference accountWireReference) {
		this.accountWireReference = accountWireReference;
	}

	public String getMethodOfPayment() {
		return methodOfPayment;
	}

	public void setMethodOfPayment(String methodOfPayment) {
		this.methodOfPayment = methodOfPayment;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public String getGeneralLedger() {
		return generalLedger;
	}

	public void setGeneralLedger(String generalLedger) {
		this.generalLedger = generalLedger;
	}

	public String getDdaNumber() {
		return ddaNumber;
	}

	public void setDdaNumber(String ddaNumber) {
		this.ddaNumber = ddaNumber;
	}

	public String getLenderBranch() {
		return lenderBranch;
	}

	public void setLenderBranch(String lenderBranch) {
		this.lenderBranch = lenderBranch;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public Date getPolicyEffectiveDay() {
		return policyEffectiveDay;
	}

	public void setPolicyEffectiveDay(Date policyEffectiveDay) {
		this.policyEffectiveDay = policyEffectiveDay;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public BigDecimal getPremuimAmount() {
		return premiumAmount;
	}

	public void setPremuimAmount(BigDecimal premuimAmount) {
		this.premiumAmount = premuimAmount;
	}


	public String getFedReferenceNumber() {
		return fedReferenceNumber;
	}

	public void setFedReferenceNumber(String fedReferenceNumber) {
		this.fedReferenceNumber = fedReferenceNumber;
	}

	public Date getDateWireSent() {
		return dateWireSent;
	}

	public void setDateWireSent(Date dateWireSent) {
		this.dateWireSent = dateWireSent;
	}
	
	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public String getLoanAcctSystem() {
		return loanAcctSystem;
	}

	public void setLoanAcctSystem(String loanAcctSystem) {
		this.loanAcctSystem = loanAcctSystem;
	}

	public String getRefundMailingAddress() {
		return refundMailingAddress;
	}

	public void setRefundMailingAddress(String refundMailingAddress) {
		this.refundMailingAddress = refundMailingAddress;
	}

	public BigDecimal getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(BigDecimal refundAmount) {
		this.refundAmount = refundAmount;
	}

	public Date getPolicyCancellationDate() {
		return policyCancellationDate;
	}

	public void setPolicyCancellationDate(Date policyCancellationDate) {
		this.policyCancellationDate = policyCancellationDate;
	}

	public String getCollateralAddress() {
		return collateralAddress;
	}

	public void setCollateralAddress(String collateralAddress) {
		this.collateralAddress = collateralAddress;
	}

	public String getCollateralUnit() {
		return collateralUnit;
	}

	public void setCollateralUnit(String collateralUnit) {
		this.collateralUnit = collateralUnit;
	}

	public String getCollateralCity() {
		return collateralCity;
	}

	public void setCollateralCity(String collateralCity) {
		this.collateralCity = collateralCity;
	}

	public String getCollateralState() {
		return collateralState;
	}

	public void setCollateralState(String collateralState) {
		this.collateralState = collateralState;
	}

	public String getCollateralZip() {
		return collateralZip;
	}

	public void setCollateralZip(String collateralZip) {
		this.collateralZip = collateralZip;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public Date getPolicyExpirationDay() {
		return policyExpirationDay;
	}

	public void setPolicyExpirationDay(Date policyExpirationDay) {
		this.policyExpirationDay = policyExpirationDay;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	@Transient
	private Double premiumAmountDouble;
	
	@Transient
	private Double refundAmountDouble;
	
	@Transient
	private Long policyRid;

	@Transient
	private String payorDisplayValue;

	@Transient
	private String costCenterDisplayValue;
	
	public Long getPolicyRid() {
		return policyRid;
	}

	public void setPolicyRid(Long policyRid) {
		this.policyRid = policyRid;
	}

	public Double getPremiumAmountDouble() {
		return premiumAmountDouble;
	}

	public void setPremiumAmountDouble(Double premuimAmountDouble) {
		this.premiumAmountDouble = premuimAmountDouble;
	}
	
	public Double getRefundAmountDouble() {
		return refundAmountDouble;
	}

	public void setRefundAmountDouble(Double refundAmountDouble) {
		this.refundAmountDouble = refundAmountDouble;
	}

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

	public String getPayorDisplayValue() {
		return payorDisplayValue;
	}

	public void setPayorDisplayValue(String payorDisplayValue) {
		this.payorDisplayValue = payorDisplayValue;
	}

	public String getCostCenterDisplayValue() {
		return costCenterDisplayValue;
	}

	public void setCostCenterDisplayValue(String costCenterDisplayValue) {
		this.costCenterDisplayValue = costCenterDisplayValue;
	}

	public void fillTransientVariables(boolean useLPIRidAsPolicyRid) {
		setPremiumAmountDouble((premiumAmount==null)?null:premiumAmount.doubleValue());
		setRefundAmountDouble((refundAmount==null)?null:refundAmount.doubleValue());
		setPolicyRid((workItem==null)?null: useLPIRidAsPolicyRid ? workItem.getRid() : workItem.getProofOfCoverageForItemType(
				ProofOfCoverageWorkItemRelationType.LENDERPLACEMENT_TO_POLICY).getRid());
		setPayorDisplayValue(StringUtils.isEmpty(payor) ? PolicyPayor.BORROWER.getDesc() : payor);
		setCostCenterDisplayValue(costCenter);
	}

	@Override
	public WiredPolicy clone() throws CloneNotSupportedException {
		return (WiredPolicy) super.clone();
	}

	
}
