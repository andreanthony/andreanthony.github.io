package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralItem;

public interface CollateralItemRepository extends JpaRepository<CollateralItem, Long> {	
	public List<CollateralItem> findByCollateralWorkItems(Collateral collateral);	
}
