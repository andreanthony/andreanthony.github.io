package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Loan;

public interface LoanRepository extends JpaRepository<Loan, Long> {

	List<Loan> findByLoanNumberContaining(String loanNumber);
	
}
