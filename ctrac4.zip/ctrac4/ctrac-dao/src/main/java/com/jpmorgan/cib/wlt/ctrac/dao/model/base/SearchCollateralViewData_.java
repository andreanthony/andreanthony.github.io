package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

/**
 * 
 * @author e078704
/**
 * This is just a meta model used to create safe query on the CollateralDetails model object
 */
@StaticMetamodel(SearchCollateralViewData.class)
public class SearchCollateralViewData_ {

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,Long> collateralRid;
	
	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> collateralId;
	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> collateralType;
	
	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> ctracID;
	
	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> propertyAddress;	
	
	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> propertyCity;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> propertyZipCode;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> propertyState;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> propertyCounty;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> floodZone;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> remapCategory;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> ownerName;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> propertyType;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> loanNumber;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> lineOfBusiness;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> loanAccountingSystem;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> name;	

	
	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> borrowerName;	
	
	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> insuredName;	
	
	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> mortgagorName;	
	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> borrowerNumber;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> borrowerAddress;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> borrowerCity;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> borrowerZipCode;	

	/**
	 */
	public static volatile SingularAttribute<SearchCollateralViewData,String> borrowerState;	
	
}
