package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;
import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ReconciliationLog;

public interface ReconciliationLogRepository extends JpaRepository<ReconciliationLog, Long> {
					
}
