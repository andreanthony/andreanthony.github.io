package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.FloodRemapRuleEngine;



public interface FloodRemapRuleEngineRepository extends JpaRepository<FloodRemapRuleEngine,Long>,JpaSpecificationExecutor<FloodRemapRuleEngine>{

}
