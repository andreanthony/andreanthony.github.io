package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Loan;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LoanBorrower;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LoanBorrowerPk;

public interface LoanBorrowerRepository extends JpaRepository<LoanBorrower, LoanBorrowerPk> {
	
	List<LoanBorrower> findByBorrower(Customer borrower);
	
	List<LoanBorrower> findByBorrowerRid(Long borrowerRid);
	
	List<LoanBorrower> findByLoan(Loan loan);
	
	List<LoanBorrower> findDistinctByBorrowerNameContaining(String borrowerName);

}
