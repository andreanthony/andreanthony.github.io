package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.ReadyForLpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

@Entity
@Table(name = "TLCP_READY_FOR_LP")
public class ReadyForLP extends CtracBaseEntity {

    @EmbeddedId
    private ReadyForLPPk readyForLPPk = new ReadyForLPPk();
    
	@Column(name = "READY")
	private Integer ready = 0;

    public ProofOfCoverage getProofOfCoverage() {
        return readyForLPPk.getProofOfCoverage();
    }

    public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
        readyForLPPk.setProofOfCoverage(proofOfCoverage);
    }

    public Collateral getCollateral() {
    	return readyForLPPk.getCollateral();
    }

    public void setCollateral(Collateral collateral) {
    	readyForLPPk.setCollateral(collateral);
    }

    public Integer getReady() {
        return ready;
    }

    public void setReady(Integer ready) {
        this.ready = ready;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((readyForLPPk == null) ? 0 : readyForLPPk.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReadyForLP other = (ReadyForLP) obj;
		if (readyForLPPk == null) {
			if (other.readyForLPPk != null)
				return false;
		} else if (!readyForLPPk.equals(other.readyForLPPk))
			return false;
		return true;
	}

	public boolean isReady() {
		return ReadyForLpCode.LP_READY.getCode().equals(ready);
	}

	public boolean isRenewalStarted() {
		return ReadyForLpCode.LP_RENEWAL_STARTED.getCode().equals(ready);
	}
}
