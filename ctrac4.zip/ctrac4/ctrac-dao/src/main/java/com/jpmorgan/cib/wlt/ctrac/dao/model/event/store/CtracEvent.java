package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "TEVT_CTRAC_EVENT")
@EntityListeners(CtracEventListener.class)
public class CtracEvent {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "ctracEventSeqGenerator")
    @TableGenerator(name = "ctracEventSeqGenerator", table = "TEVT_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TEVT_CTRAC_EVENT", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 100)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "EVENT_UUID")
    @NotNull
    private UUID eventUuid;

    @Column(name = "EVENT_TIME")
    @NotNull
    private Date eventTime;

    @Column(name = "EVENT_TYPE")
    @NotNull
    private String eventType;

    @Column(name = "EVENT_JSON")
    @NotNull
    private String eventJson;

    @Column(name = "PERFORMED_BY")
    @NotNull
    private String performedBy;

    @Column(name = "LAST_PUBLISH_TIME")
    @NotNull
    private Date lastPublishTime = new Date();

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public UUID getEventUuid() { return eventUuid; }

    public void setEventUuid(UUID eventUuid) { this.eventUuid = eventUuid; }

    public Date getEventTime() {
        if (eventTime == null) {
            return null;
        }
        return (Date) eventTime.clone();
    }

    public void setEventTime(Date eventTime) {
        if (eventTime == null) {
            this.eventTime = null;
        } else {
            this.eventTime = (Date) eventTime.clone();
        }
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventJson() {
        return eventJson;
    }

    public void setEventJson(String eventJson) {
        this.eventJson = eventJson;
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }

	public Date getLastPublishTime() {
		if (lastPublishTime == null) {
			lastPublishTime = new Date();
		}
		return (Date) lastPublishTime.clone();
	}

	public void setLastPublishTime(Date lastPublishTime) {
		if (lastPublishTime == null) {
			lastPublishTime = new Date();
		}
		this.lastPublishTime = (Date) lastPublishTime.clone();
	}
}
