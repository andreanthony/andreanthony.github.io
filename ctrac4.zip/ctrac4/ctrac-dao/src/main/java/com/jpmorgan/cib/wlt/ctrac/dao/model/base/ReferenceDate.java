package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * This is a JPA entity class to hold CTRAC reference date. 
 * @date 21-Jul-2014
 */

@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Table(name = "TLCP_CTRAC_REFERENCE_DATE")
public class ReferenceDate{

	@Id
	@Column(name = "NAME")
	private String name;

	@Column(name = "REFERENCE_DATE")
	private Date referencDate;

	@Column(name = "DESCRIPTION")
	private String description ;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getReferencDate() {
		return referencDate;
	}

	public void setReferencDate(Date referencDate) {
		this.referencDate = referencDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
