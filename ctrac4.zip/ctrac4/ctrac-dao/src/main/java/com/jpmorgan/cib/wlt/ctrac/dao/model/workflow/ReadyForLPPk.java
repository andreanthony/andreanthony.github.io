package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

@Embeddable
public class ReadyForLPPk implements Serializable {

    private static final long serialVersionUID = -609075605348561700L;

    @ManyToOne
    @JoinColumn(name = "COLLATERAL_RID")
    private Collateral collateral;
    
    @ManyToOne
    @JoinColumn(name = "PROOF_OF_COVERAGE_RID")
    private ProofOfCoverage proofOfCoverage;
    
	public Collateral getCollateral() {
		return collateral;
	}
	
	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}
	
	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}
	
	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((collateral == null) ? 0 : collateral.hashCode());
		result = prime * result + ((proofOfCoverage == null) ? 0 : proofOfCoverage.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReadyForLPPk other = (ReadyForLPPk) obj;
		if (collateral == null) {
			if (other.collateral != null)
				return false;
		} else if (!collateral.equals(other.collateral))
			return false;
		if (proofOfCoverage == null) {
			if (other.proofOfCoverage != null)
				return false;
		} else if (!proofOfCoverage.equals(other.proofOfCoverage))
			return false;
		return true;
	}

}
