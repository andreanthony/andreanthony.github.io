package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "TLCP_EMAIL_TEMPLATE")
public class EmailTemplate extends CtracBaseEntity implements Serializable {

	private static final long serialVersionUID = -7244199772464614921L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "EmailTemplateSeqGenerator")
	@TableGenerator(name = "EmailTemplateSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_EMAIL_TEMPLATE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "ACTIVE_FLAG")
	private String active;

	@Column(name = "EMAIL_TEMPLATE_CODE", unique = true)
	private String emailTemplateId;

	@Column(name = "VERSION_NUM")
	private String versionNumber;

	@Column(name = "EMAIL_BODY")
	private String emailStaticText;

	@Column(name = "EMAIL_VM_TEMPLATE")
	private String emailVmTemplate;

	@Column(name = "EMAIL_TEMPLATE_NAME")
	private String emailTemplateName;
	
	@Column(name = "SFHDF_MESSAGE")
	private String SFHDFMessage;

	public String getSFHDFMessage() {
		return SFHDFMessage;
	}

	public void setSFHDFMessage(String sFHDFMessage) {
		SFHDFMessage = sFHDFMessage;
	}

	public String getEmailTemplateName() {
		return emailTemplateName;
	}

	public void setEmailTemplateName(String emailTemplateName) {
		this.emailTemplateName = emailTemplateName;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getEmailTemplateId() {
		return emailTemplateId;
	}

	public void setEmailTemplateId(String emailTemplateId) {
		this.emailTemplateId = emailTemplateId;
	}

	public String getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}

	public String getEmailVmTemplate() {
		return emailVmTemplate;
	}

	public void setEmailVmTemplate(String emailVmTemplate) {
		this.emailVmTemplate = emailVmTemplate;
	}

	public String getEmailStaticText() {
		return emailStaticText;
	}

	public void setEmailStaticText(String emailStaticText) {
		this.emailStaticText = emailStaticText;
	}
}
