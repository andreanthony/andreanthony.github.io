package com.jpmorgan.cib.wlt.ctrac.dao.repository.letters;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.letters.CoverLetterSection;

public interface CoverLetterSectionRepository extends JpaRepository<CoverLetterSection, Long> {
	
	List<CoverLetterSection> findByTemplateCodeAndActiveTrueOrderBySectionOrderAsc(String templateCode);
		
}
