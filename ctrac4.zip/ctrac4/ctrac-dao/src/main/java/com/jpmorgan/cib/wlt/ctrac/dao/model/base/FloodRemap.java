package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.apache.commons.lang.StringUtils;

/**
 * This is a JPA entity class to hold new Flood Remap Activity.
 * @date 5-Sep-2013
 */

@Entity
@Table(name = "TLCP_FLOOD_REMAP")
public class FloodRemap extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "remapActivitySeqGenerator")
	@TableGenerator(name = "remapActivitySeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_FLOOD_REMAP", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "BORROWER_NAME")
	private String borrowerName;

	@Column(name = "DEPT_CODE")
	private String deptCode;

	@Column(name = "BORROWER_NUMBER")
	private String borrowerNum;

	@Column(name = "LOAN_NUMBER")
	private String loanNumber;

	@Column(name = "STATUS_CHANGE")
	private String statusChange;

	@Column(name = "REQUEST_NUM")
	private String reqNum;

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "CITY")
	private String city;

	@Column(name = "ZIPCODE")
	private String zipCode;

	@Column(name = "COUNTY")
	private String county;

	@Column(name = "STATE")
	private String state;

	@Column(name = "ORIG_STATUS_IN_OUT")
	private String originalStatus;

	@Column(name = "ORIG_COMM_NUM")
	private String originalCommNum;

	@Column(name = "ORIG_PANEL_NUM_AND_SUFFIX")
	private String originalPanelNumAndSuffix;

	@Column(name = "ORIG_FLOOD_ZONE")
	private String origialFloodZone;

	@Column(name = "ORIG_MAP_DATE")
	private Date originalMapdate;

	@Column(name = "REVISED_STATUS")
	private String revisedStatus;

	@Column(name = "PARTICIPATING_COMM")
	private String participatingCommunity;

	@Column(name = "REVISED_COM_NUM")
	private String revisedCommunityNum;

	@Column(name = "REVISED_PANEL_SUFFIX")
	private String revisedPanelSuffix;

	@Column(name = "REVISED_MAP_DATE")
	private Date revisedMapDate;

	@Column(name = "LOMA_R_DATE")
	private Date lomarDate;

	@Column(name = "REVISED_FLOOD_ZONE")
	private String revisedFloodZone;

	@Column(name = "CLIENT_NAME")
	private String clientName;

	@Column(name = "CLIENT_ADDRESS")
	private String clientAddress;

	@Column(name = "CLIENT_ADDRESS2")
	private String clientAddress2;

	@Column(name = "CLIENT_CITY")
	private String clientCity;

	@Column(name = "CLIENT_STATE")
	private String clientState;

	@Column(name = "CLIENT_ZIP_CODE")
	private String clientZipCode;

	@Column(name = "CLIENT_CONTACT")
	private String clientContact;

	@Column(name = "CLIENT_PHONE")
	private String clientPhone;

	@Column(name = "LOAN_PAIDOFF_TRANSFER")
	private String loanPaidOffTransfer;

	@Column(name = "TRANSFER_TO")
	private String transferredTo;

	@Column(name = "SERVICER_ADDRESS")
	private String serviceAddress;

	@Column(name = "PROCESSING_STATUS")
	private String processingStatus = "N";

	@Column(name = "REMAP_CREATION_DATE")
	private Date remapCreationDate;
	
	@Column(name = "SOURCE_SYSTEM")
	private String sourceSystem;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name = "SFHDF_RID", referencedColumnName="RID", nullable=true)
	private CollateralDocument floodRemapSFHDF;
	
	@Column(name = "CONTACT_EMAIL")
	private String contactEmail;
	
	@Column(name = "FLOOD_REMAP_LANDING_RID")
	private Long floodRemapLandingRId;
	
	@Column(name = "OTM_TASK_TYPE")
	private String tmTaskType;
	
	@Column(name = "LINE_OF_BUSINESS")
	private String lineOfBusiness;	
	
	@Column(name = "DETERMINATION_DATE")
	private Date determinationDate;
	
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getAddress() {
		return address;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public String getBorrowerNum() {
		return borrowerNum;
	}

	public String getCity() {
		return city;
	}

	public String getClientAddress() {
		return clientAddress;
	}

	public String getClientAddress2() {
		return clientAddress2;
	}

	public String getClientCity() {
		return clientCity;
	}

	public String getClientContact() {
		return clientContact;
	}

	public String getClientName() {
		return clientName;
	}

	public String getClientPhone() {
		return clientPhone;
	}

	public String getClientState() {
		return clientState;
	}

	public String getClientZipCode() {
		return clientZipCode;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public String getCounty() {
		return county;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public Long getFloodRemapLandingRId() {
		return floodRemapLandingRId;
	}

	public CollateralDocument getFloodRemapSFHDF() {
		return floodRemapSFHDF;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public String getLoanPaidOffTransfer() {
		return loanPaidOffTransfer;
	}

	public Date getLomarDate() {
		return lomarDate;
	}

	public String getOrigialFloodZone() {
		return origialFloodZone;
	}

	public String getOriginalCommNum() {
		return originalCommNum;
	}

	public Date getOriginalMapdate() {
		return originalMapdate;
	}

	public String getOriginalPanelNumAndSuffix() {
		return originalPanelNumAndSuffix;
	}

	public String getOriginalStatus() {
		return originalStatus;
	}

	public String getTmTaskType() {
		return tmTaskType;
	}

	public String getParticipatingCommunity() {
		return participatingCommunity;
	}

	public String getProcessingStatus() {
		return processingStatus;
	}

	public Date getRemapCreationDate() {
		return remapCreationDate;
	}

	public String getReqNum() {
		return reqNum;
	}

	public String getRevisedCommunityNum() {
		return revisedCommunityNum;
	}

	public String getRevisedFloodZone() {
		return revisedFloodZone;
	}

	public Date getRevisedMapDate() {
		return revisedMapDate;
	}

	public String getRevisedPanelSuffix() {
		return revisedPanelSuffix;
	}

	public String getRevisedStatus() {
		return revisedStatus;
	}

	public Long getRid() {
		return rid;
	}

	public String getServiceAddress() {
		return serviceAddress;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public String getState() {
		return state;
	}

	public String getStatusChange() {
		return statusChange;
	}

	public String getTransferredTo() {
		return transferredTo;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public void setBorrowerNum(String borrowerNum) {
		this.borrowerNum = borrowerNum;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setClientAddress(String clientAddress) {
		this.clientAddress = clientAddress;
	}

	public void setClientAddress2(String clientAddress2) {
		this.clientAddress2 = clientAddress2;
	}

	public void setClientCity(String clientCity) {
		this.clientCity = clientCity;
	}

	public void setClientContact(String clientContact) {
		this.clientContact = clientContact;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setClientPhone(String clientPhone) {
		this.clientPhone = clientPhone;
	}

	public void setClientState(String clientState) {
		this.clientState = clientState;
	}

	public void setClientZipCode(String clientZipCode) {
		this.clientZipCode = clientZipCode;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public void setFloodRemapLandingRId(Long floodRemapLandingRId) {
		this.floodRemapLandingRId = floodRemapLandingRId;
	}

	public void setFloodRemapSFHDF(CollateralDocument floodRemapSFHDF) {
		this.floodRemapSFHDF = floodRemapSFHDF;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public void setLoanPaidOffTransfer(String loanPaidOffTransfer) {
		this.loanPaidOffTransfer = loanPaidOffTransfer;
	}

	public void setLomarDate(Date lomarDate) {
		this.lomarDate = lomarDate;
	}

	public void setOrigialFloodZone(String origialFloodZone) {
		this.origialFloodZone = origialFloodZone;
	}

	public void setOriginalCommNum(String originalCommNum) {
		this.originalCommNum = originalCommNum;
	}

	public void setOriginalMapdate(Date originalMapdate) {
		this.originalMapdate = originalMapdate;
	}

	public void setOriginalPanelNumAndSuffix(String originalPanelNumAndSuffix) {
		this.originalPanelNumAndSuffix = originalPanelNumAndSuffix;
	}

	public void setOriginalStatus(String originalStatus) {
		this.originalStatus = originalStatus;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}

	public void setParticipatingCommunity(String participatingCommunity) {
		this.participatingCommunity = participatingCommunity;
	}

	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}

	public void setRemapCreationDate(Date remapCreationDate) {
		this.remapCreationDate = remapCreationDate;
	}

	public void setReqNum(String reqNum) {
		this.reqNum = reqNum;
	}

	public void setRevisedCommunityNum(String revisedCommunityNum) {
		this.revisedCommunityNum = revisedCommunityNum;
	}

	public void setRevisedFloodZone(String revisedFloodZone) {
		this.revisedFloodZone = revisedFloodZone;
	}

	public void setRevisedMapDate(Date revisedMapDate) {
		this.revisedMapDate = revisedMapDate;
	}

	public void setRevisedPanelSuffix(String revisedPanelSuffix) {
		this.revisedPanelSuffix = revisedPanelSuffix;
	}

	public void setRevisedStatus(String revisedStatus) {
		this.revisedStatus = revisedStatus;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public void setServiceAddress(String serviceAddress) {
		this.serviceAddress = serviceAddress;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setStatusChange(String statusChange) {
		this.statusChange = statusChange;
	}

	public void setTransferredTo(String transferredTo) {
		this.transferredTo = transferredTo;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	public String getFullAddress(){
	    return getFullAddress(null);
	}
	
	public String getFullAddress(String separator){
	    
	    if(StringUtils.isBlank(separator)){
	        separator = ", ";
	    }
	    StringBuilder builder = new StringBuilder();
	    builder
	    .append( address )
	    .append(separator)
	    .append(city )
	    .append(separator)
	    .append(state)
	    .append(" ")
	    .append(zipCode);
	    return builder.toString();
	}
	
	   
    public String getCityStateZip(String separator){
        
        if(StringUtils.isBlank(separator)){
            separator = ", ";
        }
        StringBuilder builder = new StringBuilder();
        builder
        .append(city )
        .append(separator)
        .append(state)
        .append(" ")
        .append(zipCode);
        return builder.toString();
    }

	public Date getDeterminationDate() {
		return determinationDate;
	}

	public void setDeterminationDate(Date determinationDate) {
		this.determinationDate = determinationDate;
	}

}
