package com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;

@Entity @Table(name="GROUPS")
public class Groups {

	@Id @Column(name="ID")
	private Long id;
	
	@Column(name="GROUP_NAME")
	private String groupName;
	@OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinTable(
			name="GROUP_LOBS",
			joinColumns = @JoinColumn( name="group_id"),
			inverseJoinColumns = @JoinColumn( name="lob_rid")
	)
	private List<LookUpCode> lineOfBusinesses;

	@Column(name="CATEGORY_NAME")
	private String categoryName;

	public List<LookUpCode> getLineOfBusinesses() {
		return lineOfBusinesses;
	}

	public void setLineOfBusinesses(List<LookUpCode> lineOfBusinesses) {
		this.lineOfBusinesses = lineOfBusinesses;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Groups other = (Groups) obj;
		if (groupName == null) {
			if (other.groupName != null)
				return false;
		} else if (!groupName.equals(other.groupName))
			return false;
		if (categoryName == null) {
			if (other.categoryName != null)
				return false;
		} else if (!categoryName.equals(other.categoryName))
			return false;
		return true;
	}
}
