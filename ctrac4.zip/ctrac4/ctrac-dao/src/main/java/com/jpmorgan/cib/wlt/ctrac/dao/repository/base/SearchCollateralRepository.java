package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.SearchCollateralViewData;

public interface SearchCollateralRepository extends JpaRepository<SearchCollateralViewData,Long> , JpaSpecificationExecutor<SearchCollateralViewData>{
	

}