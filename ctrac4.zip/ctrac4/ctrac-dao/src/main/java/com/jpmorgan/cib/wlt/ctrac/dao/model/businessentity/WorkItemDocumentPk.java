package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;

public class WorkItemDocumentPk implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long workItemRid;
	private Long collateralDocumentRid;
	
	public WorkItemDocumentPk(){}

	public Long getWorkItemRid() {
		return workItemRid;
	}

	public void setWorkItemRid(Long workItemRid) {
		this.workItemRid = workItemRid;
	}

	public Long getCollateralDocumentRid() {
		return collateralDocumentRid;
	}

	public void setCollateralDocumentRid(Long collateralDocumentRid) {
		this.collateralDocumentRid = collateralDocumentRid;
	}
	
}
