package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_LETTER_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class LetterItem extends WorkItem {
		
	@Column(name = "CREATED_DATE")
	private Date createdDate;

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
