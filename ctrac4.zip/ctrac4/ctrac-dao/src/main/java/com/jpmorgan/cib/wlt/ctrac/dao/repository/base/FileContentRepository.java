package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FileContent;

public interface FileContentRepository extends JpaRepository<FileContent, Long> {
	
}
