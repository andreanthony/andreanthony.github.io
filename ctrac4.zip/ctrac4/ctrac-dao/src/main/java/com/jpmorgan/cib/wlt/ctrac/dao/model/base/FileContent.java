package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "TLCP_FILE_CONTENT")
public class FileContent {

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "fileContentSeqGenerator")
	@TableGenerator(name = "fileContentSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_FILE_CONTENT", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 6)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Lob
	@Column(name = "FILE_CONTENT", nullable = false)
	private byte[] fileContent;
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public byte[] getFileContent() {
		return fileContent;
	}

	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}

}
