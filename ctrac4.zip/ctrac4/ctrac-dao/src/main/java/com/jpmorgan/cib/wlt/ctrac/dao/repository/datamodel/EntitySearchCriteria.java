package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

public class EntitySearchCriteria {
	String customerId;
	String name;
	String address;
	String city;
	String state;
	String zip;
	String collateralRids;
	
	private Long loanRid = null;
	private Long collateralRid = null;
	
	public String getCustomerId() {
		return (customerId==null?"":customerId);
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return (name==null?"":name);
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return (address==null?"":null);
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return (city==null?"":city);
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return (state==null?"":null);
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return (zip==null?"":zip);
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCollateralRids() {
		return (collateralRids==null?"":collateralRids);
	}
	public void setCollateralRids(String collateralRids) {
		this.collateralRids = collateralRids;
	}
	public Long getLoanRid() {
		return loanRid;
	}
	public void setLoanRid(Long loanRid) {
		this.loanRid = loanRid;
	}
	public Long getCollateralRid() {
		return collateralRid;
	}
	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}	
}
