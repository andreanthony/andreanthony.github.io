package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracReconcilable;

import javax.persistence.Id;

@Entity
@Table(name="VLCP_TASK_DETAILS")
public class TaskDetailsData implements CtracReconcilable{
	@Id
	@Column(name = "TASK_RID")
	private Long rid;
	
	@Column(name="COLLATERAL_RID")
	private String collateralId;

	@Column(name="CTRAC_ID")
	private String ctracUniqueId;
	
	@Column(name="OTM_TASK_ID")
	private String tmTaskId;
	
	@Column(name="SLA_DAYS_REMAINING")
	private Integer slaDaysRemaining;
	
	@Column(name="OTM_TASK_TYPE")
	private String tmTaskType;
	
	@Column(name="WORKFLOW_STEP")
	private String workFlowStep;
	
	@Column(name="PROPERTY_ADDRESS")
	private String propertyAddress;
	
	@Column(name="PROPERTY_CITY")
	private String city;
	
	@Column(name="PROPERTY_STATE")
	private String state;
	
	@Column(name="PROPERTY_COUNTY")
	private String county;
	
	@Column(name="PROPERTY_ZIP_CODE")
	private String zipcode;

	@Column(name="PROPERTY_FULL_ADDRESS")
	private String propertyFullAddress;
	
	@Column(name="BORROWER_NAME")
	private String borrowerName;
	
	@Column(name="LOAN_NUMBER")
	private String loanNumber;
	
	@Column(name="LINE_OF_BUSINESS")
	private String lineOfBusiness;
	
	@Column(name = "SOURCE_SYSTEM")
	private String sourceSystem;
	
	@Column(name = "FLOOD_ZONE")
	private String floodZone;

	@Column(name = "PARTICIPATING_COMM")
	private String participatingCommunity;
	
	@Column(name = "SOURCE_CREATION_DATE")
	private Date sourceCreationDate;
	
	@Column(name = "TASK_CREATION_TIME")
	private Date taskCreationDate;
	
	@Column(name = "INITIATOR_ID")
	private String initiatorId;
	
	@Column(name = "STATUS_CHANGE")
	private String statusChange;
	
	@Column(name = "REQUEST_NUM")
	private String requestNumber;
	
	@Column(name = "TASK_STATUS")
	private String taskStatus;
	
	@Transient
	private String strSlaDaysRemaining;
	
	@Column(name = "TASK_UPDATED_BY")
	private String taskUpdatedBy;
	
	@Column(name = "TASK_INSERTED_BY")
	private String taskInsertedBy;
	
	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	
	public String getStrSlaDaysRemaining() {
		return strSlaDaysRemaining;
	}

	public void setStrSlaDaysRemaining(String strSlaDaysRemaining) {
		this.strSlaDaysRemaining = strSlaDaysRemaining;
	}
	
	public String getRequestNumber() {
		return requestNumber;
	}

	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}

	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getCollateralId() {
		return collateralId;
	}

	public void setCollateralId(String collateralId) {
		this.collateralId = collateralId;
	}

	public String getCtracUniqueId() {
		return ctracUniqueId;
	}

	public void setCtracUniqueId(String ctracUniqueId) {
		this.ctracUniqueId = ctracUniqueId;
	}

	public String getTmTaskId() {
		return tmTaskId;
	}

	public void setTmTaskId(String tmTaskId) {
		this.tmTaskId = tmTaskId;
	}

	public Integer getSlaDaysRemaining() {
		return slaDaysRemaining;
	}

	public void setSlaDaysRemaining(Integer slaDaysRemaining) {
		this.slaDaysRemaining = slaDaysRemaining;
	}

	public String getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}

	public String getWorkFlowStep() {
		return workFlowStep;
	}

	public void setWorkFlowStep(String workFlowStep) {
		this.workFlowStep = workFlowStep;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getPropertyFullAddress() {
		return propertyFullAddress;
	}

	public void setPropertyFullAddress(String propertyFullAddress) {
		this.propertyFullAddress = propertyFullAddress;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public String getStatusChange() {
		return statusChange;
	}

	public void setStatusChange(String statusChange) {
		this.statusChange = statusChange;
	}

	public String getInitiatorId() {
		return initiatorId;
	}

	public void setInitiatorId(String initiatorId) {
		this.initiatorId = initiatorId;
	}

	public Date getTaskCreationDate() {
		return taskCreationDate;
	}

	public void setTaskCreationDate(Date taskCreationDate) {
		this.taskCreationDate = taskCreationDate;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getParticipatingCommunity() {
		return participatingCommunity;
	}

	public void setParticipatingCommunity(String participatingCommunity) {
		this.participatingCommunity = participatingCommunity;
	}

	public Date getSourceCreationDate() {
		return sourceCreationDate;
	}

	public void setSourceCreationDate(Date sourceCreationDate) {
		this.sourceCreationDate = sourceCreationDate;
	}

	public String getTaskUpdatedBy() {
		return taskUpdatedBy;
	}

	public void setTaskUpdatedBy(String taskUpdatedBy) {
		this.taskUpdatedBy = taskUpdatedBy;
	}

	public String getTaskInsertedBy() {
		return taskInsertedBy;
	}

	public void setTaskInsertedBy(String taskInsertedBy) {
		this.taskInsertedBy = taskInsertedBy;
	}
	
	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	@Override
	public String getGenericId() {		
		return tmTaskId;
	}

	@Override
	public void fillTransientVariables() {
		setStrSlaDaysRemaining((slaDaysRemaining==null)?"":slaDaysRemaining.toString());
		
	}
	

}
