package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "TLCP_LOB_AVAILABILITY")
public class LobAvailability extends CtracBaseEntity {

    @Id
    @NotNull
    @Column(name = "RID")
    private Long rid;

    @NotNull
    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "SERVICER_CODE")
    private String servicerCode;

    @ManyToOne
    @JoinColumn(name = "LOB_RID")
    private LineOfBusiness lineOfBusiness;

    @NotNull
    @Column(name = "ACTIVE")
    private Boolean active;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getServicerCode() {
        return servicerCode;
    }

    public void setServicerCode(String servicerCode) {
        this.servicerCode = servicerCode;
    }

    public LineOfBusiness getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(LineOfBusiness lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

}
