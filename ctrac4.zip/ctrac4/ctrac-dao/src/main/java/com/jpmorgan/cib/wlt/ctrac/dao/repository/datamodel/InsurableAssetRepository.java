package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface InsurableAssetRepository extends JpaRepository<InsurableAsset, Long> {
	List<InsurableAsset> findByRidIn (Collection<Long> rids);

	List<InsurableAsset> findByBuildingCollateralRid(Long collateralRid);
}
