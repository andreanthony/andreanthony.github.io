package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;

@Entity
@Table(name = "VLCP_LP_POLICY_REQUEST_DATA")
public class LPPolicyRequestViewData implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "RID")
	Long rid ;

	@OneToOne
	@JoinColumn(name = "PROOF_OF_COVERAGE_RID", referencedColumnName = "RID")
	private ProofOfCoverage proofOfCoverage;
	
	@OneToOne
	@JoinColumn(name = "LENDER_PLACE_ITEM_RID", referencedColumnName = "RID") 
	private LenderPlaceItem lenderPlaceItem;
	
	@Column(name = "LOAN_RID")
    private Long loanRid;
	
	@Column(name = "LP_SEND_DATE")
    private Date lpSendDate;


	@Column(name = "LOAN_NUMBER")
	private String loanNumber;


	@Column(name = "ESCROW_TYPE")
	private String escrowType;

	@Column(name = "LINE_OF_BUSINESS")
	private String lineOfBusiness;

	/**
	 * Used for Assurant; contains Building Name
	 */
	@Deprecated
	@Column(name = "PROPERTY_ADDRESS")
	private String propertyAddress;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "BUILDING_NAME")
	private String buildingName;
	
	@Column(name = "PROPERTY_STREET")
	private String propertyStreet;

	@Column(name = "PROPERTY_UNIT_BLDG")
	private String propertyUnitBldg;
	
	@Column(name = "PROPERTY_CITY")
	private String propertyCity;
	
	@Column(name = "PROPERTY_STATE")
	private String propertyState;
	
	@Column(name = "PROPERTY_ZIPCODE")
	private String propertyZipCode;
	
	@Column(name = "MORTGAGOR_ADDRESS")
	private String mortgagorAddress;

	@Column(name = "MORTGAGOR_UNIT_BLDG")
	private String mortgagorUnitBldg;
	
	@Column(name = "MORTGAGOR_CITY")
	private String mortgagorCity;
	
	@Column(name = "MORTGAGOR_STATE")
	private String mortgagorState;
	
	@Column(name = "MORTGAGOR_ZIP_CODE")
	private String mortgagorZipCode;

	@Column(name = "PROPERTY_TYPE")
	private String propertyType;

	@Column(name="FLOOD_ZONE")
	private String floodZone;
		
	@Column(name = "VERIFIER_BUILDING_COVERAGE_AMT")
	private BigDecimal buildingCoverageAmount;

	@Column(name = "VERIFIER_CONTENTS_COVERAGE_AMT")
	private BigDecimal contentsCoverageAmount;
	
	@Column(name = "VERIFIER_BUS_COVERAGE_AMT")
	private BigDecimal businessCoverageAmount;

	@Column(name = "VALUE_BASED_ON")
	private String valueBasedOn;
	
	@Column(name = "BUILDING_CONTENTS_COV")
	private String buildingContentsCov;
	
	@Column(name ="FLOOD_COVERAGE_TYPE")
	private String floodCoverageType;
	
	@Column(name ="LP_SPECIAL_PROCESSING")
	private String specialProcessing;
	
	@Column(name = "EFFECTIVE_DATE")
	private Date effectiveDate;
	
	/**
	 * Used for Assurant
	 */
	@Deprecated
	@Column(name = "ALL_OWNER_AND_BORROWER_NAMES")
	private String allOwnerAndBorrowerNames;
	
	@Column(name = "INSURABLE_ASSET_RID")
	private Long insurableAssetRid;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}

	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	public LenderPlaceItem getLenderPlaceItem() {
		return lenderPlaceItem;
	}

	public void setLenderPlaceItem(LenderPlaceItem lenderPlaceItem) {
		this.lenderPlaceItem = lenderPlaceItem;
	}

	public Long getLoanRid() {
		return loanRid;
	}

	public void setLoanRid(Long loanRid) {
		this.loanRid = loanRid;
	}

	public Date getLpSendDate() {
		return lpSendDate;
	}

	public void setLpSendDate(Date lpSendDate) {
		this.lpSendDate = lpSendDate;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getPropertyStreet() {
		return propertyStreet;
	}

	public void setPropertyStreet(String propertyStreet) {
		this.propertyStreet = propertyStreet;
	}

	public String getPropertyUnitBldg() {
		return propertyUnitBldg;
	}

	public void setPropertyUnitBldg(String propertyUnitBldg) {
		this.propertyUnitBldg = propertyUnitBldg;
	}

	public String getPropertyCity() {
		return propertyCity;
	}

	public void setPropertyCity(String propertyCity) {
		this.propertyCity = propertyCity;
	}

	public String getPropertyState() {
		return propertyState;
	}

	public void setPropertyState(String propertyState) {
		this.propertyState = propertyState;
	}

	public String getPropertyZipCode() {
		return propertyZipCode;
	}

	public void setPropertyZipCode(String propertyZipCode) {
		this.propertyZipCode = propertyZipCode;
	}

	public String getMortgagorAddress() {
		return mortgagorAddress;
	}

	public void setMortgagorAddress(String mortgagorAddress) {
		this.mortgagorAddress = mortgagorAddress;
	}

	public String getMortgagorUnitBldg() {
		return mortgagorUnitBldg;
	}

	public void setMortgagorUnitBldg(String mortgagorUnitBldg) {
		this.mortgagorUnitBldg = mortgagorUnitBldg;
	}

	public String getMortgagorCity() {
		return mortgagorCity;
	}

	public void setMortgagorCity(String mortgagorCity) {
		this.mortgagorCity = mortgagorCity;
	}

	public String getMortgagorState() {
		return mortgagorState;
	}

	public void setMortgagorState(String mortgagorState) {
		this.mortgagorState = mortgagorState;
	}

	public String getMortgagorZipCode() {
		return mortgagorZipCode;
	}

	public void setMortgagorZipCode(String mortgagorZipCode) {
		this.mortgagorZipCode = mortgagorZipCode;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public BigDecimal getBuildingCoverageAmount() {
		return buildingCoverageAmount;
	}

	public void setBuildingCoverageAmount(BigDecimal buildingCoverageAmount) {
		this.buildingCoverageAmount = buildingCoverageAmount;
	}

	public BigDecimal getContentsCoverageAmount() {
		return contentsCoverageAmount;
	}

	public void setContentsCoverageAmount(BigDecimal contentsCoverageAmount) {
		this.contentsCoverageAmount = contentsCoverageAmount;
	}

	public String getValueBasedOn() {
		return valueBasedOn;
	}

	public void setValueBasedOn(String valueBasedOn) {
		this.valueBasedOn = valueBasedOn;
	}

	public String getBuildingContentsCov() {
		return buildingContentsCov;
	}

	public void setBuildingContentsCov(String buildingContentsCov) {
		this.buildingContentsCov = buildingContentsCov;
	}

	public String getFloodCoverageType() {
		return floodCoverageType;
	}

	public void setFloodCoverageType(String floodCoverageType) {
		this.floodCoverageType = floodCoverageType;
	}

	public String getSpecialProcessing() {
		return specialProcessing;
	}

	public void setSpecialProcessing(String specialProcessing) {
		this.specialProcessing = specialProcessing;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getAllOwnerAndBorrowerNames() {
		return allOwnerAndBorrowerNames;
	}

	public void setAllOwnerAndBorrowerNames(String allOwnerAndBorrowerNames) {
		this.allOwnerAndBorrowerNames = allOwnerAndBorrowerNames;
	}

	public Long getInsurableAssetRid() {
		return insurableAssetRid;
	}

	public void setInsurableAssetRid(Long insurableAssetRid) {
		this.insurableAssetRid = insurableAssetRid;
	}

	public void setEscrowType(String escrowType) {
		this.escrowType = escrowType;
	}

	public String getEscrowType() {
		return escrowType;
	}

	public BigDecimal getBusinessCoverageAmount() {
		return businessCoverageAmount;
	}

	public void setBusinessCoverageAmount(BigDecimal businessCoverageAmount) {
		this.businessCoverageAmount = businessCoverageAmount;
	}

}
