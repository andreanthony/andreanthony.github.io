package com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements;

import java.io.Serializable;

public class GroupMemebersPK implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2763176719460894720L;
	
	public Users users;
	public Groups groups;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((users == null) ? 0 : users.hashCode());
		result = prime * result
				+ ((groups == null) ? 0 : groups.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupMemebersPK other = (GroupMemebersPK) obj;
		if (users == null) {
			if (other.users != null)
				return false;
		} else if (!users.equals(other.users))
			return false;
		if (groups == null) {
			if (other.groups != null)
				return false;
		} else if (!groups.equals(other.groups))
			return false;
		return true;
	}
	
}
