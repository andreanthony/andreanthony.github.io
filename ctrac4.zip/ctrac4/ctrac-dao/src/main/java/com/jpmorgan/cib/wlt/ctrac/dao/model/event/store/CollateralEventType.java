package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store;

import java.util.ArrayList;
import java.util.List;

public enum CollateralEventType {
    COLLATERAL_CREATED("Collateral Created"),
    COLLATERAL_PLEDGED("Collateral Pledged"),
    COLLATERAL_RELEASED("Collateral Released"),
    COLLATERAL_DELETED("Collateral Deleted"),
    ADMIN_EDITED("Edited by Admin"),
    VERIFIED_LP_WITH_WORFLOW("Verified with LP Workflow"),
    ADDED("Added"),
    EDITED("Edited"),
    VERIFIED("Verified"),
    DELETED("Deleted"),
    REMOVED("Removed"),
    EXCEPTION_CHANGED("Exception Changed"),
    CREATED("Created"),
    TRANSITIONED("Transitioned"),
    ADMIN_CREATED("Admin Created"),
    ADMIN_TRANSITIONED("Admin Transitioned");

    private final String displayValue;

    CollateralEventType(String displayValue) {
        this.displayValue = displayValue;
    }

    @Override
    public String toString() {
        return displayValue;
    }

    public static List<String> getAllSubscriberEvents(){
        List<String> allSubscribers = new ArrayList<>();
        for(CollateralEventType collateralEventType : CollateralEventType.values()){
            allSubscribers.add(collateralEventType.displayValue);
        }
        return allSubscribers;
    }
}
