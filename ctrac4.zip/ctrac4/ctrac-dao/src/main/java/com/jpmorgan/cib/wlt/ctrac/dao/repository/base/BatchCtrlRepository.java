package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BatchCtrl;


public interface BatchCtrlRepository extends JpaRepository<BatchCtrl, Long>{
	
	public List<BatchCtrl> findByBatchType(String batchType);
	
	public List<BatchCtrl> findByBatchTypeAndCtrlFlag(String batchType, Character ctrlFlag);
	
	public List<BatchCtrl> findByRunning(Character running);
	public List<BatchCtrl> findByCanHoldReleaseFlag(Character canHoldReleaseFlag);
	
	public List<BatchCtrl> findByRunningAndBatchType(Character running, String batchType);
	
	List<BatchCtrl> findByRunningAndBatchTypeIn(Character running, Collection<String> batchTypes);
 
}
