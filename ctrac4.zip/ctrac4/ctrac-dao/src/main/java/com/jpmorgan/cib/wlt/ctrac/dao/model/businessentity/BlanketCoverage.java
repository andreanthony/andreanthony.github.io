package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "TLCP_BLANKET_COVERAGE")
public class BlanketCoverage {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "blanketCoverageSeqGenerator")
	@TableGenerator(name = "blanketCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BLANKET_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "BLANKET_COVERAGE_TYPE")
	private String blanketCoverageType;
	
	@Column(name = "BLANKET_COMBINED_AMOUNT")
	private BigDecimal blanketCombinedAmount;
	
	@Column(name = "BLANKET_BUILDING_AMOUNT")
	private BigDecimal blanketBuildingAmount;
	
	@Column(name = "BLANKET_CONTENT_AMOUNT")
	private BigDecimal blanketContentAmount;
		
	public Long getRid() {
		return rid;
	}
	
	public void setRid(Long rid) {
		this.rid = rid;
	}
	
	public String getBlanketCoverageType() {
		return blanketCoverageType;
	}
	
	public void setBlanketCoverageType(String blanketCoverageType) {
		this.blanketCoverageType = blanketCoverageType;
	}
	
	public BigDecimal getBlanketCombinedAmount() {
		return blanketCombinedAmount;
	}
	
	public void setBlanketCombinedAmount(BigDecimal blanketCombinedAmount) {
		this.blanketCombinedAmount = blanketCombinedAmount;
	}
	
	public BigDecimal getBlanketBuildingAmount() {
		return blanketBuildingAmount;
	}
	
	public void setBlanketBuildingAmount(BigDecimal blanketBuildingAmount) {
		this.blanketBuildingAmount = blanketBuildingAmount;
	}
	
	public BigDecimal getBlanketContentAmount() {
		return blanketContentAmount;
	}
	
	public void setBlanketContentAmount(BigDecimal blanketContentAmount) {
		this.blanketContentAmount = blanketContentAmount;
	}
	
}
