package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "TLCP_PERFECTION_TASK")
public class PerfectionTask extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "perfectionTaskSeqGenerator")
	@TableGenerator(name = "perfectionTaskSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_PERFECTION_TASK", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "WORK_ITEM_RID")
	private WorkItem workItem;

    @Column(name = "OTM_TASK_ID")
	private String tmTaskId;

	@Column(name = "SLA_DAYS_REMAINING")
	private int slaDaysRemaining;
	
	@Column(name = "EOD_JOB_LAST_UPDATED")
	private Date eodJobLastUpdated;
	
	@Column(name = "TASK_STATUS")
	private String taskStatus;
	
	@Column(name = "WAKE_UP_DATE")
	private Date wakeUpDate;
	
	@Column(name = "OTM_TASK_TYPE")
	private String tmTaskType;
	
	@Column(name = "WORKFLOW_STEP")
	private String workflowStep;
	
	@Column(name = "IN_INSURANCE_REVIEW")
	private String inInsuranceReview;
	
	@Column(name = "JBPM_PROCESS_ID")
	private Long jbpmProcessID;

	@Column(name = "CLOSE_REASON_CODE")
	private String closeReason;
	
	@Column(name = "CLOSE_RSN_CMNTS")
	private String closeReasonComments;
	
	@Column(name = "EXECUTION_DATE")
	private Date executionDate;

	@Transient
	private String loadTimeTaskStatus;

    @Transient
	private String loadTimeWorkflowStep;

    @Transient
	private Date loadTimeWakeUpDate;

    @Transient
	private Date loadTimeExecutionDate;

    @Transient
    private boolean isUpdatedByAdmin;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public String getTmTaskId() {
		return tmTaskId;
	}

	public void setTmTaskId(String tmTaskId) {
		this.tmTaskId = tmTaskId;
	}

	public int getSlaDaysRemaining() {
		return slaDaysRemaining;
	}

	public void setSlaDaysRemaining(int slaDaysRemaining) {
		this.slaDaysRemaining = slaDaysRemaining;
	}

	public Date getEodJobLastUpdated() {
		return eodJobLastUpdated;
	}

	public void setEodJobLastUpdated(Date eodJobLastUpdated) {
		this.eodJobLastUpdated = eodJobLastUpdated;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public Date getWakeUpDate() {
		return wakeUpDate;
	}

	public void setWakeUpDate(Date wakeUpDate) {
		this.wakeUpDate = wakeUpDate;
	}

	public String getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}

	public String getWorkflowStep() {
		return workflowStep;
	}

	public void setWorkflowStep(String workflowStep) {
		this.workflowStep = workflowStep;
	}

	public String getInInsuranceReview() {
		return inInsuranceReview;
	}

	public void setInInsuranceReview(String inInsuranceReview) {
		this.inInsuranceReview = inInsuranceReview;
	}

	public Long getJbpmProcessID() {
		return jbpmProcessID;
	}

	public void setJbpmProcessID(Long jbpmProcessID) {
		this.jbpmProcessID = jbpmProcessID;
	}

	/**
	 * @return the closeReason
	 */
	public String getCloseReason() {
		return closeReason;
	}

	/**
	 * @param closeReason the closeReason to set
	 */
	public void setCloseReason(String closeReason) {
		this.closeReason = closeReason;
	}

	/**
	 * @return the closeReasonComments
	 */
	public String getCloseReasonComments() {
		return closeReasonComments;
	}

	/* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((rid == null) ? 0 : rid.hashCode());
        return result;
    }
    
    

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PerfectionTask other = (PerfectionTask) obj;
        
        if (rid == null) {
            
            if (other.rid != null) return false;
            
            if (tmTaskId == null) {
                if (other.tmTaskId != null)
                    return false;
            } else if (!tmTaskId.equals(other.tmTaskId))
                return false;
            return true; //rid null but same tm task id
        }else if (!rid.equals(other.rid))
            return false;
        return true;
    }
    

    /**
	 * @param closeReasonComments the closeReasonComments to set
	 */
	public void setCloseReasonComments(String closeReasonComments) {
		this.closeReasonComments = closeReasonComments;
	}

	public Date getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(Date executionDate) {
		this.executionDate = executionDate;
	}

    public String getLoadTimeTaskStatus() {
        return loadTimeTaskStatus;
    }

    public void setLoadTimeTaskStatus(String loadTimeTaskStatus) {
        this.loadTimeTaskStatus = loadTimeTaskStatus;
    }

    public String getLoadTimeWorkflowStep() {
        return loadTimeWorkflowStep;
    }

    public void setLoadTimeWorkflowStep(String loadTimeWorkflowStep) {
        this.loadTimeWorkflowStep = loadTimeWorkflowStep;
    }

	public Date getLoadTimeWakeUpDate() {
		return loadTimeWakeUpDate;
	}

	public void setLoadTimeWakeUpDate(Date loadTimeWakeUpDate) {
		this.loadTimeWakeUpDate = loadTimeWakeUpDate;
	}

	public Date getLoadTimeExecutionDate() {
		return loadTimeExecutionDate;
	}

	public void setLoadTimeExecutionDate(Date loadTimeExecutionDate) {
		this.loadTimeExecutionDate = loadTimeExecutionDate;
	}

	public void resetLoadTimeValues() {
		setLoadTimeTaskStatus(taskStatus);
		setLoadTimeWorkflowStep(workflowStep);
		setLoadTimeWakeUpDate(wakeUpDate);
		setLoadTimeExecutionDate(executionDate);
	}

	public void setLoadTimeValues() {
		if (loadTimeTaskStatus == null) {
			setLoadTimeTaskStatus(taskStatus);
		}
		if (loadTimeWorkflowStep == null) {
			setLoadTimeWorkflowStep(workflowStep);
		}
		if (loadTimeWakeUpDate == null) {
			setLoadTimeWakeUpDate(wakeUpDate);
		}
		if (loadTimeExecutionDate == null) {
			setLoadTimeExecutionDate(executionDate);
		}
	}

	public boolean hasChanged() {
		return !Objects.equals(taskStatus, loadTimeTaskStatus)
				|| !Objects.equals(workflowStep, loadTimeWorkflowStep)
				|| (isUpdatedByAdmin && (!Objects.equals(wakeUpDate, loadTimeWakeUpDate)
				|| !Objects.equals(executionDate, loadTimeExecutionDate)));
	}

    public boolean isUpdatedByAdmin() {
        return isUpdatedByAdmin;
    }

    public void setUpdatedByAdmin(boolean updatedByAdmin) {
        isUpdatedByAdmin = updatedByAdmin;
    }
}
