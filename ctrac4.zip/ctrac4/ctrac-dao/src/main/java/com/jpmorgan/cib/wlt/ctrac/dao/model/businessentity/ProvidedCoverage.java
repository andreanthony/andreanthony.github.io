package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

@Entity
@Table(name = "TLCP_PROVIDED_COVERAGE")
public class ProvidedCoverage extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "providedCoverageSeqGenerator")
	@TableGenerator(name = "providedCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_PROVIDED_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@OneToOne(cascade=CascadeType.PERSIST, orphanRemoval = true)
	@JoinColumn(name = "COVERAGE_DETAILS_ID", nullable = false)
	private CoverageDetails coverageDetails;
	
	@Column(name = "FLOOD_ZONE")
	private String floodZone;

	@Column(name = "DEDUCTIBLE_AMOUNT")
	private BigDecimal deductibleAmount;
	
	@Column(name = "IND_CONDO_UNIT_NUMBERS")
	private String indCondoUnitNumbers;
	
	@ManyToOne
	@JoinColumn(name = "INSURABLE_ASSET_ID", nullable = false)
	private InsurableAsset insurableAsset;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PROOF_OF_COVERAGE_ID")
	private ProofOfCoverage proofOfCoverage;
	
	
	@Column(name = "COVERAGE_ADJUSTEMENT_IND")
	private String coverageAdjustementIndicator;
	
	@Column(name = "COVERED_BY_BLANKET_POLICY")
	private String coveredByBlanketPolicy;

	@Column(name = "REQUIRED_COVERAGE_RID")
	private Long requiredCoverageRid; //original Required coverage that caused this LPI
	
    public ProvidedCoverage(){
		
	}

	public ProvidedCoverage(ProofOfCoverage proofOfCoverage, InsurableAsset insurableAsset, CoverageDetails coverageDetails){
		
		this.proofOfCoverage = proofOfCoverage;
		proofOfCoverage.addProvidedCoverage(this);
		setCoverageDetails(coverageDetails);
		setInsurableAsset(insurableAsset);
		insurableAsset.addProvidedCoverage(this);
		
	}
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public CoverageDetails getCoverageDetails() {
		return coverageDetails;
	}

	public void setCoverageDetails(CoverageDetails coverageDetails) {
		this.coverageDetails = coverageDetails;
		coverageDetails.setProvidedCoverage(this);
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public BigDecimal getDeductibleAmount() {
		return deductibleAmount;
	}

	public void setDeductibleAmount(BigDecimal deductibleAmount) {
		this.deductibleAmount = deductibleAmount;
	}

	public String getIndCondoUnitNumbers() {
		return indCondoUnitNumbers;
	}

	public void setIndCondoUnitNumbers(String indCondoUnitNumbers) {
		this.indCondoUnitNumbers = indCondoUnitNumbers;
	}

	public InsurableAsset getInsurableAsset() {
		return insurableAsset;
	}

	public void setInsurableAsset(InsurableAsset insurableAsset) {
		this.insurableAsset = insurableAsset;
	}

	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}

	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	/**
	 * @return the coverageAdjustementIndicator
	 */
	public String getCoverageAdjustementIndicator() {
		return coverageAdjustementIndicator;
	}

	/**
	 * @param coverageAdjustementIndicator the coverageAdjustementIndicator to set
	 */
	public void setCoverageAdjustementIndicator(String coverageAdjustementIndicator) {
		this.coverageAdjustementIndicator = coverageAdjustementIndicator;
	}
	
	

	public String getCoveredByBlanketPolicy() {
		return coveredByBlanketPolicy;
	}

	public void setCoveredByBlanketPolicy(String coveredByBlanketPolicy) {
		this.coveredByBlanketPolicy = coveredByBlanketPolicy;
	}
	
	public Long getRequiredCoverageRid() {
		return requiredCoverageRid;
	}

	public void setRequiredCoverageRid(Long requiredCoverageRid) {
		this.requiredCoverageRid = requiredCoverageRid;
	}

	public BigDecimal getNetProvidedCoverage (){
		
		BigDecimal coverageAmount = this.getCoverageDetails().getCoverageAmount();
		
		/**
		 * TODO FIXME uncomment this to account the deductible; for now the PO doesnt want any rule 
		 * arround the deductible.
		 * 
	    BigDecimal deductible = new BigDecimal(0);
		if(this.getInsurableAsset() instanceof Structure ){
			deductible = this.getProofOfCoverage().getBuildingDeductible();
		}else{
			deductible = this.getProofOfCoverage().getContentsDeductible();
		}
		if(deductible!=null && deductible.compareTo(new BigDecimal(5000))>0){
			coverageAmount = coverageAmount.subtract(deductible);
		}*/
		
	
		if(coverageAmount.compareTo(new BigDecimal(0))< 0){
			return new BigDecimal(0);
		}
		
		return coverageAmount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProvidedCoverage other = (ProvidedCoverage) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

}
