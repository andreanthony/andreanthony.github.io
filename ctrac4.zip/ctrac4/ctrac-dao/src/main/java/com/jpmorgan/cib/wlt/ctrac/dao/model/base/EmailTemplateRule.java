package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VLCP_EMAIL_TEMPLATE_RULES")
public class EmailTemplateRule {

	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "RULE_SET")
	private String ruleName;
	
    @Column(name = "LOB")
    private String lob;
	   
    @Column(name = "REMAP_TYPE")
    private String remapType; 
    
    @Column(name = "STATUS")
    private String status;
  
    @Column(name = "ESCALATION")
    private String escalation;
    
    @Column(name = "TYPE_ID")
    private String typeId;
    
    @Column(name = "WORKFLOW_STEP_ID")
    private String workflowStepId;
    
    @Column(name = "OTHERS")
    private String others;
   
    @Column(name = "EMAIL_TEMPLATE_CODE")
    private String emailTemplateId;
    
    @Column(name = "ADDITIONAL_INFO")
    private String additionalInfo;
    
	@Column(name = "EMAIL_CATEGORY")
	private String emailCategory;

    /**
     * @return the rid
     */
    public Long getRid() {
        return rid;
    }

    /**
     * @param rid the rid to set
     */
    public void setRid(Long rid) {
        this.rid = rid;
    }

    /**
     * @return the ruleName
     */
    public String getRuleName() {
        return ruleName;
    }

    /**
     * @param ruleName the ruleName to set
     */
    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    /**
     * @return the lob
     */
    public String getLob() {
        return lob;
    }

    /**
     * @param lob the lob to set
     */
    public void setLob(String lob) {
        this.lob = lob;
    }

    /**
     * @return the remapType
     */
    public String getRemapType() {
        return remapType;
    }

    /**
     * @param remapType the remapType to set
     */
    public void setRemapType(String remapType) {
        this.remapType = remapType;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the escalation
     */
    public String getEscalation() {
        return escalation;
    }

    /**
     * @param escalation the escalation to set
     */
    public void setEscalation(String escalation) {
        this.escalation = escalation;
    }

    /**
     * @return the typeId
     */
    public String getTypeId() {
        return typeId;
    }

    /**
     * @param typeId the typeId to set
     */
    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }


    public String getWorkflowStepId() {
		return workflowStepId;
	}

	public void setWorkflowStepId(String workflowStepId) {
		this.workflowStepId = workflowStepId;
	}

	/**
     * @return the others
     */
    public String getOthers() {
        return others;
    }

    /**
     * @param others the others to set
     */
    public void setOthers(String others) {
        this.others = others;
    }

    /**
     * @return the emailTemplateId
     */
    public String getEmailTemplateId() {
        return emailTemplateId;
    }

    /**
     * @param emailTemplateId the emailTemplateId to set
     */
    public void setEmailTemplateId(String emailTemplateId) {
        this.emailTemplateId = emailTemplateId;
    }

    /**
     * @return the additionalInfo
     */
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * @param additionalInfo the additionalInfo to set
     */
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    /**
     * @return the emailCategory
     */
    public String getEmailCategory() {
        return emailCategory;
    }

    /**
     * @param emailCategory the emailCategory to set
     */
    public void setEmailCategory(String emailCategory) {
        this.emailCategory = emailCategory;
    }
	  
	

}
