package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralInsuranceViewDataPK;

public interface CollateralInsuranceRepository extends JpaRepository<CollateralInsuranceViewData, CollateralInsuranceViewDataPK> {
	
	List<CollateralInsuranceViewData> findByCollateralRid(Long collateralRid);
	
    List<CollateralInsuranceViewData> findByCollateralRidOrderByProofOfCoverageExpirationDateAsc(Long collateralRid);
    
    List<CollateralInsuranceViewData> findByProofOfCoverageRid(Long proofOfCoverageRid);
    
}
