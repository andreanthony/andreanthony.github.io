package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.hibernate.proxy.HibernateProxy;

@MappedSuperclass
public class CtracBaseEntity {
	
	@Column(name = "INSERTED_BY")
	private String insertedBy;
	
	@Column(name = "INSERTED_DATE")
	private Date insertedDate;
	
	@Column(name = "UPDATED_BY")
	private String updatedBy;
	
	@Column(name = "UPDATED_DATE")
	private Date updatedDate;

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	/**
	 * Set the entity class with the 
	 * modification track
	 * 
	 * @param rid The record ID
	 * @param userName The logged in user name
	 */
	
	public void setInitialAuditInfo(String userName){
		Date today = new Date();
		setInsertedBy(userName);
		//setInsertedDate(today);
		setUpdatedBy(userName);
		//setUpdatedDate(today);
	}
	
	public void updateAuditInfo(String userName){
		Date today = new Date();
		setUpdatedBy(userName);
		setUpdatedDate(today);
	}
	
	
	public static <T> T deproxy(Object jassistProxy, Class<T> baseClass) throws ClassCastException {
		   
		if(jassistProxy==null){
			return null;
		}
		if (jassistProxy instanceof HibernateProxy)
		      return baseClass.cast(((HibernateProxy) jassistProxy).getHibernateLazyInitializer().getImplementation());
		   else
		      return baseClass.cast(jassistProxy);
	}

     protected void copy(CtracBaseEntity copy) {
		
		copy.insertedDate = this.insertedDate;
		copy.updatedBy = this.updatedBy;
		copy.updatedDate = this.updatedDate;
		
	}
	
	
}
