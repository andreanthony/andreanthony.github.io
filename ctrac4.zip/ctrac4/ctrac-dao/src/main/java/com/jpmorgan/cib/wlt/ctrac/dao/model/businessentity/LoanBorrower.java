package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_LOAN_BORROWER")
@IdClass(value=LoanBorrowerPk.class)
public class LoanBorrower implements Serializable{

	private static final long serialVersionUID = -6579172369232699974L;

	@Id
	@ManyToOne
	@JoinColumn(name = "LOAN_ID")
	private Loan loan;
	
	@Id
	@ManyToOne
	@JoinColumn(name = "BORROWER_ID")
	private Customer borrower;

	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	public Customer getBorrower() {
		return borrower;
	}

	public void setBorrower(Customer borrower) {
		this.borrower = borrower;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((borrower == null) ? 0 : borrower.hashCode());
		result = prime * result + ((loan == null) ? 0 : loan.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoanBorrower other = (LoanBorrower) obj;
		if (borrower == null) {
			if (other.borrower != null)
				return false;
		} else if (!borrower.equals(other.borrower))
			return false;
		if (loan == null) {
			if (other.loan != null)
				return false;
		} else if (!loan.equals(other.loan))
			return false;
		return true;
	}
}
