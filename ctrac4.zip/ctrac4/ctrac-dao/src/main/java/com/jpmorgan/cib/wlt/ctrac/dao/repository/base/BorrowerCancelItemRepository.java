package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.BorrowerCancelItem;

public interface BorrowerCancelItemRepository extends JpaRepository<BorrowerCancelItem, Long> {
	
	public BorrowerCancelItem findByRid(Long rid);

	public List<BorrowerCancelItem> findByCoverageRequestTaskRid(Long coverageRequestTaskRid);

}
