package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.ProvidedCoverageViewData;

public interface ProvidedCoverageViewRepository extends JpaRepository<ProvidedCoverageViewData, Long> {	
	ProvidedCoverageViewData findByProofOfCoverageRidAndCoverageAmountGreaterThan(Long proodOfCoverageRid, BigDecimal i);	
	
	ProvidedCoverageViewData findByProofOfCoverageRidAndInsurableAssetRid(Long proofOfCoverageRid,Long insurableAssetRid);
}
