package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;

public class CollateralOwnerPk implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Collateral collateral;
	
	private Customer owner;
	
	public CollateralOwnerPk(){}


	/**
	 * @return the collateral
	 */
	public Collateral getCollateral() {
		return collateral;
	}


	/**
	 * @return the owner
	 */
	public Customer getOwner() {
		return owner;
	}


	/**
	 * @param collateral the collateral to set
	 */
	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}


	/**
	 * @param owner the owner to set
	 */
	public void setOwner(Customer owner) {
		this.owner = owner;
	}
}
