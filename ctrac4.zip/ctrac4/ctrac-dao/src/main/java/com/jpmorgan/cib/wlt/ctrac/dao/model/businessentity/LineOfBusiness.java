package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Entity
@Table(name = "TLCP_LINE_OF_BUSINESS")
public class LineOfBusiness extends CtracBaseEntity {

    @Id
    @NotNull
    @Column(name = "RID")
    private Long rid;

    @NotNull
    @Column(name = "CODE_CONST")
    private String codeConst;

    @NotNull
    @Column(name = "CODE")
    private String code;

    @NotNull
    @Column(name = "DESCRIPTION")
    private String description;

    @NotNull
    @Column(name = "JPMC_BRAND")
    private String jpmcBrand;

    @NotNull
    @Column(name = "SERVICING_GROUP")
    private String servicingGroup;

    @ManyToOne
    @JoinColumn(name = "PARENT_LOB")
    private LineOfBusiness parentLob;

    @Column(name = "BRANCH_CODE")
    private String branchCode;

    @NotNull
    @Column(name = "SORT_ORDER")
    private Integer sortOrder;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "lineOfBusiness")
    private Set<LobAvailability> lobAvailabilitySet;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getCodeConst() {
        return codeConst;
    }

    public void setCodeConst(String codeConst) {
        this.codeConst = codeConst;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getJpmcBrand() {
        return jpmcBrand;
    }

    public void setJpmcBrand(String jpmcBrand) {
        this.jpmcBrand = jpmcBrand;
    }

    public String getServicingGroup() {
        return servicingGroup;
    }

    public void setServicingGroup(String servicingGroup) {
        this.servicingGroup = servicingGroup;
    }

    public LineOfBusiness getParentLob() {
        return parentLob;
    }

    public void setParentLob(LineOfBusiness parentLob) {
        this.parentLob = parentLob;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public Set<LobAvailability> getLobAvailabilitySet() {
        return lobAvailabilitySet;
    }

    public void setLobAvailabilitySet(Set<LobAvailability> lobAvailabilitySet) {
        this.lobAvailabilitySet = lobAvailabilitySet;
    }

}
