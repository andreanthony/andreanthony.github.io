package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;




@StaticMetamodel(CollateralSearchViewData.class)
public class CollateralSearchViewData_ {
	
	public static volatile SingularAttribute<CollateralSearchViewData,Long> rid;
	
	public static volatile SingularAttribute<CollateralSearchViewData,Long> collateralRid;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> collateralId;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> collateralType;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> workflowId;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> propertyAddress;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> propertyCity;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> propertyZipCode;	
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> propertyState;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> propertyCounty;	
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> ownerName;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> propertyFullAddress;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> loanNumber;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> lineOfBusiness;
	public static volatile SingularAttribute<CollateralSearchViewData,String> lobCode;

	public static volatile SingularAttribute<CollateralSearchViewData,String> loanAccountingSystem;	
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> borrowerName;	
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> borrowerAddress;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> borrowerCity;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> borrowerZipCode;	
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> borrowerState;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> collateralStatus;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> policyNumber;
	
	public static volatile SingularAttribute<CollateralSearchViewData,String> unitBuilding;
}
