package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search;

import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;

import java.util.List;

public class AuditRetrieveResult {

    private List<AuditEventDTO> auditData;
    private long total;

    public AuditRetrieveResult(List<AuditEventDTO> auditData, long total){
        this.auditData = auditData;
        this.total = total;
    }

    public List<AuditEventDTO> getAuditData() {
        return auditData;
    }

    public void setAuditData(List<AuditEventDTO> auditData) {
        this.auditData = auditData;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }
}
