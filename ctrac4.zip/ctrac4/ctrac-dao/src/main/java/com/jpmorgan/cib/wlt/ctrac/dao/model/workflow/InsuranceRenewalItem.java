package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

@Entity
@Table(name = "TLCP_INSURANCE_RENEWAL_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class InsuranceRenewalItem extends WorkItem {

	@Column(name = "PRE_RENEWAL_LETTER_DATE")
	private Date preRenewalLetterDate;

	@Column(name = "WORKFLOW_TYPE")
	private String workflowType;
	
	public Date getPreRenewalLetterDate() {
		return preRenewalLetterDate;
	}

	public void setPreRenewalLetterDate(Date preRenewalLetterDate) {
		this.preRenewalLetterDate = preRenewalLetterDate;
	}

	public void addProofOfCoverage(ProofOfCoverage proofOfCoverage, String itemRelType){
		ProofOfCovWorkItem proofOfCovWorkItem = null;
		if(this.proofOfCovWorkItems.isEmpty()){
			proofOfCovWorkItem = new ProofOfCovWorkItem();
			proofOfCovWorkItems.add(proofOfCovWorkItem);
		}
		proofOfCovWorkItem = proofOfCovWorkItems.get(0);
		proofOfCovWorkItem.setWorkItem(this);
		proofOfCovWorkItem.setProofOfCoverage(proofOfCoverage);
		proofOfCovWorkItem.setItemType(itemRelType);
	}
	
	public ProofOfCoverage getProofOfCoverage(){
		if(this.proofOfCovWorkItems.isEmpty()){
			return null;
		}
		else{
			return proofOfCovWorkItems.get(0).getProofOfCoverage();
		}
	}

	public String getWorkflowType() {
		return this.workflowType;
	}

	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}
	
}