package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;

@Entity
@Table(name = "TLCP_COLLATERAL_WORK_ITEM")
@IdClass(value=CollateralWorkItemPk.class)
public class CollateralWorkItem  implements Serializable {

	private static final long serialVersionUID = -3107325511375038748L;

	@Id
	@ManyToOne
	@JoinColumn(name = "COLLATERAL_ID")
	private Collateral collateral;


	@Id
	@ManyToOne
	@JoinColumn(name = "WORK_ITEM_ID")
	private WorkItem workItem;
	
	/**
     * @return the type
     */
    public String getType() {
        return type;
    }


    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }


    @Column(name="TYPE")
	private String type;


	public Collateral getCollateral() {
		return collateral;
	}


    public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}


	public WorkItem getWorkItem() {
		return workItem;
	}


	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((collateral == null) ? 0 : collateral.hashCode());
		result = prime * result + ((workItem == null) ? 0 : workItem.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollateralWorkItem other = (CollateralWorkItem) obj;
		if (collateral == null) {
			if (other.collateral != null)
				return false;
		}
		else if (!collateral.equals(other.collateral))
			return false;
		if (workItem == null) {
			if (other.workItem != null)
				return false;
		}
		else if (!workItem.equals(other.workItem))
			return false;
		return true;
	}


	
}
