package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import org.apache.commons.lang.StringUtils;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "TLCP_COLLATERAL")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Collateral extends CtracBaseEntity implements Serializable {

	private static final long serialVersionUID = 3696482819519887148L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "collateralSeqGenerator")
	@TableGenerator(name = "collateralSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_COLLATERAL", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@OrderBy("RID DSC")
	@Column(name = "RID")
	private Long rid;

	@Column(name = "COLLATERAL_REF_ID")
	private String collateralRefId;

	@Column(name = "COLLATERAL_TYPE")
	private String collateralType;

	@Column(name = "COLLATERAL_STATUS")
	private String collateralStatus;

	@Column(name = "LEGAL_DESCRIPTION")
	private String legalDescription;

	@Column(name = "COLLATERAL_SUB_TYPE")
	private String collateralSubType;

	@Column(name = "EMAIL_RID")
	private Long emailRid;

	@Column(name = "RELEASE_COMMENT")
	private String releaseComment;

	@Column(name = "RELEASE_DATE")
	private Date releaseDate;

	@Column(name = "ADMIN_COMMENTS")
	private String adminComments;

	public String getReleaseComment() {
		return releaseComment;
	}
	public void setReleaseComment(String releaseComment) {
		this.releaseComment = releaseComment;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getAdminComments() {
		return adminComments;
	}

	public void setAdminComments(String adminComments) {
		this.adminComments = adminComments;
	}

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "collateral")
	private List<LoanCollateral> loanCollaterals = new ArrayList<>();

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "collateralRid")
	private List<FloodDetermination> floodDeterminations = new ArrayList<>();

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "collateral")
	private List<CollateralWorkItem> collateralWorkItems = new ArrayList<>();

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "collateral")
	private List<CollateralOwner> collateralOwners = new ArrayList<>();

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "collateral")
	private List<Building> buildings = new ArrayList<>();

	@OneToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name = "PHYSICAL_ADDRESS_ID")
	private Address address;

	public void addWorkItem(WorkItem workItem) {
		addWorkItem(workItem, null);
	}

	public void addWorkItem(WorkItem workItem, String type) {
		CollateralWorkItem collateralWorkItem = new CollateralWorkItem();
		collateralWorkItem.setWorkItem(workItem);
		collateralWorkItem.setCollateral(this);
		if (!collateralWorkItems.contains(collateralWorkItem)) {
			if(!StringUtils.isBlank(type)){collateralWorkItem.setType(type);}
			collateralWorkItems.add(collateralWorkItem);
		}
	}

	public List<CollateralWorkItem> getCollateralWorkItems() {
		return collateralWorkItems;
	}

	public void addLoan(Loan loan) {
		for(LoanCollateral loanCollateral: loanCollaterals){
			if(loanCollateral.getLoan().equals(loan)){
				return;
			}
		}
		LoanCollateral loanCollateral = new LoanCollateral();
		loanCollateral.setLoan(loan);
		loanCollateral.setCollateral(this);
		loanCollaterals.add(loanCollateral);
	}

	public void addPrimaryLoan(Loan loan) {
		for(LoanCollateral loanCollateral: loanCollaterals){
			loanCollateral.setPrimaryFlag(null);
		}
		for(LoanCollateral loanCollateral: loanCollaterals){
			if(loanCollateral.getLoan().equals(loan)){
				loanCollateral.setPrimaryFlag("Yes");
				return;
			}
		}
		LoanCollateral loanCollateral = new LoanCollateral();
		loanCollateral.setLoan(loan);
		loanCollateral.setPrimaryFlag("Yes");
		loanCollateral.setCollateral(this);
		loanCollaterals.add(loanCollateral);
	}

	public List<FloodDetermination> getFloodDeterminations() {
		return floodDeterminations;
	}

	public void addOwner(Customer owner){
		for(CollateralOwner collateralOwner: collateralOwners){
			if(collateralOwner.getOwner().equals(owner)){
				return;
			}
		}
		CollateralOwner collateralOwner = new CollateralOwner();
		collateralOwner.setOwner(owner);
		collateralOwner.setCollateral(this);
		collateralOwners.add(collateralOwner);
	}

	public void addOwner(Customer owner, Character borrowerSameAsOwner, String userId) {
		for(CollateralOwner collateralOwner: collateralOwners){
			if(collateralOwner.getOwner().equals(owner)){
				return;
			}
		}
		CollateralOwner collateralOwner = new CollateralOwner();
		collateralOwner.setBorrowerSameAsOwner(borrowerSameAsOwner);
		collateralOwner.setOwner(owner);
		collateralOwner.setCollateral(this);
		collateralOwners.add(collateralOwner);
	}

	public List<Building> getBuildings() {
		return buildings;
	}

	public void setBuildings(List<Building> buildings) {
		this.buildings = buildings;
	}

	public List<CollateralOwner> getCollateralOwners() {
		return collateralOwners;
	}

	public String getCollateralDescription() {
		if (CollateralType.REAL_ESTATE.getCode().equals(this.getCollateralType())) {
			return this.getAddress().getFormattedFullAddress();
		} else if (CollateralType.BUSINESS_ASSETS.getCode().equals(this.getCollateralType())) {
			return this.getLegalDescription();
		}
		return "";
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getCollateralRefId() {
		return collateralRefId;
	}

	public void setCollateralRefId(String collateralRefId) {
		this.collateralRefId = collateralRefId;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public String getCollateralStatus() {
		return collateralStatus;
	}

	public void setCollateralStatus(String collateralStatus) {
		this.collateralStatus = collateralStatus;
	}

	public List<LoanCollateral> getLoanCollaterals() {
		return loanCollaterals;
	}

	public List<Loan> getAllLoans(){
		List<Loan> result = new ArrayList<Loan>();
		for(LoanCollateral loanCollateral:loanCollaterals){
			result.add(loanCollateral.getLoan());
		}
		return result;
	}

	public Loan getPreferredLoan(){

		Loan preferredLoan = null;
		Long minRid = Long.MAX_VALUE;
		for (LoanCollateral loanCollateral : loanCollaterals) {

			if( "Yes".equals(loanCollateral.getPrimaryFlag()) ){
				return loanCollateral.getLoan();
			}
			if (loanCollateral.getLoan().getRid() < minRid) {
				preferredLoan = loanCollateral.getLoan();
			}
		}
		return preferredLoan;
	}

	public String getPreferredLoanLOB(){
		Loan preferredLoan = getPreferredLoan();
		if (preferredLoan != null){
			return preferredLoan.getLineOfBusiness();
		}
		return null;
	}



	public Address getAddress() {
		return address;
	}

	public void setAddress(Address physicalAddress) {
		this.address = physicalAddress;
	}

	public String getCollateralSubType() {
		return collateralSubType;
	}

	public void setCollateralSubType(String collateralSubType) {
		this.collateralSubType = collateralSubType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	public String getLegalDescription() {
		return legalDescription;
	}

	public void setLegalDescription(String legalDescription) {
		this.legalDescription = legalDescription;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Collateral other = (Collateral) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

	public Long getEmailRid() {
		return emailRid;
	}

	public void setEmailRid(Long emailRid) {
		this.emailRid = emailRid;
	}
}
