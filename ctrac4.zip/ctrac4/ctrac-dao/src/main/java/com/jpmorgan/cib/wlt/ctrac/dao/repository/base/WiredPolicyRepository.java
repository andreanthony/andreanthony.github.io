package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AccountWireReference;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WiredPolicy;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;



public interface WiredPolicyRepository extends JpaRepository<WiredPolicy, Long> {

	List<WiredPolicy> findByAccountWireReference(AccountWireReference accountWireReference);

	List<WiredPolicy> findByWorkItem(WorkItem workItem);

}
