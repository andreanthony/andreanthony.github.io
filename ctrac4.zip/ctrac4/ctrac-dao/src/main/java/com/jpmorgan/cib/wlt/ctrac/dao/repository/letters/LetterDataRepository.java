/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.dao.repository.letters;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.letters.LetterData;


/**
 * @author Q003321
 *
 */
public interface LetterDataRepository extends JpaRepository<LetterData, Long> {
	
	List<LetterData> findByLetterFileRid(Long rid);

}
