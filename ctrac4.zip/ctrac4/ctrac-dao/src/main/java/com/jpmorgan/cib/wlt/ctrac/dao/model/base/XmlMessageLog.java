/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * @author Q003321
 *
 */
@Entity
@Table(name = "TLCP_XML_MESSAGE_LOG")
public class XmlMessageLog extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "xmlLogSeqGenerator")
	@TableGenerator(name = "xmlLogSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", 
	pkColumnValue = "TLCP_XML_MESSAGE_LOG", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id	
	@Column(name="RID")
	private Long rid;
	
	@Column(name="TASK_ID")
	private String taskid;	

	@Column(name="MSG_SEND_TIME")
	private Date creationDate;
	
	@Column(name="MESSAGE_TYPE")
	private String messageType;
	
	@Column(name="SERVICE_PROVIDER")
	private String serviceProvider;
	
	@Column(name="XML_MESSAGE")
	private String xmlMessage;
	
	/**
	 * @return the rid
	 */
	public Long getRid() {
		return rid;
	}

	/**
	 * @param rid the rid to set
	 */
	public void setRid(Long rid) {
		this.rid = rid;
	}

	/**
	 * @return the taskid
	 */
	public String getTaskid() {
		return taskid;
	}

	/**
	 * @param taskid the taskid to set
	 */
	public void setTaskid(String taskid) {
		this.taskid = taskid;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	/**
	 * @return the serviceProvider
	 */
	public String getServiceProvider() {
		return serviceProvider;
	}

	/**
	 * @param serviceProvider the serviceProvider to set
	 */
	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	/**
	 * @return the xmlMessage
	 */
	public String getXmlMessage() {
		return xmlMessage;
	}

	/**
	 * @param xmlMessage the xmlMessage to set
	 */
	public void setXmlMessage(String xmlMessage) {
		this.xmlMessage = xmlMessage;
	}
	
	
}
