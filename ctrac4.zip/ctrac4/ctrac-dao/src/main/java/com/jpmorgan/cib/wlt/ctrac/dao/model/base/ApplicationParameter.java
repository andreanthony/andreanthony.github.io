package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "TLCP_APPLICATION_PARAMETERS")
public class ApplicationParameter extends CtracBaseEntity implements Serializable {
    private static final long serialVersionUID = -1L;

    @Id
    @Column(name = "PARAM_KEY")
    private String paramKey;

    @Column(name = "DATE_VALUE")
    private Date dateValue;

    @Column(name = "NUMBER_VALUE")
    private BigDecimal numberValue;

    @Column(name = "STRING_VALUE")
    private String stringValue;

    public String getParamKey() {
        return paramKey;
    }

    public void setParamKey(String paramKey) {
        this.paramKey = paramKey;
    }

    public Date getDateValue() {
        return dateValue;
    }

    public void setDateValue(Date dateValue) {
        this.dateValue = dateValue;
    }

    public BigDecimal getNumberValue() {
        return numberValue;
    }

    public void setNumberValue(BigDecimal numberValue) {
        this.numberValue = numberValue;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

}
