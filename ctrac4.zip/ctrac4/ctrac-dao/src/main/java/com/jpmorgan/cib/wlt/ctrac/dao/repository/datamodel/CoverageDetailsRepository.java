package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Hold;
import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.CoverageDetails;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CoverageDetailsRepository extends
		JpaRepository<CoverageDetails, Long> {
    List<CoverageDetails> findByHold(Hold hold);

    @Query("select cd from CoverageDetails cd where cd.hold.rid = ?1")
    List<CoverageDetails> findByHoldRid(Long holdRid);
}
