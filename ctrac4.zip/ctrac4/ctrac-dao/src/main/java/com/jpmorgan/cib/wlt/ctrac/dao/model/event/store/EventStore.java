package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store;


import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.CtracEventSubscriberDTO;

import java.util.List;

public interface EventStore {
    void receive(String event);
    void publish(CtracEvent event);
    void subscribe(List<CtracEventSubscriberDTO> subscription);
}
