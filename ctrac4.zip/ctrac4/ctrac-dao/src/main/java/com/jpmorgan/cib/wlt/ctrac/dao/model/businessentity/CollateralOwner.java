package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_COLLATERAL_OWNER")
@IdClass(value = CollateralOwnerPk.class)
public class CollateralOwner {
	
	@Id
	@ManyToOne
	@JoinColumn(name = "COLLATERAL_ID")
	private Collateral collateral;
	
	@Id
	@ManyToOne
	@JoinColumn(name = "CUSTOMER_ID")
	private Customer owner;

	@Column(name="BORROWER_SAME_AS_OWNER")
	private Character borrowerSameAsOwner;
	
	public Collateral getCollateral() {
		return collateral;
	}

	public Customer getOwner() {
		return owner;
	}

	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}

	public void setOwner(Customer owner) {
		this.owner = owner;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((collateral == null) ? 0 : collateral.hashCode());
		result = prime * result + ((owner == null) ? 0 : owner.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollateralOwner other = (CollateralOwner) obj;
		if (collateral == null) {
			if (other.collateral != null)
				return false;
		} else if (!collateral.equals(other.collateral))
			return false;
		if (owner == null) {
			if (other.owner != null)
				return false;
		} else if (!owner.equals(other.owner))
			return false;
		return true;
	}

	public Character getBorrowerSameAsOwner() {
		return borrowerSameAsOwner;
	}

	public void setBorrowerSameAsOwner(Character borrowerSameAsOwner) {
		this.borrowerSameAsOwner = borrowerSameAsOwner;
	}

}
