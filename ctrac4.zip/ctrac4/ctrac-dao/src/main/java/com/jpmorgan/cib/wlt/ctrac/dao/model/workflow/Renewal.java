package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

@Deprecated
@Entity
@Table(name = "TLCP_RENEWAL")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class Renewal extends CtracBaseEntity{
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "renewalSeqGenerator")
	@TableGenerator(name = "renewalSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_RENEWAL", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "LOAN_ACTIVE")
	private String loanActive;
	
	@Column(name = "REMINDER_TYPE")
	private String reminderType;
	
	@Column(name = "TICKLER_ID")
	private String ticklerID;
	
	@Column(name = "TICKLER_COMMENTS")
	private String ticklerComments;

	@Column(name = "LP_CANCELLATION_DATE_COMMENT")
	private String lpCancellationDateComment;
	
	@Column(name = "PRE_RENEWAL_LETTER_DATE")
	private Date preRenewalLetterDate;
	
	@Column(name = "LP_EFFECTIVE_DATE")
	private Date lpEffectiveDate;	
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "PROOF_OF_COVERAGE_ID")
	private ProofOfCoverage proofOfCoverage;

	public String getLoanActive() {
		return loanActive;
	}
	
	public void setLoanActive(String loanActive) {
		this.loanActive = loanActive;
	}
	
	public String getReminderType() {
		return reminderType;
	}
	
	public void setReminderType(String reminderType) {
		this.reminderType = reminderType;
	}
	
	public String getTicklerID() {
		return ticklerID;
	}
	
	public void setTicklerID(String ticklerID) {
		this.ticklerID = ticklerID;
	}
	
	public String getTicklerComments() {
		return ticklerComments;
	}
	
	public void setTicklerComments(String ticklerComments) {
		this.ticklerComments = ticklerComments;
	}
	
	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}

	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	public String getLpCancellationDateComment() {
		return lpCancellationDateComment;
	}

	public void setLpCancellationDateComment(String lpCancellationDateComment) {
		this.lpCancellationDateComment = lpCancellationDateComment;
	}

	public Date getPreRenewalLetterDate() {
		return preRenewalLetterDate;
	}

	public void setPreRenewalLetterDate(Date preRenewalLetterDate) {
		this.preRenewalLetterDate = preRenewalLetterDate;
	}

	public Date getLpEffectiveDate() {
		return lpEffectiveDate;
	}

	public void setLpEffectiveDate(Date lpEffectiveDate) {
		this.lpEffectiveDate = lpEffectiveDate;
	}

}
