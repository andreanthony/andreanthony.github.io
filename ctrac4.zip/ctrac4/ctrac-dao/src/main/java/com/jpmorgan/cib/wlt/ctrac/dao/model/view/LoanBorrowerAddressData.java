package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_LOAN_BORROWER_ADDRESS")
public class LoanBorrowerAddressData {
	@Id
	@Column(name="ADDRESS_RID")
	private Long addressRid;

	@Column(name="COLLATERAL_RIDS")
	private String collateralRids;
	
	@Column(name="BORROWER_NAME")
	private String borrowerName;
	
	@Column(name="STREET_ADDRESS")
	private String streetAddress;
	
	@Column(name="UNIT_BLNG")
	private String unitBuilding;

	@Column(name="CITY")
	private String city;
	
	@Column(name="STATE_ABBR")
	private String state;
	
	@Column(name="ZIP_CODE")
	private String zipCode;

	public String getCollateralRids() {
		return collateralRids;
	}

	public void setCollateralRids(String collateralRids) {
		this.collateralRids = collateralRids;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getUnitBuilding() {
		return unitBuilding;
	}

	public void setUnitBuilding(String unitBuilding) {
		this.unitBuilding = unitBuilding;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Long getAddressRid() {
		return addressRid;
	}

	public void setAddressRid(Long addressRid) {
		this.addressRid = addressRid;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}	
}
