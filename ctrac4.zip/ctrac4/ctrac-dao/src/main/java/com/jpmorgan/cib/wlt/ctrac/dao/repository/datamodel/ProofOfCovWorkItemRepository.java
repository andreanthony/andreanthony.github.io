package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItemPk;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface ProofOfCovWorkItemRepository extends JpaRepository<ProofOfCovWorkItem, ProofOfCovWorkItemPk> {

	ProofOfCovWorkItem findByWorkItemRidAndProofOfCoverageRid(Long workItemRid, Long proofOfCoverageRid);

	ProofOfCovWorkItem findByWorkItemRidAndItemType(Long workItemRid, String itemType);

	ProofOfCovWorkItem findByWorkItemAndItemType(WorkItem workItem, String itemType);

	List<ProofOfCovWorkItem> findByProofOfCoverageRidAndItemType(Long proofOfCoverageRid, String itemType);

	ProofOfCovWorkItem findByWorkItemRid(Long workItemRid);

}
