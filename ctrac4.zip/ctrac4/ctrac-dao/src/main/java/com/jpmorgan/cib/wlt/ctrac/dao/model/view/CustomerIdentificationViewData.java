package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;

@Entity
@Table(name="VLCP_CUSTOMER_IDENTIFICATION")
@IdClass(value=CustomerIdentificationViewDataPK.class)
public class CustomerIdentificationViewData {
	
	@Id
	@Column(name="COLLATERAL_RID")
	private Long collateralRid;
	
	@Id
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CUSTOMER_RID")
	private Customer customer;
	
	@Column(name="CUSTOMER_TYPE")
	private String customerType;

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	
}
