package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralType;

@Entity
@Table(name = "TLCP_BUSINESS_ASSETS")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class BusinessAssets extends Collateral {

	private static final long serialVersionUID = 7083491804083198901L;


	public BusinessAssets() {
	    super();
	    this.setCollateralType(CollateralType.BUSINESS_ASSETS.getCode());
	}

}
