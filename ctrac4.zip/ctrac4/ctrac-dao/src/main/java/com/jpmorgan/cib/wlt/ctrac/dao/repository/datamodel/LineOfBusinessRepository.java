package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LineOfBusiness;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LineOfBusinessRepository extends JpaRepository<LineOfBusiness, Long> {

    @Query("SELECT lob FROM LineOfBusiness lob JOIN lob.lobAvailabilitySet avail " +
            "WHERE avail.category = :category AND avail.active = 1")
    List<LineOfBusiness> findActiveByCategory(@Param("category") String category);

    @Query("SELECT DISTINCT lob.description FROM LineOfBusiness lob JOIN lob.lobAvailabilitySet avail " +
            "WHERE avail.category IN :categories AND avail.active = :active ORDER BY lob.description")
    List<String> getDescriptionByCategoryInAndActive(@Param("categories") List<String> categories, @Param("active") boolean active);

    @Query("SELECT lob.rid FROM LineOfBusiness lob WHERE lob.description in :descriptions")
    List<Long> getRidByDescriptionIn(@Param("descriptions") List<String> descriptions);

    List<LineOfBusiness> findByCode(String code);
}
