package com.jpmorgan.cib.wlt.ctrac.dao.model.letters;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_COVER_LETTER_SECTION")
public class CoverLetterSection {

	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "TEMPLATE_CODE")
	private String templateCode;
	
    @Column(name = "SECTION_ORDER")
    private Integer sectionOrder;
	   
    @Column(name = "SECTION_NAME")
    private String sectionName; 
    
    @Column(name = "ACTIVE")
    private Boolean active;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getTemplateCode() {
		return templateCode;
	}

	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}

	public Integer getSectionOrder() {
		return sectionOrder;
	}

	public void setSectionOrder(Integer sectionOrder) {
		this.sectionOrder = sectionOrder;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

}
