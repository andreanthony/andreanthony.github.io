package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.InsurableAsset;
import org.springframework.data.jpa.repository.JpaRepository;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.RequiredCoverage;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RequiredCoverageRepository extends
		JpaRepository<RequiredCoverage, Long> {

	@Query("select rc from RequiredCoverage rc where rc.primaryCoverageDetails.hold.rid=?1 or rc.excessCoverageDetails.hold.rid=?1")
	List<RequiredCoverage> findRequiredCoveragesByHoldRid(Long holdRid);

	List<RequiredCoverage> findByInsurableAsset(InsurableAsset asset);
}
