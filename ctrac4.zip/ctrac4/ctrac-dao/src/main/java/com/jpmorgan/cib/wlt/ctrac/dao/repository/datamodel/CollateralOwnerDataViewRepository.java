package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CollateralOwnerViewData;

public interface CollateralOwnerDataViewRepository extends JpaRepository<CollateralOwnerViewData, Long> {	
	List <CollateralOwnerViewData> findByCollateralRid(Long collateralRid);	
	
}
