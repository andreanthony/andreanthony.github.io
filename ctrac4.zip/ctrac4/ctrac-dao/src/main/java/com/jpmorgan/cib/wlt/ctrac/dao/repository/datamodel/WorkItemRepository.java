package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;

public interface WorkItemRepository extends JpaRepository<WorkItem, Long> {

	WorkItem findByRid(Long rid);

	@Query("select workItem from WorkItem workItem, PerfectionTask perfectionTask where perfectionTask.workItem.rid = workItem.rid and perfectionTask.workflowStep = ?1 and perfectionTask.taskStatus = ?2")
	List<WorkItem> findAllByWorkflowStepAndStatus(String workflowStep,String taskStatus);

	List<WorkItem> findByCollateralWorkItemsCollateralRid(Long collateralId);

	List<WorkItem> findByPerfectionTypeAndCollateralWorkItemsCollateralRid(String perfectionType, Long collateralRid);

}
