package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "TLCP_EMAIL_DETAILS")
public class EmailDetails extends CtracBaseEntity {

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "emailDetailsSeqGenerator")
	@TableGenerator(name = "emailDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_EMAIL_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "EMAIL_TO", nullable = false)
	private String emailTo;

	@Column(name = "EMAIL_CC")
	private String emailCC;

	@Column(name = "EMAIL_BCC")
	private String emailBCC;	
	
	@Column(name = "EMAIL_SENDER", nullable = false)
	private String emailSender;	
	
	@Column(name = "EMAIL_VOLTAGE")
	private String emailVoltage;	

	@Column(name = "EMAIL_BODY")
	private String emailBody;
	
	@Column(name = "EMAIL_SUBJECT")
	private String emailSubject;
	
	@Column(name = "EMAIL_TYPE")
	private String emailType;
	
	@Column(name = "IND_FETCH_BODY")
	private String indFetchBody;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EMAIL_TEMPLATE_ID")
	private EmailTemplate emailTemplate;
	
	public String getIndFetchBody() {
		return indFetchBody;
	}

	public void setIndFetchBody(String indFetchBody) {
		this.indFetchBody = indFetchBody;
	}
	
	public String getEmailType() {
		return emailType;
	}

	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getEmailTo() {
		return emailTo;
	}
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}
	public EmailDetails emailTo(String emailTo) {
		this.emailTo = emailTo;
		return this;
	}
	public String getEmailCC() {
		return emailCC;
	}

	public void setEmailCC(String emailCC) {
		this.emailCC = emailCC;
	}
	public EmailDetails emailCC(String emailCC) {
		this.emailCC = emailCC;
		return this;
	}

	public String getEmailBCC() {
		return emailBCC;
	}

	public void setEmailBCC(String emailBCC) {
		this.emailBCC = emailBCC;
	}
	public EmailDetails emailBCC(String emailBCC) {
		this.emailBCC = emailBCC;
		return this;
	}

	public String getEmailSender() {
		return emailSender;
	}

	public void setEmailSender(String emailSender) {
		this.emailSender = emailSender;
	}
	public EmailDetails emailSender(String emailSender) {
		this.emailSender = emailSender;
		return this;
	}

	public String getEmailVoltage() {
		return emailVoltage;
	}

	public void setEmailVoltage(String emailVoltage) {
		this.emailVoltage = emailVoltage;
	}
	public EmailDetails emailVoltage(String emailVoltage) {
		this.emailVoltage = emailVoltage;
		return this;
	}

	public String getEmailBody() {
		return emailBody;
	}

	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}
	public EmailDetails emailBody(String emailBody) {
		this.emailBody = emailBody;
		return this;
	}
	

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}	
	public EmailDetails emailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
		return this;
	}

	/**
	 * @return the emailTemplate
	 */
	public EmailTemplate getEmailTemplate() {
		return emailTemplate;
	}

	/**
	 * @param emailTemplate the emailTemplate to set
	 */
	public void setEmailTemplate(EmailTemplate emailTemplate) {
		this.emailTemplate = emailTemplate;
	}
	
	/**
	 * @param emailTemplate the emailTemplate to set
	 */
	public EmailDetails emailTemplate(EmailTemplate emailTemplate) {
		this.emailTemplate = emailTemplate;
		return this;
	}	
}
