package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name="VLCP_COLLATERAL_MAIN_DETAILS")
public class CollateralMainDetailsViewData {
	@Id
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name="COLLATERAL_TYPE_CODE")
	private String collateralTypeCode;

	@Column(name="COLLATERAL_TYPE_DESC")
	private String collateralTypeDescription;
	
	@Column(name="COLLATERAL_SUB_TYPE")
	private String collateralSubType;
	
	@Column(name="COLLATERAL_SUB_TYPE_DESC")
	private String collateralSubTypeDescription;
	
	public String getCollateralSubTypeDescription() {
		return collateralSubTypeDescription;
	}

	public void setCollateralSubTypeDescription(String collateralSubTypeDescription) {
		this.collateralSubTypeDescription = collateralSubTypeDescription;
	}

	@Column(name="COLLATERAL_STATUS")
	private String collateralStatus;
	
	@Column(name="COLLATERAL_LEGAL_DESCRIPTION")
	private String collateralLegalDescription;
	
	@Column(name="COLLATERAL_ADDRESS")
	private String collateralAddress;

	@Column(name="COLLATERAL_CITY")
	private String collateralCity;
	
	@Column(name="COLLATERAL_STATE")
	private String collateralState;
	
	@Column(name="COLLATERAL_ZIPCODE")
	private String collateralZipCode;
	
	@Column(name="COLLATERAL_UNIT_BLDG")
	private String collateralUnitBuilding;

	@Column(name="COLLATERAL_EMAIL_ADDRESSES")
	private String collateralEmailAddresses;
	
	public String getCollateralEmailAddresses() {
		return collateralEmailAddresses;
	}

	public void setCollateralEmailAddresses(String collateralEmailAddresses) {
		this.collateralEmailAddresses = collateralEmailAddresses;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getCollateralTypeCode() {
		return collateralTypeCode;
	}

	public void setCollateralTypeCode(String collateralTypeCode) {
		this.collateralTypeCode = collateralTypeCode;
	}

	public String getCollateralTypeDescription() {
		return collateralTypeDescription;
	}

	public void setCollateralTypeDescription(String collateralTypeDescription) {
		this.collateralTypeDescription = collateralTypeDescription;
	}

	public String getCollateralSubType() {
		return collateralSubType;
	}

	public void setCollateralSubType(String collateralSubType) {
		this.collateralSubType = collateralSubType;
	}

	public String getCollateralStatus() {
		return collateralStatus;
	}

	public void setCollateralStatus(String collateralStatus) {
		this.collateralStatus = collateralStatus;
	}

	public String getCollateralLegalDescription() {
		return collateralLegalDescription;
	}

	public void setCollateralLegalDescription(String collateralLegalDescription) {
		this.collateralLegalDescription = collateralLegalDescription;
	}

	public String getCollateralAddress() {
		return collateralAddress;
	}

	public void setCollateralAddress(String collateralAddress) {
		this.collateralAddress = collateralAddress;
	}

	public String getCollateralCity() {
		return collateralCity;
	}

	public void setCollateralCity(String collateralCity) {
		this.collateralCity = collateralCity;
	}

	public String getCollateralState() {
		return collateralState;
	}

	public void setCollateralState(String collateralState) {
		this.collateralState = collateralState;
	}

	public String getCollateralZipCode() {
		return collateralZipCode;
	}

	public void setCollateralZipCode(String collateralZipCode) {
		this.collateralZipCode = collateralZipCode;
	}

	public String getCollateralUnitBuilding() {
		return collateralUnitBuilding;
	}

	public void setCollateralUnitBuilding(String collateralUnitBuilding) {
		this.collateralUnitBuilding = collateralUnitBuilding;
	}
	
}
