package com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.UniqueConstraint;

@Entity @Table(name="USERS", uniqueConstraints= @UniqueConstraint(columnNames = {"username"}))
public class Users extends CtracBaseEntity {

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "UserIdSeqGenerator")
	@TableGenerator(name = "UserIdSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "USERS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id @Column(name="ID")
	private Long id;

	@Column(name="USERNAME")
	private String username;
	
	@Column(name="ENABLED")
	private Boolean enabled;

	@Column(name="FIRST_NAME")
	private String firstName;

	@Column(name="LAST_NAME")
	private String lastName;

	@Column(name="SID")
	private String sid;

	@Column(name = "LAST_LOGIN_DATE")
	private Date lastLoginDate;
	
	@OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, mappedBy = "users")
	private List<GroupMembers> groupMembers = new ArrayList<GroupMembers>();

	public Users() {

	}

	public Users(String userName, String sid, String firstName, String lastName) {
		this.username = userName;
		this.sid = sid;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public void addGroups(Groups groups){
		GroupMembers groupMember = new GroupMembers();
		groupMember.setGroups(groups);
		groupMember.setUsers(this);
		if(!groupMembers.contains(groupMember)){
			groupMembers.add(groupMember);
		}
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<GroupMembers> getGroupMembers() {
		return groupMembers;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public Date getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Users other = (Users) obj;
		if (sid == null) {
			if (other.sid != null)
				return false;
		} else if (!sid.equalsIgnoreCase(other.sid))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equalsIgnoreCase(other.username)) {
			return false;
		}
		return true;
	}
}
