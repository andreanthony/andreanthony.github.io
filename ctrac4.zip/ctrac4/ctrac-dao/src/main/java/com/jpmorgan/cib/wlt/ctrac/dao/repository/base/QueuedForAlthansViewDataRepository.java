package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.QueuedForAlthansViewData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QueuedForAlthansViewDataRepository extends JpaRepository<QueuedForAlthansViewData, Long> {

}
