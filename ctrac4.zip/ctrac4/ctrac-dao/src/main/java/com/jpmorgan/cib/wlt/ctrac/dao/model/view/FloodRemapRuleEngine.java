package com.jpmorgan.cib.wlt.ctrac.dao.model.view;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VLCP_FLOOD_REMAP_RULE_ENGINE")
public class FloodRemapRuleEngine {
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "RULE_SET")
	private String ruleName;

	@Column(name = "REMAP_CATEGORY")
	private String remapCategory;
	
	@Column(name = "REMAP_TYPE")
	private String remapType;
	
	@Column(name = "CLIENT_FOUND_FLAG")
	private String clientFoundFlag;

	@Column(name = "PROPERTY_PLDGD_FLAG")
	private String propertyPledgedFlag;
	
	@Column(name = "EXPOSURE_EXISTS")
	private String exposureExists;
	
	@Column(name = "COMPLETE_FLAG")
	private String completeFlag;
	
	@Column(name = "SLA_DAYS_REMAINING")
	private String slaDaysRemaining;
	
	@Column(name = "CURRENT_WF_STEP")
	private String currentWorkFlowStep;

	@Column(name = "WF_TRANSITION_VALUE")
	private String transitionValue;
	
	@Column(name = "NEXT_WF_STEP")
	private String nextWorkFlowStep;
	
	@Column(name = "NEXT_TASK_STATUS")
	private String nextTaskStatus;
	
	@Column(name = "WF_TRACKING_TYPE")
	private String trackingType;
	
	@Column(name = "OTM_TASK_TYPE")
	private String tmTaskType;
	
	@Column(name="POLICY_TYPE")
	private String policyType;
	
	@Column(name="LOAN_TYPE")
	private String loanType;
	
	@Column(name="COLLATERAL_TYPE")
	private String collateralType;
	
	@Column(name = "PERFECTION_TYPE")
	private String perfectionType;
	
	@Column(name = "PERFECTION_SUB_TYPE")
	private String perfectionSubType;
	
	@Column(name = "REMINDER_TYPE")
	private String reminderType;
	
	@Column(name = "LOAN_ACTIVE_FLAG")
	private String loanActiveFlag;
	
	@Column(name = "COMMENTS")
	private String comments;
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}
	
	public String getNextTaskStatus() {
		return nextTaskStatus;
	}

	public void setNextTaskStatus(String nextTaskStatus) {
		this.nextTaskStatus = nextTaskStatus;
	}
	
	public String getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRemapCategory() {
		return remapCategory;
	}

	public void setRemapCategory(String remapCategory) {
		this.remapCategory = remapCategory;
	}

	public String getRemapType() {
		return remapType;
	}

	public void setRemapType(String remapType) {
		this.remapType = remapType;
	}

	public String getClientFoundFlag() {
		return clientFoundFlag;
	}

	public void setClientFoundFlag(String clientFoundFlag) {
		this.clientFoundFlag = clientFoundFlag;
	}

	public String getPropertyPledgedFlag() {
		return propertyPledgedFlag;
	}

	public void setPropertyPledgedFlag(String propertyPledgedFlag) {
		this.propertyPledgedFlag = propertyPledgedFlag;
	}

	public String getExposureExists() {
		return exposureExists;
	}

	public void setExposureExists(String exposureExists) {
		this.exposureExists = exposureExists;
	}

	public String getCompleteFlag() {
		return completeFlag;
	}

	public void setCompleteFlag(String completeFlag) {
		this.completeFlag = completeFlag;
	}

	public String getSlaDaysRemaining() {
		return slaDaysRemaining;
	}

	public void setSlaDaysRemaining(String slaDaysRemaining) {
		this.slaDaysRemaining = slaDaysRemaining;
	}

	public String getCurrentWorkFlowStep() {
		return currentWorkFlowStep;
	}

	public void setCurrentWorkFlowStep(String currentWorkFlowStep) {
		this.currentWorkFlowStep = currentWorkFlowStep;
	}

	public String getTransitionValue() {
		return transitionValue;
	}

	public void setTransitionValue(String transitionValue) {
		this.transitionValue = transitionValue;
	}

	public String getNextWorkFlowStep() {
		return nextWorkFlowStep;
	}

	public void setNextWorkFlowStep(String nextWorkFlowStep) {
		this.nextWorkFlowStep = nextWorkFlowStep;
	}

	public String getTrackingType() {
		return trackingType;
	}

	public void setTrackingType(String trackingType) {
		this.trackingType = trackingType;
	}
	
	public String getPerfectionType() {
		return perfectionType;
	}

	public void setPerfectionType(String perfectionType) {
		this.perfectionType = perfectionType;
	}

	public String getPerfectionSubType() {
		return perfectionSubType;
	}

	public void setPerfectionSubType(String perfectionSubType) {
		this.perfectionSubType = perfectionSubType;
	}
	
	public String getReminderType() {
		return reminderType;
	}

	public void setReminderType(String reminderType) {
		this.reminderType = reminderType;
	}

	public String getLoanActiveFlag() {
		return loanActiveFlag;
	}

	public void setLoanActiveFlag(String loanActiveFlag) {
		this.loanActiveFlag = loanActiveFlag;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
