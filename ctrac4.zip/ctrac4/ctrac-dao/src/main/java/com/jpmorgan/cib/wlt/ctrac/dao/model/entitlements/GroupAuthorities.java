package com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity @Table(name="GROUP_AUTHORITIES")
public class GroupAuthorities {

	@EmbeddedId
	private GroupAuthoritiesPK id;
	
	@MapsId("GROUP_ID") @OneToOne(fetch = FetchType.LAZY)
	private Groups groups;
	
	@Column(name="AUTHORITY")
	private String authority;

	public Groups getGroups() {
		return groups;
	}

	public void setGroups(Groups groups) {
		this.groups = groups;
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

}
