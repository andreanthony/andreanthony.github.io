package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.CoverageGapReportViewData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoverageGapReportViewRepository extends JpaRepository<CoverageGapReportViewData, Long> {

}
