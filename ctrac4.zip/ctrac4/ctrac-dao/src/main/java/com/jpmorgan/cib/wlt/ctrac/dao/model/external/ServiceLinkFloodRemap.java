/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.dao.model.external;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;


/**
 * @author Q003321
 *
 */
/**
 * This is a JPA entity class to hold  Service Link new Flood Remap Activity. Remap Data fetched from TLCP_SL_FLOOD_REMAP staging table.
 * @date 2-FEB-2015
 */

@Entity
@Table(name = "TLCP_SL_FLOOD_REMAP")

public class ServiceLinkFloodRemap extends CtracBaseEntity {
	
	public static final String SERVICE_LINK_SOURCE_SYSTEM = "ServiceLink";
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "remapActivitySeqGenerator")
	@TableGenerator(name = "remapActivitySeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_SL_FLOOD_REMAP", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")	
	private Long rid;	

	@Column(name ="REQUESTNUM")   
	private String requestNum;
	
	@Column(name ="LOANNUMBER")
	private String loanNumber;
	
	@Column(name ="REVISEDFLOODZONE")
	private String revisedFloodZone;
	
	@Column(name ="BORROWERFIRSTNAME")
	private String borrowerFirstName;
	
	@Column(name ="BORROWERLASTNAME")
	private String borrowerLastName;
	
	@Transient
	private String borrowerName;	
	
	@Transient
	private String sourceSystem = SERVICE_LINK_SOURCE_SYSTEM;	
	
	@Column(name ="ADDRESS")
	private String address;
	
	@Column(name ="CITY")
	private String city;
	
	@Column(name ="STATE")
	private String state;
	
	@Column(name ="ZIPCODE")
	private String zipCode;
	
	@Column(name ="ORIGINALFLOODZONE")
	private String originalFloodZone;
	
	@Column(name ="PARTICIPATINGCOMMUNITY")
	private String participatingCommunity;
	
	@Column(name ="DEPTCODE")
	private String deptCode;
	
	@Column(name ="SERVICER")
	private String servicer;
	
	@Column(name ="STATUSCHANGE")
	private String statusChange;
	
	@Column(name ="REVISEDCOMMUNITYNAME")
	private String revisedCommunityName;
	
	@Column(name ="REVISEDCOMMUNITYNUMBER")
	private String revisedCommunityNumber;
	
	@Column(name ="REVISEDMAPDATE")
	private Date revisedMapDate;
	
	@Column(name ="LOMARDATE")
	private Date lomaRDate;
	
	@Column(name ="DETERMINATIONDATE")
	private Date determinationDate;
	
	@Column(name ="FILEDATE")
	private Date fileDate;
	
	@Column(name ="COMMENTS")	
	private String comments;
	
	@Column(name ="COUNTY")
	private String county;
	
	@Column(name ="CLIENTCONTACT")
	private String clientContact;
	
	@Column(name ="ORDERDATE")
	private Date orderDate;
	
	@Column(name ="UNMAPPED")
	private String unmapped;
	
	@Column(name ="PROGRAMSTATUS")
	private String programStatus;
	
	@Column(name ="ORDERTYPE")
	private String orderType;
	
	@Column(name ="STATEFIPS")
	private String stateFips;
	
	@Column(name ="COUNTYFIPS")
	private String countyFips;
	
	@Column(name ="HMDAMSAMD")
	private String hmdaMsaMd;
	
	@Column(name ="HMDACT")
	private String hmdaCt;
	
	@Column(name ="INSURANCECHANGE")
	private String insuranceChange;
	
	@Column(name =" CBRADATE")
	private Date cbraDate;
	
	@Column(name ="UPDATEDESCRIPTION")
	private String updateDescription;
	
	@Column(name ="ORDERSTATUS")	
	private String orderStatus;
	
	@Column(name ="CUSTOMERNUMBER")
	private String customerNumber;
	
	@Column(name ="CLIENTNAME")
	private String clientName;
	
	@Column(name ="TRACKINGNUMBER")
	private String trackingNumber;
	
	@Column(name ="REVISEDMAPNUMBER")
	private String revisedMapNumber;
	
	@Column(name ="REVISEDPANEL")
	private String revisedPanel;
	
	@Column(name ="REVISEDSUFFIX")	
	private String revisedSuffix;
	
	@Column(name="LOMCCASENUMBER")
	private String lomcCaseNumber;
	
	@Column(name ="PROCESSING_STATUS")	
	private String dataProcessingStatus = "N";
	
	@Column(name ="REMAP_CREATION_DATE")	
	private Date remapCreationDate;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name = "SFHDF_RID", referencedColumnName="RID", nullable=true)
	private CollateralDocument floodRemapSFHDF;
	
	@Transient
	private String tmTaskType = TMTaskType.FLOOD_REMAP.name();

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getRequestNum() {
		return requestNum;
	}

	public void setRequestNum(String requestNum) {
		this.requestNum = requestNum;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getRevisedFloodZone() {
		return revisedFloodZone;
	}

	public void setRevisedFloodZone(String revisedFloodZone) {
		this.revisedFloodZone = revisedFloodZone;
	}

	public String getBorrowerFirstName() {
		return borrowerFirstName;
	}

	public void setBorrowerFirstName(String borrowerFirstName) {
		this.borrowerFirstName = borrowerFirstName;
	}

	public String getBorrowerLastName() {
		return borrowerLastName;
	}

	public void setBorrowerLastName(String borrowerLastName) {
		this.borrowerLastName = borrowerLastName;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getOriginalFloodZone() {
		return originalFloodZone;
	}

	public void setOriginalFloodZone(String originalFloodZone) {
		this.originalFloodZone = originalFloodZone;
	}

	public String getParticipatingCommunity() {
		return participatingCommunity;
	}

	public void setParticipatingCommunity(String participatingCommunity) {
		this.participatingCommunity = participatingCommunity;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getServicer() {
		return servicer;
	}

	public void setServicer(String servicer) {
		this.servicer = servicer;
	}

	public String getStatusChange() {
		return statusChange;
	}

	public void setStatusChange(String statusChange) {
		this.statusChange = statusChange;
	}

	public String getRevisedCommunityName() {
		return revisedCommunityName;
	}

	public void setRevisedCommunityName(String revisedCommunityName) {
		this.revisedCommunityName = revisedCommunityName;
	}

	public String getRevisedCommunityNumber() {
		return revisedCommunityNumber;
	}

	public void setRevisedCommunityNumber(String revisedCommunityNumber) {
		this.revisedCommunityNumber = revisedCommunityNumber;
	}

	public Date getRevisedMapDate() {
		return revisedMapDate;
	}

	public void setRevisedMapDate(Date revisedMapDate) {
		this.revisedMapDate = revisedMapDate;
	}

	public Date getLomaRDate() {
		return lomaRDate;
	}

	public void setLomaRDate(Date lomaRDate) {
		this.lomaRDate = lomaRDate;
	}

	public Date getDeterminationDate() {
		return determinationDate;
	}

	public void setDeterminationDate(Date determinationDate) {
		this.determinationDate = determinationDate;
	}

	public Date getFileDate() {
		return fileDate;
	}

	public void setFileDate(Date fileDate) {
		this.fileDate = fileDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getClientContact() {
		return clientContact;
	}

	public void setClientContact(String clientContact) {
		this.clientContact = clientContact;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getUnmapped() {
		return unmapped;
	}

	public void setUnmapped(String unmapped) {
		this.unmapped = unmapped;
	}

	public String getProgramStatus() {
		return programStatus;
	}

	public void setProgramStatus(String programStatus) {
		this.programStatus = programStatus;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getStateFips() {
		return stateFips;
	}

	public void setStateFips(String stateFips) {
		this.stateFips = stateFips;
	}

	public String getCountyFips() {
		return countyFips;
	}

	public void setCountyFips(String countyFips) {
		this.countyFips = countyFips;
	}

	public String getHmdaMsaMd() {
		return hmdaMsaMd;
	}

	public void setHmdaMsaMd(String hmdaMsaMd) {
		this.hmdaMsaMd = hmdaMsaMd;
	}

	public String getHmdaCt() {
		return hmdaCt;
	}

	public void setHmdaCt(String hmdaCt) {
		this.hmdaCt = hmdaCt;
	}

	public String getInsuranceChange() {
		return insuranceChange;
	}

	public void setInsuranceChange(String insuranceChange) {
		this.insuranceChange = insuranceChange;
	}

	public Date getCbraDate() {
		return cbraDate;
	}

	public void setCbraDate(Date cbraDate) {
		this.cbraDate = cbraDate;
	}

	public String getUpdateDescription() {
		return updateDescription;
	}

	public void setUpdateDescription(String updateDescription) {
		this.updateDescription = updateDescription;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

	public String getRevisedMapNumber() {
		return revisedMapNumber;
	}

	public void setRevisedMapNumber(String revisedMapNumber) {
		this.revisedMapNumber = revisedMapNumber;
	}

	public String getRevisedPanel() {
		return revisedPanel;
	}

	public void setRevisedPanel(String revisedPanel) {
		this.revisedPanel = revisedPanel;
	}

	public String getRevisedSuffix() {
		return revisedSuffix;
	}

	public void setRevisedSuffix(String revisedSuffix) {
		this.revisedSuffix = revisedSuffix;
	}

	public String getLomcCaseNumber() {
		return lomcCaseNumber;
	}

	public void setLomcCaseNumber(String lomcCaseNumber) {
		this.lomcCaseNumber = lomcCaseNumber;
	}

	public String getDataProcessingStatus() {
		return dataProcessingStatus;
	}

	public void setDataProcessingStatus(String dataProcessingStatus) {
		this.dataProcessingStatus = dataProcessingStatus;
	}

	public Date getRemapCreationDate() {
		return remapCreationDate;
	}

	public void setRemapCreationDate(Date remapCreationDate) {
		this.remapCreationDate = remapCreationDate;
	}

	public CollateralDocument getFloodRemapSFHDF() {
		return floodRemapSFHDF;
	}

	public void setFloodRemapSFHDF(CollateralDocument floodRemapSFHDF) {
		this.floodRemapSFHDF = floodRemapSFHDF;
	}
	public String getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}

}
