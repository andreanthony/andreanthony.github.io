package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;


public class CollateralWorkItemPk implements Serializable {

    private static final long serialVersionUID = -609075605348561700L;
    

    private Collateral collateral;

    private WorkItem workItem;
    
    public CollateralWorkItemPk() {
        super();
    }

    public Collateral getCollateral() {
        return collateral;
    }

    public void setCollateral(Collateral collateral) {
        this.collateral = collateral;
    }

    public WorkItem getWorkItem() {
        return workItem;
    }

    public void setWorkItem(WorkItem workItem) {
        this.workItem = workItem;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((collateral == null) ? 0 : collateral.hashCode());
        result = prime * result + ((workItem == null) ? 0 : workItem.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CollateralWorkItemPk other = (CollateralWorkItemPk) obj;
        if (collateral == null) {
            if (other.collateral != null)
                return false;
        } else if (!collateral.equals(other.collateral))
            return false;
        if (workItem == null) {
            if (other.workItem != null)
                return false;
        } else if (!workItem.equals(other.workItem))
            return false;
        return true;
    }

}
