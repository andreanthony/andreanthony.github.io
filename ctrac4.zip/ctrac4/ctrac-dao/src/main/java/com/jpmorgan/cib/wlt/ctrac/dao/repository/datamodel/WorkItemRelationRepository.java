
package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItemRelation;

public interface WorkItemRelationRepository extends JpaRepository<WorkItemRelation, Long> {
	
	@Query("select workItemRelation from WorkItemRelation workItemRelation, PerfectionTask perfectionTask where workItemRelation.parentWorkItem.rid=?1 and workItemRelation.childWorkItem.rid = perfectionTask.workItem.rid and (perfectionTask.taskStatus='SLEEPING' or perfectionTask.taskStatus='OPEN') ORDER BY workItemRelation.childWorkItem.rid")
	public List<WorkItemRelation> findSleepingAndOpenRelationsByParentRid(Long parentRid);
	
	@Query("select workItemRelation from WorkItemRelation workItemRelation, PerfectionTask perfectionTask where workItemRelation.parentWorkItem.rid=?1 and workItemRelation.relationType=?2 and workItemRelation.childWorkItem.rid = perfectionTask.workItem.rid and (perfectionTask.taskStatus='SLEEPING' or perfectionTask.taskStatus='OPEN') ORDER BY workItemRelation.childWorkItem.rid")
	public List<WorkItemRelation> findSleepingAndOpenRelationsByParentRidAndRelationType(Long parentRid, String relationType);
	
	public WorkItemRelation findByChildWorkItemAndRelationType(WorkItem childWorkItem, String relationType);
	
	public List<WorkItemRelation> findByParentWorkItemAndRelationType(WorkItem parentWorkItem, String relationType);

}
