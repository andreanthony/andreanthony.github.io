package com.jpmorgan.cib.wlt.ctrac.dao.model.audit;

import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditEntrySearchCriteria;
import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search.AuditRetrieveResult;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;

public interface AuditService {

    AuditRetrieveResult retrieve(AuditEntrySearchCriteria auditEntrySearchCriteria);

    void create(AuditEventDTO auditEventDTO);

}
