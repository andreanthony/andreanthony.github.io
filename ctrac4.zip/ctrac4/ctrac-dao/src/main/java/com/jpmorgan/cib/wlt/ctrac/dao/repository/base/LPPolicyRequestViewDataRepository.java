package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.Collection;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LPPolicyRequestViewData;

public interface LPPolicyRequestViewDataRepository extends JpaRepository<LPPolicyRequestViewData,Long> {
	
	Set<LPPolicyRequestViewData> findByProofOfCoverageIn(Collection<ProofOfCoverage> proofOfCoverages);
	
	Set<LPPolicyRequestViewData> findByProofOfCoverageRidIn(Collection<Long> proofOfCoverageRids);
	
}
