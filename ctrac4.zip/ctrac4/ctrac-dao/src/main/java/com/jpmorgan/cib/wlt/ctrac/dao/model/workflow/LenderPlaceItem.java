package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_LENDER_PLACE_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class LenderPlaceItem extends WorkItem {

	@Column(name = "LP_PHASE")
	private String lpPhase;
	
	@Column(name = "LP_SEND_DATE")
	private Date lpSendDate;
	
	@Column(name = "FIRST_LETTER_DATE")
	private Date firstLetterDate;
	
	@Column(name = "SECOND_LETTER_DATE")
	private Date secondLetterDate;
	
	@Column(name = "PREMIUM_AMOUNT")
	private BigDecimal premiumAmount;
	
	@Column(name = "BANK_PREMIUM_AMOUNT")
	private BigDecimal bankPremiumAmount;
	
	@Column(name = "BILLING_DATE")
	private Date billingDate;
	
	@Column(name = "FED_REF_NUMBER")
	private String fedReferenceNumber;
	
	@Column(name = "POLICY_INFO_VERIFIED")
	private String policyInfoVerified;

	@Column(name = "SPECIAL_PROCESSING")
	private String specialProcessing;
	
	@Column(name = "VENDOR_DOCS_IMAGED")
	private String vendorDocsImaged;
	
	@Column(name = "POLICY_IN_IMAGE_SYSTEM")
	private String policyInImageSystem;
	
	@Column(name = "WIRE_SENT_DATE")
	private Date wireSentDate;
	
	@Column(name = "CANCELLATION_REQUEST_DATE")
	private Date cancellationRequestDate;
	
	@Column(name = "CANCELLATION_LETTER_DATE")
	private Date cancellationLetterDate;

	@Column(name = "REFUND_AMOUNT")
	private BigDecimal refundAmount;
	
	@Column(name = "BANK_REFUND_AMOUNT")
	private BigDecimal bankRefundAmount;
	
	@Column(name = "CLW_REF_NUMBER")
	private String clwRefNumber;
	
	@Column(name = "REFUND_COMPLETION_DATE")
	private Date refundCompletionDate;

	@Column(name = "CONFIRM_IMG_LETTER")
	private String confirmImgLetter;
	
	@Column(name = "CANCEL_CERTIFICATE_VERIFIED")
	private String cancelCertificateVerified="N";
	
	@Column(name = "PREMIUM_CERTIFICATE_VERIFIED")
	private String premiumCertificateVerified="N";
	
	public LenderPlaceItem() {}
	
	public LenderPlaceItem(String workItemID, Date initiationDate, String perfectionType, String perfectionSubType, String lpPhase, String specialProcessing){
		super(workItemID, initiationDate, perfectionType, perfectionSubType);
		this.lpPhase = lpPhase;
		this.specialProcessing = specialProcessing;
	}

	public String getLpPhase() {
		return lpPhase;
	}

	public void setLpPhase(String lpPhase) {
		this.lpPhase = lpPhase;
	}

	public Date getLpSendDate() {
		return lpSendDate;
	}

	public void setLpSendDate(Date lpSendDate) {
		this.lpSendDate = lpSendDate;
	}

	public Date getFirstLetterDate() {
		return firstLetterDate;
	}

	public void setFirstLetterDate(Date firstLetterDate) {
		this.firstLetterDate = firstLetterDate;
	}

	public Date getSecondLetterDate() {
		return secondLetterDate;
	}

	public void setSecondLetterDate(Date secondLetterDate) {
		this.secondLetterDate = secondLetterDate;
	}

	public BigDecimal getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public BigDecimal getBankPremiumAmount() {
		return bankPremiumAmount;
	}

	public void setBankPremiumAmount(BigDecimal bankPremiumAmount) {
		this.bankPremiumAmount = bankPremiumAmount;
	}

	public Date getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(Date billingDate) {
		this.billingDate = billingDate;
	}

	public String getFedReferenceNumber() {
		return fedReferenceNumber;
	}

	public void setFedReferenceNumber(String fedReferenceNumber) {
		this.fedReferenceNumber = fedReferenceNumber;
	}

	public String getPolicyInfoVerified() {
		return policyInfoVerified;
	}

	public void setPolicyInfoVerified(String policyInfoVerified) {
		this.policyInfoVerified = policyInfoVerified;
	}

	public String getSpecialProcessing() {
		return specialProcessing;
	}

	public void setSpecialProcessing(String specialProcessing) {
		this.specialProcessing = specialProcessing;
	}

	public String getVendorDocsImaged() {
		return vendorDocsImaged;
	}

	public void setVendorDocsImaged(String vendorDocsImaged) {
		this.vendorDocsImaged = vendorDocsImaged;
	}

	public String getPolicyInImageSystem() {
		return policyInImageSystem;
	}

	public void setPolicyInImageSystem(String policyInImageSystem) {
		this.policyInImageSystem = policyInImageSystem;
	}

	public Date getWireSentDate() {
		return wireSentDate;
	}

	public void setWireSentDate(Date wireSentDate) {
		this.wireSentDate = wireSentDate;
	}

	public Date getCancellationRequestDate() {
		return cancellationRequestDate;
	}

	public void setCancellationRequestDate(Date cancellationRequestDate) {
		this.cancellationRequestDate = cancellationRequestDate;
	}

	public Date getCancellationLetterDate() {
		return cancellationLetterDate;
	}

	public void setCancellationLetterDate(Date cancellationLetterDate) {
		this.cancellationLetterDate = cancellationLetterDate;
	}

	public BigDecimal getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(BigDecimal refundAmount) {
		this.refundAmount = refundAmount;
	}

	public BigDecimal getBankRefundAmount() {
		return bankRefundAmount;
	}

	public void setBankRefundAmount(BigDecimal bankRefundAmount) {
		this.bankRefundAmount = bankRefundAmount;
	}

	public String getClwRefNumber() {
		return clwRefNumber;
	}

	public void setClwRefNumber(String clwRefNumber) {
		this.clwRefNumber = clwRefNumber;
	}

	public Date getRefundCompletionDate() {
		return refundCompletionDate;
	}

	public void setRefundCompletionDate(Date refundCompletionDate) {
		this.refundCompletionDate = refundCompletionDate;
	}

	public String getConfirmImgLetter() {
		return confirmImgLetter;
	}

	public void setConfirmImgLetter(String confirmImgLetter) {
		this.confirmImgLetter = confirmImgLetter;
	}

	public String getCancelCertificateVerified() {
		return cancelCertificateVerified;
	}

	public void setCancelCertificateVerified(String cancelCertificateVerified) {
		this.cancelCertificateVerified = cancelCertificateVerified;
	}

	public String getPremiumCertificateVerified() {
		return premiumCertificateVerified;
	}

	public void setPremiumCertificateVerified(String premiumCertificateVerified) {
		this.premiumCertificateVerified = premiumCertificateVerified;
	}

}
