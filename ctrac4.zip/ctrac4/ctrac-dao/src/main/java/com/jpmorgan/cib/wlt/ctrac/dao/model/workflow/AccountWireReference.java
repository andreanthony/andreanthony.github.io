package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;


@Entity
@Table(name = "TLCP_ACCT_WIRE_REF")
public class AccountWireReference extends CtracBaseEntity{
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "wireReferenceGenerator")
	@TableGenerator(name = "wireReferenceGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_ACCT_WIRE_REF", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name = "WORK_ITEM_RID", referencedColumnName="RID", nullable=true)
	private WorkItem workItem;

	@Column(name = "ACCOUNTING_SYS_REF")
	private String accountingSysRef;
	
	@Column(name = "REQ_NUM")
	private String requestNumber;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public String getRequestNumber() {
		return requestNumber;
	}

	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}

	public String getAccountingSysRef() {
		return accountingSysRef;
	}

	public void setAccountingSysRef(String accountingSysRef) {
		this.accountingSysRef = accountingSysRef;
	}
}
