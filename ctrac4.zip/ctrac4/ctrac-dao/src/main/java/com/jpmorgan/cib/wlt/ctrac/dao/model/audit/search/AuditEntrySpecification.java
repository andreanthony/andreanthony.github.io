package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search;

import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.AuditEntry;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.Date;

public class AuditEntrySpecification implements Specification<AuditEntry> {

    private final SearchCriteria criteria;

    public AuditEntrySpecification(SearchCriteria criteria) {
        this.criteria = criteria;
    }

    @Override
    public Predicate toPredicate(Root<AuditEntry> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder builder) {
        switch(criteria.getOperation()) {
            case EQUAL:
                return builder.equal(root.<String> get(criteria.getKey()), criteria.getValue());
            case NULL:
                return builder.isNull(root.<String> get(criteria.getKey()));
            case LESS_THAN:
                return builder.lessThanOrEqualTo(root.<Date> get(criteria.getKey()), (Date) criteria.getValue());
            case GREATER_THAN:
                return builder.greaterThanOrEqualTo(root.<Date> get(criteria.getKey()), (Date) criteria.getValue());
            case LIKE:
                return builder.like(builder.lower(root.<String> get(criteria.getKey())), criteria.getValue().toString());
            default:
                break;
        }
        return null;
    }

    SearchCriteria getSearchCriteria() {
        return criteria;
    }
}
