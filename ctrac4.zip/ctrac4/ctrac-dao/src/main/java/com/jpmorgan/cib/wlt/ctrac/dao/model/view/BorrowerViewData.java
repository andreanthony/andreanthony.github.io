package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_BORROWER_DETAILS")
public class BorrowerViewData {
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "LOAN_RID")
	private Long loanRid;	
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "BORROWER_RID")
	private Long borrowerRid;
	
	@Column(name="BORROWER_NAME")
	private String borrowerName;
	
	@Column(name="BORROWER_ADDR")
	private String borrowerAddress;
	
	@Column(name="BORROWER_CITY")
	private String borrowerCity;
	
	@Column(name="BORROWER_STATE")
	private String borrowerState;

	@Column(name="BORROWER_ZIPCODE")
	private String borrowerZipCode;
	
	@Column(name="BORROWER_UNIT_BLDG")
	private String borrowerUnitBuilding;
	
	@Column(name="BORROWER_CREATED_BY")
	private String borrowerCreatedBy;
	
	@Column(name="BORROWER_LAST_UPDATED_BY")
	private String borrowerLastUpdatedBy;
	
	@Column(name="BORROWER_CREATED_DATE")
	private Date borrowerCreatedDate;
	
	@Column(name="BORROWER_LAST_UPDATED_DATE")
	private Date borrowerLastUpdatedDate;
	
	@Column(name = "ALL_OWNER_AND_BORROWER_NAMES")
	private String allOwnerAndBorrowerNames;

	public Long getLoanRid() {
		return loanRid;
	}

	public void setLoanRid(Long loanRid) {
		this.loanRid = loanRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getBorrowerRid() {
		return borrowerRid;
	}

	public void setBorrowerRid(Long borrowerRid) {
		this.borrowerRid = borrowerRid;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getBorrowerAddress() {
		return borrowerAddress;
	}

	public void setBorrowerAddress(String borrowerAddress) {
		this.borrowerAddress = borrowerAddress;
	}

	public String getBorrowerCity() {
		return borrowerCity;
	}

	public void setBorrowerCity(String borrowerCity) {
		this.borrowerCity = borrowerCity;
	}

	public String getBorrowerState() {
		return borrowerState;
	}

	public void setBorrowerState(String borrowerState) {
		this.borrowerState = borrowerState;
	}

	public String getBorrowerZipCode() {
		return borrowerZipCode;
	}

	public void setBorrowerZipCode(String borrowerZipCode) {
		this.borrowerZipCode = borrowerZipCode;
	}

	public String getBorrowerUnitBuilding() {
		return borrowerUnitBuilding;
	}

	public void setBorrowerUnitBuilding(String borrowerUnitBuilding) {
		this.borrowerUnitBuilding = borrowerUnitBuilding;
	}

	public String getBorrowerCreatedBy() {
		return borrowerCreatedBy;
	}

	public void setBorrowerCreatedBy(String borrowerCreatedBy) {
		this.borrowerCreatedBy = borrowerCreatedBy;
	}

	public String getBorrowerLastUpdatedBy() {
		return borrowerLastUpdatedBy;
	}

	public void setBorrowerLastUpdatedBy(String borrowerLastUpdatedBy) {
		this.borrowerLastUpdatedBy = borrowerLastUpdatedBy;
	}

	public Date getBorrowerCreatedDate() {
		return borrowerCreatedDate;
	}

	public void setBorrowerCreatedDate(Date borrowerCreatedDate) {
		this.borrowerCreatedDate = borrowerCreatedDate;
	}

	public Date getBorrowerLastUpdatedDate() {
		return borrowerLastUpdatedDate;
	}

	public void setBorrowerLastUpdatedDate(Date borrowerLastUpdatedDate) {
		this.borrowerLastUpdatedDate = borrowerLastUpdatedDate;
	}

	/**
	 * @return the allOwnerAndBorrowerNames
	 */
	public String getAllOwnerAndBorrowerNames() {
		return allOwnerAndBorrowerNames;
	}

	/**
	 * @param allOwnerAndBorrowerNames the allOwnerAndBorrowerNames to set
	 */
	public void setAllOwnerAndBorrowerNames(String allOwnerAndBorrowerNames) {
		this.allOwnerAndBorrowerNames = allOwnerAndBorrowerNames;
	}
}
