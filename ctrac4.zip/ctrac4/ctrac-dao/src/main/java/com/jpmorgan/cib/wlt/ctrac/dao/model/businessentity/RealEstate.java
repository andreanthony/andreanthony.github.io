package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CollateralType;


@Entity
@Table(name = "TLCP_REAL_ESTATE")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class RealEstate extends Collateral {

	private static final long serialVersionUID = -5986118460892145233L;

	public RealEstate() {
		super();
		this.setCollateralType(CollateralType.REAL_ESTATE.getCode());
	}
	
}
