package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_COLLATERAL_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class CollateralItem extends WorkItem {

	@Column(name = "IND_HOLD_WORKFLOW")
	private String indHoldWorflow;
	
	@Column(name = "LP_DUE_DATE")
	private Date lpDueDate;
	

    public String getIndHoldWorflow() {
		return indHoldWorflow;
	}

	public void setIndHoldWorflow(String indHoldWorflow) {
		this.indHoldWorflow = indHoldWorflow;
	}

    /**
     * @return the lpDueDate
     */
    public Date getLpDueDate() {
        return lpDueDate;
    }

    /**
     * @param lpDueDate the lpDueDate to set
     */
    public void setLpDueDate(Date lpDueDate) {
        this.lpDueDate = lpDueDate;
    }
    
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((indHoldWorflow == null) ? 0 : indHoldWorflow.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollateralItem other = (CollateralItem) obj;
		if (indHoldWorflow == null) {
			if (other.indHoldWorflow != null)
				return false;
		} else if (!indHoldWorflow.equals(other.indHoldWorflow))
			return false;
		return true;
	}

}
