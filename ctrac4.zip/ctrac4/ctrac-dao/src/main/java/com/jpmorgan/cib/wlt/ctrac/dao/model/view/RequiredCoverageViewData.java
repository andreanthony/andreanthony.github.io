package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import com.jpmorgan.cib.wlt.ctrac.dao.model.SortableByDocumentDate;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_REQ_COVERAGE_DETAILS")
public class RequiredCoverageViewData implements SortableByDocumentDate {
	@Id
	@Column(name="RID")
	private Long rid;
	
	@Column(name = "REQUIRED_COVERAGE_RID")
	private Long requiredCoverageRid; //original Required coverage that caused this LPI
	
	@Column(name="COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name="INSURABLE_ASSET_RID")
	private Long insurableAssetRid;
	
	@Column(name="STATUS")
	private String status;
	
	@Column(name="DOCUMENT_DATE")
	private Date documentDate;
	
	@Column(name="INSURANCE_TYPE")
	private String insuranceType;
	
	@Column(name="SOURCE_DOCUMENT")
	private String sourceDocument;
	
	@Column(name = "REQD_COV_SAME_AS_OPB")
    private String reqdCovSameAsOPB;
    
    @Column(name = "EXCESS_REQUIRED")
    private String excessRequired;
    
    @Column(name = "OPB")
    private BigDecimal outstandingPrincipleBalance;
	
	@Column(name="PROPERTY_TYPE")
	private String propertyType;
	
	@Column(name="INPUT_DATE")
	private Date inputDate;
	
	@Column(name="ASSET_TYPE")
	private String assetType;
	
	@Column(name="ASSET_FLOOD_ZONE")
	private String assetFloodZone;
	
	@Column(name="ASSET_SORT_ORDER")
	private Long assetSortOrder; 
	
	@Column(name="COVERAGE_CREATED_BY")
	private String coverageCreatedBy;
	
	@Column(name="COVERAGE_CREATED_DATE")
	private Date coverageCreatedDate;
	
	@Column(name="COVERAGE_LAST_UPDATED_BY")
	private String coverageLastUpdatedBy;
	
	@Column(name="COVERAGE_LAST_UPDATED_DATE")
	private Date coverageLastUpdatedDate;
	
	@Column(name="BUILDING_NAME")
	private String buildingName;
	
	@Column(name="PRIMARY_COVERAGE_AMOUNT")
	private BigDecimal primaryCoverageAmount;
	
	@Column(name="PRIMARY_COVERAGE_VALUE")
	private BigDecimal primaryCoverageValue;

	
	@Column(name="IS_PRIMARY_COVERAGE_VERIFIED")
	private Integer isPrimaryCoverageVerified;
	
	@Column(name="EXCESS_COVERAGE_VALUE")
	private BigDecimal excessCoverageValue;
	
	@Column(name="EXCESS_COVERAGE_AMOUNT")
	private BigDecimal excessCoverageAmount;
	
	@Column(name="IS_EXCESS_COVERAGE_VERIFIED")
	private Integer isExcessCoverageVerified;
	
	@Column(name="E_BLDNG_CONTENT_BALANCE_TYPE")
	private String excessBuildingContentBalanceType;
	
	@Column(name="P_BLDNG_CONTENT_BALANCE_TYPE")
	private String primaryBuildingContentBalanceType;


	@Column(name="PRIMARY_BALANCE_TYPE")
	private String primaryBalanceType;
	
	@Column(name="EXCESS_BALANCE_TYPE")
	private String excessBalanceType;
	
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getRequiredCoverageRid() {
		return requiredCoverageRid;
	}

	public void setRequiredCoverageRid(Long requiredCoverageRid) {
		this.requiredCoverageRid = requiredCoverageRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getInsurableAssetRid() {
		return insurableAssetRid;
	}

	public void setInsurableAssetRid(Long insurableAssetRid) {
		this.insurableAssetRid = insurableAssetRid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public String getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}

	public String getSourceDocument() {
		return sourceDocument;
	}

	public void setSourceDocument(String sourceDocument) {
		this.sourceDocument = sourceDocument;
	}

	public String getReqdCovSameAsOPB() {
		return reqdCovSameAsOPB;
	}

	public void setReqdCovSameAsOPB(String reqdCovSameAsOPB) {
		this.reqdCovSameAsOPB = reqdCovSameAsOPB;
	}

	public String getExcessRequired() {
		return excessRequired;
	}

	public void setExcessRequired(String excessRequired) {
		this.excessRequired = excessRequired;
	}

	public BigDecimal getOutstandingPrincipleBalance() {
		return outstandingPrincipleBalance;
	}

	public void setOutstandingPrincipleBalance(BigDecimal outstandingPrincipleBalance) {
		this.outstandingPrincipleBalance = outstandingPrincipleBalance;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public Date getInputDate() {
		return inputDate;
	}

	public void setInputDate(Date inputDate) {
		this.inputDate = inputDate;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getAssetFloodZone() {
		return assetFloodZone;
	}

	public void setAssetFloodZone(String assetFloodZone) {
		this.assetFloodZone = assetFloodZone;
	}

	public Long getAssetSortOrder() {
		return assetSortOrder;
	}

	public void setAssetSortOrder(Long assetSortOrder) {
		this.assetSortOrder = assetSortOrder;
	}

	public String getCoverageCreatedBy() {
		return coverageCreatedBy;
	}

	public void setCoverageCreatedBy(String coverageCreatedBy) {
		this.coverageCreatedBy = coverageCreatedBy;
	}

	public Date getCoverageCreatedDate() {
		return coverageCreatedDate;
	}

	public void setCoverageCreatedDate(Date coverageCreatedDate) {
		this.coverageCreatedDate = coverageCreatedDate;
	}

	public String getCoverageLastUpdatedBy() {
		return coverageLastUpdatedBy;
	}

	public void setCoverageLastUpdatedBy(String coverageLastUpdatedBy) {
		this.coverageLastUpdatedBy = coverageLastUpdatedBy;
	}

	public Date getCoverageLastUpdatedDate() {
		return coverageLastUpdatedDate;
	}

	public void setCoverageLastUpdatedDate(Date coverageLastUpdatedDate) {
		this.coverageLastUpdatedDate = coverageLastUpdatedDate;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public BigDecimal getPrimaryCoverageAmount() {
		return primaryCoverageAmount;
	}

	public void setPrimaryCoverageAmount(BigDecimal primaryCoverageAmount) {
		this.primaryCoverageAmount = primaryCoverageAmount;
	}

	public Integer getIsPrimaryCoverageVerified() {
		return isPrimaryCoverageVerified;
	}

	public void setIsPrimaryCoverageVerified(Integer isPrimaryCoverageVerified) {
		this.isPrimaryCoverageVerified = isPrimaryCoverageVerified;
	}

	public BigDecimal getExcessCoverageAmount() {
		return excessCoverageAmount;
	}

	public void setExcessCoverageAmount(BigDecimal excessCoverageAmount) {
		this.excessCoverageAmount = excessCoverageAmount;
	}

	public Integer getIsExcessCoverageVerified() {
		return isExcessCoverageVerified;
	}

	public void setIsExcessCoverageVerified(Integer isExcessCoverageVerified) {
		this.isExcessCoverageVerified = isExcessCoverageVerified;
	}

	public BigDecimal getPrimaryCoverageValue() {
		return primaryCoverageValue;
	}

	public void setPrimaryCoverageValue(BigDecimal primaryCoverageValue) {
		this.primaryCoverageValue = primaryCoverageValue;
	}

	public BigDecimal getExcessCoverageValue() {
		return excessCoverageValue;
	}

	public void setExcessCoverageValue(BigDecimal excessCoverageValue) {
		this.excessCoverageValue = excessCoverageValue;
	}

	public String getExcessBuildingContentBalanceType() {
		return this.excessBuildingContentBalanceType;
	}

	public void setExcessBuildingContentBalanceType(String excessBuildingContentBalanceType) {
		this.excessBuildingContentBalanceType = excessBuildingContentBalanceType;
	}

	public String getPrimaryBuildingContentBalanceType() {
		return this.primaryBuildingContentBalanceType;
	}

	public void setPrimaryBuildingContentBalanceType(String primaryBuildingContentBalanceType) {
		this.primaryBuildingContentBalanceType = primaryBuildingContentBalanceType;
	}

	public String getPrimaryBalanceType() {
		return primaryBalanceType;
	}

	public void setPrimaryBalanceType(String primaryBalanceType) {
		this.primaryBalanceType = primaryBalanceType;
	}

	public String getExcessBalanceType() {
		return excessBalanceType;
	}

	public void setExcessBalanceType(String excessBalanceType) {
		this.excessBalanceType = excessBalanceType;
	}

		
}
