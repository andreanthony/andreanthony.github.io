package com.jpmorgan.cib.wlt.ctrac.dao.model.bir;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "TLCP_BIR_FIELD_CONCLUSION")
public class BIRRuleConclusion {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "birFieldConclusionSeqGenerator")
	@TableGenerator(name = "birFieldConclusionSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BIR_FIELD_CONCLUSION", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "PROOF_OF_COVERAGE_RID")
	private Long proofOfCoverageRid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "INSURABLE_ASSET_RID")
	private Long insurableAssetSortOrder;
	
	@Column(name = "FIELD_NAME")
	private String fieldName;
	
	@Column(name = "CONCLUSION")
	private String conclusion;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getInsurableAssetSortOrder() {
		return insurableAssetSortOrder;
	}

	public void setInsurableAssetSortOrder(Long insurableAssetSortOrder) {
		this.insurableAssetSortOrder = insurableAssetSortOrder;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getConclusion() {
		return conclusion;
	}

	public void setConclusion(String conclusion) {
		this.conclusion = conclusion;
	}
	
}
