package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.LookUpCode;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;

@Entity
@Table(name = "TLCP_FLOOD_REMAP_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class FloodRemapItem extends WorkItem {

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FLOOD_DETERMINATION_ID", referencedColumnName="RID")
	private CollateralDocument floodDetermination;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "IN_TO_OUT_NOTICE_ID", referencedColumnName="RID")
	private CollateralDocument inToOutNotice;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "RENEWAL_ID", referencedColumnName="RID")
	private Renewal renewal;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FLOOD_REMAP_LANDING_RID")
	private FloodRemap floodRemap;
		
	@Column(name = "COMPLETE_REASON")
	private String completeReason;
	
	@Column(name = "COMPLETE_REASON_COMMENT")
	private String completeReasonComment;

	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "PRE_LP_DETAILS_ID")
	private PreLenderPlaceDetails preLenderPlaceDetails;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FLOOD_ZONE_STATUS", referencedColumnName="RID", nullable=true)
	private LookUpCode statusChange;
	
	@Column(name = "REMAP_CATEGORY")
	private String remapCategory;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "COLLATERAL_RID", referencedColumnName="RID", nullable=true)
	@Deprecated //we should be using collateralWorkItem and getPrefered collatral
	private Collateral collateral;
		
	@Column(name = "COLLATERAL_REVIEWED_FLAG")
	private Character collateralReviewedFlag;
	
	@Column(name = "RESEARCH_VERIFIED_FLAG")
	private Character researchVerifiedFlag;
	
	@Column(name = "COVERAGE_REQUEST_TASK_RID")
	private Long coverageRequestTaskRid;
	
	@Column(name = "CANCELLATION_EFF_DATE")
	private Date cancellationEffDate;
	
	public Date getCancellationEffDate() {
		return cancellationEffDate;
	}

	public void setCancellationEffDate(Date cancellationEffDate) {
		this.cancellationEffDate = cancellationEffDate;
	}

	public String getRemapCategory() {
		return remapCategory;
	}

	public void setRemapCategory(String remapCategory) {
		this.remapCategory = remapCategory;
	}
	
	public CollateralDocument getFloodDetermination() {
		return floodDetermination;
	}
	
	public void setFloodDetermination(CollateralDocument floodDetermination) {
		this.floodDetermination = floodDetermination;
	}
	
	public Renewal getRenewal() {
		return renewal;
	}

	public void setRenewal(Renewal renewal) {
		this.renewal = renewal;
	}
	
	public FloodRemap getFloodRemap() {
		return floodRemap;
	}
	
	public void setFloodRemap(FloodRemap floodRemap) {
		this.floodRemap = floodRemap;
	}
	

	public PreLenderPlaceDetails getPreLenderPlaceDetails() {
		return preLenderPlaceDetails;
	}

	public void setPreLenderPlaceDetails(PreLenderPlaceDetails preLenderPlaceDetails) {
		this.preLenderPlaceDetails = preLenderPlaceDetails;
	}
	
	
	public LookUpCode getStatusChange() {
		return statusChange;
	}

	public void setStatusChange(LookUpCode statusChange) {
		this.statusChange = statusChange;
	}

	public CollateralDocument getInToOutNotice() {
		return inToOutNotice;
	}

	public void setInToOutNotice(CollateralDocument inToOutNotice) {
		this.inToOutNotice = inToOutNotice;
	}
    @Deprecated //we should be using collateralWorkItem and getPrefered collatral
	public Collateral getCollateral() {
		return collateral;
	}
    @Deprecated //we should be using collateralWorkItem and getPrefered collatral
	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}

	public Character getCollateralReviewedFlag() {
		return collateralReviewedFlag;
	}

	public void setCollateralReviewedFlag(Character collateralReviewedFlag) {
		this.collateralReviewedFlag = collateralReviewedFlag;
	}

	public Character getResearchVerifiedFlag() {
		return researchVerifiedFlag;
	}

	public void setResearchVerifiedFlag(Character researchVerifiedFlag) {
		this.researchVerifiedFlag = researchVerifiedFlag;
	}
	
	public String getCompleteReason() {
		return completeReason;
	}

	public void setCompleteReason(String completeReason) {
		this.completeReason = completeReason;
	}

	public String getCompleteReasonComment() {
		return completeReasonComment;
	}

	public void setCompleteReasonComment(String completeReasonComment) {
		this.completeReasonComment = completeReasonComment;
	}
	
	public Long getCoverageRequestTaskRid() {
		return coverageRequestTaskRid;
	}

	public void setCoverageRequestTaskRid(Long coverageRequestTaskRid) {
		this.coverageRequestTaskRid = coverageRequestTaskRid;
	}


}
