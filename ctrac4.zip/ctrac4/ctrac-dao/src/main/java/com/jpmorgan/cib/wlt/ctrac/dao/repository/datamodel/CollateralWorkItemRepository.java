package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralWorkItemPk;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;

public interface CollateralWorkItemRepository extends JpaRepository<CollateralWorkItem, CollateralWorkItemPk> {	
	
	List<CollateralWorkItem> findByCollateral(Collateral collateral);	
	
	List<CollateralWorkItem> findByWorkItem(WorkItem workItem);	
	
	List<CollateralWorkItem> findByCollateralRid(Long rid);
	
	List<CollateralWorkItem> findByCollateralRidAndWorkItemPerfectionType(
			Long rid, String perfectionType);
	
}
