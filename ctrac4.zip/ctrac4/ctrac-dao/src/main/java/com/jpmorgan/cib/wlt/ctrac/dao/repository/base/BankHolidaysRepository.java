package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.BankHolidays;



public interface BankHolidaysRepository extends JpaRepository<BankHolidays, Long>{
	
	public  List<BankHolidays> findByHolidayDateAndHolidayActiveFlagAndHolidayCalendar(Date holidayDate, Character holidayActiveFlag, String holidayCalendar);
	
	public  List<BankHolidays> findByHolidayActiveFlagAndHolidayCalendar(Character holidayActiveFlag, String holidayCalendar);
							
}
