package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_LOAN_COLLATERAL")
@IdClass(value=LoanCollateralPk.class)
public class LoanCollateral implements Serializable {

	private static final long serialVersionUID = 2149009795722171539L;

	@Id
	@ManyToOne
	@JoinColumn(name = "LOAN_ID")
	private Loan loan;
	
	@Id
	@ManyToOne
	@JoinColumn(name = "COLLATERAL_ID")
	private Collateral collateral;
	
	@Column(name = "PRIMARY_FLAG")
	private String primaryFlag;

	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	public Collateral getCollateral() {
		return collateral;
	}

	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((collateral == null) ? 0 : collateral.hashCode());
		result = prime * result + ((loan == null) ? 0 : loan.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoanCollateral other = (LoanCollateral) obj;
		if (collateral == null) {
			if (other.collateral != null)
				return false;
		} else if (!collateral.equals(other.collateral))
			return false;
		if (loan == null) {
			if (other.loan != null)
				return false;
		} else if (!loan.equals(other.loan))
			return false;
		return true;
	}

	public String getPrimaryFlag() {
		return primaryFlag;
	}

	public void setPrimaryFlag(String primaryFlag) {
		this.primaryFlag = primaryFlag;
	}

}
