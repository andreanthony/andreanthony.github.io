package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

@Entity
@Table(name = "TLCP_PROOF_COV_WORK_ITEM")
@IdClass(value=ProofOfCovWorkItemPk.class)
public class ProofOfCovWorkItem implements Serializable {

	private static final long serialVersionUID = -3107325511375038748L;

	@Id
	@ManyToOne
    @JoinColumn(name = "PROOF_OF_COVERAGE_RID" , nullable = false)
    private ProofOfCoverage proofOfCoverage;
    
	@Id
    @ManyToOne
    @JoinColumn(name = "WORK_ITEM_RID", nullable = false)
    private WorkItem workItem;	
	
	@Column(name = "ITEM_TYPE")
	private String itemType;
	/**
	 * @return the proofOfCoverage
	 */
	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}

	/**
	 * @return the workItem
	 */
	public WorkItem getWorkItem() {
		return workItem;
	}

	/**
	 * @param proofOfCoverage the proofOfCoverage to set
	 */
	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	/**
	 * @param workItem the workItem to set
	 */
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((proofOfCoverage == null) ? 0 : proofOfCoverage.hashCode());
		result = prime * result
				+ ((workItem == null) ? 0 : workItem.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProofOfCovWorkItem other = (ProofOfCovWorkItem) obj;
		if (proofOfCoverage == null) {
			if (other.proofOfCoverage != null)
				return false;
		} else if (!proofOfCoverage.equals(other.proofOfCoverage))
			return false;
		if (workItem == null) {
			if (other.workItem != null)
				return false;
		} else if (!workItem.equals(other.workItem))
			return false;
		return true;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
    
}
