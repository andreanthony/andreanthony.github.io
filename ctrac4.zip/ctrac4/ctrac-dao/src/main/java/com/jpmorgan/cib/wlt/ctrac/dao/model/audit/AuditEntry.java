package com.jpmorgan.cib.wlt.ctrac.dao.model.audit;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "TAUD_AUDIT_ENTRY")
public class AuditEntry {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "auditEntrySeqGenerator")
    @TableGenerator(name = "auditEntrySeqGenerator", table = "TAUD_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TAUD_AUDIT_ENTRY", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 100)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "EVENT_UUID")
    @NotNull
    private UUID eventUuid;

    @Column(name = "EVENT_TYPE")
    @NotNull
    private String eventType;

    @Column(name = "EVENT_TIME")
    @NotNull
    private Date eventTime;

    @Column(name = "PERFORMED_BY")
    @NotNull
    private String performedBy;

    @Column(name = "COLLATERAL_ID")
    private Long collateralId;

    @Column(name = "COLLATERAL_ID", insertable = false, updatable = false)
    private String collateralIdStr;

    @Column(name = "IDENTIFIER")
    private String identifier;

    @Column(name = "LINE_OF_BUSINESS")
    private String lineOfBusiness;

    @Column(name = "COLLATERAL_SECTION")
    private String collateralSection;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "TASK_NAME")
    private String taskName;

    @Column(name = "USERFULLNAME")
    private String userFullName;

    @Column(name = "LAST_PUBLISH_TIME")
    @NotNull
    private Date lastPublishTime = new Date();

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public UUID getEventUuid() { return eventUuid; }

    public void setEventUuid(UUID eventUuid) { this.eventUuid = eventUuid; }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public Date getEventTime() {
        if (eventTime == null) {
            return null;
        }
        return (Date) eventTime.clone();
    }

    public void setEventTime(Date eventTime) {
        if (eventTime == null) {
            this.eventTime = null;
        } else {
            this.eventTime = (Date) eventTime.clone();
        }
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }

    public Long getCollateralId() {
        return collateralId;
    }

    public void setCollateralId(Long collateralId) {
        this.collateralId = collateralId;
    }

    public String getCollateralIdStr() {
        return collateralIdStr;
    }

    public void setCollateralIdStr(String collateralIdStr) {
        this.collateralIdStr = collateralIdStr;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public String getCollateralSection() {
        return collateralSection;
    }

    public void setCollateralSection(String collateralSection) {
        this.collateralSection = collateralSection;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }
    public String getUserFullName() {
        return userFullName;
    }

    public void setUserFullName(String userFullName) {
        this.userFullName = userFullName;
    }

    public Date getLastPublishTime() {
        if (lastPublishTime == null) {
            lastPublishTime = new Date();
        }
        return (Date) lastPublishTime.clone();
    }

    public void setLastPublishTime(Date lastPublishTime) {
        if (lastPublishTime == null) {
            lastPublishTime = new Date();
        }
        this.lastPublishTime = (Date) lastPublishTime.clone();
    }
}
