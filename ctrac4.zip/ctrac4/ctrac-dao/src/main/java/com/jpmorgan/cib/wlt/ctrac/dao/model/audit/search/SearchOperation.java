package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search;

public enum SearchOperation {
    EQUAL, NULL, LESS_THAN, GREATER_THAN, LIKE
}
