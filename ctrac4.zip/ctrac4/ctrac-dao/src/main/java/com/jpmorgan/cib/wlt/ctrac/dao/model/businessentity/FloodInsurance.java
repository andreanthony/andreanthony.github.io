package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_FLOOD_INSURANCE")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class FloodInsurance extends ProofOfCoverage {
	
	@Column(name = "FLOOD_COVERAGE_TYPE")
	private String floodCoverageType;
	
	@Column(name = "FLOOD_COVERAGE_INCLUDED")
	private String floodCoverageIncluded;

	@Column(name = "PRIVATE_POL_COVERS_FLOOD")
	private String coversAllRiskOfFlood;

	@Column(name = "FLOOD_ZONES_LISTED")
	private String floodZonesListed;
	
	@Column(name = "PIA_ASSESSMENT_EXCEPTIONS")
	private String piaAssessmentExceptions;

	public String getFloodCoverageType() {
		return floodCoverageType;
	}

	public void setFloodCoverageType(String floodCoverageType) {
		this.floodCoverageType = floodCoverageType;
	}

	public String getFloodCoverageIncluded() {
		return floodCoverageIncluded;
	}

	public void setFloodCoverageIncluded(String floodCoverageIncluded) {
		this.floodCoverageIncluded = floodCoverageIncluded;
	}

	public String getCoversAllRiskOfFlood() {
		return coversAllRiskOfFlood;
	}

	public void setCoversAllRiskOfFlood(String coversAllRiskOfFlood) {
		this.coversAllRiskOfFlood = coversAllRiskOfFlood;
	}

	public String getFloodZonesListed() {
		return floodZonesListed;
	}

	public void setFloodZonesListed(String floodZonesListed) {
		this.floodZonesListed = floodZonesListed;
	}

	public String getPiaAssessmentExceptions() {
		return piaAssessmentExceptions;
	}

	public void setPiaAssessmentExceptions(String piaAssessmentExceptions) {
		this.piaAssessmentExceptions = piaAssessmentExceptions;
	}

}
