package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="VLCP_HOLD_HISTORY")
public class HoldHistoryViewData {

    @Id
    @Column(name = "HOLD_RID")
    private Long holdRid;

    @Column(name = "COLLATERAL_RID")
    private Long collateralRid;

    @Column(name = "BUILDING_NAME")
    private String buildingName;

    @Column(name = "INSURABLE_ASSET_TYPE")
    private String insurableAssetType;

    @Column(name = "COVERAGE_TYPE")
    private String coverageType;

    @Column(name = "PARENT_HOLD_RID")
    private Long parentHoldRid;

    @Column(name = "HOLD_TYPE")
    private String holdType;

    @Column(name = "START_DATE")
    private Date startDate;

    @Column(name="HOLD_PERIOD")
    private String holdPeriod;

    @Column(name = "LPI_DATE")
    private Date lpiDate;

    @Column(name = "HOLD_STATUS")
    private String holdStatus;

    @Column(name = "VERIFIED_BY")
    private String verifiedBy;

    @Column(name = "VERIFIED_DATE")
    private Date verifiedDate;

    public Long getHoldRid() {
        return holdRid;
    }

    public void setHoldRid(Long holdRid) {
        this.holdRid = holdRid;
    }

    public Long getParentHoldRid() {
        return parentHoldRid;
    }

    public void setParentHoldRid(Long parentHoldRid) {
        this.parentHoldRid = parentHoldRid;
    }

    public String getHoldType() {
        return holdType;
    }

    public void setHoldType(String holdType) {
        this.holdType = holdType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getHoldPeriod() {
        return holdPeriod;
    }

    public void setHoldPeriod(String holdPeriod) {
        this.holdPeriod = holdPeriod;
    }

    public Date getLpiDate() {
        return lpiDate;
    }

    public void setLpiDate(Date lpiDate) {
        this.lpiDate = lpiDate;
    }

    public String getHoldStatus() {
        return holdStatus;
    }

    public void setHoldStatus(String holdStatus) {
        this.holdStatus = holdStatus;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Date getVerifiedDate() {
        return verifiedDate;
    }

    public void setVerifiedDate(Date verifiedDate) {
        this.verifiedDate = verifiedDate;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getInsurableAssetType() {
        return insurableAssetType;
    }

    public void setInsurableAssetType(String insurableAssetType) {
        this.insurableAssetType = insurableAssetType;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }
}
