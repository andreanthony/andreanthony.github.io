package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;

public interface FloodRemapRepository extends JpaRepository<FloodRemap, Long>{

	@Query("select activities from FloodRemap activities where activities.processingStatus='N' and activities.statusChange != 'NC' and activities.statusChange is not null")
	public List<FloodRemap> getNewFloodRemaps();	
							
}
