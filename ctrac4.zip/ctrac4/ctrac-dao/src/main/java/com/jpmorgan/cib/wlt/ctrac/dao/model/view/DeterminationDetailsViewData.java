package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VLCP_DETERMINATION_DETAILS")
public class DeterminationDetailsViewData {

	@Id
	@Column(name = "DETERMINATION_RID")
	private Long rid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "VENDOR")
	private String vendor;
	
	@Column(name = "ORDER_NUMBER")
	private String orderNumber;
	
	@Column(name = "LOAN_IDENTIFIER")
	private String loanIdentifier;
	
	@Column(name = "DATE_OF_DETERMINATION")
	private Date dateOfDetermination;
	
	@Column(name = "DATE_OF_MAP_CHANGE")
	private Date dateOfMapChange;
	
	@Column(name = "FLOOD_ZONE")
	private String floodZone;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "VERIFICATION_DATE")
	private Date verificationDate;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getLoanIdentifier() {
		return loanIdentifier;
	}

	public void setLoanIdentifier(String loanIdentifier) {
		this.loanIdentifier = loanIdentifier;
	}

	public Date getDateOfDetermination() {
		return dateOfDetermination;
	}

	public void setDateOfDetermination(Date dateOfDetermination) {
		this.dateOfDetermination = dateOfDetermination;
	}

	public Date getDateOfMapChange() {
		return dateOfMapChange;
	}

	public void setDateOfMapChange(Date dateOfMapChange) {
		this.dateOfMapChange = dateOfMapChange;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getVerificationDate() {
		return verificationDate;
	}

	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}

}
