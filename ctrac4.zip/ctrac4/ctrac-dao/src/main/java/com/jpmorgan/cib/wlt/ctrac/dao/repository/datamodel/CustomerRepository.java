package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long>, JpaSpecificationExecutor<Customer> {
	
	
	@Query("select customer from Customer customer where soundex(name) = soundex(?1) "
			+ " or upper(name) like ?2 ORDER BY name")
	public List<Customer> findAllByNameSoudexOrLike(String name, String nameLike);
	
	public Customer findByUniqueCustomerNumber(String uniqueCustomerNumber);
}
