package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailTemplateRule;


/**
 * 
 *
 */
public interface EmailTemplateRuleRepository extends JpaRepository<EmailTemplateRule, Long>, JpaSpecificationExecutor<EmailTemplateRule> {
	
	@Deprecated
	/**
	 *  Use criteria/specification to determine the template see example in @EmailTemplateRetrievalService
	 * @param lob
	 * @return
	 */
	EmailTemplateRule findByLob(String lob);
	
	EmailTemplateRule findByLobAndAdditionalInfo(String lob, String additionalInfo);

}
