package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.WorkflowMainDetailsViewData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkflowMainDetailsViewRepository extends JpaRepository<WorkflowMainDetailsViewData, String> {
	List<WorkflowMainDetailsViewData> findByWorkItemRid(Long workItemRid);
	List<WorkflowMainDetailsViewData> findByTaskRid(Long taskRid);
	List<WorkflowMainDetailsViewData> findByCollateralRid(Long collateralRid);
	List<WorkflowMainDetailsViewData> findByCollateralRidAndProofOfCoverageRid(Long collateralRid, Long proofOfCoverageRid );
	List<WorkflowMainDetailsViewData> findByProofOfCoverageRidAndWorkFlowStep(Long proofOfCoverageRid, String workFlowStep);

	List<WorkflowMainDetailsViewData> findByTaskId(String taskId);
	List<WorkflowMainDetailsViewData> findByTaskIdAndTaskType(String taskId,String taskType);
	List<WorkflowMainDetailsViewData> findByTaskIdAndWorkFlowStep(String taskId,String workFlowStep);
}