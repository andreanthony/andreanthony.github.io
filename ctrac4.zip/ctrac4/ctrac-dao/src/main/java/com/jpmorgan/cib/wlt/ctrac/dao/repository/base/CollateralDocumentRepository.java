package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;

public interface CollateralDocumentRepository extends JpaRepository<CollateralDocument, Long> {

	public CollateralDocument findByRid(Long rid);

	public List<CollateralDocument> findByFileName(String fileName);

	public List<CollateralDocument> findByFileNameAndDocIdentifier(String fileName, String docIdentifier);

	public CollateralDocument findByRidAndDocIdentifier(Long rid, String docIdentifier);

	public List<CollateralDocument> findByCollateralRid(Long collateralRid);
	
	public List<CollateralDocument> findByCollateralRidAndDocIdentifier(Long collateralRid, String docIdentifier);
	
	public List<CollateralDocument> findByProofOfCoverageRidAndDocIdentifier(Long proofOfCoverageRid, String docType);
	
	
	
}
