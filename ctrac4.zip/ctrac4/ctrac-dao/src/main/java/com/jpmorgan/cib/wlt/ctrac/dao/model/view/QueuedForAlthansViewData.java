package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.PerfectionTask;

@Entity
@Table(name = "VLCP_QUEUED_FOR_ALTHANS")
public class QueuedForAlthansViewData implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "RID")
	private Long rid;
	
	@OneToOne
	@JoinColumn(name = "PERFECTION_TASK_RID", referencedColumnName = "RID")
	private PerfectionTask perfectionTask;

	@OneToOne
	@JoinColumn(name = "PROOF_OF_COVERAGE_RID", referencedColumnName = "RID")
	private ProofOfCoverage proofOfCoverage;
	
	@OneToOne
	@JoinColumn(name = "LENDER_PLACE_ITEM_RID", referencedColumnName = "RID") 
	private LenderPlaceItem lenderPlaceItem;
	
	@Column(name = "WORKFLOW_STEP")
	private String workflowStep;
	
	@Column(name = "LP_TARGET_DATE")
	private Date lpTargetDate;
	
	@Column(name = "LP_SEND_DATE")
	private Date lpSendDate;
	
	@Column(name = "EFFECTIVE_DATE")
	private Date effectiveDate;
	
	@Column(name = "EXPIRATION_DATE")
	private Date expirationDate;
	
	@Column(name = "CANCELLATION_TARGET_DATE")
	private Date cancellationTargetDate;
	
	@Column(name = "CANCELLATION_REQUEST_DATE")
	private Date cancellationRequestDate;
	
	@Column(name = "CANCELLATION_EFFECTIVE_DATE")
	private Date cancellationEffectiveDate;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public PerfectionTask getPerfectionTask() {
		return perfectionTask;
	}

	public void setPerfectionTask(PerfectionTask perfectionTask) {
		this.perfectionTask = perfectionTask;
	}

	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}

	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	public LenderPlaceItem getLenderPlaceItem() {
		return lenderPlaceItem;
	}

	public void setLenderPlaceItem(LenderPlaceItem lenderPlaceItem) {
		this.lenderPlaceItem = lenderPlaceItem;
	}

	public String getWorkflowStep() {
		return workflowStep;
	}

	public void setWorkflowStep(String workflowStep) {
		this.workflowStep = workflowStep;
	}

	public Date getLpTargetDate() {
		return lpTargetDate;
	}

	public void setLpTargetDate(Date lpTargetDate) {
		this.lpTargetDate = lpTargetDate;
	}

	public Date getLpSendDate() {
		return lpSendDate;
	}

	public void setLpSendDate(Date lpSendDate) {
		this.lpSendDate = lpSendDate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Date getCancellationTargetDate() {
		return cancellationTargetDate;
	}

	public void setCancellationTargetDate(Date cancellationTargetDate) {
		this.cancellationTargetDate = cancellationTargetDate;
	}

	public Date getCancellationRequestDate() {
		return cancellationRequestDate;
	}

	public void setCancellationRequestDate(Date cancellationRequestDate) {
		this.cancellationRequestDate = cancellationRequestDate;
	}

	public Date getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}

	public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}

}
