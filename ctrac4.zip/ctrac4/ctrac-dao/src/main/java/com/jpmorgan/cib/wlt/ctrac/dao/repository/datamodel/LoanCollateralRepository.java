package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LoanCollateral;

public interface LoanCollateralRepository extends
		JpaRepository<LoanCollateral, Long> {	
	public LoanCollateral findByLoanRidAndCollateralRid(Long loanRid, Long collateralRid);


}
