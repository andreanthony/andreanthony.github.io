package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_HOLD_WORK_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class HoldWorkItem extends WorkItem {

	@Column(name = "HOLD_RID")
	private Long holdRid;

	@Column(name = "DOCUMENT_RID")
	private Long documentRid;
 
	public Long getHoldRid() {
		return holdRid;
	}

	public void setHoldRid(Long holdRid) {
		this.holdRid = holdRid;
	}

	public Long getDocumentRid() {
		return documentRid;
	}

	public void setDocumentRid(Long documentRid) {
		this.documentRid = documentRid;
	}
}
