package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracReconcilable;

@Entity
@Table(name="VLCP_TASK_SOURCE_DETAILS")
public class TaskSoruceDetailsData implements CtracReconcilable{
	@Id
	@Column(name = "TASK_RID")
	private Long rid;
	
	@Column(name="CTRAC_TASK_SOURCE")
	private String taskSource;	

	@Column(name="OTM_TASK_ID")
	private String tmTaskId;
	
	@Column(name="OTM_TASK_TYPE")
	private String tmTaskType;
	
	@Column(name="WORKFLOW_STEP")
	private String workFlowStep;
	

	@Column(name = "TASK_STATUS")
	private String taskStatus;


	@Override
	public String getGenericId() {
		return tmTaskId;
	}

	public Long getRid() {
		return rid;
	}


	public void setRid(Long rid) {
		this.rid = rid;
	}


	public String getTaskSource() {
		return taskSource;
	}


	public void setTaskSource(String taskSource) {
		this.taskSource = taskSource;
	}


	public String getTmTaskId() {
		return tmTaskId;
	}


	public void setTmTaskId(String tmTaskId) {
		this.tmTaskId = tmTaskId;
	}


	public String getTmTaskType() {
		return tmTaskType;
	}


	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}


	public String getWorkFlowStep() {
		return workFlowStep;
	}


	public void setWorkFlowStep(String workFlowStep) {
		this.workFlowStep = workFlowStep;
	}


	public String getTaskStatus() {
		return taskStatus;
	}


	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	@Override
	public void fillTransientVariables() {
		// TODO Auto-generated method stub
		
	}	
	

}
