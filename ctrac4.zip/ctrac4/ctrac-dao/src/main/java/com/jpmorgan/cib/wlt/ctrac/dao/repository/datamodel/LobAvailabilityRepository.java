package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.LobAvailability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LobAvailabilityRepository extends JpaRepository<LobAvailability, Long> {

    @Modifying
    @Query("UPDATE LobAvailability avail SET avail.active = :active " +
            "WHERE avail.category IN :categories AND avail.lineOfBusiness.rid in :lobRids")
    int updateActiveByCategoryInAndLobIn(@Param("categories") List<String> categories,
                                         @Param("lobRids") List<Long> lobRids, @Param("active") boolean active);

    @Query("SELECT avail.servicerCode FROM LobAvailability avail WHERE avail.category = :category AND avail.active = :active")
    List<String> findServicerCodesByCategoryAndActive(@Param("category") String category, @Param("active") boolean active);

    List<LobAvailability> findByCategoryAndServicerCode(String category, String servicerCode);

}
