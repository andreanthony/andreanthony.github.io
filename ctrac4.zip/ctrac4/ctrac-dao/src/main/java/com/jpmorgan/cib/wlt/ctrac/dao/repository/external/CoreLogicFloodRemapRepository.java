/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.dao.repository.external;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.external.CoreLogicFloodRemap;

/**
 * @author F544636
 *
 */
public interface CoreLogicFloodRemapRepository extends JpaRepository<CoreLogicFloodRemap, Long>{	
	public List<CoreLogicFloodRemap> findByDataProcessingStatus(String dataProcessingStatus);
	
	@Query("select MAX(insertedDate) from CoreLogicFloodRemap")
    public Date findMaxInsertedDate();
}
