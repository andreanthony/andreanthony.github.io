package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.FloodDetermination;

public interface FloodDeterminationRepository extends JpaRepository<FloodDetermination, Long> {
	
	FloodDetermination findByCollateralRid(Long collateral);
	FloodDetermination findByCollateralRidAndStatus(Long collateral, String status);
	
	//Get the latest flood determination in a given status (verified/pending?)
	FloodDetermination findTop1ByCollateralRidAndStatusOrderByDateOfDeterminationDesc(Long collateralRid, String status);
	
}
