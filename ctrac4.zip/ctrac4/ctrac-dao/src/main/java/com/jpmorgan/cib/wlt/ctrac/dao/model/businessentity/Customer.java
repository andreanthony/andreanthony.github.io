package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

@Entity
@Table(name = "TLCP_CUSTOMER")
public class Customer extends CtracBaseEntity implements Serializable {

	private static final long serialVersionUID = -8682117757986297296L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "customerSeqGenerator")
	@TableGenerator(name = "customerSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_CUSTOMER", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "NAME")
	private String name;

	@Column(name = "UNIQUE_CUSTOMER_NUMBER")
	private String uniqueCustomerNumber;



	@OneToOne(cascade = {CascadeType.ALL}, orphanRemoval=true)
	@JoinColumn(name = "CONTACT_DETAILS_ID")
	private ContactDetails contactDetails;

	@OneToMany(mappedBy = "borrower")
	private List<LoanBorrower> loanBorrowers = new ArrayList<LoanBorrower>();

	@OneToMany(mappedBy = "owner")
	private List<CollateralOwner> collateralOwners = new ArrayList<CollateralOwner>();

	public List<CollateralOwner> getCollateralOwners() {
		return collateralOwners;
	}

	public void setCollateralOwners(List<CollateralOwner> collateralOwners) {
		this.collateralOwners = collateralOwners;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getUniqueCustomerNumber() {
		return uniqueCustomerNumber;
	}

	public void setUniqueCustomerNumber(String uniqueCustomerNumber) {
		this.uniqueCustomerNumber = uniqueCustomerNumber;
	}

	public ContactDetails getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(ContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}

	public List<LoanBorrower> getLoanBorrowers() {
		return loanBorrowers;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append("***** Customer: <RID: " + rid + "> <uniqueCustomerNumber: " + uniqueCustomerNumber + ">");
		if(this.getContactDetails()!=null) {
			result.append("<contactDetails (RID): " + contactDetails.getRid() + ">");
		}
		int borrowerCount=0;
		for (LoanBorrower loanBorrower: loanBorrowers) {
			result.append("<loanBorrower (RID) [" + (borrowerCount+1) + "]: " +  loanBorrower.getBorrower().getRid() + ">");
		}
		return result.toString();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}
