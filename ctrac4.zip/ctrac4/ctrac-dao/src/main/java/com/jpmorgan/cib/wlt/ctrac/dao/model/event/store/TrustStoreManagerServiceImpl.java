package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.EncryptionUtil;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.secure.TrustStoreLoadException;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.secure.TrustStoreManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.annotation.PostConstruct;

@Component
public class TrustStoreManagerServiceImpl implements TrustStoreManagerService{

    private static final Logger LOGGER = LoggerFactory.getLogger(TrustStoreManagerServiceImpl.class);
    private TrustStoreManager trustStoreManager;

    @Value("${jms.keystore.path}")
    private String keyStorePath;

    @Value("${jms.keystore.password}")
    private String keyStorePassword;

    @PostConstruct
    void init() {
        loadTrustStoreManager();
    }

    private void loadTrustStoreManager(){
        try {
            this.trustStoreManager = TrustStoreManager.aKeyStoreManager(keyStorePath,
                    EncryptionUtil.decrypt(keyStorePassword)).generateSSLContext();
        } catch (TrustStoreLoadException e) {
            LOGGER.error("Cannot load the trustStore ", e);
        }
    }

    public TrustStoreManager getTrustStoreManager(){
        return this.trustStoreManager;
    }
}
