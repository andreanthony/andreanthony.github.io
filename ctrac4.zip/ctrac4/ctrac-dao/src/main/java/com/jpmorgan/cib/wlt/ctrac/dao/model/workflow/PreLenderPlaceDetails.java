package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.EmailDetails;

@Entity
@Table(name = "TLCP_PRE_LP_DETAILS")
public class PreLenderPlaceDetails extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "preLenderPlaceDetailsSeqGenerator")
	@TableGenerator(name = "preLenderPlaceDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_PRE_LP_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "CLIENT_FOUND_FLAG")
	private Character clientFoundFlag;
	
	@Column(name = "PROPERTY_PLEDGED_FLAG")
	private Character propertyPledgedFlag;
	
	@Column(name = "EXPOSURE_EXISTS_FLAG")
	private Character exposureExistsFlag;
	
	@Column(name = "LOB_EMAIL_SENT_FLAG")
	private Character lobEmailSentFlag;
	
	@Column(name = "FIAT_ID")
	private Long fiatID;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "LP_EMAIL_DETAILS", referencedColumnName="RID")
	private EmailDetails lpEmailDetails;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "MARKET_EMAIL_DETAILS", referencedColumnName="RID")
	private EmailDetails marketEmailDetails;
	
	
	public Long getRid() {
		return rid;
	}
	public void setRid(Long rid) {
		this.rid = rid;
	}
	public Character getClientFoundFlag() {
		return clientFoundFlag;
	}
	
	public boolean isClientFound(){
	    return  ('Y' == this.clientFoundFlag);
	}
	public void setClientFoundFlag(Character clientFoundFlag) {
		this.clientFoundFlag = clientFoundFlag;
	}
	public Character getPropertyPledgedFlag() {
		return propertyPledgedFlag;
	}
	public void setPropertyPledgedFlag(Character propertyPledgedFlag) {
		this.propertyPledgedFlag = propertyPledgedFlag;
	}
	public boolean isPropertyPledge(){
	    return  (this.propertyPledgedFlag != null && 'Y' == this.propertyPledgedFlag);
	}
	public Character getExposureExistsFlag() {
		return exposureExistsFlag;
	}
	public void setExposureExistsFlag(Character exposureExistsFlag) {
		this.exposureExistsFlag = exposureExistsFlag;
	}
	public boolean  doesExposureExists() {
        return  (this.exposureExistsFlag != null && 'Y' == this.exposureExistsFlag);
    }
	
	public Character getLobEmailSentFlag() {
		return lobEmailSentFlag;
	}
	public void setLobEmailSentFlag(Character lobEmailSentFlag) {
		this.lobEmailSentFlag = lobEmailSentFlag;
	}
	public Long getFiatID() {
		return fiatID;
	}
	public void setFiatID(Long fiatID) {
		this.fiatID = fiatID;
	}

	public EmailDetails getLpEmailDetails() {
		return lpEmailDetails;
	}
	
	public void setLpEmailDetails(EmailDetails lpEmailDetails) {
		this.lpEmailDetails = lpEmailDetails;
	}
	
	public EmailDetails getMarketEmailDetails() {
		return marketEmailDetails;
	}
	
	public void setMarketEmailDetails(EmailDetails marketEmailDetails) {
		this.marketEmailDetails = marketEmailDetails;
	}

}
