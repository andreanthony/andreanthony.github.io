package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CollateralRepository extends JpaRepository<Collateral, Long> {
    
	List<Collateral> findByCollateralWorkItemsWorkItem(WorkItem workItem);

    @Query("select c.adminComments from Collateral c where c.rid = ?1")
    String getAdminCommentsFor(Long rid);

	/*@Modifying
	@Query("update Collateral c set c.adminComments = ?1 where c.rid = ?2")
	int setAdminCommentsFor(String adminComments, Long rid);*/

}
