package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;



public interface UsersRepository extends JpaRepository<Users, String>{

	Users findByUsernameIgnoreCaseAndEnabled(String username, boolean enabled);

	Users findBySidIgnoreCase(String sid);

	Users findByUsernameIgnoreCase(String username);

//disable users that did not log in in system between 90-180 days. adding logic to check inserted date also
	@Query("select user from Users user where (trunc(lastLoginDate) < trunc(sysdate-90) and trunc(lastLoginDate) >= trunc(sysdate-180)) " +
			" or (lastLoginDate is null and " +
			"  trunc(insertedDate) < trunc(sysdate-90) and trunc(insertedDate) >= trunc(sysdate-180))"
			+"and enabled = true")
	List<Users> findUsersToBeDisabled();
//remove users that are not in the system for more than 180 days
	@Query("select user from Users user where (trunc(lastLoginDate) < trunc(sysdate-180))" +
			" or ( lastLoginDate is null and trunc(insertedDate) < trunc(sysdate-180))")
	List<Users> findUsersToBeDeleted();

}



