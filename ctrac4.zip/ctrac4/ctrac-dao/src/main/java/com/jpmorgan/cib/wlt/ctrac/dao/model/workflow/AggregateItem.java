package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_AGGREGATE_ITEM")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class AggregateItem extends WorkItem {
		
	@Column(name = "CREATED_DATE")
	private Date createdDate;
	
	@Column(name = "ESCROW_BALANCE_AMOUNT")
	private BigDecimal escrowBalanceAmount;  
	
	public BigDecimal getEscrowBalanceAmount() {
		return escrowBalanceAmount;
	}

	public void setEscrowBalanceAmount(BigDecimal escrowBalanceAmount) {
		this.escrowBalanceAmount = escrowBalanceAmount;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
