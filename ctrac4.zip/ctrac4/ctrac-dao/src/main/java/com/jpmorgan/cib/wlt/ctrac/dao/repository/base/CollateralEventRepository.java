package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralEvent;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.UUID;

public interface CollateralEventRepository extends JpaRepository<CollateralEvent, Long> {

	CollateralEvent findByEventUuid(UUID eventUuid);

	Page<CollateralEvent> findByEventTimeBetween(Date fromDate, Date toDate, Pageable pageable);
}
