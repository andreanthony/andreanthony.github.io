package com.jpmorgan.cib.wlt.ctrac.dao.tm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.tm.model.TMReconciliationView;


public interface TMReconcilationViewRepository extends JpaRepository<TMReconciliationView, String>{

	public List<TMReconciliationView> findByTaskStateIn(List<String> taskStatus);
	public TMReconciliationView findByTaskId(String taskId);
	
}