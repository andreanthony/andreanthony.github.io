package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

@Entity
@Table(name="VLCP_COLLATERAL_INSURANCE")
@IdClass(value=CollateralInsuranceViewDataPK.class)
public class CollateralInsuranceViewData implements Serializable {

    private static final long serialVersionUID = -7465068132879219901L;
    
    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COLLATERAL_RID")
    private Collateral collateral;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PROOF_OF_COVERAGE_RID")
    private ProofOfCoverage proofOfCoverage;

    public Collateral getCollateral() {
        return collateral;
    }

    public void setCollateral(Collateral collateral) {
        this.collateral = collateral;
    }

    public ProofOfCoverage getProofOfCoverage() {
        return proofOfCoverage;
    }

    public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
        this.proofOfCoverage = proofOfCoverage;
    }

}
