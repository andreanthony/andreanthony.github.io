package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Building;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BuildingRepository extends JpaRepository<Building, Long> {
    @Query("select b from Building b where b.collateralRid=:collateralId and b.active=1")
    List<Building> findByCollateralId(@Param("collateralId") Long collateralId);

    @Query("select b from Building b where b.collateralRid=:collateralId and b.sortOrder=:sortOrder and b.active=1")
    Building findByCollateralIdAndSortOrder(@Param("collateralId") Long collateralId, @Param("sortOrder") Integer sortOrder);
}
