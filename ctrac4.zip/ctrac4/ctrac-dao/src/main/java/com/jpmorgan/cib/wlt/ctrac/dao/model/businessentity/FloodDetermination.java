package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

@Entity
@Table(name = "TLCP_FLOOD_DETERMINATION")
public class FloodDetermination extends CtracBaseEntity {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "floodDeterminationSeqGenerator")
	@TableGenerator(name = "floodDeterminationSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_FLOOD_DETERMINATION", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "COLLATERAL_RID", nullable = false)
	private Long collateralRid;

	@Column(name = "VENDOR")
	private String vendor;
	
	@Column(name = "ORDER_NUMBER")
	private String orderNumber;
	
	@Column(name = "LOAN_IDENTIFIER")
	private String loanIdentifier;
	
	@Column(name = "DATE_OF_DETERMINATION")
	private Date dateOfDetermination;
	
	@Column(name = "DATE_OF_MAP_CHANGE")
	private Date dateOfMapChange;
	
	@Column(name = "FLOOD_ZONE")
	private String floodZone;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "VERIFICATION_DATE")
	private Date verificationDate;
	
	@ManyToOne
	@JoinColumn(name = "COLLATERAL_DOC_RID")
	private CollateralDocument determinationDocument;
	
	public CollateralDocument getDeterminationDocument() {
		return determinationDocument;
	}

	public void setDeterminationDocument(CollateralDocument determinationDocument) {
		this.determinationDocument = determinationDocument;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getLoanIdentifier() {
		return loanIdentifier;
	}

	public void setLoanIdentifier(String loanIdentifier) {
		this.loanIdentifier = loanIdentifier;
	}

	public Date getDateOfDetermination() {
		return dateOfDetermination;
	}

	public void setDateOfDetermination(Date dateOfDetermination) {
		this.dateOfDetermination = dateOfDetermination;
	}

	public Date getDateOfMapChange() {
		return dateOfMapChange;
	}

	public void setDateOfMapChange(Date dateOfMapChange) {
		this.dateOfMapChange = dateOfMapChange;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getVerificationDate() {
		return verificationDate;
	}

	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}

	public boolean isInFloodZone() {
		if (floodZone == null) {
			return false;
		}
		return floodZone.toUpperCase().trim().startsWith("A") || floodZone.toUpperCase().trim().startsWith("V");
		
	}
		
}
