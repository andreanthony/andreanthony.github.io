/**
 *
 */
package com.jpmorgan.cib.wlt.ctrac.dao.model.workflow;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;


/**
 * @author q003321
 *
 */
@Entity
@Table(name = "TLCP_WORK_ITEM_RELATION")
public class WorkItemRelation {

	public WorkItemRelation() {
		super();
	}

	public WorkItemRelation(WorkItem parentWorkItem, WorkItem childWorkItem) {
		super();
		this.parentWorkItem = parentWorkItem;
		this.childWorkItem = childWorkItem;
	}

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "workItemRelationSeqGenerator")
	@TableGenerator(name = "workItemRelationSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_WORK_ITEM_RELATION", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name = "PARENT_WORK_ITEM_RID", referencedColumnName="RID", nullable=true)
	private WorkItem parentWorkItem;

	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name = "CHILD_WORK_ITEM_RID", referencedColumnName="RID", nullable=true)
	private WorkItem childWorkItem;

	@Column(name = "RELATION_TYPE")
	private String relationType;


	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public WorkItem getParentWorkItem() {
		return parentWorkItem;
	}

	public void setParentWorkItem(WorkItem parentWorkItem) {
		this.parentWorkItem = parentWorkItem;
	}

	public WorkItem getChildWorkItem() {
		return childWorkItem;
	}

	public void setChildWorkItem(WorkItem childWorkItem) {
		this.childWorkItem = childWorkItem;
	}

	public String getRelationType() {
		return relationType;
	}

	public void setRelationType(String relationType) {
		this.relationType = relationType;
	}
}
