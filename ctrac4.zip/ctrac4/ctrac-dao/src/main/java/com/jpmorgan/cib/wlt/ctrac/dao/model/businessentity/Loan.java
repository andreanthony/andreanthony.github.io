package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.LineOfBusiness;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

@Entity
@Table(name = "TLCP_LOAN")
public class Loan extends CtracBaseEntity implements Serializable {

	private static final long serialVersionUID = -796388696948603486L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "loanSeqGenerator")
	@TableGenerator(name = "loanSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_LOAN", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "LOAN_NUMBER")
	private String loanNumber;

	@Column(name = "LOAN_ACCOUNTING_SYSTEM")
	private String loanAccountingSystem;

	@Column(name = "LINE_OF_BUSINESS")
	private String lineOfBusiness;

	@Column(name = "LOAN_TYPE")
	private String loanType;

	@Column(name = "RELEASE_DATE")
	private Date releasedDate;

	@Column(name = "LOADED_DATE")
	private Date loadedDate;

	@Column(name = "ESCROW_TYPE")
	private String escrowType;

	@Column(name = "AGENT_LEAD_BANK_NAME")
	private String agentLeadBankName;

	@Column(name = "AGENT_LEAD_BANK_EMAIL")
	private String agentLeadBankEmail;

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "loan")
	private List<LoanCollateral> loanCollaterals = new ArrayList<LoanCollateral>();

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "loan")
	private List<LoanBorrower> loanBorrowers = new ArrayList<LoanBorrower>();

	public void addCollateral(Collateral collateral) {
		LoanCollateral loanCollateral = new LoanCollateral();
		loanCollateral.setCollateral(collateral);
		loanCollateral.setLoan(this);
		if (!this.loanCollaterals.contains(loanCollateral)) {
			this.loanCollaterals.add(loanCollateral);
		}
	}

	public boolean addBorrower(Customer borrower) {
		LoanBorrower loanBorrower = new LoanBorrower();
		loanBorrower.setBorrower(borrower);
		loanBorrower.setLoan(this);
		if (!this.loanBorrowers.contains(loanBorrower)) {
			this.loanBorrowers.add(loanBorrower);
			return true;
		}
		return false;
	}

	public void removeBorrower(Customer borrower) {
		Iterator<LoanBorrower> loanBorrowerItr = this.loanBorrowers.iterator();
		while(loanBorrowerItr.hasNext()){
			LoanBorrower loanBorrower = loanBorrowerItr.next();
			if (loanBorrower.getBorrower().equals(borrower)) {
				loanBorrowerItr.remove();
			}
		}
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getStatus() {
		return status;
	}

	public LoanStatus getStatus_( ){
		LoanStatus lsataus =null;
		try {
			lsataus =LoanStatus.valueOf(status);
		} catch (Exception swallow) {}
		return lsataus;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getLoanAccountingSystem() {
		return loanAccountingSystem;
	}

	public void setLoanAccountingSystem(String loanAccountingSystem) {
		this.loanAccountingSystem = loanAccountingSystem;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public List<LoanCollateral> getLoanCollaterals() {
		return loanCollaterals;
	}

	public List<LoanBorrower> getLoanBorrowers() {
		return loanBorrowers;
	}

	public Customer getPreferredBorrower() {
		Customer preferredBorrower = null;
		Long minRid = Long.MAX_VALUE;
		for (LoanBorrower loanBorrower : loanBorrowers) {
			if (loanBorrower.getBorrower().getRid() < minRid) {
				preferredBorrower = loanBorrower.getBorrower();
			}
		}
		return preferredBorrower;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Loan other = (Loan) obj;
		if (rid == null) {
			if (other.rid != null) {
				return false;
			}
		} else if (!rid.equals(other.rid)) {
			return false;
		}
		return true;
	}

	public Date getReleasedDate() {
		return releasedDate;
	}

	public void setReleasedDate(Date releasedDate) {
		this.releasedDate = releasedDate;
	}

	public Date getLoadedDate() {
		return loadedDate;
	}

	public void setLoadedDate(Date loadedDate) {
		this.loadedDate = loadedDate;
	}



	public String getEscrowType() {
		return escrowType;
	}

	public void setEscrowType(String escrowType) {
		this.escrowType = escrowType;
	}

	public String getAgentLeadBankName() {
		return agentLeadBankName;
	}

	public void setAgentLeadBankName(String agentLeadBankName) {
		this.agentLeadBankName = agentLeadBankName;
	}

	public String getAgentLeadBankEmail() {
		return agentLeadBankEmail;
	}

	public void setAgentLeadBankEmail(String agentLeadBankEmail) {
		this.agentLeadBankEmail = agentLeadBankEmail;
	}
}
