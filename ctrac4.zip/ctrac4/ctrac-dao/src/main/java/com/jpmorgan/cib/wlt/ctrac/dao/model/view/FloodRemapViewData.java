package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracReconcilable;


//making changes to add ctrac to tm reconciliation. task creation property was added
@Entity
@Table(name = "VLCP_FLOOD_REMAP_DATA")
public class FloodRemapViewData implements CtracReconcilable{
	
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name="WORK_ITEM_RID")
	private Long workItemRid;
	
	@Column(name = "BORROWER_NAME")
	private String borrowerName;

	@Column(name = "ADDRESS")
	private String address;
	
	@Column(name = "CITY")
	private String city;
	
	@Column(name = "STATE")
	private String state;

	@Column(name = "ZIP_CODE")
	private String zipCode;
	
	@Column(name = "COUNTY")
	private String county;
	
	@Column(name = "LOAN_NUMBER")
	private String loanNumber;
	
	@Column(name = "CTRAC_ID")
	private String ctracId;
	
	@Column(name = "WORKFLOW_STEP")
	private String workFlowStep;

	/*
	 * Changed from column FLD_ZONE_CHNG_STATUS to REMAP_CATEGORY
	 * Holds the same value, no change to the java variable name
	 */
	@Column(name = "REMAP_CATEGORY")
	private String statusChange;
	
	@Column(name = "REMAP_CATEGORY_CODE")
	private String statusChangeCode;
	
	@Column(name = "CLIENT_FOUND_FLAG")
	private Character clientFoundFlag;
	
	@Column(name = "PROPERTY_PLEDGED_ON_SYS_FLAG")
	private Character propertyPledgedFlag;
	
	@Column(name = "EXPOSURE_EXISTS_FLAG")
	private Character exposureExistsFlag;
	
	@Column(name = "LOB_EMAIL_SENT_FLAG")
	private String lobEmailSentFlag;
	
	/*
	 * Changed from column REMAP_CATEGORY to FLOOD_ZONE_STATUS
	 * holds the same value: i.e. "IN", "OUT"
	 */
	@Column(name = "FLOOD_ZONE_STATUS")
	private String floodZoneStatus;
	
	@Column(name = "SFHDF_RID")
	private Long sfhdfRid;

	@Column(name="PARTICIPATING_COMM")
	private String participatingCommunity; 
	
	@Column(name="REVISED_FLOOD_ZONE")
	private String revisedFloodZone;
	
	@Column(name="ORIG_FLOOD_ZONE")
	private String origFloodZone;
	
	@Column(name="SOURCE_SYSTEM")
	private String sourceSystem; 

	@Column(name="SOURCE_CREATION_DATE")
	private Date sourceCreationDate;	
	
	@Column(name = "SLA_DAYS_REMAINING")
	private Long slaDaysRemaining;
	
	@Transient
	private String strSlaDaysRemaining;
	
	@Column(name = "OTM_TASK_ID")
	private String tmTaskId;
	
	@Column(name = "TASK_CREATION_DATE")
	private Date taskCreationDate;
	
	@Transient
	private String strSourceCreationDate;	
	
	@Column(name = "LINE_OF_BUSINESS")
	private String lineOfBusiness;
	
	@Column(name="TASK_STATUS")
	private String taskStatus;
	
	@Column(name="REQUEST_NUM")
	private String reqNum;
	
	@Column(name="OTM_TASK_TYPE")
	private String tmTaskType;

	@Column(name="FLOOD_ZONE")
	private String floodZone;

	@Column(name="LPI_TYPE_FLAG")
	private String lpiType;
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getCtracId() {
		return ctracId;
	}

	public void setCtracId(String ctracId) {
		this.ctracId = ctracId;
	}

	public String getWorkFlowStep() {
		return workFlowStep;
	}

	public void setWorkFlowStep(String workFlowStep) {
		this.workFlowStep = workFlowStep;
	}

	public String getStatusChange() {
		return statusChange;
	}

	public void setStatusChange(String statusChange) {
		this.statusChange = statusChange;
	}

	public String getStatusChangeCode() {
		return statusChangeCode;
	}

	public void setStatusChangeCode(String statusChangeCode) {
		this.statusChangeCode = statusChangeCode;
	}

	public Character getClientFoundFlag() {
		return clientFoundFlag;
	}

	public void setClientFoundFlag(Character clientFoundFlag) {
		this.clientFoundFlag = clientFoundFlag;
	}

	public Character getPropertyPledgedFlag() {
		return propertyPledgedFlag;
	}

	public void setPropertyPledgedFlag(Character propertyPledgedFlag) {
		this.propertyPledgedFlag = propertyPledgedFlag;
	}

	public Character getExposureExistsFlag() {
		return exposureExistsFlag;
	}

	public void setExposureExistsFlag(Character exposureExistsFlag) {
		this.exposureExistsFlag = exposureExistsFlag;
	}

	public String getLobEmailSentFlag() {
		return lobEmailSentFlag;
	}

	public void setLobEmailSentFlag(String lobEmailSentFlag) {
		this.lobEmailSentFlag = lobEmailSentFlag;
	}

	public String getFloodZoneStatus() {
		return floodZoneStatus;
	}

	public void setFloodZoneStatus(String floodZoneStatus) {
		this.floodZoneStatus = floodZoneStatus;
	}

	public String getOrigFloodZone() {
		return origFloodZone;
	}

	public void setOrigFloodZone(String origFloodZone) {
		this.origFloodZone = origFloodZone;
	}

	public Long getSfhdfRid() {
		return sfhdfRid;
	}

	public void setSfhdfRid(Long sfhdfRid) {
		this.sfhdfRid = sfhdfRid;
	}

	public Long getSlaDaysRemaining() {
		return slaDaysRemaining;
	}

	public void setSlaDaysRemaining(Long slaDaysRemaining) {
		this.slaDaysRemaining = slaDaysRemaining;		
	}

	public String getTmTaskId() {
		return tmTaskId;
	}

	public void setTmTaskId(String tmTaskId) {
		this.tmTaskId = tmTaskId;
	}
	public Date getTaskCreationDate() {
		return taskCreationDate;
	}

	public void setTaskCreationDate(Date taskCreationDate) {
		this.taskCreationDate = taskCreationDate;
	}

	@Override
	@Deprecated
	public String getGenericId() {
		return tmTaskId;
	}

	public String getParticipatingCommunity() {
		return participatingCommunity;
	}

	public void setParticipatingCommunity(String participatingCommunity) {
		this.participatingCommunity = participatingCommunity;		
	}

	public String getRevisedFloodZone() {
		return revisedFloodZone;
	}

	public void setRevisedFloodZone(String revisedFloodZone) {
		this.revisedFloodZone = revisedFloodZone;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public Date getSourceCreationDate() {
		return sourceCreationDate;
	}

	public void setSourceCreationDate(Date sourceCreationDate) {		
		this.sourceCreationDate = sourceCreationDate;	
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getReqNum() {
		return reqNum;
	}

	public void setReqNum(String reqNum) {
		this.reqNum = reqNum;
	}
	
	public String getStrSlaDaysRemaining() {
		return strSlaDaysRemaining;
	}

	public void setStrSlaDaysRemaining(String strSlaDaysRemaining) {
		this.strSlaDaysRemaining = strSlaDaysRemaining;
	}
	
	public String getStrSourceCreationDate() {
		return strSourceCreationDate;
	}

	public void setStrSourceCreationDate(String strSourceCreationDate) {
		this.strSourceCreationDate = strSourceCreationDate;
	}

	@Override
	@Deprecated
	public void fillTransientVariables() {
		Format formatter_timesatamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//2014-06-12 12:06:23
		setStrSourceCreationDate((sourceCreationDate==null)?"":formatter_timesatamp.format(sourceCreationDate));
		
		setStrSlaDaysRemaining((slaDaysRemaining==null)?"":slaDaysRemaining.toString());
		
	}
	
	public String getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}

	public Long getWorkItemRid() {
		return workItemRid;
	}

	public void setWorkItemRid(Long workItemRid) {
		this.workItemRid = workItemRid;
	}
	
	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getLpiType() {
		return lpiType;
	}

	public void setLpiType(String lpiType) {
		this.lpiType = lpiType;
	}
}
