package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_REQUIRED_PROVIDED_GAP")
public class RequiredProvidedCoverageGapViewData {
	@Id
	@Column(name = "ASSET_RID")
	private Long assetRid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name="COLLATERAL_TYPE")
	private String collateralType;

	@Column(name="LINE_OF_BUSINESS")
	private String lineOfBusiness;
	
	@Column(name="LOAN_TYPE")
	private String loanType;
	
	@Column(name="BUILDING_NAME")
	private String buildingName;
	
	@Column(name="SOURCE_DOCUMENT")
	private String sourceDocument;
	
	@Column(name="DOCUMENT_DATE")
	private Date documentDate;	
	
	@Column(name="COVERAGE_TYPE")
	private String coverageType;//BUILDING or CONTENTS or BUSINESS INCOME
	
	@Column(name="PRIMARY_VS_EXCESS")
	private String primaryVsExcess;
	
	@Column(name="REQUIRED_COVERAGE_AMOUNT")
	private BigDecimal requiredCoverageAmount;
	
	@Column(name="LP_PROVIDED_COVERAGE")
	private BigDecimal lpProvidedCoverage;
	
	@Column(name="LP_EXPIRATION_DATE")
	private Date lpExpirationDate;	
	
	@Column(name="BORROWER_PROVIDED_COVERAGE")
	private BigDecimal borrowerProvidedCoverage;
	
	@Column(name="BORR_POLICY_EXPIRATION_DATE")
	private Date borrowerPolicyExpirationDate;
	
	@Column(name="GAP_AMOUNT")
	private BigDecimal gapAmount;
	
	@Column(name="STATUS")
	private String status;
	
	
	public Long getAssetRid() {
		return assetRid;
	}

	public void setAssetRid(Long assetRid) {
		this.assetRid = assetRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getSourceDocument() {
		return sourceDocument;
	}

	public void setSourceDocument(String sourceDocument) {
		this.sourceDocument = sourceDocument;
	}

	public Date getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getPrimaryVsExcess() {
		return primaryVsExcess;
	}

	public void setPrimaryVsExcess(String primaryVsExcess) {
		this.primaryVsExcess = primaryVsExcess;
	}

	public BigDecimal getRequiredCoverageAmount() {
		return requiredCoverageAmount;
	}

	public void setRequiredCoverageAmount(BigDecimal requiredCoverageAmount) {
		this.requiredCoverageAmount = requiredCoverageAmount;
	}

	public BigDecimal getLpProvidedCoverage() {
		return lpProvidedCoverage;
	}

	public void setLpProvidedCoverage(BigDecimal lpProvidedCoverage) {
		this.lpProvidedCoverage = lpProvidedCoverage;
	}

	public Date getLpExpirationDate() {
		return lpExpirationDate;
	}

	public void setLpExpirationDate(Date lpExpirationDate) {
		this.lpExpirationDate = lpExpirationDate;
	}

	public BigDecimal getBorrowerProvidedCoverage() {
		return borrowerProvidedCoverage;
	}

	public void setBorrowerProvidedCoverage(BigDecimal borrowerProvidedCoverage) {
		this.borrowerProvidedCoverage = borrowerProvidedCoverage;
	}

	public Date getBorrowerPolicyExpirationDate() {
		return borrowerPolicyExpirationDate;
	}

	public void setBorrowerPolicyExpirationDate(Date borrowerPolicyExpirationDate) {
		this.borrowerPolicyExpirationDate = borrowerPolicyExpirationDate;
	}

	public BigDecimal getGapAmount() {
		return gapAmount;
	}

	public void setGapAmount(BigDecimal gapAmount) {
		this.gapAmount = gapAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}	
}
