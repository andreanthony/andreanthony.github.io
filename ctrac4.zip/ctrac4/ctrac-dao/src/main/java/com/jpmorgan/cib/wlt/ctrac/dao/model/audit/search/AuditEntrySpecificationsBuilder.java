package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search;

import com.jpmorgan.cib.wlt.ctrac.dao.model.audit.AuditEntry;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AuditEntrySpecificationsBuilder {

    private final List<AuditEntrySpecification> specs;

    public AuditEntrySpecificationsBuilder() {
        specs = new ArrayList<>();
    }

    AuditEntrySpecificationsBuilder(List<AuditEntrySpecification> specs) {
        this.specs = new ArrayList<>(specs);
    }

    public AuditEntrySpecificationsBuilder collateralId(Long collateralId) {
        if (collateralId != 0) {
            return this.with("collateralId", SearchOperation.EQUAL, collateralId);
        } else {
            return this.with("collateralId", SearchOperation.NULL, null);
        }
    }

    public AuditEntrySpecificationsBuilder collateralSection(String collateralSection) {
        return this.with("collateralSection", SearchOperation.EQUAL, collateralSection);
    }

    public AuditEntrySpecificationsBuilder minEventTime(Date minEventTime) {
        return this.with("eventTime", SearchOperation.GREATER_THAN, minEventTime);
    }

    public AuditEntrySpecificationsBuilder maxEventTime(Date maxEventTime) {
        return this.with("eventTime", SearchOperation.LESS_THAN, maxEventTime);
    }

    public AuditEntrySpecificationsBuilder withAttrLike(String key, String value) {
        if (StringUtils.isNotBlank(value)) {
            return this.with(key, SearchOperation.LIKE, "%" + value.toLowerCase() + "%");
        }
        return this;
    }

    private AuditEntrySpecificationsBuilder with(String key, SearchOperation operation, Object value) {
        specs.add(new AuditEntrySpecification(new SearchCriteria(key, operation, value)));
        return this;
    }

    public Specification<AuditEntry> build() {
        if (specs.size() == 0) {
            return null;
        }
        Specification<AuditEntry> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specifications.where(result).and(specs.get(i));
        }
        return result;
    }

    List<AuditEntrySpecification> getSpecs() {
        return new ArrayList<>(specs);
    }
}
