package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "TLCP_BUILDING")
public class Building extends CtracBaseEntity {

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "buildingSeqGenerator")
	@TableGenerator(name = "buildingSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BUILDING", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;

    @Column(name = "COLLATERAL_RID", nullable = false)
    private Long collateralRid;

	@ManyToOne
	@JoinColumn(name = "COLLATERAL_RID", insertable = false, updatable = false)
	private Collateral collateral;

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "building")
	private List<InsurableAsset> insurableAssets = new ArrayList<>();

	@Column(name = "BUILDING_NAME")
	private String buildingName;

	@Column(name = "ACTIVE")
	private Boolean active;

	@Column(name = "SORT_ORDER")
	private Integer sortOrder;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public Collateral getCollateral() {
		return collateral;
	}

	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}

	public String getBuildingName() {
		return buildingName;
	}

    public List<InsurableAsset> getInsurableAssets() {
        return insurableAssets;
    }

    public void setInsurableAssets(List<InsurableAsset> insurableAssets) {
        this.insurableAssets = insurableAssets;
    }

    public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Integer getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}
}
