package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

/**
 * 
 * @author n595724
/**
 * This is just a meta model used to create safe query on the EmailTemplateRule model object
 */
@StaticMetamodel(EmailTemplateRule.class)
public class EmailTemplateRule_ {

    
    public static volatile SingularAttribute<EmailTemplateRule,Long> rid;
    
    public static volatile SingularAttribute<EmailTemplateRule,String> ruleName;
    
    public static volatile SingularAttribute<EmailTemplateRule,String> lob;
       
    public static volatile SingularAttribute<EmailTemplateRule,String> remapType; 
    
    public static volatile SingularAttribute<EmailTemplateRule,String> status;
  
    public static volatile SingularAttribute<EmailTemplateRule,String> escalation;
    
    public static volatile SingularAttribute<EmailTemplateRule,String> typeId;
    
    public static volatile SingularAttribute<EmailTemplateRule,String> workflowStepId;
    
    public static volatile SingularAttribute<EmailTemplateRule,String> others;
   
    public static volatile SingularAttribute<EmailTemplateRule,String> emailTemplateId;
    
    public static volatile SingularAttribute<EmailTemplateRule,String> additionalInfo;
    
    public static volatile SingularAttribute<EmailTemplateRule,String> emailCategory;


}
