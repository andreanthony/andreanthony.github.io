package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Collateral;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.CollateralItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;

@Entity
@Table(name="VLCP_ITEM_ACT_CITEM_RELATION")
public class ActiveCollateralWorkflowRelation implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6217990952571842589L;
	
	@Id
	@Column(name = "TASK_RID")
	private Long rid;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "WORK_ITEM_RID")
    private WorkItem workItem;
    
	@Column(name = "OTM_TASK_ID")
    private String taskId;
    
    
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "COLLATERAL_ITEM_RID")
    private CollateralItem collateralItem;
	
	/*@Column(name = "CTASK_WORKFLOW_STEP")
	private String ctaskWorkflowStep;	*/
	
	@Column(name = "TASK_WORKFLOW_STEP")
	private String taskWorkflowStep;	
    
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "COLLATERAL_ID")
    private Collateral collateral;  

    public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public CollateralItem getCollateralItem() {
		return collateralItem;
	}

	public void setCollateralItem(CollateralItem collateralItem) {
		this.collateralItem = collateralItem;
	}

	public Collateral getCollateral() {
		return collateral;
	}

	public void setCollateral(Collateral collateral) {
		this.collateral = collateral;
	}
	
	/*public String getCtaskWorkflowStep() {
		return ctaskWorkflowStep;
	}

	public void setCtaskWorkflowStep(String ctaskWorkflowStep) {
		this.ctaskWorkflowStep = ctaskWorkflowStep;
	}*/

	public String getTaskWorkflowStep() {
		return taskWorkflowStep;
	}

	public void setTaskWorkflowStep(String taskWorkflowStep) {
		this.taskWorkflowStep = taskWorkflowStep;
	}
}
