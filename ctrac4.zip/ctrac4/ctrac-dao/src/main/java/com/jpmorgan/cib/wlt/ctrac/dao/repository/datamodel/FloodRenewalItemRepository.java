package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.Renewal;

@Deprecated
public interface FloodRenewalItemRepository extends
		JpaRepository<Renewal, Long> {
	
	public Renewal findByRid(Long rid);

}
