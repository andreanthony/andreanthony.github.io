package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_WORKFLOW_MAIN_DETAILS")
public class WorkflowMainDetailsViewData {
	
	@Id
	@Column(name = "RID")
	private String rid;
	
	@Column(name = "TASK_RID")
	private Long taskRid;
	
	@Column(name = "WORK_ITEM_RID")
	private Long workItemRid;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "PROOF_OF_COVERAGE_RID")
	private Long proofOfCoverageRid;
	
	@Column(name = "ITEM_TYPE")
	private String itemType;
	
	@Column(name="TASK_ID")
	private String taskId;
	
	@Column(name="TASK_TYPE")
	private String taskType;
	
	@Column(name="TASK_STATUS")
	private String taskStatus;
	
	@Column(name="WORKFLOW_STEP")
	private String workFlowStep;
	
	@Column(name="PERFECTION_TYPE")
	private String perfectionType;
	
	@Column(name="PERFECTION_SUB_TYPE")
	private String perfectionSubType;
	
	@Column(name="COLLATERAL_STATUS")
	private String collateralStatus;
	
	@Column(name="COLLATERAL_TYPE")
	private String collateralType;
	
	@Column(name="COLLATERAL_SUB_TYPE")
	private String collateralSubType;
	
	public String getRid() {
		return rid;
	}

	public void setRid(String rid) {
		this.rid = rid;
	}

	public Long getTaskRid() {
		return taskRid;
	}

	public void setTaskRid(Long taskRid) {
		this.taskRid = taskRid;
	}

	public Long getWorkItemRid() {
		return workItemRid;
	}

	public void setWorkItemRid(Long workItemRid) {
		this.workItemRid = workItemRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	
	public String getTaskType() {
		return taskType;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getWorkFlowStep() {
		return workFlowStep;
	}

	public void setWorkFlowStep(String workFlowStep) {
		this.workFlowStep = workFlowStep;
	}

	public String getPerfectionType() {
		return perfectionType;
	}

	public void setPerfectionType(String perfectionType) {
		this.perfectionType = perfectionType;
	}

	public String getPerfectionSubType() {
		return perfectionSubType;
	}

	public void setPerfectionSubType(String perfectionSubType) {
		this.perfectionSubType = perfectionSubType;
	}

	public String getCollateralStatus() {
		return collateralStatus;
	}

	public void setCollateralStatus(String collateralStatus) {
		this.collateralStatus = collateralStatus;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public String getCollateralSubType() {
		return collateralSubType;
	}

	public void setCollateralSubType(String collateralSubType) {
		this.collateralSubType = collateralSubType;
	}

	
		
}
