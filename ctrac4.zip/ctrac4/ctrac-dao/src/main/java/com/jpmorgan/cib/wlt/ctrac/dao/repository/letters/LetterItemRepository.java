package com.jpmorgan.cib.wlt.ctrac.dao.repository.letters;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LetterItem;

/**
 * @author N664895
 *
 */
public interface LetterItemRepository extends JpaRepository<LetterItem, Long>{

}
