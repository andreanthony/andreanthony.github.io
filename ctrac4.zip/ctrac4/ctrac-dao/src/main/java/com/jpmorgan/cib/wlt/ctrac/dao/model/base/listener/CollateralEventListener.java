package com.jpmorgan.cib.wlt.ctrac.dao.model.base.listener;

import com.jpmorgan.cib.wlt.ctrac.auth.AuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.auth.CtracAuthenticationManagerImpl;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralEvent;
import com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.TrustStoreManagerServiceImpl;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.EventStoreException;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.client.EventStoreClient;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.client.EventStoreFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import javax.net.ssl.SSLContext;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;

public class CollateralEventListener {

	private static final Logger LOGGER = LoggerFactory.getLogger(CollateralEventListener.class);
	private EventStoreClient eventStoreClient = null;
	private String eventApiUrl;

	private void init() {
		ApplicationContext context = ApplicationContextProvider.getContext();
		eventApiUrl = context.getEnvironment().getProperty("ctrac.event.api.url");
		eventStoreClient = EventStoreFactory.create(eventApiUrl,
				getSSLContext(), getAuthenticationManager());
	}

	SSLContext getSSLContext() {
		return ApplicationContextProvider.getContext().getBean(TrustStoreManagerServiceImpl.class)
				.getTrustStoreManager().getSSLContext();
	}

	AuthenticationManager getAuthenticationManager() {
		return ApplicationContextProvider.getContext().getBean(CtracAuthenticationManagerImpl.class);
	}

	@PostPersist
	@PostUpdate
	public void postPersistOrUpdate(final CollateralEvent collateralEvent) {
		if (eventStoreClient == null) {
			init();
		}
		TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
			@Override
			public void afterCompletion(int status) {
				if (CollateralEventStatus.PENDING.name().equals(collateralEvent.getEventStatus()) &&
						TransactionSynchronization.STATUS_COMMITTED == status) {
					try {
						boolean isAsyncPost = false;
						eventStoreClient.publish(collateralEvent.getEventJson(),
								getAuthenticationManager().getAuthenticationToken(), isAsyncPost);
					} catch (EventStoreException e) {
						LOGGER.error("Publishing to event api {} failed", eventApiUrl, e);
					}
				}
			}
		});
	}
}
