package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_PRIMARY_LOANBORROWER_DATA")
public class PrimaryLoanBorrowerViewData {
	
	@Column(name = "LOAN_RID")
	private Long loanRid;	
	
	@Id
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "BORROWER_RID")
	private Long borrowerRid;

	@Column(name="IND_PRIMARY_LOAN")
	private String primaryLoanInd;
	
	@Column(name="LOAN_ACCOUNTING_SYSTEM")
	private String loanAccountingSystem;
	
	@Column(name="LINE_OF_BUSINESS")
	private String lineOfBusiness;
	
	@Column(name="LINE_OF_BUSINESS_DESC")
	private String lineOfBusinessDescription;
	
	@Column(name="LOAN_TYPE")
	private String loanType;
	
	@Column(name="LOAN_NUMBER")
	private String loanNumber;
	
	@Column(name="LOAN_RELEASE_DATE")
	private Date loanReleaseDate;
	
	@Column(name="LOAN_LOADED_DATE")
	private Date loanLoadedDate;
	
	@Column(name="LOAN_CREATED_BY")
	private String loaCreatedBy;
	
	@Column(name="LOAN_LAST_UPDATED_BY")
	private String loanLastUpdatedBy;
	
	@Column(name="LOAN_CREATED_DATE")
	private Date loanCreatedDate;
	
	@Column(name="LOAN_LAST_UPDATED_DATE")
	private Date loanLastUpdatedDate;
	
	@Column(name = "BORROWER_NAME_INCLUDE_OWNER")
	private String borrowerNameIncludingOwners;
	
	@Column(name="BORROWER_NAME")
	private String borrowerName;
	
	@Column(name="BORROWER_ADDR")
	private String borrowerAddress;
	
	@Column(name="BORROWER_CITY")
	private String borrowerCity;
	
	@Column(name="BORROWER_STATE")
	private String borrowerState;

	@Column(name="BORROWER_ZIPCODE")
	private String borrowerZipCode;
	
	@Column(name="BORROWER_UNIT_BLDG")
	private String borrowerUnitBuilding;
	
	@Column(name="BORROWER_CREATED_BY")
	private String borrowerCreatedBy;
	
	@Column(name="BORROWER_LAST_UPDATED_BY")
	private String borrowerLastUpdatedBy;
	
	@Column(name="BORROWER_CREATED_DATE")
	private Date borrowerCreatedDate;
	
	@Column(name="BORROWER_LAST_UPDATED_DATE")
	private Date borrowerLastUpdatedDate;

	public Long getLoanRid() {
		return loanRid;
	}

	public void setLoanRid(Long loanRid) {
		this.loanRid = loanRid;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getBorrowerRid() {
		return borrowerRid;
	}

	public void setBorrowerRid(Long borrowerRid) {
		this.borrowerRid = borrowerRid;
	}

	public String getPrimaryLoanInd() {
		return primaryLoanInd;
	}

	public void setPrimaryLoanInd(String primaryLoanInd) {
		this.primaryLoanInd = primaryLoanInd;
	}

	public String getLoanAccountingSystem() {
		return loanAccountingSystem;
	}

	public void setLoanAccountingSystem(String loanAccountingSystem) {
		this.loanAccountingSystem = loanAccountingSystem;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getLineOfBusinessDescription() {
		return lineOfBusinessDescription;
	}

	public void setLineOfBusinessDescription(String lineOfBusinessDescription) {
		this.lineOfBusinessDescription = lineOfBusinessDescription;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public Date getLoanReleaseDate() {
		return loanReleaseDate;
	}

	public void setLoanReleaseDate(Date loanReleaseDate) {
		this.loanReleaseDate = loanReleaseDate;
	}

	public Date getLoanLoadedDate() {
		return loanLoadedDate;
	}

	public void setLoanLoadedDate(Date loanLoadedDate) {
		this.loanLoadedDate = loanLoadedDate;
	}

	public String getLoaCreatedBy() {
		return loaCreatedBy;
	}

	public void setLoaCreatedBy(String loaCreatedBy) {
		this.loaCreatedBy = loaCreatedBy;
	}

	public String getLoanLastUpdatedBy() {
		return loanLastUpdatedBy;
	}

	public void setLoanLastUpdatedBy(String loanLastUpdatedBy) {
		this.loanLastUpdatedBy = loanLastUpdatedBy;
	}

	public Date getLoanCreatedDate() {
		return loanCreatedDate;
	}

	public void setLoanCreatedDate(Date loanCreatedDate) {
		this.loanCreatedDate = loanCreatedDate;
	}

	public Date getLoanLastUpdatedDate() {
		return loanLastUpdatedDate;
	}

	public void setLoanLastUpdatedDate(Date loanLastUpdatedDate) {
		this.loanLastUpdatedDate = loanLastUpdatedDate;
	}

	public String getBorrowerNameIncludingOwners() {
		return borrowerNameIncludingOwners;
	}

	public void setBorrowerNameIncludingOwners(String borrowerNameIncludingOwners) {
		this.borrowerNameIncludingOwners = borrowerNameIncludingOwners;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getBorrowerAddress() {
		return borrowerAddress;
	}

	public void setBorrowerAddress(String borrowerAddress) {
		this.borrowerAddress = borrowerAddress;
	}

	public String getBorrowerCity() {
		return borrowerCity;
	}

	public void setBorrowerCity(String borrowerCity) {
		this.borrowerCity = borrowerCity;
	}

	public String getBorrowerState() {
		return borrowerState;
	}

	public void setBorrowerState(String borrowerState) {
		this.borrowerState = borrowerState;
	}

	public String getBorrowerZipCode() {
		return borrowerZipCode;
	}

	public void setBorrowerZipCode(String borrowerZipCode) {
		this.borrowerZipCode = borrowerZipCode;
	}

	public String getBorrowerUnitBuilding() {
		return borrowerUnitBuilding;
	}

	public void setBorrowerUnitBuilding(String borrowerUnitBuilding) {
		this.borrowerUnitBuilding = borrowerUnitBuilding;
	}

	public String getBorrowerCreatedBy() {
		return borrowerCreatedBy;
	}

	public void setBorrowerCreatedBy(String borrowerCreatedBy) {
		this.borrowerCreatedBy = borrowerCreatedBy;
	}

	public String getBorrowerLastUpdatedBy() {
		return borrowerLastUpdatedBy;
	}

	public void setBorrowerLastUpdatedBy(String borrowerLastUpdatedBy) {
		this.borrowerLastUpdatedBy = borrowerLastUpdatedBy;
	}

	public Date getBorrowerCreatedDate() {
		return borrowerCreatedDate;
	}

	public void setBorrowerCreatedDate(Date borrowerCreatedDate) {
		this.borrowerCreatedDate = borrowerCreatedDate;
	}

	public Date getBorrowerLastUpdatedDate() {
		return borrowerLastUpdatedDate;
	}

	public void setBorrowerLastUpdatedDate(Date borrowerLastUpdatedDate) {
		this.borrowerLastUpdatedDate = borrowerLastUpdatedDate;
	}
}
