/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.dao.model.external;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.TMTaskType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;


/**
 * @author F544636
 *
 */
/**
 * This is a JPA entity class to hold  Service Link new Flood Remap Activity. Remap Data fetched from TLCP_CL_FLOOD_REMAP staging table.
 * @date 20-MAR-2015
 */

@Entity
@Table(name = "TLCP_CL_FLOOD_REMAP")

public class CoreLogicFloodRemap extends CtracBaseEntity {
	
	public static final String CORE_LOGIC_SOURCE_SYSTEM = "CoreLogic";

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "remapActivitySeqGenerator")
	@TableGenerator(name = "remapActivitySeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_CL_FLOOD_REMAP", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")	
	private Long rid;	

	@Column(name ="RECORDTYPE")   
	private String recordType; 
	
	@Column(name ="TRANSACTIONCODE")   
	private String transactionCode;
	
	@Column(name ="SERVICER")
	private String servicer;
	
	@Column(name ="DEPTCODE")
	private String deptCode;
	
	@Column(name ="BORROWERFIRSTNAME")
	private String borrowerFirstName;
	
	@Column(name ="BORROWERLASTNAME")
	private String borrowerLastName;
	
	@Column(name ="LOANNUMBER")
	private String loanNumber;
	
	@Column(name ="STATUSCHANGE")
	private String statusChange;
	
	@Column(name ="REQUESTNUM")
	private String requestNum;
	
	@Column(name ="ADDRESS")
	private String address;
	
	@Column(name ="CITY")
	private String city;
	
	@Column(name ="ZIPCODE")
	private String zipCode;
	
	@Column(name ="STATE")
	private String state;
	
	@Column(name="ORIGINALPARTIALFLAG")
	private String originalPartialFlag;
	
	@Column(name ="ORIGINALFLOODSTATUS")
	private String originalFloodStatus;
	
	@Column(name ="ORIGINALFLOODZONE")
	private String originalFloodZone;
	
	@Column(name ="REVISEDFLOODSTATUS")
	private String revisedFloodStatus;
	
	@Column(name ="REVISEDPARTIALFLAG")
	private String revisedPartialFlag;
	
	@Column(name ="ORIGINALCOMMUNITYSTATUS")
	private String originalCommunityStatus;
	
	@Column(name ="PARTICIPATINGCOMMUNITY")
	private String participatingCommunity;
	
	@Column(name ="REVISEDCOMMUNITYNUMBER")
	private String revisedCommunityNumber;
	
	@Column(name ="REVISEDCOMMUNITYNAME")
	private String revisedCommunityName;
	
	@Column(name ="REVISEDCOMMUNITYDATE")
	private Date revisedCommunityDate;
	
	@Column(name ="REVISEDPANEL")
	private String revisedPanel;
	
	@Column(name ="REVISEDSUFFIX")
	private String revisedSuffix;
	
	@Column(name ="REVISEDMAPDATE")
	private Date revisedMapDate;
	
	@Column(name ="REVISEDMAPNUMBER")
	private String revisedMapNumber;
	
	@Column(name ="LOMARDATE")
	private Date lomaRDate;
	
	@Column(name ="REVISEDFLOODZONE")
	private String revisedFloodZone;
	
	@Column(name ="DETERMINATIONDATE")
	private Date determinationDate;
	
	@Column(name ="NOTIFICATIONTYPE")
	private String notificationType;
	
	@Column(name="PROCESSING_STATUS")
	private String dataProcessingStatus;
	
	@Transient
	private String borrowerName;	
	
	@Transient
	private String sourceSystem = CORE_LOGIC_SOURCE_SYSTEM;	
	
	@Column(name ="REMAP_CREATION_DATE")	
	private Date remapCreationDate;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name = "SFHDF_RID", referencedColumnName="RID", nullable=true)
	private CollateralDocument floodRemapSFHDF;
	
	@Transient
	private String tmTaskType = TMTaskType.FLOOD_REMAP.name();

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getServicer() {
		return servicer;
	}

	public void setServicer(String servicer) {
		this.servicer = servicer;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getBorrowerFirstName() {
		return borrowerFirstName;
	}

	public void setBorrowerFirstName(String borrowerFirstName) {
		this.borrowerFirstName = borrowerFirstName;
	}

	public String getBorrowerLastName() {
		return borrowerLastName;
	}

	public void setBorrowerLastName(String borrowerLastName) {
		this.borrowerLastName = borrowerLastName;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getStatusChange() {
		return statusChange;
	}

	public void setStatusChange(String statusChange) {
		this.statusChange = statusChange;
	}

	public String getRequestNum() {
		return requestNum;
	}

	public void setRequestNum(String requestNum) {
		this.requestNum = requestNum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getOriginalPartialFlag() {
		return originalPartialFlag;
	}

	public void setOriginalPartialFlag(String originalPartialFlag) {
		this.originalPartialFlag = originalPartialFlag;
	}

	public String getOriginalFloodStatus() {
		return originalFloodStatus;
	}

	public void setOriginalFloodStatus(String originalFloodStatus) {
		this.originalFloodStatus = originalFloodStatus;
	}

	public String getOriginalFloodZone() {
		return originalFloodZone;
	}

	public void setOriginalFloodZone(String originalFloodZone) {
		this.originalFloodZone = originalFloodZone;
	}

	public String getRevisedFloodStatus() {
		return revisedFloodStatus;
	}

	public void setRevisedFloodStatus(String revisedFloodStatus) {
		this.revisedFloodStatus = revisedFloodStatus;
	}

	public String getRevisedPartialFlag() {
		return revisedPartialFlag;
	}

	public void setRevisedPartialFlag(String revisedPartialFlag) {
		this.revisedPartialFlag = revisedPartialFlag;
	}

	public String getOriginalCommunityStatus() {
		return originalCommunityStatus;
	}

	public void setOriginalCommunityStatus(String originalCommunityStatus) {
		this.originalCommunityStatus = originalCommunityStatus;
	}

	public String getParticipatingCommunity() {
		return participatingCommunity;
	}

	public void setParticipatingCommunity(String participatingCommunity) {
		this.participatingCommunity = participatingCommunity;
	}

	public String getRevisedCommunityNumber() {
		return revisedCommunityNumber;
	}

	public void setRevisedCommunityNumber(String revisedCommunityNumber) {
		this.revisedCommunityNumber = revisedCommunityNumber;
	}

	public String getRevisedCommunityName() {
		return revisedCommunityName;
	}

	public void setRevisedCommunityName(String revisedCommunityName) {
		this.revisedCommunityName = revisedCommunityName;
	}

	public Date getRevisedCommunityDate() {
		return revisedCommunityDate;
	}

	public void setRevisedCommunityDate(Date revisedCommunityDate) {
		this.revisedCommunityDate = revisedCommunityDate;
	}

	public String getRevisedPanel() {
		return revisedPanel;
	}

	public void setRevisedPanel(String revisedPanel) {
		this.revisedPanel = revisedPanel;
	}

	public String getRevisedSuffix() {
		return revisedSuffix;
	}

	public void setRevisedSuffix(String revisedSuffix) {
		this.revisedSuffix = revisedSuffix;
	}

	public Date getRevisedMapDate() {
		return revisedMapDate;
	}

	public void setRevisedMapDate(Date revisedMapDate) {
		this.revisedMapDate = revisedMapDate;
	}

	public String getRevisedMapNumber() {
		return revisedMapNumber;
	}

	public void setRevisedMapNumber(String revisedMapNumber) {
		this.revisedMapNumber = revisedMapNumber;
	}

	public Date getLomaRDate() {
		return lomaRDate;
	}

	public void setLomaRDate(Date lomaRDate) {
		this.lomaRDate = lomaRDate;
	}

	public String getRevisedFloodZone() {
		return revisedFloodZone;
	}

	public void setRevisedFloodZone(String revisedFloodZone) {
		this.revisedFloodZone = revisedFloodZone;
	}

	public Date getDeterminationDate() {
		return determinationDate;
	}

	public void setDeterminationDate(Date determinationDate) {
		this.determinationDate = determinationDate;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getDataProcessingStatus() {
		return dataProcessingStatus;
	}

	public void setDataProcessingStatus(String dataProcessingStatus) {
		this.dataProcessingStatus = dataProcessingStatus;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public Date getRemapCreationDate() {
		return remapCreationDate;
	}

	public void setRemapCreationDate(Date remapCreationDate) {
		this.remapCreationDate = remapCreationDate;
	}

	public CollateralDocument getFloodRemapSFHDF() {
		return floodRemapSFHDF;
	}

	public void setFloodRemapSFHDF(CollateralDocument floodRemapSFHDF) {
		this.floodRemapSFHDF = floodRemapSFHDF;
	}
	public String getTmTaskType() {
		return tmTaskType;
	}

	public void setTmTaskType(String tmTaskType) {
		this.tmTaskType = tmTaskType;
	}
	
}
