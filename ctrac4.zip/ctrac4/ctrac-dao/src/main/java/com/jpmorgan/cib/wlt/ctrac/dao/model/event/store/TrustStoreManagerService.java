package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store;

import com.jpmorgan.cib.wlt.ctrac.event.store.shared.secure.TrustStoreManager;

public interface TrustStoreManagerService {

    TrustStoreManager getTrustStoreManager();
}
