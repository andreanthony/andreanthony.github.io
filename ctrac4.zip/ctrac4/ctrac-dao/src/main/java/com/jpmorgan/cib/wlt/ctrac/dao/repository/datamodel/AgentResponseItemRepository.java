package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.AgentResponseItem;

public interface AgentResponseItemRepository extends JpaRepository<AgentResponseItem,Long>{

	AgentResponseItem findByProofOfCoverageRidAndCollateralRid(Long proofOfCoverageRid, Long birCollateralDetailsRid);
	
}
