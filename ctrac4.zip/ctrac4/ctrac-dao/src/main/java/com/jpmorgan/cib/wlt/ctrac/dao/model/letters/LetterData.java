/**
 * 
 */
package com.jpmorgan.cib.wlt.ctrac.dao.model.letters;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

/**
 * @author Q003321
 *
 */
 @Entity
 @Table(name = "TLCP_LETTER_DATA")
public class LetterData extends CtracBaseEntity implements Serializable{
	 
	 /**
	 * 
	 */
	private static final long serialVersionUID = 5347829321342180527L;
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "letterDataSeqGenerator")
		@TableGenerator(name = "letterDataSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_LETTER_DATA", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
 
		@Id
		@Column(name = "RID")
		private Long rid;	
		@Column(name = "COLLATERAL_RID")
		private Long collateralRid;
		
		@Column(name = "LETTER_ID")
		private String letterId;	
		
		@Column(name="LOAN_NUMBER")
		private String loanNumber;	
		
		@Column(name = "LINE_OF_BUSINESS")
		private String lineOfBusiness;	
		
		@Column(name = "BORROWER_NAME")
		private String borrowerName;	
		
		@Column(name = "PROOF_OF_COVERAGE_RID")		
		private Long proofOfCoverageRid;
		
		@Column(name = "LETTER_FILE_RID")		
		private Long letterFileRid;

		@Column(name = "STATUS")		
		private String status;
		
		@Column(name = "RECIPIENT_NAME")		
		private String recipientName;
		
		public Long getRid() {
			return rid;
		}

		public void setRid(Long rid) {
			this.rid = rid;
		}

		public Long getCollateralRid() {
			return collateralRid;
		}

		public void setCollateralRid(Long collateralRid) {
			this.collateralRid = collateralRid;
		}


		public String getLoanNumber() {
			return loanNumber;
		}

		public void setLoanNumber(String loanNumber) {
			this.loanNumber = loanNumber;
		}

		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		public String getBorrowerName() {
			return borrowerName;
		}

		public void setBorrowerName(String borrowerName) {
			this.borrowerName = borrowerName;
		}

		public Long getProofOfCoverageRid() {
			return proofOfCoverageRid;
		}

		public void setProofOfCoverageRid(Long proofOfCoverageRid) {
			this.proofOfCoverageRid = proofOfCoverageRid;
		}

		public Long getLetterFileRid() {
			return letterFileRid;
		}

		public void setLetterFileRid(Long letterFileRid) {
			this.letterFileRid = letterFileRid;
		}

		public String getLetterId() {
			return letterId;
		}

		public void setLetterId(String letterId) {
			this.letterId = letterId;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getRecipientName() {
			return recipientName;
		}

		public void setRecipientName(String recipientName) {
			this.recipientName = recipientName;
		}
		
}
