package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * This is a JPA entity class to control batch process. 
 * @date 24-Feb-2014
 */

@Entity
@Table(name = "TLCP_BATCH_CTRL")
public class BatchCtrl extends CtracBaseEntity {
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "remapBatchCtrlSeqGenerator")
	@TableGenerator(name = "remapBatchCtrlSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BATCH_CTRL", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "CTRL_FLAG")
	private Character ctrlFlag;
	
	@Column(name = "BATCH_TYPE")
	private String batchType;
	
	@Column(name = "RUNNING")
	private Character running;
	
	@Column(name = "SCHEDULER_HOST")
	private String schedulerHost;

	@Column(name = "MULTIPLE_PER_DAY")
	private Character multiplePerDay;	
	
	@Column(name= "LAST_RUN_DATE")
	private Date lastRunDate;
	
	@Column(name= "LAST_SUCCESSFUL_COMPLETE_DATE")
	private Date lastSuccessfulCompleteDate;

	@Column(name = "CAN_HOLD_RELEASE_FLAG")
	private Character canHoldReleaseFlag;

	@Column(name = "BATCH_LABEL")
	private String batchLabel;

	@Column(name = "CRON_JOB")
	private String cronJob;

	
	public Character getCanHoldReleaseFlag() {
		return canHoldReleaseFlag;
	}

	public void setCanHoldReleaseFlag(Character canHoldReleaseFlag) {
		this.canHoldReleaseFlag = canHoldReleaseFlag;
	}

	public String getCronJob() {
		return cronJob;
	}

	public void setCronJob(String cronJob) {
		this.cronJob = cronJob;
	}
	
	public Character getMultiplePerDay() {
		return multiplePerDay;
	}

	public void setMultiplePerDay(Character multiplePerDay) {
		this.multiplePerDay = multiplePerDay;
	}

	public String getBatchLabel() {
		return batchLabel;
	}

	public void setBatchLabel(String batchLabel) {
		this.batchLabel = batchLabel;
	}
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Character getCtrlFlag() {
		return ctrlFlag;
	}

	public void setCtrlFlag(Character ctrlFlag) {
		this.ctrlFlag = ctrlFlag;
	}

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}
	
	public Character getRunning() {
		return running;
	}

	public void setRunning(Character running) {
		this.running = running;
	}

	public String getSchedulerHost() {
		return schedulerHost;
	}

	public void setSchedulerHost(String schedulerHost) {
		this.schedulerHost = schedulerHost;
	}

	public Date getLastRunDate() {
		return lastRunDate;
	}

	public void setLastRunDate(Date lastRunDate) {
		this.lastRunDate = lastRunDate;
	}

	public Date getLastSuccessfulCompleteDate() {
		return lastSuccessfulCompleteDate;
	}

	public void setLastSuccessfulCompleteDate(Date lastSuccessfulCompleteDate) {
		this.lastSuccessfulCompleteDate = lastSuccessfulCompleteDate;
	}
	
}
