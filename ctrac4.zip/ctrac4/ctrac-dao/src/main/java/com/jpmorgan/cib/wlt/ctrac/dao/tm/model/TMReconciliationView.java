package com.jpmorgan.cib.wlt.ctrac.dao.tm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracReconcilable;

@Entity
@Table(name = "ltm_task")
public class TMReconciliationView implements CtracReconcilable {

	@Id
	@Column(name = "ID")
	private String id;

	@Column(name = "TASK_ID")
	private String taskId;

	@Column(name = "STATUS_CHANGE")
	private String tmStatusChange;


	@Column(name = "ADDRESS")
	private String tmAddress;

	@Column(name = "CITY")
	private String tmPropertyCity;

	@Column(name = "ZIP_CODE")
	private String tmPropertyZip;

	@Column(name = "STATE")
	private String tmPropertyState;

	@Column(name = "LOAN_NUMBER")
	private String tmLoanNumber;

	@Column(name = "SLA_DAYS_REMAINING")
	private String tmSLADaysRemaining;

	@Column(name = "BORROWER_NAME")
	private String tmBorrowerName;

	@Column(name = "LINE_OF_BUSINESS")
	private String tmLOB;

	@Column(name = "SOURCE_SYSTEM_ID")
	private String sourceSysId;

	@Column(name = "REQUEST_NUM")
	private String requestNumber;

	@Column(name = "PARTICIPATING_COMM")
	private String tmPartCommunity;

	@Column(name = "REVISED_FLOOD_ZONE")
	private String tmFLoodZone;

	@Column(name = "REFEERENCE_ENTITY_ID")
	private String tmReferenceId;

	@Column(name = "WORKFLOW_STEP")
	private String tmWorkflowStep ;

	@Column(name = "TASK_STATE")
	private String taskState;

    @Column(name = "CONTRACT_ID")
	private String iDContract;

	@Column(name = "WORKFLOW_TYPE")
	private String workFlowType ;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTmStatusChange() {
		return tmStatusChange;
	}

	public void setTmStatusChange(String tmStatusChange) {
		this.tmStatusChange = tmStatusChange;
	}

	public String getTmAddress() {
		return tmAddress;
	}

	public void setTmAddress(String tmAddress) {
		this.tmAddress = tmAddress;
	}

	public String getTmPropertyCity() {
		return tmPropertyCity;
	}

	public void setTmPropertyCity(String tmPropertyCity) {
		this.tmPropertyCity = tmPropertyCity;
	}

	public String getTmPropertyZip() {
		return tmPropertyZip;
	}

	public void setTmPropertyZip(String tmPropertyZip) {
		this.tmPropertyZip = tmPropertyZip;
	}

	public String getTmPropertyState() {
		return tmPropertyState;
	}

	public void setTmPropertyState(String tmPropertyState) {
		this.tmPropertyState = tmPropertyState;
	}

	public String getTmLoanNumber() {
		return tmLoanNumber;
	}

	public void setTmLoanNumber(String tmLoanNumber) {
		this.tmLoanNumber = tmLoanNumber;
	}

	public String getTmSLADaysRemaining() {
		return tmSLADaysRemaining;
	}

	public void setTmSLADaysRemaining(String tmSLADaysRemaining) {
		this.tmSLADaysRemaining = tmSLADaysRemaining;
	}

	public String getTmBorrowerName() {
		return tmBorrowerName;
	}

	public void setTmBorrowerName(String tmBorrowerName) {
		this.tmBorrowerName = tmBorrowerName;
	}

	public String getTmLOB() {
		return tmLOB;
	}

	public void setTmLOB(String tmLOB) {
		this.tmLOB = tmLOB;
	}

	public String getSourceSysId() {
		return sourceSysId;
	}

	public void setSourceSysId(String sourceSysId) {
		this.sourceSysId = sourceSysId;
	}

	public String getRequestNumber() {
		return requestNumber;
	}

	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}

	public String getTmPartCommunity() {
		return tmPartCommunity;
	}

	public void setTmPartCommunity(String tmPartCommunity) {
		this.tmPartCommunity = tmPartCommunity;
	}

	public String getTmFLoodZone() {
		return tmFLoodZone;
	}

	public void setTmFLoodZone(String tmFLoodZone) {
		this.tmFLoodZone = tmFLoodZone;
	}

	public String getTmReferenceId() {
		return tmReferenceId;
	}

	public void setTmReferenceId(String tmReferenceId) {
		this.tmReferenceId = tmReferenceId;
	}

	public String getTmWorkflowStep() {
		return tmWorkflowStep;
	}

	public void setTmWorkflowStep(String tmWorkflowStep) {
		this.tmWorkflowStep = tmWorkflowStep;
	}

	public String getTaskState() {
		return taskState;
	}

	public void setTaskState(String taskState) {
		this.taskState = taskState;
	}

	public String getiDContract() {
		return iDContract;
	}

	public void setiDContract(String iDContract) {
		this.iDContract = iDContract;
	}

	public String getWorkFlowType() {
		return workFlowType;
	}

	public void setWorkFlowType(String workFlowType) {
		this.workFlowType = workFlowType;
	}

	public String toString(){
		return "taskID: "+ taskId + " borrowerName: "+tmBorrowerName;
	}

	@Override
	public String getGenericId() {
		return taskId;
	}

	@Override
	public void fillTransientVariables() {
		//NoTransientVeriables defined in this Model		
	}


}
