package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.TaskDetailsData;

public interface TaskDetailsDataRepository extends JpaRepository<TaskDetailsData, Long> {	
	TaskDetailsData findByTmTaskId(String tmTaskId);	
	List<TaskDetailsData> findByTaskStatus(String taskStatus);	
	
}
