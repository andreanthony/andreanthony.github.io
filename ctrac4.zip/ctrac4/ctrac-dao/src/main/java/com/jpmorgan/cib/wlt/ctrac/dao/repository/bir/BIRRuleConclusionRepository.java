package com.jpmorgan.cib.wlt.ctrac.dao.repository.bir;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.bir.BIRRuleConclusion;

public interface BIRRuleConclusionRepository extends JpaRepository<BIRRuleConclusion, Long> {

	List<BIRRuleConclusion> findByProofOfCoverageRid(Long proofOfCoverageRid);
	
	List<BIRRuleConclusion> findByProofOfCoverageRidAndCollateralRidAndFieldName(Long proofOfCoverageRid, Long collateralRid, String fieldName);
	
	Long countByProofOfCoverageRidAndConclusion(Long proofOfCoverageRid, String conclusion);
	
}
