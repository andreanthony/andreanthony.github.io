package com.jpmorgan.cib.wlt.ctrac.dao.config;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CtracErrorSeverity;
import com.jpmorgan.cib.wlt.ctrac.commons.exception.CTracApplicationException;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.EncryptionUtil;
import com.jpmorgan.cib.wlt.ctrac.commons.utils.ErrorCodeToMessageConverter;
import javapasswordsdk.PSDKPassword;
import javapasswordsdk.PSDKPasswordRequest;
import javapasswordsdk.PasswordSDK;
import javapasswordsdk.exceptions.PSDKException;
import oracle.jdbc.pool.OracleDataSource;
import org.apache.log4j.Logger;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.hibernate4.HibernateExceptionTranslator;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.util.Properties;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
		entityManagerFactoryRef = "tmEntityManagerFactory", 
        transactionManagerRef = "tmTransactionManager",
		basePackages={"com.jpmorgan.cib.wlt.ctrac.dao.tm.repository"})  
public class TMDataSourceConfig {

	private static final String PROPERTY_NAME_DATABASE_URL = "tm.db.url";
	private static final String PROPERTY_NAME_DATABASE_USERNAME = "tm.db.username";
	private static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
	private static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
	private static final String PROPERTY_NAME_ENTITYMANAGER_PACKAGES_TO_SCAN = "tm.entitymanager.packages.to.scan";
	
	private static final String PROPERTY_NAME_DATABASE_MINLIMIT = "db.connpool.minLimit";
	private static final String PROPERTY_NAME_DATABASE_MAXLIMIT = "db.connpool.maxLimit";
	private static final String PROPERTY_NAME_DATABASE_INITIALLIMIT = "db.connpool.initialLimit";
	private static final String PROPERTY_NAME_DATABASE_CONNTIMEOUT = "db.connpool.timeout";
	private static final String PROPERTY_NAME_DATABASE_INACTIVITYTIMEOUT = "db.connpool.inactivityTimeout";
	private static final String PROPERTY_NAME_DATABASE_VALIDATECONN = "db.connpool.validateConn";

	private static final String PROPERTY_NAME_EPV_AIM_TOMCAT_CONFIG = "epv-aim.tomcat.config";
	private static final String PROPERTY_NAME_EPV_AIM_SAFE = "epv-aim.safe";
	private static final String PROPERTY_NAME_EPV_AIM_APPID = "epv-aim.appId";
	private static final String PROPERTY_NAME_EPV_AIM_FOLDER = "epv-aim.folder";
	private static final String PROPERTY_NAME_EPV_AIM_OBJECT = "epv-aim.object";
	private static final String DERIVED_PROPERTY_NAME_EPV_AIM_DB_HOSTNAME = "tm.db.hostNameFromURL";
	private static final Logger logger = Logger.getLogger(TMDataSourceConfig.class);

	@Resource
	private Environment env;

	@Bean(name = "tmDataSource")
	public DataSource dataSource(){
		DataSource dataSource = null;
		OracleDataSource oracleDataSource = null;

		try {

			String useTomcatConfiguration = env.getProperty(PROPERTY_NAME_EPV_AIM_TOMCAT_CONFIG);

			if (useTomcatConfiguration != null && useTomcatConfiguration.equalsIgnoreCase("Y")) {
				logger.info("DB password is not specified. Getting the password from EPV-AIM using Tomcat Context Configuration.");

				Context initContext = new InitialContext();
				Context webContext = (Context)initContext.lookup("java:/comp/env");
				String dataSourceName = "jdbc/tmDB";
				dataSource = (DataSource) webContext.lookup(dataSourceName);

				// Testing connection
				logger.info("Making test connection to DB (Getting connection from connection pool");
				Connection conn = dataSource.getConnection();
				DatabaseMetaData dmd = conn.getMetaData();

				logger.info("getURL: " + dmd.getURL() + " getUserName: " + dmd.getUserName());
				logger.info("Closing test connection");
				conn.close();

				return dataSource;
			} else {
				oracleDataSource = new OracleDataSource();

				oracleDataSource.setURL(env.getRequiredProperty(PROPERTY_NAME_DATABASE_URL));
				oracleDataSource.setUser(env.getRequiredProperty(PROPERTY_NAME_DATABASE_USERNAME));

				if (env.getProperty("tm.db.password") == null) {
					logger.info("DB password is not specified. Getting the password from EPV-AIM.");
					oracleDataSource.setPassword(getPasswordFromEPVAIM());
				} else {
					logger.info("DB password is specified. Getting the password from the properties file.");
					oracleDataSource.setPassword(EncryptionUtil.decrypt(env.getRequiredProperty("tm.db.password")));
				}
				oracleDataSource.setImplicitCachingEnabled(true);
				oracleDataSource.setConnectionCacheName("ctracDSCache");
				oracleDataSource.setConnectionCacheProperties(connectionCacheProperties());
				return oracleDataSource;
			}
		} catch(Exception ex) {
			// Additional safety mechanism - if exception, blank out the userId so that account doesn't get locked.
			if (oracleDataSource != null) {
				oracleDataSource.setUser("");
			}
			logger.error(ex.getMessage(), ex);
			logger.error(ErrorCodeToMessageConverter.convertToMessage("E0152", CtracErrorSeverity.CRITICAL));
		}
		return dataSource;
	}

	private String getPasswordFromEPVAIM() {
		PSDKPassword sdkPassword = null;
		String password = null;

		try {
			PSDKPasswordRequest psdkPasswordRequest = new PSDKPasswordRequest();

			String epvAIMSafe = env.getRequiredProperty(PROPERTY_NAME_EPV_AIM_SAFE);
			psdkPasswordRequest.setSafe(epvAIMSafe);

			String epvAIMAppID = env.getRequiredProperty(PROPERTY_NAME_EPV_AIM_APPID);
			psdkPasswordRequest.setAppID(epvAIMAppID);

			String epvAIMFolder = env.getRequiredProperty(PROPERTY_NAME_EPV_AIM_FOLDER);
			psdkPasswordRequest.setFolder(epvAIMFolder);

			String epvAIMObject = env.getRequiredProperty(PROPERTY_NAME_EPV_AIM_OBJECT);

			if (epvAIMObject.indexOf("{" + PROPERTY_NAME_DATABASE_USERNAME + "}") > -1) {
				epvAIMObject = epvAIMObject.replace("{db.username}", env.getRequiredProperty(PROPERTY_NAME_DATABASE_USERNAME));
			}

			if (epvAIMObject.indexOf("{" + DERIVED_PROPERTY_NAME_EPV_AIM_DB_HOSTNAME + "}") > -1) {
				String dbURL = env.getRequiredProperty(PROPERTY_NAME_DATABASE_URL);
				String hostName = "";

				String[] urlParts = dbURL.split(":");
				if (urlParts.length == 5 || urlParts.length == 6) {
					hostName = urlParts[3];
					hostName = hostName.replace("@", "");
				} else {
					throw new CTracApplicationException("E0301", CtracErrorSeverity.APPLICATION);
				}

				epvAIMObject = epvAIMObject.replace("{" + DERIVED_PROPERTY_NAME_EPV_AIM_DB_HOSTNAME + "}", hostName);
			}

			psdkPasswordRequest.setObject(epvAIMObject);

			logger.info("EPV-AIM Safe: " + epvAIMSafe + " AppID: " +  epvAIMAppID + " epvAIMFolder: " + epvAIMFolder + " epvAIMObject: " + epvAIMObject);

			sdkPassword = PasswordSDK.getPassword(psdkPasswordRequest);

			if (sdkPassword == null || sdkPassword.getContent() == null || sdkPassword.getContent().trim().equals("")) {
				throw new CTracApplicationException("E0300", CtracErrorSeverity.APPLICATION);
			} else {
				password = sdkPassword.getContent();
				String message="Address: "+sdkPassword.getAddress()+" User Name: "+sdkPassword.getUserName();
				logger.info(message);
			}
		} catch (PSDKException e) {
			// Log and throw exception
			logger.error(e.getMessage(), e);
		}

		return(password);
	}

	@Bean(name = "tmEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean  entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
		entityManagerFactoryBean.setDataSource(dataSource());
		entityManagerFactoryBean.setPersistenceProviderClass(HibernatePersistenceProvider.class);
		entityManagerFactoryBean.setPackagesToScan(env.getRequiredProperty(PROPERTY_NAME_ENTITYMANAGER_PACKAGES_TO_SCAN));
		entityManagerFactoryBean.setJpaProperties(hibProperties());
		entityManagerFactoryBean.getJpaPropertyMap().put("hibernate.default_schema", "LTM");

		entityManagerFactoryBean.afterPropertiesSet();
		return entityManagerFactoryBean;
	}

	@Bean(name = "tmTransactionManager")
	public JpaTransactionManager transactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return transactionManager;
	}
	
	@Bean
	public HibernateExceptionTranslator hibernateExceptionTranslator() {
		return new HibernateExceptionTranslator();
	}
	
	private Properties hibProperties() {
		Properties properties = new Properties();
		properties.put(PROPERTY_NAME_HIBERNATE_DIALECT, env.getRequiredProperty(PROPERTY_NAME_HIBERNATE_DIALECT));
		properties.put(PROPERTY_NAME_HIBERNATE_SHOW_SQL, env.getRequiredProperty(PROPERTY_NAME_HIBERNATE_SHOW_SQL));
		return properties;
	}
	

	private Properties connectionCacheProperties() {
		Properties properties = new Properties();
		properties.setProperty("MinLimit", env.getRequiredProperty(PROPERTY_NAME_DATABASE_MINLIMIT));    
		properties.setProperty("MaxLimit", env.getRequiredProperty(PROPERTY_NAME_DATABASE_MAXLIMIT));  
		properties.setProperty("InitialLimit", env.getRequiredProperty(PROPERTY_NAME_DATABASE_INITIALLIMIT)); 
		properties.setProperty("ConnectionWaitTimeout", env.getRequiredProperty(PROPERTY_NAME_DATABASE_CONNTIMEOUT));
		properties.setProperty("InactivityTimeout", env.getRequiredProperty(PROPERTY_NAME_DATABASE_INACTIVITYTIMEOUT)); 
		properties.setProperty("ValidateConnection", env.getRequiredProperty(PROPERTY_NAME_DATABASE_VALIDATECONN)); 
		return properties;
	}
	
	
}
