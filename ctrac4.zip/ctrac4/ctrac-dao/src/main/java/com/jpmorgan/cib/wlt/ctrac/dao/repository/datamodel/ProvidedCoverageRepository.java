package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProvidedCoverage;

public interface ProvidedCoverageRepository extends JpaRepository<ProvidedCoverage, Long> {

	List<ProvidedCoverage> findByProofOfCoverageRid(Long proofOfCoverageRid);
	
	List<ProvidedCoverage> findByProofOfCoverage(ProofOfCoverage proofOfCoverage);
	
	List<ProvidedCoverage> findByInsurableAssetRid(Long insurableAssetRid);
	
	@Modifying
    @Query("delete from ProvidedCoverage pc where pc.proofOfCoverage.rid=?1")
    void deleteByProofOfCoverageRid(Long proofOfCoverageRid);
	
}
