package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.io.Serializable;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Customer;

public class CustomerIdentificationViewDataPK implements Serializable {
	
	private static final long serialVersionUID = 5491770998169668290L;

	public CustomerIdentificationViewDataPK() {}
    
	private Long collateralRid;
	
	private Customer customer;

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((collateralRid == null) ? 0 : collateralRid.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerIdentificationViewDataPK other = (CustomerIdentificationViewDataPK) obj;
		if (collateralRid == null) {
			if (other.collateralRid != null)
				return false;
		} else if (!collateralRid.equals(other.collateralRid))
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		return true;
	}

}
