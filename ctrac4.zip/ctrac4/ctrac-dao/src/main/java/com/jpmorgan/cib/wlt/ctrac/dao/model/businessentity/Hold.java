package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "TLCP_HOLD")
public class Hold extends CtracBaseEntity implements Serializable {

	private static final long serialVersionUID = -796388696948603497L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "holdSeqGenerator")
	@TableGenerator(name = "holdSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_HOLD", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@OneToOne
	@JoinColumn(name = "PARENT_HOLD_RID")
	private Hold parentHold;

	@Column(name = "HOLD_TYPE")
	private String holdType;

	@Column(name = "START_DATE")
	private Date startDate;

	@Column(name="HOLD_PERIOD")
	private String holdPeriod;

	@Column(name = "LPI_DATE")
	private Date lpiDate;

	@Column(name = "HOLD_STATUS")
	private String holdStatus;

	@Column(name = "VERIFIED_BY")
	private String verifiedBy;

	@Column(name = "VERIFIED_DATE")
	private Date verifiedDate;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Hold getParentHold() {
		return parentHold;
	}

	public void setParentHold(Hold parentHold) {
		this.parentHold = parentHold;
	}

	public String getHoldType() {
		return holdType;
	}

	public void setHoldType(String holdType) {
		this.holdType = holdType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getHoldPeriod() {
		return holdPeriod;
	}

	public void setHoldPeriod(String holdPeriod) {
		this.holdPeriod = holdPeriod;
	}

	public Date getLpiDate() {
		return lpiDate;
	}

	public void setLpiDate(Date lpiDate) {
		this.lpiDate = lpiDate;
	}

	public String getHoldStatus() {
		return holdStatus;
	}

	public void setHoldStatus(String holdStatus) {
		this.holdStatus = holdStatus;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public Date getVerifiedDate() {
		return verifiedDate;
	}

	public void setVerifiedDate(Date verifiedDate) {
		this.verifiedDate = verifiedDate;
	}

    public boolean isNewHold() {
        return parentHold == null && startDate != null && lpiDate == null && VerificationStatus.VERIFIED.name().equals(holdStatus);
    }

}
