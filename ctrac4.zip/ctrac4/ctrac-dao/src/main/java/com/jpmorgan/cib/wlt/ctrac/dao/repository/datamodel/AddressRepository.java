package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
	
}
