package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.ProofOfCoverage;

public interface ProofOfCoverageRepository extends JpaRepository<ProofOfCoverage, Long> {
	
	@Query("select proofOfCoverage from ProofOfCoverage proofOfCoverage where expirationDate <= (select referencDate + ?1 from ReferenceDate where name = 'APP_REFERENCE_DATE') "
			+ "and policyStatus!='EXPIRED'"
			+ "and policyStatus!='EXPIRING_EA'"
			+ "and policyStatus!='PENDING_VERIFICATION'"
			+ "and policyStatus!='CANCELLED' "
			+ "and policyStatus!='EXPIRING'")
	public List<ProofOfCoverage> findAllProofOfCoverageForRenewal(Double days);

	@Query("select proofOfCoverage from ProofOfCoverage proofOfCoverage where expirationDate <= ?1 "
			+ "and policyStatus!='EXPIRED' "
			+ "and policyStatus!='PENDING_VERIFICATION' "
			+ "and policyStatus!='CANCELLED'")
	public List<ProofOfCoverage> findAllProofOfCoverageExpiringOnOrBefore(Date maxExpDate);

	  
	public  List<ProofOfCoverage> findAllProofOfCoverageByPolicyStatus(String policyStatus);
	
	@Query("select proofOfCoverage from ProofOfCoverage proofOfCoverage "
			+ "where (lpAction !='NO_ACTION'  or lpAction is null or policyStatus='PENDING_LETTER_CYCLE' )"
			+ "and (policyStatus!='EXPIRING' or policyStatus!='EXPIRING_EA' )"
			+ "and( proofOfCoverage.policyType = 'LP' or proofOfCoverage.policyType = 'LP_GAP')"
			+ "and( "
			+ "(proofOfCoverage.lpTargetDate < (select referencDate +1 from ReferenceDate where name = 'APP_REFERENCE_DATE') )"
			+ " or (cancellationTargetDate < (select referencDate +1 from ReferenceDate where name = 'APP_REFERENCE_DATE') )) "
			+ " and proofOfCoverage.insuranceAgency = 'Assurant' ")
	public  List<ProofOfCoverage> findAllProofOfCoverageReadyForLpToday();
	
	@Query("select proofOfCoverage from ProofOfCoverage proofOfCoverage where effectiveDate <= (select referencDate + ?1 from ReferenceDate where name = 'APP_REFERENCE_DATE') "
			+ "and policyStatus!='EXPIRED'"
			+ "and policyStatus!='PENDING_VERIFICATION'"
			+ "and policyStatus!='CANCELLED'"
			+ "and lpAction = 'PENDING_C3'")
	public List<ProofOfCoverage> findAllProofOfCoverageBecomingEffective(Double days);
	
	
	//TODO FIXME  review-validate
	ProofOfCoverage findByProvidedCoveragesRid(Long rid);
	
	List<ProofOfCoverage> findByParentPolicyRid(Long parentPolicyRid);

}
