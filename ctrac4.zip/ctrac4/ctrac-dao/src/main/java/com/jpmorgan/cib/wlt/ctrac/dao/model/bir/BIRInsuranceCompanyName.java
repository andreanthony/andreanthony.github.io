package com.jpmorgan.cib.wlt.ctrac.dao.model.bir;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VLCP_INSURANCE_COMPANY_LIST")
public class BIRInsuranceCompanyName {
	
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "APPROVED_INS_COMPANY_NAME")
	private String approvedInsuranceCompanyName;
	
	@Column(name = "COMPANYNAME_SOURCE")
	private String source;
	
	
	@Column(name = "ACTIVE")
	private String active;
	
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getApprovedInsuranceCompanyName() {
		return approvedInsuranceCompanyName;
	}

	public void setApprovedInsuranceCompanyName(String approvedInsuranceCompanyName) {
		this.approvedInsuranceCompanyName = approvedInsuranceCompanyName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}
}
