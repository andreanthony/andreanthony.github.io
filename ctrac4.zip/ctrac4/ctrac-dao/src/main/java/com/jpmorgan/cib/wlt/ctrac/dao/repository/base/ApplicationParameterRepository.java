package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.ApplicationParameter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicationParameterRepository extends JpaRepository<ApplicationParameter, String> {
}
