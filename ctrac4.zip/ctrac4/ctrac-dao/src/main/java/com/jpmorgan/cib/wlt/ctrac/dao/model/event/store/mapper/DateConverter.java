package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store.mapper;

import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.converter.BidirectionalConverter;
import ma.glasnost.orika.metadata.Type;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.Date;

public class DateConverter extends BidirectionalConverter<Date, String> {

    private static final DateTimeFormatter FORMATTER = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");

    @Override
    public String convertTo(Date date, Type<String> type, MappingContext mappingContext) {
        if (date == null) {
            return null;
        }
        return FORMATTER.print(date.getTime());
    }

    @Override
    public Date convertFrom(String s, Type<Date> type, MappingContext mappingContext) {
        if (s == null) {
            return null;
        }
        return FORMATTER.parseDateTime(s).toDate();
    }
}
