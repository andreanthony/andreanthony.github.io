package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;

@Entity
@Table(name = "TLCP_WORK_ITEM_DOCUMENT")
@IdClass(value=WorkItemDocumentPk.class)
public class WorkItemDocument implements Serializable{

	private static final long serialVersionUID = -6579172369232699978L;

	@Id
	@Column(name = "WORK_ITEM_RID")
	private Long workItemRid;
	
	@Id
	@Column(name = "DOCUMENT_RID")
	private Long collateralDocumentRid;

	public Long getWorkItemRid() {
		return workItemRid;
	}

	public void setWorkItemRid(Long workItemRid) {
		this.workItemRid = workItemRid;
	}

	public Long getCollateralDocumentRid() {
		return collateralDocumentRid;
	}

	public void setCollateralDocumentRid(Long collateralDocumentRid) {
		this.collateralDocumentRid = collateralDocumentRid;
	}
}
