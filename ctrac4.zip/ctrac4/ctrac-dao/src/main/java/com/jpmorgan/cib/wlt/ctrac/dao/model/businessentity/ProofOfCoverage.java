package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;

import com.jpmorgan.cib.wlt.ctrac.commons.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.CoverageType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LPActions;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.LenderPlaceReason;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.commons.enums.ProofOfCoverageWorkItemRelationType;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CollateralDocument;
import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.InsuranceRenewalItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.LenderPlaceItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ProofOfCovWorkItem;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.WorkItem;

/**
 * This is a JPA entity class to hold address  table.
 *  @author I031731
 */
@Entity
@Table(name = "TLCP_PROOF_OF_COVERAGE")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class ProofOfCoverage extends CtracBaseEntity {

	@Transient  private static final Logger logger = Logger.getLogger(ProofOfCoverage.class);

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "proofOfCoverageSeqGenerator")
	@TableGenerator(name = "proofOfCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_PROOF_OF_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "PARENT_POLICY_RID")
	private Long parentPolicyRid;

	@Column(name = "POLICY_TYPE")
	private String policyType;

	@Column(name = "POLICY_STATUS")
	private String policyStatus;

	@Column(name = "MIGRATED")
	private Boolean migrated;

	@Transient
	private PolicyStatus collateralPolicyStatus;

	@Column(name = "REASON_FOR_VERIFICATION")
	private String reasonForVerification;

	public String getReasonForVerification() {
		return reasonForVerification;
	}

	public void setReasonForVerification(String reasonForVerification) {
		this.reasonForVerification = reasonForVerification;
	}
	@Column(name = "COVERAGE_TYPE")
	private String coverageType;

	@Column(name = "LENDER_PLACE_VENDOR")
	private String lenderPlaceVendor;

	@Column(name = "POLICY_NUMBER")
	private String policyNumber;

	@Column(name = "ISSUANCE_DATE")
	private Date issuanceDate;

	@Column(name = "EFFECTIVE_DATE")
	private Date effectiveDate;

	@Column(name = "EXPIRATION_DATE")
	private Date expirationDate;

	@Column(name = "CANCELLATION_EFFECTIVE_DATE")
	private Date cancellationEffectiveDate;

	@Column(name = "INSURED_NAME")
	private String insuredName;

	@Column(name = "INSURANCE_AGENCY")
	private String insuranceAgency;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "AGENT_ID")
	private Agent agent;

	@Column(name = "LP_ACTION")
	private String lpAction;

	@Column(name = "IND_RENEWAL")
	private String indRenewal = "N";

	@Column(name = "FLOOD_ZONE")
	private String floodZone;

	@Column(name = "BUILDING_DEDUCTIBLE")
	private BigDecimal buildingDeductible;

	@Column(name = "CONTENTS_DEDUCTIBLE")
	private BigDecimal contentsDeductible;

	@OneToOne
    @JoinColumn(name = "INVOICE_PAYMENT_METHOD_RID")
	private PaymentMethod invoicePaymentMethod;

	@Column(name = "CANCELLATION_REASON")
	private String cancellationReason;

	@Column(name = "LENDER_PLACE_REASON")
	private String lenderPlaceReason;

	@Column(name="LP_TARGET_DATE")
	private Date lpTargetDate;

	@Column(name="CANCELLATION_TARGET_DATE")
	private Date cancellationTargetDate;

	@Column(name="THIRTY_DAY_REG_PERIOD")
	private Date thirtyDayRegulatoryPeriod;

	@Column(name = "LP_LETTER_CYCLE_RESTARTED_DATE")
	private Date lpLetterCycleRestartedDate;

	@OneToOne
    @JoinColumn(name = "REFUND_PAYMENT_METHOD_RID")
	private PaymentMethod refundPaymentMethod;

	@OneToOne
    @JoinColumn(name = "RENEWAL_PAY_METHOD_RID")
	private PaymentMethod preRenewalPaymentMethod;

	@OneToOne(orphanRemoval=true)
	@JoinColumn(name="BLANKET_COVERAGE_RID")
	private BlanketCoverage blanketCoverage;

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "proofOfCoverage")
	private List<ProvidedCoverage> providedCoverages = new ArrayList<ProvidedCoverage>();

	@OneToMany(cascade = {CascadeType.ALL},  mappedBy = "proofOfCoverage")
	private List<ProofOfCovWorkItem> proofOfCovWorkItem = new ArrayList<ProofOfCovWorkItem>();

	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "proofOfCoverageRid", orphanRemoval=true)
	private List<CollateralDocument> policyDocuments = new ArrayList<CollateralDocument>();

	@Column(name="GAP_BORROWER_PROOF_OF_COVG_RID")
	private Long gapBorrowerPolicyRid;

	public Boolean getInvalid() {
		return policyStatus.startsWith("INVALID_");
	}

	public void addWorkItem(WorkItem workItem, ProofOfCoverageWorkItemRelationType relType){
		ProofOfCovWorkItem proofOfCovWorkItem = new ProofOfCovWorkItem();
		proofOfCovWorkItem.setWorkItem(workItem);
		proofOfCovWorkItem.setProofOfCoverage(this);
		proofOfCovWorkItem.setItemType(relType.name());
		if(!this.proofOfCovWorkItem.contains(proofOfCovWorkItem)){
			this.proofOfCovWorkItem.add(proofOfCovWorkItem);
		}
	}

	public void removeWorkItem(WorkItem workItem){

	    Iterator<ProofOfCovWorkItem> pofIt = this.proofOfCovWorkItem.iterator();
	    while(pofIt.hasNext()){
	        ProofOfCovWorkItem proofOfCovWorkItem = pofIt.next();
	        if(proofOfCovWorkItem.getWorkItem().equals(workItem)){
                proofOfCovWorkItem.setProofOfCoverage(null);
                this.proofOfCovWorkItem.remove(proofOfCovWorkItem);
            }
        }
	}

	public void addAllItems(Collection<WorkItem> workItems, ProofOfCoverageWorkItemRelationType relType){
		for (WorkItem workItem : workItems) {
			addWorkItem(workItem, relType);
		}
	}


	public void removeAllItems(List<WorkItem> workItems){
		for (WorkItem workItem : workItems) {
			removeWorkItem(workItem);
		}
	}

	public LenderPlaceItem findLenderPlaceItem() {
		LenderPlaceItem lenderPlaceItem = null;
		for (ProofOfCovWorkItem relation : proofOfCovWorkItem) {
			WorkItem workItem = CtracBaseEntity.deproxy(relation.getWorkItem(), WorkItem.class);
			if (workItem instanceof LenderPlaceItem &&
					(lenderPlaceItem == null || workItem.getRid() > lenderPlaceItem.getRid())) {
				lenderPlaceItem = (LenderPlaceItem) workItem;
			}
		}
		return lenderPlaceItem;
	}

	public InsuranceRenewalItem findInsuranceRenewalItem() {
		InsuranceRenewalItem insuranceRenewalItem = null;
		for (ProofOfCovWorkItem relation : proofOfCovWorkItem) {
			WorkItem workItem = CtracBaseEntity.deproxy(relation.getWorkItem(), WorkItem.class);
			if (workItem instanceof InsuranceRenewalItem &&
					(insuranceRenewalItem == null || workItem.getRid() > insuranceRenewalItem.getRid())) {
				insuranceRenewalItem = (InsuranceRenewalItem) workItem;
			}
		}
		return insuranceRenewalItem;
	}

	public void addProvidedCoverage(ProvidedCoverage providedCoverage) {
		if(providedCoverage.getRid()!=null && providedCoverages.contains(providedCoverage)){
			providedCoverages.remove(providedCoverage);
		}
		providedCoverages.add(providedCoverage);
		providedCoverage.setProofOfCoverage(this);
	}

	public void removeProvidedCoverage(ProvidedCoverage providedCoverage) {
		providedCoverage.setProofOfCoverage(null);
		providedCoverages.remove(providedCoverage);
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Long getParentPolicyRid() {
		return parentPolicyRid;
	}

	public void setParentPolicyRid(Long parentPolicyRid) {
		this.parentPolicyRid = parentPolicyRid;
	}

	public String getPolicyType() {
		return policyType;
	}

	public PolicyType getPolicyType_() {
		PolicyType policyType = null;
	    try {
	        policyType = PolicyType.valueOf(getPolicyType());
	        return policyType;
	    }catch (Exception e) {
	    }
	    return null;
	}


	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

    public PolicyStatus getPolicyStatus_() {
		PolicyStatus policyStatus = null;
		try {
			policyStatus = PolicyStatus.valueOf(this.getPolicyStatus());
		} catch (Exception e) {
			logger.error("policyStatus invalid for policy: " + this.getRid() + ", " + this.getPolicyStatus());
			return null;
		}
		return policyStatus;
    }

	public Boolean getMigrated() {
		return migrated;
	}

	public void setMigrated(Boolean migrated) {
		this.migrated = migrated;
	}

	public String getCoverageType() {
        return coverageType;
    }

	public CoverageType getCoverageType_() {
		CoverageType coverageType = null;
		try {
			coverageType = CoverageType.valueOf(this.getCoverageType());
		} catch (Exception e) {
			logger.error("coverageType invalid for policy: " + this.getRid() + ", " + this.getCoverageType());
			return null;
		}
		return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public PolicyStatus getCollateralPolicyStatus() {
		return collateralPolicyStatus;
	}

	public void setCollateralPolicyStatus(PolicyStatus collateralPolicyStatus) {
		this.collateralPolicyStatus = collateralPolicyStatus;
	}

	public String getLenderPlaceVendor() {
		return lenderPlaceVendor;
	}

	public void setLenderPlaceVendor(String lenderPlaceVendor) {
		this.lenderPlaceVendor = lenderPlaceVendor;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Long getGapBorrowerPolicyRid() {
		return gapBorrowerPolicyRid;
	}

	public void setGapBorrowerPolicyRid(Long borrowerPolicyRid) {
		this.gapBorrowerPolicyRid = borrowerPolicyRid;
	}

	public Date getIssuanceDate() {
		return issuanceDate;
	}

	public void setIssuanceDate(Date issuanceDate) {
		this.issuanceDate = issuanceDate;
	}

	public Date getLpTargetDate() {
		return lpTargetDate;
	}

	public void setLpTargetDate(Date lpTargetDate) {
		this.lpTargetDate = lpTargetDate;
	}

	public Date getCancellationTargetDate() {
		return cancellationTargetDate;
	}

	public void setCancellationTargetDate(Date cancellationTargetDate) {
		this.cancellationTargetDate = cancellationTargetDate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Date getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}

	public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getInsuranceAgency() {
		return insuranceAgency;
	}

	public void setInsuranceAgency(String insuranceAgency) {
		this.insuranceAgency = insuranceAgency;
	}

	public List<ProvidedCoverage> getProvidedCoverages() {
		return providedCoverages;
	}

	public String getLpAction() {
		return lpAction;
	}

	public LPActions getLpAction_() {

		LPActions temp =null;
		try {
			temp = LPActions.valueOf(this.lpAction);
		} catch (Exception swallow) {}

		return temp;
	}


	public void setLpAction(String lpAction) {
		this.lpAction = lpAction;
	}

	public void setProvidedCoverages(List<ProvidedCoverage> providedCoverages) {
		this.providedCoverages = providedCoverages;
	}


	public Set<Collateral> getInsuredCollaterals(){
		Set<Collateral> allCollaterals = new HashSet<>();
		for(ProvidedCoverage providedCoverage : providedCoverages ){
			Collateral collateral = providedCoverage.getInsurableAsset().getBuilding().getCollateral();
			if(collateral!=null){
				allCollaterals.add(collateral);
			}
		}
		return allCollaterals;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProofOfCoverage other = (ProofOfCoverage) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}

	public Agent getAgent() {
		return agent;
	}

	public void setAgent(Agent agent) {
		this.agent = agent;
	}

	public List<ProofOfCovWorkItem> getProofOfCovWorkItem() {
		return proofOfCovWorkItem;
	}

	public void setProofOfCovWorkItem(List<ProofOfCovWorkItem> proofOfCovWorkItem) {
		this.proofOfCovWorkItem = proofOfCovWorkItem;
	}

	public String getIndRenewal() {
		return indRenewal;
	}

	public void setIndRenewal(String indRenewal) {
		this.indRenewal = indRenewal;
	}

    public String getFloodZone() {
        return floodZone;
    }

    public void setFloodZone(String floodZone) {
        this.floodZone = floodZone;
    }

    public BigDecimal getBuildingDeductible() {
        return buildingDeductible;
    }

    public void setBuildingDeductible(BigDecimal buildingDeductible) {
        this.buildingDeductible = buildingDeductible;
    }

    public BigDecimal getContentsDeductible() {
        return contentsDeductible;
    }

    public void setContentsDeductible(BigDecimal contentsDeductible) {
        this.contentsDeductible = contentsDeductible;
    }

    public PaymentMethod getInvoicePaymentMethod() {
        return invoicePaymentMethod;
    }

    public void setInvoicePaymentMethod(PaymentMethod invoicePaymentMethod) {
        this.invoicePaymentMethod = invoicePaymentMethod;
    }

    public String getCancellationReason() {
		return cancellationReason;
	}

    public CancellationReason getCancellationReason_() {
    	CancellationReason temp =null;
		try {
			temp = CancellationReason.valueOf(this.cancellationReason);
		} catch (Exception swallow) {}

		return temp;
	}

	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}

    public String getLenderPlaceReason() {
		return lenderPlaceReason;
	}

	public LenderPlaceReason getLenderPlaceReason_() {
		LenderPlaceReason temp =null;
		try {
			temp = LenderPlaceReason.valueOf(this.lenderPlaceReason);
		} catch (Exception swallow) {}

		return temp;
	}

	public void setLenderPlaceReason(String lenderPlaceReason) {
		this.lenderPlaceReason = lenderPlaceReason;
	}

	public PaymentMethod getRefundPaymentMethod() {
        return refundPaymentMethod;
    }

    public void setRefundPaymentMethod(PaymentMethod refundPaymentMethod) {
        this.refundPaymentMethod = refundPaymentMethod;
    }

    public PaymentMethod getPreRenewalPaymentMethod() {
		return preRenewalPaymentMethod;
	}

	public void setPreRenewalPaymentMethod(PaymentMethod preRenewalPaymentMethod) {
		this.preRenewalPaymentMethod = preRenewalPaymentMethod;
	}

	public List<CollateralDocument> getPolicyDocuments() {
		return policyDocuments;
	}

	public void setPolicyDocuments(List<CollateralDocument> policyDocuments) {
		this.policyDocuments = policyDocuments;
	}

	public BlanketCoverage getBlanketCoverage() {
		return blanketCoverage;
	}

	public void setBlanketCoverage(BlanketCoverage blanketCoverage) {
		this.blanketCoverage = blanketCoverage;
	}
	@Deprecated
	public boolean isBlanketPolicy() {
		if (blanketCoverage != null) {
			String blanketCoverageType = blanketCoverage.getBlanketCoverageType();
			if (!(StringUtils.isBlank(blanketCoverageType)) && !"IND".equals(blanketCoverageType)) {// TODO FIXME create an enum for this
				return true;
			}
		}
		return false;
	}
	@Deprecated
	public boolean isBlanketPolicy(InsurableAssetType assetType) {
		if (blanketCoverage != null) {
			String blanketCoverageType = blanketCoverage.getBlanketCoverageType();
			if (!(StringUtils.isBlank(blanketCoverageType))) {// TODO FIXME // create an enum for this
				if ("IND".equals(blanketCoverageType)) {
					return false;
				} /// setBlanketCoverageType "COMB"
					/// "BLDG".equals(blanketCoverageType) ||
					/// "CONTS".equals(blanketCoverageType) ||
					/// "AND_OR".equals(blanketCoverageType)
				if ((assetType == InsurableAssetType.STRUCTURE) && ("COMB BLDG AND_OR".contains(blanketCoverageType))) {
					return true;
				}
				if ((assetType == InsurableAssetType.BASE_INSURABLE_ASSET)
						&& ("COMB CONTS AND_OR".contains(blanketCoverageType))) {
					return true;
				}
			}
		}
		return false;
	}
	public boolean isReadyForRenewal(){
		if (!"N".equals(getIndRenewal()) ||
				getPolicyType() == null ||
				!getPolicyStatus_().isActive(false)) {
			return false;
		}
		return true;
	}

	/*public boolean isActive(Date date, boolean includePendingVerification) {
		if (getPolicyType_().isBorrowerPolicy()) {
			throw new RuntimeException("This method should not be used for Borrower Policies\nUse BIRCollateralDetails.policyStatus with this.isEffectiveOn");
		}
		return getPolicyStatus_().isActive(includePendingVerification) && isEffectiveOn(date);
	}*/

	public boolean isExpiring(Date date, Boolean includePendingVerification) {
		return getPolicyStatus_().isActive(includePendingVerification) && isExpired(date);
	}

	public boolean isEffectiveOn(Date date) {
		return isEffectiveOn(effectiveDate, expirationDate, date);
	}

	public static boolean isEffectiveOn(Date effectiveDate, Date expirationDate, Date date) {
		if (expirationDate == null || effectiveDate == null) {
			return false;
		}
		if (date == null) {
			return true;
		}
		DateTime effectiveDateTime = new DateTime(effectiveDate).withTimeAtStartOfDay();
		DateTime thisDateTime = new DateTime(date).withTimeAtStartOfDay();
		/**
		 * expirationDateTime must be after thisDateTime to avoid accounting for policies that expire on this date
		 * effectiveDateTime must NOT be after thisDateTime to avoid accounting for policies that aren't effective yet
		 */
		return !isExpired(expirationDate, date) && !effectiveDateTime.isAfter(thisDateTime);
	}

	public boolean isEffectiveAndNotCancelledOn(Date date) {
		if (date == null) {
			return true;
		}
		if (cancellationEffectiveDate == null) {
			return isEffectiveOn(date);
		}
		DateTime cancellationDateTime = new DateTime(cancellationEffectiveDate).withTimeAtStartOfDay();
		DateTime thisDateTime = new DateTime(date).withTimeAtStartOfDay();
		return isEffectiveOn(date) && cancellationDateTime.isAfter(thisDateTime);
	}

	public boolean isEffectiveAfter(Date date) {
		return isEffectiveAfter(effectiveDate, date);
	}

	public static boolean isEffectiveAfter(Date effectiveDate, Date date) {
		if (effectiveDate == null) {
			return false;
		}
		if (date == null) {
			return true;
		}
		DateTime effectiveDateTime = new DateTime(effectiveDate).withTimeAtStartOfDay();
		DateTime thisDateTime = new DateTime(date).withTimeAtStartOfDay();
		/**
		 * effectiveDateTime must be after thisDateTime for policies that aren't effective yet
		 */
		return effectiveDateTime.isAfter(thisDateTime);
	}

	private boolean isExpired(Date date) {
		return isExpired(expirationDate, date);
	}

	private static boolean isExpired(Date expirationDate, Date date) {
		if (expirationDate == null) {
			return true;
		}
		if (date == null) {
			return false;
		}
		DateTime expirationDateTime = new DateTime(expirationDate).withTimeAtStartOfDay();
		DateTime thisDateTime = new DateTime(date).withTimeAtStartOfDay();
		return !thisDateTime.isBefore(expirationDateTime);
	}

	public Date getThirtyDayRegulatoryPeriod() {
		return thirtyDayRegulatoryPeriod;
	}

	public void setThirtyDayRegulatoryPeriod(Date thirtyDayRegulatoryPeriod) {
		this.thirtyDayRegulatoryPeriod = thirtyDayRegulatoryPeriod;
	}

	public Date getLpLetterCycleRestartedDate() {
		return lpLetterCycleRestartedDate;
	}

	public void setLpLetterCycleRestartedDate(Date lpLetterCycleRestartedDate) {
		this.lpLetterCycleRestartedDate = lpLetterCycleRestartedDate;
	}
}
