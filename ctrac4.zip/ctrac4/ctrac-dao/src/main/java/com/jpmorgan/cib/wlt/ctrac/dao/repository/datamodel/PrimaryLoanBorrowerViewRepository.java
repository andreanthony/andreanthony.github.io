package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import com.jpmorgan.cib.wlt.ctrac.dao.model.view.PrimaryLoanBorrowerViewData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PrimaryLoanBorrowerViewRepository extends JpaRepository<PrimaryLoanBorrowerViewData, Long> {
	List<PrimaryLoanBorrowerViewData> findByCollateralRid(Long collateralRid);
	List<PrimaryLoanBorrowerViewData> findByLoanRid(Long loanRid);
}
