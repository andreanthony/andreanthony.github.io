package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

public interface CtracReconcilable {
	public String getGenericId();
	
	public void fillTransientVariables();
}
