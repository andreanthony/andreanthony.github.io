package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.FloodRemap;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.EntitySearchViewData;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.LoanBorrowerAddressData;

public interface LoanBorrowerAddressRepository extends
		JpaRepository<LoanBorrowerAddressData, Long>,
		JpaSpecificationExecutor<LoanBorrowerAddressData> {

	@Query(value="select * from (select * from VLCP_LOAN_BORROWER_ADDRESS ORDER BY STATE_ABBR, CITY, STREET_ADDRESS) WHERE rownum < 101 ORDER BY rownum", nativeQuery = true)
	List<LoanBorrowerAddressData> getLoanBorrowerAddressData();
	
	@Query(value="select count(*) as TOTAL_COUNT from VLCP_LOAN_BORROWER_ADDRESS", nativeQuery = true)
	public int getLoanBorrowerAddressCount();
}
