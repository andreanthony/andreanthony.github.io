package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_PARENT_POLICY_DETAILS")
@IdClass(value=ParentPolicyDetailsViewDataPK.class)
public class ParentPolicyDetailsViewData implements Serializable {

	private static final long serialVersionUID = -4695481099710984156L;

	@Id
    @Column(name = "PARENT_POLICY_RID")
    private Long parentPolicyRid;

	@Id
    @Column(name = "INSURABLE_ASSET_ID")
    private Long insurableAssetRid;
	
    @Column(name = "PARENT_POLICY_AMOUNT")
    private BigDecimal parentPolicyAmount;
    
    @Column(name = "PARENT_COVERAGE_TYPE")
    private String parentCoverageType;
    
    @Column(name = "PARENT_BUILDING_DEDUCTIBLE")
    private BigDecimal parentBuildingDeductible;
    
    @Column(name = "PARENT_CONTENTS_DEDUCTIBLE")
    private BigDecimal parentContentsDeductible;
    
    @Column(name = "CHILD_POLICY_RID")
    private Long childPolicyRid;
    
    @Column(name = "CHILD_POLICY_AMOUNT")
    private BigDecimal childPolicyAmount;
    
    @Column(name = "CHILD_POLICY_TYPE")
    private String childPolicyType;
    
    @Column(name = "CHILD_POLICY_STATUS")
    private String childPolicyStatus;
    
    @Column(name = "COLLATERAL_ID")
    private Long collateralRid;
    
    @Column(name = "ASSET_TYPE")
    private String assetType;
    
    @Column(name = "SORT_ORDER")
    private Integer sortOrder;

	public Long getParentPolicyRid() {
		return parentPolicyRid;
	}

	public void setParentPolicyRid(Long parentPolicyRid) {
		this.parentPolicyRid = parentPolicyRid;
	}

	public BigDecimal getParentPolicyAmount() {
		return parentPolicyAmount;
	}

	public void setParentPolicyAmount(BigDecimal parentPolicyAmount) {
		this.parentPolicyAmount = parentPolicyAmount;
	}

	public String getParentCoverageType() {
		return parentCoverageType;
	}

	public void setParentCoverageType(String parentCoverageType) {
		this.parentCoverageType = parentCoverageType;
	}

	public BigDecimal getParentBuildingDeductible() {
		return parentBuildingDeductible;
	}

	public void setParentBuildingDeductible(BigDecimal parentBuildingDeductible) {
		this.parentBuildingDeductible = parentBuildingDeductible;
	}

	public BigDecimal getParentContentsDeductible() {
		return parentContentsDeductible;
	}

	public void setParentContentsDeductible(BigDecimal parentContentsDeductible) {
		this.parentContentsDeductible = parentContentsDeductible;
	}

	public Long getChildPolicyRid() {
		return childPolicyRid;
	}

	public void setChildPolicyRid(Long childPolicyRid) {
		this.childPolicyRid = childPolicyRid;
	}

	public BigDecimal getChildPolicyAmount() {
		return childPolicyAmount;
	}

	public void setChildPolicyAmount(BigDecimal childPolicyAmount) {
		this.childPolicyAmount = childPolicyAmount;
	}

	public String getChildPolicyType() {
		return childPolicyType;
	}

	public void setChildPolicyType(String childPolicyType) {
		this.childPolicyType = childPolicyType;
	}

	public String getChildPolicyStatus() {
		return childPolicyStatus;
	}

	public void setChildPolicyStatus(String childPolicyStatus) {
		this.childPolicyStatus = childPolicyStatus;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getInsurableAssetRid() {
		return insurableAssetRid;
	}

	public void setInsurableAssetRid(Long insurableAssetRid) {
		this.insurableAssetRid = insurableAssetRid;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public Integer getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

}
