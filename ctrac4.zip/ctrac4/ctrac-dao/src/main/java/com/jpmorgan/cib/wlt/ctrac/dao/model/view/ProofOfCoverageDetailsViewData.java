package com.jpmorgan.cib.wlt.ctrac.dao.model.view;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VLCP_PROOF_OF_COVERAGE_DETAILS")
public class ProofOfCoverageDetailsViewData {
	
	@Id
	@Column(name="PROOF_OF_COVERAGE_RID")
	private Long proofOfCoverageRid;
	
	@Column(name="INSURANCE_TYPE")
	private String insuranceType;
	
	@Column(name="EFFECTIVE_DATE")
	private Date effectiveDate;
	
	@Column(name="EXPIRATION_DATE")
	private Date expirationDate;
	
	@Column(name="CANCELLATION_EFFECTIVE_DATE")
	private Date cancellationEffectiveDate;
	
	@Column(name="POLICY_NUMBER")
	private String policyNumber;
	
	@Column(name="FLOOD_ZONE")
	private String floodZone;
	
	@Column(name="INSURED_NAME")
	private String insuredName;
	
	@Column(name="POLICY_TYPE_CODE")
	private String policyTypeCode;
	
	@Column(name="POLICY_TYPE_DESC")
	private String policyTypeDescription;
	
	@Column(name="COVERAGE_TYPE_CODE")
	private String coverageTypeCode;
	
	@Column(name="COVERAGE_TYPE_DESC")
	private String coverageTypeDescription;
	
	@Column(name="INSURANCE_AGENCY")
	private String insuranceAgency;
	
	@Column(name="BUILDING_DEDUCTIBLE")
	private BigDecimal buildingDeductible;
	
	@Column(name="CONTENTS_DEDUCTIBLE")
	private BigDecimal contentsDeductible;
	
	@Column(name="AGENT_EMAIL_ADDRESS")
	private String agentEmailAddress;
	
	@Column(name="AGENT_PHONE_NUMBER")
	private String agentPhoneNumber;
	
	@Column(name="INV_PAYMENT_METHOD_CODE")
	private String invoicePaymentMethodCode;
	
	@Column(name="INV_PAYMENT_METHOD_DESC")
	private String invoicePaymentMethodDescription;
	
	@Column(name="INV_PAYMENT_ACCOUNT")
	private String invoicePaymentAccount;
	
	@Column(name="INV_PAY_ADDR")
	private String invoicePaymentAddress;
	
	@Column(name="INV_PAY_CITY")
	private String invoicePaymentCity;
	
	@Column(name="INV_PAY_STATE")
	private String invoicePaymentState;
	
	@Column(name="INV_PAY_ZIPCODE")
	private String invoicePaymentZipCode;
	
	@Column(name="INV_PAY_UNIT_BLDG")
	private String invoicePaymentUnitBuilding;
	
	@Column(name="REF_PAYMENT_METHOD_CODE")
	private String refundPaymentMethodCode;
	
	@Column(name="REF_PAYMENT_METHOD_DESC")
	private String refundPaymentMethodDescription;
	
	@Column(name="REFUND_PAYMENT_ACCOUNT")
	private String refundPaymentAccount;
	
	@Column(name="REF_PAY_ADDR")
	private String refundPaymentAddress;
	
	@Column(name="REF_PAY_CITY")
	private String refundPaymentCity;
	
	@Column(name="REF_PAY_STATE")
	private String refundPaymentState;
	
	@Column(name="REF_PAY_ZIPCODE")
	private String refundPaymentZipCode;
	
	@Column(name="REF_PAY_UNIT_BLDG")
	private String refundPaymentUnitBuilding;
	
	@Column(name="POLICY_STATUS")
	private String policyStatus;

	public Long getProofOfCoverageRid() {
		return proofOfCoverageRid;
	}

	public void setProofOfCoverageRid(Long proofOfCoverageRid) {
		this.proofOfCoverageRid = proofOfCoverageRid;
	}

	public String getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Date getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}

	public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getFloodZone() {
		return floodZone;
	}

	public void setFloodZone(String floodZone) {
		this.floodZone = floodZone;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getPolicyTypeCode() {
		return policyTypeCode;
	}

	public void setPolicyTypeCode(String policyTypeCode) {
		this.policyTypeCode = policyTypeCode;
	}

	public String getPolicyTypeDescription() {
		return policyTypeDescription;
	}

	public void setPolicyTypeDescription(String policyTypeDescription) {
		this.policyTypeDescription = policyTypeDescription;
	}

	public String getCoverageTypeCode() {
		return coverageTypeCode;
	}

	public void setCoverageTypeCode(String coverageTypeCode) {
		this.coverageTypeCode = coverageTypeCode;
	}

	public String getCoverageTypeDescription() {
		return coverageTypeDescription;
	}

	public void setCoverageTypeDescription(String coverageTypeDescription) {
		this.coverageTypeDescription = coverageTypeDescription;
	}

	public String getInsuranceAgency() {
		return insuranceAgency;
	}

	public void setInsuranceAgency(String insuranceAgency) {
		this.insuranceAgency = insuranceAgency;
	}

	public BigDecimal getBuildingDeductible() {
		return buildingDeductible;
	}

	public void setBuildingDeductible(BigDecimal buildingDeductible) {
		this.buildingDeductible = buildingDeductible;
	}

	public BigDecimal getContentsDeductible() {
		return contentsDeductible;
	}

	public void setContentsDeductible(BigDecimal contentsDeductible) {
		this.contentsDeductible = contentsDeductible;
	}

	public String getAgentEmailAddress() {
		return agentEmailAddress;
	}

	public void setAgentEmailAddress(String agentEmailAddress) {
		this.agentEmailAddress = agentEmailAddress;
	}

	public String getAgentPhoneNumber() {
		return agentPhoneNumber;
	}

	public void setAgentPhoneNumber(String agentPhoneNumber) {
		this.agentPhoneNumber = agentPhoneNumber;
	}

	public String getInvoicePaymentMethodCode() {
		return invoicePaymentMethodCode;
	}

	public void setInvoicePaymentMethodCode(String invoicePaymentMethodCode) {
		this.invoicePaymentMethodCode = invoicePaymentMethodCode;
	}

	public String getInvoicePaymentMethodDescription() {
		return invoicePaymentMethodDescription;
	}

	public void setInvoicePaymentMethodDescription(
			String invoicePaymentMethodDescription) {
		this.invoicePaymentMethodDescription = invoicePaymentMethodDescription;
	}

	public String getInvoicePaymentAccount() {
		return invoicePaymentAccount;
	}

	public void setInvoicePaymentAccount(String invoicePaymentAccount) {
		this.invoicePaymentAccount = invoicePaymentAccount;
	}

	public String getInvoicePaymentAddress() {
		return invoicePaymentAddress;
	}

	public void setInvoicePaymentAddress(String invoicePaymentAddress) {
		this.invoicePaymentAddress = invoicePaymentAddress;
	}

	public String getInvoicePaymentCity() {
		return invoicePaymentCity;
	}

	public void setInvoicePaymentCity(String invoicePaymentCity) {
		this.invoicePaymentCity = invoicePaymentCity;
	}

	public String getInvoicePaymentState() {
		return invoicePaymentState;
	}

	public void setInvoicePaymentState(String invoicePaymentState) {
		this.invoicePaymentState = invoicePaymentState;
	}

	public String getInvoicePaymentZipCode() {
		return invoicePaymentZipCode;
	}

	public void setInvoicePaymentZipCode(String invoicePaymentZipCode) {
		this.invoicePaymentZipCode = invoicePaymentZipCode;
	}

	public String getInvoicePaymentUnitBuilding() {
		return invoicePaymentUnitBuilding;
	}

	public void setInvoicePaymentUnitBuilding(String invoicePaymentUnitBuilding) {
		this.invoicePaymentUnitBuilding = invoicePaymentUnitBuilding;
	}

	public String getRefundPaymentMethodCode() {
		return refundPaymentMethodCode;
	}

	public void setRefundPaymentMethodCode(String refundPaymentMethodCode) {
		this.refundPaymentMethodCode = refundPaymentMethodCode;
	}

	public String getRefundPaymentMethodDescription() {
		return refundPaymentMethodDescription;
	}

	public void setRefundPaymentMethodDescription(
			String refundPaymentMethodDescription) {
		this.refundPaymentMethodDescription = refundPaymentMethodDescription;
	}

	public String getRefundPaymentAccount() {
		return refundPaymentAccount;
	}

	public void setRefundPaymentAccount(String refundPaymentAccount) {
		this.refundPaymentAccount = refundPaymentAccount;
	}

	public String getRefundPaymentAddress() {
		return refundPaymentAddress;
	}

	public void setRefundPaymentAddress(String refundPaymentAddress) {
		this.refundPaymentAddress = refundPaymentAddress;
	}

	public String getRefundPaymentCity() {
		return refundPaymentCity;
	}

	public void setRefundPaymentCity(String refundPaymentCity) {
		this.refundPaymentCity = refundPaymentCity;
	}

	public String getRefundPaymentState() {
		return refundPaymentState;
	}

	public void setRefundPaymentState(String refundPaymentState) {
		this.refundPaymentState = refundPaymentState;
	}

	public String getRefundPaymentZipCode() {
		return refundPaymentZipCode;
	}

	public void setRefundPaymentZipCode(String refundPaymentZipCode) {
		this.refundPaymentZipCode = refundPaymentZipCode;
	}

	public String getRefundPaymentUnitBuilding() {
		return refundPaymentUnitBuilding;
	}

	public void setRefundPaymentUnitBuilding(String refundPaymentUnitBuilding) {
		this.refundPaymentUnitBuilding = refundPaymentUnitBuilding;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
		
}
