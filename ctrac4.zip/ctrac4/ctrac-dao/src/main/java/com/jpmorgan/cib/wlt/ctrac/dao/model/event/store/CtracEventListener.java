package com.jpmorgan.cib.wlt.ctrac.dao.model.event.store;

import com.jpmorgan.cib.wlt.ctrac.commons.utils.ApplicationContextProvider;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;

public class CtracEventListener {

    @PostPersist
    @PostUpdate
    public void postPersistOrUpdate(final CtracEvent ctracEvent) {
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCompletion(int status) {
                if (TransactionSynchronization.STATUS_COMMITTED == status) {
                    EventStore eventStore = ApplicationContextProvider.getContext().getBean(EventStore.class);
                    eventStore.publish(ctracEvent);
                }
            }
        });
    }
}
