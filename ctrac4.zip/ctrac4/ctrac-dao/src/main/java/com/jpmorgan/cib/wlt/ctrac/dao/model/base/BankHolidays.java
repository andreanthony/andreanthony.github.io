package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * This is a JPA entity class to hold bank holidays. 
 * @date 26-Feb-2014
 */

@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
@Table(name = "TLCP_BANK_HOLIDAYS")
public class BankHolidays extends CtracBaseEntity {
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "bankHolidaySeqGenerator")
	@TableGenerator(name = "bankHolidaySeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BANK_HOLIDAYS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "HOLIDAY_CALENDAR")
	private String holidayCalendar;

	@Column(name = "HOLIDAY_ACTIVE_FLAG")
	private Character holidayActiveFlag ;

	@Column(name = "HOLIDAY_DATE")
	private Date holidayDate;
	
	@Column(name = "HOLIDAY_DESCRIPTION")
	private String holidayDescription;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}
	
	public String getHolidayCalendar() {
		return holidayCalendar;
	}

	public void setHolidayCalendar(String holidayCalendar) {
		this.holidayCalendar = holidayCalendar;
	}

	public Character getHolidayActiveFlag() {
		return holidayActiveFlag;
	}

	public void setHolidayActiveFlag(Character holidayActiveFlag) {
		this.holidayActiveFlag = holidayActiveFlag;
	}
	

	public Date getHolidayDate() {
		return holidayDate;
	}

	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}


	public String getHolidayDescription() {
		return holidayDescription;
	}

	public void setHolidayDescription(String holidayDescription) {
		this.holidayDescription = holidayDescription;
	}
}
