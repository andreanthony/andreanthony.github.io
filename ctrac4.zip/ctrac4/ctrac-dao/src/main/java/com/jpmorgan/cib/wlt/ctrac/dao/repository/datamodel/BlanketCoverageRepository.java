package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity.BlanketCoverage;

public interface BlanketCoverageRepository  extends JpaRepository<BlanketCoverage, Long> {

}
