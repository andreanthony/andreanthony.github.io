package com.jpmorgan.cib.wlt.ctrac.dao.model.businessentity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.jpmorgan.cib.wlt.ctrac.dao.model.base.CtracBaseEntity;

@Entity
@Table(name = "TLCP_AGENT")
public class Agent extends CtracBaseEntity implements Serializable {

	private static final long serialVersionUID = -8682117757986297296L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "agentSeqGenerator")
	@TableGenerator(name = "agentSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_AGENT", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "CONTACT_DETAILS_ID")
	private ContactDetails contactDetails;
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public ContactDetails getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(ContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Agent other = (Agent) obj;
		if (rid == null) {
			if (other.rid != null)
				return false;
		} else if (!rid.equals(other.rid))
			return false;
		return true;
	}
	
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append("***** Customer: <RID: " + rid + ">");
		if(this.getContactDetails()!=null) {
			result.append("<contactDetails (RID): " + contactDetails.getRid() + ">");
		}

		return result.toString();
	}
}
