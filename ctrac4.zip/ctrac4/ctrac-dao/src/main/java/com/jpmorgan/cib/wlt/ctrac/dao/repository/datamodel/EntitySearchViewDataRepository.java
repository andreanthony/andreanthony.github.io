package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import com.jpmorgan.cib.wlt.ctrac.dao.model.view.EntitySearchViewData;

public interface EntitySearchViewDataRepository extends JpaRepository<EntitySearchViewData, Long>, JpaSpecificationExecutor<EntitySearchViewData> {
	@Query(value = "SELECT * from TABLE(LOANS02.GetEntities(?1, ?2,?3, ?4, ?5, ?6, ?7, ?8, ?9))", nativeQuery = true)
	List<EntitySearchViewData> getEntityRecordsLOANS02(String customerId, String name, String address, String city, String state, String zip, 
			String collateralRids, Long excludeCOForCollateralRid, Long excludeLBForLoanRid);
	
	@Query(value = "SELECT * from TABLE(GetEntities(?1, ?2,?3, ?4, ?5, ?6, ?7, ?8, ?9))", nativeQuery = true)
	List<EntitySearchViewData> getEntityRecords(String customerId, String name, String address, String city, String state, String zip, 
			String collateralRids, Long excludeCOForCollateralRid, Long excludeLBForLoanRid);
}
