package com.jpmorgan.cib.wlt.ctrac.dao.model.base;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.springframework.util.StringUtils;

/**
 * This is a JPA entity class to hold reconciliation logs.
 * @date 24-Feb-2014
 */

@Entity
@Table(name = "TLCP_RECON_LOG")
public class ReconciliationLog extends CtracBaseEntity {
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "remapReconLogSeqGenerator")
	@TableGenerator(name = "remapReconLogSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_RECON_LOG", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Column(name = "BATCH_NAME")
	private String batchName;
	
	@Column(name = "FILE_NAME")
	private String fileName ="NA";
	
	@Column(name = "PROCESSED_TIMESTAMP")
	private Date processedTimestamp;

	@Column(name = "INPUT_COUNT")
	private Integer inputCount;
	
	@Column(name = "PROCESSED_COUNT")
	private Integer processedCount;
	
	@Column(name = "REJECTED_COUNT")
	private Integer rejectedCount;
	
	@Column(name ="GLOBAL_EXIT_STATUS")
	private String globalExitStatus;
	
	@Column(name ="EXIT_LOG")
	private String exitLog;
	

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Date getProcessedTimestamp() {
		return processedTimestamp;
	}

	public void setProcessedTimestamp(Date processedTimestamp) {
		this.processedTimestamp = processedTimestamp;
	}

	public Integer getInputCount() {
		return inputCount;
	}

	public void setInputCount(Integer inputCount) {
		this.inputCount = inputCount;
	}

	public Integer getProcessedCount() {
		return processedCount;
	}

	public void setProcessedCount(Integer processedCount) {
		this.processedCount = processedCount;
	}

	public Integer getRejectedCount() {
		return rejectedCount;
	}

	public void setRejectedCount(Integer rejectedCount) {
		this.rejectedCount = rejectedCount;
	}

	public String getGlobalExitStatus() {
		return globalExitStatus;
	}

	public void setGlobalExitStatus(String globalExitStatus) {
		this.globalExitStatus = globalExitStatus;
	}

	public String getExitLog() {
		return exitLog;
	}

	public void setExitLog(String exitLog) {
		this.exitLog = exitLog;
	}
	
	
	//just enabling method chaining as it is more convenient for this object
	public ReconciliationLog batchName(String batchName){
		this.batchName =batchName;
		return this;
	}
	public ReconciliationLog fileName (String fileName){
		
		if(StringUtils.isEmpty(fileName)) this.fileName ="NA";
		else   this.fileName =fileName;
		
		return this;
	}
	public ReconciliationLog processedTimestamp(Date processedTimestamp){
		this.processedTimestamp=processedTimestamp;
		return this;
	}
	public ReconciliationLog inputCount(int inputCount){
		this.inputCount=inputCount;
		return this;
	}
	public ReconciliationLog processedCount(int processedCount){
		this.processedCount =processedCount;
		return this;
	}
	public ReconciliationLog rejectedCount(int rejectedCount){
		this.rejectedCount =rejectedCount;
		return this;
	}	
	public ReconciliationLog globalExitStatus(String globalExitStatus){
		this.globalExitStatus =globalExitStatus;
		return this;
	}
	public ReconciliationLog exitLog(String exitLog){
		
		if(exitLog.length()>2500) {exitLog =exitLog.substring(0,2450);}
		this.exitLog =exitLog;
		
		return this;
	}
}
