package com.jpmorgan.cib.wlt.ctrac.dao.model.audit.search;

public class AuditEntrySearchCriteria {

    private Long collateralId;

    private String minEventTime;

    private String maxEventTime;

    private String collateralSection;

    private String collateralIdLike;

    private String eventTypeLike;

    private String performedByLike;

    private String identifierLike;

    private String lineOfBusinessLike;

    private String collateralSectionLike;

    private String descriptionLike;

    private String taskNameLike;

    private String userFullNameLike;

    private int pageNum;

    private int pageSize;

    private String sortDir;

    private String sortCol;

    public Long getCollateralId() {
        return collateralId;
    }

    public void setCollateralId(Long collateralId) {
        this.collateralId = collateralId;
    }

    public String getCollateralIdLike() {
        return collateralIdLike;
    }

    public void setCollateralIdLike(String collateralIdLike) {
        this.collateralIdLike = collateralIdLike;
    }

    public String getEventTypeLike() {
        return eventTypeLike;
    }

    public void setEventTypeLike(String eventTypeLike) {
        this.eventTypeLike = eventTypeLike;
    }

    public String getMinEventTime() {
        return minEventTime;
    }

    public void setMinEventTime(String minEventTime) {
        this.minEventTime = minEventTime;
    }

    public String getMaxEventTime() {
        return maxEventTime;
    }

    public void setMaxEventTime(String maxEventTime) {
        this.maxEventTime = maxEventTime;
    }

    public String getPerformedByLike() {
        return performedByLike;
    }

    public void setPerformedByLike(String performedByLike) {
        this.performedByLike = performedByLike;
    }

    public String getIdentifierLike() {
        return identifierLike;
    }

    public void setIdentifierLike(String identifierLike) {
        this.identifierLike = identifierLike;
    }

    public String getLineOfBusinessLike() {
        return lineOfBusinessLike;
    }

    public void setLineOfBusinessLike(String lineOfBusinessLike) {
        this.lineOfBusinessLike = lineOfBusinessLike;
    }

    public String getCollateralSection() {
        return collateralSection;
    }

    public void setCollateralSection(String collateralSection) {
        this.collateralSection = collateralSection;
    }

    public String getCollateralSectionLike() {
        return collateralSectionLike;
    }

    public void setCollateralSectionLike(String collateralSectionLike) {
        this.collateralSectionLike = collateralSectionLike;
    }

    public String getDescriptionLike() {
        return descriptionLike;
    }

    public void setDescriptionLike(String descriptionLike) {
        this.descriptionLike = descriptionLike;
    }

    public String getTaskNameLike() {
        return taskNameLike;
    }

    public void setTaskNameLike(String taskNameLike) {
        this.taskNameLike = taskNameLike;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getSortDir() {
        return sortDir;
    }

    public void setSortDir(String sortDir) {
        this.sortDir = sortDir;
    }

    public String getSortCol() {
        return sortCol;
    }

    public void setSortCol(String sortCol) {
        this.sortCol = sortCol;
    }
    public String getUserFullNameLike() {
        return userFullNameLike;
    }

    public void setUserFullNameLike(String userFullNameLike) {
        this.userFullNameLike = userFullNameLike;
    }

}
