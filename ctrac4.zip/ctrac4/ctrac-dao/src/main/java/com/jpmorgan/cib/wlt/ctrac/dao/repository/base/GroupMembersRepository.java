package com.jpmorgan.cib.wlt.ctrac.dao.repository.base;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.entitlements.GroupMembers;


public interface GroupMembersRepository extends JpaRepository<GroupMembers, Long>{
	
}



