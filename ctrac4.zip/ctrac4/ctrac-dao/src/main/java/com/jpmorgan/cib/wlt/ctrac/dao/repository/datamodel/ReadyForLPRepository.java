package com.jpmorgan.cib.wlt.ctrac.dao.repository.datamodel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ReadyForLP;
import com.jpmorgan.cib.wlt.ctrac.dao.model.workflow.ReadyForLPPk;

public interface ReadyForLPRepository extends JpaRepository<ReadyForLP, ReadyForLPPk> {

	List<ReadyForLP> findByReadyForLPPkCollateralRidAndReady(Long collateralId, Integer ready);

    List<ReadyForLP> findByReadyForLPPkProofOfCoverageRid(Long proofOfCoverageRid);

    List<ReadyForLP> findByReadyInAndReadyForLPPkProofOfCoveragePolicyStatusNotIn(List<Integer> ready, List<String> policyStatuses);
}
