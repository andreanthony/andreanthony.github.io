package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Loan;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;

public class TestLoanStatusRule {

    private LoanStatusRule testObj;

    @Before
    public void setUp() {
        testObj = new LoanStatusRule();
    }

    @Test
    public void testOneActive() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO();
        addLoan(LoanStatus.ACTIVE, c3RequestDTO);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertNoCancellations(c3ResponseDTO);
    }

    @Test
    public void testOnePendingVerification() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        addLoan(LoanStatus.PENDING_VERIFICATION, c3RequestDTO);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertNoCancellations(c3ResponseDTO);
    }

    @Test
    public void testOneActiveOnePaidOff() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO();
        addLoan(LoanStatus.ACTIVE, c3RequestDTO);
        addLoan(LoanStatus.RELEASED, "09/07/2018", c3RequestDTO);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertNoCancellations(c3ResponseDTO);
    }

    @Test
    public void testOnePaidOff() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO();
        addLoan(LoanStatus.RELEASED, "09/07/2018", c3RequestDTO);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertCancellation(c3ResponseDTO, "09/07/2018");
    }

    @Test
    public void testMultiplePaidOff() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO();
        addLoan(LoanStatus.RELEASED, "09/07/2018", c3RequestDTO);
        addLoan(LoanStatus.RELEASED, "09/10/2018", c3RequestDTO);
        addLoan(LoanStatus.RELEASED, "09/05/2018", c3RequestDTO);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertCancellation(c3ResponseDTO, "09/10/2018");
    }

    private C3RequestDTO mockC3RequestDTO() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy c3Policy = C3RuleTestUtil.mockGeneralPolicy(1L, PolicyType.GI_LP, PolicyStatus.PAID, "cov");
        c3RequestDTO.getLpPolicies().add(c3Policy);
        return c3RequestDTO;
    }

    private void addLoan(LoanStatus loanStatus, C3RequestDTO c3RequestDTO) {
        addLoan(loanStatus, null, c3RequestDTO);
    }

    private void addLoan(LoanStatus loanStatus, String releasedDate, C3RequestDTO c3RequestDTO) {
        C3Loan loan = new C3Loan();
        loan.setStatus(loanStatus.name());
        loan.setReleasedDate(releasedDate);
        c3RequestDTO.getLoans().add(loan);
    }

    private void assertNoCancellations(C3ResponseDTO c3ResponseDTO) {
        assertThat(c3ResponseDTO.getPoliciesToCancel(), is(empty()));
        assertThat(c3ResponseDTO.isComplete(), is(false));
    }

    private void assertCancellation(C3ResponseDTO c3ResponseDTO, String cancellationEffectiveDate) {
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getPolicyId(), is(1L));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getCancellationEffectiveDate(), is(cancellationEffectiveDate));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getCancellationReason(), is(CancellationReason.LOAN_PAID_OFF));
        assertThat(c3ResponseDTO.isComplete(), is(true));
    }
}
