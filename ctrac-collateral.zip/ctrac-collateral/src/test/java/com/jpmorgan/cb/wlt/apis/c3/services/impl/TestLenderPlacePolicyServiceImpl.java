package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3AlertEmailBuilder;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.policy.dao.*;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository.GeneralCoverageRepository;
import com.jpmorgan.cb.wlt.rules.CtracJUnitTestRule;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.enums.C3AlertEmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AlertEmailEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3WorkflowRequestEventDTO;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestLenderPlacePolicyServiceImpl {

    private static Long INSURABLE_ASSET_ID = 1L;

    @Mock
    private ProofOfCoverageRepository proofOfCoverageRepository;
    @Mock
    private InsurableAssetRepository insurableAssetRepository;
    @Mock
    private GeneralCoverageRepository generalCoverageRepository;
    @Mock
    private ReferenceDateService referenceDateService;

    @Mock
    private PublishEventService publishEventService;
    private Date refDate = new Date();

    @Spy
    @InjectMocks
    private LenderPlacePolicyServiceImpl testObj;
    private ProofOfCoverage generalInsurance = new GeneralInsurance();
    private ProofOfCoverage floodInsurance = new FloodInsurance();
    private C3PolicyCancellation policyCancellation = new C3PolicyCancellation();

    @ClassRule
    public static CtracJUnitTestRule CTRAC_JUNIT_TEST_RULE = new CtracJUnitTestRule();

    @Before
    public void setUp() {
        doReturn(refDate).when(referenceDateService).getCurrentReferenceDate();
        CTRAC_JUNIT_TEST_RULE.addBeanToContext(InsurableAssetRepository.class, insurableAssetRepository);
        CTRAC_JUNIT_TEST_RULE.addBeanToContext(GeneralCoverageRepository.class, generalCoverageRepository);
        populateProofOfCoverage(generalInsurance, "GI_LP");
        populateProofOfCoverage(floodInsurance, "LP");
        policyCancellation.setPolicyId(1L);
        policyCancellation.setCancellationEffectiveDate("01/01/2018");
        policyCancellation.setCancellationReason(CancellationReason.INSURANCE_NOT_NEEDED);
        doReturn(floodInsurance).when(proofOfCoverageRepository).save(any(FloodInsurance.class));
    }

    private void populateProofOfCoverage(ProofOfCoverage generalInsurance, String policyType) {
        generalInsurance.setRid(5L);
        generalInsurance.setPolicyType(policyType);
        generalInsurance.setEffectiveDate(refDate);
        generalInsurance.setPolicyStatus("PAID");
        ProvidedCoverage providedCoverage = new ProvidedCoverage();
        providedCoverage.setCollateralId(1L);
        generalInsurance.addProvidedCoverage(providedCoverage);
    }

    @Test
    public void createFlood() {
        doReturn(Optional.of(new InsurableAsset())).when(insurableAssetRepository).findById(INSURABLE_ASSET_ID);
        C3PolicyIssuance policyIssuance = new C3PolicyIssuance();
        policyIssuance.setPolicyType(PolicyType.LP);
        policyIssuance.setCoverageType("PRIMARY");
        policyIssuance.setInsurableAssetId(INSURABLE_ASSET_ID);
        ProofOfCoverage result = testObj.create(policyIssuance);
        assertEquals("FLOOD", result.getInsuranceType());
    }

    @Test
    public void createGeneral() {
        doReturn(generalInsurance).when(proofOfCoverageRepository).save(any(GeneralInsurance.class));
        C3PolicyIssuance policyIssuance = new C3PolicyIssuance();
        policyIssuance.setPolicyType(PolicyType.GI_LP);
        policyIssuance.setCoverageType("test");
        ProofOfCoverage result = testObj.create(policyIssuance);
        assertEquals("GENERAL", result.getInsuranceType());
        assertEquals("Policy number", "5", generalInsurance.getPolicyNumber());
    }

    @Test
    public void testIssuePolicies() {
        List<C3PolicyIssuance> policyIssuances = new ArrayList<>();
        C3PolicyIssuance c3PolicyIssuance = new C3PolicyIssuance();
        c3PolicyIssuance.setPolicyType(PolicyType.GI_POLICY);
        policyIssuances.add(c3PolicyIssuance);
        doReturn(generalInsurance).when(testObj).create(c3PolicyIssuance);
        List<Long> policyIssuanceRids = testObj.issuePolicies(policyIssuances);
        verify(testObj).create(c3PolicyIssuance);
        assertEquals(1, policyIssuanceRids.size());
        assertEquals(generalInsurance.getRid(), policyIssuanceRids.get(0));
    }

    @Test
    public void testCancelPolicies() {
        List<C3PolicyCancellation> policyCancellations = new ArrayList<>();
        C3PolicyCancellation c3PolicyCancellation = new C3PolicyCancellation();
        Long proofOfCoverageRid = 2L;
        c3PolicyCancellation.setPolicyId(proofOfCoverageRid);
        policyCancellations.add(c3PolicyCancellation);
        ProofOfCoverage proofOfCoverage = new GeneralInsurance();
        proofOfCoverage.setRid(1L);
        doReturn(proofOfCoverage).when(testObj).cancel(c3PolicyCancellation);
        List<Long> policyCancellationRids = testObj.cancelPolicies(policyCancellations);
        verify(testObj).cancel(c3PolicyCancellation);
        assertEquals(1, policyCancellationRids.size());
        assertEquals(proofOfCoverageRid, policyCancellationRids.get(0));
    }

    @Test
    public void cancelGeneralNotFlatCancelled() {
        doReturn(generalInsurance).when(proofOfCoverageRepository).save(any(GeneralInsurance.class));
        doReturn(Optional.of(generalInsurance)).when(proofOfCoverageRepository).findById(any(Long.class));
        doNothing().when(testObj).publishLPPolicyEvent(eq(generalInsurance), any(CtracEventType.class));
        testObj.cancel(policyCancellation);
        verify(testObj).processCancellation(generalInsurance, policyCancellation);
    }

    @Test
    public void cancelPolicy() {
        String expDate = "02/02/2018";
        String cancDate = "03/03/3018";
        testCancellationResult(true, null, null);
        testCancellationResult(false, expDate, null);
        testCancellationResult(false, null, cancDate);
    }

    private void testCancellationResult(boolean isDeleted, String updatedExpDate, String cancelDate) {

        policyCancellation = new C3PolicyCancellation();
        policyCancellation.setDeleted(isDeleted);
        policyCancellation.setUpdatedExpirationDate(updatedExpDate);
        policyCancellation.setCancellationEffectiveDate(cancelDate);
        policyCancellation.setCancellationReason(CancellationReason.BORROWER_POLICY_RECEIVED);
        ProofOfCoverage generalInsurance = new GeneralInsurance();
        generalInsurance.setPolicyType("GI_LP");
        generalInsurance.setPolicyStatus("PAID");
        testObj.processCancellation(generalInsurance, policyCancellation);

        assertEquals("isDeleted", isDeleted, PolicyStatus.DELETED == generalInsurance.getPolicyStatus_());
        if(isDeleted) {
            assertEquals("cancelDate", generalInsurance.getEffectiveDate(), generalInsurance.getCancellationEffectiveDate());
            assertNull("targetDate", generalInsurance.getLpTargetDate());
            assertEquals("lpAction", "NO_ACTION", generalInsurance.getLpAction());
        }
        if(updatedExpDate != null) {
            assertNull("cancelDate", generalInsurance.getCancellationEffectiveDate());
            assertEquals("expirationDate", policyCancellation.getUpdatedExpirationDate_(), generalInsurance.getExpirationDate());
            assertEquals("policyType", "GI_LP_GAP", generalInsurance.getPolicyType());
            assertEquals("inRenewal", "Y", generalInsurance.getIndRenewal());
        }
        if (cancelDate != null) {
            assertEquals("cancelDate", policyCancellation.getCancellationEffectiveDate_(), generalInsurance.getCancellationEffectiveDate());
            assertEquals("CANCEL_LP", generalInsurance.getLpAction());
            assertEquals("targetDate", refDate, generalInsurance.getCancellationTargetDate());
            assertEquals("reason", policyCancellation.getCancellationReason().name(), generalInsurance.getCancellationReason());
            assertEquals("status", PolicyStatus.CANCELLED.name(), generalInsurance.getPolicyStatus());
        }
    }

   @Test
    public void applyC3Response() {
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.applyC3Response(c3ResponseDTO);
        verify(testObj).issuePolicies(c3ResponseDTO.getPoliciesToIssue());
        verify(testObj).cancelPolicies(c3ResponseDTO.getPoliciesToCancel());
    }

    @Test
    public void publishC3WorkflowEvent() {
        ArrayList<Long> proofOfCoverageIds = new ArrayList<>();
        ArgumentCaptor<C3WorkflowRequestEventDTO> argument = ArgumentCaptor.forClass(C3WorkflowRequestEventDTO.class);
        Long collateralRid = 333L;
        testObj.publishC3WorkflowEvent(proofOfCoverageIds, collateralRid, CtracEventType.C3_COMPLETED);
        verify(publishEventService).publishEvent(argument.capture());
        C3WorkflowRequestEventDTO eventDTO = argument.getValue();
        assertEquals("C3 Completed", eventDTO.getEventType());
        assertEquals(proofOfCoverageIds, eventDTO.getProofOfCoverageRids());
        assertEquals("SYSTEM", eventDTO.getPerformedBy());
        assertEquals(collateralRid, eventDTO.getCollateralRid());
    }

    @Test
    public void publishAlertEmailEvent_INACTIVE_LP_POLICY() {
        C3CalculatedCoverageDate calculatedCoverageDate =  new C3CalculatedCoverageDate();
        calculatedCoverageDate.setCoverageDate(new Date());
        C3AlertEmail alertEmail =  new C3AlertEmailBuilder(C3AlertEmailTemplate.INACTIVE_LP_POLICY)
                .calculatedCoverageDate(calculatedCoverageDate).lpPolicyId(12345L).collateralRid(98765L).build();
        ArgumentCaptor<AlertEmailEventDTO> argument = ArgumentCaptor.forClass(AlertEmailEventDTO.class);
        testObj.publishAlertEmailEvent(alertEmail);
        verify(publishEventService).publishEvent(argument.capture());
        AlertEmailEventDTO eventDTO = argument.getValue();
        assertEquals("Send Alert Email", eventDTO.getEventType());
        assertEquals("Alert: 98765 - Policy Received Effective During Inactive LP Period", eventDTO.getSubject());
        assertEquals("Alert: Collateral ID: 98765 and LP Policy RID: 12345 - A borrower policy has been received where the effective date falls before the coverage " +
                "end date of an inactive LP policy. CTRAC is not taking any actions on the inactive policies. " +
                "Please review the inactive LP policies and determine if any actions are required including " +
                "cancellations or new issues.", eventDTO.getEmailBody());
        assertEquals("High", eventDTO.getImportance());
        assertEquals("SYSTEM", eventDTO.getPerformedBy());
    }

    @Test
    public void publishAlertEmailEvent_SUBSEQUENT_LP_POLICY() {
        C3CalculatedCoverageDate calculatedCoverageDate =  new C3CalculatedCoverageDate();
        calculatedCoverageDate.setCoverageDate(new Date());
        C3AlertEmail alertEmail =  new C3AlertEmailBuilder(C3AlertEmailTemplate.SUBSEQUENT_LP_POLICY)
                .calculatedCoverageDate(calculatedCoverageDate).lpPolicyId(12345L).collateralRid(98765L).build();
        ArgumentCaptor<AlertEmailEventDTO> argument = ArgumentCaptor.forClass(AlertEmailEventDTO.class);
        testObj.publishAlertEmailEvent(alertEmail);
        verify(publishEventService).publishEvent(argument.capture());
        AlertEmailEventDTO eventDTO = argument.getValue();
        assertEquals("Send Alert Email", eventDTO.getEventType());
        assertEquals("Effective date calculation - Recheck needed", eventDTO.getSubject());
        assertEquals("Collateral ID: 98765", eventDTO.getEmailBody());
        assertEquals("High", eventDTO.getImportance());
        assertEquals("SYSTEM", eventDTO.getPerformedBy());
    }

    @Test
    public void publishAlertEmailEvent_MULTIPLE_EXCESS_POLICIES() {
        C3CalculatedCoverageDate calculatedCoverageDate =  new C3CalculatedCoverageDate();
        calculatedCoverageDate.setCoverageDate(new Date());
        C3AlertEmail alertEmail =  new C3AlertEmailBuilder(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES)
                .calculatedCoverageDate(calculatedCoverageDate).lpPolicyId(12345L).collateralRid(98765L).build();
        ArgumentCaptor<AlertEmailEventDTO> argument = ArgumentCaptor.forClass(AlertEmailEventDTO.class);
        testObj.publishAlertEmailEvent(alertEmail);
        verify(publishEventService).publishEvent(argument.capture());
        AlertEmailEventDTO eventDTO = argument.getValue();
        assertEquals("Send Alert Email", eventDTO.getEventType());
        assertEquals("Alert: 98765 - Multiple Excess Policies - Update collateral record", eventDTO.getSubject());
        assertEquals("Alert: 98765 - Multiple Excess Policies - Update collateral record", eventDTO.getEmailBody());
        assertEquals("High", eventDTO.getImportance());
        assertEquals("SYSTEM", eventDTO.getPerformedBy());
    }


}