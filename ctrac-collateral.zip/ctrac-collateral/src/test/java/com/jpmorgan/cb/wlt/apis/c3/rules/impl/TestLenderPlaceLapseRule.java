package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3PolicyIssuanceBuilder;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil;
import com.jpmorgan.cb.wlt.apis.c3.services.impl.C3PolicyBuilder;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.joda.time.DateTime;
import org.junit.Test;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;

import static org.junit.Assert.*;

public class TestLenderPlaceLapseRule {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    LenderPlaceLapseRule testObj = new LenderPlaceLapseRule();

    @Test
    public void executeDuplicate() {
        testExecute(10000, "PRIMARY", "01/01/2018", 10000, "PRIMARY", "01/01/2018", "FLOOD", 1, "01/01/2019", null);
    }

    @Test
    public void executeDuplicateGeneral() {
        testExecute(10000, "cov", "01/01/2018", 10000, "cov", "01/01/2018", "GENERAL", 1, "01/01/2019", null);
    }

    @Test
    public void executeDifCoverages() {
        testExecute(10000, "PRIMARY", "01/01/2018", 10000, "EXCESS", "01/01/2018", "FLOOD", 2, "01/01/2019", "01/01/2019");
    }

    @Test
    public void executeDifCoveragesGeneral() {
        testExecute(10000, "cov", "01/01/2018", 10000, "cov1", "01/01/2018", "GENERAL", 2, "01/01/2019", "01/01/2019");
    }

    @Test
    public void executeSameAmountDiffDates() {
        testExecute(10000, "PRIMARY", "02/01/2018", 10000, "PRIMARY", "01/01/2018", "FLOOD", 1, "01/01/2019", null);
    }

    @Test
    public void executeSameAmountDiffDatesGeneral() {
        testExecute(10000, "PRIMARY", "02/01/2018", 10000, "PRIMARY", "01/01/2018", "GENERAL", 1, "01/01/2019", null);
    }

    @Test
    public void executeDiffAmountDiffDates() {
        testExecute(10000, "PRIMARY", "02/01/2018", 20000, "PRIMARY", "01/01/2018", "FLOOD", 2, "02/01/2019", "02/01/2018");
    }

    @Test
    public void executeDiffAmountDiffDatesGeneral() {
        testExecute(10000, "cov", "02/01/2018", 20000, "cov", "01/01/2018", "GENERAL", 2, "02/01/2019", "02/01/2018");
    }

    @Test
    public void multipleGapPolicies() {
        C3Policy policy = C3RuleTestUtil.mockGeneralPolicy(100L, PolicyType.GI_POLICY, PolicyStatus.ACCEPTED, "");
        policy.getProvidedCoverages().add(C3RuleTestUtil.mockGeneralProvidedCoverage("cov1", "10000"));
        policy.getProvidedCoverages().add(C3RuleTestUtil.mockGeneralProvidedCoverage("cov2", "10000"));
        policy.getProvidedCoverages().add(C3RuleTestUtil.mockGeneralProvidedCoverage("cov2", "10000"));

        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.addRequiredCoverages(Arrays.asList(
                C3RuleTestUtil.mockGeneralRequiredCoverage("cov1", "2000"),
                C3RuleTestUtil.mockGeneralRequiredCoverage("cov2", "3000"),
                C3RuleTestUtil.mockGeneralRequiredCoverage("cov3", "4000")));

        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        addPolicyToIssue(1000, "cov1", "01/01/2018", "GENERAL", c3ResponseDTO);
        addPolicyToIssue(2000, "cov2", "01/01/2018", "GENERAL", c3ResponseDTO);
        addPolicyToIssue(3000, "cov3", "01/01/2018", "GENERAL", c3ResponseDTO);

        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(3, c3ResponseDTO.getPoliciesToIssue().size());
    }

    @Test
    public void multipleGapAnLapsePolicies() {
        C3Policy policy = C3RuleTestUtil.mockGeneralPolicy(100L, PolicyType.GI_POLICY, PolicyStatus.ACCEPTED, "");
        policy.getProvidedCoverages().add(C3RuleTestUtil.mockGeneralProvidedCoverage("cov1", "10000"));
        policy.getProvidedCoverages().add(C3RuleTestUtil.mockGeneralProvidedCoverage("cov2", "10000"));
        policy.getProvidedCoverages().add(C3RuleTestUtil.mockGeneralProvidedCoverage("cov2", "10000"));

        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.addRequiredCoverages(Arrays.asList(
                C3RuleTestUtil.mockGeneralRequiredCoverage("cov1", "2000"),
                C3RuleTestUtil.mockGeneralRequiredCoverage("cov2", "3000"),
                C3RuleTestUtil.mockGeneralRequiredCoverage("cov3", "4000")));

        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        addPolicyToIssue(1000, "cov1", "12/01/2017", "GENERAL", c3ResponseDTO);
        addPolicyToIssue(2000, "cov2", "12/01/2017", "GENERAL", c3ResponseDTO);
        addPolicyToIssue(3000, "cov3", "12/01/2017", "GENERAL", c3ResponseDTO);
        assertEquals(PolicyType.GI_LP, c3ResponseDTO.getPoliciesToIssue().get(0).getPolicyType());

        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(3, c3ResponseDTO.getPoliciesToIssue().size());
        assertEquals(PolicyType.GI_LP_GAP, c3ResponseDTO.getPoliciesToIssue().get(0).getPolicyType());
        assertEquals(LenderPlaceReason.GENERAL_INSURANCE_LAPSE, c3ResponseDTO.getPoliciesToIssue().get(0).getLenderPlaceReason());
    }

    @Test
    public void multiplePolicies() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();

        addPolicyToIssue(1000, "PRIMARY", "01/01/2018", "FLOOD", c3ResponseDTO);
        addPolicyToIssue(2000, "PRIMARY", "01/15/2018", "FLOOD", c3ResponseDTO);
        addPolicyToIssue(3000, "PRIMARY", "02/01/2018", "FLOOD", c3ResponseDTO);
        addPolicyToIssue(4000, "PRIMARY", "03/01/2018", "FLOOD", c3ResponseDTO);
        addPolicyToIssue(5000, "PRIMARY", "04/01/2018", "FLOOD", c3ResponseDTO);

        testObj.execute(c3RequestDTO, c3ResponseDTO);

        assertEquals("policiesToIssue", 5, c3ResponseDTO.getPoliciesToIssue().size());
        for (C3PolicyIssuance c3PolicyIssuance : c3ResponseDTO.getPoliciesToIssue()) {
            if (c3PolicyIssuance.getCoverageAmount().equals(1000)) {
                assertEquals("expectedExpDate", "01/15/2018", c3PolicyIssuance.getExpirationDate());
                assertEquals("policyType", "LP_GAP", c3PolicyIssuance.getPolicyType().name());
            }
            if (c3PolicyIssuance.getCoverageAmount().equals(2000)) {
                assertEquals("expectedExpDate", 02/01/2018, c3PolicyIssuance.getExpirationDate());
                assertEquals("policyType", "LP_GAP", c3PolicyIssuance.getPolicyType().name());
           }
            if (c3PolicyIssuance.getCoverageAmount().equals(3000)) {
                assertEquals("expectedExpDate", "03/01/2018", c3PolicyIssuance.getExpirationDate());
                assertEquals("policyType", "LP_GAP", c3PolicyIssuance.getPolicyType().name());
            }
            if (c3PolicyIssuance.getCoverageAmount().equals(4000)) {
                assertEquals("expectedExpDate", 04/01/2018, c3PolicyIssuance.getExpirationDate());
                assertEquals("policyType", "LP_GAP", c3PolicyIssuance.getPolicyType().name());
            }
            if (c3PolicyIssuance.getCoverageAmount().equals(5000)) {
                assertEquals("expectedExpDate", 04/01/2019, c3PolicyIssuance.getExpirationDate());
                assertEquals("policyType", "LP", c3PolicyIssuance.getPolicyType().name());
            }
        }
    }

    private void testExecute(int amountToIssue, String coverageToIssue, String dateToIssue,
                             int amountToIssue1, String coverageToIssue1, String dateToIssue1, String insuranceType,
                             int expectedPoliciesToIssue, String expectedExpDate, String expectedExpDate1) {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();

        addPolicyToIssue(amountToIssue, coverageToIssue, dateToIssue, insuranceType, c3ResponseDTO);
        addPolicyToIssue(amountToIssue1, coverageToIssue1, dateToIssue1, insuranceType, c3ResponseDTO);

        testObj.execute(c3RequestDTO, c3ResponseDTO);

        assertEquals("policiesToIssue", expectedPoliciesToIssue, c3ResponseDTO.getPoliciesToIssue().size());
        for (C3PolicyIssuance c3PolicyIssuance : c3ResponseDTO.getPoliciesToIssue()) {
            if (c3PolicyIssuance.getCoverageAmount().equals(amountToIssue)) {
                assertEquals("expectedExpDate", expectedExpDate, c3PolicyIssuance.getExpirationDate());
            }
            if (c3PolicyIssuance.getCoverageAmount().equals(amountToIssue1)) {
                assertEquals("expectedExpDate", expectedExpDate1, c3PolicyIssuance.getExpirationDate());
            }
        }
    }

    private void addPolicyToIssue(int amountToIssue, String coverageToIssue, String dateToIssue, String insuranceType, C3ResponseDTO c3ResponseDTO) {
        if (amountToIssue > 0) {
            C3PolicyIssuance c3PolicyIssuance = mockC3PolicyIssuance(amountToIssue, coverageToIssue, dateToIssue, insuranceType,
                    insuranceType.equals("FLOOD") ? coverageToIssue.equals("PRIMARY") ? PolicyType.LP : PolicyType.LP_EXCESS : PolicyType.GI_LP);
            c3ResponseDTO.getPoliciesToIssue().add(c3PolicyIssuance);
        }
    }

    private C3PolicyIssuance mockC3PolicyIssuance(int amountToIssue, String coverageToIssue, String dateToIssue, String insuranceType, PolicyType policyType) {
        C3PolicyIssuance c3PolicyIssuance = new C3PolicyIssuance();
        c3PolicyIssuance.setCoverageAmount(new BigDecimal(amountToIssue));
        c3PolicyIssuance.setEffectiveDate(dateToIssue);
        DateTime effDate = new DateTime(DATE_FORMATTER.parse(dateToIssue)).withTimeAtStartOfDay();
        c3PolicyIssuance.setExpirationDate(DATE_FORMATTER.print(effDate.plusYears(1).toDate()));
        c3PolicyIssuance.setCoverageType(coverageToIssue);
        boolean isFlood = insuranceType.equals("FLOOD");
        c3PolicyIssuance.setInsurableAssetId(isFlood ? 2L: null);
        c3PolicyIssuance.setPolicyType(policyType);
        c3PolicyIssuance.setLenderPlaceReason(policyType.isGapPolicy() ?
                (isFlood ? LenderPlaceReason.BORROWER_POLICY_RECEIVED_AMOUNT_GAP: LenderPlaceReason.GENERAL_INSURANCE_GAP) : null);
        return c3PolicyIssuance;
    }

    @Test
    public void convertToLapsePolicy() {
        testLapse(PolicyType.LP_GAP,"PRIMARY", "FLOOD", true, false, false,false);
        testLapse(PolicyType.LP,"PRIMARY", "FLOOD", true, false, false,true);
        testLapse(PolicyType.LP,"PRIMARY", "FLOOD", false, true, false,true);
        testLapse(PolicyType.LP,"PRIMARY", "FLOOD", false, false, true,true);
        testLapse(PolicyType.LP,"PRIMARY", "FLOOD", false, false, false,false);
    }

    @Test
    public void convertToLapsePolicyExcess() {
        testLapse(PolicyType.LP_EXCESS,"EXCESS", "FLOOD", true, false, false,false);
        testLapse(PolicyType.LP_EXCESS,"EXCESS", "FLOOD", false, true, false,false);
        testLapse(PolicyType.LP_EXCESS,"EXCESS", "FLOOD", false, false, true,false);
        testLapse(PolicyType.LP_EXCESS,"EXCESS", "FLOOD", false, false, false,false);
    }

    @Test
    public void convertToLapsePolicyGeneral() {
        testLapse(PolicyType.GI_LP,"cov", "GENERAL", true, false, false,true);
        testLapse(PolicyType.GI_LP,"cov", "GENERAL", false, true, false,true);
        testLapse(PolicyType.GI_LP,"cov", "GENERAL", false, false, true,true);
        testLapse(PolicyType.GI_LP_GAP,"cov", "GENERAL", true, false, false,false);
    }

    private void testLapse(PolicyType policyType, String coverageToIssue, String insuranceType,
                           boolean borrowerAccepted, boolean borrowerExpired, boolean borrowerCancelled, boolean expectedLapse) {
        String date = "02/01/2018";
        C3PolicyIssuance lapsePolicy = mockC3PolicyIssuance(
                1000, coverageToIssue, "01/01/2018", insuranceType, policyType);
        Long policyId = 100L;
        C3Policy policy = null;
        boolean isFlood = insuranceType.equals("FLOOD");
        if (borrowerAccepted || borrowerCancelled || borrowerExpired) {
            if (isFlood) {
                policy = C3RuleTestUtil.mockPolicy(policyId, PolicyType.ACCORD, PolicyStatus.ACCEPTED, InsuranceType.FLOOD);
                policy.getProvidedCoverages().add(C3RuleTestUtil.mockProvidedCoverage(2L, coverageToIssue));
            } else {
                policy = C3RuleTestUtil.mockGeneralPolicy(policyId, PolicyType.ACCORD, PolicyStatus.ACCEPTED, coverageToIssue);
            }
            policy.setEffectiveDate(borrowerAccepted ? date : null);
            policy.setExpirationDate(borrowerExpired ? date : null);
            policy.setCancellationEffectiveDate(borrowerCancelled ? date : null);
        }

        testObj.convertToLapsePolicy(lapsePolicy, date, policy);

        if ("EXCESS".equals(coverageToIssue)) {
            assertTrue(lapsePolicy.getPolicyType().isLpExcessCoverageOnly());
            assertEquals("Y", lapsePolicy.getIndRenewal());
        }
        else {
            PolicyType expectedPolicyType = isFlood? PolicyType.LP_GAP: PolicyType.GI_LP_GAP;
            assertEquals(expectedPolicyType, lapsePolicy.getPolicyType());
            if (expectedLapse) {
                LenderPlaceReason expectedLapseReason = isFlood?
                        LenderPlaceReason.BORROWER_POLICY_RECEIVED_DATE_LAPSE: LenderPlaceReason.GENERAL_INSURANCE_LAPSE;
                assertEquals("Y", lapsePolicy.getIndRenewal());
                assertEquals(expectedLapseReason, lapsePolicy.getLenderPlaceReason());
                assertEquals(policyId, lapsePolicy.getGapBorrowerPolicyId());
            }
            else {
                LenderPlaceReason expectedGapReason = isFlood?
                        LenderPlaceReason.BORROWER_POLICY_RECEIVED_AMOUNT_GAP: LenderPlaceReason.GENERAL_INSURANCE_GAP;
                assertEquals(expectedGapReason, lapsePolicy.getLenderPlaceReason());
            }
        }
    }

    @Test
    public void testEvaluateBorrowerPoliciesCausingLapseWithLapseA() throws Exception{
        borrowerPolicyCausingLapse("02/01/2018", "03/01/2018", "08/15/2018", "Borrower policy active during lp policy to issue.", true);
        borrowerPolicyCausingLapse("02/01/2018", "03/01/2018", "08/15/2019", "Borrower policy active during and after lp policy to issue expires.", true);
        borrowerPolicyCausingLapse("02/01/2018", "01/01/2018", "08/15/2018", "Borrower policy active before lp policy to issue.", false);
        borrowerPolicyCausingLapse("02/01/2018", "01/01/2017", "01/01/2018", "Borrower policy expires before lp policy to issue.", false);
    }

    private void borrowerPolicyCausingLapse(String lpIssuanceDateString, String borrowerPolicyEffectiveDate, String borrowerPolicyExpirationDate, String message, boolean lapse) throws ParseException {
        final String coverageType = "Avalanche";
        final BigDecimal coverageAmount = new BigDecimal("100000");
        Date lpIssuanceDate = DATE_FORMATTER.parse(lpIssuanceDateString);

        C3Policy borrowerPolicy = new C3PolicyBuilder(InsuranceType.GENERAL, 1001L,
                    PolicyType.GI_POLICY, PolicyStatus.ACCEPTED, borrowerPolicyEffectiveDate, borrowerPolicyExpirationDate)
                .providedGeneralCoverage(coverageType, coverageAmount)
                .build();
        C3PolicyIssuance policyToIssue = C3PolicyIssuanceBuilder.buildC3PolicyIssuance(coverageType, PolicyType.GI_LP, coverageAmount, lpIssuanceDate);

        if (lapse) {
            assertEquals(message, borrowerPolicy, testObj.getBorrowerPolicyLeadingToLapse(policyToIssue, Arrays.asList(borrowerPolicy)));
        }
        else {
            assertNull(message, testObj.getBorrowerPolicyLeadingToLapse(policyToIssue, Arrays.asList(borrowerPolicy)));
        }
    }

    @Test
    public void testHoldStartDateCausingLapse() throws Exception{
        processLapseForHold("02/01/2018", null, "no hold during lp policy to issue.", false);
        processLapseForHold("02/01/2018", "03/01/2018", "holdStartDate during lp policy to issue.", true);
        processLapseForHold("02/01/2018", "03/01/2019", "holdStartDate after lp policy to issue expires.", false);
        processLapseForHold("02/01/2018", "01/01/2018", "holdStartDate before lp policy to issue.", false);
        processLapseForHold("02/01/2018", "02/01/2018", "holdStartDate on lp policy to issue eff date.", true);
    }

    private void processLapseForHold(String lpIssuanceDateString, String holdStartDate, String message, boolean lapse) throws ParseException {
        final String coverageType = "PRIMARY";
        final BigDecimal coverageAmount = new BigDecimal("100000");
        Date lpIssuanceDate = DATE_FORMATTER.parse(lpIssuanceDateString);

        C3PolicyIssuance policyToIssue = C3PolicyIssuanceBuilder.buildC3PolicyIssuance(
                coverageType, PolicyType.LP, coverageAmount, lpIssuanceDate);

        testObj.processLapseForHoldStartDate(policyToIssue, DATE_FORMATTER.parse(holdStartDate));

        if (lapse) {
            assertEquals(message, PolicyType.LP_GAP, policyToIssue.getPolicyType());
            assertEquals(message, holdStartDate, policyToIssue.getExpirationDate());
        }
        else {
            assertEquals(message, PolicyType.LP, policyToIssue.getPolicyType());
            assertEquals(message, lpIssuanceDateString, policyToIssue.getEffectiveDate());
        }
    }

    @Test
    public void executeOnHoldStartDate() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3RequiredCoverage requiredCoverage = C3RuleTestUtil.mockRequiredCoverage(InsuranceType.FLOOD, 2L, FloodCoverageType.PRIMARY);
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        String date = "01/01/2019";
        requiredCoverage.setDocumentDate(date);
        requiredCoverage.setCoverageAmount(new BigDecimal("1000"));
        C3Hold hold = new C3Hold();
        Date startDate = DATE_FORMATTER.parse(date);
        hold.setHoldStartDate(startDate);
        requiredCoverage.setHold(hold);

        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3PolicyIssuance c3PolicyIssuance = mockC3PolicyIssuance(1000, "PRIMARY", date, "FLOOD", PolicyType.LP);
        c3PolicyIssuance.setEffectiveDate(date);
        c3PolicyIssuance.setExpirationDate(DATE_FORMATTER.print(new DateTime(startDate).plusYears(1).toDate()));
        c3ResponseDTO.getPoliciesToIssue().add(c3PolicyIssuance);

        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(0, c3ResponseDTO.getPoliciesToIssue().size());
    }

}