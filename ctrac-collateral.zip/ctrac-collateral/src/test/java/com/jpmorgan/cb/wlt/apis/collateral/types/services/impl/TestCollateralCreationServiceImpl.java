package com.jpmorgan.cb.wlt.apis.collateral.types.services.impl;

import com.jpmorgan.cb.wlt.apis.ApiDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.CollateralRepository;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.apis.collateral.types.CollateralType;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.RealEstate;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateCollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateRealEstateDTO;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.dao.LoanRepository;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanService;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanStatus;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.CollateralStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralCreationServiceImpl {

    @Mock
    private CollateralRepository collateralRepository;

    @Mock
    private CollateralDetailsService collateralRetrievalService;

    @Mock
    private CollateralSectionService collateralSectionService;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CollateralCreationServiceImpl testObj;

    @Mock
    private CollateralDTO collateralDetailsDTO;
    @Mock
    private LoanService loanService;
    @Mock
    private LoanDTO loanDTO;

    @Mock
    private LoanRepository loanRepository;

    private static final UserRequestInfo CONST_TEST_USER = new UserRequestInfo("testUser");

    @Before
    public void setUp() {
       when(collateralRetrievalService.getCollateralDetails(1L)).thenReturn(collateralDetailsDTO);
    }

    @Test
    public void testGetCollateralTypes() {
        List<ApiDTO> apiDTOList = testObj.getCollateralTypeAPIs();
        Set<String> apis = new HashSet<>();
        for (ApiDTO apiDTO : apiDTOList) {
            apis.add(apiDTO.getDescription());
            CollateralType collateralType = CollateralType.findByDescription(apiDTO.getDescription());
            assertThat(apiDTO.getApi(), is(collateralType.getApi()));
        }
        assertThat(apis.size(), is(CollateralType.values().length));
    }

    @Test
    public void testCreateCollateral()
    {
        RealEstate collateral = new RealEstate();
        collateral.setRid(1L);
        CreateRealEstateDTO createCollateralDTO1 = new CreateRealEstateDTO();
        when(modelMapper.map(createCollateralDTO1, RealEstate.class)).thenReturn(collateral);
        when(collateralRepository.save(collateral)).thenReturn(collateral);
        CollateralDTO actual = testObj.createCollateral(createCollateralDTO1, CollateralType.REAL_ESTATE, CONST_TEST_USER);
        assertThat(actual, is(collateralDetailsDTO));
        assertThat(collateral.getCollateralStatus(),is(CollateralStatus.DRAFT.getName()));
        verify(collateralSectionService).initializeCollateralSections(1L, CONST_TEST_USER);
    }

    @Test
    public void testpopulateLoanDTO()
    {
        CreateRealEstateDTO mockCreateCollateralDTO = new CreateRealEstateDTO();
        mockCreateCollateralDTO.setLineOfBusiness("CB");
        LoanDTO loanDTO = testObj.populateLoanDTO(mockCreateCollateralDTO,1L);
        assertThat(loanDTO.getLineOfBusiness(),is(mockCreateCollateralDTO.getLineOfBusiness()));
        assertThat(loanDTO.getCollateralId(),is(1L));
        assertThat(loanDTO.getStatus(),is(LoanStatus.PENDING_VERIFICATION.name()));
        assertThat(loanDTO.getPrimaryFlag(),is(true));
    }

}
