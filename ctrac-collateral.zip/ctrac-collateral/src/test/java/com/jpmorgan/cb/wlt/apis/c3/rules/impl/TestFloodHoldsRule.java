package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.C3AlertEmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.*;
import static junit.framework.TestCase.assertNull;
import static org.hamcrest.MatcherAssert.assertThat;

public class TestFloodHoldsRule {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    private FloodHoldsRule testObj;

    @Before
    public void setUp() {
        testObj = new FloodHoldsRule();
    }

    @Test
    public void testBeforeHold() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setHasFloodHolds(true);
        C3RequiredCoverage requiredCoverage = mockRequiredCoverage(InsuranceType.FLOOD, 4001L, FloodCoverageType.PRIMARY);
        requiredCoverage.setHold(mockHold("09/10/2018", null));
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate calculatedCoverageDate = mockCalculatedCoverageDate(
                InsuranceType.FLOOD, "09/07/2018", 4001L, FloodCoverageType.PRIMARY);
        c3ResponseDTO.getCalculatedFloodCoverageDates().add(calculatedCoverageDate);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(1));
        assertThat(c3ResponseDTO.getAlertEmails().get(0).getAlertTemplate(), Matchers.is(C3AlertEmailTemplate.HOLD_ACTION_REQUIRED));
        assertThat(c3ResponseDTO.getAlertEmails().get(0).getCalculatedCoverageDate(), Matchers.is(calculatedCoverageDate));
        assertThat(calculatedCoverageDate.isValid(), Matchers.is(false));
    }

    @Test
    public void testDuringHold() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setHasFloodHolds(true);
        C3RequiredCoverage requiredCoverage = mockRequiredCoverage(InsuranceType.FLOOD, 4001L, FloodCoverageType.PRIMARY);
        requiredCoverage.setHold(mockHold("09/01/2018", null));
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate calculatedCoverageDate = mockCalculatedCoverageDate(
                InsuranceType.FLOOD, "09/07/2018", 4001L, FloodCoverageType.PRIMARY);
        c3ResponseDTO.getCalculatedFloodCoverageDates().add(calculatedCoverageDate);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(DATE_FORMATTER.parse("09/01/2018")));
        assertThat(calculatedCoverageDate.isValid(), Matchers.is(true));
    }
    @Test
    public void testDuringHoldWithLpiDate() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setHasFloodHolds(true);
        C3RequiredCoverage requiredCoverage = mockRequiredCoverage(InsuranceType.FLOOD, 4001L, FloodCoverageType.PRIMARY);
        requiredCoverage.setHold(mockHold("09/01/2018", "10/01/2018"));
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate calculatedCoverageDate = mockCalculatedCoverageDate(
                InsuranceType.FLOOD, "09/07/2018", 4001L, FloodCoverageType.PRIMARY);
        c3ResponseDTO.getCalculatedFloodCoverageDates().add(calculatedCoverageDate);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(DATE_FORMATTER.parse("09/01/2018")));
        assertThat(calculatedCoverageDate.isValid(), Matchers.is(true));
    }

    @Test
    public void testAfterHold() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3RequiredCoverage requiredCoverage = mockRequiredCoverage(InsuranceType.FLOOD, 4001L, FloodCoverageType.PRIMARY);
        requiredCoverage.setHold(mockHold("08/01/2018", "09/01/2018"));
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate calculatedCoverageDate = mockCalculatedCoverageDate(
                InsuranceType.FLOOD, "09/07/2018", 4001L, FloodCoverageType.PRIMARY);
        c3ResponseDTO.getCalculatedFloodCoverageDates().add(calculatedCoverageDate);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(DATE_FORMATTER.parse("09/07/2018")));
        assertThat(calculatedCoverageDate.isValid(), Matchers.is(true));
    }

    @Test
    public void calculateHoldLpiDates() {
        List<C3CalculatedCoverageDate> calculatedCoverageDates = new ArrayList<>();
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        C3Hold hold = new C3Hold();
        Date holdLpiDate = new Date();
        hold.setHoldLpiDate(holdLpiDate);
        requiredCoverage.setHold(hold);
        List<C3RequiredCoverage> requiredCoverages = new ArrayList<>(Arrays.asList(requiredCoverage));
        testObj.calculateHoldLpiDates(calculatedCoverageDates, requiredCoverages);
        assertThat(calculatedCoverageDates.size(), Matchers.is(1));
        assertThat(calculatedCoverageDates.get(0).getCoverageDate(), Matchers.is(holdLpiDate));
    }

    @Test
    public void calculateHoldsWithVerifiedLpiDate() {
        C3RequiredCoverage requiredCoverageWithHold = C3RuleTestUtil.mockRequiredCoverage(InsuranceType.FLOOD, 4001L, FloodCoverageType.PRIMARY);
        long holdRid = 15L;
        C3Hold hold = mockHold(holdRid, "01/01/2018", "03/01/2018");
        requiredCoverageWithHold.setHold(hold);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setHasFloodHolds(true);
        c3RequestDTO.addRequiredCoverage(requiredCoverageWithHold);
        c3RequestDTO.addRequiredCoverage(C3RuleTestUtil.mockRequiredCoverage(InsuranceType.FLOOD, 4001L, FloodCoverageType.EXCESS));
        c3RequestDTO.getHoldsVerifiedWithLpiDate().add(holdRid);

        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getAllCalculatedCoverageDates().size(), Matchers.is(1));
        C3CalculatedCoverageDate result = c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0);
        assertThat(result.getCoverageDate(), Matchers.is(hold.getHoldLpiDate()));
        assertThat(result.getInsuranceType(), Matchers.is("FLOOD"));
        assertThat(result.getCoverageType(), Matchers.is(requiredCoverageWithHold.getCoverageType()));
        assertThat(result.getInsurableAssetId(), Matchers.is(requiredCoverageWithHold.getInsurableAssetId()));
        assertThat(result.getInsurableAssetType().name(), Matchers.is(requiredCoverageWithHold.getInsurableAssetType()));
    }

    @Test
    public void calculateNewHoldDates() {
        C3RequiredCoverage requiredCoverageWithHold = C3RuleTestUtil.mockRequiredCoverage(InsuranceType.FLOOD, 4001L, FloodCoverageType.PRIMARY);
        long holdRid = 15L;
        C3Hold hold = mockHold(holdRid, "01/01/2018", "03/01/2018");
        hold.setNewHold(true);
        requiredCoverageWithHold.setHold(hold);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.addRequiredCoverage(requiredCoverageWithHold);
        c3RequestDTO.setHasFloodHolds(true);
        c3RequestDTO.setAddedAndRemovedCoveragesOnly(true);

        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getAllCalculatedCoverageDates().size(), Matchers.is(1));
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0).getCoverageDate(), Matchers.is(hold.getHoldStartDate()));
    }

    @Test
    public void testFloodHold() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setHasFloodHolds(true);
        long insurableAssetId = 4001L;
        C3RequiredCoverage requiredCoverage = C3RuleTestUtil.mockRequiredCoverage(InsuranceType.FLOOD, insurableAssetId, FloodCoverageType.PRIMARY);
        C3Hold hold = new C3Hold();
        hold.setHoldStartDate(DATE_FORMATTER.parse("09/01/2018"));
        hold.setHoldLpiDate(DATE_FORMATTER.parse("10/01/2018"));
        requiredCoverage.setHold(hold);
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        C3CalculatedCoverageDate calculatedCoverageDate = c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0);
        assertThat(calculatedCoverageDate.getInsuranceType(), Matchers.is(InsuranceType.FLOOD.name()));
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(hold.getHoldLpiDate()));
        assertThat(calculatedCoverageDate.getInsurableAssetId(), Matchers.is(insurableAssetId));
        assertThat(calculatedCoverageDate.getCoverageType(), Matchers.is(requiredCoverage.getCoverageType()));
        assertNull(calculatedCoverageDate.getPolicyId());
    }

}
