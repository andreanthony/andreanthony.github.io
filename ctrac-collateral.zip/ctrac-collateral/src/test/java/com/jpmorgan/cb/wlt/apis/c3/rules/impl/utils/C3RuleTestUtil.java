package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;

import java.math.BigDecimal;

public class C3RuleTestUtil {
    public static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    public static final long INSURABLE_ASSET_ID = 4001L;

    private C3RuleTestUtil() {}

    public static C3RequiredCoverage mockRequiredCoverage(InsuranceType insuranceType, Long insurableAssetId, FloodCoverageType coverageType) {
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsurableAssetType(InsurableAssetType.STRUCTURE.name());
        requiredCoverage.setInsuranceType(insuranceType.name());
        requiredCoverage.setInsurableAssetId(insurableAssetId);
        requiredCoverage.setCoverageType(coverageType.name());
        return requiredCoverage;
    }

    public static C3RequiredCoverage mockRequiredCoverage(InsurableAssetType insurableAssetType, Long insurableAssetId, FloodCoverageType coverageType) {
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsurableAssetType(insurableAssetType.name());
        requiredCoverage.setInsurableAssetId(insurableAssetId);
        requiredCoverage.setCoverageType(coverageType.name());
        return requiredCoverage;
    }

    public static C3RequiredCoverage mockGeneralRequiredCoverage(String coverageType, String amount) {
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsuranceType("GENERAL");
        requiredCoverage.setCoverageType(coverageType);
        requiredCoverage.setCoverageAmount(new BigDecimal(amount));
        return requiredCoverage;
    }

    public static C3CalculatedCoverageDate mockCalculatedCoverageDate(InsuranceType insuranceType, String coverageDate, Long insurableAssetId, FloodCoverageType coverageType) {
        return mockCalculatedCoverageDate(insuranceType, coverageDate, insurableAssetId, coverageType.name());
    }

    public static C3CalculatedCoverageDate mockCalculatedCoverageDate(InsuranceType insuranceType, String coverageDate,
                Long insurableAssetId, String coverageType) {
        C3CalculatedCoverageDate calculatedCoverageDate = new C3CalculatedCoverageDate();
        calculatedCoverageDate.setInsuranceType(insuranceType.name());
        calculatedCoverageDate.setInsurableAssetType(InsurableAssetType.STRUCTURE);
        calculatedCoverageDate.setCoverageDate(DATE_FORMATTER.parse(coverageDate));
        calculatedCoverageDate.setInsurableAssetId(insurableAssetId);
        calculatedCoverageDate.setCoverageType(coverageType);
        calculatedCoverageDate.setValid(true);
        return calculatedCoverageDate;
    }

    public static C3Hold mockHold(Long rid, String startDate, String lpiDate) {
        C3Hold hold = new C3Hold();
        hold.setRid(rid);
        hold.setHoldStartDate(DATE_FORMATTER.parse(startDate));
        hold.setHoldLpiDate(DATE_FORMATTER.parse(lpiDate));
        return hold;
    }

    public static C3Hold mockHold(String startDate, String lpiDate) {
        return mockHold(15L, startDate, lpiDate);
    }

    public static C3Policy mockFloodPolicy(Long policyId, PolicyType policyType, PolicyStatus policyStatus, String coverageType) {
        C3Policy policy =  mockPolicy(policyId, policyType, policyStatus,InsuranceType.FLOOD);
        policy.getProvidedCoverages().add(mockProvidedCoverage(INSURABLE_ASSET_ID, coverageType));
        return policy;
    }

    public static C3Policy mockGeneralPolicy(Long policyId, PolicyType policyType, PolicyStatus policyStatus, String coverageType) {
        C3Policy policy =  mockPolicy(policyId, policyType, policyStatus, InsuranceType.GENERAL);
        C3ProvidedCoverage providedCoverage = new C3ProvidedCoverage();
        providedCoverage.setCoverageType(coverageType);
        policy.getProvidedCoverages().add(providedCoverage);
        return policy;
    }

    public static C3Policy mockPolicy(Long policyId, PolicyType policyType, PolicyStatus policyStatus, InsuranceType insuranceType) {
        C3Policy policy = new C3Policy();
        policy.setPolicyId(policyId);
        policy.setPolicyType(policyType.name());
        policy.setPolicyStatus(policyStatus.name());
        policy.setEffectiveDate("01/01/2018");
        policy.setExpirationDate("01/01/2019");
        policy.setInsuranceType(insuranceType.name());
        return policy;
    }

    public static C3ProvidedCoverage mockGeneralProvidedCoverage(String coverageType, String amount) {
        C3ProvidedCoverage providedCoverage = new C3ProvidedCoverage();
        providedCoverage.setCoverageType(coverageType);
        providedCoverage.setCoverageAmount(new BigDecimal(amount));
        return providedCoverage;
    }

    public static C3ProvidedCoverage mockProvidedCoverage(Long insurableAssetId, String coverageType) {
        C3ProvidedCoverage providedCoverage = new C3ProvidedCoverage();
        providedCoverage.setInsurableAssetType(InsurableAssetType.STRUCTURE.name());
        providedCoverage.setInsurableAssetId(insurableAssetId);
        providedCoverage.setCoverageType(coverageType);
        return providedCoverage;
    }

    public static C3PolicyIssuance mockC3PoliciesToIssue(Long insurableAssetId, InsurableAssetType insurableAssetType) {
        C3PolicyIssuance c3PolicyIssuance = new C3PolicyIssuance();
        c3PolicyIssuance.setInsurableAssetId(insurableAssetId);
        c3PolicyIssuance.setInsurableAssetType(insurableAssetType);
        return c3PolicyIssuance;
    }

    public static C3AlertEmail mockAlertEmailTemplate(C3AlertEmailTemplate c3AlertEmailTemplate, InsurableAssetType insurableAssetType,Long insurableAssetId,  FloodCoverageType coverageType) {
        C3AlertEmail c3AlertEmail = new C3AlertEmail();
        c3AlertEmail.setAlertTemplate(c3AlertEmailTemplate);
        c3AlertEmail.setRequiredCoverage(mockRequiredCoverage(insurableAssetType,insurableAssetId,coverageType));
        return c3AlertEmail;
    }


}
