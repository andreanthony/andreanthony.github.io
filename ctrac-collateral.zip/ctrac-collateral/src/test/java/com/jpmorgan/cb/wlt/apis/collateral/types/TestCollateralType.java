package com.jpmorgan.cb.wlt.apis.collateral.types;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralType {

    @Test
    public void testCollateralTypes() {
        assertThat(CollateralType.values().length, is(7));
    }

    @Test
    public void testCollateralTypeApis() {
        assertThat(CollateralType.REAL_ESTATE.getApi(), is("realestate"));
        assertThat(CollateralType.BUSINESS_ASSETS.getApi(), is("businessassets"));
        assertThat(CollateralType.CASH.getApi(), is("cash"));
        assertThat(CollateralType.LIFE_INSURANCE.getApi(), is("lifeinsurance"));
        assertThat(CollateralType.OTHER.getApi(), is("other"));
        assertThat(CollateralType.SECURITIES.getApi(), is("securities"));
        assertThat(CollateralType.TITLED_COLLATERAL.getApi(), is("titledcollateral"));
    }

    @Test
    public void testFindByDescription() {
        assertThat(CollateralType.findByDescription("Real Estate"), is(CollateralType.REAL_ESTATE));
        assertThat(CollateralType.findByDescription("Business Assets/UCC"), is(CollateralType.BUSINESS_ASSETS));
        assertThat(CollateralType.findByDescription("Cash"), is(CollateralType.CASH));
        assertThat(CollateralType.findByDescription("Life Insurance"), is(CollateralType.LIFE_INSURANCE));
        assertThat(CollateralType.findByDescription("Other"), is(CollateralType.OTHER));
        assertThat(CollateralType.findByDescription("Securities"), is(CollateralType.SECURITIES));
        assertThat(CollateralType.findByDescription("Titled Collateral"), is(CollateralType.TITLED_COLLATERAL));
    }
}
