package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;

@RunWith(MockitoJUnitRunner.class)
public class TestC3RuleFactoryImpl {

    @InjectMocks
    private C3RuleFactoryImpl testObj;

    @Test
    public void testRules() {
        List<C3Rule> c3Rules = testObj.getC3Rules();
        int i = 0;
        assertThat(c3Rules.get(i++), instanceOf(CollateralStatusRule.class));
        assertThat(c3Rules.get(i++), instanceOf(BIRWorkflowRule.class));
        assertThat(c3Rules.get(i++), instanceOf(LoanStatusRule.class));
        assertThat(c3Rules.get(i++), instanceOf(FloodZoneRule.class));
        assertThat(c3Rules.get(i++), instanceOf(ExternallyAgentedRule.class));
        assertThat(c3Rules.get(i++), instanceOf(FloodCoverageDateRule.class));
        assertThat(c3Rules.get(i++), instanceOf(FloodHoldsRule.class));
        assertThat(c3Rules.get(i++), instanceOf(GeneralCoverageDateRule.class));
        assertThat(c3Rules.get(i++), instanceOf(AlertLenderPlaceRestrictionRule.class));
        assertThat(c3Rules.get(i++), instanceOf(FloodLenderPlaceCalculationRule.class));
        assertThat(c3Rules.get(i++), instanceOf(GeneralLenderPlaceCalculationRule.class));
        assertThat(c3Rules.get(i++), instanceOf(LenderPlaceLapseRule.class));
        assertThat(c3Rules.get(i++), instanceOf(GapOnPolicyExpirationRule.class));
        assertThat(c3Rules.get(i++), instanceOf(LenderPlaceMatchingRule.class));
        assertThat(c3Rules.get(i++), instanceOf(AlertFloodMultipleExcessPoliciesRule.class));
    }
}
