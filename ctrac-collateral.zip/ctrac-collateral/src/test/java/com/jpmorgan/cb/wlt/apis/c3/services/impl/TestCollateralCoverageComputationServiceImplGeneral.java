package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3RuleFactory;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.C3RuleFactoryImpl;
import com.jpmorgan.cb.wlt.apis.c3.services.C3RequestPopulationService;
import com.jpmorgan.cb.wlt.apis.c3.services.LenderPlacePolicyService;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverageRepository;
import com.jpmorgan.cb.wlt.services.Ctrac2ApiService;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;


@RunWith(MockitoJUnitRunner.class)
public class TestCollateralCoverageComputationServiceImplGeneral {

    private static final String FLOOD_ZONE_D = "D";
    private static final String COVERAGE_TYPE_AVALANCHE = "Avalanche";
    private static final Long POLICY_ID_1 = 1001L;
    private static final Long POLICY_ID_2 = 1002L;
    private static final Long POLICY_ID_3 = 1003L;
    private static final BigDecimal _500K = new BigDecimal("500000.00");
    private static final BigDecimal _300K = new BigDecimal("300000.00");
    private static final BigDecimal _100K = new BigDecimal("100000.00");
    private static final String _12_01_2017 = "12/01/2017";
    private static final String _12_01_2018 = "12/01/2018";
    private static final String _12_01_2019 = "12/01/2019";
    private static final String _12_15_2018 = "12/15/2018";
    private static final String _12_15_2019 = "12/15/2019";
    private static final String REFERENCE_DATE_STRING = "12/01/2018";

    @InjectMocks
    private CollateralCoverageComputationServiceImpl testObj;
    @Mock
    private ProofOfCoverageRepository proofOfCoverageRepository;
    @Mock
    private ReferenceDateService referenceDateService;
    @Mock
    private Ctrac2ApiService ctrac2ApiService;
    @Mock
    private PublishEventService publishEventService;
    @Mock
    private C3RequestPopulationService c3RequestPopulationService;
    @Mock
    private LenderPlacePolicyService lenderPlacePolicyService;

    @Spy
    private C3RuleFactory c3RuleFactory = new C3RuleFactoryImpl();


    @Test
    public void testLPLapseCreation() {
        C3RequestDTO c3RequestDTO = new C3RequestDTOBuilder(REFERENCE_DATE_STRING, CollateralStatus.PLEDGED, LoanStatus.ACTIVE, FLOOD_ZONE_D)
                .requiredGeneralCoverage(COVERAGE_TYPE_AVALANCHE, _500K)
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.GENERAL, POLICY_ID_1, PolicyType.NFIP, PolicyStatus.EXPIRING, _12_01_2017, _12_01_2018)
                        .providedGeneralCoverage(COVERAGE_TYPE_AVALANCHE, _500K).build())
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.GENERAL, POLICY_ID_2, PolicyType.NFIP, PolicyStatus.EXPIRING, _12_15_2018, _12_15_2019)
                        .providedGeneralCoverage(COVERAGE_TYPE_AVALANCHE, _500K).build())
                .build();

        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);
        System.out.println(c3ResponseDTO);
        //TODO: perform verification
    }

    @Test
    public void testMultipleBorrowerGapCreation() {
        C3RequestDTO c3RequestDTO = new C3RequestDTOBuilder(REFERENCE_DATE_STRING, CollateralStatus.PLEDGED, LoanStatus.ACTIVE, FLOOD_ZONE_D)
                .requiredGeneralCoverage(COVERAGE_TYPE_AVALANCHE, _500K)
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.GENERAL, POLICY_ID_1, PolicyType.GI_POLICY, PolicyStatus.ACCEPTED, _12_01_2017, _12_01_2018)
                        .providedGeneralCoverage(COVERAGE_TYPE_AVALANCHE, _300K).build())
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.GENERAL, POLICY_ID_2, PolicyType.GI_POLICY, PolicyStatus.ACCEPTED, _12_01_2017, _12_01_2018)
                        .providedGeneralCoverage(COVERAGE_TYPE_AVALANCHE, _100K).build())
                .lpPolicy(new C3PolicyBuilder(InsuranceType.GENERAL, POLICY_ID_3, PolicyType.GI_LP, PolicyStatus.PAID, _12_01_2018, _12_01_2019)
                        .providedGeneralCoverage(COVERAGE_TYPE_AVALANCHE, _100K).build())
                .build();

        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);
        System.out.println(c3ResponseDTO);
        //TODO: perform verification
    }
}
