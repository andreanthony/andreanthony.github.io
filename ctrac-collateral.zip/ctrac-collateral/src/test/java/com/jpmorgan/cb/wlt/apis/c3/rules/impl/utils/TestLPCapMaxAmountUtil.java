package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.enums.AlthansPropertyType;
import com.jpmorgan.cb.wlt.apis.c3.dtos.enums.RealEstateSubType;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;

public class TestLPCapMaxAmountUtil {
    public static final BigDecimal _100M = new BigDecimal(100000000);
    public static final BigDecimal OVER_PRIMARY_RESIDENTIAL_LIMIT = LPCapMaxAmountUtil.PRIMARY_RESIDENTIAL_LIMIT.add(BigDecimal.ONE);
    public static final BigDecimal OVER_PRIMARY_COMMERCIAL_LIMIT = LPCapMaxAmountUtil.PRIMARY_COMMERCIAL_LIMIT.add(BigDecimal.ONE);
    public static final BigDecimal OVER_EXCESS_LIMIT = LPCapMaxAmountUtil.EXCESS_LIMIT.add(BigDecimal.ONE);
    public static final BigDecimal UNDER_PRIMARY_RESIDENTIAL_LIMIT = LPCapMaxAmountUtil.PRIMARY_RESIDENTIAL_LIMIT.subtract(BigDecimal.ONE);
    public static final BigDecimal UNDER_PRIMARY_COMMERCIAL_LIMIT = LPCapMaxAmountUtil.PRIMARY_COMMERCIAL_LIMIT.subtract(BigDecimal.ONE);
    public static final BigDecimal UNDER_EXCESS_LIMIT = LPCapMaxAmountUtil.EXCESS_LIMIT.subtract(BigDecimal.ONE);
    public static final InsurableAssetType businessIncome = InsurableAssetType.BUSINESS_INCOME;
    public static final InsurableAssetType baseInsurableAsset = InsurableAssetType.BASE_INSURABLE_ASSET;
    public static final InsurableAssetType structure = InsurableAssetType.STRUCTURE;
    public static final String residential = RealEstateSubType.DWELLING_RESIDENTIAL.getCode();
    public static final FloodCoverageType primary = FloodCoverageType.PRIMARY;
    public static final String condo = AlthansPropertyType.CONDO_ASSOC.getCode();
    public static final String commercialCollateraSubtype = RealEstateSubType.COMMERCIAL.getCode();
    public static final String commercial = AlthansPropertyType.COMMERCIAL.getCode();


    @Test
    public void capLPCoverageAmountNoChange() {
        assertEquals(BigDecimal.ZERO, LPCapMaxAmountUtil.capLPCoverageAmount(BigDecimal.ZERO, primary,
                structure, commercial, commercialCollateraSubtype));
        assertEquals(_100M, LPCapMaxAmountUtil.capLPCoverageAmount(_100M, null,
                structure, commercial, RealEstateSubType.COMMERCIAL.getCode()));
        assertEquals(_100M, LPCapMaxAmountUtil.capLPCoverageAmount(_100M, primary,
                null, commercial, commercialCollateraSubtype));
    }

    @Test
    public void capLPCoverageAmountExcess() {
        assertEquals(LPCapMaxAmountUtil.EXCESS_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_EXCESS_LIMIT, FloodCoverageType.EXCESS,
                structure, commercial, commercialCollateraSubtype));
        assertEquals(UNDER_EXCESS_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_EXCESS_LIMIT, FloodCoverageType.EXCESS,
                structure, commercial, commercialCollateraSubtype));

        assertEquals(OVER_EXCESS_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_EXCESS_LIMIT, FloodCoverageType.EXCESS,
                baseInsurableAsset, commercial, commercialCollateraSubtype));
        assertEquals(UNDER_EXCESS_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_EXCESS_LIMIT, FloodCoverageType.EXCESS,
                baseInsurableAsset, commercial, commercialCollateraSubtype));

        assertEquals(BigDecimal.ZERO, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_EXCESS_LIMIT, FloodCoverageType.EXCESS,
                businessIncome, commercial, commercialCollateraSubtype));
        assertEquals(BigDecimal.ZERO, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_EXCESS_LIMIT, FloodCoverageType.EXCESS,
                businessIncome, commercial, commercialCollateraSubtype));
    }

    @Test
    public void capLPCoverageAmountPrimaryBUSINESS_INCOME() {
        assertEquals(_100M, LPCapMaxAmountUtil.capLPCoverageAmount(_100M, primary,
                businessIncome, commercial, commercialCollateraSubtype));
        assertEquals(_100M, LPCapMaxAmountUtil.capLPCoverageAmount(_100M, primary,
                businessIncome, AlthansPropertyType.DWELLING_RESIDENTIAL.getCode(), residential));
    }
    
    @Test
    public void capLPCoverageAmountPrimaryResidential() {
        assertEquals(UNDER_PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                structure, AlthansPropertyType.DWELLING_RESIDENTIAL.getCode(), residential));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                structure, AlthansPropertyType.DWELLING_RESIDENTIAL.getCode(), residential));

        assertEquals(UNDER_PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                baseInsurableAsset, AlthansPropertyType.DWELLING_RESIDENTIAL.getCode(), residential));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                baseInsurableAsset, AlthansPropertyType.DWELLING_RESIDENTIAL.getCode(), residential));
    }

    @Test
    public void capLPCoverageAmountPrimaryCommercial() {
        assertEquals(UNDER_PRIMARY_COMMERCIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_COMMERCIAL_LIMIT, primary,
                structure, commercial, commercialCollateraSubtype));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_COMMERCIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_COMMERCIAL_LIMIT, primary,
                structure, commercial, commercialCollateraSubtype));

        assertEquals(UNDER_PRIMARY_COMMERCIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_COMMERCIAL_LIMIT, primary,
                baseInsurableAsset, commercial, commercialCollateraSubtype));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_COMMERCIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_COMMERCIAL_LIMIT, primary,
                baseInsurableAsset, commercial, commercialCollateraSubtype));
    }

    @Test
    public void capLPCoverageAmountPrimarycondoiationCommercial() {
        assertEquals(UNDER_PRIMARY_COMMERCIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_COMMERCIAL_LIMIT, primary,
                structure, condo, commercialCollateraSubtype));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_COMMERCIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_COMMERCIAL_LIMIT, primary,
                structure, condo, commercialCollateraSubtype));

        assertEquals(UNDER_PRIMARY_COMMERCIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_COMMERCIAL_LIMIT, primary,
                baseInsurableAsset, condo, commercialCollateraSubtype));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_COMMERCIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_COMMERCIAL_LIMIT, primary,
                baseInsurableAsset, condo, commercialCollateraSubtype));
    }

    @Test
    public void capLPCoverageAmountPrimaryCondoResidential() {
        assertEquals(UNDER_PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                structure, condo, residential));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                structure, condo, residential));

         assertEquals(UNDER_PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                baseInsurableAsset, condo, residential));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                baseInsurableAsset, condo, residential));
    }

    @Test
    public void capLPCoverageAmountPrimaryCondoResidentialFiat() {
        assertEquals(UNDER_PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                structure, "Dwelling (1-4 Unit) Residential", residential));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                structure, "Dwelling (1-4 Unit) Residential", residential));

        assertEquals(UNDER_PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(UNDER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                baseInsurableAsset, "Dwelling (1-4 Unit) Residential", residential));
        assertEquals(LPCapMaxAmountUtil.PRIMARY_RESIDENTIAL_LIMIT, LPCapMaxAmountUtil.capLPCoverageAmount(OVER_PRIMARY_RESIDENTIAL_LIMIT, primary,
                baseInsurableAsset, "Dwelling (1-4 Unit) Residential", residential));
    }
}