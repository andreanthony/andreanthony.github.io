package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cb.wlt.apis.c3.services.C3RequestPopulationService;
import com.jpmorgan.cb.wlt.apis.c3.services.LenderPlacePolicyService;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3WorkflowRequestEventDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collections;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestC3AdminServiceImpl {

    @Mock
    private C3RequestPopulationService c3RequestPopulationService;

    @Mock
    private LenderPlacePolicyService lenderPlacePolicyService;

    @InjectMocks
    private C3AdminServiceImpl testObj;

    Long collateralId = 333L;

    @Test
    public void testCancelPreLetterCycle() {
        C3WorkflowRequestEventDTO workflowRequestEventDTO = setUpCancellation(PolicyStatus.PENDING_LETTER_CYCLE, PolicyStatus.DELETED,"01/05/2018");
        C3PolicyCancellation actual = testObj.cancel(workflowRequestEventDTO);
        verifyCancellation(actual, null, null, true);
    }

    @Test
    public void testCancelLetterCycleFlat() {
        C3WorkflowRequestEventDTO workflowRequestEventDTO = setUpCancellation(PolicyStatus.LETTER_CYCLE, PolicyStatus.CANCELLED,"01/05/2018");
        C3PolicyCancellation actual = testObj.cancel(workflowRequestEventDTO);
        verifyCancellation(actual, "01/05/2018", null, false);
    }

    @Test
    public void testCancelLetterCycleNotFlat() {
        C3WorkflowRequestEventDTO workflowRequestEventDTO = setUpCancellation(PolicyStatus.LETTER_CYCLE, PolicyStatus.LETTER_CYCLE, "01/06/2018");
        C3PolicyCancellation actual = testObj.cancel(workflowRequestEventDTO);
        verifyCancellation(actual, null, "01/06/2018", false);
    }

    @Test
    public void testCancelPreInvoiced() {
        C3WorkflowRequestEventDTO workflowRequestEventDTO = setUpCancellation(PolicyStatus.PRE_INVOICED, PolicyStatus.CANCELLED,"01/05/2018");
        C3PolicyCancellation actual = testObj.cancel(workflowRequestEventDTO);
        verifyCancellation(actual, "01/05/2018", null, false);
    }

    private C3WorkflowRequestEventDTO setUpCancellation(PolicyStatus policyStatus, PolicyStatus resultStatus, String cancellationEffectiveDate) {
        C3WorkflowRequestEventDTO workflowRequestEventDTO = new C3WorkflowRequestEventDTO();
        workflowRequestEventDTO.setProofOfCoverageRids(Collections.singletonList(5L));
        C3Policy c3Policy = new C3Policy();
        c3Policy.setPolicyId(5L);
        c3Policy.setPolicyStatus(policyStatus.name());
        c3Policy.setEffectiveDate("01/05/2018");
        c3Policy.setCancellationEffectiveDate(cancellationEffectiveDate);
        c3Policy.setExpirationDate("01/05/2019");
        when(c3RequestPopulationService.populatePolicy(5L)).thenReturn(c3Policy);
        ProofOfCoverage proofOfCoverage = mock(ProofOfCoverage.class);
        when(proofOfCoverage.getPolicyStatus_()).thenReturn(resultStatus);
        when(proofOfCoverage.getCancellationReason()).thenReturn(CancellationReason.BORROWER_POLICY_RECEIVED.name());
        ArrayList<ProvidedCoverage> providedCoverages = new ArrayList<>();
        ProvidedCoverage providedCoverage = new ProvidedCoverage();
        providedCoverage.setCollateralId(collateralId);
        providedCoverages.add(providedCoverage);
        when(proofOfCoverage.getProvidedCoverages()).thenReturn(providedCoverages);
        when(lenderPlacePolicyService.cancel(any())).thenReturn(proofOfCoverage);
        return workflowRequestEventDTO;
    }

    private void verifyCancellation(C3PolicyCancellation actual, String cancellationDate, String updatedExpirationDate, boolean isDeleted) {
        ArgumentCaptor<C3PolicyCancellation> cancellationArgCaptor = ArgumentCaptor.forClass(C3PolicyCancellation.class);
        InOrder inOrder = inOrder(lenderPlacePolicyService);
        inOrder.verify(lenderPlacePolicyService).cancel(cancellationArgCaptor.capture());
        if (updatedExpirationDate == null) {
            inOrder.verify(lenderPlacePolicyService).publishC3WorkflowEvent(eq(Collections.singletonList(5L)), eq(collateralId), eq(CtracEventType.C3_COMPLETED));
        } else {
            inOrder.verify(lenderPlacePolicyService, never()).publishC3WorkflowEvent(eq(Collections.singletonList(5L)), eq(collateralId), eq(CtracEventType.C3_COMPLETED));
        }
        C3PolicyCancellation cancelledPolicy = cancellationArgCaptor.getValue();
        assertThat(cancelledPolicy.getPolicyId(), is(5L));
        assertThat(cancelledPolicy.getCancellationEffectiveDate(), is(cancellationDate));
        assertThat(cancelledPolicy.getCancellationReason(), is(CancellationReason.BORROWER_POLICY_RECEIVED));
        assertThat(cancelledPolicy.getUpdatedExpirationDate(), is(updatedExpirationDate));
        assertEquals(cancelledPolicy.isDeleted(), isDeleted);
        assertThat(actual, is(cancelledPolicy));
    }
}