package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.mockGeneralPolicy;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class TestGeneralCoverageDateRule {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    private GeneralCoverageDateRule testObj;

    @Before
    public void setUp() {
        testObj = new GeneralCoverageDateRule();
    }

    @Test
    public void getInsuranceType() {
        assertThat(testObj.getInsuranceType(), Matchers.is(InsuranceType.GENERAL));
    }

    @Test
    public void getC3CalculatedCoverageDates() {
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.setCalculatedGeneralCoverageDates(new ArrayList<>());
        assertThat(testObj.getC3CalculatedCoverageDates(c3ResponseDTO), Matchers.is(c3ResponseDTO.getCalculatedGeneralCoverageDates()));
    }

    @Test
    public void getOverrideCalculatedCoverageDate() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setOverrideGeneralCoverageDate("01/01/2018");
        assertThat(testObj.getOverrideCalculatedCoverageDate(c3RequestDTO), Matchers.is(c3RequestDTO.getOverrideGeneralCoverageDate_()));
    }

    @Test
    public void testOverrideDateGeneralOnly() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setOverrideGeneralCoverageDate("01/01/2018");
        c3RequestDTO.setInsuranceType("GENERAL");
        assertThat(testObj.getOverrideCalculatedCoverageDate(c3RequestDTO), Matchers.is(c3RequestDTO.getOverrideGeneralCoverageDate_()));
    }

    @Test
    public void testOverrideDateFloodOnly() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setOverrideFloodCoverageDate("09/07/2018");
        c3RequestDTO.setInsuranceType("FLOOD");
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(0));
    }

    @Test
    public void testProcessedBorrowerPoliciesPopulated() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy;
        policy = mockGeneralPolicy(1L, PolicyType.NFIP, PolicyStatus.CANCELLED, "Hazard");
        policy = mockGeneralPolicy(2L, PolicyType.NFIP, PolicyStatus.CANCELLED, "Avalanche");
    }

    @Test
    public void addCalculatedCoverageDates() {
        List< C3CalculatedCoverageDate > calculatedCoverageDates = new ArrayList<>();
        Date coverageDate = new Date();
        Long policyId = 1L;
        C3Policy policy = mockGeneralPolicy(policyId, PolicyType.NFIP, PolicyStatus.CANCELLED, "Hazard");
        testObj.addCalculatedCoverageDates(calculatedCoverageDates, coverageDate, policy);
        assertEquals(1, calculatedCoverageDates.size());
        assertEquals(coverageDate, calculatedCoverageDates.get(0).getCoverageDate());
        assertEquals("Hazard", calculatedCoverageDates.get(0).getCoverageType());
        assertEquals(policyId, calculatedCoverageDates.get(0).getPolicyId());
    }

    @Test
    public void testOverrideDate() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setOverrideGeneralCoverageDate("09/07/2018");
        C3RequiredCoverage c3RequiredCoverage = new C3RequiredCoverage();
        c3RequiredCoverage.setInsuranceType("GENERAL");
        c3RequestDTO.addRequiredCoverages(Arrays.asList(c3RequiredCoverage));
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getCalculatedGeneralCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getCalculatedGeneralCoverageDates().get(0), "09/07/2018", null, null);
    }

    @Test
    public void testCancelled() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockGeneralPolicy(1L, PolicyType.NFIP, PolicyStatus.CANCELLED, "test");
        policy.setLpAction("CANCEL_BP");
        policy.setCancellationEffectiveDate("09/08/2018");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.setCurrentReferenceDate(policy.getCancellationEffectiveDate());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getCalculatedGeneralCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getCalculatedGeneralCoverageDates().get(0), "09/08/2018",
                "test", 1L);
    }

    @Test
    public void testCancelledApp() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockGeneralPolicy(1L, PolicyType.APPLICATION, PolicyStatus.CANCELLED, "test");
        policy.setLpAction("CANCEL_BP");
        policy.setCancellationEffectiveDate("09/08/2018");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.setCurrentReferenceDate(policy.getCancellationEffectiveDate());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getCalculatedGeneralCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getCalculatedGeneralCoverageDates().get(0), "01/01/2018",
                "test", 1L);
    }

    @Test
    public void testAccepted() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockGeneralPolicy(1L, PolicyType.NFIP, PolicyStatus.ACCEPTED, "test");
        policy.setLpAction("NEW_BP");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.setCurrentReferenceDate(policy.getEffectiveDate());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getCalculatedGeneralCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getCalculatedGeneralCoverageDates().get(0), "01/01/2018",
                "test", 1L);
    }

    @Test
    public void testExpired() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockGeneralPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, "test");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getCalculatedGeneralCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getCalculatedGeneralCoverageDates().get(0), "01/01/2019",
                "test", 1L);
    }

    @Test
    public void testExpiredBinder() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockGeneralPolicy(1L, PolicyType.BINDER, PolicyStatus.EXPIRING, "test");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getCalculatedGeneralCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getCalculatedGeneralCoverageDates().get(0), "01/01/2018",
                "test", 1L);
    }


    @Test
    public void testTwoCoverages() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockGeneralPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, "test");
        C3ProvidedCoverage providedCoverage = new C3ProvidedCoverage();
        providedCoverage.setCoverageType("cov2");
        policy.getProvidedCoverages().add(providedCoverage);
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getCalculatedGeneralCoverageDates().size(), Matchers.is(2));
        assertOneCoverageDate(c3ResponseDTO.getCalculatedGeneralCoverageDates().get(0), "01/01/2019",
                "test", 1L);
        assertOneCoverageDate(c3ResponseDTO.getCalculatedGeneralCoverageDates().get(1), "01/01/2019",
                "cov2", 1L);
    }


    @Test
    public void testGeneralHold() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsuranceType(InsuranceType.GENERAL.name());
        C3Hold hold = new C3Hold();
        hold.setHoldStartDate(DATE_FORMATTER.parse("09/01/2018"));
        hold.setHoldLpiDate(DATE_FORMATTER.parse("10/01/2018"));
        requiredCoverage.setHold(hold);
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(0));
    }

    private void assertOneCoverageDate(C3CalculatedCoverageDate calculatedCoverageDate, String coverageDate,
                                       String coverageType, Long borrowerPolicyId) {
        assertThat(calculatedCoverageDate.getInsuranceType(), Matchers.is(InsuranceType.GENERAL.name()));
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(DATE_FORMATTER.parse(coverageDate)));
        assertNull(calculatedCoverageDate.getInsurableAssetId());
        assertThat(calculatedCoverageDate.getCoverageType(), Matchers.is(coverageType == null? null: coverageType));
        assertThat(calculatedCoverageDate.getPolicyId(), Matchers.is(borrowerPolicyId));
    }

}