package com.jpmorgan.cb.wlt.apis.collateral.sections.dao;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dtos.SectionStatusDto;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.RealEstate;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Date;

import static junit.framework.TestCase.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class TestSectionStatus {
    private DefaultDateFormatter defaultDateFormatter=new DefaultDateFormatter();

    @Test
    public void testMaptoDto(){
        SectionStatus sectionStatus=new SectionStatus();
        Collateral collateral=new RealEstate();
        Date date=new Date("28/1/2019");
        Long colRid=new Long(1234);
        collateral.setRid(colRid);
        sectionStatus.setRid(100l);
        sectionStatus.setStatusId("COLLATERAL_BASIC_DETAILS");
        sectionStatus.setSectionId("VERIFIED");
        sectionStatus.setModifiedBy("LOCAL");
        sectionStatus.setModifiedDate(date);
        sectionStatus.setVerifiedDate(date);
        sectionStatus.setCollateral(collateral);
        SectionStatusDto sectionStatusDto= sectionStatus.mapToDto();
        assertEquals(new Long(100),new Long(sectionStatusDto.getRid()));
        assertEquals(defaultDateFormatter.print(date),sectionStatusDto.getModifiedDate());
        assertEquals("LOCAL",sectionStatusDto.getModifiedBy());
        assertEquals(defaultDateFormatter.print(date),sectionStatusDto.getVerifiedDate());
        assertEquals(colRid,new Long(sectionStatusDto.getCollateralRid()));

    }
}
