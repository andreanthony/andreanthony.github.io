package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.junit.Test;

import java.util.Date;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.DATE_FORMATTER;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class TestC3PolicyCancellationUtil {


    @Test
    public void getCancellationReasonWithGapBorrowerPolicy() {
        runTest(LPAction.NEW_BP.name(), 2L, CancellationReason.BORROWER_POLICY_RECEIVED);
    }

    @Test
    public void getCancellationReasonNEW_BP() {
        runTest(LPAction.NEW_BP.name(), null, CancellationReason.BORROWER_POLICY_RECEIVED);

    }
    @Test
    public void getCancellationReasonPENDING_C3() {
        runTest(LPAction.PENDING_C3.name(), null, CancellationReason.BORROWER_POLICY_RECEIVED);
    }

    @Test
    public void getCancellationReasonCANCEL_BP() {
        runTest(LPAction.CANCEL_BP.name(), null, CancellationReason.INSURANCE_NOT_NEEDED);
    }
    @Test
    public void getCancellationReasonNoBpReceived() {
        runTest(null, null, CancellationReason.INSURANCE_NOT_NEEDED);
    }

    private void runTest(String lpAction, Long gapBorrowerPolicyId, CancellationReason expected) {
        C3Policy lpPolicy = C3RuleTestUtil.mockGeneralPolicy(1L, PolicyType.LP, PolicyStatus.PAID, "cov");
        lpPolicy.setGapBorrowerPolicyId(gapBorrowerPolicyId);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        if (lpAction != null) {
            C3Policy bpPolicy = C3RuleTestUtil.mockGeneralPolicy(2L, PolicyType.PRIVATE, PolicyStatus.ACCEPTED, "cov");
            bpPolicy.setLpAction(lpAction);
            c3RequestDTO.getBorrowerPolicies().add(bpPolicy);
        }
        Date date = DATE_FORMATTER.parse("02/01/2018");

        assertEquals(expected, C3PolicyCancellationUtil.getCancellationReason(lpPolicy, date, c3RequestDTO.getMatchingBorrowerPolicies(lpPolicy)));
    }

    @Test
    public void cancelPolicy() {
        testCancellationResult(
                true, true, true, true, false, false);
        testCancellationResult(
                true, true, false, false, false, true);
        testCancellationResult(
                true, false, true, false, false, false);
        testCancellationResult(
                true, false, false, false, false, false);
        testCancellationResult(
                false, true, false, false, false, true);
        testCancellationResult(
                false, false, false, false, false, true);
    }
    private void testCancellationResult(boolean isBeforeLpRequestSent, boolean isFlatCancelled, boolean isPendingLetterCycle,
                                        boolean expectedDeleted, boolean expectedUpdated, boolean expectedCancelled) {

        C3PolicyCancellation c3PolicyCancellation = new C3PolicyCancellation();
        String cancellationDate = "01/01/2019";
        CancellationReason cancellationReason = CancellationReason.BORROWER_POLICY_RECEIVED;
        C3PolicyCancellationUtil.populatePolicyCancellation(cancellationReason, cancellationDate,
                isFlatCancelled, isBeforeLpRequestSent, isPendingLetterCycle, c3PolicyCancellation);

        testPolicyCancellationResults(expectedDeleted, expectedUpdated, expectedCancelled, c3PolicyCancellation, cancellationDate, cancellationReason);
    }

    private void testPolicyCancellationResults(boolean expectedDeleted, boolean expectedUpdated, boolean expectedCancelled, C3PolicyCancellation c3PolicyCancellation, String cancellationDate, CancellationReason cancellationReason) {
        assertEquals("isDeleted", expectedDeleted, c3PolicyCancellation.isDeleted());

        if(expectedUpdated) {
            assertNull("cancelDate", c3PolicyCancellation.getCancellationEffectiveDate());
            assertEquals("expirationDate", cancellationDate, c3PolicyCancellation.getUpdatedExpirationDate());
        }
        if (expectedCancelled) {
            assertEquals("cancelDate", cancellationDate, c3PolicyCancellation.getCancellationEffectiveDate());
            assertEquals("reason", cancellationReason, c3PolicyCancellation.getCancellationReason());
        }
    }

    @Test
    public void cancelLpPolicy() {
        //mock policy is eff on 1/1/2018 expires on 1/1/2019
        testCancelLpPolicy(PolicyStatus.PAID, "01/01/2018", false, false, true);
        testCancelLpPolicy(PolicyStatus.PAID, "12/31/2018", false, false, true);
        testCancelLpPolicy(PolicyStatus.LETTER_CYCLE, "01/01/2018", false, false, true);
        testCancelLpPolicy(PolicyStatus.LETTER_CYCLE, "12/31/2018", false, true, false);
        testCancelLpPolicy(PolicyStatus.PENDING_LETTER_CYCLE, "01/01/2018", true, false, false);
        testCancelLpPolicy(PolicyStatus.PENDING_LETTER_CYCLE, "12/31/2018", false, true, false);
    }

    private void testCancelLpPolicy(PolicyStatus policyStatus, String cancellationDate,
                                    boolean expectedDeleted, boolean expectedUpdated, boolean expectedCancelled) {
        C3Policy policy = C3RuleTestUtil.mockGeneralPolicy(1L, PolicyType.GI_LP, policyStatus, "cov");
        CancellationReason cancellationReason = CancellationReason.BORROWER_POLICY_RECEIVED;
        C3PolicyCancellation c3PolicyCancellation = C3PolicyCancellationUtil.cancelLpPolicy(policy, DATE_FORMATTER.parse(cancellationDate), cancellationReason);
        testPolicyCancellationResults(expectedDeleted, expectedUpdated, expectedCancelled, c3PolicyCancellation, cancellationDate, cancellationReason);
    }

    @Test
    public void cancelLpPolicyAdjustedDate() {
        //mock policy is eff on 1/1/2018 expires on 1/1/2019
        testCancelLpPolicy("10/01/2017", "01/01/2018");
        testCancelLpPolicy("01/01/2018", "01/01/2018");
        testCancelLpPolicy("01/02/2018", "01/02/2018");
        testCancelLpPolicy("12/31/2018", "12/31/2018");
        testCancelLpPolicy("01/01/2019", null);
        testCancelLpPolicy("01/02/2019", null);
    }

    @Test
    public void cancelLpPolicyWithCancellationDate() {
        C3Policy policy = C3RuleTestUtil.mockGeneralPolicy(1L, PolicyType.GI_LP, PolicyStatus.CANCELLED,"cov");
        policy.setCancellationEffectiveDate("07/18/2018");
        CancellationReason cancellationReason = CancellationReason.BORROWER_POLICY_RECEIVED;
        C3PolicyCancellation c3PolicyCancellation = C3PolicyCancellationUtil.cancelLpPolicy(policy, DATE_FORMATTER.parse("10/01/2018"), cancellationReason);
        assertNull(c3PolicyCancellation);
    }

    @Test
    public void cancelLpPolicyWithSameCancellationDate() {
        C3Policy policy = C3RuleTestUtil.mockGeneralPolicy(1L, PolicyType.GI_LP, PolicyStatus.CANCELLED,"cov");
        policy.setCancellationEffectiveDate("07/18/2018");
        CancellationReason cancellationReason = CancellationReason.BORROWER_POLICY_RECEIVED;
        C3PolicyCancellation c3PolicyCancellation = C3PolicyCancellationUtil.cancelLpPolicy(policy, DATE_FORMATTER.parse("07/18/2018"), cancellationReason);
        assertNull(c3PolicyCancellation);
    }
    private void testCancelLpPolicy(String cancellationDate, String expectedCancellationDate) {
        C3Policy policy = C3RuleTestUtil.mockGeneralPolicy(1L, PolicyType.GI_LP, PolicyStatus.PAID, "cov");
        CancellationReason cancellationReason = CancellationReason.BORROWER_POLICY_RECEIVED;
        C3PolicyCancellation c3PolicyCancellation = C3PolicyCancellationUtil.cancelLpPolicy(policy, DATE_FORMATTER.parse(cancellationDate), cancellationReason);
        if (expectedCancellationDate == null) {
            assertNull(c3PolicyCancellation);
        }
        else {
            assertEquals(expectedCancellationDate, c3PolicyCancellation.getCancellationEffectiveDate());
        }
    }

}