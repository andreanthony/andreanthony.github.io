package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3AlertEmail;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3CalculatedCoverageDate;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3AlertEmailBuilder;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3RuleFactory;
import com.jpmorgan.cb.wlt.apis.c3.services.C3RequestPopulationService;
import com.jpmorgan.cb.wlt.apis.c3.services.LenderPlacePolicyService;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.enums.C3AlertEmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralCoverageComputationServiceImpl {

    private static final String USER_ID = "E704298";
    private static final long COLLATERAL_RID = 100L;

    @Mock
    private C3Rule c3Rule1;

    @Mock
    private C3Rule c3Rule2;

    @Mock
    private C3RuleFactory c3RuleFactory;

    @Mock
    private LenderPlacePolicyService lenderPlacePolicyService;

    @Mock
    private C3RequestPopulationService c3RequestPopulationService;

    @Mock
    private PublishEventService publishEventService;

    @Spy
    @InjectMocks
    private CollateralCoverageComputationServiceImpl testObj;

    private List<C3Rule> c3Rules = new ArrayList<>();
    C3RequestDTO c3RequestDTO = new C3RequestDTO();

    @Before
    public void setUp() {
        c3Rules.add(c3Rule1);
        c3Rules.add(c3Rule2);
        when(c3RuleFactory.getC3Rules()).thenReturn(c3Rules);
    }

    @Test
    public void testEvaluate() {
        mockC3Rule(c3Rule1, false);
        mockC3Rule(c3Rule2, false);
        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);
        assertThat(c3ResponseDTO, notNullValue());
        verify(c3Rule1).execute(refEq(c3RequestDTO), eq(c3ResponseDTO));
        verify(c3Rule2).execute(c3RequestDTO, c3ResponseDTO);
    }

    @Test
    public void testEvaluateComplete() {
        mockC3Rule(c3Rule1, true);
        mockC3Rule(c3Rule2, false);
        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);
        assertThat(c3ResponseDTO, notNullValue());
        verify(c3Rule1).execute(refEq(c3RequestDTO), eq(c3ResponseDTO));
        verifyNoMoreInteractions(c3Rule2);
    }

    @Test
    public void testEvaluateByC3RequestCollateralDTO(){
        C3RequestEventDTO c3RequestEventDTO = new C3RequestEventDTO(COLLATERAL_RID, CtracEventType.BORROWER_POLICY_ACCEPTED.getDisplayValue());
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        doReturn(c3RequestDTO).when(c3RequestPopulationService).build(c3RequestEventDTO);
        ArgumentCaptor<C3RequestDTO> argumentCaptor = ArgumentCaptor.forClass(C3RequestDTO.class);
        testObj.evaluate(c3RequestEventDTO);
        verify(c3RequestPopulationService).build(c3RequestEventDTO);
        verify(testObj).evaluate(argumentCaptor.capture());
        assertEquals(c3RequestDTO, argumentCaptor.getValue());
    }

    @Test
    public void apply() {
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.setCollateralRid(COLLATERAL_RID);
        List<Long> policies = new ArrayList<>();
        policies.add(1L);
        policies.add(2L);
        C3CalculatedCoverageDate calculatedCoverageDate =  new C3CalculatedCoverageDate();
        calculatedCoverageDate.setCoverageDate(new Date());
        List<C3AlertEmail> emailAlerts =  new ArrayList<C3AlertEmail>();
        emailAlerts.add( new C3AlertEmailBuilder(C3AlertEmailTemplate.INACTIVE_LP_POLICY)
                .calculatedCoverageDate(calculatedCoverageDate).lpPolicyId(12345L).collateralRid(COLLATERAL_RID).build());
        ArgumentCaptor<List> policyListArgumentCaptor = ArgumentCaptor.forClass(List.class);
        doReturn(policies).when(lenderPlacePolicyService).applyC3Response(c3ResponseDTO);
        c3ResponseDTO.getAlertEmails().addAll(emailAlerts);
        testObj.apply(c3ResponseDTO);
        verify(lenderPlacePolicyService).publishC3WorkflowEvent(policies, COLLATERAL_RID, CtracEventType.C3_COMPLETED);
        verify(lenderPlacePolicyService).publishAlertEmailEvent(emailAlerts.get(0));
        verify(lenderPlacePolicyService).publishC3WorkflowEvent(policyListArgumentCaptor.capture(), eq(COLLATERAL_RID), eq(CtracEventType.C3_COMPLETED));
        assertEquals(policies.size(),policyListArgumentCaptor.getAllValues().get(0).size());
    }

    private void mockC3Rule(C3Rule c3Rule, boolean complete) {
        doAnswer((Answer<Void>) invocation -> {
            C3ResponseDTO internalC3Response = (C3ResponseDTO) invocation.getArguments()[1];
            internalC3Response.setComplete(complete);
            return null;
        }).when(c3Rule).execute(any(C3RequestDTO.class), any(C3ResponseDTO.class));
    }
}
