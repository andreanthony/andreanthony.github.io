package com.jpmorgan.cb.wlt.apis.c3.dtos;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class TestC3ResponseDTO {

    @Test
    public void addPolicyToCancel() {
        C3PolicyCancellation one = new C3PolicyCancellation();
        C3PolicyCancellation two = new C3PolicyCancellation();
        one.setUpdatedExpirationDate("01/01/2018");
        two.setCancellationEffectiveDate("02/01/2018");
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.addPolicyToCancel(one);
        c3ResponseDTO.addPolicyToCancel(two);
        assertFalse(c3ResponseDTO.getPoliciesToCancel().contains(two));
        assertTrue(c3ResponseDTO.getPoliciesToCancel().contains(one));
    }

    @Test
    public void addPolicyToCancelReplace() {
        C3PolicyCancellation one = new C3PolicyCancellation();
        C3PolicyCancellation two = new C3PolicyCancellation();
        one.setUpdatedExpirationDate("01/01/2018");
        two.setCancellationEffectiveDate("02/01/2018");
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.addPolicyToCancel(two);
        c3ResponseDTO.addPolicyToCancel(one);
        assertFalse(c3ResponseDTO.getPoliciesToCancel().contains(two));
        assertTrue(c3ResponseDTO.getPoliciesToCancel().contains(one));
    }

    @Test
    public void testAddPolicyToCancelA() {
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        final Long policyId = 1001L;

        C3PolicyCancellation c3PolicyCancellation = new C3PolicyCancellation();
        c3PolicyCancellation.setPolicyId(policyId);
        c3ResponseDTO.addPolicyToCancel(c3PolicyCancellation);

        c3ResponseDTO.addPolicyToCancel(c3PolicyCancellation);

        assertEquals("When the policy to add is already being canceled don't add it to the list to cancel again."
                , 1, c3ResponseDTO.getPoliciesToCancel().size());
    }

    @Test
    public void testAddPolicyToCancelB() {
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        final Long policyIdA = 1001L;
        final Long policyIdB = 1002L;

        C3PolicyCancellation c3PolicyCancellation = new C3PolicyCancellation();
        c3PolicyCancellation.setPolicyId(policyIdA);
        c3ResponseDTO.addPolicyToCancel(c3PolicyCancellation);

        c3PolicyCancellation = new C3PolicyCancellation();
        c3PolicyCancellation.setPolicyId(policyIdB);
        c3ResponseDTO.addPolicyToCancel(c3PolicyCancellation);

        assertEquals("When the policy to add isn't being canceled yet it needs to be added to the to cancel list."
                , 2, c3ResponseDTO.getPoliciesToCancel().size());
    }

    @Test
    public void testAddPoliciesToCancelA() {
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        final Long policyId = 1001L;

        List<C3PolicyCancellation> policiesToCancel = new ArrayList();

        C3PolicyCancellation c3PolicyCancellation = new C3PolicyCancellation();
        c3PolicyCancellation.setPolicyId(policyId);
        policiesToCancel.add(c3PolicyCancellation);

        c3ResponseDTO.addPoliciesToCancel(policiesToCancel);

        assertEquals("When the policy to add is already being canceled don't add it to the list to cancel again."
                , 1, c3ResponseDTO.getPoliciesToCancel().size());
    }

    @Test
    public void testAddPoliciesToCancelB() {
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        final Long policyIdA = 1001L;
        final Long policyIdB = 1002L;

        List<C3PolicyCancellation> policiesToCancel = new ArrayList();

        C3PolicyCancellation c3PolicyCancellation = new C3PolicyCancellation();
        c3PolicyCancellation.setPolicyId(policyIdA);
        policiesToCancel.add(c3PolicyCancellation);

        c3PolicyCancellation = new C3PolicyCancellation();
        c3PolicyCancellation.setPolicyId(policyIdB);
        policiesToCancel.add(c3PolicyCancellation);

        c3ResponseDTO.addPoliciesToCancel(policiesToCancel);

        assertEquals("When the policy to add isn't being canceled yet it needs to be added to the to cancel list."
                , 2, c3ResponseDTO.getPoliciesToCancel().size());
    }
}
