package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Loan;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanType;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;

public class TestExternallyAgentedRule {

    private ExternallyAgentedRule testObj;

    @Before
    public void setUp() {
        testObj = new ExternallyAgentedRule();
    }

    @Test
    public void testExternallyAgented() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO(LoanType.EXTERNALLY_AGENTED);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.isComplete(), Matchers.is(true));
    }

    @Test
    public void testNotExternallyAgented() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO(LoanType.STANDARD);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.isComplete(), Matchers.is(false));
    }

    private C3RequestDTO mockC3RequestDTO(LoanType loanType) {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        addLoan(loanType, c3RequestDTO);
        return c3RequestDTO;
    }

    private void addLoan(LoanType loanType, C3RequestDTO c3RequestDTO) {
        C3Loan loan = new C3Loan();
        loan.setLoanType(loanType.name());
        c3RequestDTO.getLoans().add(loan);
    }
}
