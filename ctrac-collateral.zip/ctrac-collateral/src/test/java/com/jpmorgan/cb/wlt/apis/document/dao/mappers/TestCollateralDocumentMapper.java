package com.jpmorgan.cb.wlt.apis.document.dao.mappers;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.FileContent;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentDTO;
import com.jpmorgan.cb.wlt.apis.document.dtos.FileContentDTO;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Date;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertFalse;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralDocumentMapper {

    private CollateralDocumentMapper mapper = new CollateralDocumentMapper();
    private static final Long CONST_RID = 1L;
    private static final Long CONST_FILE_CONTENT_RID = 3L;
    private static final String CONST_FILE_NAME = "fileName";
    private static final String CONST_FILE_WITH_EXT = "fileWithExt";
    private static final String CONST_DOC_IDENTIFIER = "docIdentifier";
    private static final Long CONST_COLLATERAL_RID = 2L;
    private static final Date CONST_DOCUMENT_DATE = new DateTime().minusDays(1).toDate();
    private FileContentDTO testFileContentDTO;
    private FileContent testFileContent;

    @Before
    public void setup(){
        testFileContent = new FileContent();
        testFileContent.setRid(CONST_FILE_CONTENT_RID);
        testFileContentDTO = testFileContent.toFileContentDTO();
    }

    @Test
    public void testToDTO() {
        CollateralDocument model = getModel();
        CollateralDocumentDTO actual = mapper.toDTO(model);
        CollateralDocumentDTO expected = getDTO();
        assertEquals(expected, actual);
    }

    @Test
    public void testMapNotChanged() {
        CollateralDocumentDTO dto = getDTO();
        CollateralDocument model = getModel();
        boolean hasChanged = mapper.map(dto, model);
        assertFalse(hasChanged);
        CollateralDocument expected = getModel();
        assertEquals(expected, model);
    }

    @Test
    public void testMapChanged() {
        CollateralDocumentDTO dto = getDTO();
        dto.setDocumentDate(new Date());
        CollateralDocument model = getModel();
        boolean hasChanged = mapper.map(dto, model);
        assertTrue(hasChanged);
    }

    private CollateralDocument getModel() {
        CollateralDocument model = new CollateralDocument();
        model.setRid(CONST_RID);
        model.setCollateralRid(CONST_COLLATERAL_RID);
        model.setFileName(CONST_FILE_NAME);
        model.setFileNameWithExt(CONST_FILE_WITH_EXT);
        model.setDocumentDate(CONST_DOCUMENT_DATE);
        model.setDocIdentifier(CONST_DOC_IDENTIFIER);
        model.setFileContent(testFileContent);
        return model;
    }

    private CollateralDocumentDTO getDTO() {
        CollateralDocumentDTO expected = new CollateralDocumentDTO();
        expected.setRid(CONST_RID);
        expected.setCollateralRid(CONST_COLLATERAL_RID);
        expected.setFileName(CONST_FILE_NAME);
        expected.setFileNameWithExt(CONST_FILE_WITH_EXT);
        expected.setDocumentDate(CONST_DOCUMENT_DATE);
        expected.setDocIdentifier(CONST_DOC_IDENTIFIER);
        expected.setFileContent(testFileContentDTO);
        return expected;
    }
}
