package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.joda.time.DateTime;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;

import static org.junit.Assert.assertEquals;

public class TestC3PolicyIssuanceBuilder {

    @Test
    public void createLpPolicyToIssue() {
        Date coverageDate = new DateTime().withTimeAtStartOfDay().toDate();
        Date expirationDate = new DateTime(coverageDate).plusYears(1).toDate();
        C3PolicyIssuance c3PolicyIssuance = C3PolicyIssuanceBuilder.buildC3PolicyIssuance("cov",
                PolicyType.GI_LP, new BigDecimal(10000), coverageDate);
        assertEquals("cov", c3PolicyIssuance.getCoverageType());
        assertEquals(coverageDate, c3PolicyIssuance.getEffectiveDate_());
        assertEquals(expirationDate, c3PolicyIssuance.getExpirationDate_());
        assertEquals(PolicyType.GI_LP, c3PolicyIssuance.getPolicyType());
        assertEquals(new BigDecimal(10000), c3PolicyIssuance.getCoverageAmount());
        assertEquals(null, c3PolicyIssuance.getInsuredName());
        assertEquals(LPAction.NEW_LP, c3PolicyIssuance.getLpAction());
    }


}