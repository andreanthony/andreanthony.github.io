package com.jpmorgan.cb.wlt.apis.document;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.FileContent;
import com.jpmorgan.cb.wlt.apis.document.services.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import org.springframework.web.util.NestedServletException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doThrow;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestDocumentAPI {

    private static final String CONST_DOCUMENT_API = "/api/document/";
    private static final String CONST_URL_STREAM_SUFFIX = "/stream";
    private static final Long CONST_TEST_DOC_ID = 1L;

    @InjectMocks
    private DocumentAPI api;

    @Mock
    private CollateralDocumentService collateralDocumentService;

    private MockMvc mockMvc;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(api)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testStreamDocument_Success() throws Exception {
        CollateralDocument existingDoc = new CollateralDocument();
        FileContent fileContent = new FileContent();
        fileContent.setFileContent("pdf".getBytes());
        existingDoc.setFileContent(fileContent);
        given(collateralDocumentService.lookupAndValidateDocument(CONST_TEST_DOC_ID)).willReturn(existingDoc);

        MvcResult result = mockMvc.perform(get(CONST_DOCUMENT_API+CONST_TEST_DOC_ID+CONST_URL_STREAM_SUFFIX)
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn();
        assertThat(result.getResponse().getContentAsByteArray()).isEqualTo(fileContent.getFileContent());
    }

    @Test(expected = NestedServletException.class)
    public void testStreamDocument_Failure() throws Exception {
        doThrow(new CtracException("No Doc Found")).when(collateralDocumentService)
                .lookupAndValidateDocument(CONST_TEST_DOC_ID);

        mockMvc.perform(get(CONST_DOCUMENT_API+CONST_TEST_DOC_ID+CONST_URL_STREAM_SUFFIX)
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(status().isBadRequest()).andReturn();
    }

}
