package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.junit.Test;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.mockFloodPolicy;
import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.mockProvidedCoverage;
import static org.junit.Assert.assertEquals;

public class TestGapOnPolicyExpirationRule {
    GapOnPolicyExpirationRule testObj = new GapOnPolicyExpirationRule();

    @Test
    public void execute_isEvaluateGapFalse() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(0, c3ResponseDTO.getExpiringPoliciesWithNoGap().size());
    }

    @Test
    public void execute_noNewC3Policies() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setEvaluateGap(true);
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.ACCEPTED, FloodCoverageType.PRIMARY.name());
        policy.setLpAction("CANCEL_BP");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(0, c3ResponseDTO.getExpiringPoliciesWithNoGap().size());
    }

    @Test
    public void execute_noExpiringPolicies() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setEvaluateGap(true);
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.ACCEPTED, FloodCoverageType.PRIMARY.name());
        policy.setLpAction("NEW_BP");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(0, c3ResponseDTO.getExpiringPoliciesWithNoGap().size());
    }

    @Test
    public void execute_noMatchingCoverage() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setEvaluateGap(true);
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.ACCEPTED, "PRIMARY");
        policy.setLpAction("NEW_BP");
        C3Policy policy1 = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, "EXCESS");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.getBorrowerPolicies().add(policy1);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(0, c3ResponseDTO.getExpiringPoliciesWithNoGap().size());
    }

    @Test
    public void execute_noPolicyIssuanceNeeded() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setEvaluateGap(true);
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.ACCEPTED, "PRIMARY");
        policy.setLpAction("NEW_BP");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3Policy policy1 = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, "PRIMARY");
        Long policyId = 120L;
        policy1.setPolicyId(policyId);
        c3RequestDTO.getBorrowerPolicies().add(policy1);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(1, c3ResponseDTO.getExpiringPoliciesWithNoGap().size());
        assertEquals(policyId, c3ResponseDTO.getExpiringPoliciesWithNoGap().get(0));
    }

    @Test
    public void execute_matchButPolicyIssuanceNeeded() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setEvaluateGap(true);
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.ACCEPTED, "PRIMARY");
        policy.setLpAction("NEW_BP");
        C3Policy policy1 = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, "PRIMARY");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.getBorrowerPolicies().add(policy1);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3PolicyIssuance c3PolicyIssuance = new C3PolicyIssuance();
        c3PolicyIssuance.setEffectiveDate("01/01/2019");
        c3PolicyIssuance.setCoverageType("PRIMARY");
        c3PolicyIssuance.setInsurableAssetId(4001L);
        c3ResponseDTO.getPoliciesToIssue().add(c3PolicyIssuance);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(0, c3ResponseDTO.getExpiringPoliciesWithNoGap().size());
    }

    @Test
    public void execute_notAllInsurableAssetsMatching() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setEvaluateGap(true);
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.ACCEPTED, "PRIMARY");
        policy.setLpAction("NEW_BP");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3Policy policy1 = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, "PRIMARY");
        Long policyId = 120L;
        policy1.setPolicyId(policyId);
        policy1.getProvidedCoverages().add(mockProvidedCoverage(5001L, "PRIMARY"));
        c3RequestDTO.getBorrowerPolicies().add(policy1);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(1, c3ResponseDTO.getExpiringPoliciesWithNoGap().size());
        assertEquals(policyId, c3ResponseDTO.getExpiringPoliciesWithNoGap().get(0));
    }

}