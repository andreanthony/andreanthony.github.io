package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3RuleFactory;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.C3RuleFactoryImpl;
import com.jpmorgan.cb.wlt.apis.c3.services.C3RequestPopulationService;
import com.jpmorgan.cb.wlt.apis.c3.services.LenderPlacePolicyService;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverageRepository;
import com.jpmorgan.cb.wlt.services.Ctrac2ApiService;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class TestCollateralCoverageComputationServiceImplFlood {

    private static final String FLOOD_ZONE_A = "A";
    private static final Long INSURABLE_ASSET_ID_1 = 4001L;
    private static final Long INSURABLE_ASSET_ID_2 = 4002L;
    private static final Long POLICY_ID_1 = 1001L;
    private static final Long POLICY_ID_2 = 1002L;
    private static final Long POLICY_ID_3 = 1003L;
    private static final BigDecimal _500K = new BigDecimal("500000.00");
    private static final BigDecimal _1M = new BigDecimal("1000000.00");
    private static final BigDecimal _1_5M = new BigDecimal("1500000.00");
    private static final BigDecimal _250K = new BigDecimal("250000.00");;
    private static final String _09_01_2017 = "09/01/2017";
    private static final String _08_01_2018 = "08/01/2018";
    private static final String _09_01_2018 = "09/01/2018";
    private static final String _08_01_2019 = "08/01/2019";
    private static final String _09_01_2019 = "09/01/2019";


    @Mock
    private ProofOfCoverageRepository proofOfCoverageRepository;
    @Mock
    private ReferenceDateService referenceDateService;
    @Mock
    private Ctrac2ApiService ctrac2ApiService;
    @Mock
    private PublishEventService publishEventService;
    @Mock
    private C3RequestPopulationService c3RequestPopulationService;
    @Spy
    private C3RuleFactory c3RuleFactory = new C3RuleFactoryImpl();
    @Mock
    private LenderPlacePolicyService lenderPlacePolicyService;

    @InjectMocks
    private CollateralCoverageComputationServiceImpl testObj;

    @Test
    public void testExpiringPolicyNoCoverage() {
        C3RequestDTO c3RequestDTO = new C3RequestDTOBuilder(_09_01_2018, CollateralStatus.PLEDGED, LoanStatus.ACTIVE, FLOOD_ZONE_A)
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K, "COMM")
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_1, PolicyType.NFIP, PolicyStatus.EXPIRING, _09_01_2017, _09_01_2018)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K).build())
                .build();

        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);

        assertThat(c3ResponseDTO.getPoliciesToIssue().size(), Matchers.is(1));
        assertPolicyIssuance(c3ResponseDTO.getPoliciesToIssue().get(0), PolicyType.LP, INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE,
                FloodCoverageType.PRIMARY, _500K, _09_01_2018, _09_01_2019);
        assertThat(c3ResponseDTO.getPoliciesToCancel().size(), Matchers.is(0));
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
    }

    @Test
    public void testExpiringPolicyNoCoverageResidential() {
        C3RequestDTO c3RequestDTO = new C3RequestDTOBuilder(_09_01_2018, CollateralStatus.PLEDGED, LoanStatus.ACTIVE, FLOOD_ZONE_A)
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K, "DW")
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_1, PolicyType.NFIP, PolicyStatus.EXPIRING, _09_01_2017, _09_01_2018)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K).build())
                .build();

        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);

        assertThat(c3ResponseDTO.getPoliciesToIssue().size(), Matchers.is(1));
        assertPolicyIssuance(c3ResponseDTO.getPoliciesToIssue().get(0), PolicyType.LP, INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE,
                FloodCoverageType.PRIMARY, _250K, _09_01_2018, _09_01_2019);
        assertThat(c3ResponseDTO.getPoliciesToCancel().size(), Matchers.is(0));
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
    }

    @Test
    public void testExpiringPolicyPrimaryAndExcess() {
        C3RequestDTO c3RequestDTO = new C3RequestDTOBuilder(_09_01_2018, CollateralStatus.PLEDGED, LoanStatus.ACTIVE, FLOOD_ZONE_A)
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K, "COMM")
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.EXCESS, _1M, "COMM")
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_1, PolicyType.NFIP, PolicyStatus.EXPIRING, _09_01_2017, _09_01_2018)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY_AND_EXCESS, _1_5M).build())
                .build();

        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);

        assertThat(c3ResponseDTO.getPoliciesToIssue().size(), Matchers.is(2));
        assertPolicyIssuance(c3ResponseDTO.getPoliciesToIssue().get(0), PolicyType.LP, INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE,
                FloodCoverageType.PRIMARY, _500K, _09_01_2018, _09_01_2019);
        assertPolicyIssuance(c3ResponseDTO.getPoliciesToIssue().get(1), PolicyType.LP_EXCESS, INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE,
                FloodCoverageType.EXCESS, _1M, _09_01_2018, _09_01_2019);
        assertThat(c3ResponseDTO.getPoliciesToCancel().size(), Matchers.is(0));
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
    }

    @Test
    public void testExpiringPolicyTwoBuildings() {
        C3RequestDTO c3RequestDTO = new C3RequestDTOBuilder(_09_01_2018, CollateralStatus.PLEDGED, LoanStatus.ACTIVE, FLOOD_ZONE_A)
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K, "COMM")
                .requiredFloodCoverage(INSURABLE_ASSET_ID_2, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K, "COMM")
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_1, PolicyType.NFIP, PolicyStatus.EXPIRING, _09_01_2017, _09_01_2018)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_2, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K).build())
                .build();

        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);

        assertThat(c3ResponseDTO.getPoliciesToIssue().size(), Matchers.is(2));
        assertPolicyIssuance(c3ResponseDTO.getPoliciesToIssue().get(0), PolicyType.LP, INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE,
                FloodCoverageType.PRIMARY, _500K, _09_01_2018, _09_01_2019);
        assertPolicyIssuance(c3ResponseDTO.getPoliciesToIssue().get(1), PolicyType.LP, INSURABLE_ASSET_ID_2, InsurableAssetType.STRUCTURE,
                FloodCoverageType.PRIMARY, _500K, _09_01_2018, _09_01_2019);
        assertThat(c3ResponseDTO.getPoliciesToCancel().size(), Matchers.is(0));
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
    }

    @Test
    public void testExpiringPolicyWithMatchingLP() {
        C3RequestDTO c3RequestDTO = new C3RequestDTOBuilder(_09_01_2018, CollateralStatus.PLEDGED, LoanStatus.ACTIVE, FLOOD_ZONE_A)
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K, "COMM")
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.EXCESS, _1M, "COMM")
                .requiredFloodCoverage(INSURABLE_ASSET_ID_2, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, BigDecimal.ZERO, "COMM")
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_1, PolicyType.NFIP, PolicyStatus.EXPIRING, _09_01_2017, _09_01_2018)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_2, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K).build())
                .lpPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_2, PolicyType.LP_EXCESS, PolicyStatus.PAID, _08_01_2018, _08_01_2019)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.EXCESS, _1M).build())
                .build();

        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);

        assertThat(c3ResponseDTO.getPoliciesToIssue().size(), Matchers.is(2));
        assertPolicyIssuance(c3ResponseDTO.getPoliciesToIssue().get(0), PolicyType.LP, INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE,
                FloodCoverageType.PRIMARY, _500K, _09_01_2018, _09_01_2019);
        assertThat(c3ResponseDTO.getPoliciesToCancel().size(), Matchers.is(0));
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
    }

    @Test
    public void testExpiringPolicyWithMultipleExcess() {
        C3RequestDTO c3RequestDTO = new C3RequestDTOBuilder(_09_01_2018, CollateralStatus.PLEDGED, LoanStatus.ACTIVE, FLOOD_ZONE_A)
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K, "COMM")
                .requiredFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.EXCESS, _1M, "COMM")
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_1, PolicyType.NFIP, PolicyStatus.EXPIRING, _09_01_2017, _09_01_2018)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.PRIMARY, _500K).build())
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_2, PolicyType.NFIP, PolicyStatus.EXPIRING, _08_01_2018, _08_01_2019)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.EXCESS, _500K).build())
                .borrowerPolicy(new C3PolicyBuilder(InsuranceType.FLOOD, POLICY_ID_3, PolicyType.NFIP, PolicyStatus.EXPIRING, _08_01_2018, _08_01_2019)
                        .providedFloodCoverage(INSURABLE_ASSET_ID_1, InsurableAssetType.STRUCTURE, FloodCoverageType.EXCESS, _500K).build())
                .build();

        C3ResponseDTO c3ResponseDTO = testObj.evaluate(c3RequestDTO);

        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(1));
        assertThat(c3ResponseDTO.getAlertEmails().get(0).getAlertTemplate(), Matchers.is(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES));
        assertThat(c3ResponseDTO.getPoliciesToIssue().size(), Matchers.is(0));
        assertThat(c3ResponseDTO.getPoliciesToCancel().size(), Matchers.is(0));
    }

    private void assertPolicyIssuance(C3PolicyIssuance policyIssuance, PolicyType policyType, Long insurableAssetId,
                                      InsurableAssetType insurableAssetType, FloodCoverageType coverageType,
                                      BigDecimal coverageAmount, String effectiveDate, String expirationDate) {
        assertThat(policyIssuance.getPolicyType(), Matchers.is(policyType));
        assertThat(policyIssuance.getInsurableAssetId(), Matchers.is(insurableAssetId));
        assertThat(policyIssuance.getInsurableAssetType(), Matchers.is(insurableAssetType));
        assertThat(policyIssuance.getCoverageType_(), Matchers.is(coverageType));
        assertThat(policyIssuance.getCoverageAmount(), Matchers.comparesEqualTo(coverageAmount));
        assertThat(policyIssuance.getEffectiveDate(), Matchers.is(effectiveDate));
        assertThat(policyIssuance.getExpirationDate(), Matchers.is(expirationDate));
    }

    @Test
    public void evaluateGap() {
        C3RequestEventDTO c3RequestEventDTO = new C3RequestEventDTO();
        Long collateralId = 1L;
        c3RequestEventDTO.setCollateralId(collateralId);
        CollateralCoverageComputationServiceImpl c3 = spy(testObj);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        List<Long> expiringPoliciesWithNoGap = c3ResponseDTO.getExpiringPoliciesWithNoGap();
        expiringPoliciesWithNoGap.add(100L);
        doReturn(c3ResponseDTO).when(c3).evaluate(c3RequestEventDTO);
        C3ResponseDTO returned = c3.evaluateGap(c3RequestEventDTO);
        assertEquals(c3ResponseDTO, returned);
        verify(lenderPlacePolicyService).publishC3WorkflowEvent(
                expiringPoliciesWithNoGap, collateralId, CtracEventType.C3_EVALUATE_GAP_COMPLETED);
    }
}
