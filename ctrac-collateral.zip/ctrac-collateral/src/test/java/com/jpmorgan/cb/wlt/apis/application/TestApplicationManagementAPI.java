package com.jpmorgan.cb.wlt.apis.application;

import com.jpmorgan.cb.wlt.apis.application.dto.ApplicationInfoDTO;
import com.jpmorgan.cb.wlt.apis.application.services.ApplicationManagementService;
import com.jpmorgan.cb.wlt.apis.user.services.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.mockito.BDDMockito.given;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class TestApplicationManagementAPI {

    private static final String CONST_APPLICATION_API = "/api/application/";

    @InjectMocks
    private ApplicationManagementAPI api;

    @Mock
    private ApplicationManagementService applicationManagementService;
    @Mock
    private UserService userService;

    private MockMvc mockMvc;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(api)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testGetApplicationInfo() throws Exception {
        ApplicationInfoDTO dto = new ApplicationInfoDTO();
        dto.setRefDate("04/08/2018");
        given(applicationManagementService.getApplicationInfo()).willReturn(dto);

        mockMvc.perform(get(CONST_APPLICATION_API + "info")
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.refDate").value("04/08/2018"))
                .andExpect(status().isOk()).andReturn();
    }

    @Test
    public void testClearUserEntitlementsCache() throws Exception {
        given(userService.clearUserEntitlementsCache()).willReturn(true);

        mockMvc.perform(post(CONST_APPLICATION_API + "entitlements/cache/clear")
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(content().string("true"))
                .andExpect(status().isOk()).andReturn();
    }

}
