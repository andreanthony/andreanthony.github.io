package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ProvidedCoverage;
import com.jpmorgan.cib.wlt.ctrac.enums.*;

import java.math.BigDecimal;

public class C3PolicyBuilder {

    private C3Policy policy = new C3Policy();

    public C3PolicyBuilder(InsuranceType insuranceType, Long policyId, PolicyType policyType, PolicyStatus policyStatus,
                           String effectiveDate, String expirationDate) {
        policy.setInsuranceType(insuranceType.name());
        policy.setPolicyId(policyId);
        policy.setPolicyType(policyType.name());
        policy.setPolicyStatus(policyStatus.name());
        policy.setEffectiveDate(effectiveDate);
        policy.setExpirationDate(expirationDate);
    }

    public C3PolicyBuilder providedFloodCoverage(Long insurableAssetId, InsurableAssetType insurableAssetType,
                                                 FloodCoverageType coverageType, BigDecimal coverageAmount) {
        C3ProvidedCoverage borrowerProvidedCoverage = new C3ProvidedCoverage();
        borrowerProvidedCoverage.setInsurableAssetId(insurableAssetId);
        borrowerProvidedCoverage.setInsurableAssetType(insurableAssetType.name());
        borrowerProvidedCoverage.setCoverageType(coverageType.name());
        borrowerProvidedCoverage.setCoverageAmount(coverageAmount);
        policy.getProvidedCoverages().add(borrowerProvidedCoverage);
        return this;
    }

    public C3PolicyBuilder providedGeneralCoverage(String coverageType, BigDecimal coverageAmount) {
        C3ProvidedCoverage borrowerProvidedCoverage = new C3ProvidedCoverage();
        borrowerProvidedCoverage.setCoverageType(coverageType);
        borrowerProvidedCoverage.setCoverageAmount(coverageAmount);
        policy.getProvidedCoverages().add(borrowerProvidedCoverage);
        return this;
    }

    public C3Policy build() {
        return policy;
    }
}
