package com.jpmorgan.cb.wlt.apis.collateral.details.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralStatus;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.CollateralRepository;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.EmailDetails;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.EmailDetailsRepository;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralValidationService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.RealEstate;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.config.mappings.CollateralDetailsMapping;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.VerifyCollateralEventDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralDetailsServiceImpl {

    private static final Long COLLATERAL_ID = 1L;
    private static final Long NON_EXISTENT_COLLATERAL_ID = 2L;

    @Mock
    private CollateralDetailsMapping collateralMapper;

    @Mock
    private CollateralRepository collateralRepository;

    @Mock
    private CollateralValidationService collateralValidationService;
    @Mock
    private PublishEventService publishEventService;
    @Mock
    private EmailDetailsRepository emailDetailsRepository;

    @InjectMocks
    private CollateralDetailsServiceImpl testObj;

    @Mock
    private Collateral collateral;

    @Mock
    private CollateralDTO collateralDetailsDTO;
    @Mock
    private CollateralSectionService collateralSectionService;
    @Mock
    EmailDetails emailDetails;
    private static final UserRequestInfo CONST_TEST_USER = new UserRequestInfo("testUser");


    @Test
    public void testGetCollateral() {
        when(collateralRepository.findById(COLLATERAL_ID)).thenReturn(Optional.of(collateral));
        when(collateralMapper.map(collateral, CollateralDTO.class)).thenReturn(collateralDetailsDTO);
        assertThat(testObj.getCollateralDetails(COLLATERAL_ID), is(collateralDetailsDTO));
    }

    @Test
    public void testGetCollateralNull() {
        when(collateralRepository.findById(NON_EXISTENT_COLLATERAL_ID)).thenReturn(Optional.empty());
        assertThat(testObj.getCollateralDetails(NON_EXISTENT_COLLATERAL_ID), is(nullValue()));
    }

    @Test
    public void testVerifyCollateral() {
        when(collateralRepository.findById(NON_EXISTENT_COLLATERAL_ID)).thenReturn(Optional.empty());
        assertThat(testObj.getCollateralDetails(NON_EXISTENT_COLLATERAL_ID), is(nullValue()));
    }

    @Test
    public void testPledgeCollateral() {
        when(collateralSectionService.areBasicSectionsVerified(COLLATERAL_ID)).thenReturn(true);
        Collateral testCollateral = new RealEstate();
        when(collateralRepository.getOne(COLLATERAL_ID)).thenReturn(testCollateral);
        testObj.pledgeCollateral(COLLATERAL_ID,CONST_TEST_USER);
        assertThat(testCollateral.getCollateralStatus(),is(CollateralStatus.PLEDGED.name()));
        verify(collateralRepository).save(testCollateral);
    }
    @Test
    public void testSubmitForVarification(){
        UserRequestInfo userRequestInfo=mock(UserRequestInfo.class);
        ArgumentCaptor<VerifyCollateralEventDto> argument = ArgumentCaptor.forClass(VerifyCollateralEventDto.class);
        when(collateralRepository.findById(COLLATERAL_ID)).thenReturn(Optional.of(collateral));
        when(collateralMapper.map(collateral, CollateralDTO.class)).thenReturn(collateralDetailsDTO);
        testObj.submitForVerification(COLLATERAL_ID,userRequestInfo);
        verify(collateralValidationService,times(1)).validateSubmitForVerification(collateralDetailsDTO);
        verify(collateralSectionService,times(1)).advanceAllSections(collateralDetailsDTO);
        verify(publishEventService,times(1)).publishEvent(argument.capture());
        assertEquals(COLLATERAL_ID,argument.getValue().getCollateralId()) ;
        assertEquals(CtracEventType.VERIFY_COLLATERAL.getDisplayValue(),argument.getValue().getEventType());
    }


}
