package com.jpmorgan.cb.wlt.apis.document.dao.mappers;

import com.jpmorgan.cb.wlt.apis.document.dao.FileContent;
import com.jpmorgan.cb.wlt.apis.document.dtos.FileContentDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertFalse;

@RunWith(MockitoJUnitRunner.class)
public class TestFileContentMapper {

    private FileContentMapper mapper = new FileContentMapper();
    private static final Long CONST_RID = 1L;
    private static final byte[] CONST_FILE_CONTENT = "file".getBytes();

    @Test
    public void testToDTO() {
        FileContent model = getModel();
        FileContentDTO actual = mapper.toDTO(model);
        FileContentDTO expected = getDTO();
        assertEquals(expected, actual);
    }

    @Test
    public void testMapNotChanged() {
        FileContentDTO dto = getDTO();
        FileContent model = getModel();
        boolean hasChanged = mapper.map(dto, model);
        assertFalse(hasChanged);
        FileContent expected = getModel();
        assertEquals(expected, model);
    }

    @Test
    public void testMapChanged() {
        FileContentDTO dto = getDTO();
        dto.setFileContent("file2".getBytes());
        FileContent model = getModel();
        boolean hasChanged = mapper.map(dto, model);
        assertTrue(hasChanged);
    }

    private FileContent getModel() {
        FileContent model = new FileContent();
        model.setRid(CONST_RID);
        model.setFileContent(CONST_FILE_CONTENT);
        return model;
    }

    private FileContentDTO getDTO() {
        FileContentDTO expected = new FileContentDTO();
        expected.setRid(CONST_RID);
        expected.setFileContent(CONST_FILE_CONTENT);
        return expected;
    }
}
