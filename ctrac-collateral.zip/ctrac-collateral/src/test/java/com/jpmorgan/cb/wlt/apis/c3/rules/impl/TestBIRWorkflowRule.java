package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ExceptionLevel;
import org.hamcrest.core.Is;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.fail;

public class TestBIRWorkflowRule {
    private static final String USER_ID = "E704298";

    private BIRWorkflowRule testObj;

    @Before
    public void setUp() {
        testObj = new BIRWorkflowRule();
    }

    @Test
    public void testExecute() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setPerformedBy(USER_ID);
        c3RequestDTO.addBorrowerPolicy(mockPolicy(1L, null));
        c3RequestDTO.addBorrowerPolicy(mockPolicy(2L, LPAction.NEW_BP));
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getNewlyVerifiedBorrowerPolicies(), contains(2L));
        assertThat(c3ResponseDTO.getPerformedBy(), is(USER_ID));
    }

    @Test
    public void testExecuteWithPending() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setPerformedBy(USER_ID);
        c3RequestDTO.addBorrowerPolicy(mockPolicy(1L, null));
        c3RequestDTO.addBorrowerPolicy(mockPolicy(2L, LPAction.NEW_BP));
        c3RequestDTO.addBorrowerPolicy(mockPolicy(3L, LPAction.PENDING_C3));
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getNewlyVerifiedBorrowerPolicies(), contains(2L, 3L));
        assertThat(c3ResponseDTO.getPerformedBy(), is(USER_ID));
    }

    @Test
    public void testExecuteNonAlphanumeric() {
        try {
            C3RequestDTO c3RequestDTO = new C3RequestDTO();
            c3RequestDTO.setPerformedBy("<test></test>");
            C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
            testObj.execute(c3RequestDTO, c3ResponseDTO);
        } catch (CtracException e) {
            assertThat(e.getExceptionLevel(), Is.is(ExceptionLevel.GENEOS));
            assertThat(e.getMessage(), containsString("Received a performedBy that is non-alphanumeric"));
        }
    }

    @Test
    public void testExecuteNonAlphanumericNull() {
        try {
            C3RequestDTO c3RequestDTO = new C3RequestDTO();
            c3RequestDTO.setPerformedBy(null);
            C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
            testObj.execute(c3RequestDTO, c3ResponseDTO);
        } catch (CtracException e) {
            fail("Should be able to have performedBy=null");
        }
    }

    private C3Policy mockPolicy(Long policyId, LPAction lpAction) {
        C3Policy c3Policy = C3RuleTestUtil.mockGeneralPolicy(policyId, PolicyType.GI_POLICY, PolicyStatus.ACCEPTED, "cov");
        c3Policy.setLpAction(lpAction != null ? lpAction.name() : null);
        return c3Policy;
    }
}
