package com.jpmorgan.cb.wlt.apis.c3.dtos;

import org.joda.time.DateTime;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TestC3Hold {
    C3Hold c3Hold = new C3Hold();
    Date today = new Date();
    Date plus_1 = new DateTime(new Date()).plusDays(1).toDate();
    Date minus_1 = new DateTime(new Date()).minusDays(1).toDate();
    Date plus_2 = new DateTime(new Date()).plusDays(2).toDate();
    Date minus_2 = new DateTime(new Date()).minusDays(2).toDate();

    @Test
    public void isAfter() {
        c3Hold.setHoldStartDate(today);
        assertTrue(c3Hold.isAfter(minus_1));
        assertFalse(c3Hold.isAfter(today));
        assertFalse(c3Hold.isAfter(plus_1));
    }

    @Test
    public void isActiveCurrentHold() {
        c3Hold.setHoldStartDate(today);
        assertFalse(c3Hold.isActive(minus_1));
        assertTrue(c3Hold.isActive(today));
        assertTrue(c3Hold.isActive(plus_1));
    }

    @Test
    public void isActive_withLpiDate() {
        c3Hold.setHoldStartDate(minus_1);
        c3Hold.setHoldLpiDate(plus_1);
        assertFalse(c3Hold.isActive(minus_2));
        assertTrue(c3Hold.isActive(minus_1));
        assertTrue(c3Hold.isActive(today));
        assertFalse(c3Hold.isActive(plus_1));
        assertFalse(c3Hold.isActive(plus_2));
    }
}