package com.jpmorgan.cb.wlt.apis.application.services.impl;

import com.jpmorgan.cb.wlt.apis.application.dto.ApplicationInfoDTO;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Date;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;

@RunWith(MockitoJUnitRunner.class)
public class TestApplicationManagementServiceImpl {

    @InjectMocks
    private ApplicationManagementServiceImpl applicationManagementService;

    @Mock
    private ReferenceDateService referenceDateService;

    @Test
    public void testGetApplicationInfo(){
        Date curDate = new DateTime().withDate(2018,8,4).toDate();
        given(referenceDateService.getCurrentReferenceDate()).willReturn(curDate);

        ApplicationInfoDTO dto = applicationManagementService.getApplicationInfo();

        assertNotNull(dto);
        assertThat(dto.getRefDate(),is("08/04/2018"));
    }
}
