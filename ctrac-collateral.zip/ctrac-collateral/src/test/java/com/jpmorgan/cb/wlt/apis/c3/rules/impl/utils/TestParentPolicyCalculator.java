package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class TestParentPolicyCalculator {

    private ParentPolicyCalculator calculator;

    @Test
    public void testcalculateParentPolicyNEW_BP() {
        calculateParentPolicy("NEW_BP", null, "PENDING_C3", 1L);
        calculateParentPolicy("PENDING_C3", null, "NEW_BP", 3L);
        calculateParentPolicy(null, "NEW_BP", "PENDING_C3", 2L);
    }
    @Test
    public void testcalculateParentPolicyNull() {
        calculateParentPolicy(null, null, "PENDING_C3", 1L);
        calculateParentPolicy("PENDING_C3", null, null, 2L);
    }
    @Test
    public void testcalculateParentPolicy() {
        calculateParentPolicy("PENDING_C3", "PENDING_C3", "PENDING_C3", 1L);
    }

    private void calculateParentPolicy(String lpAction1, String lpAction2, String lpAction3, Long expected) {
        C3Policy policy1 = new C3Policy();
        policy1.setPolicyId(1L);
        policy1.setLpAction(lpAction1);
        C3Policy policy2 = new C3Policy();
        policy2.setPolicyId(2L);
        policy2.setLpAction(lpAction2);
        C3Policy policy3 = new C3Policy();
        policy3.setPolicyId(3L);
        policy3.setLpAction(lpAction3);
        List<C3Policy> policyList = new ArrayList<>();
        policyList.add(policy1);
        policyList.add(policy2);
        policyList.add(policy3);

        calculator = new ParentPolicyCalculator(policyList);
        assertThat(calculator.calculateParentPolicy().getPolicyId(),is(expected));
    }

 }
