package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class TestAlertFloodMultipleExcessPoliciesRule {

    private AlertFloodMultipleExcessPoliciesRule testObj;

    List<C3PolicyIssuance> refC3PolicyIssuanceList;

    @Before
    public void setUp() {

        testObj = new AlertFloodMultipleExcessPoliciesRule();
        refC3PolicyIssuanceList = stubC3PoliciesToIssueList();
    }

    @Test
    public void testWithSameAlertEmailsandPolicies() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.EXPIRED, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        List<C3PolicyIssuance> c3PolicyIssuanceList =  stubC3PoliciesToIssueList();
        c3ResponseDTO.setPoliciesToIssue(c3PolicyIssuanceList);
        c3ResponseDTO.setAlertEmails(stubC3AlertEmailList());
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(0,c3ResponseDTO.getPoliciesToIssue().size());
        for(C3PolicyIssuance c3PolicyIssuance : refC3PolicyIssuanceList) {
            assertEquals(false , c3ResponseDTO.getPoliciesToIssue().contains(c3PolicyIssuance));
        }
    }


    @Test
    public void testWithDifferentAssetId() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.EXPIRED, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.setPoliciesToIssue(stubC3PoliciesToIssueList());
        c3ResponseDTO.setAlertEmails(stubC3AlertEmailListWithDiffAssetId());
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(1,c3ResponseDTO.getPoliciesToIssue().size());
        for(C3PolicyIssuance c3PolicyIssuance : c3ResponseDTO.getPoliciesToIssue()) {
            assertEquals((Long)30L,c3PolicyIssuance.getInsurableAssetId());
            assertNotEquals((Long)10L,c3PolicyIssuance.getInsurableAssetId());
            assertNotEquals((Long)20L,c3PolicyIssuance.getInsurableAssetId());
        }

    }

    @Test
    public void testWithWithDifferentEmailTemplate() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.EXPIRED, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.setPoliciesToIssue(stubC3PoliciesToIssueList());
        c3ResponseDTO.setAlertEmails(stubC3AlertEmailListWithDiffEmailTemplate());
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(3,c3ResponseDTO.getPoliciesToIssue().size());
        for(C3PolicyIssuance c3PolicyIssuance : refC3PolicyIssuanceList) {
            assertEquals(true , c3ResponseDTO.getPoliciesToIssue().contains(c3PolicyIssuance));
        }
    }


    @Test
    public void testWithWithDifferentEmailTemplate1() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.EXPIRED, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.setPoliciesToIssue(stubC3PoliciesToIssueList());
        c3ResponseDTO.setAlertEmails(stubC3AlertEmailListWithDiffEmailTemplate1());
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(2,c3ResponseDTO.getPoliciesToIssue().size());
        for(C3PolicyIssuance c3PolicyIssuance : c3ResponseDTO.getPoliciesToIssue()) {
            assertNotEquals((Long)10L,c3PolicyIssuance.getInsurableAssetId());
        }
    }

    @Test
    public void testWithWithDifferentInsurableAssetType() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.EXPIRED, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.setPoliciesToIssue(stubC3PoliciesToIssueList());
        c3ResponseDTO.setAlertEmails(stubC3AlertEmailListWithDiffInsurableAssetType());
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertEquals(3,c3ResponseDTO.getPoliciesToIssue().size());
        for(C3PolicyIssuance c3PolicyIssuance : refC3PolicyIssuanceList) {
            assertEquals(true , c3ResponseDTO.getPoliciesToIssue().contains(c3PolicyIssuance));
        }
    }



    private  List<C3PolicyIssuance> stubC3PoliciesToIssueList() {
        List<C3PolicyIssuance> c3PolicyIssuanceList = new ArrayList<C3PolicyIssuance>();
        c3PolicyIssuanceList.add(mockC3PoliciesToIssue(10L,InsurableAssetType.STRUCTURE));
        c3PolicyIssuanceList.add(mockC3PoliciesToIssue(20L,InsurableAssetType.STRUCTURE));
        c3PolicyIssuanceList.add(mockC3PoliciesToIssue(30L,InsurableAssetType.STRUCTURE));
        return c3PolicyIssuanceList;
    }



    private  List<C3AlertEmail> stubC3AlertEmailList() {
        List<C3AlertEmail> c3AlertEmail = new ArrayList<C3AlertEmail>();
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.STRUCTURE,10L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.STRUCTURE,20L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.STRUCTURE,30L, FloodCoverageType.PRIMARY));
        return c3AlertEmail;
    }

    private  List<C3AlertEmail> stubC3AlertEmailListWithDiffAssetId() {
        List<C3AlertEmail> c3AlertEmail = new ArrayList<C3AlertEmail>();
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.STRUCTURE,10L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.STRUCTURE,20L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.STRUCTURE,40L, FloodCoverageType.PRIMARY));
        return c3AlertEmail;
    }


    private  List<C3AlertEmail> stubC3AlertEmailListWithDiffEmailTemplate() {
        List<C3AlertEmail> c3AlertEmail = new ArrayList<C3AlertEmail>();
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.INACTIVE_LP_POLICY,InsurableAssetType.STRUCTURE,10L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.INACTIVE_LP_POLICY,InsurableAssetType.STRUCTURE,20L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.INACTIVE_LP_POLICY,InsurableAssetType.STRUCTURE,30L, FloodCoverageType.PRIMARY));
        return c3AlertEmail;
    }

    private  List<C3AlertEmail> stubC3AlertEmailListWithDiffEmailTemplate1() {
        List<C3AlertEmail> c3AlertEmail = new ArrayList<C3AlertEmail>();
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.STRUCTURE,10L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.INACTIVE_LP_POLICY,InsurableAssetType.STRUCTURE,20L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.INACTIVE_LP_POLICY,InsurableAssetType.STRUCTURE,30L, FloodCoverageType.PRIMARY));
        return c3AlertEmail;
    }


    private  List<C3AlertEmail> stubC3AlertEmailListWithDiffInsurableAssetType() {
        List<C3AlertEmail> c3AlertEmail = new ArrayList<C3AlertEmail>();
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.BUSINESS_INCOME,10L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.BUSINESS_INCOME,20L, FloodCoverageType.PRIMARY));
        c3AlertEmail.add(mockAlertEmailTemplate(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES,InsurableAssetType.BUSINESS_INCOME,30L, FloodCoverageType.PRIMARY));
        return c3AlertEmail;
    }

}