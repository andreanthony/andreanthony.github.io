package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.junit.Test;

import java.util.Arrays;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.mockFloodPolicy;
import static org.junit.Assert.*;

public class TestC3Policy {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    @Test
    public void setCancellationEffectiveDateBeforeEffective() {
        C3Policy testObj = new C3Policy();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setCancellationEffectiveDate("12/31/2018");
        assertEquals("01/01/2019", testObj.getCancellationEffectiveDate());
    }

    @Test
    public void setCancellationEffectiveDateAfterEffective() {
        C3Policy testObj = new C3Policy();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setCancellationEffectiveDate("01/02/2019");
        assertEquals("01/02/2019", testObj.getCancellationEffectiveDate());
    }

    @Test
    public void setCancellationEffectiveDateWhenEffectiveDateIsNull() {
        C3Policy testObj = new C3Policy();
        testObj.setCancellationEffectiveDate("01/02/2019");
        assertEquals("01/02/2019", testObj.getCancellationEffectiveDate());
    }

    @Test
    public void setNullCancellationEffectiveDate() {
        C3Policy testObj = new C3Policy();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setCancellationEffectiveDate(null);
        assertNull(testObj.getCancellationEffectiveDate());
    }

    @Test
    public void setNullCancellationEffectiveDateWhenEffectiveDateIsNull() {
        C3Policy testObj = new C3Policy();
        testObj.setCancellationEffectiveDate(null);
        assertNull(testObj.getCancellationEffectiveDate());
    }

    @Test
    public void setExpirationDateBeforeEffective() {
        C3Policy testObj = new C3Policy();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setExpirationDate("12/31/2018");
        assertEquals("01/01/2019", testObj.getExpirationDate());
    }

    @Test
    public void setExpirationDateAfterEffective() {
        C3Policy testObj = new C3Policy();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setExpirationDate("01/02/2019");
        assertEquals("01/02/2019", testObj.getExpirationDate());
    }

    @Test
    public void setExpirationDateWhenEffectiveDateIsNull() {
        C3Policy testObj = new C3Policy();
        testObj.setExpirationDate("01/02/2019");
        assertEquals("01/02/2019", testObj.getExpirationDate());
    }

    @Test
    public void setNullExpirationDate() {
        C3Policy testObj = new C3Policy();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setExpirationDate(null);
        assertNull(testObj.getExpirationDate());
    }

    @Test
    public void setNullExpirationDateWhenEffectiveDateIsNull() {
        C3Policy testObj = new C3Policy();
        testObj.setExpirationDate(null);
        assertNull(testObj.getExpirationDate());
    }

    @Test
    public void isNewlyAcceptedFalse() {
        C3Policy policy = mockFloodPolicy(1L, PolicyType.PRIVATE, PolicyStatus.ACCEPTED, FloodCoverageType.PRIMARY.name());
        assertFalse(policy.isNewlyAccepted());

        policy.setLpAction(LPAction.CANCEL_BP.name());
        assertFalse(policy.isNewlyAccepted());
    }

    @Test
    public void isNewlyAcceptedTrue() {
        C3Policy policy = mockFloodPolicy(1L, PolicyType.PRIVATE, PolicyStatus.ACCEPTED, FloodCoverageType.PRIMARY.name());
        policy.setLpAction(LPAction.NEW_BP.name());
        assertTrue(policy.isNewlyAccepted());

        policy.setLpAction(LPAction.PENDING_C3.name());
        assertTrue(policy.isNewlyAccepted());
    }

    @Test
    public void isExpiring() {
        C3Policy policy = new C3Policy();
        Arrays.stream(PolicyStatus.values()).forEach(policyStatus -> {
            policy.setPolicyStatus(policyStatus.name());
            assertEquals(policyStatus.isExpiring(), policy.isExpiring());
        });
    }

    @Test
    public void hasMatchingCoverage() {
        assertEquals(true, buildPolicy("PRIMARY", 5L)
                .hasMatchingCoverage("PRIMARY", 5L));
        assertEquals(false, buildPolicy("EXCESS", 5L)
                .hasMatchingCoverage("PRIMARY", 5L));
        assertEquals(false, buildPolicy("PRIMARY", 25L)
                .hasMatchingCoverage("PRIMARY", 5L));
        assertEquals(false, buildPolicy("EXCESS", 25L)
                .hasMatchingCoverage("PRIMARY", 5L));
        assertEquals(true, buildPolicy("PRIMARY", 5L)
                .hasMatchingCoverage("PRIMARY_AND_EXCESS", 5L));
        assertEquals(true, buildPolicy("EXCESS", 5L)
                .hasMatchingCoverage("PRIMARY_AND_EXCESS", 5L));
    }

    @Test
    public void isProvidingCoverageOn() {
        C3Policy policy = buildPolicy("PRIMARY", 5L);
        policy.setEffectiveDate("01/01/2019");
        policy.setExpirationDate("01/01/2020");
        assertTrue(policy.isProvidingCoverageOn("PRIMARY", 5L, DATE_FORMATTER.parse("02/01/2019")));
        assertFalse(policy.isProvidingCoverageOn("EXCESS", 5L, DATE_FORMATTER.parse("02/01/2019")));
        assertFalse(policy.isProvidingCoverageOn("PRIMARY", 53L, DATE_FORMATTER.parse("02/01/2019")));
        assertFalse(policy.isProvidingCoverageOn("PRIMARY", 5L, DATE_FORMATTER.parse("02/01/2020")));
    }

    public C3Policy buildPolicy(String coverageType, long insurableAssetId) {
        C3Policy policy = new C3Policy();
        C3ProvidedCoverage coverage = buildC3ProvidedCoverage(coverageType, insurableAssetId);
        policy.getProvidedCoverages().add(coverage);
        return policy;
    }

    public C3ProvidedCoverage buildC3ProvidedCoverage(String coverageType, long insurableAssetId) {
        C3ProvidedCoverage coverage = new C3ProvidedCoverage();
        coverage.setCoverageType(coverageType);
        coverage.setInsurableAssetId(insurableAssetId);
        return coverage;
    }

    @Test
    public void hasMatchingCoverageForPolicy() {
        C3Policy policy = buildPolicy("PRIMARY", 5L, "PRIMARY", 25L);

        assertTrue(buildPolicy("PRIMARY", 5L).hasMatchingCoverage(policy));
        assertFalse(buildPolicy("EXCESS", 25L).hasMatchingCoverage(policy));
        assertTrue(
                buildPolicy("PRIMARY", 5L, "PRIMARY", 25L).hasMatchingCoverage(policy));
        assertFalse(
                buildPolicy("EXCESS", 5L, "EXCESS", 25L).hasMatchingCoverage(policy));
        assertFalse(
                buildPolicy("PRIMARY", 15L, "PRIMARY", 35L).hasMatchingCoverage(policy));
    }

    public C3Policy buildPolicy(String coverage1, Long asset1, String coverage2, Long asset2) {
        C3Policy policy = buildPolicy(coverage1, asset1);
        policy.getProvidedCoverages().add(buildC3ProvidedCoverage(coverage2, asset2));
        return policy;
    }
}