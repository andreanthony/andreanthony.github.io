package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestC3RequiredCoverage {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    @Test
    public void testHoldDates() {
        testGetHoldDates(getC3Hold("01/01/2019", "02/01/2019", false));
        testGetHoldDates(getC3Hold(null, "02/01/2019", false));
        testGetHoldDates(getC3Hold("01/01/2019", null, true));
        testGetHoldDates(getC3Hold("01/01/2019", null, false));
    }

    private C3Hold getC3Hold(String startDate, String lpiDate, boolean newHold) {
        C3Hold c3Hold = new C3Hold();
        c3Hold.setHoldStartDate(DATE_FORMATTER.parse(startDate));
        c3Hold.setHoldLpiDate(DATE_FORMATTER.parse(lpiDate));
        c3Hold.setNewHold(newHold);
        return c3Hold;
    }

    private void testGetHoldDates(C3Hold c3Hold) {
        C3RequiredCoverage testObj = new C3RequiredCoverage();
        testObj.setHold(c3Hold);
        assertEquals(c3Hold.getHoldStartDate(), testObj.getHoldStartDate());
        assertEquals(c3Hold.getHoldLpiDate(), testObj.getHoldLpiDate());
        assertEquals(c3Hold.isNewHold(), testObj.hasNewHold());
    }


}