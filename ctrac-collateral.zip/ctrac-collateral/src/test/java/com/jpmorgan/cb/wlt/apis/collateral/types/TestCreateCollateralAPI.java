package com.jpmorgan.cb.wlt.apis.collateral.types;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerServiceImpl;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateBusinessAssetsDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateCollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateRealEstateDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.services.CollateralCreationService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestCreateCollateralAPI {

    private static final String API = "/api/collaterals/types";
    private static final String LINE_OF_BUSINESS = "Business Banking";
    private static final Long COLLATERAL_RID = 1L;
    private static final String DESCRIPTION = "My Collateral Description";
    private static final String STREET_ADDRESS = "10 S DEARBORN ST";
    private static final String COUNTY = "COOK";
    private static final String CITY = "CHICAGO";
    private static final String STATE = "IL";
    private static final String ZIP_CODE = "60603";
    private static final UserRequestInfo CONST_TEST_USER = new UserRequestInfo("testUser");
    private static final ObjectMapper MAPPER;
    private static final ObjectWriter WRITER;

    static {
        MAPPER = new ObjectMapper();
        MAPPER.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        WRITER = MAPPER.writer().withDefaultPrettyPrinter();
    }

    @Mock
    private CollateralCreationService collateralCreationService;

    @InjectMocks
    private CreateCollateralAPI testObj;

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testCreateCollateralRealEstate() {
        testCreateCollateral(stubCreateRealEstateCollateralDTO(), API + "/realestate", CollateralType.REAL_ESTATE);
    }

    @Test
    public void testCreateCollateralBusinessAssets() {
        testCreateCollateral(stubCreateBusinessAssetsDTO(), API + "/businessassets", CollateralType.BUSINESS_ASSETS);
    }

    private void testCreateCollateral(CreateRealEstateDTO createCollateralDTO, String api, CollateralType collateralType) {
        try {
            CollateralDTO collateralDTO = stubCollateralDetailsDTO();
            when(collateralCreationService.createCollateral(any(CreateRealEstateDTO.class), eq(collateralType), eq(CONST_TEST_USER))).thenReturn(collateralDTO);
            mockMvc.perform(post(api).contentType(APPLICATION_JSON_UTF8)
                    .requestAttr(CtracAuthenticationManagerServiceImpl.USER_REQUEST_INFO,CONST_TEST_USER)
                    .content(WRITER.writeValueAsString(createCollateralDTO)))
                    .andExpect(jsonPath("$.rid").value(COLLATERAL_RID))
                    .andExpect(jsonPath("$.streetAddress").value(STREET_ADDRESS))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail();
        }
    }

    private void testCreateCollateral(CreateBusinessAssetsDTO createCollateralDTO, String api, CollateralType collateralType) {
        try {
            CollateralDTO collateralDTO = stubCollateralDetailsDTO();
            when(collateralCreationService.createCollateral(any(CreateBusinessAssetsDTO.class), eq(collateralType), eq(CONST_TEST_USER))).thenReturn(collateralDTO);
            mockMvc.perform(post(api).contentType(APPLICATION_JSON_UTF8)
                    .requestAttr(CtracAuthenticationManagerServiceImpl.USER_REQUEST_INFO,CONST_TEST_USER)
                    .content(WRITER.writeValueAsString(createCollateralDTO)))
                    .andExpect(jsonPath("$.rid").value(COLLATERAL_RID))
                    .andExpect(jsonPath("$.streetAddress").value(STREET_ADDRESS))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail();
        }
    }

    private CreateRealEstateDTO stubCreateRealEstateCollateralDTO() {
        CreateRealEstateDTO createCollateralDTO = new CreateRealEstateDTO();
        stubCreateCollateralDTO(createCollateralDTO);
        return createCollateralDTO;
    }

    private CreateBusinessAssetsDTO stubCreateBusinessAssetsDTO() {
        CreateBusinessAssetsDTO createCollateralDTO = new CreateBusinessAssetsDTO();
        stubCreateCollateralDTO(createCollateralDTO);
        createCollateralDTO.setDescription(DESCRIPTION);
        createCollateralDTO.setCollateralType(CollateralType.BUSINESS_ASSETS.name());
        return createCollateralDTO;
    }

    private void stubCreateCollateralDTO(CreateRealEstateDTO createCollateralDTO) {
        createCollateralDTO.setLineOfBusiness(LINE_OF_BUSINESS);
        createCollateralDTO.setStreetAddress(STREET_ADDRESS);
        createCollateralDTO.setCounty(COUNTY);
        createCollateralDTO.setCity(CITY);
        createCollateralDTO.setState(STATE);
        createCollateralDTO.setZipCode(ZIP_CODE);
        createCollateralDTO.setCollateralType(CollateralType.REAL_ESTATE.name());
    }

    private CollateralDTO stubCollateralDetailsDTO() {
        CollateralDTO collateralDetailsDTO = new CollateralDTO();
        collateralDetailsDTO.setRid(COLLATERAL_RID);
        collateralDetailsDTO.setStreetAddress(STREET_ADDRESS);
        return collateralDetailsDTO;
    }
}
