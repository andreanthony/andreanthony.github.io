package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;

public class TestFloodZoneRule {

    private FloodZoneRule testObj;

    @Before
    public void setUp() {
        testObj = new FloodZoneRule();
    }

    @Test
    public void testZoneA() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO("A1");
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertNoCancellations(c3ResponseDTO);
    }

    @Test
    public void testZoneV() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO("V1");
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertNoCancellations(c3ResponseDTO);
    }

    @Test
    public void testZoneX() {
        C3RequestDTO c3RequestDTO = mockC3RequestDTO("X", "09/07/2018");
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getPolicyId(), is(1L));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getCancellationEffectiveDate(), is("09/07/2018"));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getCancellationReason(), is(CancellationReason.INSURANCE_NOT_NEEDED));
        assertThat(c3RequestDTO.isInsuranceTypeRequested("FLOOD"), is(false));
        assertThat(c3ResponseDTO.isComplete(), is(false));
    }

    private C3RequestDTO mockC3RequestDTO(String floodZone) {
        return mockC3RequestDTO(floodZone, null);
    }

    private C3RequestDTO mockC3RequestDTO(String floodZone, String dateOfMapChange) {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy c3Policy = C3RuleTestUtil.mockGeneralPolicy(1L, PolicyType.LP, PolicyStatus.PAID, "cov");
        c3Policy.setInsuranceType(InsuranceType.FLOOD.name());
        c3RequestDTO.getLpPolicies().add(c3Policy);
        c3RequestDTO.getFloodDetermination().setFloodZone(floodZone);
        c3RequestDTO.getFloodDetermination().setDateOfMapChange(dateOfMapChange);
        return c3RequestDTO;
    }

    private void assertNoCancellations(C3ResponseDTO c3ResponseDTO) {
        assertThat(c3ResponseDTO.isComplete(), Matchers.is(false));
        assertThat(c3ResponseDTO.getPoliciesToCancel(), is(empty()));
    }
}
