package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.junit.Test;

import java.math.BigDecimal;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.*;
import static org.junit.Assert.*;

public class TestLenderPlaceMatchingRule {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    private LenderPlaceMatchingRule testObj = new LenderPlaceMatchingRule();

    @Test
    public void testExistingPolicySameAmountCoverageDate() {
        testExecute(10000, "PRIMARY", "01/01/2018",
                10000, "PRIMARY", "01/01/2018","FLOOD", 0, 0);
        testExecute(10000, "cov", "01/01/2018",
                10000, "cov", "01/01/2018","GENERAL", 0, 0);
    }

    @Test
    public void testExistingPolicyAmountLess() {
        testExecute(10000, "cov", "01/01/2018",
                9000, "cov", "01/01/2018","FLOOD", 1, 1);
        testExecute(10000, "cov", "01/01/2018",
                9000, "cov", "01/01/2018","GENERAL", 1, 1);
    }

    @Test
    public void testExistingPolicyAmountMore() {
        testExecute(10000, "cov", "01/01/2018",
                11000, "cov", "01/01/2018","FLOOD", 1, 1);
        testExecute(10000, "cov", "01/01/2018",
                11000, "cov", "01/01/2018","GENERAL", 1, 1);
    }

    @Test
    public void testNoExistingPolicy() {
        testExecute(10000, "cov", "01/01/2018",
                0, "", "","FLOOD", 1, 0);
        testExecute(10000, "cov", "01/01/2018",
                0, "", "","GENERAL", 1, 0);
    }

    @Test
    public void testExistingPolicyDiffCoverage() {
        testExecute(10000, "PRIMARY", "01/01/2018",
                10000, "EXCESS", "01/01/2018","FLOOD", 1, 0);
        testExecute(10000, "cov1", "01/01/2018",
                10000, "cov2", "01/01/2018","GENERAL", 1, 0);
    }
    @Test
    public void testExistingPolicyNotEffectiveOnCalculatedDate() {
        testExecute(10000, "cov", "01/01/2019",
                10000, "cov", "01/01/2018","FLOOD", 1, 0);
        testExecute(10000, "cov", "01/01/2019",
                10000, "cov", "01/01/2018","GENERAL", 1, 0);
    }

    @Test
    public void testExistingPolicyNotRequired() {
        testExecute(0, "cov", "01/01/2018",
                10000, "cov", "01/01/2018","FLOOD", 0, 1);
        testExecute(0, "cov", "01/01/2018",
                10000, "cov", "01/01/2018","GENERAL", 0, 1);
    }

    private void testExecute(int amountToIssue, String coverageToIssue, String dateToIssue,
                             int providedAmount, String providedCoverage, String effectiveDate,  String insuranceType,
                             int policiesToIssue, int policiesToCancel) {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();

        populateRequestResponse(amountToIssue, coverageToIssue, dateToIssue, providedAmount, providedCoverage, effectiveDate, insuranceType, c3RequestDTO, c3ResponseDTO);
        testObj.execute(c3RequestDTO, c3ResponseDTO);

        assertEquals("policiesToIssue", policiesToIssue, c3ResponseDTO.getPoliciesToIssue().size());
        assertEquals("policiesToCancel", policiesToCancel, c3ResponseDTO.getPoliciesToCancel().size());
        if (policiesToCancel > 0) {
            assertNotNull("Reason", c3ResponseDTO.getPoliciesToCancel().get(0).getCancellationReason());
        }
    }

    private void populateRequestResponse(int amountToIssue, String coverageToIssue, String dateToIssue, int providedAmount,
                                         String providedCoverage, String effectiveDate, String insuranceType, C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        boolean flood = insuranceType.equals("FLOOD");
        PolicyType policyType = flood ? PolicyType.LP : PolicyType.GI_LP;
        Long policyId = 1L;
        if (providedAmount > 0) {
            C3Policy policy = flood ? mockFloodPolicy(policyId, policyType, PolicyStatus.PAID, providedCoverage) :
                    mockGeneralPolicy(policyId, policyType, PolicyStatus.PAID, providedCoverage);
            policy.getProvidedCoverages().get(0).setCoverageAmount(new BigDecimal(providedAmount));
            policy.getProvidedCoverages().get(0).setInsurableAssetId(flood ? INSURABLE_ASSET_ID : null);
            policy.setEffectiveDate(effectiveDate);
            c3RequestDTO.getLpPolicies().add(policy);
        }
        if (amountToIssue > 0) {
            C3PolicyIssuance c3PolicyIssuance = new C3PolicyIssuance();
            c3PolicyIssuance.setCoverageAmount(new BigDecimal(amountToIssue));
            c3PolicyIssuance.setEffectiveDate(dateToIssue);
            c3PolicyIssuance.setCoverageType(coverageToIssue);
            c3PolicyIssuance.setInsurableAssetId(flood ? INSURABLE_ASSET_ID : null);
            c3PolicyIssuance.setGapBorrowerPolicyId(policyId);
            c3ResponseDTO.getPoliciesToIssue().add(c3PolicyIssuance);
        }
        C3CalculatedCoverageDate c3CalculatedCoverageDate = new C3CalculatedCoverageDate();
        c3CalculatedCoverageDate.setCoverageDate(DATE_FORMATTER.parse(dateToIssue));
        c3CalculatedCoverageDate.setCoverageType(coverageToIssue);
        c3CalculatedCoverageDate.setInsuranceType(insuranceType);
        c3CalculatedCoverageDate.setPolicyId(1L);
        c3CalculatedCoverageDate.setInsurableAssetId(flood ? INSURABLE_ASSET_ID : null);
        if (flood) {
            c3ResponseDTO.getCalculatedFloodCoverageDates().add(c3CalculatedCoverageDate);
        }
        else {
            c3ResponseDTO.getCalculatedGeneralCoverageDates().add(c3CalculatedCoverageDate);
        }
    }

    @Test
    public void processRenewalPoliciesRenewal() {
        renewal(10000, "cov", "01/01/2019",
                10000, "cov", "01/01/2018", "FLOOD", true, false);
    }
    @Test
    public void processRenewalPoliciesIssueWithCancellation() {
        renewal(10000, "cov", "12/01/2018",
                20000, "cov", "01/01/2018", "FLOOD", false, true);
    }
    @Test
    public void processRenewalPoliciesDiffCoverage() {
        renewal(10000, "cov", "01/01/2019",
                10000, "cov1", "01/01/2018", "FLOOD", false, false);
    }
    @Test
    public void processRenewalPoliciesNotOverlapping() {
        renewal(10000, "cov", "02/01/2019",
                10000, "cov", "01/01/2018","FLOOD", false, false);
    }

    private void renewal(int amountToIssue, String coverageToIssue, String dateToIssue,
                         int providedAmount, String providedCoverage, String effectiveDate,  String insuranceType,
                         boolean renewal, boolean issueWithCancel) {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        populateRequestResponse(amountToIssue, coverageToIssue, dateToIssue, providedAmount, providedCoverage, effectiveDate, insuranceType, c3RequestDTO, c3ResponseDTO);
        testObj.processRenewalPolicies(c3RequestDTO, c3ResponseDTO);

        C3PolicyIssuance c3PolicyIssuance = c3ResponseDTO.getPoliciesToIssue().get(0);
        C3Policy policy = c3RequestDTO.getLpPolicies().get(0);
        if (renewal) {
            assertEquals("parentRid", policy.getPolicyId(), c3PolicyIssuance.getParentPolicyId());
            assertEquals("LPAction", LPAction.RENEW_LP, c3PolicyIssuance.getLpAction());
            assertEquals("PolicyStatus", PolicyStatus.PRE_INVOICED, c3PolicyIssuance.getPolicyStatus());
        }
        else if (issueWithCancel) {
            assertEquals("parentRid", policy.getPolicyId(), c3PolicyIssuance.getParentPolicyId());
            assertNotEquals("LPAction", LPAction.RENEW_LP, c3PolicyIssuance.getLpAction());
        }
        else {
            assertNull("parentRid", c3PolicyIssuance.getParentPolicyId());
            assertNull("LPAction", c3PolicyIssuance.getLpAction());
        }
    }
}