package com.jpmorgan.cb.wlt.apis.c3;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.services.C3AdminService;
import com.jpmorgan.cb.wlt.apis.c3.services.CollateralCoverageComputationService;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3WorkflowRequestEventDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.Collections;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.refEq;
import static org.mockito.Mockito.verify;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestC3API {

    private static final String API = "/api/c3";

    private static final ObjectWriter WRITER;
    private static final Long COLLATERAL_ID = 1L;

    static {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        WRITER = mapper.writer().withDefaultPrettyPrinter();
    }

    @Mock
    private CollateralCoverageComputationService c3Service;

    @Mock
    private C3AdminService c3AdminService;

    @InjectMocks
    private C3API testObj;

    private MockMvc mockMvc;

    private C3RequestEventDTO request = new C3RequestEventDTO(COLLATERAL_ID, CtracEventType.BORROWER_POLICY_ACCEPTED.getDisplayValue());

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testEvaluateAPI() {
        try {
            C3RequestDTO c3RequestDTO = new C3RequestDTO();
            mockMvc.perform(post(API + "/evaluate")
                    .contentType(APPLICATION_JSON_UTF8)
                    .content(WRITER.writeValueAsString(c3RequestDTO)))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testEvaluateAndExecuteAPI() {
        try {
            mockMvc.perform(post(API)
                    .contentType(APPLICATION_JSON_UTF8)
                    .content(WRITER.writeValueAsString(request)))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testAdminCancelLpAPI() {
        C3WorkflowRequestEventDTO workflowRequestEventDTO = new C3WorkflowRequestEventDTO();
        workflowRequestEventDTO.setProofOfCoverageRids(Collections.singletonList(5L));
        try {
            mockMvc.perform(post(API + "/admin/cancel")
                    .contentType(APPLICATION_JSON_UTF8)
                    .content(WRITER.writeValueAsString(workflowRequestEventDTO)))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail(e.getMessage());
        }
        verify(c3AdminService).cancel(refEq(workflowRequestEventDTO));
    }

    @Test
    public void testEvaluateGapAPI() {
        try {
            C3RequestDTO c3RequestDTO = new C3RequestDTO();
            mockMvc.perform(post(API + "/evaluate/gap")
                    .contentType(APPLICATION_JSON_UTF8)
                    .content(WRITER.writeValueAsString(c3RequestDTO)))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

}
