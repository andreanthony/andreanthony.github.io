package com.jpmorgan.cb.wlt.apis.collateral.sections.impl;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.CollateralRepository;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionStatus;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dao.SectionStatus;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dao.SectionStatusRepository;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dtos.SectionStatusDto;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.RealEstate;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.floodDetermination.dao.DeterminationDetailsViewRepository;
import com.jpmorgan.cb.wlt.apis.policy.dao.*;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.repository.RequiredCoverageViewRepository;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralRequiredCoverageSource;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository.GeneralRequiredCoverageSourceRepository;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.SectionUpdatedEventDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.hamcrest.core.Is;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralSectionStatusImpl {

    private static final Long COLLATERAL_ID = 1L;
    private static final Long NON_EXISTENT_COLLATERAL_ID = 2L;
    private static final UserRequestInfo CONST_TEST_USER = new UserRequestInfo("testUser");

    @Mock
    private CollateralRepository collateralRepository;

    @Mock
    private SectionStatusRepository sectionStatusRepository;

    @Spy
    @InjectMocks
    private CollateralSectionStatusImpl testObj;

    @Mock
    private Collateral collateral;

    @Captor
    private ArgumentCaptor<List<SectionStatus>> argumentCaptor;

    @Mock
    private PublishEventService publishEventService;

    @Mock
    ProofOfCoverageRepository proofOfCoverageRepository;
    @Mock
    GeneralRequiredCoverageSourceRepository generalRequiredCoverageSourceRepository;
    @Mock
    CollateralInsuranceRepository collateralInsuranceRepository;
    @Mock
    DeterminationDetailsViewRepository determinationDetailsViewRepository;
    @Mock
    RequiredCoverageViewRepository requiredCoverageViewRepository;

    @Captor
    private ArgumentCaptor<SectionUpdatedEventDTO> sectionUpdatedEventCaptor;

    @Mock private List<SectionStatus> sectionStatuses;


    @Before
    public void setup(){
        UserEntitlementsDTO userEntitlement = new UserEntitlementsDTO();
        userEntitlement.setFirstName("testUser");
        userEntitlement.setLastName("testUser");
        userEntitlement.setJanusUsername("testUser");
        CONST_TEST_USER.setUserEntitlementsDto(userEntitlement);
    }

    @Test
    public void testInitialize() {
        when(collateralRepository.findById(COLLATERAL_ID)).thenReturn(Optional.of(collateral));
        testObj.initializeCollateralSections(COLLATERAL_ID, CONST_TEST_USER);
        verifySectionStatuses(CollateralSectionStatus.DRAFT);
    }

    @Test
    public void testInitializeNoCollateral() {
        try {
            when(collateralRepository.findById(NON_EXISTENT_COLLATERAL_ID)).thenReturn(Optional.empty());
            testObj.initializeCollateralSections(NON_EXISTENT_COLLATERAL_ID, CONST_TEST_USER);
        } catch (CtracException e) {
            assertThat(e.getMessage(), containsString("No collateral for initializeCollateralSections, rid=2"));
            verifyZeroInteractions(sectionStatusRepository);
            return;
        }
        fail();
    }

    @Test
    public void testSubmitForVerification_CreateSection_On_Missing() {
        SectionStatus newSection = new SectionStatus();
        newSection.setSectionId(CollateralSection.GENERAL_INSURANCE_POLICIES.name());
        given(sectionStatusRepository.findByCollateral_RidAndSectionId(
                COLLATERAL_ID, CollateralSection.GENERAL_INSURANCE_POLICIES.name())).willReturn(newSection);

        testObj.edit(COLLATERAL_ID, CollateralSection.GENERAL_INSURANCE_POLICIES, CONST_TEST_USER);

        verify(sectionStatusRepository).save(newSection);
        assertThat(newSection.getStatusId(),is(CollateralSectionStatus.PENDING_VERIFICATION.name()));
    }

    @Test
    public void testVerifySection() {
        SectionStatus sectionStatus = mockSection(CollateralSection.COLLATERAL_BASIC_DETAILS, CollateralSectionStatus.PENDING_VERIFICATION);
        testObj.verify(COLLATERAL_ID, CollateralSection.COLLATERAL_BASIC_DETAILS, CONST_TEST_USER);
        InOrder inOrder = inOrder(sectionStatus, sectionStatusRepository);
        inOrder.verify(sectionStatus).setStatusId(CollateralSectionStatus.VERIFIED.name());
        inOrder.verify(sectionStatusRepository).save(sectionStatus);
    }

    private SectionStatus mockSection(CollateralSection section, CollateralSectionStatus status) {
        SectionStatus sectionStatus = mock(SectionStatus.class);
        when(sectionStatus.getStatusId()).thenReturn(status.name());
        when(sectionStatusRepository.findByCollateral_RidAndSectionId(COLLATERAL_ID, section.name())).thenReturn(sectionStatus);
        return sectionStatus;
    }

    @Test
    public void testEventEditGI() {
        mockSection(CollateralSection.GENERAL_INSURANCE_POLICIES, CollateralSectionStatus.VERIFIED);
        testObj.edit(COLLATERAL_ID, CollateralSection.GENERAL_INSURANCE_POLICIES, CONST_TEST_USER);
        verifyAction(CollateralSection.GENERAL_INSURANCE_POLICIES, CollateralScreenAction.EDIT);
    }

    @Test
    public void testEventEditNonGI() {
        mockSection(CollateralSection.COLLATERAL_BASIC_DETAILS, CollateralSectionStatus.VERIFIED);
        testObj.edit(COLLATERAL_ID, CollateralSection.COLLATERAL_BASIC_DETAILS, CONST_TEST_USER);
        verifyAction(CollateralSection.COLLATERAL_BASIC_DETAILS, CollateralScreenAction.EDIT);
    }

    @Test
    public void testEventVerifyGI() {
        mockSection(CollateralSection.GENERAL_INSURANCE_POLICIES, CollateralSectionStatus.PENDING_VERIFICATION);
        testObj.verify(COLLATERAL_ID, CollateralSection.GENERAL_INSURANCE_POLICIES, CONST_TEST_USER);
        verifyAction(CollateralSection.GENERAL_INSURANCE_POLICIES, CollateralScreenAction.VERIFY);
    }

    @Test
    public void testEventVerifyNonGI() {
        mockSection(CollateralSection.COLLATERAL_BASIC_DETAILS, CollateralSectionStatus.PENDING_VERIFICATION);
        testObj.verify(COLLATERAL_ID, CollateralSection.COLLATERAL_BASIC_DETAILS, CONST_TEST_USER);
        verifyAction(CollateralSection.COLLATERAL_BASIC_DETAILS, CollateralScreenAction.VERIFY);
    }

    @Test
    public void testVerifySectionMissing() {
        try {
            testObj.verify(COLLATERAL_ID, CollateralSection.COLLATERAL_BASIC_DETAILS, CONST_TEST_USER);
        } catch (CtracException e) {
            assertThat(e.getMessage(), containsString("Invalid request"));
        }
    }

    @Test
    public void testVerifySectionDraft() {
        testVerifySectionWithException(CollateralSectionStatus.DRAFT);
    }

    @Test
    public void testVerifySectionVerified() {
        testVerifySectionWithException(CollateralSectionStatus.VERIFIED);
    }

    private void testVerifySectionWithException(CollateralSectionStatus collateralSectionStatus) {
        try {
            SectionStatus sectionStatus = mock(SectionStatus.class);
            when(sectionStatus.getStatusId()).thenReturn(collateralSectionStatus.name());
            when(sectionStatusRepository.findByCollateral_RidAndSectionId(COLLATERAL_ID, CollateralSection.COLLATERAL_BASIC_DETAILS.name())).thenReturn(sectionStatus);
            testObj.verify(COLLATERAL_ID, CollateralSection.COLLATERAL_BASIC_DETAILS, CONST_TEST_USER);
        } catch (CtracException e) {
            assertThat(e.getMessage(), containsString("Invalid request"));
            verify(sectionStatusRepository, never()).save(any(SectionStatus.class));
            verifyNoMoreInteractions(publishEventService);
            return;
        }
        fail();
    }

    @Test
    public void testgetSectionStatuses(){
        when(sectionStatusRepository.findByCollateralRid(COLLATERAL_ID)).thenReturn(createSectionStatus());
        List<SectionStatusDto> sectionStatusDtos= testObj.getSectionStatuses(COLLATERAL_ID);
        assertEquals(COLLATERAL_ID,sectionStatusDtos.get(0).getCollateralRid());

    }

    @Test
    public void testAllowAnyVerification(){
        List<SectionStatus> sectionaStatuses=createSectionStatus();
        sectionaStatuses.get(0).setStatusId("PENDING_VERIFICATION");
        sectionaStatuses.get(1).setStatusId("PENDING_VERIFICATION");
        when(sectionStatusRepository.findByCollateralRid(COLLATERAL_ID)).thenReturn(sectionaStatuses);
        testObj.allowAnyVerification(COLLATERAL_ID);
        verify(testObj,times(0)).allowForVerificationProofOfCoverage(COLLATERAL_ID);
        verify(testObj,times(0)).allowForVerificationRequiredCoverageSource(COLLATERAL_ID);
        assertEquals("ADMIN",sectionaStatuses.get(0).getModifiedBy());
        assertEquals("ADMIN",sectionaStatuses.get(1).getModifiedBy());
        //junit for proof of coverage section
        sectionaStatuses.get(0).setStatusId("VERIFIED");
        sectionaStatuses.get(1).setStatusId("VERIFIED");
        sectionaStatuses.get(3).setStatusId("PENDING_VERIFICATION");
        List<CollateralInsuranceViewData> collateralInsuranceViewDataList=createInsurableAssetforSectionalStatus();
        when(collateralInsuranceRepository.findByCollateralRidAndProofOfCoveragePolicyStatusIn(COLLATERAL_ID,
                Collections.singletonList(PolicyStatus.PENDING_VERIFICATION.name()))).thenReturn(collateralInsuranceViewDataList);
        testObj.allowAnyVerification(COLLATERAL_ID);
        verify(testObj,times(1)).allowForVerificationProofOfCoverage(COLLATERAL_ID);
        verify(testObj,times(0)).allowForVerificationRequiredCoverageSource(COLLATERAL_ID);
        assertEquals("ADMIN",collateralInsuranceViewDataList.get(0).getProofOfCoverage().getUpdatedBy());
        //junit for require Coverage
        sectionaStatuses.get(3).setStatusId("VERIFIED");
        sectionaStatuses.get(2).setStatusId("PENDING_VERIFICATION");
        List<GeneralRequiredCoverageSource> sourceList = createGIRequireCoverage();
                when(generalRequiredCoverageSourceRepository.findByCollateralRid(COLLATERAL_ID)).thenReturn(sourceList);
        testObj.allowAnyVerification(COLLATERAL_ID);
        verify(testObj,times(1)).allowForVerificationRequiredCoverageSource(COLLATERAL_ID);
        assertEquals("ADMIN",sourceList.get(0).getUpdatedBy());

    }

    @Test
    public void TestAdvanceSectionStatus(){
        List<SectionStatus> sectionStatusList=createSectionalStatus();
        CollateralDTO collateralDTO=new CollateralDTO();
        collateralDTO.setRid(COLLATERAL_ID);
        when(sectionStatusRepository.findByCollateralRid(collateralDTO.getRid())).thenReturn(sectionStatusList);
        testObj.advanceAllSections(collateralDTO);
        for(SectionStatus sectionStatus : sectionStatusList){
            if(sectionStatus.getSectionId().equals(CollateralSection.COLLATERAL_BASIC_DETAILS.name()) || sectionStatus.getSectionId().equals(CollateralSection.LOAN_BORROWER.name())){
                assertEquals("PENDING_VERIFICATION",sectionStatus.getStatusId());
            }else{
                assertEquals("VERIFIED",sectionStatus.getStatusId());
            }
        }
    }
    @Test
    public void TestAdvanceSectionStatus_ProofOfCoverage(){
        List<SectionStatus> sectionStatusList=createSectionalStatus();
        CollateralDTO collateralDTO=new CollateralDTO();
        collateralDTO.setRid(COLLATERAL_ID);
        when(sectionStatusRepository.findByCollateralRid(collateralDTO.getRid())).thenReturn(sectionStatusList);
        ProofOfCoverage proofOfCoverage=getGeneralInsuranceProofOfCoverage();
        List<ProofOfCoverage> proofOfCoverages=new ArrayList<>();
        proofOfCoverages.add(proofOfCoverage);
        when(proofOfCoverageRepository.findByCollateralIdAndStatus(anyLong(),anyList())).thenReturn(proofOfCoverages);
        testObj.advanceAllSections(collateralDTO);
        for(SectionStatus sectionStatus : sectionStatusList){
            if(sectionStatus.getSectionId().equals(CollateralSection.COLLATERAL_BASIC_DETAILS.name()) ||
                    sectionStatus.getSectionId().equals(CollateralSection.LOAN_BORROWER.name()) ||
            sectionStatus.getSectionId().equals(CollateralSection.GENERAL_INSURANCE_POLICIES.name())){
                assertEquals("PENDING_VERIFICATION",sectionStatus.getStatusId());
            }else{
                assertEquals("VERIFIED",sectionStatus.getStatusId());
            }
        }
    }

    private ProofOfCoverage getGeneralInsuranceProofOfCoverage(){
        ProofOfCoverage GIProofOfCoverage=new GeneralInsurance();
        return GIProofOfCoverage;
    }

    private List<SectionStatus> createSectionalStatus(){
        List<SectionStatus> sectionStatusList=new ArrayList<>();
        SectionStatus sectionStatusOfCollateralBasicDetails=createSectionalStatusObj();
        sectionStatusOfCollateralBasicDetails.setSectionId(CollateralSection.COLLATERAL_BASIC_DETAILS.name());
        sectionStatusList.add(sectionStatusOfCollateralBasicDetails);
        SectionStatus sectionStatusLoanBorrower=createSectionalStatusObj();
        sectionStatusLoanBorrower.setSectionId(CollateralSection.LOAN_BORROWER.name());
        sectionStatusList.add(sectionStatusLoanBorrower);
        SectionStatus sectionStatusOfFloodHazardDetermination=createSectionalStatusObj();
        sectionStatusOfFloodHazardDetermination.setSectionId(CollateralSection.FLOOD_HAZARD_DETERMINATION_FORM.name());
        sectionStatusList.add(sectionStatusOfFloodHazardDetermination);
        SectionStatus sectionStatusOfFloodRequireInsurance=createSectionalStatusObj();
        sectionStatusOfFloodRequireInsurance.setSectionId(CollateralSection.FLOOD_REQUIRED_INSURANCE_COVERAGE.name());
        sectionStatusList.add(sectionStatusOfFloodRequireInsurance);
        SectionStatus sectionStatusOfGeneralRequireInsurance=createSectionalStatusObj();
        sectionStatusOfGeneralRequireInsurance.setSectionId(CollateralSection.GENERAL_REQUIRED_INSURANCE_COVERAGE.name());
        sectionStatusList.add(sectionStatusOfGeneralRequireInsurance);
        SectionStatus sectionStatusOfFloodInsurancePolicy=createSectionalStatusObj();
        sectionStatusOfFloodInsurancePolicy.setSectionId(CollateralSection.FLOOD_INSURANCE_POLICIES.name());
        sectionStatusList.add(sectionStatusOfFloodInsurancePolicy);
        SectionStatus sectionStatusOfGeneralInsurancePolicy=createSectionalStatusObj();
        sectionStatusOfGeneralInsurancePolicy.setSectionId(CollateralSection.GENERAL_INSURANCE_POLICIES.name());
        sectionStatusList.add(sectionStatusOfGeneralInsurancePolicy);
        SectionStatus sectionStatusOfWorkFlowDetails=createSectionalStatusObj();
        sectionStatusOfWorkFlowDetails.setStatusId("VERIFIED");
        sectionStatusOfWorkFlowDetails.setSectionId(CollateralSection.WORKFLOW_DETAILS.name());
        sectionStatusList.add(sectionStatusOfWorkFlowDetails);

        return sectionStatusList;

    }

    private SectionStatus createSectionalStatusObj(){
        SectionStatus sectionStatus=new SectionStatus();
        sectionStatus.setRid(new Random().nextLong());
        sectionStatus.setCollateral(getCollateral());
        sectionStatus.setStatusId("DRAFT");
        sectionStatus.setModifiedBy("ADMIN");
        return sectionStatus;
    }
    private List<GeneralRequiredCoverageSource> createGIRequireCoverage(){
        List<GeneralRequiredCoverageSource> generalRequiredCoverageSources=new ArrayList<>();
        GeneralRequiredCoverageSource generalRequiredCoverageSource=new GeneralRequiredCoverageSource();
        generalRequiredCoverageSource.setRid(1000l);
        generalRequiredCoverageSource.setUpdatedBy("LOCAL");
        generalRequiredCoverageSource.setStatus("PENDING_VERIFICATION");
        generalRequiredCoverageSources.add(generalRequiredCoverageSource);
        return generalRequiredCoverageSources;

    }

    private List<CollateralInsuranceViewData> createInsurableAssetforSectionalStatus(){
        List<CollateralInsuranceViewData> collateralInsuranceViewDataList=new ArrayList<>();
        CollateralInsuranceViewData collateralInsuranceViewData=new CollateralInsuranceViewData();
        Collateral collateral=getCollateral();
        ProofOfCoverage proofOfCoverage=new GeneralInsurance();
        proofOfCoverage.setRid(1000l);
        proofOfCoverage.setUpdatedBy("LOCAL");
        proofOfCoverage.setPolicyStatus("PENDING_VERIFICATION");
        collateralInsuranceViewData.setCollateral(collateral);
        collateralInsuranceViewData.setProofOfCoverage(proofOfCoverage);
        collateralInsuranceViewDataList.add(collateralInsuranceViewData);
        return collateralInsuranceViewDataList;
    }

    private List<SectionStatus> createSectionStatus(){
        Collateral collateral = getCollateral();
        List<SectionStatus> sectionStatuses=new ArrayList<>();
        //sectional status for collateral Basic Details
        SectionStatus sectionStatusBasicDetails=new SectionStatus();
        sectionStatusBasicDetails.setRid(1001l);
        sectionStatusBasicDetails.setModifiedBy("LOCAL");
        sectionStatusBasicDetails.setSectionId("COLLATERAL_BASIC_DETAILS");
        sectionStatusBasicDetails.setStatusId("VERIFIED");
        sectionStatusBasicDetails.setCollateral(collateral);
        sectionStatuses.add(sectionStatusBasicDetails);
        //sectional status for loan borrower
        SectionStatus sectionStatusLoanBrowwer=new SectionStatus();
        sectionStatusLoanBrowwer.setRid(1002l);
        sectionStatusLoanBrowwer.setModifiedBy("LOCAL");
        sectionStatusLoanBrowwer.setSectionId("LOAN_BORROWER");
        sectionStatusLoanBrowwer.setStatusId("VERIFIED");
        sectionStatusLoanBrowwer.setCollateral(collateral);
        sectionStatuses.add(sectionStatusLoanBrowwer);
        //sectional details for GENERAL_REQUIRED_INSURANCE_COVERAGE
        SectionStatus sectionStatusLGIRequireCoverage=new SectionStatus();
        sectionStatusLGIRequireCoverage.setRid(1003l);
        sectionStatusLGIRequireCoverage.setModifiedBy("LOCAL");
        sectionStatusLGIRequireCoverage.setSectionId("GENERAL_REQUIRED_INSURANCE_COVERAGE");
        sectionStatusLGIRequireCoverage.setStatusId("VERIFIED");
        sectionStatusLGIRequireCoverage.setCollateral(collateral);
        sectionStatuses.add(sectionStatusLGIRequireCoverage);
        //sectional details for GENERAL_INSURANCE_POLICIES
        SectionStatus sectionStatusLGIPolicy=new SectionStatus();
        sectionStatusLGIPolicy.setRid(1004l);
        sectionStatusLGIPolicy.setModifiedBy("LOCAL");
        sectionStatusLGIPolicy.setSectionId("GENERAL_INSURANCE_POLICIES");
        sectionStatusLGIPolicy.setStatusId("VERIFIED");
        sectionStatusLGIPolicy.setCollateral(collateral);
        sectionStatuses.add(sectionStatusLGIPolicy);

        return sectionStatuses;
    }

    private Collateral getCollateral() {
        Collateral collateral=new RealEstate();
        collateral.setRid(COLLATERAL_ID);
        return collateral;
    }

    private void verifySectionStatuses(CollateralSectionStatus collateralSectionStatus) {
        verify(sectionStatusRepository).saveAll(argumentCaptor.capture());
        List<SectionStatus> sectionStatuses = argumentCaptor.getValue();
        Set<CollateralSection> collateralSectionSet = new HashSet<>();
        for (SectionStatus sectionStatus : sectionStatuses) {
            CollateralSection collateralSection = CollateralSection.valueOf(sectionStatus.getSectionId());
            collateralSectionSet.add(collateralSection);
            assertThat(sectionStatus.getStatusId(), is(collateralSectionStatus.name()));
        }
        assertThat(collateralSectionSet.size(), is(CollateralSection.values().length));
    }

    private void verifyAction(CollateralSection expectedSection, CollateralScreenAction expectedAction) {
        verify(publishEventService).publishEvent(sectionUpdatedEventCaptor.capture());
        SectionUpdatedEventDTO eventDTO = sectionUpdatedEventCaptor.getValue();
        assertThat(eventDTO.getCollateralId(), Is.is(COLLATERAL_ID));
        assertThat(eventDTO.getAction(), Is.is(expectedAction.name()));
        assertThat(eventDTO.getCollateralSection(), Is.is(expectedSection.name()));
    }
}
