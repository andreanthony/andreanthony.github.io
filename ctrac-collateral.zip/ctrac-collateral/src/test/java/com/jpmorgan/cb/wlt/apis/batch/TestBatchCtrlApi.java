package com.jpmorgan.cb.wlt.apis.batch;

import com.jpmorgan.cb.wlt.apis.batch.services.BatchCtrlService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import static org.mockito.BDDMockito.given;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestBatchCtrlApi {


    private static final String CONST_BATCH_CTRL_API = "/api/batchInfo";

    @InjectMocks
    private BatchCtrlApi api;

    @Mock
    private BatchCtrlService batchCtrlService;

    private MockMvc mockMvc;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.standaloneSetup(api)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testIsBatchRunningTrue() throws Exception {
        BatchCtrlDTO batchCtrlDTO = new BatchCtrlDTO();
        batchCtrlDTO.setBatchRunning(true);
        given(batchCtrlService.isBatchRunning()).willReturn(batchCtrlDTO.isBatchRunning());

        mockMvc.perform(get(CONST_BATCH_CTRL_API)
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.batchRunning").value("true"))
                .andExpect(status().isOk()).andReturn();
    }

    @Test
    public void testIsBatchRunningFalse() throws Exception {
        BatchCtrlDTO batchCtrlDTO = new BatchCtrlDTO();
        batchCtrlDTO.setBatchRunning(false);
        given(batchCtrlService.isBatchRunning()).willReturn(batchCtrlDTO.isBatchRunning());

        mockMvc.perform(get(CONST_BATCH_CTRL_API)
                .contentType(APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.batchRunning").value("false"))
                .andExpect(status().isOk()).andReturn();
    }
}