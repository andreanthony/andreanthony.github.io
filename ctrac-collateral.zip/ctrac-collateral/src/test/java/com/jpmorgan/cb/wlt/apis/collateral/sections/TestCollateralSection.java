package com.jpmorgan.cb.wlt.apis.collateral.sections;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralSection {

    @Test
    public void testValues() {
        CollateralSection[] collateralSections = CollateralSection.values();
        assertThat(collateralSections.length, is(8));
       }
    @Test
    public void testGetBasicCollateralSections() {
        assertThat(CollateralSection.getBasicCollateralSections().size(), is(2));
        assertTrue(CollateralSection.getBasicCollateralSections().contains(CollateralSection.COLLATERAL_BASIC_DETAILS));
        assertTrue(CollateralSection.getBasicCollateralSections().contains(CollateralSection.LOAN_BORROWER));
        assertFalse(CollateralSection.getBasicCollateralSections().contains(CollateralSection.GENERAL_REQUIRED_INSURANCE_COVERAGE));
    }
}
