package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.collateral.owner.services.CollateralOwnerService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionStatus;
import com.jpmorgan.cb.wlt.apis.floodDetermination.dao.FloodDetermination;
import com.jpmorgan.cb.wlt.apis.floodDetermination.services.FloodDeterminationService;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanStatus;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanType;
import com.jpmorgan.cb.wlt.apis.loan.services.impl.LoanServiceImpl;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyCollateralDetailsDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyService;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.HoldHistoryView;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.repository.HoldHistoryViewRepository;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dto.FloodRequiredCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.flood.services.FloodRequiredCoverageService;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageRequirementDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageSourceDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralCoverageService;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.impl.GeneralRequiredCoverageSourceServiceImpl;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.ListUtils;
import org.hamcrest.core.Is;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestC3RequestPopulationServiceImpl {

    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    private static final String USER_ID = "E704298";
    private static final String LINE_OF_BUSINESS = "Business Banking";
    private static final String DESCRIPTION = "My Collateral Description";
    private static final String STREET_ADDRESS = "10 S DEARBORN ST";
    private static final String UNIT_OR_BUILDING = "MAIL CODE 123";
    private static final String COUNTY = "COOK";
    private static final String CITY = "CHICAGO";
    private static final String STATE = "IL";
    private static final String ZIP_CODE = "60603";

    @Mock
    private ReferenceDateService referenceDateService;
    @Mock
    private CollateralDetailsService collateralDetailsService;
    @Mock
    private LoanServiceImpl loanServiceImpl;
    @Mock
    private GeneralRequiredCoverageSourceServiceImpl generalRequiredCoverageSourceService;
    @Mock
    private FloodRequiredCoverageService floodRequiredCoverageService;
    @Mock
    private GeneralCoverageService generalCoverageService;
    @Mock
    private PolicyService policyService;
    @Mock FloodDeterminationService floodDeterminationService;
    @Mock private CollateralOwnerService collateralOwnerService;

    @Mock
    private HoldHistoryViewRepository holdHistoryViewRepository;
    private DefaultDateFormatter defaultDateFormatter = new DefaultDateFormatter();
    private Long COLLATERAL_ID = 1L;
    private Date refDate = new Date();

    @Spy
    @InjectMocks
    C3RequestPopulationServiceImpl testObj;

    @Before
    public void setUp() {
        doReturn(refDate).when(referenceDateService).getCurrentReferenceDate();
    }

    @Test
    public void testPopulate() {
        CollateralDTO collateralDTO  = buildCollateralDTO("PLEGED", "10/01/2018", COLLATERAL_ID);
        doReturn(collateralDTO).when(collateralDetailsService).getCollateralDetails(COLLATERAL_ID);

        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = new GeneralRequiredCoverageSourceDTO();
        GeneralRequiredCoverageDTO generalRequiredCoverageDTO = new GeneralRequiredCoverageDTO();
        generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages().add(generalRequiredCoverageDTO);
        GeneralCoverageRequirementDTO generalCoverageRequirementDTO = new GeneralCoverageRequirementDTO();
        generalCoverageRequirementDTO.setVerifiedRequirementSource(generalRequiredCoverageSourceDTO);
        doReturn(generalCoverageRequirementDTO).when(generalRequiredCoverageSourceService).getByCollateralId(COLLATERAL_ID);
        List<LoanDTO> loans = new ArrayList<>();
        LoanDTO loanDTO = new LoanDTO();
        loanDTO.setLoanType(LoanType.STANDARD.name());
        loanDTO.setReleaseDate(new Date("07/10/2018"));
        loanDTO.setStatus(LoanStatus.RELEASED.name());
        loans.add(loanDTO);
        doReturn(loans).when(loanServiceImpl).getLoans(COLLATERAL_ID);

        //populatePolicies is called once

        List<FloodRequiredCoverageDTO> floodRequiredCoverageDTOs = new ArrayList<>();
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = new FloodRequiredCoverageDTO();
        floodRequiredCoverageDTO.setStatus("VERIFIED");
        floodRequiredCoverageDTOs.add(floodRequiredCoverageDTO);
        doReturn(floodRequiredCoverageDTOs).when(floodRequiredCoverageService).getByCollateralId(COLLATERAL_ID);
        List<GeneralCoverageDTO> generalCoverageDTOs = new ArrayList<>();
        when(generalCoverageService.getGeneralCoverageTypes()).thenReturn(generalCoverageDTOs);
        List<HoldHistoryView> holdHistoryViews = new ArrayList<>();
        when(holdHistoryViewRepository.findByCollateralRid(COLLATERAL_ID)).thenReturn(holdHistoryViews);

        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        testObj.populate(collateralDTO.getRid(), c3RequestDTO);
        verify(testObj, times(1)).populate(collateralDTO.getRid(), c3RequestDTO);
        verify(testObj).getFloodRequiredCoverages(collateralDTO, holdHistoryViews);
        verify(testObj).getGeneralRequiredCoverages(collateralDTO);
        verify(testObj).buildC3RequiredCoverageDTO(generalRequiredCoverageDTO, generalCoverageDTOs);
        verify(testObj).buildC3RequiredCoverageDTO(floodRequiredCoverageDTO, holdHistoryViews);
        verify(testObj).buildC3LoanDTO(loanDTO);
        verify(testObj).populateFloodDetermination(collateralDTO,c3RequestDTO );
        String expected = defaultDateFormatter.print(refDate);
        assertEquals(expected, c3RequestDTO.getCurrentReferenceDate());
        assertEquals("10/01/2018", c3RequestDTO.getCollateralReleaseDate());
        assertEquals(LoanType.STANDARD.name(),c3RequestDTO.getLoans().get(0).getLoanType());
        assertEquals(LoanStatus.RELEASED.name(),c3RequestDTO.getLoans().get(0).getStatus());
        assertEquals("07/10/2018", c3RequestDTO.getLoans().get(0).getReleasedDate());
        assertEquals(COLLATERAL_ID, c3RequestDTO.getCollateralRid());
    }

    @Test
    public void testBuild() {
        C3RequestEventDTO c3RequestEventDTO = new C3RequestEventDTO(COLLATERAL_ID, CtracEventType.COVERAGE_REQUIREMENTS_VERIFIED.getDisplayValue());
        c3RequestEventDTO.setAddedAndRemovedCoverages(true);
        c3RequestEventDTO.setCollateralId(COLLATERAL_ID);
        c3RequestEventDTO.setInsuranceType(InsuranceType.GENERAL.name());
        c3RequestEventDTO.setPerformedBy(USER_ID);
        prepareC3RequestDTO();
        C3RequestDTO c3RequestDTO = testObj.build(c3RequestEventDTO);
        verify(testObj).populate(COLLATERAL_ID, c3RequestDTO);
        assertTrue(c3RequestDTO.isAddedAndRemovedCoveragesOnly());
        assertThat(c3RequestDTO.getPerformedBy(), Is.is(USER_ID));
    }

    private void prepareC3RequestDTO() {
        CollateralDTO collateralDTO = createCollateralDTO(new CollateralDTO());
        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = getGeneralRequiredCoverageSourceDTO(new GeneralRequiredCoverageSourceDTO());
        GeneralCoverageRequirementDTO generalCoverageRequirementDTO = mockGeneralCoverageRequirementDTO(new GeneralRequiredCoverageSourceDTO(), generalRequiredCoverageSourceDTO);
        when(collateralDetailsService.getCollateralDetails(any(Long.class))).thenReturn(collateralDTO);
        when(generalRequiredCoverageSourceService.getByCollateralId(any(Long.class))).thenReturn(generalCoverageRequirementDTO);
    }

    @Test (expected = CtracException.class)
    public void testBuildException() {
        C3RequestEventDTO c3RequestEventDTO = new C3RequestEventDTO(COLLATERAL_ID, CtracEventType.BORROWER_POLICY_ACCEPTED.getDisplayValue());
        c3RequestEventDTO.setAddedAndRemovedCoverages(true);
        c3RequestEventDTO.setCollateralId(COLLATERAL_ID);
        c3RequestEventDTO.setInsuranceType(InsuranceType.GENERAL.name());
        testObj.build(c3RequestEventDTO);
    }

    @Test
    public void testBuildFloodRemap() {
        C3RequestEventDTO c3RequestEventDTO = new C3RequestEventDTO(COLLATERAL_ID, CtracEventType.COVERAGE_REQUIREMENTS_VERIFIED.getDisplayValue());
        c3RequestEventDTO.setAddedAndRemovedCoverages(false);
        c3RequestEventDTO.setCollateralId(COLLATERAL_ID);
        c3RequestEventDTO.setInsuranceType(null);
        c3RequestEventDTO.setFloodRemapZoneIn(true);
        Date floodDate = new Date();
        doReturn(floodDate).when(referenceDateService).addBusinessDays(1, refDate);
        prepareC3RequestDTO();
        C3RequestDTO c3RequestDTO = testObj.build(c3RequestEventDTO);
        verify(testObj).populate(COLLATERAL_ID, c3RequestDTO);
        verify(referenceDateService).addCalendarDays(45, floodDate);
        assertEquals(InsuranceType.FLOOD.name(), c3RequestDTO.getInsuranceType());
    }

    @Test (expected = CtracException.class)
    public void testBuildFloodRemapException() {
        C3RequestEventDTO c3RequestEventDTO = new C3RequestEventDTO(COLLATERAL_ID, CtracEventType.BORROWER_POLICY_ACCEPTED.getDisplayValue());
        c3RequestEventDTO.setAddedAndRemovedCoverages(false);
        c3RequestEventDTO.setCollateralId(COLLATERAL_ID);
        c3RequestEventDTO.setInsuranceType(InsuranceType.FLOOD.name());
        c3RequestEventDTO.setEventType("Flood Remap");
        testObj.build(c3RequestEventDTO);
    }

    @Test
    public void testPopulateRequiredCoverages() {
        CollateralDTO collateralDTO  = buildCollateralDTO("PLEGED", "10/01/2018", COLLATERAL_ID);
        doReturn(collateralDTO).when(collateralDetailsService).getCollateralDetails(COLLATERAL_ID);
        collateralDTO.setRid(COLLATERAL_ID);
        List<FloodRequiredCoverageDTO> floodRequiredCoverageDTOs = new ArrayList<>();
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = new FloodRequiredCoverageDTO();
        floodRequiredCoverageDTO.setStatus("VERIFIED");
        floodRequiredCoverageDTOs.add(floodRequiredCoverageDTO);
        doReturn(floodRequiredCoverageDTOs).when(floodRequiredCoverageService).getByCollateralId(COLLATERAL_ID);
        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = new GeneralRequiredCoverageSourceDTO();
        GeneralRequiredCoverageDTO generalRequiredCoverageDTO = new GeneralRequiredCoverageDTO();
        generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages().add(generalRequiredCoverageDTO);
        GeneralCoverageRequirementDTO generalCoverageRequirementDTO = new GeneralCoverageRequirementDTO();
        generalCoverageRequirementDTO.setVerifiedRequirementSource(generalRequiredCoverageSourceDTO);
        doReturn(generalCoverageRequirementDTO).when(generalRequiredCoverageSourceService).getByCollateralId(COLLATERAL_ID);
        List<GeneralCoverageDTO> generalCoverageDTOs = new ArrayList<>();
        when(generalCoverageService.getGeneralCoverageTypes()).thenReturn(generalCoverageDTOs);
        List<HoldHistoryView> holdHistoryViews = new ArrayList<>();
        when(holdHistoryViewRepository.findByCollateralRid(COLLATERAL_ID)).thenReturn(holdHistoryViews);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        testObj.populate(COLLATERAL_ID, c3RequestDTO);
        verify(testObj).buildC3RequiredCoverageDTO(generalRequiredCoverageDTO, generalCoverageDTOs);
        verify(testObj).buildC3RequiredCoverageDTO(floodRequiredCoverageDTO, holdHistoryViews);
        assertEquals(2, c3RequestDTO.getRequiredCoverages().size());
    }

    @Test
    public void testPopulateRequiredCoveragesFloodOnly() {
        CollateralDTO collateralDTO  = buildCollateralDTO("PLEGED", "10/01/2018", COLLATERAL_ID);
        doReturn(collateralDTO).when(collateralDetailsService).getCollateralDetails(COLLATERAL_ID);
        collateralDTO.setRid(COLLATERAL_ID);
        List<FloodRequiredCoverageDTO> floodRequiredCoverageDTOs = new ArrayList<>();
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = new FloodRequiredCoverageDTO();
        floodRequiredCoverageDTO.setStatus("VERIFIED");
        floodRequiredCoverageDTOs.add(floodRequiredCoverageDTO);
        doReturn(floodRequiredCoverageDTOs).when(floodRequiredCoverageService).getByCollateralId(COLLATERAL_ID);
        GeneralCoverageRequirementDTO generalCoverageRequirementDTO = new GeneralCoverageRequirementDTO();
        generalCoverageRequirementDTO.setVerifiedRequirementSource(null);
        when(generalRequiredCoverageSourceService.getByCollateralId(COLLATERAL_ID)).thenReturn(generalCoverageRequirementDTO);
        List<HoldHistoryView> holdHistoryViews = new ArrayList<>();
        when(holdHistoryViewRepository.findByCollateralRid(COLLATERAL_ID)).thenReturn(holdHistoryViews);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        testObj.populate(COLLATERAL_ID, c3RequestDTO);
        verify(generalCoverageService, never()).getGeneralCoverageTypes();
        verify(testObj, never()).buildC3RequiredCoverageDTO(any(GeneralRequiredCoverageDTO.class), anyList());
        verify(testObj).buildC3RequiredCoverageDTO(floodRequiredCoverageDTO, holdHistoryViews);
        verify(testObj).setNewlyAdded(anyList(), eq(c3RequestDTO.getRequiredCoverages()));
        assertEquals(1, c3RequestDTO.getRequiredCoverages().size());
    }

    @Test
    public void testPopulateRequiredCoveragesGeneralOnly() {
        CollateralDTO collateralDTO  = buildCollateralDTO("PLEGED", "10/01/2018", COLLATERAL_ID);
        doReturn(collateralDTO).when(collateralDetailsService).getCollateralDetails(COLLATERAL_ID);
        collateralDTO.setRid(COLLATERAL_ID);
        List<FloodRequiredCoverageDTO> floodRequiredCoverageDTOs = new ArrayList<>();
        doReturn(floodRequiredCoverageDTOs).when(floodRequiredCoverageService).getByCollateralId(COLLATERAL_ID);
        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = new GeneralRequiredCoverageSourceDTO();
        GeneralRequiredCoverageDTO generalRequiredCoverageDTO = new GeneralRequiredCoverageDTO();
        generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages().add(generalRequiredCoverageDTO);
        GeneralCoverageRequirementDTO generalCoverageRequirementDTO = new GeneralCoverageRequirementDTO();
        generalCoverageRequirementDTO.setVerifiedRequirementSource(generalRequiredCoverageSourceDTO);
        doReturn(generalCoverageRequirementDTO).when(generalRequiredCoverageSourceService).getByCollateralId(COLLATERAL_ID);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        testObj.populate(COLLATERAL_ID, c3RequestDTO);
        List<GeneralCoverageDTO> generalCoverageDTOs = new ArrayList<>();
        verify(testObj).buildC3RequiredCoverageDTO(generalRequiredCoverageDTO, generalCoverageDTOs);
        verify(testObj, never()).buildC3RequiredCoverageDTO(any(FloodRequiredCoverageDTO.class), anyList());
        verify(testObj, times(1)).setNewlyAdded(anyList(), eq(c3RequestDTO.getRequiredCoverages()));
        assertEquals(1, c3RequestDTO.getRequiredCoverages().size());
    }


    @Test
    public void testPopulateRequiredCoveragesEmpty() {
        CollateralDTO collateralDTO  = buildCollateralDTO("PLEGED", "10/01/2018", COLLATERAL_ID);
        doReturn(collateralDTO).when(collateralDetailsService).getCollateralDetails(COLLATERAL_ID);
        collateralDTO.setRid(COLLATERAL_ID);
        List<FloodRequiredCoverageDTO> floodRequiredCoverageDTOs = new ArrayList<>();
        doReturn(floodRequiredCoverageDTOs).when(floodRequiredCoverageService).getByCollateralId(COLLATERAL_ID);
        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = new GeneralRequiredCoverageSourceDTO();
        GeneralCoverageRequirementDTO generalCoverageRequirementDTO = new GeneralCoverageRequirementDTO();
        generalCoverageRequirementDTO.setVerifiedRequirementSource(generalRequiredCoverageSourceDTO);
        when(generalRequiredCoverageSourceService.getByCollateralId(COLLATERAL_ID)).thenReturn(generalCoverageRequirementDTO);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        testObj.populate(COLLATERAL_ID, c3RequestDTO);
        verify(testObj, never()).buildC3RequiredCoverageDTO(any(GeneralRequiredCoverageDTO.class), anyList());
        verify(testObj, never()).buildC3RequiredCoverageDTO(any(FloodRequiredCoverageDTO.class), anyList());
        assertEquals(0, c3RequestDTO.getRequiredCoverages().size());

        generalCoverageRequirementDTO.setVerifiedRequirementSource(null);
        testObj.populate(COLLATERAL_ID, c3RequestDTO);
        verify(testObj, never()).buildC3RequiredCoverageDTO(any(GeneralRequiredCoverageDTO.class), anyList());
        verify(testObj, never()).buildC3RequiredCoverageDTO(any(FloodRequiredCoverageDTO.class), anyList());
        assertEquals(0, c3RequestDTO.getRequiredCoverages().size());
    }

    @Test
    public void testGetGeneralCoverageType() {
        List<GeneralCoverageDTO> generalCoverageDTOs = new ArrayList<>();
        GeneralCoverageDTO generalCoverageDTO = new GeneralCoverageDTO();
        generalCoverageDTO.setRid(1L);
        generalCoverageDTO.setCoverageType("Property / Hazard");
        generalCoverageDTOs.add(generalCoverageDTO);
        String generalCoverageType = testObj.getGeneralCoverageType(1L, generalCoverageDTOs);
        assertEquals("Property / Hazard", generalCoverageType);
    }

    @Test
    public void testGetGeneralCoverageTypeNoMatch() {
        List<GeneralCoverageDTO> generalCoverageDTOs = new ArrayList<>();
        GeneralCoverageDTO generalCoverageDTO = new GeneralCoverageDTO();
        generalCoverageDTO.setRid(2L);
        generalCoverageDTO.setCoverageType("Property / Hazard");
        generalCoverageDTOs.add(generalCoverageDTO);
        String generalCoverageType = testObj.getGeneralCoverageType(1L, generalCoverageDTOs);
        assertEquals(null, generalCoverageType);
    }

    @Test
    public void testPopulateGIPolicies() {
        CollateralDTO collateralDTO  = buildCollateralDTO("PLEGED", "10/01/2018", COLLATERAL_ID);

        final int BORROWER_POLICIES_COUNT = 7;
        final int LP_POLICIES_COUNT = 11;
        List<PolicyDTO> borrowerPolicies = buildPolicyDTOs(BORROWER_POLICIES_COUNT, PolicyType.GI_POLICY);
        List<PolicyDTO> lpPolicies = buildPolicyDTOs(LP_POLICIES_COUNT, PolicyType.GI_LP);
        when(policyService.getPoliciesForC3(collateralDTO.getRid()))
                .thenReturn(ListUtils.union(borrowerPolicies, lpPolicies));
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCollateralRid(collateralDTO.getRid());
        doReturn(new C3Policy()).when(testObj).c3PolicyFromPolicyDTO(Mockito.any(PolicyDTO.class), Mockito.anyLong());
        testObj.populatePolicies(c3RequestDTO);

        assertEquals(BORROWER_POLICIES_COUNT, c3RequestDTO.getBorrowerPolicies().size());
        assertEquals(LP_POLICIES_COUNT, c3RequestDTO.getLpPolicies().size());
        verify(testObj, times(BORROWER_POLICIES_COUNT + LP_POLICIES_COUNT))
                .c3PolicyFromPolicyDTO(Mockito.any(PolicyDTO.class), Mockito.anyLong());;
    }

    @Test
    public void testC3PolicyFromPolicyDTO() {
        final Long POLICY_ID = 5L;
        final String POLICY_TYPE = "Policy Type";
        final String POLICY_STATUS = "Policy Status";
        final String INSURANCE_TYPE = InsuranceType.GENERAL.name();
        final String EFFECTIVE_DATE = "01/01/2018";
        final String EXPIRATION_DATE = "01/01/2019";
        final String CANCELLATION_DATE = "10/01/2018";
        final String LP_ACTION = LPAction.NEW_BP.name();

        PolicyDTO policyDTO = new PolicyDTO();
        policyDTO.setPolicyId(POLICY_ID);
        policyDTO.setPolicyType(POLICY_TYPE);
        policyDTO.setPolicyStatus(POLICY_STATUS);
        policyDTO.setInsuranceType(INSURANCE_TYPE);
        policyDTO.setEffectiveDate(EFFECTIVE_DATE);
        policyDTO.setExpirationDate(EXPIRATION_DATE);
        policyDTO.setCancellationDate(CANCELLATION_DATE);
        policyDTO.setLpAction(LP_ACTION);

        final List<C3ProvidedCoverage> PROVIDED_COVERAGES = new ArrayList<>();

        doReturn(PROVIDED_COVERAGES).when(testObj).getProvidedCoverages(policyDTO, COLLATERAL_ID);

        C3Policy response = testObj.c3PolicyFromPolicyDTO(policyDTO, COLLATERAL_ID);

        assertEquals(POLICY_ID, response.getPolicyId());
        assertEquals(POLICY_TYPE, response.getPolicyType());
        assertEquals(POLICY_STATUS, response.getPolicyStatus());
        assertEquals(INSURANCE_TYPE, response.getInsuranceType());
        assertEquals(EFFECTIVE_DATE, response.getEffectiveDate());
        assertEquals(EXPIRATION_DATE, response.getExpirationDate());
        assertEquals(CANCELLATION_DATE, response.getCancellationEffectiveDate());
        assertEquals(PROVIDED_COVERAGES, response.getProvidedCoverages());
        assertEquals(LP_ACTION, response.getLpAction());
    }

    @Test
    public void testC3FloodDeterminationDTO() {
        CollateralDTO collateralDTO = new CollateralDTO();
        collateralDTO.setRid(COLLATERAL_ID);
        FloodDetermination floodDetermination = new FloodDetermination();
        floodDetermination.setFloodZone("A");
        floodDetermination.setDateOfMapChange(refDate);
        floodDetermination.setCollateralRid(1L);
        floodDetermination.setDateOfDetermination(refDate);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        doReturn(floodDetermination).when(floodDeterminationService).findByCollateralRidAndStatus(COLLATERAL_ID,CollateralSectionStatus.VERIFIED.name());
        testObj.populateFloodDetermination(collateralDTO, c3RequestDTO);
        String expected = defaultDateFormatter.print(refDate);
        assertEquals(expected, c3RequestDTO.getFloodDetermination().getDateOfMapChange());
        assertEquals(true, c3RequestDTO.getFloodDetermination().isInHighRiskFloodZone());
        assertEquals("A", c3RequestDTO.getFloodDetermination().getFloodZone());
    }

    @Test
    public void testGetProvidedCoverages() {
        final int INSURANCE_COVERAGES_COUNT = 8;

        PolicyDTO policyDTO = new PolicyDTO();

        PolicyCollateralDetailsDTO policyCollateralDetailsDTO = new PolicyCollateralDetailsDTO();

        policyCollateralDetailsDTO.setCollateralId(COLLATERAL_ID);
        policyCollateralDetailsDTO.setInsuranceCoverages(buildPolicyInsuranceCoverageDTOs(INSURANCE_COVERAGES_COUNT));

        policyDTO.setCollateralCoverages(Arrays.asList(policyCollateralDetailsDTO));

        List<C3ProvidedCoverage> providedCoveragesResponse =
                testObj.getProvidedCoverages(policyDTO, COLLATERAL_ID);

        assertEquals(INSURANCE_COVERAGES_COUNT, providedCoveragesResponse.size());
    }

    @Test
    public void testGetC3Holds() {
        HoldHistoryView holdHistoryView = new HoldHistoryView();
        Long holdRid = 1L;
        holdHistoryView.setStartDate(DATE_FORMATTER.parse("01/01/2018"));
        holdHistoryView.setLpiDate(DATE_FORMATTER.parse("02/01/2018"));
        holdHistoryView.setHoldStatus(VerificationStatus.VERIFIED.name());
        holdHistoryView.setHoldRid(holdRid);
        C3Hold c3Hold = testObj.c3HoldFromHoldHistoryView(holdHistoryView);
        assertEquals("01/01/2018", DATE_FORMATTER.print(c3Hold.getHoldStartDate()));
        assertEquals("02/01/2018", DATE_FORMATTER.print(c3Hold.getHoldLpiDate()));
        assertEquals(holdRid, c3Hold.getRid());
        assertFalse(c3Hold.isNewHold());
    }
    @Test
    public void testGetC3HoldNewHold() {
        HoldHistoryView holdHistoryView = new HoldHistoryView();
        Long holdRid = 1L;
        holdHistoryView.setStartDate(DATE_FORMATTER.parse("01/01/2018"));
        holdHistoryView.setHoldStatus(VerificationStatus.VERIFIED.name());
        holdHistoryView.setHoldRid(holdRid);
        C3Hold c3Hold = testObj.c3HoldFromHoldHistoryView(holdHistoryView);
        assertEquals("01/01/2018", DATE_FORMATTER.print(c3Hold.getHoldStartDate()));
        assertNull(c3Hold.getHoldLpiDate());
        assertEquals(holdRid, c3Hold.getRid());
        assertTrue(c3Hold.isNewHold());
    }

    @Test
    public void testGetMatchingC3Hold() {
        List<HoldHistoryView> holdHistoryViews = new ArrayList<>();
        HoldHistoryView mockHoldHistory = mockHoldHistoryView(1L);
        mockHoldHistory.setParentHold(mockHoldHistoryView(5L));
        holdHistoryViews.add(mockHoldHistory);
        C3Hold c3hold = testObj.getMatchingC3Hold(holdHistoryViews, 1L);
        assertThat(c3hold.getRid(), is(1L));
        assertThat(c3hold.getHoldStartDate(), is(DATE_FORMATTER.parse("01/01/2018")));
        assertThat(c3hold.getHoldLpiDate(), is(DATE_FORMATTER.parse("02/02/2018")));

        HoldHistoryView childHoldHistoryView = mockHoldHistoryView(2L);
        childHoldHistoryView.setStartDate(DATE_FORMATTER.parse("01/15/2018"));
        childHoldHistoryView.setParentHold(mockHoldHistory);
        holdHistoryViews.add(childHoldHistoryView);
        c3hold = testObj.getMatchingC3Hold(holdHistoryViews, 1L);
        assertThat(c3hold.getRid(), is(1L));
        assertThat(c3hold.getHoldStartDate(), is(DATE_FORMATTER.parse("01/01/2018")));
        assertThat(c3hold.getHoldLpiDate(), is(DATE_FORMATTER.parse("02/02/2018")));
    }

    @Test
    public void testGetMatchingC3HoldNoMatch() {
        List<HoldHistoryView> holdHistoryViews = new ArrayList<>();
        C3Hold c3hold = testObj.getMatchingC3Hold(holdHistoryViews, 1L);
        assertNull(c3hold);

        HoldHistoryView mockHoldHistory = mockHoldHistoryView(1L);
        holdHistoryViews.add(mockHoldHistory);
        c3hold = testObj.getMatchingC3Hold(holdHistoryViews, 2L);
        assertNull(c3hold);
    }

    private HoldHistoryView mockHoldHistoryView(Long holdRid) {
        HoldHistoryView holdHistoryView = new HoldHistoryView();
        holdHistoryView.setHoldRid(holdRid);
        holdHistoryView.setHoldStatus(VerificationStatus.VERIFIED.name());
        holdHistoryView.setStartDate(DATE_FORMATTER.parse("01/01/2018"));
        holdHistoryView.setLpiDate(DATE_FORMATTER.parse("02/02/2018"));
        return holdHistoryView;
    }

    private FloodRequiredCoverageDTO mockFloodRequiredCoverageDTO() {
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = new FloodRequiredCoverageDTO();
        floodRequiredCoverageDTO.setInsuranceType(InsuranceType.FLOOD.name());
        floodRequiredCoverageDTO.setInsurableAssetId(1L);
        floodRequiredCoverageDTO.setInsurableAssetType(InsurableAssetType.STRUCTURE.name());
        floodRequiredCoverageDTO.setCoverageType(FloodCoverageType.PRIMARY.name());
        floodRequiredCoverageDTO.setCoverageAmount(BigDecimal.TEN);
        floodRequiredCoverageDTO.setDescoped(true);
        floodRequiredCoverageDTO.setDocumentDate("10/10/10");
        floodRequiredCoverageDTO.setHoldRid(2L);
        return floodRequiredCoverageDTO;
    }

    @Test
    public void testBuildC3RequiredCoverageDTOFlood() {
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = mockFloodRequiredCoverageDTO();
        List<HoldHistoryView> holdHistoryViews = new ArrayList<>();
        Long holdRid = 2L;
        HoldHistoryView mockHoldHistoryView = mockHoldHistoryView(holdRid);
        holdHistoryViews.add(mockHoldHistoryView);
        C3RequiredCoverage c3RequiredCoverage = testObj.buildC3RequiredCoverageDTO(floodRequiredCoverageDTO, holdHistoryViews);
        verify(testObj).getMatchingC3Hold(holdHistoryViews, holdRid);
        assertEquals(InsuranceType.FLOOD.name(), c3RequiredCoverage.getInsuranceType());
        assertEquals((Long)1L, c3RequiredCoverage.getInsurableAssetId());
        assertEquals(InsurableAssetType.STRUCTURE.name(), c3RequiredCoverage.getInsurableAssetType());
        assertEquals(FloodCoverageType.PRIMARY.name(), c3RequiredCoverage.getCoverageType());
        assertEquals(BigDecimal.TEN, c3RequiredCoverage.getCoverageAmount());
        assertTrue(c3RequiredCoverage.isDescoped());
        assertEquals("10/10/10", c3RequiredCoverage.getDocumentDate());
        assertEquals(holdRid, c3RequiredCoverage.getHold().getRid());
    }

    @Test
    public void testBuildC3RequiredCoverageDTOFloodNoHolds() {
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = mockFloodRequiredCoverageDTO();
        C3RequiredCoverage c3RequiredCoverage = testObj.buildC3RequiredCoverageDTO(floodRequiredCoverageDTO, null);
        assertNull(c3RequiredCoverage.getHold());

        c3RequiredCoverage = testObj.buildC3RequiredCoverageDTO(floodRequiredCoverageDTO, new ArrayList<>());
        assertNull(c3RequiredCoverage.getHold());

        floodRequiredCoverageDTO.setHoldRid(null);
        List<HoldHistoryView> holdHistoryViews = Arrays.asList(mockHoldHistoryView(1L));
        c3RequiredCoverage = testObj.buildC3RequiredCoverageDTO(floodRequiredCoverageDTO, holdHistoryViews);
        assertNull(c3RequiredCoverage.getHold());
    }

    @Test
    public void testBuildC3RequiredCoverageDTOGeneral() {
        GeneralRequiredCoverageDTO generalRequiredCoverageDTO = new GeneralRequiredCoverageDTO();
        generalRequiredCoverageDTO.setCoverageAmount(BigDecimal.TEN);
        generalRequiredCoverageDTO.setGeneralCoverageRid(1L);
        List<GeneralCoverageDTO> generalCoverages = new ArrayList<>();
        GeneralCoverageDTO generalCoverageDTO = new GeneralCoverageDTO();
        generalCoverageDTO.setRid(1L);
        generalCoverageDTO.setCoverageType("Property / Hazard");
        generalCoverages.add(generalCoverageDTO);
        C3RequiredCoverage c3RequiredCoverage = testObj.buildC3RequiredCoverageDTO(generalRequiredCoverageDTO, generalCoverages);
        verify(testObj).getGeneralCoverageType(1L, generalCoverages);
        assertEquals(BigDecimal.TEN, c3RequiredCoverage.getCoverageAmount());
        assertEquals("Property / Hazard", c3RequiredCoverage.getCoverageType());
        assertEquals(InsuranceType.GENERAL.name(), c3RequiredCoverage.getInsuranceType());
    }

    private List<PolicyDTO> buildPolicyDTOs(int policiesToBuild, PolicyType policyType) {
        List<PolicyDTO> policyDTOS = new ArrayList<>();

        for (int i = 0; i < policiesToBuild; i++) {
            PolicyDTO policyDTO = new PolicyDTO();
            policyDTO.setPolicyType(policyType.toString());
            policyDTO.setInsuranceType(policyType.getInsuranceType().name());
            policyDTOS.add(policyDTO);
        }

        return policyDTOS;

    }

    private CollateralDTO buildCollateralDTO(String collateralStatus, String releaseDate, Long collateralId) {
        CollateralDTO collateralDTO = new CollateralDTO();
        collateralDTO.setRid(collateralId);
        collateralDTO.setCollateralStatus(collateralStatus);
        collateralDTO.setReleaseDate(defaultDateFormatter.parse(releaseDate));
        return collateralDTO;
    }

    List<PolicyInsuranceCoverageDTO> buildPolicyInsuranceCoverageDTOs(int coveragesToBuild) {
        List<PolicyInsuranceCoverageDTO> policyInsuranceCoverageDTOs = new ArrayList<>();

        for (int i = 0 ; i < coveragesToBuild; i++) {
            PolicyInsuranceCoverageDTO policyInsuranceCoverageDTO = new PolicyInsuranceCoverageDTO();
            policyInsuranceCoverageDTO.setDeductibleAmount("5");
            policyInsuranceCoverageDTOs.add(policyInsuranceCoverageDTO);
        }

        return policyInsuranceCoverageDTOs;
    }

    @Test
    public void setNewlyAddedFlood() {
        testNewlyAdded("PRIMARY", 5L, "EXCESS", 1L, "PRIMARY", null, false, true);
        testNewlyAdded("PRIMARY", 5L, "PRIMARY", 1L, "PRIMARY", null, false, true);
        testNewlyAdded("PRIMARY", 5L, "PRIMARY", 5L, "PRIMARY", null, false, false);
        testNewlyAdded("PRIMARY", 5L, "PRIMARY", 1L, "PRIMARY", 5L, true, true);
        testNewlyAdded("PRIMARY", 5L, "EXCESS", 1L, "PRIMARY", 5L, false, true);
    }

    @Test
    public void setNewlyAddedGeneral() {
        testNewlyAdded("cov", null, "cov1", null, "cov2", null, false, true);
        testNewlyAdded("cov", null, "cov", null, "cov2", null, false, false);
        testNewlyAdded("cov", null, "cov", null, "cov2", null, true, true);
        testNewlyAdded("cov", null, "cov1", null, "cov", null, false, true);
        testNewlyAdded("cov", null, "cov1", null, null, null, false, true);
        testNewlyAdded("cov", null, "cov", null, null, null, false, false);
        testNewlyAdded("cov", null, null, null, null, null, false, false);
    }

    private void testNewlyAdded(String coverageType, Long insurableAssetId, String coverageType1, Long insurableAssetId1, String coverageType2, Long insurableAssetId2, boolean descoped, boolean expected) {
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setCoverageType(coverageType);
        requiredCoverage.setInsurableAssetId(insurableAssetId);

        List<C3RequiredCoverage> requiredCoverages = new ArrayList<>();
        requiredCoverages.add(requiredCoverage);

        List<C3RequiredCoverage> inactiveCoverages = new ArrayList<>();
        if (coverageType1 != null) {
            C3RequiredCoverage inactiveCoverage1 = new C3RequiredCoverage();
            inactiveCoverage1.setDocumentDate("10/10/2018"); //"10/10/2018"
            inactiveCoverage1.setCoverageType(coverageType1);
            inactiveCoverage1.setInsurableAssetId(insurableAssetId1);
            inactiveCoverage1.setDescoped(descoped);
            inactiveCoverages.add(inactiveCoverage1);
        }
        if (coverageType2 != null) {
            C3RequiredCoverage inactiveCoverage2 = new C3RequiredCoverage();
            inactiveCoverage2.setDocumentDate("09/10/2018");
            inactiveCoverage2.setCoverageType(coverageType2);
            inactiveCoverage2.setInsurableAssetId(insurableAssetId2);
            inactiveCoverages.add(inactiveCoverage2);
        }
        testObj.setNewlyAdded(inactiveCoverages, requiredCoverages);
        assertEquals(expected, requiredCoverage.isNewlyAdded());
    }

    @Test
    public void populateInsuranceType() {
        testInsuranceType("FLOOD", CtracEventType.BORROWER_POLICY_ACCEPTED, "FLOOD");
        testInsuranceType("GENERAL", CtracEventType.BORROWER_POLICY_ACCEPTED, "GENERAL");
        testInsuranceType("FLOOD", CtracEventType.COLLATERAL_RELEASED, null);
        testInsuranceType("GENERAL", CtracEventType.COLLATERAL_RELEASED, null);
        testInsuranceType("FLOOD", CtracEventType.LAST_LOAN_PAID_OFF, null);
        testInsuranceType("GENERAL", CtracEventType.LAST_LOAN_PAID_OFF, null);
    }

    private void testInsuranceType(String insuranceType, CtracEventType ctracEventType, String expectedInsuranceType) {
        C3RequestEventDTO c3RequestEventDTO = new C3RequestEventDTO();
        c3RequestEventDTO.setCollateralId(COLLATERAL_ID);
        c3RequestEventDTO.setInsuranceType(insuranceType);
        c3RequestEventDTO.setEventType(ctracEventType.getDisplayValue());
        prepareC3RequestDTO();
        C3RequestDTO c3RequestDTO = testObj.build(c3RequestEventDTO);
        assertEquals(expectedInsuranceType, c3RequestDTO.getInsuranceType());
    }

    private void testIsAddedAndRemovedCoverages(CtracEventType ctracEventType, boolean requested, boolean expected) {
        C3RequestEventDTO c3RequestEventDTO = new C3RequestEventDTO();
        c3RequestEventDTO.setCollateralId(COLLATERAL_ID);
        c3RequestEventDTO.setEventType(ctracEventType.getDisplayValue());
        c3RequestEventDTO.setAddedAndRemovedCoverages(requested);
        prepareC3RequestDTO();
        C3RequestDTO c3RequestDTO = testObj.build(c3RequestEventDTO);
        assertEquals(expected, c3RequestDTO.isAddedAndRemovedCoveragesOnly());
    }

    private CollateralDTO createCollateralDTO(CollateralDTO createCollateralDTO) {
        createCollateralDTO.setStreetAddress(STREET_ADDRESS);
        createCollateralDTO.setUnitOrBuilding(UNIT_OR_BUILDING);
        createCollateralDTO.setCounty(COUNTY);
        createCollateralDTO.setCity(CITY);
        createCollateralDTO.setState(STATE);
        createCollateralDTO.setZipCode(ZIP_CODE);
        createCollateralDTO.setRid(1L);
        return createCollateralDTO;
    }

    private GeneralRequiredCoverageSourceDTO getGeneralRequiredCoverageSourceDTO(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO){
        generalRequiredCoverageSourceDTO.setRid(1L);
        generalRequiredCoverageSourceDTO.setStatus("PENDING_VERIFICATION");
        generalRequiredCoverageSourceDTO.setCollateralRid(1L);
        return generalRequiredCoverageSourceDTO;
    }
    private GeneralCoverageRequirementDTO mockGeneralCoverageRequirementDTO(
            GeneralRequiredCoverageSourceDTO pending, GeneralRequiredCoverageSourceDTO verified) {
        GeneralCoverageRequirementDTO existing = new GeneralCoverageRequirementDTO();
        existing.setPendingVerificationRequirementSource(pending);
        existing.setVerifiedRequirementSource(verified);
        return existing;
    }

}