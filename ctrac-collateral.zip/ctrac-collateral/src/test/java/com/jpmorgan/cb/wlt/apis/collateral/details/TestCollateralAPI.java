package com.jpmorgan.cb.wlt.apis.collateral.details;

import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerServiceImpl;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static junit.framework.TestCase.fail;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralAPI {

    private static final String API = "/api/collaterals";
    private static final Long COLLATERAL_ID = 1L;
    private static final String STREET_ADDRESS = "10 S DEARBORN ST";
    private static final UserRequestInfo CONST_TEST_USER = new UserRequestInfo("testUser");

    @Mock
    private CollateralDetailsService collateralRetrievalService;

    @Mock
    private CollateralSectionService collateralSectionService;
    @InjectMocks
    private CollateralAPI testObj;

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(testObj)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();
    }

    @Test
    public void testGetCollateral() {
        try {
            when(collateralRetrievalService.getCollateralDetails(COLLATERAL_ID)).thenReturn(stubCollateralDetailsDTO());
            mockMvc.perform(get(API + "/" + COLLATERAL_ID).contentType(APPLICATION_JSON_UTF8))
                    .andExpect(jsonPath("$.rid").value(COLLATERAL_ID))
                    .andExpect(jsonPath("$.streetAddress").value(STREET_ADDRESS))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void testGetCollateralDetails() {
        try {
            when(collateralRetrievalService.getCollateralDetails(COLLATERAL_ID)).thenReturn(stubCollateralDetailsDTO());
            mockMvc.perform(get(API + "/" + COLLATERAL_ID).contentType(APPLICATION_JSON_UTF8))
                    .andExpect(jsonPath("$.rid").value(COLLATERAL_ID))
                    .andExpect(jsonPath("$.streetAddress").value(STREET_ADDRESS))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void testVerifyCollateralDetailsSection() {
        testPostAPI(API + "/" + COLLATERAL_ID + "/verify");
        verify(collateralSectionService).verify(COLLATERAL_ID, CollateralSection.COLLATERAL_BASIC_DETAILS, CONST_TEST_USER);
    }
    @Test
    public void testPledgeCollateral() {
        try {
            when(collateralRetrievalService.pledgeCollateral(COLLATERAL_ID, CONST_TEST_USER)).thenReturn(stubCollateralDetailsDTO());
            mockMvc.perform(post(API + "/" + COLLATERAL_ID + "/pledged")
                    .requestAttr(CtracAuthenticationManagerServiceImpl.USER_REQUEST_INFO, CONST_TEST_USER)
                    .contentType(APPLICATION_JSON_UTF8))
                    .andExpect(jsonPath("$.rid").value(COLLATERAL_ID))
                    .andExpect(jsonPath("$.streetAddress").value(STREET_ADDRESS))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail();
        }

    }
    @Test
    public void testchangeCollateralDraftToVerify_WriteRolesSuccess() {
        try {
            UserRequestInfo userRequestInfo = getRoleWritesUserRequestInfo();
            doNothing().when(collateralRetrievalService).submitForVerification(COLLATERAL_ID, userRequestInfo);
            mockMvc.perform(get(API + "/" + COLLATERAL_ID + "/changeCollateralDraftToVerify")
                    .requestAttr(CtracAuthenticationManagerServiceImpl.USER_REQUEST_INFO, userRequestInfo)
                    .contentType(APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk());
            verify(collateralRetrievalService,times(1)).submitForVerification(COLLATERAL_ID,userRequestInfo);
        } catch (Exception e) {
            fail();
        }

    }

    private void testPostAPI(String api) {
        try {
            when(collateralRetrievalService.getCollateralDetails(COLLATERAL_ID)).thenReturn(stubCollateralDetailsDTO());
            mockMvc.perform(post(api).requestAttr(CtracAuthenticationManagerServiceImpl.USER_REQUEST_INFO,CONST_TEST_USER).contentType(APPLICATION_JSON_UTF8))
                  .andExpect(jsonPath("$.rid").value(COLLATERAL_ID))
                    .andExpect(jsonPath("$.streetAddress").value(STREET_ADDRESS))
                    .andExpect(status().isOk());
        } catch (Exception e) {
            fail();
        }
    }

    private CollateralDTO stubCollateralDetailsDTO() {
        CollateralDTO collateralDetailsDTO = new CollateralDTO();
        collateralDetailsDTO.setRid(COLLATERAL_ID);
        collateralDetailsDTO.setStreetAddress(STREET_ADDRESS);
        return collateralDetailsDTO;
    }
    private UserRequestInfo getRoleWritesUserRequestInfo() {
        Map<String, Set<String>> authorities = new HashMap<>();
        String LOCAL_USER = "LOCAL";
        String role = "ROLE_WRITER";
        UserRequestInfo userRequestInfo = new UserRequestInfo(LOCAL_USER);
        Set<String> set = new HashSet();
        set.add("DCS");
        authorities.put(role, set);


        UserEntitlementsDTO userEntitlement = new UserEntitlementsDTO();
        userEntitlement.setFirstName(LOCAL_USER);
        userEntitlement.setLastName(LOCAL_USER);
        userEntitlement.setJanusUsername(LOCAL_USER);
        userEntitlement.setAuthorities(authorities);
        userRequestInfo.setUserEntitlementsDto(userEntitlement);

        return userRequestInfo;
    }
}
