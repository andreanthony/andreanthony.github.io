package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;

public class TestCollateralStatusRule {

    private CollateralStatusRule testObj;

    @Before
    public void setUp() {
        testObj = new CollateralStatusRule();
    }

    @Test
    public void testCollateralPledged() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCollateralStatus("PLEDGED");
        c3RequestDTO.getLpPolicies().add(createLpPolicy(1L));
        c3RequestDTO.getLpPolicies().add(createLpPolicy(2L));
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getPoliciesToCancel(), is(empty()));
        assertThat(c3ResponseDTO.isComplete(), is(false));
    }

    @Test
    public void testCollateralReleased() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCollateralStatus("RELEASED");
        c3RequestDTO.setCollateralReleaseDate("01/01/2018");
        c3RequestDTO.getLpPolicies().add(createLpPolicy(1L));
        c3RequestDTO.getLpPolicies().add(createLpPolicy(2L));
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getPolicyId(), is(1L));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getCancellationEffectiveDate(), is("01/01/2018"));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(0).getCancellationReason(), is(CancellationReason.COLLATERAL_RELEASED));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(1).getPolicyId(), is(2L));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(1).getCancellationEffectiveDate(), is("01/01/2018"));
        assertThat(c3ResponseDTO.getPoliciesToCancel().get(1).getCancellationReason(), is(CancellationReason.COLLATERAL_RELEASED));
        assertThat(c3ResponseDTO.isComplete(), is(true));
    }

    private C3Policy createLpPolicy(Long policyId) {
        C3Policy c3Policy = C3RuleTestUtil.mockGeneralPolicy(policyId, PolicyType.GI_LP, PolicyStatus.PAID, "cov");
        return c3Policy;
    }
}
