package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import java.util.ArrayList;
import java.util.List;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.mockFloodPolicy;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestFloodCoverageDateRule {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    @InjectMocks
    private FloodCoverageDateRule testObj;

    @Before
    public void setUp() {
        testObj = new FloodCoverageDateRule();
    }

    @Test
    public void testOverrideDate() {
        overrideDate(InsuranceType.FLOOD.name(), 1);
        overrideDate(InsuranceType.GENERAL.name(), 0);
    }

    private void overrideDate(String insuranceType, int expectedSize) {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setOverrideFloodCoverageDate("09/07/2018");
        c3RequestDTO.setInsuranceType(insuranceType);
        C3RequiredCoverage c3RequiredCoverage = new C3RequiredCoverage();
        c3RequiredCoverage.setInsuranceType(insuranceType);
        c3RequestDTO.addRequiredCoverage(c3RequiredCoverage);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(expectedSize));
        if (expectedSize > 0) {
            assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "09/07/2018", null, null, null);
        }
    }

    @Test
    public void testOverrideDateFloodOnly() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setOverrideFloodCoverageDate("09/07/2018");
        c3RequestDTO.setCurrentReferenceDate(c3RequestDTO.getOverrideFloodCoverageDate());
        c3RequestDTO.setInsuranceType("FLOOD");
        C3RequiredCoverage c3RequiredCoverage = new C3RequiredCoverage();
        c3RequiredCoverage.setInsuranceType("FLOOD");
        c3RequestDTO.addRequiredCoverage(c3RequiredCoverage);
        C3Policy policyBefore = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.CANCELLED, FloodCoverageType.PRIMARY.name());
        policyBefore.setLpAction("CANCEL_BP");
        policyBefore.setCancellationEffectiveDate("09/01/2018");
        c3RequestDTO.getBorrowerPolicies().add(policyBefore);
        C3Policy policyAfter = mockFloodPolicy(2L, PolicyType.NFIP, PolicyStatus.CANCELLED, FloodCoverageType.PRIMARY.name());
        policyAfter.setLpAction("CANCEL_BP");
        policyAfter.setCancellationEffectiveDate("09/10/2018");
        c3RequestDTO.getBorrowerPolicies().add(policyAfter);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(2));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(1), "09/07/2018", null, null, null);
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "09/10/2018", 4001L, FloodCoverageType.PRIMARY, 2L);
    }

    @Test
    public void testOverrideDateGeneralOnly() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setOverrideFloodCoverageDate("09/07/2018");
        c3RequestDTO.setInsuranceType("GENERAL");
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(0));
    }

    @Test
    public void testCancelled() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.CANCELLED, FloodCoverageType.PRIMARY.name());
        policy.setLpAction("CANCEL_BP");
        policy.setCancellationEffectiveDate("09/08/2018");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.setCurrentReferenceDate(policy.getCancellationEffectiveDate());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "09/08/2018",
                4001L, FloodCoverageType.PRIMARY, 1L);
    }

    @Test
    public void testCancelledApp() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.APPLICATION, PolicyStatus.CANCELLED, FloodCoverageType.PRIMARY.name());
        policy.setLpAction("CANCEL_BP");
        policy.setCancellationEffectiveDate("09/08/2018");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.setCurrentReferenceDate(policy.getCancellationEffectiveDate());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2018",
                4001L, FloodCoverageType.PRIMARY, 1L);
    }

    @Test
    public void testAccepted() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.ACCEPTED, FloodCoverageType.PRIMARY.name());
        policy.setLpAction("NEW_BP");
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.setCurrentReferenceDate(policy.getEffectiveDate());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2018",
                4001L, FloodCoverageType.PRIMARY, 1L);
    }

    @Test
    public void testExpiredBP() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getBorrowerPolicies().add(policy);
        c3RequestDTO.setCurrentReferenceDate(policy.getExpirationDate());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2019",
                4001L, FloodCoverageType.PRIMARY, 1L);
    }

    @Test
    public void testExpiredLP() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.EXPIRING, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        c3RequestDTO.setCurrentReferenceDate(policy.getExpirationDate());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2019",
                4001L, FloodCoverageType.PRIMARY, 1L);
    }

    @Test
    public void testExpiredBinder() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockFloodPolicy(1L, PolicyType.BINDER, PolicyStatus.EXPIRING, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2018",
                4001L, FloodCoverageType.PRIMARY, 1L);
    }

    @Test
    public void testPrimaryAndExcess() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockFloodPolicy(1L, PolicyType.PRIVATE, PolicyStatus.EXPIRING, FloodCoverageType.PRIMARY_AND_EXCESS.name());
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(2));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2019",
                4001L, FloodCoverageType.PRIMARY, 1L);
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(1), "01/01/2019",
                4001L, FloodCoverageType.EXCESS, 1L);
    }

    @Test
    public void testExcess() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockFloodPolicy(1L, PolicyType.PRIVATE, PolicyStatus.EXPIRING, FloodCoverageType.EXCESS.name());
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2019",
                4001L, FloodCoverageType.EXCESS, 1L);
    }

    @Test
    public void testTwoBuildings() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("01/01/2019");
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, FloodCoverageType.PRIMARY.name());
        policy.getProvidedCoverages().add(C3RuleTestUtil.mockProvidedCoverage(4002L, FloodCoverageType.PRIMARY.name()));
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(2));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2019",
                4001L, FloodCoverageType.PRIMARY, 1L);
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(1), "01/01/2019",
                4002L, FloodCoverageType.PRIMARY, 1L);
    }

    private void assertOneCoverageDate(C3CalculatedCoverageDate calculatedCoverageDate, String coverageDate,
                                       Long insurableAssetId, FloodCoverageType coverageType, Long borrowerPolicyId) {
        assertThat(calculatedCoverageDate.getInsuranceType(), Matchers.is(InsuranceType.FLOOD.name()));
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(DATE_FORMATTER.parse(coverageDate)));
        assertThat(calculatedCoverageDate.getInsurableAssetId(), Matchers.is(insurableAssetId));
        assertThat(calculatedCoverageDate.getCoverageType(), Matchers.is(coverageType == null? null: coverageType.name()));
        assertThat(calculatedCoverageDate.getPolicyId(), Matchers.is(borrowerPolicyId));
    }
    @Test
    public void getInsuranceType() {
        Assert.assertThat(testObj.getInsuranceType(), Matchers.is(InsuranceType.FLOOD));
    }

    @Test
    public void getC3CalculatedCoverageDates() {
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.setCalculatedFloodCoverageDates(new ArrayList<>());
        Assert.assertThat(testObj.getC3CalculatedCoverageDates(c3ResponseDTO), Matchers.is(c3ResponseDTO.getCalculatedFloodCoverageDates()));
    }

    @Test
    public void getOverrideCalculatedCoverageDate() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setOverrideFloodCoverageDate("01/01/2018");
        assertThat(testObj.getOverrideCalculatedCoverageDate(c3RequestDTO), Matchers.is(c3RequestDTO.getOverrideFloodCoverageDate_()));
    }

    @Test
    public void calculateAddedAndRemovedCoverageDates() {
        C3RequiredCoverage newlyAdded = mockC3RequiredCoverage(true, false, "PRIMARY");
        C3RequiredCoverage descoped = mockC3RequiredCoverage(false, true, "EXCESS");

        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        ArrayList<C3RequiredCoverage> requiredCoverages = new ArrayList<>();
        requiredCoverages.add(newlyAdded);
        requiredCoverages.add(descoped);
        c3RequestDTO.addRequiredCoverages(requiredCoverages);

        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getAllCalculatedCoverageDates().size(), Matchers.is(2));
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0).getCoverageDate(), Matchers.is(newlyAdded.getDocumentDate_()));
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(1).getCoverageDate(), Matchers.is(newlyAdded.getCancellationEffectiveDate_()));
    }

    private C3RequiredCoverage mockC3RequiredCoverage(boolean newlyAdded, boolean descoped, String coverageType) {
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setNewlyAdded(newlyAdded);
        requiredCoverage.setDescoped(descoped);
        String documentDate = "01/01/2018";
        String cancellationEffectiveDate = "02/01/2018";
        requiredCoverage.setDocumentDate(documentDate);
        requiredCoverage.setCancellationEffectiveDate(cancellationEffectiveDate);
        requiredCoverage.setInsuranceType("FLOOD");
        requiredCoverage.setInsurableAssetType("STRUCTURE");
        requiredCoverage.setInsurableAssetId(1L);
        requiredCoverage.setCoverageType(coverageType);
        return requiredCoverage;
    }

    @Test
    public void calculateFutureBorrowerPolicyDatesEmpty() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        List<C3CalculatedCoverageDate> calculatedCoverageDates = new ArrayList<>();
        testObj.calculateFutureBorrowerPolicyDates(c3RequestDTO, calculatedCoverageDates);
        assertTrue(calculatedCoverageDates.isEmpty());
    }

    @Test
    public void calculateFutureBorrowerPolicyDates() {
        testAfterEarlestDate("02/02/2018", "02/01/2018", "03/15/2018", true);
        testAfterEarlestDate("04/01/2018", "02/01/2018", "03/15/2018", true);
        testAfterEarlestDate("01/01/2018", "02/01/2018", "03/15/2018", false);
        testAfterEarlestDate("02/01/2018", "02/01/2018", "03/15/2018", false);
    }

    private void testAfterEarlestDate(String effectiveDate, String calcDate1, String calcDate2, boolean dateAdded) {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        ArrayList<C3Policy> borrowerPolicies = new ArrayList<>();
        C3Policy policy = new C3Policy();
        policy.setInsuranceType("FLOOD");
        policy.setEffectiveDate(effectiveDate);
        C3ProvidedCoverage c3ProvidedCoverage = new C3ProvidedCoverage();
        c3ProvidedCoverage.setCoverageType("PRIMARY");
        c3ProvidedCoverage.setInsurableAssetType("STRUCTURE");
        c3ProvidedCoverage.setInsurableAssetId(100L);
        policy.getProvidedCoverages().add(c3ProvidedCoverage);
        borrowerPolicies.add(policy);
        c3RequestDTO.addBorrowerPolicies(borrowerPolicies);

        List<C3CalculatedCoverageDate> calculatedCoverageDates = new ArrayList<>();
        C3CalculatedCoverageDate c3CalculatedCoverageDate1 = new C3CalculatedCoverageDate();
        c3CalculatedCoverageDate1.setCoverageDate(DATE_FORMATTER.parse(calcDate1));
        calculatedCoverageDates.add(c3CalculatedCoverageDate1);
        C3CalculatedCoverageDate c3CalculatedCoverageDate2 = new C3CalculatedCoverageDate();
        c3CalculatedCoverageDate2.setCoverageDate(DATE_FORMATTER.parse(calcDate2));
        calculatedCoverageDates.add(c3CalculatedCoverageDate2);

        testObj.calculateFutureBorrowerPolicyDates(c3RequestDTO, calculatedCoverageDates);
        if (dateAdded) {
            assertEquals(3, calculatedCoverageDates.size());
            assertEquals(policy.getEffectiveDate_(), calculatedCoverageDates.get(2).getCoverageDate());
        }
        else {
            assertEquals(2, calculatedCoverageDates.size());
        }
    }

    private C3Hold getHold(long rid, String startDate, String lpiDate) {
        C3Hold hold = new C3Hold();
        hold.setRid(rid);
        hold.setHoldStartDate(DATE_FORMATTER.parse(startDate));
        hold.setHoldLpiDate(DATE_FORMATTER.parse(lpiDate));
        return hold;
    }

    @Test
    public void testEvaluateGap() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setEvaluateGap(true);
        c3RequestDTO.setCurrentReferenceDate("12/01/2018");
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(1));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "01/01/2019",
                4001L, FloodCoverageType.PRIMARY, 1L);
    }

    @Test
    public void futurePolicyAcceptedWithFutureLapse() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setCurrentReferenceDate("12/01/2018");
        // 01/01/2018-19
        C3Policy policy = mockFloodPolicy(1L, PolicyType.NFIP, PolicyStatus.EXPIRING, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getBorrowerPolicies().add(policy);
        C3Policy policyNew = mockFloodPolicy(2L, PolicyType.NFIP, PolicyStatus.ACCEPTED, FloodCoverageType.PRIMARY.name());
        policyNew.setEffectiveDate("02/01/2019");
        policyNew.setExpirationDate("02/01/2020");
        policyNew.setLpAction("NEW_BP");
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3RequestDTO.getBorrowerPolicies().add(policyNew);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getValidCalculatedFloodCoverageDates().size(), Matchers.is(2));
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(0), "02/01/2019",
                4001L, FloodCoverageType.PRIMARY, 2L);
        assertOneCoverageDate(c3ResponseDTO.getValidCalculatedFloodCoverageDates().get(1), "01/01/2019",
                4001L, FloodCoverageType.PRIMARY, 1L);
    }


}
