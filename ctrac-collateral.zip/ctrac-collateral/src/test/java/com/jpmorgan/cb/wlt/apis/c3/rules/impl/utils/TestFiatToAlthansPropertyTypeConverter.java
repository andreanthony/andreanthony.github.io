package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.enums.AlthansPropertyType;
import com.jpmorgan.cb.wlt.apis.c3.dtos.enums.FIATPropertyType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

/**
 * Created by V704662 on 7/11/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestFiatToAlthansPropertyTypeConverter {

    @InjectMocks private FiatToAlthansPropertyTypeConverter converter;

    /**
     * - convertByPropertyDescription
     * TestCase: Verify for each possible Fiat Property Type Description
     * that it maps correctly to a AlthansPropertyType Enum
     */
    @Test
    public void testPropertyTypeConvertDescriptionToEnum(){
        assertThat(converter.convertByPropertyDescription(
                FIATPropertyType.COMMERCIAL.getDisplayName()),is(AlthansPropertyType.COMMERCIAL));
        assertThat(converter.convertByPropertyDescription(
                FIATPropertyType.COMMERCIAL_CONDO_ASSOCIATION.getDisplayName()),is(AlthansPropertyType.CONDO_ASSOC));
        assertThat(converter.convertByPropertyDescription(
                FIATPropertyType.RESIDENTIAL_CONDO_ASSOCIATION.getDisplayName()),is(AlthansPropertyType.CONDO_ASSOC));
        assertThat(converter.convertByPropertyDescription(
                FIATPropertyType.DWELLING_RESIDENTIAL.getDisplayName()),is(AlthansPropertyType.DWELLING_RESIDENTIAL));
        assertThat(converter.convertByPropertyDescription(
                FIATPropertyType.MULTI_FAMILY.getDisplayName()),is(AlthansPropertyType.MULTI_FAMILY));
    }

    /**
     * - convertByPropertyDescription
     * TestCase: Verify for a non existing Fiat Property Type Description
     * no value will be returned
     */
    @Test
    public void testPropertyTypeConvertDescriptionToEnumNotFound(){
        assertNull(converter.convertByPropertyDescription(
                "TEST"));
    }
}
