package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestC3PolicyCancellationDateComparator {

    C3PolicyCancellationDateComparator testObj = new C3PolicyCancellationDateComparator();

    @Test
    public void compareTo() {
        C3PolicyCancellation one = new C3PolicyCancellation();
        assertEquals(-1, testObj.compare(one, null));
        assertEquals(0, testObj.compare(one, one));

        C3PolicyCancellation two = new C3PolicyCancellation();
        assertEquals(-1, testObj.compare(one, two));
    }

    @Test
    public void compareToDeleted() {
        C3PolicyCancellation one = new C3PolicyCancellation();
        C3PolicyCancellation two = new C3PolicyCancellation();
        two.setDeleted(true);
        assertEquals(1, testObj.compare(one, two));
        assertEquals(-1, testObj.compare(two, one));
        one.setDeleted(true);
        assertEquals(0, testObj.compare(one, two));
    }

    @Test
    public void compareToDeletedCancellationEffectiveDate() {
        C3PolicyCancellation one = new C3PolicyCancellation();
        C3PolicyCancellation two = new C3PolicyCancellation();
        one.setCancellationEffectiveDate("01/01/2018");
        assertEquals(-1, testObj.compare(one, two));
        assertEquals(1, testObj.compare(two, one));
        two.setCancellationEffectiveDate("02/01/2018");
        assertEquals(-1, testObj.compare(one, two));
        assertEquals(1, testObj.compare(two, one));
    }

    @Test
    public void compareToDeletedUpdatedExpirationDate() {
        C3PolicyCancellation one = new C3PolicyCancellation();
        C3PolicyCancellation two = new C3PolicyCancellation();
        one.setUpdatedExpirationDate("01/01/2018");
        assertEquals(-1, testObj.compare(one, two));
        assertEquals(1, testObj.compare(two, one));
        two.setUpdatedExpirationDate("02/01/2018");
        assertEquals(-1, testObj.compare(one, two));
        assertEquals(1, testObj.compare(two, one));
    }

    @Test
    public void compareToDeletedMixedDates1() {
        C3PolicyCancellation one = new C3PolicyCancellation();
        C3PolicyCancellation two = new C3PolicyCancellation();
        one.setUpdatedExpirationDate("01/01/2018");
        assertEquals(-1, testObj.compare(one, two));
        assertEquals(1, testObj.compare(two, one));
        two.setCancellationEffectiveDate("02/01/2018");
        assertEquals(-1, testObj.compare(one, two));
        assertEquals(1, testObj.compare(two, one));
    }

    @Test
    public void compareToDeletedMixedDates2() {
        C3PolicyCancellation one = new C3PolicyCancellation();
        C3PolicyCancellation two = new C3PolicyCancellation();
        one.setCancellationEffectiveDate("01/01/2018");
        assertEquals(-1, testObj.compare(one, two));
        assertEquals(1, testObj.compare(two, one));
        two.setUpdatedExpirationDate("02/01/2018");
        assertEquals(-1, testObj.compare(one, two));
        assertEquals(1, testObj.compare(two, one));
    }

}