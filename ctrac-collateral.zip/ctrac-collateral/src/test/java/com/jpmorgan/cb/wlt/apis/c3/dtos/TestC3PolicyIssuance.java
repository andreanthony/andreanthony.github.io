package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.junit.Test;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.*;

public class TestC3PolicyIssuance {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    @Test
    public void setExpirationDateBeforeEffective() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setExpirationDate("12/31/2018");
        assertEquals("01/01/2019", testObj.getExpirationDate());
    }

    @Test
    public void setExpirationDateAfterEffective() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setExpirationDate("01/02/2019");
        assertEquals("01/02/2019", testObj.getExpirationDate());
    }

    @Test
    public void setExpirationDateWhenEffectiveDateIsNull() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setExpirationDate("01/02/2019");
        assertEquals("01/02/2019", testObj.getExpirationDate());
    }

    @Test
    public void setNullExpirationDate() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setEffectiveDate("01/01/2019");
        testObj.setExpirationDate(null);
        assertNull(testObj.getExpirationDate());
    }

    @Test
    public void setNullExpirationDateWhenEffectiveDateIsNull() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setExpirationDate(null);
        assertNull(testObj.getExpirationDate());
    }

    @Test
    public void hasMatchingCoverageGI() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setCoverageType("test");
        assertTrue(testObj.hasMatchingCoverage("test", null));
        assertFalse(testObj.hasMatchingCoverage("test", 1L));
        assertFalse(testObj.hasMatchingCoverage("test1", null));
    }

    @Test
    public void hasMatchingCoverageFloodPrimary() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setInsurableAssetId(1L);
        testObj.setCoverageType("PRIMARY");
        assertTrue(testObj.hasMatchingCoverage("PRIMARY", 1L));
        assertTrue(testObj.hasMatchingCoverage("PRIMARY_AND_EXCESS", 1L));
        assertFalse(testObj.hasMatchingCoverage("EXCESS", 1L));
        assertFalse(testObj.hasMatchingCoverage("PRIMARY", 2L));
        assertFalse(testObj.hasMatchingCoverage("PRIMARY", null));
    }

    @Test
    public void hasMatchingCoverageFloodExcess() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setInsurableAssetId(1L);
        testObj.setCoverageType("EXCESS");
        assertFalse(testObj.hasMatchingCoverage("PRIMARY", 1L));
        assertTrue(testObj.hasMatchingCoverage("PRIMARY_AND_EXCESS", 1L));
        assertTrue(testObj.hasMatchingCoverage("EXCESS", 1L));
        assertFalse(testObj.hasMatchingCoverage("EXCESS", 2L));
        assertFalse(testObj.hasMatchingCoverage("EXCESS", null));
    }


    @Test
    public void isProvidingCoverage() {
        C3PolicyIssuance testObj = new C3PolicyIssuance();
        testObj.setInsurableAssetId(5L);
        testObj.setCoverageType("PRIMARY");
        testObj.setEffectiveDate("01/01/2019");
        testObj.setExpirationDate("01/01/2020");
        assertTrue(testObj.isProvidingCoverage("PRIMARY", 5L, DATE_FORMATTER.parse("01/01/2019")));
        assertFalse(testObj.isProvidingCoverage("EXCESS", 5L, DATE_FORMATTER.parse("02/01/2019")));
        assertFalse(testObj.isProvidingCoverage("PRIMARY", 53L, DATE_FORMATTER.parse("02/01/2019")));
        assertFalse(testObj.isProvidingCoverage("PRIMARY", 5L, DATE_FORMATTER.parse("02/01/2020")));
    }

}