package com.jpmorgan.cb.wlt.apis.c3.dtos.enums;

import org.junit.Test;

import static org.junit.Assert.*;

public class TestAlthansPropertyType {

    @Test
    public void isCommercial() {
        assertTrue(AlthansPropertyType.COMMERCIAL.isCommercial());
        assertFalse(AlthansPropertyType.CONDO_ASSOC.isCommercial());
        assertTrue(AlthansPropertyType.MULTI_FAMILY.isCommercial());
        assertFalse(AlthansPropertyType.DWELLING_RESIDENTIAL.isCommercial());
    }

    @Test
    public void isResidential() {
        assertFalse(AlthansPropertyType.COMMERCIAL.isResidential());
        assertFalse(AlthansPropertyType.CONDO_ASSOC.isResidential());
        assertFalse(AlthansPropertyType.MULTI_FAMILY.isResidential());
        assertTrue(AlthansPropertyType.DWELLING_RESIDENTIAL.isResidential());
    }

    @Test
    public void isCondoAssociation() {
        assertFalse(AlthansPropertyType.COMMERCIAL.isCondoAssociation());
        assertTrue(AlthansPropertyType.CONDO_ASSOC.isCondoAssociation());
        assertFalse(AlthansPropertyType.MULTI_FAMILY.isCondoAssociation());
        assertFalse(AlthansPropertyType.DWELLING_RESIDENTIAL.isCondoAssociation());
    }

    @Test
    public void getByCode() {
        assertEquals(AlthansPropertyType.COMMERCIAL, AlthansPropertyType.getByCodeOrDesc("COMM"));
        assertEquals(AlthansPropertyType.CONDO_ASSOC, AlthansPropertyType.getByCodeOrDesc("CA"));
        assertEquals(AlthansPropertyType.MULTI_FAMILY, AlthansPropertyType.getByCodeOrDesc("MF"));
        assertEquals(AlthansPropertyType.DWELLING_RESIDENTIAL, AlthansPropertyType.getByCodeOrDesc("DW"));
        assertNull(AlthansPropertyType.getByCodeOrDesc("not valid"));
    }
}