package com.jpmorgan.cb.wlt.apis.collateral.sections;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerServiceImpl;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dtos.SectionStatusDto;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import java.util.*;

import static com.jpmorgan.cb.wlt.TestConstants.COLLATERAL_RID_1;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestSectionStatusAPI {

    @Mock
    private CollateralSectionService collateralSectionService;

    @InjectMocks
    private SectionStatusAPI sectionStatusAPI;
    private static String API="/api/collaterals/"+COLLATERAL_RID_1+"/sectionStatuses";
    private static final ObjectWriter WRITER;
    private MockMvc mockMvc;
    private static final UserRequestInfo CONST_TEST_USER = new UserRequestInfo("testUser");


    static {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        WRITER = mapper.writer().withDefaultPrettyPrinter();
    }

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(sectionStatusAPI)
                .setHandlerExceptionResolvers(new SimpleMappingExceptionResolver()).build();

    }



    @Test
    public void TestgetSectionStatuses(){
        try {
            when(collateralSectionService.getSectionStatuses(COLLATERAL_RID_1)).thenReturn(stubSectionStatusDtos());
            mockMvc.perform(get(API).contentType(APPLICATION_JSON_UTF8))
                    .andExpect(jsonPath("$[0].rid").value(100))
                    .andExpect(status().isOk());
            verify(collateralSectionService).getSectionStatuses(COLLATERAL_RID_1);
        }catch (Exception ex){

        }

    }

    @Test
    public void TestAllowVerification(){
        try {
            UserRequestInfo userRequestInfo = getAdminUserRequestInfo();
            when(collateralSectionService.getSectionStatuses(COLLATERAL_RID_1)).thenReturn(stubSectionStatusDtos());
            mockMvc.perform(post(API+"/allowVerification").contentType(APPLICATION_JSON_UTF8)
                    .requestAttr(CtracAuthenticationManagerServiceImpl.USER_REQUEST_INFO,userRequestInfo))
                    .andExpect(jsonPath("$[0].rid").value(100))
                    .andExpect(status().isOk());
            verify(collateralSectionService).allowAnyVerification(COLLATERAL_RID_1);
        }catch (Exception ex){

        }

    }

    private List<SectionStatusDto> stubSectionStatusDtos(){
        List<SectionStatusDto> sectionStatusDtos=new ArrayList<>();
        SectionStatusDto sectionStatusDto=new SectionStatusDto();
        sectionStatusDto.setRid(100l);
        sectionStatusDto.setCollateralRid(COLLATERAL_RID_1);
        sectionStatusDtos.add(sectionStatusDto);

        return sectionStatusDtos;

    }

    private UserRequestInfo getAdminUserRequestInfo() {
        Map<String, Set<String>> authorities = new HashMap<>();
        String LOCAL_USER = "LOCAL";
        String role = "ROLE_OPERATE_WRITERS";
        UserRequestInfo userRequestInfo = new UserRequestInfo(LOCAL_USER);
        Set<String> set = new HashSet();
        set.add("DCS");
        authorities.put(role, set);


        UserEntitlementsDTO userEntitlement = new UserEntitlementsDTO();
        userEntitlement.setFirstName(LOCAL_USER);
        userEntitlement.setLastName(LOCAL_USER);
        userEntitlement.setJanusUsername(LOCAL_USER);
        userEntitlement.setAuthorities(authorities);
        userRequestInfo.setUserEntitlementsDto(userEntitlement);

        return userRequestInfo;
    }
}
