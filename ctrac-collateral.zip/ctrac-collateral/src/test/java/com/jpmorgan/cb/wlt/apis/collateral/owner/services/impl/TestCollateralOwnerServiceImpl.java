package com.jpmorgan.cb.wlt.apis.collateral.owner.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.owner.dao.CollateralOwnerRepository;
import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;
import com.jpmorgan.cb.wlt.apis.entity.services.EntityService;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralOwnerServiceImpl {
    @Spy
    @InjectMocks
    CollateralOwnerServiceImpl collateralOwnerServiceImpl;

    @Mock
    EntityService entityService;
    @Mock
    private CollateralOwnerRepository collateralOwnerRepository;
    @Mock
    private ModelMapper modelMapper;
    @Mock
    private LoanService loanService;

    Long COLLATERAL_ID = 1L;


    @Test
    public void getUniqueMortgagorAndBorrowerNames() {
        when(collateralOwnerServiceImpl.getCollateralOwners(COLLATERAL_ID)).thenReturn(mockEntityDtos());
        when(loanService.getActiveLoans(COLLATERAL_ID)).thenReturn(mockLoans());
        String borrowerDataList = collateralOwnerServiceImpl.getUniqueMortgagorAndBorrowerNames(1L, "|");
        assertEquals(borrowerDataList, "ABC|UVC|DEF|XYZ|GHI");
    }


    @Test
    public void getUniqueBorrowerNames() {
        when(loanService.getActiveLoans(COLLATERAL_ID)).thenReturn(mockLoans());
        Set<String> borrowerDataList = collateralOwnerServiceImpl.getUniqueBorrowerNames(COLLATERAL_ID);
        assertEquals(2, borrowerDataList.size());
    }


    private List<LoanDTO> mockLoans() {
        LoanDTO loanDTO = new LoanDTO();
        List<LoanDTO> loans = new ArrayList<LoanDTO>();
        List<EntityDTO> customers = new ArrayList<EntityDTO>();
        customers.add(mockEntityDTO(5L, "XYZ"));
        customers.add(mockEntityDTO(6L, "XYZ"));
        customers.add(mockEntityDTO(7L, "UVC"));
        loanDTO.setBorrowers(customers);
        loans.add(loanDTO);
        return loans;
    }

    private EntityDTO mockEntityDTO(Long rid, String name) {
        EntityDTO entityDTO = new EntityDTO();
        entityDTO.setName(name);
        entityDTO.setRid(rid);
        return entityDTO;
    }

    private List<EntityDTO> mockEntityDtos() {
        List<EntityDTO> customerList = new ArrayList<EntityDTO>();
        customerList.add(mockEntityDTO(1l, "ABC"));
        customerList.add(mockEntityDTO(2l, "DEF"));
        customerList.add(mockEntityDTO(3l, "DEF"));
        customerList.add(mockEntityDTO(4l, "GHI"));
        return customerList;
    }

}