package com.jpmorgan.cb.wlt.apis.document.services.impl;

import com.itextpdf.text.pdf.PdfReader;
import com.jpmorgan.cb.wlt.apis.document.builder.DocumentMetaDataBuilder;
import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.FileContent;
import com.jpmorgan.cb.wlt.apis.document.dao.repository.CollateralDocumentRepository;
import com.jpmorgan.cb.wlt.apis.document.dao.repository.EntityCollateralDocumentRepository;
import com.jpmorgan.cb.wlt.apis.document.dao.types.EntityCollateralDocumentRelation;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentSummaryDTO;
import com.jpmorgan.cb.wlt.apis.document.dtos.DocumentMetaDataDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralRequiredCoverageSource;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentSummaryDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TestCollateralDocumentServiceImpl {

    private static Long CONST_COLLATERAL_RID = 1L;
    private static String CONST_DOCUMENT_IDENTIFIER = "identifier";
    private static String CONST_FILE_NAME = "fileName";
    private static byte[] CONST_FILE_CONTENT = "file".getBytes();
    private static Date CONST_DOCUMENT_DATE = new Date();

    @Spy
    @InjectMocks
    private CollateralDocumentServiceImpl service;

    @Mock
    private EntityCollateralDocumentRepository entityCollateralDocumentRepository;

    @Mock
    private CollateralDocumentRepository collateralDocumentRepository;

    private CollateralDocument generateCollateralDocument(Long rid){
        CollateralDocument document = new CollateralDocument();
        document.setRid(rid);
        return document;
    }

    private FileUploadAttachmentDTO generateFileUploadAttachmentDTO(){
        FileUploadAttachmentDTO fileUploadAttachmentDTO = new FileUploadAttachmentDTO();
        FileUploadAttachmentSummaryDTO summaryDTO = new FileUploadAttachmentSummaryDTO();
        summaryDTO.setFileName(CONST_FILE_NAME);
        fileUploadAttachmentDTO.setSummary(summaryDTO);
        fileUploadAttachmentDTO.setFileContent(CONST_FILE_CONTENT);
        return fileUploadAttachmentDTO;
    }

    private DocumentMetaDataDTO generateDocumentMetaData(){
        return DocumentMetaDataBuilder.aDocumentMetaData()
                .withCollateralRid(CONST_COLLATERAL_RID)
                .withDocIdentifier(CONST_DOCUMENT_IDENTIFIER)
                .withDocumentDate(CONST_DOCUMENT_DATE).buildDto();
    }

    @Test
    public void testDeleteAllDocuments_MultipleDocuments(){
        List<CollateralDocument> documentList = new ArrayList<>();
        documentList.add(generateCollateralDocument(1L));
        documentList.add(generateCollateralDocument(2L));

        service.deleteAllDocuments(documentList);

        verify(entityCollateralDocumentRepository,times(2)).deleteByDocument(any(CollateralDocument.class));
    }

    @Test
    public void testDeleteAllDocuments_1Document(){
        List<CollateralDocument> documentList = new ArrayList<>();
        documentList.add(generateCollateralDocument(1L));

        service.deleteAllDocuments(documentList);

        verify(entityCollateralDocumentRepository,times(1)).deleteByDocument(any(CollateralDocument.class));
    }

    @Test
    public void testDeleteAllDocuments_NoDocuments(){
        List<CollateralDocument> documentList = new ArrayList<>();

        service.deleteAllDocuments(documentList);

        verify(entityCollateralDocumentRepository,never()).deleteByDocument(any(CollateralDocument.class));
    }


    @Test
    public void testSaveDocuments_WithAttachment(){
        CollateralDocument expectedReturnDocument = generateCollateralDocument(1L);
        GeneralRequiredCoverageSource coverageSource = new GeneralRequiredCoverageSource();

        ArgumentCaptor<EntityCollateralDocumentRelation> argumentCaptor = ArgumentCaptor.forClass(EntityCollateralDocumentRelation.class);
        EntityCollateralDocumentRelation expectedSave = new EntityCollateralDocumentRelation();
        expectedSave.setDocument(expectedReturnDocument);
        expectedSave.setEntity(coverageSource);
        given(entityCollateralDocumentRepository.save(argumentCaptor.capture())).willReturn(expectedSave);

        List<CollateralDocumentSummaryDTO> documentSummaryDtoList = service.saveDocuments(Collections.singletonList(generateFileUploadAttachmentDTO()),
                coverageSource, generateDocumentMetaData());

        assertThat(documentSummaryDtoList.size()).isEqualTo(1);
        assertThat(documentSummaryDtoList.get(0).getRid()).isEqualTo(1L);
        assertThat(argumentCaptor.getValue().getDocument().getFileContent().getFileContent()).isEqualTo(CONST_FILE_CONTENT);
        assertThat(argumentCaptor.getValue().getDocument().getFileName()).isEqualTo(CONST_FILE_NAME);
        assertThat(argumentCaptor.getValue().getDocument().getCollateralRid()).isEqualTo(CONST_COLLATERAL_RID);
        assertThat(argumentCaptor.getValue().getDocument().getDocIdentifier()).isEqualTo(CONST_DOCUMENT_IDENTIFIER);
        assertThat(argumentCaptor.getValue().getDocument().getDocumentDate()).isEqualTo(CONST_DOCUMENT_DATE);
        verify(entityCollateralDocumentRepository).save(any(EntityCollateralDocumentRelation.class));
    }

    @Test(expected = CtracException.class)
    public void testLookupAndValidateDocument_NoDocumentContent(){
        CollateralDocument existingDoc = new CollateralDocument();
        given(collateralDocumentRepository.getOne(1L)).willReturn(existingDoc);
        service.lookupAndValidateDocument(1L);
    }

    @Test(expected = CtracException.class)
    public void testLookupAndValidateDocument_NoDocument(){
        given(collateralDocumentRepository.getOne(1L)).willReturn(null);
        service.lookupAndValidateDocument(1L);
    }

    @Test(expected = CtracException.class)
    public void testLookupAndValidateDocument_InValidPDF() throws IOException {
        CollateralDocument existingDoc = new CollateralDocument();
        FileContent fileContent = new FileContent();
        fileContent.setFileContent("pdf".getBytes());
        existingDoc.setFileContent(fileContent);
        PdfReader readerMocked = mock(PdfReader.class);
        doReturn(readerMocked).when(service).getPdfReaderFromBytes(fileContent.getFileContent());

        given(readerMocked.getPdfVersion()).willReturn(' ');
        given(collateralDocumentRepository.getOne(1L)).willReturn(existingDoc);
        service.lookupAndValidateDocument(1L);
    }

    @Test
    public void testLookupAndValidateDocument_Success() throws IOException {
        CollateralDocument existingDoc = new CollateralDocument();
        FileContent fileContent = new FileContent();
        fileContent.setFileContent("pdf".getBytes());
        existingDoc.setFileContent(fileContent);
        PdfReader readerMocked = mock(PdfReader.class);
        doReturn(readerMocked).when(service).getPdfReaderFromBytes(fileContent.getFileContent());

        given(readerMocked.getPdfVersion()).willReturn('Y');
        given(collateralDocumentRepository.getOne(1L)).willReturn(existingDoc);

        CollateralDocument collateralDocument = service.lookupAndValidateDocument(1L);
        assertThat(collateralDocument).isEqualTo(collateralDocument);
    }

}
