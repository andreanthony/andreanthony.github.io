package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static junit.framework.TestCase.assertNull;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class TestC3RequestDTO {

    @Test
    public void setFloodComplete() {
        testSetFloodComplete(null, "GENERAL", false);
        testSetFloodComplete("GENERAL", "GENERAL", false);
        testSetFloodComplete("FLOOD", "FLOOD", true);
    }

    private void testSetFloodComplete(String requestedInsType, String expectedReqInsType, boolean expectedIsComplete) {
        C3RequestDTO testObj = new C3RequestDTO();
        testObj.setInsuranceType(requestedInsType);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        testObj.setFloodComplete(c3ResponseDTO);
        assertEquals(expectedReqInsType, testObj.getInsuranceType());
        assertEquals(true, testObj.isInsuranceTypeRequested(expectedReqInsType));
        assertEquals(expectedIsComplete, c3ResponseDTO.isComplete());
    }

    @Test
    public void getGeneralRequiredCoverage() {
        C3RequestDTO testObj = new C3RequestDTO();
        C3RequiredCoverage c3RequiredCoverage = new C3RequiredCoverage();
        c3RequiredCoverage.setInsuranceType("GENERAL");
        c3RequiredCoverage.setCoverageType("Cov");
        testObj.addRequiredCoverage(c3RequiredCoverage);
        assertEquals(c3RequiredCoverage, testObj.getGeneralRequiredCoverage("Cov"));
    }

    @Test
    public void isHoldVerifiedWithLpiDateOnlyFalse() {
        C3RequestDTO testObj = new C3RequestDTO();
        assertFalse(testObj.isHoldVerifiedWithLpiDateOnly());

        ArrayList<Long> holdsVerifiedWithLpiDate = new ArrayList<>();
        testObj.setHoldsVerifiedWithLpiDate(holdsVerifiedWithLpiDate);
        assertFalse(testObj.isHoldVerifiedWithLpiDateOnly());
    }

    @Test
    public void isHoldVerifiedWithLpiDateOnlyTrue() {
        C3RequestDTO testObj = new C3RequestDTO();
        ArrayList<Long> holdsVerifiedWithLpiDate = new ArrayList<>();
        holdsVerifiedWithLpiDate.add(1L);
        testObj.setHoldsVerifiedWithLpiDate(holdsVerifiedWithLpiDate);
        assertTrue(testObj.isHoldVerifiedWithLpiDateOnly());
    }

    @Test
    public void getHoldStartDate() {
        String coverageType = "PRIMARY";
        Long insurableAssetId = 2L;
        C3Hold hold = new C3Hold();
        Date holdStartDate = new Date();
        hold.setHoldStartDate(holdStartDate);
        C3RequestDTO testObj = buildC3RequestDTO(coverageType, insurableAssetId, hold);
        assertEquals(holdStartDate, testObj.getHoldStartDate(coverageType, insurableAssetId));
    }

    public C3RequestDTO buildC3RequestDTO(String coverageType, Long insurableAssetId, C3Hold hold) {
        C3RequestDTO testObj = new C3RequestDTO();
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsuranceType(InsuranceType.FLOOD.name());
        requiredCoverage.setCoverageType(coverageType);
        requiredCoverage.setInsurableAssetId(insurableAssetId);
        requiredCoverage.setHold(hold);
        testObj.addRequiredCoverage(requiredCoverage);
        return testObj;
    }

    @Test
    public void getRequiredCoverageHold() {
        String coverageType = "PRIMARY";
        Long insurableAssetId = 2L;
        assertNull(buildC3RequestDTO(coverageType, insurableAssetId, null)
                .getRequiredCoverageHold(insurableAssetId, FloodCoverageType.PRIMARY));
        C3Hold hold = new C3Hold();
        assertNull(buildC3RequestDTO(coverageType, insurableAssetId, hold)
                .getRequiredCoverageHold(insurableAssetId, FloodCoverageType.EXCESS));
        assertEquals(hold, buildC3RequestDTO(coverageType, insurableAssetId, hold)
                .getRequiredCoverageHold(insurableAssetId, FloodCoverageType.PRIMARY));
    }

    @Test
    public void getAllPolicies() {
        C3RequestDTO testObj = new C3RequestDTO();
        testObj.getLpPolicies().add(buildC3Policy("FLOOD", "LP"));
        testObj.getBorrowerPolicies().add(buildC3Policy("FLOOD", "NFIP"));
        testObj.getLpPolicies().add(buildC3Policy("GENERAL", "GI_LP"));
        testObj.getBorrowerPolicies().add(buildC3Policy("GENERAL", "POLICY"));
        assertEquals(4, testObj.getAllPolicies().size());
        List<C3Policy> floodPolicies = testObj.getAllPolicies(InsuranceType.FLOOD);
        assertEquals(2, floodPolicies.size());
        assertTrue(floodPolicies.get(0).getPolicyType().equals("NFIP") || floodPolicies.get(1).getPolicyType().equals("NFIP"));
        assertTrue(floodPolicies.get(0).getPolicyType().equals("LP") || floodPolicies.get(1).getPolicyType().equals("LP"));
        List<C3Policy> generalPolicies = testObj.getAllPolicies(InsuranceType.GENERAL);
        assertEquals(2, generalPolicies.size());
        assertTrue(generalPolicies.get(0).getPolicyType().equals("POLICY") || generalPolicies.get(1).getPolicyType().equals("POLICY"));
        assertTrue(generalPolicies.get(0).getPolicyType().equals("GI_LP") || generalPolicies.get(1).getPolicyType().equals("GI_LP"));
    }

    private C3Policy buildC3Policy(String insuranceType, String policyType) {
        return buildC3Policy(insuranceType, policyType, null);
    }

    private C3Policy buildC3Policy(String insuranceType, String policyType, String status) {
        C3Policy policy = new C3Policy();
        policy.setInsuranceType(insuranceType);
        policy.setPolicyType(policyType);
        policy.setPolicyStatus(status);
        return policy;
    }

    @Test
    public void getExpiringPolicies() {
        C3RequestDTO testObj = new C3RequestDTO();
        C3Policy expiringFloodLp = buildC3Policy("FLOOD", "LP", "EXPIRING");
        testObj.getLpPolicies().add(expiringFloodLp);
        C3Policy expiringFloodBp = buildC3Policy("FLOOD", "NFIP", "EXPIRING");
        C3Policy paidFloodLp = buildC3Policy("FLOOD", "LP", "PAID");
        testObj.getLpPolicies().add(paidFloodLp);
        testObj.getBorrowerPolicies().add(expiringFloodBp);
        C3Policy expiringGeneralLp = buildC3Policy("GENERAL", "GI_LP", "EXPIRING");
        testObj.getLpPolicies().add(expiringGeneralLp);
        C3Policy expiringGeneralBp = buildC3Policy("GENERAL", "POLICY", "EXPIRING");
        testObj.getBorrowerPolicies().add(expiringGeneralBp);
        C3Policy acceptedGeneralBp = buildC3Policy("GENERAL", "POLICY", "ACCEPTED");
        testObj.getBorrowerPolicies().add(acceptedGeneralBp);
        assertEquals(2, testObj.getExpiringPolicies(testObj.getAllPolicies(InsuranceType.FLOOD)).size());
        assertTrue(testObj.getExpiringPolicies(testObj.getAllPolicies(InsuranceType.FLOOD)).contains(expiringFloodLp));
        assertTrue(testObj.getExpiringPolicies(testObj.getAllPolicies(InsuranceType.FLOOD)).contains(expiringFloodBp));
        assertEquals(2, testObj.getExpiringPolicies(testObj.getAllPolicies(InsuranceType.GENERAL)).size());
        assertTrue(testObj.getExpiringPolicies(testObj.getAllPolicies(InsuranceType.GENERAL)).contains(expiringGeneralLp));
        assertTrue(testObj.getExpiringPolicies(testObj.getAllPolicies(InsuranceType.GENERAL)).contains(expiringGeneralBp));
        assertEquals(4, testObj.getExpiringPolicies(testObj.getAllPolicies()).size());
        assertTrue(testObj.getExpiringPolicies(testObj.getAllPolicies()).contains(expiringFloodLp));
        assertTrue(testObj.getExpiringPolicies(testObj.getAllPolicies()).contains(expiringFloodBp));
        assertTrue(testObj.getExpiringPolicies(testObj.getAllPolicies()).contains(expiringGeneralLp));
        assertTrue(testObj.getExpiringPolicies(testObj.getAllPolicies()).contains(expiringGeneralBp));
    }
}