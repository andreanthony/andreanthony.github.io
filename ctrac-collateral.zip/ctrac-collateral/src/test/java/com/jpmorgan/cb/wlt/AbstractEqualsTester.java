package com.jpmorgan.cb.wlt;

import static org.junit.Assert.*;

public abstract class AbstractEqualsTester {

    protected void checkDefault(Object one) {
        checkEqual(one, one);
        checkNotEqual(one, "two");
        checkNull(one);
    }

    protected void checkEqual(Object one, Object two) {
        assertTrue("Check one equals two", one.equals(two));
        assertTrue("Check two equals one", two.equals(one));
        assertEquals("Check that objects that equal have same hashCode", one.hashCode(), two.hashCode());
    }

    protected void checkNotEqual(Object one, Object two) {
        assertFalse("Check one does not equal two", one.equals(two));
        assertFalse("Check two does not equal one", two.equals(one));
    }

    private void checkNull(Object one) {
        if(one != null) {
            assertFalse("Check object does not equal null", one.equals(null));
        }
    }
}
