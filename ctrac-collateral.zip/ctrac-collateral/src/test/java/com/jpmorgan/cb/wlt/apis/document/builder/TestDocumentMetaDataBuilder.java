package com.jpmorgan.cb.wlt.apis.document.builder;

import com.jpmorgan.cb.wlt.apis.document.dtos.DocumentMetaDataDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class TestDocumentMetaDataBuilder {


    @Test
    public void testDocumentMetaDataBuildDto(){
        Date documentDate = new Date();
        String docId = "testId";
        Long colId = 1L;

        DocumentMetaDataDTO dto = DocumentMetaDataBuilder.aDocumentMetaData()
                .withDocumentDate(documentDate)
                .withDocIdentifier(docId)
                .withCollateralRid(colId).buildDto();

        assertThat(dto.getCollateralRid()).isEqualTo(colId);
        assertThat(dto.getDocIdentifier()).isEqualTo(docId);
        assertThat(dto.getDocumentDate()).isEqualTo(documentDate);
    }
}
