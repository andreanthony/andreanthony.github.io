package com.jpmorgan.cb.wlt.apis.collateral.sections.impl;

import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralScreenSection;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestCollateralScreenSection {

    @Test
    public void test(){
        testCollateralScreenName("Collateral Details Section",CollateralScreenSection.COLLATERAL_DETAILS);
        testCollateralScreenName("Borrower/Loan Information Section",CollateralScreenSection.BORROWER_LOAN);
        testCollateralScreenName("Collateral Owner Section",CollateralScreenSection.COLLATERAL_OWNER);
    }


    private void testCollateralScreenName(String expectedDisplayValue, CollateralScreenSection collateralScreenSection){
        assertEquals(expectedDisplayValue,collateralScreenSection.getDisplayName());

    }
}
