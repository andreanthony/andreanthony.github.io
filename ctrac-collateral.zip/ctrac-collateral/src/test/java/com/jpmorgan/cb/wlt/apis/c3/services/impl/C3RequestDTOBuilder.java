package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Loan;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequiredCoverage;
import com.jpmorgan.cib.wlt.ctrac.enums.*;

import java.math.BigDecimal;

public class C3RequestDTOBuilder {

    private C3RequestDTO c3RequestDTO = new C3RequestDTO();

    public C3RequestDTOBuilder(String currentReferenceDate, CollateralStatus collateralStatus, LoanStatus loanStatus, String floodZone) {
        c3RequestDTO.setCurrentReferenceDate(currentReferenceDate);
        c3RequestDTO.setCollateralStatus(collateralStatus.name());
        C3Loan loan = new C3Loan();
        loan.setStatus(loanStatus.name());
        c3RequestDTO.getLoans().add(loan);
        c3RequestDTO.getFloodDetermination().setFloodZone(floodZone);
    }

    public C3RequestDTOBuilder requiredFloodCoverage(Long insurableAssetId, InsurableAssetType insurableAssetType,
                                                     FloodCoverageType coverageType, BigDecimal coverageAmount, String propertyType) {
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsuranceType(InsuranceType.FLOOD.name());
        requiredCoverage.setInsurableAssetId(insurableAssetId);
        requiredCoverage.setInsurableAssetType(insurableAssetType.name());
        requiredCoverage.setCoverageType(coverageType.name());
        requiredCoverage.setCoverageAmount(coverageAmount);
        requiredCoverage.setPropertyType(propertyType);
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        return this;
    }

    public C3RequestDTOBuilder requiredGeneralCoverage(String coverageType, BigDecimal coverageAmount) {
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsuranceType(InsuranceType.GENERAL.name());
        requiredCoverage.setCoverageType(coverageType);
        requiredCoverage.setCoverageAmount(coverageAmount);
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        return this;
    }

    public C3RequestDTOBuilder borrowerPolicy(C3Policy borrowerPolicy) {
        c3RequestDTO.getBorrowerPolicies().add(borrowerPolicy);
        return this;
    }

    public C3RequestDTOBuilder lpPolicy(C3Policy lpPolicy) {
        c3RequestDTO.getLpPolicies().add(lpPolicy);
        return this;
    }

    public C3RequestDTO build() {
        return c3RequestDTO;
    }
}
