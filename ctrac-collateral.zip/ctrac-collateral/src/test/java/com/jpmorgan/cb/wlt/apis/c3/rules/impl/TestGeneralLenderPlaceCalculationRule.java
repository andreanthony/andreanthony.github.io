package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.DATE_FORMATTER;
import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.mockGeneralPolicy;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class TestGeneralLenderPlaceCalculationRule {
    private GeneralLenderPlaceCalculationRule testObj;

    @Before
    public void setUp() {
        testObj = new GeneralLenderPlaceCalculationRule();
    }

    @Test
    public void executeNoBorrowerProvided() {
        testExecute(10000, 0, "GI_LP", 10000);
    }

    @Test
    public void executeNoBorrowerProvidesrequiredAmount() {
        testExecute(10000, 10000, null, 0);
    }

    @Test
    public void executeBorrowerProvidesUnderToleranceAmount() {
        testExecute(10000, 9000, null, 0);
    }

    @Test
    public void executeBorrowerProvidesOverToleranceAmount() {
        testExecute(10000, 8999, "GI_LP_GAP", 1001);
    }

    void testExecute(int required, int provided, String expectedPolicyType, Integer lpAmount) {
        BigDecimal requiredCoverageAmount = new BigDecimal(required);
        BigDecimal providedCoverageAmount = new BigDecimal(provided);
        BigDecimal lpCoverageAmount = new BigDecimal(lpAmount);
        String insuranceType = "GENERAL";
        String coverageType = "coverageType";
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate c3CalculatedCoverageDate = new C3CalculatedCoverageDate();
        Date coverageDate = DATE_FORMATTER.parse("02/02/2018");;
        c3CalculatedCoverageDate.setCoverageDate(coverageDate);
        c3CalculatedCoverageDate.setCoverageType(coverageType);
        c3CalculatedCoverageDate.setInsuranceType(insuranceType);
        c3CalculatedCoverageDate.setPolicyId(1L);
        c3ResponseDTO.getCalculatedGeneralCoverageDates().add(c3CalculatedCoverageDate);

        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsuranceType(insuranceType);
        requiredCoverage.setCoverageType(coverageType);
        requiredCoverage.setCoverageAmount(requiredCoverageAmount);
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        Long collateralRid = 5L;
        c3RequestDTO.setCollateralRid(collateralRid);
        c3RequestDTO.addRequiredCoverage(requiredCoverage);
        Long policyId = 1L;
        if (providedCoverageAmount != null) {
            C3Policy policy = mockGeneralPolicy(policyId, PolicyType.NFIP, PolicyStatus.ACCEPTED, coverageType);
            //TODO policy.setLpAction = NEW_BP;
            policy.getProvidedCoverages().get(0).setCoverageAmount(providedCoverageAmount);
            c3RequestDTO.getBorrowerPolicies().add(policy);
        }
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        if (expectedPolicyType == null) {
            assertEquals(0, c3ResponseDTO.getPoliciesToIssue().size());
        }
        else {
            assertEquals(1, c3ResponseDTO.getPoliciesToIssue().size());
            C3PolicyIssuance c3PolicyIssuance = c3ResponseDTO.getPoliciesToIssue().get(0);
            assertEquals(expectedPolicyType, c3PolicyIssuance.getPolicyType().name());
            assertEquals(coverageType, c3PolicyIssuance.getCoverageType());
            assertEquals(lpCoverageAmount, c3PolicyIssuance.getCoverageAmount());
            assertEquals(coverageDate, c3PolicyIssuance.getEffectiveDate_());
            assertEquals(collateralRid, c3PolicyIssuance.getCollateralRid());
            assertEquals(policyId, c3PolicyIssuance.getParentPolicyId());
            if (PolicyType.GI_LP_GAP.name().equals(expectedPolicyType)) {
                assertEquals(policyId, c3PolicyIssuance.getGapBorrowerPolicyId());
            } else {
                assertNull(c3PolicyIssuance.getGapBorrowerPolicyId());
            }
        }

    }

    @Test
    public void getLpAmount() {
        BigDecimal requiredAmount = new BigDecimal(10000);
        testGetLpAmount(requiredAmount, new BigDecimal(10000), new BigDecimal(0));
        testGetLpAmount(requiredAmount, new BigDecimal(9999), new BigDecimal(1));
        testGetLpAmount(requiredAmount, new BigDecimal(9999.9), new BigDecimal(0));
        testGetLpAmount(requiredAmount, new BigDecimal(9999.1), new BigDecimal(0));
    }

    void testGetLpAmount(BigDecimal requiredAmount, BigDecimal providedAmount, BigDecimal expectedAmount) {
        assertEquals(expectedAmount, testObj.getLpAmount(requiredAmount, providedAmount));
    }

    @Test
    public void getLpPolicyType() {
        assertEquals(PolicyType.GI_LP_GAP, testObj.getLpPolicyType(new BigDecimal(1)));
        assertEquals(PolicyType.GI_LP, testObj.getLpPolicyType(new BigDecimal(0)));
    }
}