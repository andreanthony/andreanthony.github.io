package com.jpmorgan.cb.wlt.apis.batch.services.impl;

import com.jpmorgan.cb.wlt.dao.BatchCtrl;
import com.jpmorgan.cb.wlt.dao.BatchCtrlRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestBatchCtrlServiceImpl {

    @InjectMocks
    private BatchCtrlServiceImpl batchCtrlServiceImpl;

    @Mock
    private BatchCtrlRepository batchCtrlRepository;

    List<BatchCtrl> batchCtrlList=new ArrayList<BatchCtrl>();
    List<BatchCtrl> emptyBatchCtrlList=new ArrayList<BatchCtrl>();

    @Before
    public void setUp() {
        BatchCtrl batchCtrl=new BatchCtrl();
        batchCtrlList.add(batchCtrl);
    }

    @Test
    public void testIsBatchRunningTrue() {
        when(batchCtrlRepository.findByRunningAndBatchTypeIn(any(Character.class),any(List.class))).thenReturn(batchCtrlList);
        assertTrue(batchCtrlServiceImpl.isBatchRunning());
    }

    @Test
    public void testIsBatchRunningFalse() {
        when(batchCtrlRepository.findByRunningAndBatchTypeIn(any(Character.class),any(List.class))).thenReturn(emptyBatchCtrlList);
        assertFalse(batchCtrlServiceImpl.isBatchRunning());
    }
}