package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.*;
import static org.hamcrest.MatcherAssert.assertThat;

public class TestAlertLenderPlaceRestrictionRule {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    private AlertLenderPlaceRestrictionRule testObj;

    @Before
    public void setUp() {
        testObj = new AlertLenderPlaceRestrictionRule();
    }

    @Test
    public void testInactiveLpPolicy() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.EXPIRED, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate calculatedCoverageDate = mockCalculatedCoverageDate(
                InsuranceType.FLOOD, "09/07/2018", 4001L, FloodCoverageType.PRIMARY);
        c3ResponseDTO.getCalculatedFloodCoverageDates().add(calculatedCoverageDate);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertAlertEmail(c3ResponseDTO, C3AlertEmailTemplate.INACTIVE_LP_POLICY, calculatedCoverageDate);
        assertThat(calculatedCoverageDate.isValid(), Matchers.is(false));
    }

    @Test
    public void testBeforeLpPolicy() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.PAID, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate calculatedCoverageDate = mockCalculatedCoverageDate(
                InsuranceType.FLOOD, "09/07/2017", 4001L, FloodCoverageType.PRIMARY);
        c3ResponseDTO.getCalculatedFloodCoverageDates().add(calculatedCoverageDate);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertAlertEmail(c3ResponseDTO, C3AlertEmailTemplate.SUBSEQUENT_LP_POLICY, calculatedCoverageDate);
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(DATE_FORMATTER.parse("01/01/2018")));
        assertThat(calculatedCoverageDate.isValid(), Matchers.is(true));
    }
    @Test
    public void testBeforeLpPolicyGeneral() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockGeneralPolicy(1L, PolicyType.GI_LP, PolicyStatus.PAID, "cov");
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate calculatedCoverageDate = mockCalculatedCoverageDate(
                InsuranceType.GENERAL, "09/07/2017", null, "cov");
        c3ResponseDTO.getCalculatedGeneralCoverageDates().add(calculatedCoverageDate);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertAlertEmail(c3ResponseDTO, C3AlertEmailTemplate.SUBSEQUENT_LP_POLICY, calculatedCoverageDate);
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(DATE_FORMATTER.parse("01/01/2018")));
        assertThat(calculatedCoverageDate.isValid(), Matchers.is(true));
    }

    @Test
    public void testDuringLpPolicy() {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        C3Policy policy = mockFloodPolicy(1L, PolicyType.LP, PolicyStatus.PAID, FloodCoverageType.PRIMARY.name());
        c3RequestDTO.getLpPolicies().add(policy);
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate calculatedCoverageDate = mockCalculatedCoverageDate(
                InsuranceType.FLOOD, "09/07/2018", 4001L, FloodCoverageType.PRIMARY);
        c3ResponseDTO.getCalculatedFloodCoverageDates().add(calculatedCoverageDate);
        testObj.execute(c3RequestDTO, c3ResponseDTO);
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(0));
        assertThat(calculatedCoverageDate.getCoverageDate(), Matchers.is(DATE_FORMATTER.parse("09/07/2018")));
        assertThat(calculatedCoverageDate.isValid(), Matchers.is(true));
    }

    private void assertAlertEmail(C3ResponseDTO c3ResponseDTO, C3AlertEmailTemplate alertEmailTemplate, C3CalculatedCoverageDate calculatedCoverageDate) {
        assertThat(c3ResponseDTO.getAlertEmails().size(), Matchers.is(1));
        C3AlertEmail alertEmail = c3ResponseDTO.getAlertEmails().get(0);
        assertThat(alertEmail.getAlertTemplate(), Matchers.is(alertEmailTemplate));
        assertThat(alertEmail.getCalculatedCoverageDate(), Matchers.is(calculatedCoverageDate));
        assertThat(alertEmail.getLpPolicyId(), Matchers.is(1L));
    }
}
