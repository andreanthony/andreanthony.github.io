package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;

import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.DATE_FORMATTER;
import static com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3RuleTestUtil.mockGeneralPolicy;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class TestFloodLenderPlaceCalculationRule {

    private FloodLenderPlaceCalculationRule testObj;
    Long borrowerPolicyRid = 11L;

    @Before
    public void setUp() {
        testObj = new FloodLenderPlaceCalculationRule();
    }

    @Test
    public void executeNoBorrowerProvided() {
        testExecute(10000, 0, "LP", 10000, "PRIMARY");
        testExecute(10000, 0, "LP_EXCESS", 10000, "EXCESS");
    }

    @Test
    public void executeBorrowerProvidesRequiredAmount() {
        testExecute(10000, 10000, null, 0, "PRIMARY");
        testExecute(10000, 10000, null, 0, "EXCESS");
    }

    @Test
    public void executeBorrowerProvidesUnderToleranceAmount() {
        testExecute(10000, 9000, null, 0, "PRIMARY");
        testExecute(10000, 9000, null, 0, "EXCESS");
    }

    @Test
    public void executeBorrowerProvidesOverToleranceAmount() {
        testExecute(10000, 8999, "LP_GAP", 1001, "PRIMARY");
        testExecute(10000, 8999, "LP_EXCESS", 1001, "EXCESS");
    }

    @Test
    public void executeOverLimit() {
        testExecute(3000000, 0, "LP", 250000, "PRIMARY");
    }


    void testExecute(int required, int provided, String expectedPolicyType, Integer lpAmount, String coverageType) {
        BigDecimal requiredCoverageAmount = new BigDecimal(required);
        BigDecimal providedCoverageAmount = new BigDecimal(provided);
        BigDecimal lpCoverageAmount = new BigDecimal(lpAmount);
        String insuranceType = "FLOOD";
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        C3CalculatedCoverageDate c3CalculatedCoverageDate = new C3CalculatedCoverageDate();
        Date coverageDate = DATE_FORMATTER.parse("02/01/2018");
        c3CalculatedCoverageDate.setCoverageDate(coverageDate);
        c3CalculatedCoverageDate.setCoverageType(coverageType);
        c3CalculatedCoverageDate.setInsuranceType(insuranceType);
        long insurableAssetId = 2L;
        c3CalculatedCoverageDate.setInsurableAssetId(insurableAssetId);
        String structure = "STRUCTURE";
        c3CalculatedCoverageDate.setInsurableAssetType(InsurableAssetType.STRUCTURE);
        c3CalculatedCoverageDate.setPolicyId(1L);
        c3CalculatedCoverageDate.setValid(true);
        c3ResponseDTO.getCalculatedFloodCoverageDates().add(c3CalculatedCoverageDate);

        C3AlertEmail c3AlertEmail = new C3AlertEmail();
        c3AlertEmail.setAlertTemplate(C3AlertEmailTemplate.SUBSEQUENT_LP_POLICY);
        c3ResponseDTO.getAlertEmails().add(c3AlertEmail);

        C3AlertEmail c3AlertEmail2 = new C3AlertEmail();
        c3AlertEmail2.setAlertTemplate(C3AlertEmailTemplate.INACTIVE_LP_POLICY);
        c3ResponseDTO.getAlertEmails().add(c3AlertEmail2);

        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        if ("EXCESS".equals(coverageType)) {
            // cannot have excess requirement without primary
            c3RequestDTO.addRequiredCoverage(getC3RequiredCoverage(
                    "PRIMARY", requiredCoverageAmount, insuranceType, insurableAssetId, structure));
            c3RequestDTO.getBorrowerPolicies().add(getC3Policy(
                    "PRIMARY", requiredCoverageAmount, insuranceType, insurableAssetId, structure));
        }
        c3RequestDTO.addRequiredCoverage(getC3RequiredCoverage(
                coverageType, requiredCoverageAmount, insuranceType, insurableAssetId, structure));

        if (provided > 0) {
            c3RequestDTO.getBorrowerPolicies().add(getC3Policy(
                    coverageType, providedCoverageAmount, insuranceType, insurableAssetId, structure));
        }
        C3FloodDetermination floodDetermination = new C3FloodDetermination();
        floodDetermination.setFloodZone("A");
        c3RequestDTO.setFloodDetermination(floodDetermination);
        c3RequestDTO.setInsuredName("Insured Name");

        testObj.execute(c3RequestDTO, c3ResponseDTO);
        if (expectedPolicyType == null) {
            assertEquals(0, c3ResponseDTO.getPoliciesToIssue().size());
        }
        else {
            assertEquals(1, c3ResponseDTO.getPoliciesToIssue().size());
            C3PolicyIssuance c3PolicyIssuance = c3ResponseDTO.getPoliciesToIssue().get(0);
            assertEquals(expectedPolicyType, c3PolicyIssuance.getPolicyType().name());
            assertEquals(coverageType, c3PolicyIssuance.getCoverageType());
            assertEquals(lpCoverageAmount, c3PolicyIssuance.getCoverageAmount());
            assertEquals(coverageDate, c3PolicyIssuance.getEffectiveDate_());
            assertEquals("A", c3PolicyIssuance.getFloodZone());
            assertEquals("Insured Name", c3PolicyIssuance.getInsuredName());
            assertEquals(LPAction.NEW_LP, c3PolicyIssuance.getLpAction());
            if (provided > 0) {
                assertEquals(borrowerPolicyRid, c3PolicyIssuance.getGapBorrowerPolicyId());
            }
            else {
                assertNull(c3PolicyIssuance.getGapBorrowerPolicyId());
            }
        }
    }

    private C3Policy getC3Policy(String coverageType, BigDecimal providedCoverageAmount, String insuranceType, long insurableAssetId, String structure) {
        C3Policy policy = mockGeneralPolicy(borrowerPolicyRid, PolicyType.NFIP, PolicyStatus.ACCEPTED, coverageType);
        //TODO policy.setLpAction = NEW_BP;
        policy.getProvidedCoverages().get(0).setCoverageAmount(providedCoverageAmount);
        policy.getProvidedCoverages().get(0).setInsurableAssetId(insurableAssetId);
        policy.getProvidedCoverages().get(0).setInsurableAssetType(structure);
        policy.setInsuranceType(insuranceType);
        return policy;
    }

    private C3RequiredCoverage getC3RequiredCoverage(String coverageType, BigDecimal requiredCoverageAmount, String insuranceType, long insurableAssetId, String structure) {
        C3RequiredCoverage requiredCoverage = new C3RequiredCoverage();
        requiredCoverage.setInsuranceType(insuranceType);
        requiredCoverage.setCoverageType(coverageType);
        requiredCoverage.setCoverageAmount(requiredCoverageAmount);
        requiredCoverage.setInsurableAssetId(insurableAssetId);
        requiredCoverage.setInsurableAssetType(structure);
        requiredCoverage.setPropertyType("DW");
        return requiredCoverage;
    }

}