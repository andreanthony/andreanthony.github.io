package com.jpmorgan.cb.wlt.apis.c3.dtos.enums;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by E704298 on 7/11/2017.
 */
public class TestFIATPropertyType {

    @Test
    public void testSize() {
        assertEquals(5, FIATPropertyType.values().length);
    }

    @Test
    public void testDwellingResidential() {
        assertEquals("Dwelling (1-4 Unit) Residential", FIATPropertyType.DWELLING_RESIDENTIAL.getDisplayName());
    }

    @Test
    public void testMultiFamily() {
        assertEquals("5+ Multi Family", FIATPropertyType.MULTI_FAMILY.getDisplayName());
    }

    @Test
    public void testCommercial() {
        assertEquals("Commercial", FIATPropertyType.COMMERCIAL.getDisplayName());
    }

    @Test
    public void testCommercialCondoAssociation() {
        assertEquals("Commercial Condo Association", FIATPropertyType.COMMERCIAL_CONDO_ASSOCIATION.getDisplayName());
    }

    @Test
    public void testResidentialCondoAssociation() {
        assertEquals("Residential Condo Association", FIATPropertyType.RESIDENTIAL_CONDO_ASSOCIATION.getDisplayName());
    }

}
