create table tlcp_loan_borrower (
  LOAN_ID	NUMBER(20,0),
  BORROWER_ID	NUMBER(20,0),
  PRIMARY KEY (LOAN_ID,BORROWER_ID)
);
