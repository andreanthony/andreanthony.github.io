Update TLCP_LOOKUP_CODES set code = 'GENERAL_REQ_COV' where RID = 1400;
Update TLCP_LOOKUP_CODES set code = 'GENERAL_BP' where RID = 1401;
Update TLCP_LOOKUP_CODES set code = 'GENERAL_LP' where RID = 1402;