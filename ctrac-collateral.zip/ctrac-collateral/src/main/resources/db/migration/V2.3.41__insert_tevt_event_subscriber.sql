insert into tevt_event_subscriber values ('Verify Collateral','ctrac.workflow.verifyCollateral.api.url');
commit;