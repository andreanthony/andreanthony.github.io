insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
  values(1400,'FILE_UPLOAD_BUCKET_CATEGORY','REQCOV','REQUIRED_COVERAGE','Y','ADMIN',sysdate,1);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
  values(1401,'FILE_UPLOAD_BUCKET_CATEGORY','BP','BORROWER_POLICY','Y','ADMIN',sysdate,2);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
  values(1402,'FILE_UPLOAD_BUCKET_CATEGORY','LPP','LENDER_PLACEMENT_POLICY','Y','ADMIN',sysdate,3);