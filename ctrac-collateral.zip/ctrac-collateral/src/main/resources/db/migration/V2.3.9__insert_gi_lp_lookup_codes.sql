insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1301,'GENERAL_COVERAGE_BALANCE_TYPE','ACV','ACV','N','ADMIN',sysdate,1);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1302,'GENERAL_COVERAGE_BALANCE_TYPE','RCV','RCV','Y','ADMIN',sysdate,2);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1303,'GENERAL_COVERAGE_BALANCE_TYPE','UPB','UPB','Y','ADMIN',sysdate,3);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1311,'GENERAL_COVERAGE_REQUIREMENT_SOURCE','Closing Documentation','Closing Documentation','Y','ADMIN',sysdate,1);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1312,'GENERAL_COVERAGE_REQUIREMENT_SOURCE','Annual Rent Roll(s)','Annual Rent Roll(s)','Y','ADMIN',sysdate,2);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1313,'GENERAL_COVERAGE_REQUIREMENT_SOURCE','Last Known Coverage Amount','Last Known Coverage Amount','Y','ADMIN',sysdate,3);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1314,'GENERAL_COVERAGE_REQUIREMENT_SOURCE','SBA Credit Approval','SBA Credit Approval','Y','ADMIN',sysdate,4);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1315,'GENERAL_COVERAGE_REQUIREMENT_SOURCE','Waiver','Waiver','Y','ADMIN',sysdate,5);
insert into TLCP_LOOKUP_CODES (rid,codeset,code,description,active,inserted_by,inserted_date,sort_order)
values(1316,'GENERAL_COVERAGE_REQUIREMENT_SOURCE','Migration Data','Migration Data','Y','ADMIN',sysdate,6);