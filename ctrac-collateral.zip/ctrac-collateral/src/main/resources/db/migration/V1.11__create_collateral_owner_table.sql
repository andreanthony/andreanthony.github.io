create table tlcp_collateral_owner(
  COLLATERAL_ID	NUMBER(20,0),
  CUSTOMER_ID	NUMBER(20,0),
  PRIMARY KEY (COLLATERAL_ID,CUSTOMER_ID)
);
