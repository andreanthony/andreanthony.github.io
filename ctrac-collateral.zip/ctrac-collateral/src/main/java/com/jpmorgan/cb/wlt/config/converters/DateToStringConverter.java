package com.jpmorgan.cb.wlt.config.converters;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.modelmapper.AbstractConverter;

import java.util.Date;

public class DateToStringConverter extends AbstractConverter<Date, String> {
    private static final DateTimeFormatter US_DATE_FORMAT = DateTimeFormat.forPattern("MM/dd/yyyy");

    @Override
    protected String convert(Date date) {
        if (date == null) {
            return null;
        }
        return US_DATE_FORMAT.print(date.getTime());
    }
}
