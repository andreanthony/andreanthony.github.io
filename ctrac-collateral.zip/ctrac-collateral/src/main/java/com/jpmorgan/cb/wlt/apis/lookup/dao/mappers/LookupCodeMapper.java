package com.jpmorgan.cb.wlt.apis.lookup.dao.mappers;

import com.jpmorgan.cb.wlt.apis.lookup.dao.LookupCode;
import com.jpmorgan.cb.wlt.apis.lookup.dtos.LookupCodeDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

public class LookupCodeMapper implements DaoMapper<LookupCode, LookupCodeDTO> {

    @Override
    public LookupCodeDTO toDTO(LookupCode model) {
        LookupCodeDTO dto = new LookupCodeDTO();
        dto.setRid(model.getRid());
        dto.setActive(model.getActive());
        dto.setCode(model.getCode());
        dto.setCodeSet(model.getCodeSet());
        dto.setDescription(model.getDescription());
        dto.setSortOrder(model.getSortOrder());
        dto.setChildCodeSet(model.getChildCodeSet());
        return dto;
    }

    @Override
    public boolean map(LookupCodeDTO dto, LookupCode model) {
        //Lookup Code DTO should not get mapped
        return false;
    }
}
