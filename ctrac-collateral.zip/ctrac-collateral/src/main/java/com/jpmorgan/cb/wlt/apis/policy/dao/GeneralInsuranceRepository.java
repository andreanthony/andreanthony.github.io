package com.jpmorgan.cb.wlt.apis.policy.dao;

import org.springframework.data.jpa.repository.JpaRepository;


public interface GeneralInsuranceRepository extends JpaRepository<GeneralInsurance, Long> {


}
