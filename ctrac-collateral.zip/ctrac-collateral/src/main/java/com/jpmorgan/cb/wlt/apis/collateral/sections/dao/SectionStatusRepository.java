package com.jpmorgan.cb.wlt.apis.collateral.sections.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SectionStatusRepository extends JpaRepository<SectionStatus, Long> {
    List<SectionStatus> findByCollateralRid(Long collateralRid);
    SectionStatus findByCollateral_RidAndSectionId(Long collateralRid, String sectionId);
}
