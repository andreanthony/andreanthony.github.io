package com.jpmorgan.cb.wlt.apis.policy.dtos;

import com.jpmorgan.cb.wlt.apis.policy.services.impl.BorrowerInsuranceReviewConclusion;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class PolicyAttributeDTO {
    public PolicyAttributeDTO() {
        this(null, BorrowerInsuranceReviewConclusion.NONE.name());
    }

    public PolicyAttributeDTO(String value, String conclusion) {
        this.value = value;
        this.conclusion = conclusion;
    }
    private String value;
    private String conclusion;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getConclusion() {
        return conclusion;
    }

    public void setConclusion(String conclusion) {
        this.conclusion = conclusion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        PolicyAttributeDTO that = (PolicyAttributeDTO) o;

        return new EqualsBuilder()
                .append(value, that.value)
                .isEquals() && hasMatchingConclusion(conclusion, that.conclusion);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(value)
                .append(conclusion)
                .toHashCode();
    }

    private boolean hasMatchingConclusion(String value1, String value2){
        String _value1 = StringUtils.defaultString(value1, BorrowerInsuranceReviewConclusion.NONE.name());
        String _value2 = StringUtils.defaultString(value2, BorrowerInsuranceReviewConclusion.NONE.name());
        return _value1.compareTo(_value2) == 0;
    }



}
