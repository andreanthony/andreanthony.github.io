package com.jpmorgan.cb.wlt.apis.upload.dao;

import com.jpmorgan.cb.wlt.apis.upload.dao.mappers.FileUploadAttachmentMapper;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "TLCP_FILE_UPLOAD_ATTACHMENT")
public class FileUploadAttachment extends AuditableEntity implements Serializable {
    private static final long serialVersionUID = -1;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "fileUploadAttachmentSeqGenerator")
    @TableGenerator(name = "fileUploadAttachmentSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_FILE_UPLOAD_ATTACHMENT", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Column(name = "RID")
    private Long rid;

    @Column(name = "BUCKET_NAME")
    private String bucketName;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Lob
    @Column(name = "FILE_CONTENT", nullable = false)
    private byte[] fileContent;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getFileContent() {
        return fileContent;
    }

    public void setFileContent(byte[] fileContent) {
        this.fileContent = fileContent;
    }

    public FileUploadAttachmentDTO toFileUploadAttachmentDTO() {
        return new FileUploadAttachmentMapper().toDTO(this);
    }

    public boolean map(FileUploadAttachmentDTO fileUploadAttachmentDTO) {
        return new FileUploadAttachmentMapper().map(fileUploadAttachmentDTO, this);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        FileUploadAttachment that = (FileUploadAttachment) o;

        return new EqualsBuilder()
                .append(rid, that.rid)
                .append(bucketName, that.bucketName)
                .append(fileName, that.fileName)
                .append(fileContent, that.fileContent)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(bucketName)
                .append(fileName)
                .append(fileContent)
                .toHashCode();
    }

}
