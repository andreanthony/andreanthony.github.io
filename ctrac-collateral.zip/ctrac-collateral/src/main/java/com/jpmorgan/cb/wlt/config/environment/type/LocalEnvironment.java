package com.jpmorgan.cb.wlt.config.environment.type;


import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerService;

import javax.servlet.http.HttpServletRequest;

public class LocalEnvironment extends AbstractEnvironment{

    public LocalEnvironment(CtracAuthenticationManagerService ctracAuthenticationManagerService) {
        super(ctracAuthenticationManagerService);
    }

    public String getUserNameFromRequest(HttpServletRequest request){
        return "LOCAL";
    }
}
