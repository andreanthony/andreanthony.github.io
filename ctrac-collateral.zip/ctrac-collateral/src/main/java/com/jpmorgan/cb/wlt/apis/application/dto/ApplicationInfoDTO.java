package com.jpmorgan.cb.wlt.apis.application.dto;

import java.io.Serializable;

public class ApplicationInfoDTO implements Serializable {
    private static final long serialVersionUID = -1;

    private String refDate;

    public String getRefDate() {
        return refDate;
    }

    public void setRefDate(String refDate) {
        this.refDate = refDate;
    }
}
