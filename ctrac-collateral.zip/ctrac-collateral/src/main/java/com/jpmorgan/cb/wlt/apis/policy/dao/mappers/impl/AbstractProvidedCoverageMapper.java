package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProvidedCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.dao.CoverageDetails;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;

import java.math.BigDecimal;

public abstract class AbstractProvidedCoverageMapper implements DaoMapper<ProvidedCoverage, PolicyInsuranceCoverageDTO> {

    @Override
    public PolicyInsuranceCoverageDTO toDTO(ProvidedCoverage model) {
        PolicyInsuranceCoverageDTO insuranceCoverageDTO = new PolicyInsuranceCoverageDTO();
        insuranceCoverageDTO.setCoverageAmount(model.getCoverageDetails().getCoverageAmount());
        insuranceCoverageDTO.setAggregateAmount(model.getCoverageDetails().getAggregateAmount());
        insuranceCoverageDTO.setDeductibleAmount(
                model.getCoverageDetails().getDeductibleAmount() != null ?
                        String.valueOf(model.getCoverageDetails().getDeductibleAmount()) : null
                );
        return insuranceCoverageDTO;
    }

    @Override
    public boolean map(PolicyInsuranceCoverageDTO dto, ProvidedCoverage model) {
        if (model.getCoverageDetails() != null && model.getGeneralCoverage() != null &&
                new EqualsBuilder()
                .append(model.getCoverageDetails().getCoverageAmount(), dto.getCoverageAmount())
                .append(model.getCoverageDetails().getAggregateAmount(), dto.getAggregateAmount())
                .isEquals()) {
            return false;
        }
        if (model.getCoverageDetails() == null) {
            model.setCoverageDetails(new CoverageDetails());
        }
        model.getCoverageDetails().setCoverageAmount(dto.getCoverageAmount());
        model.getCoverageDetails().setAggregateAmount(dto.getAggregateAmount());
        model.getCoverageDetails().setDeductibleAmount(dto.getDeductibleAmount() != null &&
                StringUtils.isNotBlank(dto.getDeductibleAmount()) ?
                new BigDecimal(dto.getDeductibleAmount()): BigDecimal.ZERO.setScale(2));
        return true;
    }
}
