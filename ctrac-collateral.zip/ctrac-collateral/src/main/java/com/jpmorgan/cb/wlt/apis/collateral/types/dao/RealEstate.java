package com.jpmorgan.cb.wlt.apis.collateral.types.dao;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.types.CollateralType;


@Entity
@Table(name = "TLCP_REAL_ESTATE")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class RealEstate extends Collateral {

    private static final long serialVersionUID = -5986118460892145233L;

    public RealEstate() {
        super();
        this.setCollateralTypeCode(CollateralType.REAL_ESTATE.getCode());
    }

}