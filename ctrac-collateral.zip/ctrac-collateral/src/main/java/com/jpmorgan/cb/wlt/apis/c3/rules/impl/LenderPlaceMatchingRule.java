package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3PolicyCancellationUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class LenderPlaceMatchingRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(LenderPlaceMatchingRule.class);

    public static final RoundingMode ALTHANS_ROUNDING_MODE = RoundingMode.FLOOR;

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        Set<Long> insurableAssets = new HashSet<>();
        for (C3CalculatedCoverageDate date: c3ResponseDTO.getAllCalculatedCoverageDates()) {
            if(date.getInsurableAssetId() == null || !insurableAssets.contains(date.getInsurableAssetId())) {
                processMatchingPolicies(date, c3RequestDTO, c3ResponseDTO);
                insurableAssets.add(date.getInsurableAssetId());
            }
        }
        processRenewalPolicies(c3RequestDTO, c3ResponseDTO);
        logger.debug("LenderPlaceMatchingRule - policies to be canceled for Collateral and Policy ID{} ",c3ResponseDTO.getPoliciesToCancel().stream().map(C3PolicyCancellation::toString).collect(Collectors.joining(",")));
    }

    void processRenewalPolicies(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        c3ResponseDTO.getPoliciesToIssue()
            .stream()
            .forEach(c3PolicyIssuance -> {
                c3RequestDTO.getLpPolicies()
                    .stream()
                    .forEach(policy -> {
                        if (policy.hasMatchingCoverage(c3PolicyIssuance.getCoverageType(), c3PolicyIssuance.getInsurableAssetId())) {
                            if (policy.getExpirationDate_().equals(c3PolicyIssuance.getEffectiveDate_())
                                    && isMatchingAmount(c3PolicyIssuance, policy)){
                                //this is a renewal
                                c3PolicyIssuance.setParentPolicyId(policy.getPolicyId());
                                c3PolicyIssuance.setLpAction(LPAction.RENEW_LP);
                                c3PolicyIssuance.setPolicyStatus(PolicyStatus.PRE_INVOICED);
                            }
                            else if (policy.getExpirationDate_().after(c3PolicyIssuance.getEffectiveDate_())
                                     && !isMatchingAmount(c3PolicyIssuance, policy)) {
                                //this is issue with cancellation
                                c3PolicyIssuance.setParentPolicyId(policy.getPolicyId());
                            }
                        }
                    });
                });
    }

    private void processMatchingPolicies(C3CalculatedCoverageDate date, C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        C3PolicyIssuance policyToIssue = c3ResponseDTO.getPoliciesToProvideCoverage(
                date.getCoverageType(), date.getInsurableAssetId(), date.getCoverageDate())
                .stream()
                .findAny()
                .orElse(null);
        List<C3Policy> policies = c3RequestDTO.getLpPolicies()
                .stream()
                .filter(policy -> policy.isProvidingCoverageOn(
                        date.getCoverageType(), date.getInsurableAssetId(), date.getCoverageDate()))
                .collect(Collectors.toList());
        policies.forEach(policy -> {
            if(policyToIssue != null && isMatchingAmount(policyToIssue, policy)) {
                    c3ResponseDTO.getPoliciesToIssue().remove(policyToIssue);
            }
            else {
                CancellationReason cancellationReason = C3PolicyCancellationUtil.getCancellationReason(
                        policy, date.getCoverageDate(), c3RequestDTO.getMatchingBorrowerPolicies(policy));
                c3ResponseDTO.addPolicyToCancel(
                        C3PolicyCancellationUtil.cancelLpPolicy(policy, date.getCoverageDate(), cancellationReason));
            }
       });
    }

    private boolean isMatchingAmount(C3PolicyIssuance c3PolicyIssuance, C3Policy policy) {
        return isMatchingAmount(c3PolicyIssuance.getCoverageAmount(), policy.getFirstProvidedCoverage().getCoverageAmount());
    }
    private boolean isMatchingAmount(BigDecimal requiredLpAmount, BigDecimal currentLpAmount) {
        return (currentLpAmount.setScale(0, ALTHANS_ROUNDING_MODE).compareTo(
                requiredLpAmount.setScale(0, ALTHANS_ROUNDING_MODE)) == 0);
    }

}
