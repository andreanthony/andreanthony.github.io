package com.jpmorgan.cb.wlt.apis.collateral.sections;

public enum CollateralScreenSection {

    COLLATERAL_DETAILS("Collateral Details Section"),
    BORROWER_LOAN("Borrower/Loan Information Section"),
    COLLATERAL_OWNER("Collateral Owner Section");

    CollateralScreenSection(String screenSectionName){
        this.screenSectionName=screenSectionName;
    }

    private String screenSectionName;

    public String getDisplayName(){
        return this.screenSectionName;
    }

}
