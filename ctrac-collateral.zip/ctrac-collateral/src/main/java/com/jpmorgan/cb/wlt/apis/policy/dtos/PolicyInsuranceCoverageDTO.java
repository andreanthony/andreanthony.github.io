package com.jpmorgan.cb.wlt.apis.policy.dtos;

import com.jpmorgan.cb.wlt.dao.CoverageDetails;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.math.BigDecimal;

public class PolicyInsuranceCoverageDTO {

    @ApiModelProperty(position = 1)
    private String insuranceCoverageType;

    @ApiModelProperty(position = 2)
    private BigDecimal coverageAmount;

    @ApiModelProperty(position = 3)
    private String deductibleAmount;

    @ApiModelProperty(position = 4)
    private BigDecimal aggregateAmount;

    @ApiModelProperty(position = 5)
    private String insurableAssetType;

    @ApiModelProperty(position = 6)
    private Long insurableAssetRid;

    @ApiModelProperty(position = 7)
    private String coverageCategory;

    public String getInsuranceCoverageType() {
        return insuranceCoverageType;
    }

    public void setInsuranceCoverageType(String insuranceCoverageType) { this.insuranceCoverageType = insuranceCoverageType; }

    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(BigDecimal coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public String getDeductibleAmount() {
        return deductibleAmount;
    }

    public void setDeductibleAmount(String deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
    }

    public BigDecimal getAggregateAmount() {
        return aggregateAmount;
    }

    public void setAggregateAmount(BigDecimal aggregateAmount) {
        this.aggregateAmount = aggregateAmount;
    }

    public String getInsurableAssetType() { return insurableAssetType; }

    public void setInsurableAssetType(String insurableAssetType) { this.insurableAssetType = insurableAssetType; }

    public Long getInsurableAssetRid() {
        return insurableAssetRid;
    }

    public void setInsurableAssetRid(Long insurableAssetRid) {
        this.insurableAssetRid = insurableAssetRid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        PolicyInsuranceCoverageDTO that = (PolicyInsuranceCoverageDTO) o;

        return new EqualsBuilder()
                .append(insuranceCoverageType, that.insuranceCoverageType)
                .append(insurableAssetRid, that.insurableAssetRid)
                .append(insurableAssetType, that.insurableAssetType)
                .isEquals() &&
                amountIsEqual(this.coverageAmount, that.coverageAmount) &&
                amountIsEqual(this.aggregateAmount, that.aggregateAmount) &&
                amountIsEqual(this.deductibleAmount, that.deductibleAmount);
    }

    private boolean amountIsEqual(BigDecimal value, BigDecimal value2){
        BigDecimal value1Converted = value == null ? CoverageDetails.DEFAULT_COVERAGE_AMOUNT : value;
        BigDecimal value2Converted = value2 == null ? CoverageDetails.DEFAULT_COVERAGE_AMOUNT : value2;
        return value1Converted.compareTo(value2Converted) == 0;
    }

    private boolean amountIsEqual(String value, String value2){
        BigDecimal value1Converted = StringUtils.isEmpty(value) ? CoverageDetails.DEFAULT_COVERAGE_AMOUNT : new BigDecimal(value);
        BigDecimal value2Converted = StringUtils.isEmpty(value2) ? CoverageDetails.DEFAULT_COVERAGE_AMOUNT : new BigDecimal(value2);
        return value1Converted.compareTo(value2Converted) == 0;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(insuranceCoverageType)
                .append(insurableAssetType)
                .append(insurableAssetRid)
                .append(coverageAmount)
                .append(deductibleAmount)
                .append(aggregateAmount)
                .toHashCode();
    }

    public void setCoverageCategory(String coverageCategory) {
        this.coverageCategory = coverageCategory;
    }

    public String getCoverageCategory() {
        return coverageCategory;
    }
}
