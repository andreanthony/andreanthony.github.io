package com.jpmorgan.cb.wlt.apis.collateral.types;

import com.jpmorgan.cb.wlt.apis.ApiDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateBusinessAssetsDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateRealEstateDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.services.CollateralCreationService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/collaterals/types")
public class CreateCollateralAPI {

    private static final Logger logger = LoggerFactory.getLogger(CreateCollateralAPI.class);

    private CollateralCreationService collateralCreationService;

    @Autowired
    public CreateCollateralAPI(CollateralCreationService collateralCreationService) {
        assert(collateralCreationService != null);
        this.collateralCreationService = collateralCreationService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<ApiDTO>> getCollateralTypes() {
        return ResponseEntity.ok(collateralCreationService.getCollateralTypeAPIs());
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/realestate", method = RequestMethod.POST)
    public ResponseEntity<CollateralDTO> createCollateral(@Valid @RequestBody CreateRealEstateDTO createCollateralDTO, @RequestAttribute UserRequestInfo userRequestInfo) {
        return ResponseEntity.ok(collateralCreationService.createCollateral(createCollateralDTO, CollateralType.REAL_ESTATE, userRequestInfo));
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/businessassets", method = RequestMethod.POST)
    public ResponseEntity<CollateralDTO> createCollateral(@Valid @RequestBody CreateBusinessAssetsDTO createCollateralDTO, @RequestAttribute UserRequestInfo userRequestInfo) {
        return ResponseEntity.ok(collateralCreationService.createCollateral(createCollateralDTO, CollateralType.BUSINESS_ASSETS, userRequestInfo));
    }
}
