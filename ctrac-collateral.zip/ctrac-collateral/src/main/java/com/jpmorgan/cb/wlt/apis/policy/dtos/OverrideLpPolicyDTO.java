package com.jpmorgan.cb.wlt.apis.policy.dtos;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.WorkItemUpdateRequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.workitem.EventInsuranceRenewalItemDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.workitem.EventLenderPlaceItemDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.workitem.EventWorkItemDTO;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.ArrayList;
import java.util.List;


public class OverrideLpPolicyDTO {

    @ApiModelProperty(position = 1)
    private PolicyDTO lpPolicy;

    @ApiModelProperty(position = 2)
    private Boolean overrideRenewalItem;

    @ApiModelProperty(position = 3)
    private String preRenewalLetterDate;

    @ApiModelProperty(position = 4)
    private Boolean overrideLenderPlaceItem;

    @ApiModelProperty(position = 5)
    private String lpSendDate;

    @ApiModelProperty(position = 6)
    private String wireSentDate;

    @ApiModelProperty(position = 7)
    private String cancellationRequestDate;

    @ApiModelProperty(position = 8)
    private String cancellationLetterDate;

    @ApiModelProperty(position = 9)
    private String refundCompletionDate;

    @ApiModelProperty(position = 10)
    private String premiumAmount;

    @ApiModelProperty(position = 11)
    private String bankPremiumAmount;

    @ApiModelProperty(position = 12)
    private String refundAmount;

    @ApiModelProperty(position = 13)
    private String bankRefundAmount;

    @ApiModelProperty(position = 14)
    private Boolean startCancellationWorkflow;

    public PolicyDTO getLpPolicy() {
        return lpPolicy;
    }

    public void setLpPolicy(PolicyDTO lpPolicy) {
        this.lpPolicy = lpPolicy;
    }

    public Boolean isOverrideRenewalItem() {
        return overrideRenewalItem;
    }

    public void setOverrideRenewalItem(Boolean overrideRenewalItem) {
        this.overrideRenewalItem = overrideRenewalItem;
    }

    public Boolean isOverrideLenderPlaceItem() {
        return overrideLenderPlaceItem;
    }

    public void setOverrideLenderPlaceItem(Boolean overrideLenderPlaceItem) {
        this.overrideLenderPlaceItem = overrideLenderPlaceItem;
    }

    public String getPreRenewalLetterDate() {
        return preRenewalLetterDate;
    }

    public void setPreRenewalLetterDate(String preRenewalLetterDate) {
        this.preRenewalLetterDate = preRenewalLetterDate;
    }

    public String getLpSendDate() {
        return lpSendDate;
    }

    public void setLpSendDate(String lpSendDate) {
        this.lpSendDate = lpSendDate;
    }

    public String getWireSentDate() {
        return wireSentDate;
    }

    public void setWireSentDate(String wireSentDate) {
        this.wireSentDate = wireSentDate;
    }

    public String getCancellationRequestDate() {
        return cancellationRequestDate;
    }

    public void setCancellationRequestDate(String cancellationRequestDate) {
        this.cancellationRequestDate = cancellationRequestDate;
    }

    public String getCancellationLetterDate() {
        return cancellationLetterDate;
    }

    public void setCancellationLetterDate(String cancellationLetterDate) {
        this.cancellationLetterDate = cancellationLetterDate;
    }

    public String getRefundCompletionDate() {
        return refundCompletionDate;
    }

    public void setRefundCompletionDate(String refundCompletionDate) {
        this.refundCompletionDate = refundCompletionDate;
    }

    public String getPremiumAmount() {
        return premiumAmount;
    }

    public void setPremiumAmount(String premiumAmount) {
        this.premiumAmount = premiumAmount;
    }

    public String getBankPremiumAmount() {
        return bankPremiumAmount;
    }

    public void setBankPremiumAmount(String bankPremiumAmount) {
        this.bankPremiumAmount = bankPremiumAmount;
    }

    public String getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(String refundAmount) {
        this.refundAmount = refundAmount;
    }

    public String getBankRefundAmount() {
        return bankRefundAmount;
    }

    public void setBankRefundAmount(String bankRefundAmount) {
        this.bankRefundAmount = bankRefundAmount;
    }

    public Boolean getStartCancellationWorkflow() {
        return startCancellationWorkflow;
    }

    public void setStartCancellationWorkflow(Boolean startCancellationWorkflow) {
        this.startCancellationWorkflow = startCancellationWorkflow;
    }

    public WorkItemUpdateRequestEventDTO toWorkItemUpdateRequestDto(UserRequestInfo userRequestInfo){
        WorkItemUpdateRequestEventDTO eventDTO = new WorkItemUpdateRequestEventDTO();
        List<EventWorkItemDTO> list = new ArrayList<>();
        if(BooleanUtils.isTrue(isOverrideLenderPlaceItem())) {
            EventLenderPlaceItemDTO lpiEventDto = new EventLenderPlaceItemDTO();
            lpiEventDto.setPolicyRid(getLpPolicy().getPolicyId());
            lpiEventDto.setRefundCompletionDate(getRefundCompletionDate());
            lpiEventDto.setWireSentDate(getWireSentDate());
            lpiEventDto.setLpSendDate(getLpSendDate());
            lpiEventDto.setCancellationLetterDate(getCancellationLetterDate());
            lpiEventDto.setCancellationRequestDate(getCancellationRequestDate());
            lpiEventDto.setPremiumAmount(getPremiumAmount());
            lpiEventDto.setBankPremiumAmount(getBankPremiumAmount());
            lpiEventDto.setRefundAmount(getRefundAmount());
            lpiEventDto.setBankRefundAmount(getBankRefundAmount());
            list.add(lpiEventDto);
        }

        if(BooleanUtils.isTrue(isOverrideRenewalItem())){
            EventInsuranceRenewalItemDTO renewalItemEventDto = new EventInsuranceRenewalItemDTO();
            renewalItemEventDto.setPolicyRid(getLpPolicy().getPolicyId());
            renewalItemEventDto.setPreRenewalLetterDate(getPreRenewalLetterDate());
            list.add(renewalItemEventDto);
        }

        eventDTO.setWorkItems(list);
        eventDTO.setPerformedBy(userRequestInfo.getUserSid());
        eventDTO.setEventType(CtracEventType.LP_POLICY_OVERRIDE.getDisplayValue());
        return eventDTO;
    }

    public boolean isTriggerCancellationWorkflow(){
        return BooleanUtils.isTrue(getStartCancellationWorkflow()) && getLpPolicy().getCancellationDate() != null &&
                StringUtils.isNotEmpty(getLpPolicy().getCancellationDate());
    }

    public boolean hasPremiumNotReceived(ProofOfCoverage originalPolicyDto){
        return PolicyStatus.valueOf(originalPolicyDto.getPolicyStatus()).isBeforeLpRequestSent() ||
                (getPremiumAmount() == null || StringUtils.isEmpty(getPremiumAmount()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        OverrideLpPolicyDTO that = (OverrideLpPolicyDTO) o;

        return new EqualsBuilder()
                .append(lpPolicy, that.lpPolicy)
                .append(overrideRenewalItem, that.overrideRenewalItem)
                .append(preRenewalLetterDate, that.preRenewalLetterDate)
                .append(lpSendDate, that.lpSendDate)
                .append(wireSentDate, that.wireSentDate)
                .append(cancellationRequestDate, that.cancellationRequestDate)
                .append(cancellationLetterDate, that.cancellationLetterDate)
                .append(refundCompletionDate, that.refundCompletionDate)
                .append(premiumAmount, that.premiumAmount)
                .append(bankPremiumAmount, that.bankPremiumAmount)
                .append(refundAmount, that.refundAmount)
                .append(bankRefundAmount, that.bankRefundAmount)
                .append(startCancellationWorkflow, that.startCancellationWorkflow)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(lpPolicy)
                .append(overrideRenewalItem)
                .append(preRenewalLetterDate)
                .append(lpSendDate)
                .append(wireSentDate)
                .append(cancellationRequestDate)
                .append(cancellationLetterDate)
                .append(refundCompletionDate)
                .append(premiumAmount)
                .append(bankPremiumAmount)
                .append(refundAmount)
                .append(bankRefundAmount)
                .append(startCancellationWorkflow)
                .toHashCode();
    }
}