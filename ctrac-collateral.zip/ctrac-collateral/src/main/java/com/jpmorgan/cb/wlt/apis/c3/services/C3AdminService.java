package com.jpmorgan.cb.wlt.apis.c3.services;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3WorkflowRequestEventDTO;

public interface C3AdminService {
    C3PolicyCancellation cancel(C3WorkflowRequestEventDTO workflowRequestEventDTO);
}
