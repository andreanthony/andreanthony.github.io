package com.jpmorgan.cb.wlt.apis.policy.dtos;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class LetterCycleDTO {
    public static final String FIRST_WORKFLOW_STEP = "Send_1st_LP_Letter";

    private Long proofOfCoverageRid;
    private String workflowStep;
    private String firstLetterDate;
    private String secondLetterDate;
    boolean marketEmailNeeded;
    Long borrowerPolicyRid;

    public LetterCycleDTO() {
    }

    public String getWorkflowStep() {
        return workflowStep;
    }

    public void setWorkflowStep(String workflowStep) {
        this.workflowStep = workflowStep;
    }

    public String getFirstLetterDate() {
        return firstLetterDate;
    }

    public void setFirstLetterDate(String firstLetterDate) {
        this.firstLetterDate = firstLetterDate;
    }

    public String getSecondLetterDate() {
        return secondLetterDate;
    }

    public void setSecondLetterDate(String secondLetterDate) {
        this.secondLetterDate = secondLetterDate;
    }

    public boolean isMarketEmailNeeded() {
        return marketEmailNeeded;
    }

    public void setMarketEmailNeeded(boolean marketEmailNeeded) {
        this.marketEmailNeeded = marketEmailNeeded;
    }

    public Long getBorrowerPolicyRid() {
        return borrowerPolicyRid;
    }

    public void setBorrowerPolicyRid(Long borrowerPolicyRid) {
        this.borrowerPolicyRid = borrowerPolicyRid;
    }

    public Long getProofOfCoverageRid() {
        return proofOfCoverageRid;
    }

    public void setProofOfCoverageRid(Long proofOfCoverageRid) {
        this.proofOfCoverageRid = proofOfCoverageRid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        LetterCycleDTO letterCycleDTO = (LetterCycleDTO) o;

        return new EqualsBuilder()
                .append(proofOfCoverageRid, letterCycleDTO.proofOfCoverageRid)
                .append(borrowerPolicyRid, letterCycleDTO.borrowerPolicyRid)
                .append(marketEmailNeeded, letterCycleDTO.marketEmailNeeded)
                .append(firstLetterDate, letterCycleDTO.firstLetterDate)
                .append(secondLetterDate, letterCycleDTO.secondLetterDate)
                .append(workflowStep, letterCycleDTO.workflowStep)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(proofOfCoverageRid)
                .append(borrowerPolicyRid)
                .append(marketEmailNeeded)
                .append(firstLetterDate)
                .append(secondLetterDate)
                .append(workflowStep)
                .toHashCode();
    }

}
