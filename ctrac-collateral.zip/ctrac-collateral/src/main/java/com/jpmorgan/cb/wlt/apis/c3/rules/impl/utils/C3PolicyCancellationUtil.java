package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class C3PolicyCancellationUtil {

    private C3PolicyCancellationUtil() {}

    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    public static List<C3PolicyCancellation> cancelLpPolicies(List<C3Policy> activeLpPolicies, String cancellationEffectiveDate, CancellationReason cancellationReason) {
        Date cancellationDate = DATE_FORMATTER.parse(cancellationEffectiveDate);
        List<C3PolicyCancellation> policiesToCancel = new ArrayList<>();
        activeLpPolicies.forEach(policy -> {
            C3PolicyCancellation c3PolicyCancellation = cancelLpPolicy(policy, cancellationDate, cancellationReason);
            if (c3PolicyCancellation != null) {
                policiesToCancel.add(c3PolicyCancellation);
            }
        });
        return policiesToCancel;
    }

    public static C3PolicyCancellation cancelLpPolicy(C3Policy policy, Date cancellationEffectiveDate, CancellationReason cancellationReason) {
        boolean isFlatCancelled = !cancellationEffectiveDate.after(policy.getEffectiveDate_());
        boolean isBeforeLpRequestSent = policy.getPolicyStatus_().isBeforeLpRequestSent();
        boolean isPendingLetterCycle = PolicyStatus.PENDING_LETTER_CYCLE.name().equals(policy.getPolicyStatus());
        if(policy.getPolicyStatus_().isInactive()) {
            return null;
        }
        cancellationEffectiveDate = adjustPolicyCancellationDate(policy, cancellationEffectiveDate);
        if (cancellationEffectiveDate == null) {
            return null;
        }
        C3PolicyCancellation policyCancellation = new C3PolicyCancellation();
        policyCancellation.setPolicyId(policy.getPolicyId());
        populatePolicyCancellation(cancellationReason, DATE_FORMATTER.print(cancellationEffectiveDate),
                isFlatCancelled, isBeforeLpRequestSent, isPendingLetterCycle, policyCancellation);
        return policyCancellation;

    }

    private static Date adjustPolicyCancellationDate(C3Policy policy, Date cancellationEffectiveDate) {
        if (policy.getEffectiveDate_().after(cancellationEffectiveDate)) {
            return policy.getEffectiveDate_();
        }

        if (!policy.getExpirationDate_().after(cancellationEffectiveDate)) {
            return null;
        }
        return cancellationEffectiveDate;
    }

    static void populatePolicyCancellation(CancellationReason cancellationReason, String cancellationDate,
                                           boolean isFlatCancelled, boolean isBeforeLpRequestSent, boolean isPendingLetterCycle,
                                           C3PolicyCancellation policyCancellation) {
        if (isFlatCancelled && isPendingLetterCycle) {
            policyCancellation.setDeleted(true);
        }
        else if (!isFlatCancelled && isBeforeLpRequestSent) {
            policyCancellation.setUpdatedExpirationDate(cancellationDate);
        }
        else {
            policyCancellation.setCancellationEffectiveDate(cancellationDate);
            policyCancellation.setCancellationReason(cancellationReason);
        }
    }

    public static List<C3PolicyCancellation> cancelLpPolicies(List<C3Policy> activeLpPolicies, Date cancellationEffectiveDate, CancellationReason cancellationReason) {
        return cancelLpPolicies(activeLpPolicies, DATE_FORMATTER.print(cancellationEffectiveDate), cancellationReason);
    }

    /**
     * Figure out the CancellationReason based on the borrower policies becoming effective.
     * @param lpPolicy
     * @param cancellationEffectiveDate
     * @param matchingBorrowerPolicies
     * @return
     */
    public static CancellationReason getCancellationReason(C3Policy lpPolicy, Date cancellationEffectiveDate, List<C3Policy> matchingBorrowerPolicies) {
        C3Policy borrowerPolicyRecieved = getBorrowerPolicyRecieved(cancellationEffectiveDate, matchingBorrowerPolicies);
        if(borrowerPolicyRecieved != null) {
            return CancellationReason.BORROWER_POLICY_RECEIVED;
        }
        if(lpPolicy.getGapBorrowerPolicyId() != null) {
            return CancellationReason.BORROWER_POLICY_RECEIVED_AMOUNT_GAP;
        }
        return CancellationReason.INSURANCE_NOT_NEEDED;
    }

    private static C3Policy getBorrowerPolicyRecieved(Date effectiveOn, List<C3Policy> borrowerPolicies) {
        return borrowerPolicies
                .stream().filter(activePolicy -> activePolicy.isEffectiveOn(effectiveOn) &&
                        (activePolicy.getLpAction_() == LPAction.NEW_BP || activePolicy.getLpAction_() == LPAction.PENDING_C3))
                .findFirst()
                .orElse(null);
    }

}
