package com.jpmorgan.cb.wlt.apis.policy.services.exceptions;

import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;

public class PolicyNotFoundException extends CtracException {
    public PolicyNotFoundException(String message) {
        super(message);
    }
}
