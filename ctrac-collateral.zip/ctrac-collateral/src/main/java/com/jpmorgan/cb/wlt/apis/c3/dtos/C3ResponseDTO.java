package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3PolicyCancellationDateComparator;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class C3ResponseDTO implements Serializable {
    private static final long serialVersionUID = -1;
    private boolean complete = false;
    private List<C3CalculatedCoverageDate> calculatedFloodCoverageDates = new ArrayList<>();
    private List<C3CalculatedCoverageDate> calculatedGeneralCoverageDates = new ArrayList<>();
    private List<C3PolicyIssuance> policiesToIssue = new ArrayList<>();
    private List<C3PolicyCancellation> policiesToCancel = new ArrayList<>();
    private List<C3AlertEmail> alertEmails = new ArrayList<>();
    private List<Long> processedPolicies = new ArrayList<>();
    private List<Long> newlyVerifiedBorrowerPolicies = new ArrayList<>();
    private List<Long> expiringPoliciesWithNoGap = new ArrayList<>();
    private Long collateralRid;
    private String performedBy;

    @ApiModelProperty(hidden = true)
    public Map<Long, SortedSet<Date>> getFloodCoverageDatesByInsurableAssetId() {
        Map<Long, SortedSet<Date>> coverageDatesByInsurableAssetId = new HashMap<>();
        getValidCalculatedFloodCoverageDates().forEach(coverageDate -> {
            Long insurableAssetId = coverageDate.getInsurableAssetId();
            if (!coverageDatesByInsurableAssetId.containsKey(insurableAssetId)) {
                coverageDatesByInsurableAssetId.put(insurableAssetId, new TreeSet<>());
            }
            SortedSet<Date> coverageDates = coverageDatesByInsurableAssetId.get(insurableAssetId);
            coverageDates.add(coverageDate.getCoverageDate());
        });
        return coverageDatesByInsurableAssetId;
    }

    @ApiModelProperty(hidden = true)
    public Map<String, SortedSet<Date>> getGeneralCoverageDatesByCoverageType() {
        Map<String, SortedSet<Date>> coverageDatesByCoverageType = new HashMap<>();
        calculatedGeneralCoverageDates.forEach(coverageDate -> {
            String coverageType = coverageDate.getCoverageType();
            if (!coverageDatesByCoverageType.containsKey(coverageType)) {
                coverageDatesByCoverageType.put(coverageType, new TreeSet<>());
            }
            SortedSet<Date> coverageDates = coverageDatesByCoverageType.get(coverageType);
            coverageDates.add(coverageDate.getCoverageDate());
        });
        return coverageDatesByCoverageType;
    }

    @ApiModelProperty(hidden = true)
    public List<C3CalculatedCoverageDate> getValidCalculatedFloodCoverageDates() {
        return calculatedFloodCoverageDates.stream().filter(C3CalculatedCoverageDate::isValid).collect(Collectors.toList());
    }

    public List<C3CalculatedCoverageDate> getAllCalculatedCoverageDates() {
        List<C3CalculatedCoverageDate> allCalculatedDates = getValidCalculatedFloodCoverageDates();
        allCalculatedDates.addAll(getCalculatedGeneralCoverageDates());
        return allCalculatedDates;
    }

    public boolean isComplete() {
        return complete;
    }

    public void setComplete(boolean complete) {
        this.complete = complete;
    }

    public List<C3CalculatedCoverageDate> getCalculatedFloodCoverageDates() {
        return calculatedFloodCoverageDates;
    }

    public void setCalculatedFloodCoverageDates(List<C3CalculatedCoverageDate> calculatedFloodCoverageDates) {
        this.calculatedFloodCoverageDates = calculatedFloodCoverageDates;
    }

    public List<C3PolicyIssuance> getPoliciesToIssue() {
        return policiesToIssue;
    }

    public void setPoliciesToIssue(List<C3PolicyIssuance> policiesToIssue) {
        this.policiesToIssue = policiesToIssue;
    }

    public List<C3PolicyCancellation> getPoliciesToCancel() {
        return Collections.unmodifiableList(policiesToCancel);
    }

    public void addPoliciesToCancel(List<C3PolicyCancellation> policiesToCancel) {
        policiesToCancel.forEach(this::addPolicyToCancel);
    }

    public void addPolicyToCancel(C3PolicyCancellation policyToCancel) {
        if (policyToCancel == null) {
            return;
        }

        Optional<C3PolicyCancellation> policyPreviouslyAdded = policiesToCancel
                .stream()
                .filter(policyAlreadyBeingCancelled ->
                        policyToCancel != null && policyAlreadyBeingCancelled.getPolicyId() == policyToCancel.getPolicyId())
                .findFirst();

        if (policyPreviouslyAdded.isPresent()) {
            C3PolicyCancellation previouslyAdded = policyPreviouslyAdded.get();
            if (new C3PolicyCancellationDateComparator().compare(previouslyAdded, policyToCancel) > 0) {
                // replace with the earlier cancellation
                policiesToCancel.remove(previouslyAdded);
                policiesToCancel.add(policyToCancel);
            }
        } else {
            policiesToCancel.add(policyToCancel);
        }
    }

    public List<C3AlertEmail> getAlertEmails() {
        return alertEmails;
    }

    public void setAlertEmails(List<C3AlertEmail> alertEmails) {
        this.alertEmails = alertEmails;
    }

    public List<C3CalculatedCoverageDate> getCalculatedGeneralCoverageDates() {
        return calculatedGeneralCoverageDates;
    }

    public void setCalculatedGeneralCoverageDates(List<C3CalculatedCoverageDate> calculatedGeneralCoverageDates) {
        this.calculatedGeneralCoverageDates = calculatedGeneralCoverageDates;
    }

    public List<C3PolicyIssuance> getPoliciesToProvideCoverage(String coverageType, Long insurableAssetId, Date coverageDate) {
          return policiesToIssue.stream().filter(policyIssuance -> policyIssuance.isProvidingCoverage(
                  coverageType, insurableAssetId, coverageDate))
                  .collect(Collectors.toList());
    }

    public List<Long> getProcessedPolicies() {
        return processedPolicies;
    }

    public void setProcessedPolicies(List<Long> processedPolicies) {
        this.processedPolicies = processedPolicies;
    }

    public void addNewlyVerifiedBorrowerPolicies(Collection<Long> policyRids) {
        this.newlyVerifiedBorrowerPolicies.addAll(policyRids);
    }

    public List<Long> getNewlyVerifiedBorrowerPolicies() {
        return Collections.unmodifiableList(newlyVerifiedBorrowerPolicies);
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }

    public List<Long> getExpiringPoliciesWithNoGap() {
        return expiringPoliciesWithNoGap;
    }

    public void setExpiringPoliciesWithNoGap(List<Long> expiringPoliciesWithNoGap) {
        this.expiringPoliciesWithNoGap = expiringPoliciesWithNoGap;
    }
}
