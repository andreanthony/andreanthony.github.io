package com.jpmorgan.cb.wlt.apis.lookup;

import com.jpmorgan.cb.wlt.apis.lookup.dtos.LookupCodeDTO;
import com.jpmorgan.cb.wlt.apis.lookup.services.LookupCodeService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/lookup")
public class LookupCodeAPI {
    private static final Logger logger = LoggerFactory.getLogger(LookupCodeAPI.class);

    private LookupCodeService lookupCodeService;

    @Autowired
    public LookupCodeAPI(LookupCodeService lookupCodeService) {
        assert(lookupCodeService != null);
        this.lookupCodeService = lookupCodeService;
    }

    @RequestMapping(value = "/{codeset}", method = RequestMethod.GET)
    public ResponseEntity<List<LookupCodeDTO>> getByCodeset(@PathVariable String codeset) {
        List<LookupCodeDTO> lookupCodeDTOS = new ArrayList<>();
        try {
            lookupCodeDTOS = lookupCodeService.getByCodeset(codeset);
        } catch (CtracException e) {
            logger.error(e.getMessage(), e);
        }
        return ResponseEntity.ok(lookupCodeDTOS);
    }

    @RequestMapping(value = "/{codeset}/{code}", method = RequestMethod.GET)
    public ResponseEntity<LookupCodeDTO> getByCode(@PathVariable String codeset, @PathVariable String code) {
        LookupCodeDTO lookupCodeDTO = new LookupCodeDTO();
        try {
            lookupCodeDTO = lookupCodeService.getByCodeSetAndCode(codeset, code);
        } catch (CtracException e) {
            logger.error(e.getMessage(), e);
        }
        return ResponseEntity.ok(lookupCodeDTO);
    }

    @RequestMapping(value = "/{codeSet}/{code}/children", method = RequestMethod.GET)
    public ResponseEntity<List<LookupCodeDTO>> getChildrenLookupCodes(@PathVariable String codeSet, @PathVariable String code) {
        List<LookupCodeDTO> lookupCodeDTOS = new ArrayList<>();
        try {
            lookupCodeDTOS = lookupCodeService.getChildrenLookupCodes(codeSet, code);
        } catch (CtracException e) {
            logger.error(e.getMessage(), e);
        }
        return ResponseEntity.ok(lookupCodeDTOS);
    }
}
