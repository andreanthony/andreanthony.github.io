package com.jpmorgan.cb.wlt.config.environment;

public interface EnvironmentManager {

    EnvironmentType getActiveEnvironment();

}
