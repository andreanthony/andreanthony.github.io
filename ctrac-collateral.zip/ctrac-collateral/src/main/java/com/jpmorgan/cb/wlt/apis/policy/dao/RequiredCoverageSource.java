package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "TLCP_REQUIRED_COVERAGE_SOURCE")
public class RequiredCoverageSource extends AuditableEntity {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "requiredCoverageSourceSeqGenerator")
    @TableGenerator(name = "requiredCoverageSourceSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_REQUIRED_COVERAGE_SOURCE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "SOURCE")
    private String source;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "INSURANCE_TYPE")
    private String insuranceType;

    @Column(name = "PROPERTY_TYPE")
    private String propertyType;

    @Column(name = "DOCUMENT_DATE")
    private Date documentDate;

    @Column(name = "CANCELLATION_EFFECTIVE_DATE")
    private Date cancellationEffectiveDate;

    @Column(name = "REQD_COV_SAME_AS_OPB")
    private String reqdCovSameAsOPB;

    @Column(name = "EXCESS_REQUIRED")
    private String excessRequired;

    @Column(name = "OPB")
    private BigDecimal outstandingPrincipleBalance;

    @OneToMany(mappedBy = "requiredCoverageSource", orphanRemoval = true)
    private List<RequiredCoverage> requiredCoverages;


    public RequiredCoverageSource() {
    }


    /**
     * @return the rid
     */
    public Long getRid() {
        return rid;
    }


    /**
     * @return the source
     */
    public String getSource() {
        return source;
    }


    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }


    /**
     * @return the insuranceType
     */
    public String getInsuranceType() {
        return insuranceType;
    }


    /**
     * @return the propertyType
     */
    public String getPropertyType() {
        return propertyType;
    }


    /**
     * @param rid the rid to set
     */
    public void setRid(Long rid) {
        this.rid = rid;
    }

    /**
     * @param source the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }


    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }


    /**
     * @param insuranceType the insuranceType to set
     */
    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }


    /**
     * @param propertyType the propertyType to set
     */
    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }


    /**
     * @return the documentDate
     */
    public Date getDocumentDate() {
        return documentDate;
    }


    /**
     * @return the requiredCoverages
     */
    public List<RequiredCoverage> getRequiredCoverages() {
        return requiredCoverages;
    }


    /**
     * @param documentDate the documentDate to set
     */
    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }


    /**
     * @param requiredCoverages the requiredCoverages to set
     */
    public void setRequiredCoverages(List<RequiredCoverage> requiredCoverages) {
        this.requiredCoverages = requiredCoverages;
    }

    public boolean isVeried() {
        return VerificationStatus.VERIFIED.name().equalsIgnoreCase(status);
    }

    public Date getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
        this.cancellationEffectiveDate = cancellationEffectiveDate;
    }


    public String getReqdCovSameAsOPB() {
        return reqdCovSameAsOPB;
    }


    public void setReqdCovSameAsOPB(String reqdCovSameAsOPB) {
        this.reqdCovSameAsOPB = reqdCovSameAsOPB;
    }


    public String getExcessRequired() {
        return excessRequired;
    }


    public void setExcessRequired(String excessRequired) {
        this.excessRequired = excessRequired;
    }


    public BigDecimal getOutstandingPrincipleBalance() {
        return outstandingPrincipleBalance;
    }


    public void setOutstandingPrincipleBalance(BigDecimal outstandingPrincipleBalance) {
        this.outstandingPrincipleBalance = outstandingPrincipleBalance;
    }
}
