package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.BirCollateralDetails;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyCollateralDetailsDTO;
import com.jpmorgan.cb.wlt.dao.Address;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

public abstract class AbstractBirCollateralDetailsMapper implements DaoMapper<BirCollateralDetails, PolicyCollateralDetailsDTO> {


    @Override
    public PolicyCollateralDetailsDTO toDTO(BirCollateralDetails model) {
        PolicyCollateralDetailsDTO dto = new PolicyCollateralDetailsDTO();
        return mapOnToDTO(dto, model);
    }

    public PolicyCollateralDetailsDTO mapOnToDTO(PolicyCollateralDetailsDTO dto, BirCollateralDetails model) {
        dto.setCollateralId(model.getCollateralRid());
        if(model.getPolicyAddress() != null) {
            dto.setPolicyAddress(model.getPolicyAddress().getStreetAddress());
            dto.setUnitOrBuilding(model.getPolicyAddress().getUnitOrBuilding());
            dto.setCity(model.getPolicyAddress().getCity());
            dto.setState(model.getPolicyAddress().getState());
            dto.setZipCode(model.getPolicyAddress().getZipCode());
        }
        return dto;
    }

    public boolean map(PolicyCollateralDetailsDTO dto, BirCollateralDetails model) {
        model.setCollateralRid(dto.getCollateralId());
        if (model.getPolicyAddress() == null) {
            model.setPolicyAddress(new Address());
        }
        model.getPolicyAddress().setStreetAddress(dto.getPolicyAddress());
        model.getPolicyAddress().setUnitOrBuilding(dto.getUnitOrBuilding());
        model.getPolicyAddress().setCity(dto.getCity());
        model.getPolicyAddress().setState(dto.getState());
        model.getPolicyAddress().setZipCode(dto.getZipCode());
        return true;
    }
}
