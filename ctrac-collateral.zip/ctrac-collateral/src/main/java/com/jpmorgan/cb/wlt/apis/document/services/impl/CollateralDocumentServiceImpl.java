package com.jpmorgan.cb.wlt.apis.document.services.impl;

import com.itextpdf.text.pdf.PdfReader;
import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.repository.CollateralDocumentRepository;
import com.jpmorgan.cb.wlt.apis.document.dao.repository.EntityCollateralDocumentRepository;
import com.jpmorgan.cb.wlt.apis.document.dao.types.EntityCollateralDocumentRelation;
import com.jpmorgan.cb.wlt.apis.document.dao.types.EntityDocumentHolder;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentDTO;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentSummaryDTO;
import com.jpmorgan.cb.wlt.apis.document.dtos.DocumentMetaDataDTO;
import com.jpmorgan.cb.wlt.apis.document.services.CollateralDocumentService;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class CollateralDocumentServiceImpl implements CollateralDocumentService{

    private static final Logger logger = LoggerFactory.getLogger(CollateralDocumentServiceImpl.class);
    private EntityCollateralDocumentRepository entityCollateralDocumentRepository;
    private CollateralDocumentRepository collateralDocumentRepository;

    @Autowired
    public CollateralDocumentServiceImpl(EntityCollateralDocumentRepository entityCollateralDocumentRepository,
                                         CollateralDocumentRepository collateralDocumentRepository)
    {
        assert(entityCollateralDocumentRepository != null);
        this.entityCollateralDocumentRepository = entityCollateralDocumentRepository;
        assert(collateralDocumentRepository != null);
        this.collateralDocumentRepository = collateralDocumentRepository;
    }


    @Override
    public List<CollateralDocumentSummaryDTO> saveDocuments(List<FileUploadAttachmentDTO> fileUploadAttachmentDTOList,
                                                            EntityDocumentHolder entityDocumentHolder,
                                                            DocumentMetaDataDTO documentMetaDataDTO) {
        List<CollateralDocumentSummaryDTO> documentSummaryDTOList = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(fileUploadAttachmentDTOList)){
            for(FileUploadAttachmentDTO fileUploadAttachmentDTO:fileUploadAttachmentDTOList){
                //Create document
                CollateralDocument collateralDocument = new CollateralDocument();
                CollateralDocumentDTO collateralDocumentDTO = CollateralDocumentDTO.parseFromFileUpload(fileUploadAttachmentDTO, documentMetaDataDTO);
                collateralDocument.map(collateralDocumentDTO);
                collateralDocument.setInitialAuditInfo(documentMetaDataDTO.getUserSid());

                //Create entity to document relation
                EntityCollateralDocumentRelation entityCollateralDocumentRelation = new EntityCollateralDocumentRelation();
                entityCollateralDocumentRelation.setDocument(collateralDocument);
                entityCollateralDocumentRelation.setEntity(entityDocumentHolder);
                entityCollateralDocumentRelation = entityCollateralDocumentRepository.save(entityCollateralDocumentRelation);
                logger.debug("transferred uploaded document for entity in document table");
                collateralDocumentDTO.setRid(entityCollateralDocumentRelation.getDocument().getRid());
                documentSummaryDTOList.add(collateralDocumentDTO.getCollateralDocumentSummary());
            }
        }
        return documentSummaryDTOList;
    }

    @Override
    public void deleteAllDocuments(Collection<CollateralDocument> documentList) {
        try {
            if(CollectionUtils.isNotEmpty(documentList)) {
                for (CollateralDocument document : documentList) {
                    entityCollateralDocumentRepository.deleteByDocument(document);
                }
            }
        }catch(Exception ex){
            logger.error("Failure deleting all documents from Entity", ex);
            throw new CtracException("Failure deleting all documents from Entity");
        }
    }

    @Override
    public CollateralDocument lookupAndValidateDocument(Long docRid){
        CollateralDocument document = collateralDocumentRepository.getOne(docRid);
        if(document == null || document.getFileContent() == null){
            throw new CtracException("Failure - Document " + docRid + " does not exist");
        }
        try {
            PdfReader reader = getPdfReaderFromBytes(document.getFileContent().getFileContent());
            if (Character.isWhitespace(reader.getPdfVersion())) {
                throw new CtracException("Failure - Document " + docRid + " is not a valid PDF");
            }
            return document;
        } catch (IOException e) {
            throw new CtracException("Failure - Document " + docRid + " is not a valid PDF");
        }
    }

    protected PdfReader getPdfReaderFromBytes(byte[] content) throws IOException {
        return new PdfReader(content);
    }

}
