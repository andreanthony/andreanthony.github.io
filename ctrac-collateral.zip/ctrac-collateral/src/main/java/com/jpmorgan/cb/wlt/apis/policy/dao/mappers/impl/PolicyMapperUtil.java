package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.PaymentMethod;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PaymentMethodDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ExceptionLevel;

public class PolicyMapperUtil {

    public static void populateLPPolicyDTOPaymentMethodDetails(ProofOfCoverage model, PolicyDTO dto) {
        if (model.getInvoicePaymentMethod() != null) {
            dto.setInvoicePaymentMethod(model.getInvoicePaymentMethod().toDTO());
        }
        if (model.getRefundPaymentMethod() != null) {
            dto.setRefundPaymentMethod(model.getRefundPaymentMethod().toDTO());
        }
        if (model.getRenewalPaymentMethod() != null) {
            dto.setRenewalPaymentMethod(model.getRenewalPaymentMethod().toDTO());
        }
    }

    public static void mapLPPolicyDTOPaymentMethodDetailsToModel(PolicyDTO dto, ProofOfCoverage model) {
        model.setInvoicePaymentMethod(mapPaymentMethod(dto.getInvoicePaymentMethod(), model.getInvoicePaymentMethod()));
        model.setRefundPaymentMethod(mapPaymentMethod(dto.getRefundPaymentMethod(), model.getRefundPaymentMethod()));
        model.setRenewalPaymentMethod(mapPaymentMethod(dto.getRenewalPaymentMethod(), model.getRenewalPaymentMethod()));
    }

    private static PaymentMethod mapPaymentMethod(PaymentMethodDTO dto, PaymentMethod model) {
        if (dto != null) {
            PaymentMethod modelToSave = model;
            if (modelToSave == null) {
                modelToSave = new PaymentMethod();
            }
            modelToSave.map(dto);
            return modelToSave;
        }
        return null;
    }

    public static Boolean validLPPolicyDTOProvidedCoverages(PolicyDTO dto) {
        if (dto.getCollateralCoverages().size() == 1 &&
                dto.getCollateralCoverages().get(0).getInsuranceCoverages().size() == 1) {
           return true;
        } else {
            throw new CtracException("Incorrect number of coverages provided", ExceptionLevel.GENEOS);
        }
    }
}
