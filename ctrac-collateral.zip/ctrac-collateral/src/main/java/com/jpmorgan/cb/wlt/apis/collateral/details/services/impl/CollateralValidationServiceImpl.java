package com.jpmorgan.cb.wlt.apis.collateral.details.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralValidationService;
import com.jpmorgan.cb.wlt.apis.collateral.owner.services.CollateralOwnerService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralScreenSection;
import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanService;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ValidationException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CollateralValidationServiceImpl implements CollateralValidationService {

    @Autowired
    private CollateralOwnerService collateralOwnerService;
    @Autowired
    private LoanService loanService;
    @Override
    public void validateSubmitForVerification(CollateralDTO collateralDTO) {
        List<String> validationErrors = new ArrayList<>();
        List<EntityDTO> customerData=collateralOwnerService.getCollateralOwners(collateralDTO.getRid());
        List<LoanDTO> loans = loanService.getLoans(collateralDTO.getRid());
        validateCollateralDetailsSection(collateralDTO,customerData,validationErrors);
        validateLoanBorrowerInformationSection(loans,validationErrors);
        if(CollectionUtils.isNotEmpty(validationErrors)){
            throw new ValidationException().with(validationErrors);
        }
    }
    private void validateCollateralDetailsSection(CollateralDTO collateralDto, List<EntityDTO> ownerDataList, List<String> validationErrors) {
       validateCollateralDetails(collateralDto,ownerDataList,validationErrors);
       ownerDataList.forEach(ownerData-> validateCustomerData(ownerData, CollateralScreenSection.COLLATERAL_OWNER.getDisplayName(),validationErrors));
    }

    private void validateCollateralDetails(CollateralDTO collateralDto, List<EntityDTO> ownerDataList, List<String> validationErrors) {
        if (StringUtils.isBlank(collateralDto.getCollateralSubTypeCode())) {
            validationErrors.add(CollateralScreenSection.COLLATERAL_DETAILS.getDisplayName()+" CollateralSubtype Required");
        }
        if(StringUtils.isBlank(collateralDto.getStreetAddress())){
            validationErrors.add(CollateralScreenSection.COLLATERAL_DETAILS.getDisplayName()+ " StreetAddress Required");
        }
        if(StringUtils.isBlank(collateralDto.getCity())){
            validationErrors.add(CollateralScreenSection.COLLATERAL_DETAILS.getDisplayName()+" City Required");
        }
        if(StringUtils.isBlank(collateralDto.getZipCode())){
            validationErrors.add(CollateralScreenSection.COLLATERAL_DETAILS.getDisplayName()+" ZipCode Required");
        }
        if(StringUtils.isBlank(collateralDto.getMarketEmailAddress())){
            validationErrors.add(CollateralScreenSection.COLLATERAL_DETAILS.getDisplayName()+" Market Email Required");
        }

        if (CollectionUtils.isEmpty(ownerDataList)) {
            validationErrors.add("Please add collateral Owner Section");
        }
    }

    private void validateCustomerData(EntityDTO customerData, String sectionName, List<String> validationErrors) {
        if(StringUtils.isBlank(customerData.getName())){
            validationErrors.add(sectionName+" Customer Name Required");
        }
        if(StringUtils.isBlank(customerData.getStreetAddress())){
            validationErrors.add(sectionName+" StreetAddress Required");
        }
        if(StringUtils.isBlank(customerData.getCity())){
            validationErrors.add(sectionName+" City Required");
        }
        if(StringUtils.isBlank(customerData.getState())){
            validationErrors.add(sectionName+" State Required");
        }
        if(StringUtils.isBlank(customerData.getZipCode())){
            validationErrors.add(sectionName+" ZipCode Required");
        }
    }

    private void validateLoanBorrowerInformationSection(List<LoanDTO> activeLoansData, List<String> validationErrors) {
        if (CollectionUtils.isNotEmpty(activeLoansData) ) {
            activeLoansData.forEach(loanData -> validateLoanBorrower(loanData,validationErrors));
        }else{
            validationErrors.add("Please add Borrower/Loan Information sections");
        }
    }

    private void validateLoanBorrower(LoanDTO loanData, List<String> validationErrors) {
        if(StringUtils.isBlank(loanData.getLoanAccountingSystem())){
            validationErrors.add(CollateralScreenSection.BORROWER_LOAN.getDisplayName()+" LoanAccountingSystem required");
        }
        if(StringUtils.isBlank(loanData.getLineOfBusiness())){
            validationErrors.add(CollateralScreenSection.BORROWER_LOAN.getDisplayName()+" Line Of Business required");
        }
        if(StringUtils.isBlank(loanData.getLoanType())){
            validationErrors.add(CollateralScreenSection.BORROWER_LOAN.getDisplayName()+" Loan Type required");
        }
        if(StringUtils.isBlank(loanData.getLoanNumber())){
            validationErrors.add(CollateralScreenSection.BORROWER_LOAN.getDisplayName()+" Loan Number required");
        }
        if(loanData.getLoadedDate()==null){
            validationErrors.add(CollateralScreenSection.BORROWER_LOAN.getDisplayName()+" Load Date required");
        }
        if(CollectionUtils.isNotEmpty(loanData.getBorrowers())) {
             loanData.getBorrowers().forEach(entityDTO -> validateCustomerData(entityDTO,CollateralScreenSection.BORROWER_LOAN.getDisplayName(),validationErrors));
        }else{
            validationErrors.add("Please add Borrower in the Borrower/Loan Information sections");
        }
    }
}
