package com.jpmorgan.cb.wlt.apis.collateral.types.dao;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.types.CollateralType;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_BUSINESS_ASSETS")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class BusinessAssets extends Collateral {

    private static final long serialVersionUID = 7083491804083198901L;


    public BusinessAssets() {
        super();
        this.setCollateralTypeCode(CollateralType.BUSINESS_ASSETS.getCode());
    }

}