package com.jpmorgan.cb.wlt.apis.floodDetermination.services;

import com.jpmorgan.cb.wlt.apis.floodDetermination.dao.FloodDetermination;

public interface FloodDeterminationService {
    FloodDetermination findByCollateralRidAndStatus(Long collateral, String status);
}
