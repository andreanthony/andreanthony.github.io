package com.jpmorgan.cb.wlt.apis.document.builder;

import com.jpmorgan.cb.wlt.apis.document.dtos.DocumentMetaDataDTO;

import java.util.Date;

public class DocumentMetaDataBuilder {

    private String docIdentifier;
    private Long collateralRid;
    private Date documentDate;

    private String userSid;

    public static DocumentMetaDataBuilder aDocumentMetaData() {
        return new DocumentMetaDataBuilder();
    }

    public DocumentMetaDataBuilder withCollateralRid(Long collateralRid){
        this.collateralRid = collateralRid;
        return this;
    }

    public DocumentMetaDataBuilder withDocumentDate(Date documentDate){
        this.documentDate = documentDate;
        return this;
    }

    public DocumentMetaDataBuilder withDocIdentifier(String docIdentifier){
        this.docIdentifier = docIdentifier;
        return this;
    }

    public DocumentMetaDataBuilder withUserSid(String userSid){
        this.userSid = userSid;
        return this;
    }

    public DocumentMetaDataDTO buildDto(){
        DocumentMetaDataDTO documentMetaDataDTO = new DocumentMetaDataDTO();
        documentMetaDataDTO.setCollateralRid(this.collateralRid);
        documentMetaDataDTO.setDocIdentifier(this.docIdentifier);
        documentMetaDataDTO.setDocumentDate(this.documentDate);
        documentMetaDataDTO.setUserSid(this.userSid);
        return documentMetaDataDTO;
    }


}
