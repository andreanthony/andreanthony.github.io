package com.jpmorgan.cb.wlt.apis.entity;

public class EntityDTO {
    private Long rid;
    private String name;
    private String uniqueCustomerNumber;
    private String streetAddress;
    private String unitOrBuilding;
    private String city;
    private String county;
    private String state;
    private String zipCode;
    private String phoneNumber;
    private String emailAddress;
    private String faxNumber;
    private Boolean specialHandling;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUniqueCustomerNumber() {
        return uniqueCustomerNumber;
    }

    public void setUniqueCustomerNumber(String uniqueCustomerNumber) {
        this.uniqueCustomerNumber = uniqueCustomerNumber;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getUnitOrBuilding() {
        return unitOrBuilding;
    }

    public void setUnitOrBuilding(String unitOrBuilding) {
        this.unitOrBuilding = unitOrBuilding;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public Boolean getSpecialHandling() {
        return specialHandling;
    }

    public void setSpecialHandling(Boolean specialHandling) {
        this.specialHandling = specialHandling;
    }
}
