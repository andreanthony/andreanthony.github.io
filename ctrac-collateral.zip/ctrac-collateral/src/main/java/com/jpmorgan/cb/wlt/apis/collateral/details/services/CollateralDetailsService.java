package com.jpmorgan.cb.wlt.apis.collateral.details.services;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

public interface CollateralDetailsService {
    CollateralDTO getCollateralDetails(Long collateralId);
    CollateralDTO pledgeCollateral(Long collateralRid, UserRequestInfo userRequestInfo);

    void submitForVerification(Long collateralId, UserRequestInfo userRequestInfo);
}
