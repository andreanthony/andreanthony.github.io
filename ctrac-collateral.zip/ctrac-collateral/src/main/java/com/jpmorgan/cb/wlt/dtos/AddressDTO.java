package com.jpmorgan.cb.wlt.dtos;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class AddressDTO {
    private String streetAddress;
    private String unitOrBuilding;
    private String city;
    private String county;
    private String state;
    private String zipCode;

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        AddressDTO that = (AddressDTO) o;

        return new EqualsBuilder()
                .append(streetAddress, that.streetAddress)
                .append(unitOrBuilding, that.unitOrBuilding)
                .append(city, that.city)
                .append(county, that.county)
                .append(state, that.state)
                .append(zipCode, that.zipCode)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(streetAddress)
                .append(unitOrBuilding)
                .append(city)
                .append(county)
                .append(state)
                .append(zipCode)
                .toHashCode();
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getUnitOrBuilding() {
        return unitOrBuilding;
    }

    public void setUnitOrBuilding(String unitOrBuilding) {
        this.unitOrBuilding = unitOrBuilding;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}
