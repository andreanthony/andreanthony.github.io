package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.types.EntityDocumentHolder;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.PolicyMapperFactory;
import com.jpmorgan.cb.wlt.apis.policy.dao.populators.PolicyAuditPopulator;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.WhereJoinTable;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "TLCP_PROOF_OF_COVERAGE")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class ProofOfCoverage extends AuditableEntity implements EntityDocumentHolder {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "proofOfCoverageSeqGenerator")
    @TableGenerator(name = "proofOfCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_PROOF_OF_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    private Long rid;

    @Column(name = "POLICY_TYPE")
    private String policyType;

    @Column(name = "POLICY_NUMBER")
    private String policyNumber;

    @Column(name = "POLICY_STATUS")
    private String policyStatus;

    @Type(type = "org.hibernate.type.NumericBooleanType")
    private Boolean migrated;

    @Column(name = "INSURED_NAME")
    private String insuredName;

    @Column(name = "INSURANCE_AGENCY")
    private String insuranceAgency;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "AGENT_ID")
    private Agent insuranceAgent;

    @Column(name = "ISSUANCE_DATE")
    private Date issuanceDate;

    @Column(name = "EFFECTIVE_DATE")
    private Date effectiveDate;

    @Column(name = "EXPIRATION_DATE")
    private Date expirationDate;

    @Column(name = "CANCELLATION_EFFECTIVE_DATE")
    private Date cancellationEffectiveDate;

    @Column(name = "IND_RENEWAL")
    private String indRenewal = "N";

    @Column(name = "PARENT_POLICY_RID")
    private Long parentPolicyRid;

    @Column(name = "LP_ACTION")
    private String lpAction;

    @Column(name = "LP_TARGET_DATE")
    private Date lpTargetDate;

    @Column(name = "CANCELLATION_TARGET_DATE")
    private Date cancellationTargetDate;

    @Column(name = "CANCELLATION_REASON")
    private String cancellationReason;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "INVOICE_PAYMENT_METHOD_RID")
    private PaymentMethod invoicePaymentMethod;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "REFUND_PAYMENT_METHOD_RID")
    private PaymentMethod refundPaymentMethod;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "RENEWAL_PAY_METHOD_RID")
    private PaymentMethod renewalPaymentMethod;

    @Column(name = "FLOOD_ZONE")
    private String floodZone;

    @Column(name = "LP_LETTER_CYCLE_RESTARTED_DATE")
    private Date lpLetterCycleRestartedDate;

    @Column(name = "THIRTY_DAY_REG_PERIOD")
    private Date thirtyDayRegPeriod;

    @Column(name = "COVERAGE_TYPE")
    private String coverageType;

    @Column(name = "BUILDING_DEDUCTIBLE")
    private BigDecimal buildingDeductible;

    @Column(name = "CONTENTS_DEDUCTIBLE")
    private BigDecimal contentsDeductible;

    @Column(name = "REASON_FOR_VERIFICATION")
    private String reasonForVerification;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "BLANKET_COVERAGE_RID")
    private BlanketCoverage blanketCoverage;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "proofOfCoverage")
    private BirProofOfCovDetails birProofOfCovDetails;

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "proofOfCoverage")
    private List<BIRRuleConclusion> birRuleConclusions = new ArrayList<>();

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "proofOfCoverage", orphanRemoval = true)
    private List<ProvidedCoverage> providedCoverages = new ArrayList<>();

    @OneToMany(orphanRemoval = true)
    @JoinTable(name = "TLCP_ENTITY_DOCUMENTS_REL",
            joinColumns = { @JoinColumn(name = "ENTITY_RID") },
            inverseJoinColumns = { @JoinColumn(name = "DOCUMENT_RID") })
    @WhereJoinTable(clause = "ENTITY_TYPE = 'GeneralInsurance' ")
    private Collection<CollateralDocument> policyDocuments = new ArrayList<>();

    @Column(name = "LENDER_PLACE_REASON")
    private String lenderPlaceReason;

    @Column(name="GAP_BORROWER_PROOF_OF_COVG_RID")
    private Long gapBorrowerPolicyRid;

    public void addProvidedCoverage(ProvidedCoverage providedCoverage) {
        if (providedCoverage.getRid() != null && providedCoverages.contains(providedCoverage)) {
            providedCoverages.remove(providedCoverage);
        }
        providedCoverages.add(providedCoverage);
        providedCoverage.setProofOfCoverage(this);
    }

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getPolicyType() {
        return policyType;
    }

    public PolicyType getPolicyType_() {
        return EnumUtils.getEnum(PolicyType.class, policyType);
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public PolicyStatus getPolicyStatus_() {
        return EnumUtils.getEnum(PolicyStatus.class, policyStatus);
    }

    public String getPolicyStatus() {
        return policyStatus;
    }

    public void setPolicyStatus(String policyStatus) {
        this.policyStatus = policyStatus;
    }

    public Boolean getMigrated() {
        return migrated;
    }

    public void setMigrated(Boolean migrated) {
        this.migrated = migrated;
    }

    public String getInsuredName() {
        return insuredName;
    }

    public void setInsuredName(String insuredName) {
        this.insuredName = insuredName;
    }

    public String getInsuranceAgency() {
        return insuranceAgency;
    }

    public void setInsuranceAgency(String insuranceAgency) {
        this.insuranceAgency = insuranceAgency;
    }

    public Agent getInsuranceAgent() {
        return insuranceAgent;
    }

    public void setInsuranceAgent(Agent insuranceAgent) {
        this.insuranceAgent = insuranceAgent;
    }

    public Date getIssuanceDate() {
        return issuanceDate;
    }

    public void setIssuanceDate(Date issuanceDate) {
        this.issuanceDate = issuanceDate;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Date getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
        this.cancellationEffectiveDate = cancellationEffectiveDate;
    }

    public String getIndRenewal() {
        return indRenewal;
    }

    public void setIndRenewal(String indRenewal) {
        this.indRenewal = indRenewal;
    }

    public Long getParentPolicyRid() {
        return parentPolicyRid;
    }

    public void setParentPolicyRid(Long parentPolicyRid) {
        this.parentPolicyRid = parentPolicyRid;
    }

    public String getLpAction() {
        return lpAction;
    }

    public LPAction getLpAction_() {
        return EnumUtils.getEnum(LPAction.class, lpAction);
    }

    public void setLpAction(String lpAction) {
        this.lpAction = lpAction;
    }

    public Date getLpTargetDate() {
        return lpTargetDate;
    }

    public void setLpTargetDate(Date lpTargetDate) {
        this.lpTargetDate = lpTargetDate;
    }

    public Date getCancellationTargetDate() {
        return cancellationTargetDate;
    }

    public void setCancellationTargetDate(Date cancellationTargetDate) {
        this.cancellationTargetDate = cancellationTargetDate;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public PaymentMethod getInvoicePaymentMethod() {
        return invoicePaymentMethod;
    }

    public void setInvoicePaymentMethod(PaymentMethod invoicePaymentMethod) {
        this.invoicePaymentMethod = invoicePaymentMethod;
    }

    public PaymentMethod getRefundPaymentMethod() {
        return refundPaymentMethod;
    }

    public void setRefundPaymentMethod(PaymentMethod refundPaymentMethod) {
        this.refundPaymentMethod = refundPaymentMethod;
    }

    public PaymentMethod getRenewalPaymentMethod() {
        return renewalPaymentMethod;
    }

    public void setRenewalPaymentMethod(PaymentMethod renewalPaymentMethod) {
        this.renewalPaymentMethod = renewalPaymentMethod;
    }

    public String getFloodZone() {
        return floodZone;
    }

    public void setFloodZone(String floodZone) {
        this.floodZone = floodZone;
    }

    public Date getLpLetterCycleRestartedDate() {
        return lpLetterCycleRestartedDate;
    }

    public void setLpLetterCycleRestartedDate(Date lpLetterCycleRestartedDate) {
        this.lpLetterCycleRestartedDate = lpLetterCycleRestartedDate;
    }

    public Date getThirtyDayRegPeriod() {
        return thirtyDayRegPeriod;
    }

    public void setThirtyDayRegPeriod(Date thirtyDayRegPeriod) {
        this.thirtyDayRegPeriod = thirtyDayRegPeriod;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public BigDecimal getBuildingDeductible() {
        return buildingDeductible;
    }

    public void setBuildingDeductible(BigDecimal buildingDeductible) {
        this.buildingDeductible = buildingDeductible;
    }

    public BigDecimal getContentsDeductible() {
        return contentsDeductible;
    }

    public void setContentsDeductible(BigDecimal contentsDeductible) {
        this.contentsDeductible = contentsDeductible;
    }

    public BlanketCoverage getBlanketCoverage() {
        return blanketCoverage;
    }

    public void setBlanketCoverage(BlanketCoverage blanketCoverage) {
        this.blanketCoverage = blanketCoverage;
    }

    public BirProofOfCovDetails getBirProofOfCovDetails() {
        return birProofOfCovDetails;
    }

    public void setBirProofOfCovDetails(BirProofOfCovDetails birProofOfCovDetails) {
        this.birProofOfCovDetails = birProofOfCovDetails;
    }

    public List<BIRRuleConclusion> getBirRuleConclusions() {
        return birRuleConclusions;
    }

    public void setBirRuleConclusions(List<BIRRuleConclusion> birRuleConclusions) {
        this.birRuleConclusions = birRuleConclusions;
    }

    public List<ProvidedCoverage> getProvidedCoverages() {
        return providedCoverages;
    }

    public void setProvidedCoverages(List<ProvidedCoverage> providedCoverages) {
        this.providedCoverages = providedCoverages;
    }

    public Collection<CollateralDocument> getPolicyDocuments() {
        return policyDocuments;
    }

    public void setPolicyDocuments(Collection<CollateralDocument> policyDocuments) {
        this.policyDocuments = policyDocuments;
    }

    public void addPolicyDocuments(Collection<CollateralDocument> policyDocuments) {
        this.policyDocuments.addAll(policyDocuments);
    }

    public String getReasonForVerification() {
        return reasonForVerification;
    }

    public void setReasonForVerification(String reasonForVerification) {
        this.reasonForVerification = reasonForVerification;
    }

    public List<Long> getLinkedCollateralIds() {
        List<Long> linkedCollateralIds = new ArrayList<>();
        if (getPolicyType_().isLenderPlaced()) {
            linkedCollateralIds.add(getProvidedCoverages().get(0).getCollateralId());
        } else {
            getBirProofOfCovDetails().getBirCollateralDetails().forEach(birCollateralDetails ->
                    linkedCollateralIds.add(birCollateralDetails.getCollateralRid())
            );
        }
        return linkedCollateralIds;
    }

    public void applyDeepLevelAuditInfo(UserRequestInfo userRequestInfo) {
        new PolicyAuditPopulator().populateAuditInfo(this, userRequestInfo);
    }

    public boolean map(PolicyDTO policyDTO) {
        String mapperPolicyType = policyType != null ? policyType : policyDTO.getPolicyType();
        return PolicyMapperFactory.getPolicyMapper(getInsuranceType(), PolicyType.valueOf(mapperPolicyType)).map(policyDTO, this);
    }

    public void map(C3PolicyIssuance policyIssuance) {
        this.policyType = policyIssuance.getPolicyType().name();
        this.policyStatus = policyIssuance.getPolicyStatus().name();
        this.floodZone = policyIssuance.getFloodZone();
        this.coverageType = policyIssuance.getCoverageType();
        this.effectiveDate = policyIssuance.getEffectiveDate_();
        this.expirationDate = policyIssuance.getExpirationDate_();
        this.insuredName = policyIssuance.getInsuredName();
        this.parentPolicyRid = policyIssuance.getParentPolicyId();
        this.lpAction = policyIssuance.getLpAction() == null? null : policyIssuance.getLpAction().name();
        this.lenderPlaceReason = policyIssuance.getLenderPlaceReason() == null? null : policyIssuance.getLenderPlaceReason().name();
        this.gapBorrowerPolicyRid = policyIssuance.getGapBorrowerPolicyId();
        this.indRenewal = policyIssuance.getIndRenewal();
        this.insuranceAgency = LpInsuranceVendor.ALTHANS.getDisplayName();
        this.migrated = false;
        this.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);
    }

    public void updateToLpLapse(Date expirationDate){
        this.setExpirationDate(expirationDate);
        this.setCancellationEffectiveDate(null);
        PolicyType policyType = PolicyType.valueOf(this.policyType);
        this.setPolicyType(policyType.getLpGapType().name());
        this.setLenderPlaceReason(LenderPlaceReason.getLapseReasonForInsuranceType(policyType.getInsuranceType()).name());
        this.setIndRenewal("Y");
    }

    public void delete(){
        this.setCancellationEffectiveDate(effectiveDate);
        this.setPolicyStatus(PolicyStatus.DELETED.name());
        updateToNoAction();
    }

    public void cancel(CancellationReason cancellationReason, Date cancellationEffectiveDate, Date cancellationTargetDate) {
        this.setCancellationEffectiveDate(cancellationEffectiveDate);
        this.setCancellationTargetDate(cancellationTargetDate);
        this.setLpAction(LPAction.CANCEL_LP.name());
        this.setPolicyStatus(PolicyStatus.CANCELLED.name());
        // do not override cancellationReason if null is  passed
        if (cancellationReason != null) {
            this.setCancellationReason(cancellationReason.name());
        }
    }

    public void cancel(C3PolicyCancellation policyCancellation, Date cancellationTargetDate) {
        this.cancel(policyCancellation.getCancellationReason(),policyCancellation.getCancellationEffectiveDate_(), cancellationTargetDate);
     }

    public void updateToNoAction() {
        setLpTargetDate(null);
        setLpAction(LPAction.NO_ACTION.name());
    }

    public PolicyDTO toPolicyDTO() {
        return PolicyMapperFactory.getPolicyMapper(getInsuranceType(), PolicyType.valueOf(policyType)).toDTO(this);
    }

    public abstract String getInsuranceType();

    public String getLenderPlaceReason() {
        return lenderPlaceReason;
    }

    public void setLenderPlaceReason(String lenderPlaceReason) {
        this.lenderPlaceReason = lenderPlaceReason;
    }

    public Long getGapBorrowerPolicyRid() {
        return gapBorrowerPolicyRid;
    }

    public void setGapBorrowerPolicyRid(Long gapBorrowerPolicyRid) {
        this.gapBorrowerPolicyRid = gapBorrowerPolicyRid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        ProofOfCoverage that = (ProofOfCoverage) o;

        return new EqualsBuilder()
                .append(rid, that.rid)
                .append(policyType, that.policyType)
                .append(policyNumber, that.policyNumber)
                .append(policyStatus, that.policyStatus)
                .append(migrated, that.migrated)
                .append(insuredName, that.insuredName)
                .append(insuranceAgency, that.insuranceAgency)
                .append(insuranceAgent, that.insuranceAgent)
                .append(issuanceDate, that.issuanceDate)
                .append(effectiveDate, that.effectiveDate)
                .append(expirationDate, that.expirationDate)
                .append(cancellationEffectiveDate, that.cancellationEffectiveDate)
                .append(indRenewal, that.indRenewal)
                .append(parentPolicyRid, that.parentPolicyRid)
                .append(lpAction, that.lpAction)
                .append(lpTargetDate, that.lpTargetDate)
                .append(cancellationTargetDate, that.cancellationTargetDate)
                .append(cancellationReason, that.cancellationReason)
                .append(invoicePaymentMethod, that.invoicePaymentMethod)
                .append(refundPaymentMethod, that.refundPaymentMethod)
                .append(renewalPaymentMethod, that.renewalPaymentMethod)
                .append(floodZone, that.floodZone)
                .append(lpLetterCycleRestartedDate, that.lpLetterCycleRestartedDate)
                .append(thirtyDayRegPeriod, that.thirtyDayRegPeriod)
                .append(coverageType, that.coverageType)
                .append(buildingDeductible, that.buildingDeductible)
                .append(contentsDeductible, that.contentsDeductible)
                .append(blanketCoverage, that.blanketCoverage)
                .append(birProofOfCovDetails, that.birProofOfCovDetails)
                .append(reasonForVerification, that.reasonForVerification)
                .append(lenderPlaceReason, that.lenderPlaceReason)
                .append(gapBorrowerPolicyRid, that.gapBorrowerPolicyRid)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(policyType)
                .append(policyNumber)
                .append(policyStatus)
                .append(migrated)
                .append(insuredName)
                .append(insuranceAgency)
                .append(insuranceAgent)
                .append(issuanceDate)
                .append(effectiveDate)
                .append(expirationDate)
                .append(cancellationEffectiveDate)
                .append(indRenewal)
                .append(parentPolicyRid)
                .append(lpAction)
                .append(lpTargetDate)
                .append(cancellationTargetDate)
                .append(cancellationReason)
                .append(invoicePaymentMethod)
                .append(refundPaymentMethod)
                .append(renewalPaymentMethod)
                .append(floodZone)
                .append(lpLetterCycleRestartedDate)
                .append(thirtyDayRegPeriod)
                .append(coverageType)
                .append(buildingDeductible)
                .append(contentsDeductible)
                .append(blanketCoverage)
                .append(birProofOfCovDetails)
                .append(reasonForVerification)
                .append(lenderPlaceReason)
                .append(gapBorrowerPolicyRid)
                .toHashCode();
    }
}
