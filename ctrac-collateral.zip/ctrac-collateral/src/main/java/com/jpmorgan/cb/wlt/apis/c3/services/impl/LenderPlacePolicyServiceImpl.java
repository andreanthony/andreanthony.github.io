package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3AlertEmail;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.services.LenderPlacePolicyService;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.policy.dao.FloodInsurance;
import com.jpmorgan.cb.wlt.apis.policy.dao.GeneralInsurance;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverageRepository;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyPublishEventRequest;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.enums.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AlertEmailEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3WorkflowRequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class LenderPlacePolicyServiceImpl implements LenderPlacePolicyService {

    private static final Logger logger = LoggerFactory.getLogger(LenderPlacePolicyServiceImpl.class);
    private ProofOfCoverageRepository proofOfCoverageRepository;
    private ReferenceDateService referenceDateService;
    private PublishEventService publishEventService;

    @Autowired
    public LenderPlacePolicyServiceImpl(ProofOfCoverageRepository proofOfCoverageRepository,
                                        ReferenceDateService referenceDateService,
                                        PublishEventService publishEventService) {
        assert(proofOfCoverageRepository != null);
        this.proofOfCoverageRepository = proofOfCoverageRepository;
        assert(referenceDateService != null);
        this.referenceDateService = referenceDateService;
        assert(publishEventService != null);
        this.publishEventService = publishEventService;
    }

    @Override
    public List<Long> applyC3Response(C3ResponseDTO c3ResponseDTO) {
        List<Long> proofOfCoverageIds =  issuePolicies(c3ResponseDTO.getPoliciesToIssue());
        proofOfCoverageIds.addAll(cancelPolicies(c3ResponseDTO.getPoliciesToCancel()));
        return proofOfCoverageIds;
    }

    ProofOfCoverage create(C3PolicyIssuance policyIssuance) {
        ProofOfCoverage proofOfCoverage = policyIssuance.getPolicyType().getInsuranceType() == InsuranceType.FLOOD ? new FloodInsurance() : new GeneralInsurance();
        proofOfCoverage.map(policyIssuance);
        proofOfCoverage = saveProofOfCoverage(proofOfCoverage);
        publishLPPolicyEvent(proofOfCoverage, CtracEventType.CREATED);
        return proofOfCoverage;
    }

    @Override
    public ProofOfCoverage cancel(C3PolicyCancellation policyCancellation) {
        ProofOfCoverage proofOfCoverage = getProofOfCoverage(policyCancellation.getPolicyId());
        processCancellation(proofOfCoverage, policyCancellation);
        proofOfCoverage = saveProofOfCoverage(proofOfCoverage);
        publishLPPolicyEvent(proofOfCoverage, PolicyStatus.DELETED == proofOfCoverage.getPolicyStatus_() ?
                CtracEventType.DELETED: CtracEventType.EDITED);
        return proofOfCoverage;
    }

    private ProofOfCoverage saveProofOfCoverage(ProofOfCoverage proofOfCoverage) {
        final String C_3 = "C3";
        proofOfCoverage.updateAuditInfo(C_3);
        proofOfCoverage = proofOfCoverageRepository.save(proofOfCoverage);
        if (StringUtils.isEmpty(proofOfCoverage.getPolicyNumber())) {
            proofOfCoverage.setPolicyNumber(proofOfCoverage.getRid().toString());
            proofOfCoverage = proofOfCoverageRepository.save(proofOfCoverage);
        }
        return proofOfCoverage;
    }

    ProofOfCoverage getProofOfCoverage(Long policyId) {
        Optional<ProofOfCoverage> policy = proofOfCoverageRepository.findById(policyId);
        if (!policy.isPresent()) {
            logger.debug("Policy not found for policyId={}", policyId);
            throw new CtracException("Policy not found for policyId=" + policyId);
        }
        return policy.get();
    }

    List<Long> issuePolicies(List<C3PolicyIssuance> policyIssuances) {
        List<Long> proofOfCoverageIds = new ArrayList<>();
        policyIssuances.parallelStream().forEach(policyIssue ->
                proofOfCoverageIds.add(create(policyIssue).getRid()));
        return proofOfCoverageIds;
    }

    List<Long> cancelPolicies(List<C3PolicyCancellation> policyCancellations) {
        List<Long> proofOfCoverageIds = new ArrayList<>();
        policyCancellations.parallelStream().forEach(policyCancellation -> {
            if (cancel(policyCancellation).getRid() != null) {
                proofOfCoverageIds.add(policyCancellation.getPolicyId());
            }
        });
        return proofOfCoverageIds;
    }

    void processCancellation(ProofOfCoverage proofOfCoverage, C3PolicyCancellation policyCancellation) {
        if (policyCancellation.isDeleted()) {
            proofOfCoverage.delete();
        } else if (policyCancellation.getUpdatedExpirationDate() != null) {
            proofOfCoverage.updateToLpLapse(policyCancellation.getUpdatedExpirationDate_());
        } else {
            proofOfCoverage.cancel(policyCancellation, referenceDateService.getCurrentReferenceDate());
        }
    }

    void publishLPPolicyEvent(ProofOfCoverage proofOfCoverage, CtracEventType ctracEventType){
        publishEventService.publishEvent(new PolicyPublishEventRequest(
                proofOfCoverage, InsuranceType.valueOf(proofOfCoverage.getInsuranceType()),
                proofOfCoverage.getProvidedCoverages().get(0).getCollateralId())
                        .forCtracEventType(ctracEventType)
                        .withUserRequestInfo(UserRequestInfo.createSystemUserRequest()));
    }

    @Override
    public void publishC3WorkflowEvent(List<Long> proofOfCoverageIds, Long collateralRid, CtracEventType ctracEventType){
        C3WorkflowRequestEventDTO c3WorkflowRequestEvent = new C3WorkflowRequestEventDTO();
        c3WorkflowRequestEvent.setEventType(ctracEventType.getDisplayValue());
        c3WorkflowRequestEvent.setProofOfCoverageRids(proofOfCoverageIds);
        c3WorkflowRequestEvent.setCollateralRid(collateralRid);
        c3WorkflowRequestEvent.setPerformedBy(CtracAppConstants.SYSTEM_USER);
        publishEventService.publishEvent(c3WorkflowRequestEvent);
    }

    @Override
    public void publishAlertEmailEvent(C3AlertEmail alertEmail){
        AlertEmailEventDTO alertEmailEvent =  alertEmail.toAlertTemplateDTO();
        alertEmailEvent.setEventType(CtracEventType.SEND_ALERT_EMAIL.getDisplayValue());
        alertEmailEvent.setPerformedBy(CtracAppConstants.SYSTEM_USER);
        publishEventService.publishEvent(alertEmailEvent);
    }

}
