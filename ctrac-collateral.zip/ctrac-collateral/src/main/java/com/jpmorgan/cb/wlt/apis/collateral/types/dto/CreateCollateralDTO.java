package com.jpmorgan.cb.wlt.apis.collateral.types.dto;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotBlank;

public abstract class CreateCollateralDTO {

    private String lineOfBusiness;

    private String collateralType;

    @ApiModelProperty(required = true)
    public String getCollateralType() {
        return collateralType;
    }

    public void setCollateralType(String collateralType) {
        this.collateralType = collateralType;
    }

    @ApiModelProperty(required = true)
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

}