package com.jpmorgan.cb.wlt.apis.event;

public enum CollateralEventStatus {
    PENDING, PUBLISHED
}
