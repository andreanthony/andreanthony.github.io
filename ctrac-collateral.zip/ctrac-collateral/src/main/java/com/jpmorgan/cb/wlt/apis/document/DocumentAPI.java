package com.jpmorgan.cb.wlt.apis.document;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.services.CollateralDocumentService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/document/")
public class DocumentAPI {

    private static final Logger logger = LoggerFactory.getLogger(DocumentAPI.class);
    private CollateralDocumentService collateralDocumentService;

    @Autowired
    public DocumentAPI(CollateralDocumentService collateralDocumentService) {
        assert(collateralDocumentService != null);
        this.collateralDocumentService = collateralDocumentService;
    }

    @RequestMapping(value = "/{docId}/stream", method = RequestMethod.GET, produces = MediaType.APPLICATION_PDF_VALUE)
    public void streamDocument(@PathVariable("docId") Long docId, HttpServletResponse response) {
        try {
            CollateralDocument document = collateralDocumentService.lookupAndValidateDocument(docId);
            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "inline; filename="+document.getFileName());
            response.getOutputStream().write(document.getFileContent().getFileContent());
        } catch (IOException e) {
            throw new CtracException("Failure - streaming the document " + docId);
        } finally {
            try {
                response.getOutputStream().close();
            } catch (IOException e) {
                logger.error("Failed to close response output stream for document streaming for document "+ docId, e);
            }
        }
    }


}
