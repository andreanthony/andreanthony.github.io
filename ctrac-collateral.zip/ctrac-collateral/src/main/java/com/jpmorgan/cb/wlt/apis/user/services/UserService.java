package com.jpmorgan.cb.wlt.apis.user.services;

import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

public interface UserService {

    void populateUserDetails(UserRequestInfo userRequestInfo);

    Boolean clearUserEntitlementsCache();
}
