package com.jpmorgan.cb.wlt.apis.upload.dao.repository;

import com.jpmorgan.cb.wlt.apis.upload.dao.FileUploadAttachment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FileUploadAttachmentRepository extends JpaRepository<FileUploadAttachment, Long> {
    List<FileUploadAttachment> findByBucketName(String bucketName);

    void deleteByBucketName(String bucketName);

    Integer countByBucketName(String bucketName);
}
