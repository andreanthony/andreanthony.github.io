package com.jpmorgan.cb.wlt.apis.policy.dao.mappers;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.FloodBorrowerPolicyMapper;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.FloodLenderPlacePolicyMapper;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.GeneralBorrowerPolicyMapper;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.GeneralLenderPlacePolicyMapper;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;

public class PolicyMapperFactory {
    private PolicyMapperFactory() {}

    public static DaoMapper<ProofOfCoverage, PolicyDTO> getPolicyMapper(String insuranceType, PolicyType policyType) {
        if (InsuranceType.GENERAL.name().equals(insuranceType)) {
            if (policyType.isLenderPlaced()) {
                return new GeneralLenderPlacePolicyMapper();
            }
            return new GeneralBorrowerPolicyMapper();
        } else {
            if (policyType.isLenderPlaced()) {
                return new FloodLenderPlacePolicyMapper();
            }
            return new FloodBorrowerPolicyMapper();
        }
    }
}
