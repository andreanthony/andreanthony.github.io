package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cb.wlt.dao.CoverageDetails;
import com.jpmorgan.cb.wlt.dao.Hold;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_REQUIRED_COVERAGE")
public class RequiredCoverage extends AuditableEntity {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "requiredCoverageSeqGenerator")
    @TableGenerator(name = "requiredCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_REQUIRED_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Id
    @Column(name = "RID")
    private Long rid;

    @OneToOne(cascade = {CascadeType.ALL}, orphanRemoval = true)
    @JoinColumn(name = "PRIMARY_COV_DET_ID", nullable = false)
    private CoverageDetails primaryCoverageDetails;

    // TODO FIXME: make nullable false after migration is determined!!!
    @OneToOne(cascade = {CascadeType.ALL}, orphanRemoval = true)
    @JoinColumn(name = "EXCESS_COV_DET_ID", nullable = true)
    private CoverageDetails excessCoverageDetails = new CoverageDetails();

    @ManyToOne
    @JoinColumn(name = "INSURABLE_ASSET_ID", nullable = false)
    private InsurableAsset insurableAsset;

    @Column(name = "PROPERTY_TYPE")
    private String propertyType;

    @Column(name = "IS_DESCOPED")
    private String isDescoped;

    @ManyToOne
    @JoinColumn(name = "REQUIRED_COVERAGE_SOURCE_ID", nullable = false)
    private RequiredCoverageSource requiredCoverageSource;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public InsurableAsset getInsurableAsset() {
        return insurableAsset;
    }

    public void setInsurableAsset(InsurableAsset insurableAsset) {
        this.insurableAsset = insurableAsset;
    }

    public RequiredCoverageSource getRequiredCoverageSource() {
        return requiredCoverageSource;
    }

    public void setRequiredCoverageSource(RequiredCoverageSource requiredCoverageSource) {
        this.requiredCoverageSource = requiredCoverageSource;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public String getIsDescoped() {
        return isDescoped;
    }

    public void setIsDescoped(String isDescoped) {
        this.isDescoped = isDescoped;
    }

    public CoverageDetails getPrimaryCoverageDetails() {
        return primaryCoverageDetails;
    }

    public void setPrimaryCoverageDetails(CoverageDetails primaryCoverageDetails) {
        this.primaryCoverageDetails = primaryCoverageDetails;
    }

    public CoverageDetails getExcessCoverageDetails() {
        return excessCoverageDetails;
    }

    public void setExcessCoverageDetails(CoverageDetails excessCoverageDetails) {
        this.excessCoverageDetails = excessCoverageDetails;
    }

    public Hold getPrimaryHold() {
        if(primaryCoverageDetails != null) {
            return primaryCoverageDetails.getHold();
        }
        return null;
    }

    public Hold getExcessHold() {
        if(excessCoverageDetails != null) {
            return excessCoverageDetails.getHold();
        }
        return null;
    }
}
