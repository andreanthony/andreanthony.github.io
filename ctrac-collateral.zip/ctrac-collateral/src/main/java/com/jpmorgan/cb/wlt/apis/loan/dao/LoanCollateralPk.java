package com.jpmorgan.cb.wlt.apis.loan.dao;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.io.Serializable;

public class LoanCollateralPk implements Serializable {
    private static final long serialVersionUID = -1;

    private Loan loan;
    private Long collateralId;

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public Long getCollateralId() {
        return collateralId;
    }

    public void setCollateralId(Long collateralId) {
        this.collateralId = collateralId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {return true;}
        if (o == null || getClass() != o.getClass()) {return false;}

        LoanCollateralPk that = (LoanCollateralPk) o;
        return new EqualsBuilder()
                .append(loan, that.loan)
                .append(collateralId, that.collateralId)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(loan)
                .append(collateralId)
                .toHashCode();
    }
}
