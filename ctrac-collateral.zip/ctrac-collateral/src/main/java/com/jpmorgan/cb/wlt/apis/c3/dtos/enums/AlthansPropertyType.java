package com.jpmorgan.cb.wlt.apis.c3.dtos.enums;

import java.util.Arrays;

public enum AlthansPropertyType {

	DWELLING_RESIDENTIAL("DW", "Dwelling (1-4 Unit) Residential"), 
	MULTI_FAMILY("MF", "5+ Multi Family"), 
	COMMERCIAL("COMM", "Commercial"), 
	CONDO_ASSOC("CA", "Condo Association");
		
	private final String code;
	private final String desc;

	AlthansPropertyType(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public static AlthansPropertyType getByCodeOrDesc(String value) {
		  return Arrays.stream(AlthansPropertyType.values())
				.filter(propertyType ->
						propertyType.code.equals(value) || propertyType.desc.equals(value))
				  .findAny()
				  .orElse(null);
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	public boolean isCommercial() {
		return this == MULTI_FAMILY || this == COMMERCIAL;
	}
	public boolean isResidential() {
		return this == DWELLING_RESIDENTIAL;
	}
	public boolean isCondoAssociation() {
		return this == CONDO_ASSOC;
	}
}
