package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;

import java.util.Comparator;
import java.util.Date;

public class C3PolicyCancellationDateComparator implements Comparator<C3PolicyCancellation> {
    public int compare(C3PolicyCancellation one, C3PolicyCancellation two) {
        if (one == two) {
            return 0;
        }
        if (two == null) {
            return -1;
        }
        if (one == null) {
            return 1;
        }
        if (one.isDeleted()) {
            if (two.isDeleted()) {
                return 0;
            }
            else {
                return -1;
            }
        }
        else if (two.isDeleted()) {
            return 1;
        }
        Date date1 = one.getUpdatedExpirationDate_() == null? one.getCancellationEffectiveDate_() : one.getUpdatedExpirationDate_();
        Date date2 = two.getUpdatedExpirationDate_() == null? two.getCancellationEffectiveDate_() : two.getUpdatedExpirationDate_();
        if (date2 == null) {
            return -1;
        }
        if (date1 == null) {
            return 1;
        }
        return date1.compareTo(date2);
    }

}


