package com.jpmorgan.cb.wlt.apis.c3.dtos;

import io.swagger.annotations.ApiModelProperty;

import java.beans.Transient;
import java.io.Serializable;
import java.util.Date;

public class C3Hold implements Serializable {
    private static final long serialVersionUID = -1;
    // start date of the entire hold
    private Date holdStartDate;
    private Date holdLpiDate;
    private Long rid;
    private boolean newHold;

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isAfter(Date calculatedCoverageDate) {
        return holdStartDate.after(calculatedCoverageDate);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isActive(Date calculatedCoverageDate) {
        return !holdStartDate.after(calculatedCoverageDate) &&
                (holdLpiDate == null || calculatedCoverageDate.before(holdLpiDate));
    }

    public Date getHoldStartDate() {
        return holdStartDate;
    }

    public void setHoldStartDate(Date holdStartDate) {
        this.holdStartDate = holdStartDate;
    }

    public Date getHoldLpiDate() {
        return holdLpiDate;
    }

    public void setHoldLpiDate(Date holdLpiDate) {
        this.holdLpiDate = holdLpiDate;
    }

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public boolean isNewHold() {
        return newHold;
    }

    public void setNewHold(boolean newHold) {
        this.newHold = newHold;
    }
}
