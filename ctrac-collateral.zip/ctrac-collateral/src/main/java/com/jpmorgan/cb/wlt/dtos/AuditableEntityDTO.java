package com.jpmorgan.cb.wlt.dtos;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.SimplePatternDateFormatter;

public class AuditableEntityDTO {

    private static final DateFormatter DATE_FORMATTER = new SimplePatternDateFormatter("MM/dd/yyyy HH:mm Z");

    private String updatedBy;
    private String updatedDate;

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    public void fromAuditableEntityModel(AuditableEntity auditableEntity){
        this.setUpdatedBy(auditableEntity.getUpdatedBy());
        this.setUpdatedDate(DATE_FORMATTER.print(auditableEntity.getUpdatedDate()));
    }
}
