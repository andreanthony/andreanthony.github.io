package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.CollateralRepository;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.lookup.dtos.LookupCodeDTO;
import com.jpmorgan.cb.wlt.apis.lookup.services.LookupCodeService;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PaymentMethodDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.services.LetterCycleValidator;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyService;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyValidationService;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralRequiredCoverageSourceService;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.dtos.AddressDTO;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.bir.enums.BorrowerInsuranceReviewRule;
import com.jpmorgan.cib.wlt.ctrac.bir.rules.BIRRuleHelper;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ValidationException;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;


@Service
public class PolicyValidationServiceImpl implements PolicyValidationService {

    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    private static final Set<String> VALID_YES_NO_VALUES =
            new HashSet<>(Arrays.asList("Yes", "No"));

    private ReferenceDateService referenceDateService;
    private GeneralRequiredCoverageSourceService generalRequiredCoverageSourceService;
    private PolicyService policyService;
    private CollateralDetailsService collateralDetailsService;
    @Autowired
    private CollateralRepository collateralRepository;
    private List<String> stateList = new ArrayList<>();
    private Set<String> validJPMLienPositionValues = new HashSet<>();
    private LetterCycleValidator letterCycleValidator;

    @Autowired
    public PolicyValidationServiceImpl (ReferenceDateService referenceDateService,
                                        GeneralRequiredCoverageSourceService generalRequiredCoverageSourceService,
                                        PolicyService policyService,
                                        CollateralDetailsService collateralDetailsService,
                                        LookupCodeService lookupCodeService,
                                        LetterCycleValidator letterCycleValidator) {
        assert(referenceDateService != null);
        this.referenceDateService = referenceDateService;
        assert(generalRequiredCoverageSourceService != null);
        this.generalRequiredCoverageSourceService = generalRequiredCoverageSourceService;
        assert(policyService != null);
        this.policyService = policyService;
        assert(collateralDetailsService != null);
        this.collateralDetailsService = collateralDetailsService;
        assert(lookupCodeService != null);
        List<LookupCodeDTO> stateCodeDTOs = lookupCodeService.getByCodeset("STATE_CODES");
        for (LookupCodeDTO stateCodeDTO: stateCodeDTOs) {
            stateList.add(stateCodeDTO.getCode());
        }
        List<LookupCodeDTO> jpmLienPositionValues = lookupCodeService.getByCodeset("BRW_INS_REVIEW_JPM_LIEN_POSITION");
        for (LookupCodeDTO jpmLienPosition: jpmLienPositionValues) {
            validJPMLienPositionValues.add(jpmLienPosition.getCode());
        }
        assert(letterCycleValidator != null);
        this.letterCycleValidator = letterCycleValidator;
    }

    @Override
    public void validateCreate(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded) {
        List<String> validationErrors = new ArrayList<>();
        validateCollateralIds(policyDTO, validationErrors);
        validatePolicyIdNull(policyDTO, validationErrors);
        validatePolicyStatusBlank(policyDTO, validationErrors);
        validatePolicyDocumentIsProvided(policyDTO, filesUploaded, validationErrors);
        Map<Long, List<GeneralCoverageDTO>> generalCoveragesMap = getGeneralCoverages(policyDTO);
        validateForm(policyDTO, validationErrors, null, generalCoveragesMap);
        if (!validationErrors.isEmpty()) {
            throw new ValidationException().with(validationErrors);
        }
    }

    private void validateCollateralIds(PolicyDTO policyDTO, List<String> validationErrors) {
        if (policyDTO.getCollateralCoverages().stream().anyMatch(collateralDetailsDto ->
                collateralDetailsDto.getCollateralId() == null || collateralDetailsDto.getCollateralId() <= 0 ||
                        (!collateralRepository.findById(collateralDetailsDto.getCollateralId()).isPresent()))) {
            validationErrors.add("collateralRid invalid");
        }
    }

    @Override
    public void validateEdit(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, PolicyStatus policyStatus) {
        List<String> validationErrors = new ArrayList<>();
        Map<Long, List<GeneralCoverageDTO>> generalCoveragesMap = getGeneralCoverages(policyDTO);
        validateForm(policyDTO, validationErrors, policyStatus, generalCoveragesMap);
        if (!validationErrors.isEmpty()) {
            throw new ValidationException().with(validationErrors);
        }
    }

    @Override
    public void validateOverride(PolicyDTO policyDTO, PolicyStatus policyStatus) {
        List<String> validationErrors = new ArrayList<>();
        validateFormForOverride(policyDTO, validationErrors, policyStatus);
        if (!validationErrors.isEmpty()) {
            throw new ValidationException().with(validationErrors);
        }
    }

    @Override
    public void validateVerify(PolicyDTO policyDTO, PolicyStatus policyStatus) {
        List<String> validationErrors = new ArrayList<>();
        Map<Long, List<GeneralCoverageDTO>> generalCoveragesMap = getGeneralCoverages(policyDTO);
        validateForm(policyDTO, validationErrors, policyStatus, generalCoveragesMap);
        validationErrors.addAll(letterCycleValidator.validate(policyDTO, generalCoveragesMap.get(policyDTO.getCollateralCoverages().get(0).getCollateralId())));
        if (!validationErrors.isEmpty()) {
            throw new ValidationException().with(validationErrors);
        }
    }

    @Override
    public void validateReview(PolicyDTO policyDTO) {
        List<String> validationErrors = new ArrayList<>();
        if (!EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()).isBorrowerPolicy()) {
            validationErrors.add("Policy is not a Borrower policy");
        }
        validateJpmMortgagePayee(policyDTO, validationErrors);
        validateJpmLenderLossPayee(policyDTO, validationErrors);
        validateJpmAdditionalInsured(policyDTO, validationErrors);
        validateJpmLienPosition(policyDTO, validationErrors);
        validateProofofPayment(policyDTO, validationErrors);
        validatePolicyWrittenAtRcv(policyDTO, validationErrors);
        validateInsuredNameBlank(policyDTO, validationErrors);
        validatePolicyCollateralAddresses(policyDTO, validationErrors);
        if (!validationErrors.isEmpty()) {
            throw new ValidationException().with(validationErrors);
        }
    }

    private void validateForm(PolicyDTO policyDTO, List<String> validationErrors, PolicyStatus policyStatus,  Map<Long, List<GeneralCoverageDTO>> generalCoverages) {
        if (validatePolicyType(policyDTO, validationErrors)) {
            if(EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()).isLenderPlaced()) {
                validateInvoicePaymentMethod(policyDTO, validationErrors);
                validateRefundPaymentMethod(policyDTO, validationErrors);
                if (policyStatus != null && policyStatus.isExpiring()) {
                    validateRenewalPaymentMethod(policyDTO, validationErrors);
                }
                validateOneToOneCoverage(policyDTO, validationErrors);
                validatePolicyConclusionsLP(policyDTO, validationErrors);
            } else {
                validateEoiReceivedDateBlank(policyDTO, validationErrors);
                validateEvidenceOfInsurance(policyDTO, validationErrors);
                validateJpmMortgagePayee(policyDTO, validationErrors);
                validateJpmLenderLossPayee(policyDTO, validationErrors);
                validateJpmAdditionalInsured(policyDTO, validationErrors);
                validateJpmLienPosition(policyDTO, validationErrors);
                validateProofofPayment(policyDTO, validationErrors);
                validatePolicyWrittenAtRcv(policyDTO, validationErrors);
                validateInsuredNameBlank(policyDTO, validationErrors);
                validateMigratedPolicyBlank(policyDTO, validationErrors);
                validateInsuranceCompanyDetails(policyDTO, validationErrors);
                validateCancellationDate(policyDTO, validationErrors);
                validatePolicyCollateralAddresses(policyDTO, validationErrors);
                validateValidPolicyConclusions(policyDTO, validationErrors);
            }
            validateInsuranceCoverageType(policyDTO, generalCoverages, validationErrors);
            validateCoverageAmount(policyDTO, validationErrors);
        }
        validateDates(policyDTO, validationErrors);
        validatePolicyNumber(policyDTO, validationErrors);
        validateInsuranceCompanyName(policyDTO, validationErrors);
    }

    private void validatePolicyCollateralAddresses(PolicyDTO policyDTO, List<String> validationErrors) {
        policyDTO.getCollateralCoverages().forEach(policyCollateralDetailsDTO -> {
            validatePolicyAddress(policyCollateralDetailsDTO.getPolicyAddress(), validationErrors);
            validateCity(policyCollateralDetailsDTO.getCity(), validationErrors);
            validateState(policyCollateralDetailsDTO.getState(), validationErrors);
            validateZipcode(policyCollateralDetailsDTO.getZipCode(), validationErrors);
        });
    }

     private void validateFormForOverride(PolicyDTO policyDTO, List<String> validationErrors, PolicyStatus policyStatus) {
        if (validatePolicyType(policyDTO, validationErrors)) {
            if (!EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()).isLenderPlaced()){
                validationErrors.add("Policy is not a Lender Placed policy");
            } else {
                validateInvoicePaymentMethod(policyDTO, validationErrors);
                validateRefundPaymentMethod(policyDTO, validationErrors);
                if (policyStatus != null && policyStatus.isExpiring()) {
                    validateRenewalPaymentMethod(policyDTO, validationErrors);
                }
                validateCoverageAmount(policyDTO, validationErrors);
            }
        }
        validateDates(policyDTO, validationErrors);
        validatePolicyNumber(policyDTO, validationErrors);
    }


    private void validateEffectiveDate(DateTime effectiveDate, DateTime expirationDate, List<String> validationErrors) {
        if (!expirationDate.isAfter(effectiveDate)){
            validationErrors.add("Expiration date must be greater than the effective date.");
        }
    }

    private void validateExpirationDate(DateTime expirationDate, List<String> validationErrors) {
        DateTime referenceDate = new DateTime(referenceDateService.getCurrentReferenceDate()).withTimeAtStartOfDay();
        if(!expirationDate.isAfter(referenceDate)) {
            validationErrors.add("Expiration date must be a future date.");
        }
    }

    private void validateDates(PolicyDTO policyDTO, List<String> validationErrors) {
        DateTime effectiveDate = DateValidator.validateDateValue(policyDTO.getEffectiveDate(), "effective", validationErrors);
        DateTime expirationDate = DateValidator.validateDateValue(policyDTO.getExpirationDate(), "expiration", validationErrors);
        if (expirationDate != null) {
            validateExpirationDate(expirationDate.withTimeAtStartOfDay(), validationErrors);
            if (effectiveDate != null) {
                validateEffectiveDate(effectiveDate, expirationDate, validationErrors);
                if (validatePolicyType(policyDTO, validationErrors) && EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()).isLenderPlaced()) {
                    // TODO: following method only pull the first coverage - update to do multiple for borrower policy
                    validateDateOverlap(policyDTO, effectiveDate, expirationDate, validationErrors);
                }
            }
        }
    }

    private void validateDateOverlap(PolicyDTO policyDTO, DateTime effectiveDate, DateTime expirationDate, List<String> validationErrors) {
        if (!policyDTO.getCollateralCoverages().isEmpty() && !policyDTO.getCollateralCoverages().get(0).getInsuranceCoverages().isEmpty()) {
            Long collateralId = policyDTO.getCollateralCoverages().get(0).getCollateralId();
            String insuranceCoverageType = policyDTO.getCollateralCoverages().get(0).getInsuranceCoverages().get(0).getInsuranceCoverageType();
            List<PolicyDTO> collateralPolicies = getSameCoverageTypePolicies(collateralId, insuranceCoverageType);
            for (PolicyDTO collateralPolicy : collateralPolicies) {
                if (!collateralPolicy.getPolicyId().equals(policyDTO.getPolicyId())) {
                    DateTime compEffectiveDate = new DateTime(DATE_FORMATTER.parse(collateralPolicy.getEffectiveDate()));
                    DateTime compExpirationDate = new DateTime(DATE_FORMATTER.parse(collateralPolicy.getExpirationDate()));
                    boolean datesBefore = effectiveDate.isBefore(compEffectiveDate) && !expirationDate.isAfter(compEffectiveDate);
                    boolean datesAfter = !effectiveDate.isBefore(compExpirationDate) && expirationDate.isAfter(compExpirationDate);
                    if (!(datesBefore || datesAfter)) {
                        validationErrors.add("Current dates overlap with existing policy.");
                        return;
                    }
                }
            }
        }
    }

    private void validatePolicyNumber(PolicyDTO policyDTO, List<String> validationErrors) {
        if (StringUtils.isBlank(policyDTO.getPolicyNumber())) {
            validationErrors.add("policyNumber required");
        }
    }


    private void validateInsuranceCompanyName(PolicyDTO policyDTO, List<String> validationErrors) {
        if (StringUtils.isBlank(policyDTO.getInsuranceCompanyName())) {
            validationErrors.add("insuranceCompanyName required");
        }
    }

    private void validateInvoicePaymentMethod(PolicyDTO policyDTO, List<String> validationErrors) {
        if (StringUtils.isBlank(policyDTO.getInvoicePaymentMethod().getPaymentMethod())) {
            validationErrors.add("invoicePaymentMethod required");
        } else {
            validatePaymentDetails(policyDTO.getInvoicePaymentMethod(), validationErrors);
        }
    }

    private void validateRenewalPaymentMethod(PolicyDTO policyDTO, List<String> validationErrors) {
        if (StringUtils.isBlank(policyDTO.getRenewalPaymentMethod().getPaymentMethod())) {
            validationErrors.add("renewalPaymentMethod required");
        } else {
            validatePaymentDetails(policyDTO.getRenewalPaymentMethod(), validationErrors);
        }
    }

    private void validateRefundPaymentMethod(PolicyDTO policyDTO, List<String> validationErrors) {
        if (!StringUtils.isBlank(policyDTO.getRefundPaymentMethod().getPaymentMethod())) {
            validatePaymentDetails(policyDTO.getRefundPaymentMethod(), validationErrors);
        }
    }

    private void validatePaymentDetails(PaymentMethodDTO paymentMethodDTO, List<String> validationErrors) {
        if ("CC".equals(paymentMethodDTO.getPaymentMethod())) {
            validateAddress(paymentMethodDTO.getAddress(), validationErrors);
        } else if (StringUtils.isBlank(paymentMethodDTO.getPaymentAccount())) {
            validationErrors.add("paymentAccount required");
        }
    }

    private void validateAddress(AddressDTO addressDTO, List<String> validationErrors) {
        if (addressDTO == null) {
            validationErrors.add("addressDTO required");
        } else {
            validateStreetAddress(addressDTO.getStreetAddress(), validationErrors);
            validateCity(addressDTO.getCity(), validationErrors);
            validateState(addressDTO.getState(), validationErrors);
            validateZipcode(addressDTO.getZipCode(), validationErrors);
        }
    }

    private void validateStreetAddress(String streetAddress, List<String> validationErrors) {
        if (StringUtils.isBlank(streetAddress)) {
            validationErrors.add("streetAddress required");
        }
    }

    private void validatePolicyAddress(String policyAddress, List<String> validationErrors) {
        if (StringUtils.isBlank(policyAddress)) {
            validationErrors.add("Policy Address required");
        }
    }

    private void validateCity(String city, List<String> validationErrors) {
        if (StringUtils.isBlank(city)) {
            validationErrors.add("city required");
        }
    }

    private void validateState(String state, List<String> validationErrors) {
        if (StringUtils.isBlank(state)) {
            validationErrors.add("state required");
        } else if (!stateList.contains(state)) {
            validationErrors.add("state invalid");
        }
    }

    private void validateZipcode(String zipcode, List<String> validationErrors) {
        if (StringUtils.isBlank(zipcode)) {
            validationErrors.add("zipcode required");
        } else if (zipcode.length() != 5 && zipcode.length() != 10) {
            validationErrors.add("zipcode invalid");
        } else if (zipcode.length() == 5 && !StringUtils.isNumeric(zipcode)) {
            validationErrors.add("zipcode invalid");
        } else if (zipcode.length() == 10) { // 12345-1234
            String[] detailedZipCode = zipcode.split("-");
            if (!(detailedZipCode.length == 2 && detailedZipCode[0].length() == 5 && StringUtils.isNumeric(detailedZipCode[0]) && StringUtils.isNumeric(detailedZipCode[1]))) {
                validationErrors.add("zipcode invalid");
            }
        }
    }

    private void validateInsuranceCoverageType(PolicyDTO policyDTO,  Map<Long, List<GeneralCoverageDTO>> generalCoveragesMap, List<String> validationErrors) {
        if(EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()).isLenderPlaced()) {
            if (!policyDTO.getCollateralCoverages().isEmpty() && !policyDTO.getCollateralCoverages().get(0).getInsuranceCoverages().isEmpty()) {
                String insuranceCoverageType = policyDTO.getCollateralCoverages().get(0).getInsuranceCoverages().get(0).getInsuranceCoverageType();
                if (StringUtils.isBlank(insuranceCoverageType)) {
                    validationErrors.add("insuranceCoverageType required");
                } else if (!getRequiredCoverageTypes(generalCoveragesMap.get(policyDTO.getCollateralCoverages().get(0).getCollateralId())).contains(insuranceCoverageType)) {
                    validationErrors.add("insuranceCoverageType invalid");
                }
            } else {
                validationErrors.add("insuranceCoverageType required");
            }
        } else {
            if (CollectionUtils.isNotEmpty(policyDTO.getCollateralCoverages())) {
                policyDTO.getCollateralCoverages().forEach(policyCollateralDetails -> {
                    if (CollectionUtils.isNotEmpty(policyCollateralDetails.getInsuranceCoverages())) {
                        Boolean result = policyCollateralDetails.getInsuranceCoverages().stream().anyMatch(policyInsuranceCoverageDTO ->
                                StringUtils.isBlank(policyInsuranceCoverageDTO.getInsuranceCoverageType()) ||
                                        !getRequiredCoverageTypes(generalCoveragesMap.get(policyCollateralDetails.getCollateralId())).contains(policyInsuranceCoverageDTO.getInsuranceCoverageType()));
                        if (BooleanUtils.isTrue(result)) {
                            validationErrors.add(StringUtils.join("insuranceCoverageType required/invalid - collateral:",policyCollateralDetails.getCollateralId()));
                        }

                    } else {
                        validationErrors.add(StringUtils.join("Insurance coverage required for collateral:", policyCollateralDetails.getCollateralId()));
                    }
                });
            } else {
                validationErrors.add("collateralCoverages required");
            }
        }
    }

    private void validateOneToOneCoverage(PolicyDTO policyDTO, List<String> validationErrors) {
        if (policyDTO.getCollateralCoverages().size() > 1 ||
                !policyDTO.getCollateralCoverages().isEmpty()
                        && policyDTO.getCollateralCoverages().get(0).getInsuranceCoverages().size() > 1) {
            validationErrors.add("Only 1 coverage type allowed per LPI");
        }
    }

    private void validateCoverageAmount(PolicyDTO policyDTO,  List<String> validationErrors) {
        if(EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()).isLenderPlaced()) {
            if (!policyDTO.getCollateralCoverages().isEmpty() && !policyDTO.getCollateralCoverages().get(0).getInsuranceCoverages().isEmpty()) {
                BigDecimal coverageAmount = policyDTO.getCollateralCoverages().get(0).getInsuranceCoverages().get(0).getCoverageAmount();
                if (coverageAmount == null) {
                    validationErrors.add("coverageAmount required");
                } else if (coverageAmount.signum() <= 0) {
                    validationErrors.add("coverageAmount invalid");
                }
            } else {
                validationErrors.add("coverageAmount required");
            }
        } else {
            if (CollectionUtils.isNotEmpty(policyDTO.getCollateralCoverages())) {
                policyDTO.getCollateralCoverages().forEach(policyCollateralDetails -> {
                    if (CollectionUtils.isNotEmpty(policyCollateralDetails.getInsuranceCoverages())) {
                        policyCollateralDetails.getInsuranceCoverages().forEach(policyInsuranceCoverageDTO -> {
                            if (policyInsuranceCoverageDTO.getCoverageAmount() == null) {
                                validationErrors.add(StringUtils.join("coverageAmount required - collateral:", policyCollateralDetails.getCollateralId(),
                                        " - coverageType:", policyInsuranceCoverageDTO.getInsuranceCoverageType()));
                            } else if (policyInsuranceCoverageDTO.getCoverageAmount().signum() <= 0) {
                                validationErrors.add(StringUtils.join("coverageAmount invalid - collateral:", policyCollateralDetails.getCollateralId(),
                                        " - coverageType:", policyInsuranceCoverageDTO.getInsuranceCoverageType()));
                            }
                        });
                    }
                });
           }
        }
    }


    private void validatePolicyIdNull(PolicyDTO policyDTO, List<String> validationErrors) {
        if (policyDTO.getPolicyId() != null) {
            validationErrors.add("policyId not null");
        }
    }

    private boolean validatePolicyType(PolicyDTO policyDTO, List<String> validationErrors) {
        if (StringUtils.isBlank(policyDTO.getPolicyType())) {
            validationErrors.add("policyType required");
        }
        try {
            PolicyType.valueOf(policyDTO.getPolicyType());
            return true;
        } catch (Exception e) {
            validationErrors.add("policyType invalid");
        }
        return false;
    }

    private void validatePolicyStatusBlank(PolicyDTO policyDTO, List<String> validationErrors) {
        if (StringUtils.isNotBlank(policyDTO.getPolicyStatus())) {
            validationErrors.add("policyStatus invalid");
        }
    }

    private void validatePolicyDocumentIsProvided(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded,
                                                  List<String> validationErrors) {
        if (CollectionUtils.isEmpty(filesUploaded) && CollectionUtils.isEmpty(policyDTO.getPolicyDocuments())) {
            validationErrors.add("policyDocuments required");
        }
    }

    private void validateInsuranceCompanyDetails(PolicyDTO policyDTO, List<String> validationErrors) {
        validateInsuranceCompanyName(policyDTO, validationErrors);
        if(StringUtils.isBlank(policyDTO.getAgentEmailAddress())
            && StringUtils.isBlank(policyDTO.getAgentPhoneNumber())
            && StringUtils.isBlank(policyDTO.getAgentFaxNumber())) {
            validationErrors.add("At least one among these are required: Agent Email Address, Phone number, Fax number required");
        }
    }

    private void validateEvidenceOfInsurance(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isBlank(policyDTO.getEvidenceOfInsurance())) {
            validationErrors.add("Evidence of Insurance required");
        } else {
            if(EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()) == PolicyType.BINDER
                && StringUtils.isBlank(policyDTO.getProofOfPayment())) {
                validationErrors.add("Proof of Payment required");
            }
        }
    }

    private void validateCancellationDate(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isNotEmpty(policyDTO.getCancellationDate())) {
            DateTime effectiveDate = DateValidator.validateDateValue(policyDTO.getEffectiveDate(), "effective", validationErrors);
            DateTime expirationDate = DateValidator.validateDateValue(policyDTO.getExpirationDate(), "expiration", validationErrors);
            DateTime cancellationDate = DateValidator.validateDateValue(policyDTO.getCancellationDate(), "cancellation", validationErrors);
            if (expirationDate != null && effectiveDate != null) {
                if(cancellationDate.isBefore(effectiveDate) || cancellationDate.isAfter(expirationDate)) {
                    validationErrors.add("Cancellation Date must be between Effective Date and Expiration Date");
                }
            }
        }
    }

    private void validateEoiReceivedDateBlank(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isBlank(policyDTO.getEoiReceivedDate())) {
            validationErrors.add("EOI Received Date required");
        }
    }

    private void validateJpmMortgagePayee(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isBlank(policyDTO.getJpmMortgageePayee() )){
            validationErrors.add("JPM Listed as Mortgage Payee required");
        }
        if(!VALID_YES_NO_VALUES.contains(policyDTO.getJpmMortgageePayee() )){
            validationErrors.add("Invalid value for JPM Listed as Mortgagee Payee");
        }

    }

    private void validateJpmLenderLossPayee(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isBlank(policyDTO.getJpmLenderLossPayee())) {
            validationErrors.add("JPM Listed as Lender Loss Payee required");
        }
        if(!VALID_YES_NO_VALUES.contains(policyDTO.getJpmLenderLossPayee() )){
            validationErrors.add("Invalid value for JPM Listed as Lender Loss Payee");
        }

    }

    private void validateJpmAdditionalInsured(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isBlank(policyDTO.getJpmAdditionalInsured())) {
            validationErrors.add("JPM Listed as Additional Insured required");
        }
        if(!VALID_YES_NO_VALUES.contains(policyDTO.getJpmAdditionalInsured() )){
            validationErrors.add("Invalid value for JPM Listed as Additional Insured");
        }

    }

    private void validatePolicyWrittenAtRcv(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isBlank(policyDTO.getPolicyWrittenAtRcv())) {
            validationErrors.add("Policy written at RCV required");
        }
        if(!VALID_YES_NO_VALUES.contains(policyDTO.getPolicyWrittenAtRcv() )){
            validationErrors.add("Invalid value for Policy written at RCV");
        }

    }

    private void validateJpmLienPosition(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isBlank(policyDTO.getJpmLienPosition())) {
            validationErrors.add("JPM Lien Position required");
        }
        if(!validJPMLienPositionValues.contains(policyDTO.getJpmLienPosition() )){
            validationErrors.add("Invalid value for JPM Lien Position");
        }

    }

    private void validateProofofPayment(PolicyDTO policyDTO, List<String> validationErrors) {
        if(!StringUtils.isBlank(policyDTO.getProofOfPayment()) &&
                !(BIRRuleHelper.VALID_POP.contains(policyDTO.getProofOfPayment()) || "OTHR".equals(policyDTO.getProofOfPayment()))){
            validationErrors.add("Invalid value for Proof of Payment");
        }

    }

    private void validateInsuredNameBlank(PolicyDTO policyDTO, List<String> validationErrors) {
        if(StringUtils.isBlank(policyDTO.getInsuredName())) {
            validationErrors.add("Insured Name required");
        }
    }

    private void validateMigratedPolicyBlank(PolicyDTO policyDTO, List<String> validationErrors) {
        if(policyDTO.getMigrated() == null) {
            validationErrors.add("Migrated required");
        }
    }

    private List<String> getRequiredCoverageTypes(List<GeneralCoverageDTO> generalCoverageDTOS) {
        List<String> requiredCoverageTypes = new ArrayList<>();
        for (GeneralCoverageDTO generalCoverageDTO: generalCoverageDTOS) {
            requiredCoverageTypes.add(generalCoverageDTO.getCoverageType());
        }
        return requiredCoverageTypes;
    }

    private Map<Long, List<GeneralCoverageDTO>> getGeneralCoverages(PolicyDTO policyDTO) {
        Map<Long, List<GeneralCoverageDTO>> generalCoverageDtoMap = new HashMap<>();
        policyDTO.getCollateralCoverages().forEach(collateralCoverage ->
                generalCoverageDtoMap.put(collateralCoverage.getCollateralId(), generalRequiredCoverageSourceService.getCoveragesByCollateralId(collateralCoverage.getCollateralId()))
        );
        return generalCoverageDtoMap;
    }

    private void validatePolicyConclusionsLP(PolicyDTO policyDTO, List<String> validationErrors) {
        if (!policyDTO.getRuleConclusions().isEmpty()) {
            validationErrors.add("No rule conclusions allowed for Lender policy");
        }
    }

    private void validateValidPolicyConclusions(PolicyDTO policyDTO, List<String> validationErrors) {
       if (policyDTO.getRuleConclusions().values().stream().anyMatch(ruleConclusion ->
            BorrowerInsuranceReviewRule.getRulesByInsuranceType(InsuranceType.GENERAL)
                    .stream()
                    .noneMatch(generalInsuranceRule -> generalInsuranceRule.getKey().equals(ruleConclusion.getFieldName())))) {
           validationErrors.add("Invalid policy rule conclusions found ");
       }
        if (policyDTO.getRuleConclusions().values().stream().anyMatch(ruleConclusion ->
                StringUtils.isEmpty(ruleConclusion.getConclusion()) || BorrowerInsuranceReviewConclusion.NONE == EnumUtils.getEnum(BorrowerInsuranceReviewConclusion.class, ruleConclusion.getConclusion()) )) {
            validationErrors.add("Null/None conclusions are not allowed ");
        }
    }

    private List<PolicyDTO> getSameCoverageTypePolicies(Long collateralId, String insuranceCoverageType) {
        return policyService.getGeneralPolicies(collateralId, true).stream()
                .filter(cpDTO -> !cpDTO.getCollateralCoverages().isEmpty() &&
                        !cpDTO.getCollateralCoverages().get(0).getInsuranceCoverages().isEmpty() &&
                        insuranceCoverageType.equals(
                                cpDTO.getCollateralCoverages().get(0).getInsuranceCoverages().get(0).getInsuranceCoverageType()) &&
                        EnumUtils.getEnum(PolicyType.class, cpDTO.getPolicyType()).isLenderPlaced()
                ).sorted((o1, o2) -> {
                    DateTime o1EffectiveDate = new DateTime(DATE_FORMATTER.parse(o1.getEffectiveDate()));
                    DateTime o2EffectiveDate = new DateTime(DATE_FORMATTER.parse(o2.getEffectiveDate()));
                    if (o1EffectiveDate.isEqual(o2EffectiveDate)) {
                        return 0;
                    }
                    return o1EffectiveDate.isBefore(o2EffectiveDate) ? -1 : 1;
                }).collect(Collectors.toList());
    }

}
