package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProvidedCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository.GeneralCoverageRepository;
import com.jpmorgan.cb.wlt.config.ApplicationContextProvider;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import org.apache.commons.lang.StringUtils;

public class GeneralProvidedCoverageMapper extends AbstractProvidedCoverageMapper implements DaoMapper<ProvidedCoverage, PolicyInsuranceCoverageDTO> {


    @Override
    public PolicyInsuranceCoverageDTO toDTO(ProvidedCoverage model) {
        PolicyInsuranceCoverageDTO policyInsuranceCoverageDTO = super.toDTO(model);

        policyInsuranceCoverageDTO.setInsuranceCoverageType(model.getGeneralCoverage().getCoverageType());
        return policyInsuranceCoverageDTO;
    }

    @Override
    public boolean map(PolicyInsuranceCoverageDTO dto, ProvidedCoverage model) {
        if (!super.map(dto, model) && StringUtils
                .equals(dto.getInsuranceCoverageType(), model.getGeneralCoverage().getCoverageType())) {
            return false;
        }

        GeneralCoverageRepository generalCoverageRepository =
                ApplicationContextProvider.getContext().getBean(GeneralCoverageRepository.class);
        model.setGeneralCoverage(generalCoverageRepository.findByCoverageType(dto.getInsuranceCoverageType()));
        return true;
    }
}
