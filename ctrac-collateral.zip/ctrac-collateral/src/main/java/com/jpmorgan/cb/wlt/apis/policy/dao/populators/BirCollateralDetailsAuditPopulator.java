package com.jpmorgan.cb.wlt.apis.policy.dao.populators;

import com.jpmorgan.cb.wlt.apis.policy.dao.BirCollateralDetails;
import com.jpmorgan.cb.wlt.dao.DaoAuditDataPopulator;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

public class BirCollateralDetailsAuditPopulator implements DaoAuditDataPopulator<BirCollateralDetails,UserRequestInfo> {

    @Override
    public void populateAuditInfo(BirCollateralDetails source, UserRequestInfo userRequestInfo) {
        if(source.getPolicyAddress() != null){
            source.getPolicyAddress().setAuditInfo(userRequestInfo);
        }
    }
}
