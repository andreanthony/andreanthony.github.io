package com.jpmorgan.cb.wlt.apis.collateral.types.services.impl;

import com.jpmorgan.cb.wlt.apis.ApiDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralStatus;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.CollateralRepository;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.apis.collateral.types.CollateralType;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.BusinessAssets;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.RealEstate;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateCollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.services.CollateralCreationService;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanService;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanStatus;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;

@Service
public class CollateralCreationServiceImpl implements CollateralCreationService {

    private CollateralRepository collateralRepository;
    private CollateralDetailsService collateralRetrievalService;
    private CollateralSectionService collateralSectionService;
    private LoanService loanService;
    private ModelMapper modelMapper;

    @Autowired
    public CollateralCreationServiceImpl(CollateralRepository collateralRepository, CollateralDetailsService collateralRetrievalService,
                                         CollateralSectionService collateralSectionService,
                                         LoanService loanService, ModelMapper modelMapper) {
        assert(collateralRepository != null);
        this.collateralRepository = collateralRepository;
        assert(collateralRetrievalService != null);
        this.collateralRetrievalService = collateralRetrievalService;
        assert(collateralSectionService != null);
        this.collateralSectionService = collateralSectionService;
        assert(modelMapper != null);
        this.modelMapper = modelMapper;
        assert(loanService != null);
        this.loanService = loanService;
    }

    @Override
    public List<ApiDTO> getCollateralTypeAPIs() {
        List<ApiDTO> apiDTOs = new ArrayList<>();
        for (CollateralType collateralType : CollateralType.values()) {
            ApiDTO apiDTO = new ApiDTO();
            apiDTO.setApi(collateralType.getApi());
            apiDTO.setDescription(collateralType.getDescription());
            apiDTOs.add(apiDTO);
        }
        return apiDTOs;
    }

    @Override
    public CollateralDTO createCollateral(CreateCollateralDTO createCollateralDTO, CollateralType collateralType, UserRequestInfo userRequestInfo) {
        Collateral collateral = saveCollateral(createCollateralDTO, collateralType);
        if(collateral!=null) {
            LoanDTO loanDTO = populateLoanDTO(createCollateralDTO, collateral.getRid());
            loanService.createLoan(loanDTO, userRequestInfo);
            collateralSectionService.initializeCollateralSections(collateral.getRid(), userRequestInfo);
            // TODO: audit trail - create collateral
            return collateralRetrievalService.getCollateralDetails(collateral.getRid());
        }
        return null;
    }

    private Collateral saveCollateral(CreateCollateralDTO createCollateralDTO, CollateralType collateralType) {
        if(collateralType==CollateralType.REAL_ESTATE) {
            RealEstate collateral=null;
            collateral = modelMapper.map(createCollateralDTO, RealEstate.class);
            collateral.setCollateralTypeCode(collateralType);
            collateral.setCollateralStatus(CollateralStatus.DRAFT.getName());
            return collateralRepository.save(collateral);
        }
        if(collateralType==CollateralType.BUSINESS_ASSETS){
            BusinessAssets collateral = null;
            collateral = modelMapper.map(createCollateralDTO, BusinessAssets.class);
            collateral.setCollateralTypeCode(collateralType);
            collateral.setCollateralStatus(CollateralStatus.DRAFT.getName());
            return collateralRepository.save(collateral);
        }
        return null;
    }

    protected LoanDTO populateLoanDTO(CreateCollateralDTO createCollateralDTO,Long collateralRid) {
        LoanDTO loanDTO = new LoanDTO();
        loanDTO.setCollateralId(collateralRid);
        loanDTO.setLineOfBusiness(createCollateralDTO.getLineOfBusiness());
        loanDTO.setPrimaryFlag(true);
        loanDTO.setStatus(LoanStatus.PENDING_VERIFICATION.name());
        return loanDTO;
    }

}
