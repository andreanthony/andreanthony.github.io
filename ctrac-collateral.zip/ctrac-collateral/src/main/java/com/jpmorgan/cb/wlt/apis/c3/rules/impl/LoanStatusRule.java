package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3PolicyCancellationUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

public class LoanStatusRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(LoanStatusRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        // returns null if there is an active loan
        Date latestLoanPaidOffDate = c3RequestDTO.getLatestLoanPaidOffDate();
        if (latestLoanPaidOffDate != null) {
            c3ResponseDTO.addPoliciesToCancel(C3PolicyCancellationUtil.cancelLpPolicies(
                    c3RequestDTO.getLpPolicies(), latestLoanPaidOffDate, CancellationReason.LOAN_PAID_OFF));
            c3ResponseDTO.setComplete(true);
        }
        logger.debug("LoanStatusRule - Number of policies to be cancelled : {} ",c3ResponseDTO.getPoliciesToCancel().size());
    }
}
