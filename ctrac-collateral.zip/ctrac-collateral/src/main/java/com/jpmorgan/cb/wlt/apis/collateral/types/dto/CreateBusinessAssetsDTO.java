package com.jpmorgan.cb.wlt.apis.collateral.types.dto;

import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateRealEstateDTO;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;

public class CreateBusinessAssetsDTO extends CreateRealEstateDTO {

    private String description;

    @ApiModelProperty(required = true)

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public void setDescription(String description) {
        this.description = description;
    }
}