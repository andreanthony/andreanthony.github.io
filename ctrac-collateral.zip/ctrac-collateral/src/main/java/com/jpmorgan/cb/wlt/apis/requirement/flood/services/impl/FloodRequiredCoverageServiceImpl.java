package com.jpmorgan.cb.wlt.apis.requirement.flood.services.impl;

import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.RequiredCoverageView;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.repository.RequiredCoverageViewRepository;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dto.FloodRequiredCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.flood.services.FloodRequiredCoverageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FloodRequiredCoverageServiceImpl implements FloodRequiredCoverageService {

    private RequiredCoverageViewRepository requiredCoverageViewRepository;

    @Autowired
    public FloodRequiredCoverageServiceImpl(RequiredCoverageViewRepository requiredCoverageViewRepository) {
        assert(requiredCoverageViewRepository != null);
        this.requiredCoverageViewRepository = requiredCoverageViewRepository;
    }

    @Override
    public List<FloodRequiredCoverageDTO> getByCollateralId(Long collateralId) {
        List<RequiredCoverageView> requiredCoverageViews = requiredCoverageViewRepository.
                findByCollateralRid(collateralId);
        List<FloodRequiredCoverageDTO> floodRequiredCoverages = new ArrayList<>();
        requiredCoverageViews.stream().forEach(
                requiredCoverageView -> {
                    floodRequiredCoverages.add(requiredCoverageView.toPrimaryFloodRequiredCoverageDTO());
                    floodRequiredCoverages.add(requiredCoverageView.toExcessFloodRequiredCoverageDTO());
                });
        return floodRequiredCoverages;
    }
}
