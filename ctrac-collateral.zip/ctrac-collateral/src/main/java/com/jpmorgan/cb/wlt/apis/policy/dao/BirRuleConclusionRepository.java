package com.jpmorgan.cb.wlt.apis.policy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BirRuleConclusionRepository extends JpaRepository<BIRRuleConclusion, Long> {
    List<BIRRuleConclusion> findByProofOfCoverageRid(Long proofOfCoverageRid);
}
