package com.jpmorgan.cb.wlt.apis.loan;

import java.math.BigDecimal;

public class UpbDTO {

	private Long rid;

	private BigDecimal upb;

	private String upbDate;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public BigDecimal getUpb() {
		return upb;
	}

	public void setUpb(BigDecimal upb) {
		this.upb = upb;
	}

	public String getUpbDate() {
		return upbDate;
	}

	public void setUpbDate(String upbDate) {
		this.upbDate = upbDate;
	}
}
