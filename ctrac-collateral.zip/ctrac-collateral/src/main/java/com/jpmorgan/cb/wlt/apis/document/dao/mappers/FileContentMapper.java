package com.jpmorgan.cb.wlt.apis.document.dao.mappers;

import com.jpmorgan.cb.wlt.apis.document.dao.FileContent;
import com.jpmorgan.cb.wlt.apis.document.dtos.FileContentDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

public class FileContentMapper implements DaoMapper<FileContent, FileContentDTO> {

    @Override
    public FileContentDTO toDTO(FileContent model) {
        FileContentDTO dto = new FileContentDTO();
        dto.setFileContent(model.getFileContent());
        dto.setRid(model.getRid());
        return dto;
    }

    @Override
    public boolean map(FileContentDTO dto, FileContent model) {
        if (dto.equals(toDTO(model))) {
            return false;
        }
        model.setFileContent(dto.getFileContent());
        model.setRid(dto.getRid());
        return true;
    }
}
