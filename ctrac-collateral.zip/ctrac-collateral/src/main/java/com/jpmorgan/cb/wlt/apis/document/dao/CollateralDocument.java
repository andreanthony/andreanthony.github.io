package com.jpmorgan.cb.wlt.apis.document.dao;

import com.jpmorgan.cb.wlt.apis.document.dao.mappers.CollateralDocumentMapper;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentDTO;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "TLCP_COLLATERAL_DOCUMENTS")
public class CollateralDocument extends AuditableEntity implements Serializable {

	private static final long serialVersionUID = 3953244370852597669L;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "collateralActivityDocSeqGenerator")
	@TableGenerator(name = "collateralActivityDocSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_COLLATERAL_DOCUMENTS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "FILE_NAME")
	private String fileName;

	@Column(name = "FILE_NAME_WITH_EXT")
	private String fileNameWithExt;

	@Column(name = "DOC_IDENTIFIER")
	private String docIdentifier;

	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;

	@Column(name = "DOCUMENT_DATE")
	private Date documentDate;

	@OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@JoinColumn(name = "FILE_CONTENT_RID")
	private FileContent fileContent;

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileNameWithExt() {
		return fileNameWithExt;
	}

	public void setFileNameWithExt(String fileNameWithExt) {
		this.fileNameWithExt = fileNameWithExt;
	}

	public String getDocIdentifier() {
		return docIdentifier;
	}

	public void setDocIdentifier(String docIdentifier) {
		this.docIdentifier = docIdentifier;
	}

	public Date getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public FileContent getFileContent() {
		return fileContent;
	}

	public void setFileContent(FileContent fileContent) {
		this.fileContent = fileContent;
	}

	public CollateralDocumentDTO toCollateralDocumentDTO() {
		return new CollateralDocumentMapper().toDTO(this);
	}

	public boolean map(CollateralDocumentDTO collateralDocumentDTO) {
		return new CollateralDocumentMapper().map(collateralDocumentDTO, this);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;

		if (o == null || getClass() != o.getClass()) return false;

		CollateralDocument that = (CollateralDocument) o;

		return new EqualsBuilder()
				.append(rid, that.rid)
				.append(fileName, that.fileName)
				.append(fileNameWithExt, that.fileNameWithExt)
				.append(docIdentifier, that.docIdentifier)
				.append(collateralRid, that.collateralRid)
				.append(documentDate, that.documentDate)
				.append(fileContent, that.fileContent)
				.isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 37)
				.append(rid)
				.append(fileName)
				.append(fileNameWithExt)
				.append(docIdentifier)
				.append(collateralRid)
				.append(documentDate)
				.append(fileContent)
				.toHashCode();
	}

}
