package com.jpmorgan.cb.wlt.apis.document.dao.repository;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CollateralDocumentRepository extends JpaRepository<CollateralDocument, Long> {


}
