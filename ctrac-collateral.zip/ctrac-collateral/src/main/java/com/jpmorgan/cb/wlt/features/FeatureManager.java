package com.jpmorgan.cb.wlt.features;

import com.jpmorgan.cb.wlt.dao.FeatureSwitch;
import com.jpmorgan.cb.wlt.dao.FeatureSwitchRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
public class FeatureManager {

    private static final Logger LOG = LoggerFactory.getLogger(FeatureManager.class);

    private List<FeatureSwitch> featureSwitches = null;

    @Autowired
    FeatureManager(FeatureSwitchRepository featureSwitchRepository){
        try {
            featureSwitches = featureSwitchRepository.findAll();
        }catch(Exception ex){
            LOG.error("Error occurred while loading the feature switches from the database",ex);
        }
    }

    public boolean isActive(final FeatureBook feature){
        if(feature == null){
            //Unknown feature
            return false;
        }
        if(CollectionUtils.isNotEmpty(featureSwitches)){
            FeatureSwitch featureSwitch = (FeatureSwitch) CollectionUtils.find(featureSwitches, new Predicate() {
                @Override
                public boolean evaluate(Object o) {
                    FeatureSwitch featureSwitchObject = (FeatureSwitch)o;
                    return featureSwitchObject.getFeatureName().equals(feature.name());
                }
            });
            if(featureSwitch != null){
                LOG.debug("Feature {} found and has status ", feature.name(), featureSwitch.isEnabled());
                return featureSwitch.isEnabled();
            }
        }
        LOG.debug("Feature {} was not found in DB so is enabled by default", feature.name());
        return true;
    }

    public boolean isActive(String feature){
       return isActive(FeatureBook.valueOf(feature));
    }




}
