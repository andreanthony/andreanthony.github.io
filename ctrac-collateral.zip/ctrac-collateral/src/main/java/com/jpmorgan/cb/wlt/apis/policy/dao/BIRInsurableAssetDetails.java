package com.jpmorgan.cb.wlt.apis.policy.dao;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_BIR_INS_ASSET_DETAILS")
public class BIRInsurableAssetDetails {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "birInsAssetDetailsSeqGenerator")
    @TableGenerator(name = "birInsAssetDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BIR_INS_ASSET_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "BIR_COLLATERAL_DETAILS_RID")
    private Long birCollateralDetailsRid;

    @Column(name = "INSURABLE_ASSET_RID")
    private Long insurableAssetSortOrder;

    @Column(name = "POLICY_PROPERTY_TYPE")
    private String propertyType;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public Long getBirCollateralDetailsRid() {
        return birCollateralDetailsRid;
    }

    public void setBirCollateralDetailsRid(Long birCollateralDetailsRid) {
        this.birCollateralDetailsRid = birCollateralDetailsRid;
    }

    public Long getInsurableAssetSortOrder() {
        return insurableAssetSortOrder;
    }

    public void setInsurableAssetSortOrder(Long insurableAssetSortOrder) {
        this.insurableAssetSortOrder = insurableAssetSortOrder;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

}