package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.enums.C3AlertEmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AlertEmailEventDTO;

import java.io.Serializable;

public class C3AlertEmail implements Serializable {
    private static final long serialVersionUID = -1;
    private C3AlertEmailTemplate alertTemplate;
    private C3CalculatedCoverageDate calculatedCoverageDate;
    private Long lpPolicyId;
    private Long collateralRid;
    private C3RequiredCoverage requiredCoverage;

    public C3AlertEmailTemplate getAlertTemplate() {
        return alertTemplate;
    }

    public void setAlertTemplate(C3AlertEmailTemplate alertTemplate) {
        this.alertTemplate = alertTemplate;
    }

    public C3CalculatedCoverageDate getCalculatedCoverageDate() {
        return calculatedCoverageDate;
    }

    public void setCalculatedCoverageDate(C3CalculatedCoverageDate calculatedCoverageDate) {
        this.calculatedCoverageDate = calculatedCoverageDate;
    }

    public Long getLpPolicyId() {
        return lpPolicyId;
    }

    public void setLpPolicyId(Long lpPolicyId) {
        this.lpPolicyId = lpPolicyId;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public void setRequiredCoverage(C3RequiredCoverage requiredCoverage) {
        this.requiredCoverage = requiredCoverage;
    }

    public C3RequiredCoverage getRequiredCoverage() {
        return requiredCoverage;
    }

    @Override
    public String toString() {
        if(alertTemplate!=null) {
            return alertTemplate.name();
        }else {return "";}
    }

    public AlertEmailEventDTO toAlertTemplateDTO(){
        AlertEmailEventDTO dto = new AlertEmailEventDTO();
        dto.setCollateralRid(this.collateralRid);
        dto.setProofOfCoverageRid(this.lpPolicyId);
        dto.setAlertTemplate(this.alertTemplate.name());
        dto.setTargetCoverageDate(this.calculatedCoverageDate.getCoverageDate());
        return dto;
    }
}
