package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3RuleFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class C3RuleFactoryImpl implements C3RuleFactory {
    @Override
    public List<C3Rule> getC3Rules() {
        List<C3Rule> c3Rules = new ArrayList<>();
        // collateral level rules
        c3Rules.add(new CollateralStatusRule());
        c3Rules.add(new BIRWorkflowRule());
        c3Rules.add(new LoanStatusRule());
        c3Rules.add(new FloodZoneRule());
        c3Rules.add(new ExternallyAgentedRule());
        // building a list of coverage dates
        c3Rules.add(new FloodCoverageDateRule());
        c3Rules.add(new FloodHoldsRule());
        c3Rules.add(new GeneralCoverageDateRule());
        c3Rules.add(new AlertLenderPlaceRestrictionRule());
        // coverage amount calculation
        c3Rules.add(new FloodLenderPlaceCalculationRule());
        c3Rules.add(new GeneralLenderPlaceCalculationRule());
        c3Rules.add(new LenderPlaceLapseRule());
        // GapOnPolicyExpirationRule must run before LenderPlaceMatchingRule
        c3Rules.add(new GapOnPolicyExpirationRule());
        c3Rules.add(new LenderPlaceMatchingRule());
        c3Rules.add(new AlertFloodMultipleExcessPoliciesRule());
        return c3Rules;
    }
}
