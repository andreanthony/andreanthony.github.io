package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "TLCP_BLANKET_COVERAGE")
public class BlanketCoverage extends AuditableEntity {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "blanketCoverageSeqGenerator")
    @TableGenerator(name = "blanketCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BLANKET_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "BLANKET_COVERAGE_TYPE")
    private String blanketCoverageType;

    @Column(name = "BLANKET_BUILDING_AMOUNT")
    private BigDecimal blanketBuildingAmount;

    @Column(name = "BLANKET_CONTENT_AMOUNT")
    private BigDecimal blanketContentAmount;

    @Column(name = "BLANKET_COMBINED_AMOUNT")
    private BigDecimal blanketCombinedAmount;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getBlanketCoverageType() {
        return blanketCoverageType;
    }

    public void setBlanketCoverageType(String blanketCoverageType) {
        this.blanketCoverageType = blanketCoverageType;
    }

    public BigDecimal getBlanketBuildingAmount() {
        return blanketBuildingAmount;
    }

    public void setBlanketBuildingAmount(BigDecimal blanketBuildingAmount) {
        this.blanketBuildingAmount = blanketBuildingAmount;
    }

    public BigDecimal getBlanketContentAmount() {
        return blanketContentAmount;
    }

    public void setBlanketContentAmount(BigDecimal blanketContentAmount) {
        this.blanketContentAmount = blanketContentAmount;
    }

    public BigDecimal getBlanketCombinedAmount() {
        return blanketCombinedAmount;
    }

    public void setBlanketCombinedAmount(BigDecimal blanketCombinedAmount) {
        this.blanketCombinedAmount = blanketCombinedAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        BlanketCoverage that = (BlanketCoverage) o;

        return new EqualsBuilder()
                .append(rid, that.rid)
                .append(blanketCoverageType, that.blanketCoverageType)
                .append(blanketBuildingAmount, that.blanketBuildingAmount)
                .append(blanketContentAmount, that.blanketContentAmount)
                .append(blanketCombinedAmount, that.blanketCombinedAmount)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(blanketCoverageType)
                .append(blanketBuildingAmount)
                .append(blanketContentAmount)
                .append(blanketCombinedAmount)
                .toHashCode();
    }
}
