package com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository;

import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralRequiredCoverageSource;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GeneralRequiredCoverageSourceRepository extends JpaRepository<GeneralRequiredCoverageSource, Long>  {

    List<GeneralRequiredCoverageSource>  findByCollateralRidAndStatus(Long collateralRid, String taskStatus);
    List<GeneralRequiredCoverageSource> findByCollateralRid(Long requiredCoverageRid);
}
