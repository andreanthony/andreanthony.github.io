package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3PolicyCancellationUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CollateralStatusRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(CollateralStatusRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        if (c3RequestDTO.isReleased()) {
            c3ResponseDTO.addPoliciesToCancel(C3PolicyCancellationUtil.cancelLpPolicies(
                    c3RequestDTO.getLpPolicies(),
                    c3RequestDTO.getCollateralReleaseDate(),
                    CancellationReason.COLLATERAL_RELEASED));
            c3ResponseDTO.setComplete(true);
        }
        logger.debug("CollateralStatusRule - Number of policies to be cancelled : {} ",c3ResponseDTO.getPoliciesToCancel().size());
    }
}
