package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.services.C3RequestPopulationService;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.collateral.owner.services.CollateralOwnerService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionStatus;
import com.jpmorgan.cb.wlt.apis.floodDetermination.dao.FloodDetermination;
import com.jpmorgan.cb.wlt.apis.floodDetermination.services.FloodDeterminationService;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.services.impl.LoanServiceImpl;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyCollateralDetailsDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyService;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.HoldHistoryView;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.repository.HoldHistoryViewRepository;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dto.FloodRequiredCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.flood.services.FloodRequiredCoverageService;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageRequirementDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageSourceDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralCoverageService;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.impl.GeneralRequiredCoverageSourceServiceImpl;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ExceptionLevel;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class C3RequestPopulationServiceImpl implements C3RequestPopulationService {

    private CollateralDetailsService collateralDetailsService;
    private ReferenceDateService referenceDateService;
    private GeneralRequiredCoverageSourceServiceImpl generalRequiredCoverageSourceService;
    private PolicyService policyService;
    private LoanServiceImpl loanService;
    private FloodRequiredCoverageService floodRequiredCoverageService;
    private GeneralCoverageService generalCoverageService;
    private FloodDeterminationService floodDeterminationService;
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    private CollateralOwnerService collateralOwnerService;
    private HoldHistoryViewRepository holdHistoryViewRepository;

    @Autowired
    public C3RequestPopulationServiceImpl(CollateralDetailsService collateralDetailsService,
                                          ReferenceDateService referenceDateService,
                                          GeneralRequiredCoverageSourceServiceImpl generalRequiredCoverageSourceService,
                                          PolicyService policyService, LoanServiceImpl loanService,
                                          FloodRequiredCoverageService floodRequiredCoverageService,
                                          GeneralCoverageService generalCoverageService,
                                          FloodDeterminationService floodDeterminationService,
                                          CollateralOwnerService collateralOwnerService,
                                          HoldHistoryViewRepository holdHistoryViewRepository) {
        assert (collateralDetailsService != null);
        this.collateralDetailsService = collateralDetailsService;
        assert (referenceDateService != null);
        this.referenceDateService = referenceDateService;
        assert (generalRequiredCoverageSourceService != null);
        this.generalRequiredCoverageSourceService = generalRequiredCoverageSourceService;
        assert (policyService != null);
        this.policyService = policyService;
        assert (loanService != null);
        this.loanService = loanService;
        assert (floodRequiredCoverageService != null);
        this.floodRequiredCoverageService = floodRequiredCoverageService;
        assert (generalCoverageService != null);
        this.generalCoverageService = generalCoverageService;
        assert (floodDeterminationService != null);
        this.floodDeterminationService = floodDeterminationService;
        assert (collateralOwnerService != null);
        this.collateralOwnerService = collateralOwnerService;
        assert (holdHistoryViewRepository != null);
        this.holdHistoryViewRepository = holdHistoryViewRepository;

    }

    @Override
    public void populate(Long collateralId, C3RequestDTO c3RequestDTO) {
        CollateralDTO collateralDTO = collateralDetailsService.getCollateralDetails(collateralId);
        if(collateralDTO == null){
            throw new CtracException("Collateral doesn't exists ", ExceptionLevel.ERROR);
        }
        populate(collateralDTO, c3RequestDTO);
    }

    @Override
    public C3RequestDTO build(C3RequestEventDTO c3RequestEventDTO) {
        C3RequestDTO c3RequestDTO = new C3RequestDTO();
        c3RequestDTO.setInsuranceType(getInsuranceType(c3RequestEventDTO));
        populate(c3RequestEventDTO.getCollateralId(), c3RequestDTO);
        c3RequestDTO.setAddedAndRemovedCoveragesOnly(c3RequestEventDTO.isAddedAndRemovedCoverages());
        c3RequestDTO.setOverrideFloodCoverageDate(getOverrideFloodCoverageDate(c3RequestEventDTO));
        c3RequestDTO.setHoldsVerifiedWithLpiDate(c3RequestEventDTO.getHoldsVerifiedWithLpiDate());
        c3RequestDTO.setEvaluateGap(c3RequestEventDTO.isEvaluateGap());
        c3RequestDTO.setPerformedBy(c3RequestEventDTO.getPerformedBy());
        return c3RequestDTO;
    }

    private String getInsuranceType(C3RequestEventDTO c3RequestEventDTO) {
        CtracEventType eventType = CtracEventType.fromDisplayValue(c3RequestEventDTO.getEventType());
        if (eventType == CtracEventType.COLLATERAL_RELEASED || eventType == CtracEventType.LAST_LOAN_PAID_OFF) {
            return null;
        }
        if (c3RequestEventDTO.isFloodRemapZoneIn() || eventType == CtracEventType.FLOOD_REMAP) {
            return InsuranceType.FLOOD.name();
        }
        return c3RequestEventDTO.getInsuranceType();
    }

    private String getOverrideFloodCoverageDate(C3RequestEventDTO c3RequestEventDTO) {
        return c3RequestEventDTO.isFloodRemapZoneIn()? getFloodRemapZoneInDate() : null;
    }

    private String getFloodRemapZoneInDate() {
        Date currentReferenceDate = referenceDateService.getCurrentReferenceDate();
        Date nextBusinessDay = referenceDateService.addBusinessDays(1, currentReferenceDate);
        return DATE_FORMATTER.print(
                referenceDateService.addCalendarDays(45, nextBusinessDay));
    }

    private void populate(CollateralDTO collateralDTO, C3RequestDTO c3RequestDTO) {
        if (collateralDTO != null) {
            c3RequestDTO.setCollateralRid(collateralDTO.getRid());
            c3RequestDTO.setCurrentReferenceDate(
                    DATE_FORMATTER.print(referenceDateService.getCurrentReferenceDate()));
            c3RequestDTO.setCollateralStatus(collateralDTO.getCollateralStatus());
            c3RequestDTO.setCollateralReleaseDate(
                    DATE_FORMATTER.print(collateralDTO.getReleaseDate()));
            c3RequestDTO.setCollateralSubType(collateralDTO.getCollateralSubTypeCode());
            populateRequiredCoverages(collateralDTO, c3RequestDTO);
            populatePolicies(c3RequestDTO);
            populateFloodDetermination(collateralDTO, c3RequestDTO);
            c3RequestDTO.setInsuredName(collateralOwnerService.getUniqueMortgagorAndBorrowerNames(collateralDTO.getRid(),"|"));
            populateLoans(collateralDTO, c3RequestDTO.getLoans());
        }
    }

    private void populateRequiredCoverages(CollateralDTO collateralDTO, C3RequestDTO c3RequestDTO) {
        if (c3RequestDTO.isInsuranceTypeRequested(InsuranceType.FLOOD)) {
            List<HoldHistoryView> holdHistoryViewList = holdHistoryViewRepository.findByCollateralRid(collateralDTO.getRid());
            c3RequestDTO.setHasFloodHolds(!holdHistoryViewList.isEmpty());
            c3RequestDTO.addRequiredCoverages(getFloodRequiredCoverages(collateralDTO, holdHistoryViewList));
        }
        if (c3RequestDTO.isInsuranceTypeRequested(InsuranceType.GENERAL)) {
            c3RequestDTO.addRequiredCoverages(getGeneralRequiredCoverages(collateralDTO));
        }
    }

    protected List<C3RequiredCoverage> getFloodRequiredCoverages(CollateralDTO collateralDTO, List<HoldHistoryView> holdHistoryViewList) {
        List<FloodRequiredCoverageDTO> floodRequiredCoverageDTOS = floodRequiredCoverageService.getByCollateralId(collateralDTO.getRid());
        List<C3RequiredCoverage> verifiedRequiredCoverages = mapToC3RequiredCoverages(floodRequiredCoverageDTOS, VerificationStatus.VERIFIED, holdHistoryViewList);
        List<C3RequiredCoverage> inactiveRequiredCoverages = mapToC3RequiredCoverages(floodRequiredCoverageDTOS, VerificationStatus.INACTIVE, null);
        setNewlyAdded(inactiveRequiredCoverages, verifiedRequiredCoverages);
        return verifiedRequiredCoverages;
    }

    private List<C3RequiredCoverage> mapToC3RequiredCoverages(List<FloodRequiredCoverageDTO> floodRequiredCoverageDTOS, VerificationStatus verificationStatus,
                                                              List<HoldHistoryView> holdHistoryViewList) {
        return floodRequiredCoverageDTOS
                    .stream()
                    .filter(floodRequiredCoverageDTO -> verificationStatus.name().equals(floodRequiredCoverageDTO.getStatus()))
                    .map(floodRequiredCoverageDTO -> buildC3RequiredCoverageDTO(floodRequiredCoverageDTO, holdHistoryViewList))
                    .collect(Collectors.toList());
    }

    void setNewlyAdded(List<C3RequiredCoverage> inactiveRequiredCoverages, List<C3RequiredCoverage> requiredCoverages) {
        Date prevDocumentDate = getPrevDocumentDate(inactiveRequiredCoverages);
        if (prevDocumentDate != null) {
            List<C3RequiredCoverage> prevFloodRequiredCoverages = inactiveRequiredCoverages
                    .stream()
                    .filter(prevRequiredCoverage -> prevDocumentDate.equals(prevRequiredCoverage.getDocumentDate_()))
                    .collect(Collectors.toList());
            requiredCoverages
                    .stream()
                    .forEach(floodRequiredCoverage -> {
                            boolean previouslyRequired = prevFloodRequiredCoverages
                                    .stream()
                                    .anyMatch(prevCoverage -> !prevCoverage.isDescoped() && prevCoverage.isMatching(
                                            floodRequiredCoverage.getCoverageType(), floodRequiredCoverage.getInsurableAssetId()));
                            floodRequiredCoverage.setNewlyAdded(!previouslyRequired);
                    });
        }
    }

    protected List<C3RequiredCoverage> getGeneralRequiredCoverages(CollateralDTO collateralDTO) {
        GeneralCoverageRequirementDTO requirementDTO = generalRequiredCoverageSourceService.getByCollateralId(collateralDTO.getRid());
        GeneralRequiredCoverageSourceDTO verifiedRequirementSource = requirementDTO.getVerifiedRequirementSource();
        if (verifiedRequirementSource != null) {
            List<GeneralCoverageDTO> generalCoverages = generalCoverageService.getGeneralCoverageTypes();
            List<GeneralRequiredCoverageDTO> verifiedRequiredCoverages = verifiedRequirementSource.getGeneralRequiredCoverages();

            List<C3RequiredCoverage> requiredCoverages = mapToC3RequiredCoverages(generalCoverages, verifiedRequiredCoverages);

            List<GeneralRequiredCoverageDTO> inactiveCoverages =
                requirementDTO.getInactiveRequirementSources()
                        .stream()
                        .flatMap(sourceDTO -> sourceDTO.getGeneralRequiredCoverages().stream())
                .collect(Collectors.toList());

            setNewlyAdded(mapToC3RequiredCoverages(generalCoverages, inactiveCoverages), requiredCoverages);
            return requiredCoverages;
        }
        return new ArrayList<>();
    }

    private List<C3RequiredCoverage> mapToC3RequiredCoverages(List<GeneralCoverageDTO> generalCoverages, List<GeneralRequiredCoverageDTO> verifiedRequiredCoverages) {
        return verifiedRequiredCoverages
                        .stream()
                        .map(generalRequiredCoverageDTO -> buildC3RequiredCoverageDTO(generalRequiredCoverageDTO, generalCoverages))
                .collect(Collectors.toList());
    }

    private Date getPrevDocumentDate(List<C3RequiredCoverage> requiredCoverageDTOS) {
        return CollectionUtils.isEmpty(requiredCoverageDTOS)? null:
                requiredCoverageDTOS.stream()
                        .map(C3RequiredCoverage::getDocumentDate_)
                        .max(Date::compareTo).orElse(null);
    }

    private void populateLoans(CollateralDTO collateralDTO, List<C3Loan> loans) {
       loanService.getLoans(collateralDTO.getRid())
               .forEach(loanDTO -> loans.add(buildC3LoanDTO(loanDTO))
       );
    }

    C3Loan buildC3LoanDTO(LoanDTO loanDTO) {
        C3Loan c3Loan = new C3Loan();
        c3Loan.setLoanType(loanDTO.getLoanType());
        c3Loan.setReleasedDate(DATE_FORMATTER.print(loanDTO.getReleaseDate()));
        c3Loan.setStatus(loanDTO.getStatus());
        return c3Loan;
    }

    C3RequiredCoverage buildC3RequiredCoverageDTO(GeneralRequiredCoverageDTO generalRequiredCoverageDTO, List<GeneralCoverageDTO> generalCoverages) {
        C3RequiredCoverage c3RequiredCoverage = new C3RequiredCoverage();

        c3RequiredCoverage.setInsuranceType(InsuranceType.GENERAL.name());
        c3RequiredCoverage.setCoverageAmount(generalRequiredCoverageDTO.getCoverageAmount());
        c3RequiredCoverage.setCoverageType(getGeneralCoverageType(generalRequiredCoverageDTO.getGeneralCoverageRid(), generalCoverages));
        // TODO: populate when general coverage is descoped or newly added
        // c3RequiredCoverage.setCancellationEffectiveDate();
        // c3RequiredCoverage.setDescoped();
        // c3RequiredCoverage.setNewlyAdded();

        return c3RequiredCoverage;
    }

    protected String getGeneralCoverageType(Long generalCoverageRid, List<GeneralCoverageDTO> generalCoverages) {
        Optional<GeneralCoverageDTO> matchedGeneralCoverageDTO = generalCoverages.stream()
                .filter(generalCoverageDTO -> generalCoverageRid.equals(generalCoverageDTO.getRid()))
                .findFirst();
        return matchedGeneralCoverageDTO.isPresent() ? matchedGeneralCoverageDTO.get().getCoverageType() : null;
    }

    C3RequiredCoverage buildC3RequiredCoverageDTO(FloodRequiredCoverageDTO floodRequiredCoverageDTO, List<HoldHistoryView> holdHistoryViewList) {
        C3RequiredCoverage c3RequiredCoverage = new C3RequiredCoverage();
        c3RequiredCoverage.setInsuranceType(InsuranceType.FLOOD.name());
        c3RequiredCoverage.setCoverageAmount(floodRequiredCoverageDTO.getCoverageAmount());
        c3RequiredCoverage.setCoverageType(floodRequiredCoverageDTO.getCoverageType());
        c3RequiredCoverage.setDescoped(floodRequiredCoverageDTO.isDescoped());
        c3RequiredCoverage.setDocumentDate(floodRequiredCoverageDTO.getDocumentDate());
        c3RequiredCoverage.setInsurableAssetId(floodRequiredCoverageDTO.getInsurableAssetId());
        c3RequiredCoverage.setInsurableAssetType(floodRequiredCoverageDTO.getInsurableAssetType());
        c3RequiredCoverage.setPropertyType(floodRequiredCoverageDTO.getPropertyType());
        if (CollectionUtils.isNotEmpty(holdHistoryViewList) && floodRequiredCoverageDTO.getHoldRid() != null) {
            c3RequiredCoverage.setHold(getMatchingC3Hold(holdHistoryViewList, floodRequiredCoverageDTO.getHoldRid()));
        }
        return c3RequiredCoverage;
    }

    protected C3Hold c3HoldFromHoldHistoryView(HoldHistoryView holdHistoryView) {
        C3Hold c3Hold = new C3Hold();
        // the date when the entire hold started
        c3Hold.setHoldStartDate(holdHistoryView.getParentStartDate());
        c3Hold.setHoldLpiDate(holdHistoryView.getHoldEndDate());
        c3Hold.setRid(holdHistoryView.getHoldRid());
        c3Hold.setNewHold(holdHistoryView.getParentHold() == null &&
                holdHistoryView.getStartDate() != null && holdHistoryView.getLpiDate() == null);
        return c3Hold;
    }

    protected C3Hold getMatchingC3Hold(List<HoldHistoryView> holdHistoryViewList, Long holdRid) {
        return holdHistoryViewList.stream()
                .filter(holdHistoryView -> holdHistoryView.getHoldRid() == holdRid)
                .map(this::c3HoldFromHoldHistoryView)
                .findFirst()
                .orElse(null);
    }

    protected void populatePolicies(C3RequestDTO c3RequestDTO) {
        Long collateralRid = c3RequestDTO.getCollateralRid();
        List<PolicyDTO> policies = policyService.getPoliciesForC3(collateralRid);
        if (c3RequestDTO.isInsuranceTypeRequested(InsuranceType.FLOOD)) {
            c3RequestDTO.addBorrowerPolicies(getBorrowerPolicies(policies, InsuranceType.FLOOD, collateralRid));
            c3RequestDTO.addLPPolicies(getLenderPlacedPolicies(policies, InsuranceType.FLOOD, collateralRid));
        }
        if (c3RequestDTO.isInsuranceTypeRequested(InsuranceType.GENERAL)) {
            c3RequestDTO.addBorrowerPolicies(getBorrowerPolicies(policies, InsuranceType.GENERAL, collateralRid));
            c3RequestDTO.addLPPolicies(getLenderPlacedPolicies(policies, InsuranceType.GENERAL, collateralRid));
        }
    }

    private List<C3Policy> getBorrowerPolicies(List<PolicyDTO> policies, InsuranceType insuranceType, Long collateralRid) {
       return policies
                .stream()
                .filter(policyDTO -> !PolicyType.isLenderPlace(policyDTO.getPolicyType()) &&
                        insuranceType == EnumUtils.getEnum(InsuranceType.class, policyDTO.getInsuranceType()))
                .map(policyDto -> c3PolicyFromPolicyDTO(policyDto, collateralRid)).collect(Collectors.toList());
    }

    private List<C3Policy> getLenderPlacedPolicies(List<PolicyDTO> policies, InsuranceType insuranceType, Long collateralRid) {
            return policies
                .stream()
                .filter(policyDTO -> PolicyType.isLenderPlace(policyDTO.getPolicyType()) &&
                        insuranceType == EnumUtils.getEnum(InsuranceType.class, policyDTO.getInsuranceType()))
                .map(policyDto -> c3PolicyFromPolicyDTO(policyDto, collateralRid)).collect(Collectors.toList());
    }

    @Override
    public C3Policy populatePolicy(Long policyId) {
        PolicyDTO policyDTO = policyService.getPolicy(policyId);
        return c3PolicyFromPolicyDTO(policyDTO, policyDTO.getCollateralCoverages().get(0).getCollateralId());
    }

    protected C3Policy c3PolicyFromPolicyDTO(PolicyDTO policyDTO, Long collateralId) {
        C3Policy c3Policy = new C3Policy();
        c3Policy.setPolicyId(policyDTO.getPolicyId());
        c3Policy.setPolicyType(policyDTO.getPolicyType());
        c3Policy.setPolicyStatus(policyDTO.getPolicyStatus());
        c3Policy.setInsuranceType(policyDTO.getInsuranceType());
        c3Policy.setEffectiveDate(policyDTO.getEffectiveDate());
        c3Policy.setExpirationDate(policyDTO.getExpirationDate());
        c3Policy.setCancellationEffectiveDate(policyDTO.getCancellationDate());
        c3Policy.setProvidedCoverages(getProvidedCoverages(policyDTO, collateralId));
        c3Policy.setLpAction(policyDTO.getLpAction());
        return c3Policy;
    }

    protected List<C3ProvidedCoverage> getProvidedCoverages(PolicyDTO policyDTO, Long collateralId) {

        PolicyCollateralDetailsDTO policyCollateralDetailsDTO = policyDTO.getCollateralCoverages()
                .stream()
                .filter(policyCollateralDetails -> policyCollateralDetails.getCollateralId()
                        .equals(collateralId)).findFirst().get();

        return policyCollateralDetailsDTO.getInsuranceCoverages()
                .stream()
                .map(policyInsuranceCoverage -> {
                    C3ProvidedCoverage c3ProvidedCoverage = new C3ProvidedCoverage();
                    c3ProvidedCoverage.setCoverageAmount(policyInsuranceCoverage.getCoverageAmount());
                    c3ProvidedCoverage.setCoverageType(policyInsuranceCoverage.getInsuranceCoverageType());
                    c3ProvidedCoverage.setInsurableAssetType(policyInsuranceCoverage.getInsurableAssetType());
                    c3ProvidedCoverage.setInsurableAssetId(policyInsuranceCoverage.getInsurableAssetRid());
                    if (policyInsuranceCoverage.getDeductibleAmount() != null) {
                        c3ProvidedCoverage.setDeductibleAmount(new BigDecimal(policyInsuranceCoverage.getDeductibleAmount()));
                    }
                    return c3ProvidedCoverage;
                }).collect(Collectors.toList());
    }

    protected void populateFloodDetermination(CollateralDTO collateralDTO, C3RequestDTO c3RequestDTO)
    {
        FloodDetermination floodDetermination = floodDeterminationService.findByCollateralRidAndStatus(collateralDTO.getRid(), CollateralSectionStatus.VERIFIED.name());
        if (floodDetermination != null) {
            C3FloodDetermination c3FloodDetermination = new C3FloodDetermination();
            c3FloodDetermination.setFloodZone(floodDetermination.getFloodZone());
            c3FloodDetermination.setDateOfMapChange(DATE_FORMATTER.print(floodDetermination.getDateOfMapChange()));
            c3RequestDTO.setFloodDetermination(c3FloodDetermination);
        }
    }

}
