package com.jpmorgan.cb.wlt.apis.entity;

import com.jpmorgan.cb.wlt.apis.entity.services.EntityService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/entities")
public class EntityAPI {

    private static final Logger logger = LoggerFactory.getLogger(EntityAPI.class);

    private EntityService entityService;

    @Autowired
    public EntityAPI(EntityService entityService) {
        this.entityService = entityService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<EntityDTO>> getEntities(@RequestParam List<Long> entityIds) {
        List<EntityDTO> entityDTOs = new ArrayList<>();
        try {
            entityDTOs = entityService.getEntities(entityIds);
        } catch (CtracException e) {
            logger.error(e.getMessage(), e);
        }
        return ResponseEntity.ok(entityDTOs);
    }

}
