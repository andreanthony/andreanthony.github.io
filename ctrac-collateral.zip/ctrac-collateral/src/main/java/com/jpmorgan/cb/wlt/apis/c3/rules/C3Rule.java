package com.jpmorgan.cb.wlt.apis.c3.rules;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;

public interface C3Rule {
    void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO);
}
