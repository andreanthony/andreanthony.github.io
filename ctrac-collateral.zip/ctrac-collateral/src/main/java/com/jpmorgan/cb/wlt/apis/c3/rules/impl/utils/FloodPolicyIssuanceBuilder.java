package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3AlertEmailBuilder;
import com.jpmorgan.cib.wlt.ctrac.enums.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FloodPolicyIssuanceBuilder extends C3PolicyIssuanceBuilder {

    private static final BigDecimal ALTHANS_LP_TOLERANCE_AMOUNT = new BigDecimal(1000);
    private static final RoundingMode ALTHANS_ROUNDING_MODE = RoundingMode.FLOOR;

    private C3RequestDTO c3RequestDTO;
    private Long insurableAssetId;
    private List<C3PolicyIssuance> policiesToIssue = new ArrayList<>();
    private C3Hold primaryHold;
    private C3Hold excessHold;
    private C3RequiredCoverage primaryRequiredCoverage;
    private C3RequiredCoverage excessRequiredCoverage;
    private List<C3AlertEmail> alertEmails = new ArrayList<>();
    private InsurableAssetType insurableAssetType;
    private List<C3Policy> borrowerPolicies;
    private Date coverageDate;

    public FloodPolicyIssuanceBuilder(C3RequestDTO c3RequestDTO, Long insurableAssetId, Date coverageDate) {
        this.c3RequestDTO = c3RequestDTO;
        this.insurableAssetId = insurableAssetId;
        this.coverageDate = coverageDate;
    }

    private void init() {
        primaryHold = c3RequestDTO.getRequiredCoverageHold(insurableAssetId, FloodCoverageType.PRIMARY);
        excessHold = c3RequestDTO.getRequiredCoverageHold(insurableAssetId, FloodCoverageType.EXCESS);
        primaryRequiredCoverage = c3RequestDTO.getFloodRequiredCoverage(insurableAssetId, FloodCoverageType.PRIMARY);
        excessRequiredCoverage = c3RequestDTO.getFloodRequiredCoverage(insurableAssetId, FloodCoverageType.EXCESS);
        insurableAssetType = c3RequestDTO.getInsurableAssetType(insurableAssetId);
        borrowerPolicies = c3RequestDTO.getFloodBorrowerPoliciesEffectiveOn(coverageDate, insurableAssetId);
    }

    public void calculateLenderPlacement() {
        init();
        final BigDecimal primaryRequiredAmount = primaryHold != null && primaryHold.isActive(coverageDate) || primaryRequiredCoverage == null
                ? BigDecimal.ZERO : primaryRequiredCoverage.getCoverageAmount();
        final BigDecimal excessRequiredAmount = excessHold != null && excessHold.isActive(coverageDate) || excessRequiredCoverage == null
                ? BigDecimal.ZERO : excessRequiredCoverage.getCoverageAmount();

        BigDecimal primaryProvidedAmount = BigDecimal.ZERO;
        BigDecimal excessProvidedAmount = BigDecimal.ZERO;
        BigDecimal excessDeductibleAmount = BigDecimal.ZERO;
        BigDecimal primaryAndExcessProvidedAmount = BigDecimal.ZERO;
        for (C3Policy policy : borrowerPolicies) {
            List<C3ProvidedCoverage> providedCoverages = policy.getProvidedCoverages(insurableAssetId, null);
            for (C3ProvidedCoverage providedCoverage : providedCoverages) {
                FloodCoverageType coverageType = providedCoverage.getFloodCoverageType();
                if (coverageType == FloodCoverageType.PRIMARY) {
                    primaryProvidedAmount = primaryProvidedAmount.add(providedCoverage.getCoverageAmount());
                } else if (coverageType == FloodCoverageType.EXCESS) {
                    if (excessProvidedAmount.compareTo(BigDecimal.ZERO) > 0) {
                        alertEmails.add(new C3AlertEmailBuilder(C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES)
                                .requiredCoverage(excessRequiredCoverage).collateralRid(c3RequestDTO.getCollateralRid()).build());
                        return;
                    }
                    excessProvidedAmount = excessProvidedAmount.add(providedCoverage.getCoverageAmount());
                    excessDeductibleAmount = providedCoverage.getDeductibleAmount();
                } else if (coverageType == FloodCoverageType.PRIMARY_AND_EXCESS) {
                    primaryAndExcessProvidedAmount = primaryAndExcessProvidedAmount.add(providedCoverage.getCoverageAmount());
                }
            }
        }
        createLenderPlacePolicies(primaryRequiredAmount, excessRequiredAmount, primaryProvidedAmount, excessProvidedAmount,
                excessDeductibleAmount, primaryAndExcessProvidedAmount);
    }

    private void createLenderPlacePolicies(BigDecimal primaryRequiredAmount, BigDecimal excessRequiredAmount,
                                           BigDecimal primaryProvidedAmount, BigDecimal excessProvidedAmount,
                                           BigDecimal excessDeductibleAmount, BigDecimal primaryAndExcessProvidedAmount) {
        PolicyType primaryPolicyType = PolicyType.LP;
        BigDecimal additionalExcessCoverage = BigDecimal.ZERO;
        boolean hasPrimaryRequirement = primaryRequiredAmount.compareTo(BigDecimal.ZERO) > 0;
        boolean hasProvidedPrimaryCoverage = primaryProvidedAmount.add(primaryAndExcessProvidedAmount).compareTo(BigDecimal.ZERO) > 0;
        BigDecimal primaryLpAmount = primaryRequiredAmount;
        if (hasPrimaryRequirement && hasProvidedPrimaryCoverage) {
            // There is primary requirement and borrower has provided coverage; Change to create Gap LP Policy
            primaryPolicyType = PolicyType.LP_GAP;
            // Subtract Primary coverage from requirement
            primaryLpAmount = primaryRequiredAmount.subtract(primaryProvidedAmount).max(BigDecimal.ZERO);
            // Calculate if you have Primary and Excess coverage left over
            additionalExcessCoverage = additionalExcessCoverage.max(primaryAndExcessProvidedAmount.subtract(primaryLpAmount));
            // Subtract Primary and Excess coverage from requirement
            primaryLpAmount = primaryLpAmount.subtract(primaryAndExcessProvidedAmount).max(BigDecimal.ZERO);
        }

        primaryLpAmount = roundAndLimitAmount(primaryLpAmount, FloodCoverageType.PRIMARY, primaryRequiredCoverage.getPropertyType());
        createLpPolicyIfNecessary(FloodCoverageType.PRIMARY, primaryPolicyType, primaryLpAmount, coverageDate, hasProvidedPrimaryCoverage);
        if (excessRequiredAmount.compareTo(BigDecimal.ZERO) > 0) {
            // Create Excess LP Policy
            boolean hasProvidedExcessCoverage = excessProvidedAmount.add(primaryAndExcessProvidedAmount).compareTo(BigDecimal.ZERO) > 0;
            BigDecimal excessLpAmount = calculateExcessRequiredAmount(primaryRequiredAmount, excessRequiredAmount,
                    excessProvidedAmount, excessDeductibleAmount, additionalExcessCoverage);
            excessLpAmount = roundAndLimitAmount(excessLpAmount, FloodCoverageType.EXCESS, excessRequiredCoverage.getPropertyType());
            createLpPolicyIfNecessary(FloodCoverageType.EXCESS, PolicyType.LP_EXCESS, excessLpAmount, coverageDate, hasProvidedExcessCoverage);
        }
    }

    private BigDecimal roundAndLimitAmount(BigDecimal lpAmount, FloodCoverageType coverageType, String propertyType) {
        lpAmount = lpAmount.setScale(0, ALTHANS_ROUNDING_MODE);
        if (lpAmount.compareTo(ALTHANS_LP_TOLERANCE_AMOUNT) <= 0) {
            return BigDecimal.ZERO;
        }
        return LPCapMaxAmountUtil.capLPCoverageAmount(
                lpAmount, coverageType, insurableAssetType, propertyType, c3RequestDTO.getCollateralSubType());
    }

    private BigDecimal calculateExcessRequiredAmount(BigDecimal primaryRequiredAmount, BigDecimal excessRequiredAmount,
                                                     BigDecimal excessProvidedAmount, BigDecimal excessDeductibleAmount,
                                                     BigDecimal additionalExcessCoverage) {
        excessRequiredAmount = excessRequiredAmount.subtract(additionalExcessCoverage).max(BigDecimal.ZERO);
        BigDecimal deductibleShortage = excessDeductibleAmount.subtract(primaryRequiredAmount);
        BigDecimal additionalExcessNeeded = excessRequiredAmount.subtract(excessProvidedAmount);
        boolean isExcessDeductibleMet = deductibleShortage.compareTo(BigDecimal.ZERO) <= 0;
        if (!isExcessDeductibleMet && excessProvidedAmount.add(deductibleShortage).compareTo(excessRequiredAmount) < 0) {
            // Meeting Excess Deductible leads to sufficient coverage -> Pay the deductible
            return deductibleShortage;
        }
        // Excess Deductible met -> Subtract Excess coverage from requirement
        // OR Meeting Excess Deductible is not enough -> Purchase additional coverage
        return additionalExcessNeeded.max(BigDecimal.ZERO);
    }

    private void createLpPolicyIfNecessary(FloodCoverageType coverageType, PolicyType policyType, BigDecimal lpAmount,
                                           Date coverageDate, boolean hasBorrowerProvidedCoverage) {
        if (lpAmount.compareTo(BigDecimal.ZERO) > 0) {
            C3PolicyIssuance c3PolicyIssuance = buildC3PolicyIssuance(coverageType.name(), policyType, lpAmount, coverageDate);

            c3PolicyIssuance.setInsurableAssetId(insurableAssetId);
            c3PolicyIssuance.setInsurableAssetType(insurableAssetType);
            c3PolicyIssuance.setInsuredName(c3RequestDTO.getInsuredName());
            c3PolicyIssuance.setFloodZone(c3RequestDTO.getFloodDetermination().getFloodZone());
            c3PolicyIssuance.setParentPolicyId(
                    getParentPolicyId(c3RequestDTO.getBorrowerPoliciesExcludingPendingVerification(
                            InsuranceType.FLOOD, coverageType.name(), insurableAssetId)));
            if (hasBorrowerProvidedCoverage) {
                c3PolicyIssuance.setGapBorrowerPolicyId(c3PolicyIssuance.getParentPolicyId());
            }
            policiesToIssue.add(c3PolicyIssuance);
        }
    }

    public List<C3PolicyIssuance> getPoliciesToIssue() {
        return policiesToIssue;
    }

    public List<C3AlertEmail> getAlertEmails() {
        return alertEmails;
    }
}
