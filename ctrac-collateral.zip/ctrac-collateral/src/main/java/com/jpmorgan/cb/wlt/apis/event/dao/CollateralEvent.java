package com.jpmorgan.cb.wlt.apis.event.dao;

import com.jpmorgan.cb.wlt.apis.event.store.CollateralEventListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "TLCP_COLLATERAL_EVENT")
@EntityListeners(CollateralEventListener.class)
public class CollateralEvent {

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "collateralEventSeqGenerator")
	@TableGenerator(name = "collateralEventSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_COLLATERAL_EVENT", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "EVENT_UUID")
	@NotNull
	private UUID eventUuid;

	@Column(name = "EVENT_TIME")
	@NotNull
	private Date eventTime;

	@Column(name = "EVENT_JSON")
	@NotNull
	private String eventJson;

	@Column(name = "EVENT_STATUS")
	@NotNull
	private String eventStatus;

	@Column(name = "LAST_PUBLISH_TIME")
	@NotNull
	private Date lastPublishTime = new Date();

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public UUID getEventUuid() { return eventUuid; }

	public void setEventUuid(UUID eventUuid) { this.eventUuid = eventUuid; }

	public Date getEventTime() {
		if (eventTime == null) {
			return null;
		}
		return (Date) eventTime.clone();
	}

	public void setEventTime(Date eventTime) {
		if (eventTime == null) {
			this.eventTime = null;
		} else {
			this.eventTime = (Date) eventTime.clone();
		}
	}

	public String getEventJson() {
		return eventJson;
	}

	public void setEventJson(String eventJson) {
		this.eventJson = eventJson;
	}

	public String getEventStatus() {
		return eventStatus;
	}

	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}

	public Date getLastPublishTime() {
		if (lastPublishTime == null) {
			lastPublishTime = new Date();
		}
		return (Date) lastPublishTime.clone();
	}

	public void setLastPublishTime(Date lastPublishTime) {
		if (lastPublishTime == null) {
			lastPublishTime = new Date();
		}
		this.lastPublishTime = (Date) lastPublishTime.clone();
	}
}
