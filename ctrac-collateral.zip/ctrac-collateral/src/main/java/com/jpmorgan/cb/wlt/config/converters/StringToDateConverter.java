package com.jpmorgan.cb.wlt.config.converters;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.modelmapper.AbstractConverter;

import java.util.Date;

public class StringToDateConverter extends AbstractConverter<String, Date> {
    private static final DateTimeFormatter US_DATE_FORMAT = DateTimeFormat.forPattern("MM/dd/yyyy");

    @Override
    protected Date convert(String s) {
        if (StringUtils.isBlank(s)) {
            return null;
        }
        return US_DATE_FORMAT.parseDateTime(s).withTimeAtStartOfDay().toDate();
    }
}
