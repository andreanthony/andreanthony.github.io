package com.jpmorgan.cb.wlt.apis.loan.services;

import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.UpbDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

import java.util.List;

public interface LoanService {
    LoanDTO getLoan(Long loanId);
    LoanDTO createLoan(LoanDTO loanDTO,UserRequestInfo userRequestInfo);
    List<LoanDTO> getLoans(Long collateralId, Boolean active, Boolean primary);
    List<LoanDTO> getActiveLoans(Long collateralId);
    List<LoanDTO> getLoans(Long collateralId);
    List<UpbDTO> getLoanUPBDetails(Long loanId);
    List<LoanDTO> verifyLoanSection(Long collateralId,UserRequestInfo userRequestInfo);

}