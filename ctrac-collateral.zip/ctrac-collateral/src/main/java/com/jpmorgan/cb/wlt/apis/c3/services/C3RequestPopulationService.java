package com.jpmorgan.cb.wlt.apis.c3.services;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;

public interface C3RequestPopulationService {
    void populate(Long collateralId, C3RequestDTO c3RequestDTO);
    C3RequestDTO build(C3RequestEventDTO c3RequestEventDTO);
    C3Policy populatePolicy(Long policyId);
}
