package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.enums.AlthansPropertyType;
import com.jpmorgan.cb.wlt.apis.c3.dtos.enums.RealEstateSubType;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;

import java.math.BigDecimal;

public class LPCapMaxAmountUtil {

    public static final BigDecimal PRIMARY_RESIDENTIAL_LIMIT = new BigDecimal("250000");
    public static final BigDecimal PRIMARY_COMMERCIAL_LIMIT = new BigDecimal("500000");
    public static final BigDecimal EXCESS_LIMIT = new BigDecimal("25000000");

    public static BigDecimal capLPCoverageAmount(BigDecimal lpAmount, FloodCoverageType coverageType,
                                                 InsurableAssetType insurableAssetType, String propertyType, String collateralSubType){
		if(insurableAssetType == null || coverageType == null)
			return lpAmount;

		if(coverageType == FloodCoverageType.PRIMARY) {
			return cap(getMaximumPrimaryLPCoverageAmount(insurableAssetType, propertyType, collateralSubType), lpAmount);
		}
		else if(coverageType == FloodCoverageType.EXCESS) {
			return cap(getMaximumExcessLPCoverageAmount(insurableAssetType), lpAmount);
		}
		else {
			return lpAmount;
		}
	}

    private static BigDecimal getMaximumExcessLPCoverageAmount(InsurableAssetType insurableAssetType) {
        if(InsurableAssetType.STRUCTURE == insurableAssetType){
            return EXCESS_LIMIT;
        }
        if(InsurableAssetType.BUSINESS_INCOME == insurableAssetType) {
            return BigDecimal.ZERO;
        }
        return null;
    }

    private static BigDecimal getMaximumPrimaryLPCoverageAmount(InsurableAssetType insurableAssetType,
                                                                String propertyType, String collateralSubType) {
        if(InsurableAssetType.BUSINESS_INCOME == insurableAssetType) {
            return null;
        }
        AlthansPropertyType althansPropertyType = getAlthansPropertyType(propertyType);
        if (althansPropertyType == null) {
            return null;
        }
        if (althansPropertyType.isCondoAssociation()) {
            RealEstateSubType realEstateSubType = RealEstateSubType.getByCode((collateralSubType));
            if (realEstateSubType == null) {
                return null;
            }
            return realEstateSubType.isCommercial()? PRIMARY_COMMERCIAL_LIMIT: PRIMARY_RESIDENTIAL_LIMIT;
        }
        if (althansPropertyType.isResidential()) {
            return PRIMARY_RESIDENTIAL_LIMIT;
        }
        if (althansPropertyType.isCommercial()) {
            return PRIMARY_COMMERCIAL_LIMIT;
        }
        return null;
    }

    private static AlthansPropertyType getAlthansPropertyType(String propertyType) {
        AlthansPropertyType althansPropertyType = AlthansPropertyType.getByCodeOrDesc(propertyType);
        return althansPropertyType != null? althansPropertyType :
                new FiatToAlthansPropertyTypeConverter().convertByPropertyDescription(propertyType);
    }

    private static BigDecimal cap(BigDecimal capAmount, BigDecimal actualAmount){
		return (capAmount == null || actualAmount.compareTo(capAmount) == -1)? actualAmount: capAmount;
	}

}
