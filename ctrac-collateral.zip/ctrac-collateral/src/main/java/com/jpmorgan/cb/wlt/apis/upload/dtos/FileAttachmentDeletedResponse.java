package com.jpmorgan.cb.wlt.apis.upload.dtos;

public class FileAttachmentDeletedResponse {

    private int filesDeleted;

    public FileAttachmentDeletedResponse(int filesDeleted){
        this.filesDeleted = filesDeleted;
    }

    public int getFilesDeleted() {
        return filesDeleted;
    }

}
