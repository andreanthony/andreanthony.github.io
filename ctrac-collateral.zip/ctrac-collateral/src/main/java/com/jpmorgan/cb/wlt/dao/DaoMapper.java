package com.jpmorgan.cb.wlt.dao;

public interface DaoMapper<M, D> {
    /**
     * @param model the model object to be mapped to DTO
     * @return the mapped DTO
     */
    D toDTO(M model);

    /**
     * @param dto the DTO object to be saved
     * @param model the model object freshly queried from the database
     * @return whether or not the model has been modified
     */
    boolean map(D dto, M model);
}
