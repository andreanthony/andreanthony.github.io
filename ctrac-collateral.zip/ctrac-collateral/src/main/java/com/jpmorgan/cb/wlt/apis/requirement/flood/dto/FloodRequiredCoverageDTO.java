package com.jpmorgan.cb.wlt.apis.requirement.flood.dto;

import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.ObjectUtils;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

public class FloodRequiredCoverageDTO {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    @NotNull
    private Long requiredCoverageRid;
    private String insuranceType;
    private String coverageType;
    private Long insurableAssetId;
    private String insurableAssetType;
    private String documentDate;
    private boolean descoped = false;
    private BigDecimal coverageAmount;
    private String propertyType;
    private String status;
    private String cancellationEffectiveDate;
    private Long holdRid;

    public Long getRequiredCoverageRid() {
        return requiredCoverageRid;
    }

    public void setRequiredCoverageRid(Long requiredCoverageRid) {
        this.requiredCoverageRid = requiredCoverageRid;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    @ApiModelProperty(hidden = true)
    public InsuranceType getInsuranceType_() {
        return InsuranceType.valueOf(insuranceType);
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public String getCoverageType() {
        return coverageType;
    }

    @ApiModelProperty(hidden = true)
    public FloodCoverageType getFloodCoverageType() {
        return FloodCoverageType.valueOf(coverageType);
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public Long getInsurableAssetId() {
        return insurableAssetId;
    }

    public void setInsurableAssetId(Long insurableAssetId) {
        this.insurableAssetId = insurableAssetId;
    }

    public String getInsurableAssetType() {
        return insurableAssetType;
    }

    @ApiModelProperty(hidden = true)
    public InsurableAssetType getInsurableAssetType_() {
        return InsurableAssetType.valueOf(insurableAssetType);
    }

    public void setInsurableAssetType(String insurableAssetType) {
        this.insurableAssetType = insurableAssetType;
    }

    public String getDocumentDate() {
        return documentDate;
    }

    @ApiModelProperty(hidden = true)
    public Date getDocumentDate_() {
        return DATE_FORMATTER.parse(documentDate);
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

    public BigDecimal getCoverageAmount() {
        return ObjectUtils.defaultIfNull(coverageAmount, BigDecimal.ZERO);
    }

    public void setCoverageAmount(BigDecimal coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public boolean isDescoped() {
        return descoped;
    }

    public void setDescoped(boolean descoped) {
        this.descoped = descoped;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
        this.cancellationEffectiveDate = cancellationEffectiveDate;
    }

    public String getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    public void setHoldRid(Long holdRid) {
        this.holdRid = holdRid;
    }

    public Long getHoldRid() {
        return holdRid;
    }
}
