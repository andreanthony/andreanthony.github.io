package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;

import java.io.Serializable;
import java.util.Date;

public class C3CalculatedCoverageDate implements Serializable {
    private static final long serialVersionUID = -1;

    public static final DefaultDateFormatter DATE_FORMAT = new DefaultDateFormatter();

    public C3CalculatedCoverageDate() {}
    public C3CalculatedCoverageDate(String insuranceType, Date coverageDate) {
        this.insuranceType = insuranceType;
        this.coverageDate = coverageDate;
    }

    private String insuranceType;
    private Date coverageDate;
    private String coverageType;
    private Long insurableAssetId;
    private InsurableAssetType insurableAssetType;
    private Long policyId;
    private boolean valid = true;

    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public Date getCoverageDate() {
        return coverageDate;
    }

    public void setCoverageDate(Date coverageDate) {
        this.coverageDate = coverageDate;
    }

    @JsonIgnore
    public FloodCoverageType getCoverageType_() {
        return FloodCoverageType.valueOf(coverageType);
    }

    public void setCoverageType_(FloodCoverageType coverageType) {
        this.coverageType = coverageType.name();
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public Long getInsurableAssetId() {
        return insurableAssetId;
    }

    public void setInsurableAssetId(Long insurableAssetId) {
        this.insurableAssetId = insurableAssetId;
    }

    public InsurableAssetType getInsurableAssetType() {
        return insurableAssetType;
    }

    public void setInsurableAssetType(InsurableAssetType insurableAssetType) {
        this.insurableAssetType = insurableAssetType;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    @Override
    public String toString() {
        return DATE_FORMAT.print(getCoverageDate()) + " Coverage: " + coverageType + " InsurableAsset: " + insurableAssetId;
    }

}
