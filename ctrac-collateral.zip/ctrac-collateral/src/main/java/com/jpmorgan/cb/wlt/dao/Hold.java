package com.jpmorgan.cb.wlt.dao;

import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "TLCP_HOLD")
public class Hold extends AuditableEntity {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "holdSeqGenerator")
    @TableGenerator(name = "holdSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_HOLD", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @OneToOne
    @JoinColumn(name = "PARENT_HOLD_RID")
    private Hold parentHold;

    @Column(name = "HOLD_STATUS")
    private String holdStatus;

    @Column(name = "HOLD_TYPE")
    private String holdType;

    @Column(name = "START_DATE")
    private Date startDate;

    @Column(name = "HOLD_PERIOD")
    private String holdPeriod;

    @Column(name = "LPI_DATE")
    private Date lpiDate;

    @Column(name = "VERIFIED_BY")
    private String verifiedBy;

    @Column(name = "VERIFIED_DATE")
    private Date verifiedDate;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public Hold getParentHold() {
        return parentHold;
    }

    public void setParentHold(Hold parentHold) {
        this.parentHold = parentHold;
    }

    public String getHoldStatus() {
        return holdStatus;
    }

    public void setHoldStatus(String holdStatus) {
        this.holdStatus = holdStatus;
    }

    public String getHoldType() {
        return holdType;
    }

    public void setHoldType(String holdType) {
        this.holdType = holdType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getHoldPeriod() {
        return holdPeriod;
    }

    public void setHoldPeriod(String holdPeriod) {
        this.holdPeriod = holdPeriod;
    }

    public Date getLpiDate() {
        return lpiDate;
    }

    public void setLpiDate(Date lpiDate) {
        this.lpiDate = lpiDate;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Date getVerifiedDate() {
        return verifiedDate;
    }

    public void setVerifiedDate(Date verifiedDate) {
        this.verifiedDate = verifiedDate;
    }

    @Transient
    public Date getHoldEndDate() {
        Date endDate = this.getLpiDate();
        if (!VerificationStatus.VERIFIED.name().equals(this.getHoldStatus())) {
            endDate = null;
        }
        return endDate;
    }

    @Transient
    public Date getHoldStartDate() {
        Date startDate = this.getStartDate();
        // Initial hold start date is in the parent hold row
        if (this.getParentHold() != null) {
            startDate = this.getParentHold().getStartDate();
        }
        return startDate;
    }

}
