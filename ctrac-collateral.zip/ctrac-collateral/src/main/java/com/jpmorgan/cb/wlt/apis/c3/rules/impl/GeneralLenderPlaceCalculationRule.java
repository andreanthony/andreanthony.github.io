package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3PolicyIssuanceBuilder;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.LenderPlaceReason;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.SortedSet;

public class GeneralLenderPlaceCalculationRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(GeneralLenderPlaceCalculationRule.class);

    private static final BigDecimal ALTHANS_LP_TOLERANCE_AMOUNT = new BigDecimal(1000);
    private static final RoundingMode ALTHANS_ROUNDING_MODE = RoundingMode.FLOOR;

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        // get a map coverage type to list of dates
        c3ResponseDTO.getGeneralCoverageDatesByCoverageType().entrySet().forEach(coverageTypeEntry ->
                calculateLenderPlacementForCoverageType(c3RequestDTO, c3ResponseDTO,
                        coverageTypeEntry.getKey(), coverageTypeEntry.getValue()));
        logger.debug("GeneralLenderPlaceCalculationRule - policies to be canceled for Collateral and Policy ID {}",
                StringUtils.join(c3ResponseDTO.getPoliciesToIssue(), ','));
    }

    private void calculateLenderPlacementForCoverageType(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO,
                                                           String coverageType, SortedSet<Date> coverageDates) {
        final C3RequiredCoverage requiredCoverage = c3RequestDTO.getGeneralRequiredCoverage(coverageType);
        coverageDates.forEach(coverageDate -> calculateLenderPlacementForDate(
                c3RequestDTO, c3ResponseDTO, requiredCoverage, coverageDate));
    }

    private void calculateLenderPlacementForDate(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO,
                                                 C3RequiredCoverage requiredCoverage, Date coverageDate) {
        final BigDecimal requiredAmount = requiredCoverage.getCoverageAmount();
        if (requiredAmount.compareTo(BigDecimal.ZERO) > 0) {
            final List<C3Policy> borrowerPolicies = c3RequestDTO.getGeneralBorrowerPoliciesEffectiveOn(
                    coverageDate, requiredCoverage.getCoverageType());
            BigDecimal providedAmount = getProvidedAmount(requiredCoverage, borrowerPolicies);
            BigDecimal lpAmount = getLpAmount(requiredAmount, providedAmount);
            if (lpAmount.compareTo(ALTHANS_LP_TOLERANCE_AMOUNT) > 0) {
                PolicyType policyType = getLpPolicyType(providedAmount);
                // TODO: lpAmount = LPCapMaxAmountUtil.capLPCoverageAmount(coverageType, insurableAssetType, lpAmount);
                C3PolicyIssuance c3PolicyIssuance = C3PolicyIssuanceBuilder.buildC3PolicyIssuance(
                        requiredCoverage.getCoverageType(), policyType, lpAmount, coverageDate);
                c3PolicyIssuance.setParentPolicyId(C3PolicyIssuanceBuilder.getParentPolicyId(
                        c3RequestDTO.getBorrowerPoliciesExcludingPendingVerification(
                                InsuranceType.GENERAL, c3PolicyIssuance.getCoverageType(), null)));
                c3PolicyIssuance.setCollateralRid(c3RequestDTO.getCollateralRid());
                c3PolicyIssuance.setLenderPlaceReason(LenderPlaceReason.GENERAL_INSURANCE_PRIMARY);
                if (PolicyType.GI_LP_GAP == policyType) {
                    c3PolicyIssuance.setGapBorrowerPolicyId(c3PolicyIssuance.getParentPolicyId());
                    c3PolicyIssuance.setLenderPlaceReason(LenderPlaceReason.GENERAL_INSURANCE_GAP);
                }
                c3ResponseDTO.getPoliciesToIssue().add(c3PolicyIssuance);
            }
        }
    }

    BigDecimal getLpAmount(BigDecimal requiredAmount, BigDecimal providedAmount) {
        BigDecimal lpAmount = requiredAmount.subtract(providedAmount).max(BigDecimal.ZERO);
        lpAmount = lpAmount.setScale(0, ALTHANS_ROUNDING_MODE);
        return lpAmount;
    }

    private BigDecimal getProvidedAmount(C3RequiredCoverage requiredCoverage, List<C3Policy> borrowerPolicies) {
        BigDecimal providedAmount = BigDecimal.ZERO;
        for (C3Policy policy : borrowerPolicies) {
            List<C3ProvidedCoverage> providedCoverages = policy.getProvidedCoverages(requiredCoverage.getCoverageType());
            providedAmount = providedAmount.add(providedCoverages.stream()
                    .map(C3ProvidedCoverage::getCoverageAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add));
         }
        return providedAmount;
    }

    PolicyType getLpPolicyType(BigDecimal providedAmount) {
        return providedAmount.compareTo(BigDecimal.ZERO) > 0? PolicyType.GI_LP_GAP : PolicyType.GI_LP;
    }

}
