package com.jpmorgan.cb.wlt.apis.policy.dtos;

import com.jpmorgan.cb.wlt.dtos.AddressDTO;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class PaymentMethodDTO {
    private String paymentMethod;
    private String paymentAccount;
    private AddressDTO address;

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public AddressDTO getAddress() {
        return address;
    }

    public void setAddress(AddressDTO address) {
        this.address = address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        PaymentMethodDTO that = (PaymentMethodDTO) o;

        return new EqualsBuilder()
                .append(paymentMethod, that.paymentMethod)
                .append(paymentAccount, that.paymentAccount)
                .append(address, that.address)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(paymentMethod)
                .append(paymentAccount)
                .append(address)
                .toHashCode();
    }
}
