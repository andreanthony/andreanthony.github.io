package com.jpmorgan.cb.wlt.apis.event.store;

import com.jpmorgan.cib.wlt.ctrac.encryption.EncryptionUtil;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.secure.TrustStoreLoadException;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.secure.TrustStoreManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class TrustStoreManagerServiceImpl implements TrustStoreManagerService {

	private static final Logger logger = LoggerFactory.getLogger(TrustStoreManagerServiceImpl.class);
	private TrustStoreManager trustStoreManager;

	@Value("${jms.keystore.path}")
	private String keyStorePath;

	@Value("${jms.keystore.password}")
	private String keyStorePassword;

	@PostConstruct
	void init() {
		loadTrustStoreManager();
	}

	private void loadTrustStoreManager() {
		try {
			this.trustStoreManager = TrustStoreManager.aKeyStoreManager(keyStorePath,
					EncryptionUtil.decrypt(keyStorePassword)).generateSSLContext();
		} catch (TrustStoreLoadException e) {
			logger.error("Cannot load the trustStore ", e);
		}
	}

	public TrustStoreManager getTrustStoreManager() {
		return this.trustStoreManager;
	}
}
