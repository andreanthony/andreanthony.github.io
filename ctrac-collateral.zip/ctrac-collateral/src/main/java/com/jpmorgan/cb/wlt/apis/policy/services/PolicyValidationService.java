package com.jpmorgan.cb.wlt.apis.policy.services;

import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;

import java.util.List;

public interface PolicyValidationService {
    void validateCreate(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded);

    void validateEdit(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, PolicyStatus policyStatus);

    void validateOverride(PolicyDTO policyDTO, PolicyStatus policyStatus);

    void validateVerify(PolicyDTO policyDTO, PolicyStatus policyStatus);

    void validateReview(PolicyDTO policyDTO);
}
