package com.jpmorgan.cb.wlt.apis.batch.services;

public interface BatchCtrlService {


    boolean isBatchRunning();

}
