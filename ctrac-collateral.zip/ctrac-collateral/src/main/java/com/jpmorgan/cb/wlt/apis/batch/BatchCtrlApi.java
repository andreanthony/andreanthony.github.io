package com.jpmorgan.cb.wlt.apis.batch;
import com.jpmorgan.cb.wlt.apis.batch.services.BatchCtrlService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Secured({CtracRole.ROLE_READER})
@RestController
@RequestMapping(value = "/api/batchInfo")
public class BatchCtrlApi {

    private BatchCtrlService batchCtrlService;
    @Autowired
    public BatchCtrlApi(BatchCtrlService batchCtrlService) {
        assert(batchCtrlService != null);
        this.batchCtrlService = batchCtrlService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<BatchCtrlDTO> isBatchRunning() {
        BatchCtrlDTO batchCtrlDTO=new BatchCtrlDTO();
        batchCtrlDTO.setBatchRunning(batchCtrlService.isBatchRunning());
        return ResponseEntity.ok(batchCtrlDTO);
    }
}
