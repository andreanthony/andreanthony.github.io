package com.jpmorgan.cb.wlt.apis.requirement.general.dtos;

import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentSummaryDTO;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class GeneralRequiredCoverageSourceDTO implements Comparable {
    private static final DateFormatter DEFAULT_DATE_FORMATTER = new DefaultDateFormatter();
    private static final Comparator<GeneralRequiredCoverageSourceDTO> DTO_COMPARATOR = Comparator
            .comparing((GeneralRequiredCoverageSourceDTO sourceDto) -> DEFAULT_DATE_FORMATTER.parse(sourceDto.getDocumentDate()))
            .thenComparing(GeneralRequiredCoverageSourceDTO::getRid);

    private Long rid;
    private Long collateralRid;
    private String source;
    private String status;
    private String insuranceType;
    private String documentDate;
    private String cancellationEffectiveDate;
    @NotEmpty @Valid
    private List<GeneralRequiredCoverageDTO> generalRequiredCoverages = new ArrayList<>();
    private List<CollateralDocumentSummaryDTO> coverageSourceDocuments = new ArrayList<>();
    private boolean canDelete;
    private String uploadBucketName;
    private String updatedBy;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public List<GeneralRequiredCoverageDTO> getGeneralRequiredCoverages() {
        return generalRequiredCoverages;
    }

    public void setGeneralRequiredCoverages(List<GeneralRequiredCoverageDTO> generalRequiredCoverages) {
        this.generalRequiredCoverages = generalRequiredCoverages;
    }




    public boolean canDelete() {
        return canDelete;
    }

    public void setCanDelete(boolean canDelete) {
        this.canDelete = canDelete;
    }


    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public String getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
        this.cancellationEffectiveDate = cancellationEffectiveDate;
    }

    public String getUploadBucketName() {
        return uploadBucketName;
    }

    public void setUploadBucketName(String uploadBucketName) {
        this.uploadBucketName = uploadBucketName;
    }

    public List<CollateralDocumentSummaryDTO> getCoverageSourceDocuments() {
        return coverageSourceDocuments;
    }

    public void addCoverageSourceDocuments(List<CollateralDocumentSummaryDTO> coverageSourceDocuments) {
        this.getCoverageSourceDocuments().addAll(coverageSourceDocuments);
    }

    public void setCoverageSourceDocuments(List<CollateralDocumentSummaryDTO> coverageSourceDocuments) {
        this.coverageSourceDocuments = coverageSourceDocuments;
    }

    @Override
    public int compareTo(Object o) {
        GeneralRequiredCoverageSourceDTO otherSourceDto = (GeneralRequiredCoverageSourceDTO) o;
        return DTO_COMPARATOR.compare(this,otherSourceDto);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = (GeneralRequiredCoverageSourceDTO) o;
        return new EqualsBuilder()
                .append(rid, generalRequiredCoverageSourceDTO.rid)
                .append(collateralRid, generalRequiredCoverageSourceDTO.collateralRid)
                .append(cancellationEffectiveDate, generalRequiredCoverageSourceDTO.cancellationEffectiveDate)
                .append(documentDate, generalRequiredCoverageSourceDTO.documentDate)
                .append(insuranceType, generalRequiredCoverageSourceDTO.insuranceType)
                .append(source, generalRequiredCoverageSourceDTO.source)
                .isEquals() && equalRequiredCoverages(generalRequiredCoverageSourceDTO.generalRequiredCoverages);
    }

    private boolean equalRequiredCoverages(List<GeneralRequiredCoverageDTO> coveragesToCompare){
        return generalRequiredCoverages.containsAll(coveragesToCompare)
                && generalRequiredCoverages.size() == coveragesToCompare.size();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(collateralRid)
                .append(cancellationEffectiveDate)
                .append(documentDate)
                .append(generalRequiredCoverages)
                .append(insuranceType)
                .append(source)
                .toHashCode();
    }

}
