package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3AlertEmail;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.FloodPolicyIssuanceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Collectors;

public class FloodLenderPlaceCalculationRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(FloodLenderPlaceCalculationRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        c3ResponseDTO.getFloodCoverageDatesByInsurableAssetId()
                .entrySet()
                .forEach(insurableAssetEntry ->
                    insurableAssetEntry.getValue()
                            .stream()
                            .forEach(coverageDate -> {
                                FloodPolicyIssuanceBuilder c3PolicyIssuanceBuilder = new FloodPolicyIssuanceBuilder(
                                    c3RequestDTO, insurableAssetEntry.getKey(), coverageDate);
                                c3PolicyIssuanceBuilder.calculateLenderPlacement();
                                c3ResponseDTO.getPoliciesToIssue().addAll(c3PolicyIssuanceBuilder.getPoliciesToIssue());
                                c3ResponseDTO.getAlertEmails().addAll(c3PolicyIssuanceBuilder.getAlertEmails());
                                logger.debug("FloodLenderPlaceCalculationRule - policies to be issued for Collateral and Policy ID{} ",c3PolicyIssuanceBuilder.getPoliciesToIssue().stream().map(C3PolicyIssuance::toString).collect(Collectors.joining(",")));
                                logger.debug("FloodLenderPlaceCalculationRule - alert email sent for email template {}", c3PolicyIssuanceBuilder.getAlertEmails().stream().map(C3AlertEmail::toString).collect(Collectors.joining(",")));
                            })
                );

    }


 }
