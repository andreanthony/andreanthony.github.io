package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.InsurableAsset;
import com.jpmorgan.cb.wlt.apis.policy.dao.InsurableAssetRepository;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProvidedCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.config.ApplicationContextProvider;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import org.apache.commons.lang3.builder.EqualsBuilder;

public class FloodProvidedCoverageMapper extends AbstractProvidedCoverageMapper implements DaoMapper<ProvidedCoverage, PolicyInsuranceCoverageDTO> {

    @Override
    public PolicyInsuranceCoverageDTO toDTO(ProvidedCoverage model) {
        PolicyInsuranceCoverageDTO policyInsuranceCoverageDTO = super.toDTO(model);

        policyInsuranceCoverageDTO.setInsuranceCoverageType(getInsuranceCoverageType(model.getCoverageDetails().getCoverageType()));
        policyInsuranceCoverageDTO.setInsurableAssetType(model.getInsurableAsset().getAssetType());
        policyInsuranceCoverageDTO.setInsurableAssetRid(model.getInsurableAsset().getRid());

        return policyInsuranceCoverageDTO;
    }

    private String getInsuranceCoverageType(String coverageType) {
        FloodCoverageType floodCoverageType = FloodCoverageType.forName(coverageType);
        return floodCoverageType == null ? null : floodCoverageType.name();
    }

    @Override
    public boolean map(PolicyInsuranceCoverageDTO dto, ProvidedCoverage model) {
        if (!super.map(dto, model) && new EqualsBuilder()
                .append(dto.getInsuranceCoverageType(), getInsuranceCoverageType(model.getCoverageDetails().getCoverageType()))
                .append(dto.getInsurableAssetType(), model.getInsurableAsset().getAssetType())
                .append(dto.getInsurableAssetRid(), model.getInsurableAsset().getRid())
                .isEquals()) {
            return false;
        }

        model.getCoverageDetails().setCoverageType(dto.getInsuranceCoverageType());
        InsurableAssetRepository insurableAssetRepository =
                ApplicationContextProvider.getContext().getBean(InsurableAssetRepository.class);
        model.setInsurableAsset(insurableAssetRepository.findById(dto.getInsurableAssetRid()).orElse(new InsurableAsset()));

        return true;
    }
}