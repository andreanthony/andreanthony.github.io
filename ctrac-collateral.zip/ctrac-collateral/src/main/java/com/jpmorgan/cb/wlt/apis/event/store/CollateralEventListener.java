package com.jpmorgan.cb.wlt.apis.event.store;

import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerServiceImpl;
import com.jpmorgan.cb.wlt.apis.event.CollateralEventStatus;
import com.jpmorgan.cb.wlt.apis.event.dao.CollateralEvent;
import com.jpmorgan.cb.wlt.config.ApplicationContextProvider;
import com.jpmorgan.cib.wlt.ctrac.auth.AuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.client.EventStoreClient;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.client.EventStoreFactory;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import javax.net.ssl.SSLContext;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import java.util.Arrays;

public class CollateralEventListener {

	private static final Logger logger = LoggerFactory.getLogger(CollateralEventListener.class);
	private EventStoreClient eventStoreClient = null;
	private String eventApiUrl;
	private String[] activeProfiles;

	private void init() {
		ApplicationContext context = ApplicationContextProvider.getContext();
		eventApiUrl = context.getEnvironment().getProperty("ctrac.event.api.url");
		activeProfiles = context.getEnvironment().getActiveProfiles();
	}

	private void initEventStore() {
		eventStoreClient = EventStoreFactory.create(eventApiUrl,
				getSSLContext(), getAuthenticationManager());
	}

	SSLContext getSSLContext() {
		return ApplicationContextProvider.getContext().getBean(TrustStoreManagerServiceImpl.class)
				.getTrustStoreManager().getSSLContext();
	}

	AuthenticationManager getAuthenticationManager() {
		return ApplicationContextProvider.getContext().getBean(CtracAuthenticationManagerServiceImpl.class)
				.getAuthenticationManager();
	}

	@PostPersist
	@PostUpdate
	public void postPersistOrUpdate(final CollateralEvent collateralEvent) {
		if (activeProfiles == null) {
			init();
		}
		boolean skipSendingEvent = StringUtils.isNotEmpty(
				Arrays.stream(activeProfiles)
						.filter("test"::equalsIgnoreCase)
						.findFirst().orElse(null));
		if(skipSendingEvent){
			return;
		}

		if (eventStoreClient == null) {
			initEventStore();
		}
		TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
			@Override
			public void afterCompletion(int status) {
				if (CollateralEventStatus.PENDING.name().equals(collateralEvent.getEventStatus()) &&
						TransactionSynchronization.STATUS_COMMITTED == status) {
					try {
						//TODO get this from featureManager
						boolean isAsyncPost = false;
						eventStoreClient.publish(collateralEvent.getEventJson(),
								getAuthenticationManager().getAuthenticationToken(), isAsyncPost);
					} catch (Exception e) {
						logger.error("Publishing to event api {} failed", eventApiUrl, e);
					}
				}
			}
		});
	}
}
