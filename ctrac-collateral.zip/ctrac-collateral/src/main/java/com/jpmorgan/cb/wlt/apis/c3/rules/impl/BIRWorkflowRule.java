package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ExceptionLevel;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Collectors;

public class BIRWorkflowRule implements C3Rule {
    private static final Logger logger = LoggerFactory.getLogger(BIRWorkflowRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        String performedBy = c3RequestDTO.getPerformedBy();
        if (StringUtils.isNotBlank(performedBy) && !StringUtils.isAlphanumeric(c3RequestDTO.getPerformedBy())) {
            logger.error("Received a performedBy that is non-alphanumeric={}", c3RequestDTO.getPerformedBy());
            throw new CtracException("Received a performedBy that is non-alphanumeric", ExceptionLevel.GENEOS);
        } else {
            c3ResponseDTO.setPerformedBy(c3RequestDTO.getPerformedBy());
        }
        c3ResponseDTO.addNewlyVerifiedBorrowerPolicies(c3RequestDTO.getBorrowerPolicies().stream()
                .filter(policy -> policy.getLpAction_() == LPAction.NEW_BP || policy.getLpAction_() == LPAction.PENDING_C3)
                .map(C3Policy::getPolicyId)
                .collect(Collectors.toSet())
        );
    }
}
