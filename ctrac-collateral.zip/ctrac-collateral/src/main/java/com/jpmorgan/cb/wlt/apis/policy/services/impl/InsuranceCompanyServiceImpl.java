package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.InsuranceCompanyMapper;
import com.jpmorgan.cb.wlt.apis.policy.dao.BIRInsuranceCompanyName;
import com.jpmorgan.cb.wlt.apis.policy.dtos.InsuranceCompanyDTO;

import com.jpmorgan.cb.wlt.apis.policy.services.InsuranceCompanyService;
import com.jpmorgan.cb.wlt.dao.InsuranceCompanyListRepository;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InsuranceCompanyServiceImpl implements InsuranceCompanyService {

    private static final Logger logger = LoggerFactory.getLogger(InsuranceCompanyServiceImpl.class);

    @Autowired
    private InsuranceCompanyListRepository insuranceCompanyListRepository;

    public List<InsuranceCompanyDTO> getListofInsuranceCompanyNames(String searchParam) {
        List<InsuranceCompanyDTO> listofCompanyNames = new ArrayList<>();
        InsuranceCompanyMapper mapper = new InsuranceCompanyMapper();
        try {
            List<BIRInsuranceCompanyName> searchResult = insuranceCompanyListRepository.findByApprovedInsCompanyNameContainingIgnoreCase(searchParam);
            searchResult.forEach((insuranceCompanyList) -> {listofCompanyNames.add(mapper.toDTO(insuranceCompanyList)); });
        }catch (Exception e) {
            logger.error("Error occurred lookup Company Name" ,e.getMessage());
            throw new CtracException(e.getMessage());
        }
        return listofCompanyNames;
    }
}
