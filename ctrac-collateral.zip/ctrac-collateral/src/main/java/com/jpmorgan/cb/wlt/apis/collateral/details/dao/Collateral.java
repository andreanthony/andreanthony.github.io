package com.jpmorgan.cb.wlt.apis.collateral.details.dao;

import com.jpmorgan.cb.wlt.apis.collateral.types.CollateralType;
import com.jpmorgan.cb.wlt.dao.Address;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "TLCP_COLLATERAL")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Collateral extends AuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "collateralSeqGenerator")
    @TableGenerator(name = "collateralSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_COLLATERAL", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Column(name = "RID")
    private Long rid;

    @Column(name = "COLLATERAL_TYPE")
    private String collateralTypeCode;

    @Column(name = "COLLATERAL_SUB_TYPE")
    private String collateralSubTypeCode;

    @Column(name = "COLLATERAL_STATUS")
    private String collateralStatus;

    @Transient
    private String marketEmailAddress;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="EMAIL_RID")
    private EmailDetails emailDetails;

    @Column(name = "RELEASE_DATE")
    private Date releaseDate;

    @Column(name = "ADMIN_COMMENTS")
    private String adminComments;

    @Column(name = "LEGAL_DESCRIPTION")
    private String collateralDescription;

    @Column(name = "RELEASE_COMMENT")
    private String releaseComments;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "PHYSICAL_ADDRESS_ID")
    private Address collateralAddress;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getCollateralTypeCode() {
        return collateralTypeCode;
    }

    public void setCollateralTypeCode(CollateralType collateralType) {
        this.collateralTypeCode = collateralType.getCode();
    }

    public void setCollateralTypeCode(String collateralTypeCode) {
        this.collateralTypeCode = collateralTypeCode;
    }

    public String getCollateralSubTypeCode() {
        return collateralSubTypeCode;
    }

    public void setCollateralSubTypeCode(String collateralSubTypeCode) {
        this.collateralSubTypeCode = collateralSubTypeCode;
    }

    public String getCollateralStatus() {
        return collateralStatus;
    }

    public void setCollateralStatus(String collateralStatus) {
        this.collateralStatus = collateralStatus;
    }

    public String getMarketEmailAddress() {
        return marketEmailAddress;
    }

    public void setMarketEmailAddress(String marketEmailAddress) {
        this.marketEmailAddress = marketEmailAddress;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getAdminComments() {
        return adminComments;
    }

    public void setAdminComments(String adminComments) {
        this.adminComments = adminComments;
    }

    public String getCollateralDescription() {
        return collateralDescription;
    }

   public void setCollateralDescription(String collateralDescription) {
        this.collateralDescription = collateralDescription;
    }

    public String getReleaseComments() {
        return releaseComments;
    }

    public void setReleaseComments(String releaseComments) {
        this.releaseComments = releaseComments;
    }

    public Address getCollateralAddress() {
        return collateralAddress;
    }

    public void setCollateralAddress(Address collateralAddress) {
        this.collateralAddress = collateralAddress;
    }

    public EmailDetails getEmailDetails() {
        return emailDetails;
    }

    public void setEmailDetails(EmailDetails emailDetails) {
        this.emailDetails = emailDetails;
    }
}
