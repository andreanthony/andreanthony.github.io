package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import io.swagger.annotations.ApiModelProperty;

import java.beans.Transient;
import java.util.Date;

public class C3RequiredCoverage extends C3Coverage {
    private static final long serialVersionUID = -1;
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    private String documentDate;
    private String cancellationEffectiveDate;
    private boolean newlyAdded = false;
    private boolean descoped = false;
    private C3Hold hold;
    private String propertyType;

    public String getDocumentDate() {
        return documentDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getDocumentDate_() {
        return DATE_FORMATTER.parse(documentDate);
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

    public String getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getCancellationEffectiveDate_() {
        return DATE_FORMATTER.parse(cancellationEffectiveDate);
    }

    public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
        this.cancellationEffectiveDate = cancellationEffectiveDate;
    }

    public boolean isNewlyAdded() {
        return newlyAdded;
    }

    public void setNewlyAdded(boolean newlyAdded) {
        this.newlyAdded = newlyAdded;
    }

    public boolean isDescoped() {
        return descoped;
    }

    public void setDescoped(boolean descoped) {
        this.descoped = descoped;
    }

    public C3Hold getHold() {
        return hold;
    }

    public void setHold(C3Hold hold) {
        this.hold = hold;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getHoldStartDate() {
        return hold == null ? null : hold.getHoldStartDate();
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getHoldLpiDate() {
        return hold == null? null : hold.getHoldLpiDate();
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean hasNewHold() {
        return hold != null && hold.isNewHold();
    }
}
