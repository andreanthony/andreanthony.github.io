package com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository;

import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralRequiredCoverage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GeneralRequiredCoverageRepository extends JpaRepository<GeneralRequiredCoverage, Long> {


}
