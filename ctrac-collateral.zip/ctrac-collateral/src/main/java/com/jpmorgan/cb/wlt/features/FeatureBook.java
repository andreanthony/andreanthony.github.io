package com.jpmorgan.cb.wlt.features;

public enum FeatureBook {

    @FeatureLabel("Placeholder for future features")
    FEATURE_PLACEHOLDER

}
