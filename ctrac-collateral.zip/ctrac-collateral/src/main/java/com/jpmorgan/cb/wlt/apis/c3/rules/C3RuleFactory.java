package com.jpmorgan.cb.wlt.apis.c3.rules;

import java.util.List;

public interface C3RuleFactory {
    List<C3Rule> getC3Rules();
}
