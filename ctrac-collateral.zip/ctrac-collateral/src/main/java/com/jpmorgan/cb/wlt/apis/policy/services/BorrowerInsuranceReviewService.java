package com.jpmorgan.cb.wlt.apis.policy.services;

import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;

import java.util.Map;

public interface BorrowerInsuranceReviewService {
    public Map<String, BIRRuleConclusionDTO> getBorrowerPolicyConclusions(PolicyDTO policyDTO);
}
