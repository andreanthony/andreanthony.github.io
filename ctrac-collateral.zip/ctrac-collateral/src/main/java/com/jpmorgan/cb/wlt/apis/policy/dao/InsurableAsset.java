package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "TLCP_INSURABLE_ASSET")
public class InsurableAsset extends AuditableEntity {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "insurableAssetSeqGenerator")
    @TableGenerator(name = "insurableAssetSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_INSURABLE_ASSET", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "ASSET_TYPE")
    protected String assetType;

    @Column(name = "SORT_ORDER")
    private Integer sortOrder;

    @Column(name = "FLOOD_ZONE")
    private String floodZone;

    @ManyToOne
    @JoinColumn(name = "BUILDING_RID", nullable = false)
    private Building building;

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "insurableAsset", orphanRemoval = true)
    private List<RequiredCoverage> requiredCoverages = new ArrayList<RequiredCoverage>();

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "insurableAsset", orphanRemoval = true)
    private List<ProvidedCoverage> providedCoverages = new ArrayList<ProvidedCoverage>();

    public InsurableAsset() {
        super();
    }

    public InsurableAsset(InsurableAssetType assetType) {
        super();
        this.assetType = assetType != null ? assetType.name() : null;
    }

    public void addRequiredCoverage(RequiredCoverage requiredCoverage) {
        if(requiredCoverage.getRid()!=null && requiredCoverages.contains(requiredCoverage)){
            requiredCoverages.remove(requiredCoverage);
        }
        requiredCoverages.add(requiredCoverage);
        requiredCoverage.setInsurableAsset(this);
    }

    public void removeRequiredCoverage(RequiredCoverage requiredCoverage) {
        requiredCoverage.setInsurableAsset(null);
        requiredCoverages.remove(requiredCoverage);
    }

    public void addProvidedCoverage(ProvidedCoverage providedCoverage) {

        if(providedCoverage.getRid()!=null && providedCoverages.contains(providedCoverage)){
            providedCoverages.remove(providedCoverage);
        }
        providedCoverages.add(providedCoverage);
        providedCoverage.setInsurableAsset(this);
    }

    public void removeProvidedCoverage(ProvidedCoverage providedCoverage) {
        providedCoverage.setInsurableAsset(null);
        providedCoverages.remove(providedCoverage);
    }

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    public String getAssetType() {
        return assetType;
    }

    public InsurableAssetType getAssetType_(){
        InsurableAssetType result = null;
        try {
            result = InsurableAssetType.valueOf(assetType);
        } catch (Exception swallow) {}

        return result;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public Building getBuilding() {
        return building;
    }

    public void setBuilding(Building building) {
        this.building = building;
    }

    public List<RequiredCoverage> getRequiredCoverages() {
        return requiredCoverages;
    }

    public List<ProvidedCoverage> getProvidedCoverages() {
        return providedCoverages;
    }

    public String getFloodZone() {
        return floodZone;
    }

    public void setFloodZone(String floodZone) {
        this.floodZone = floodZone;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((rid == null) ? 0 : rid.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        InsurableAsset other = (InsurableAsset) obj;
        if (rid == null) {
            if (other.rid != null)
                return false;
        } else if (!rid.equals(other.rid))
            return false;
        return true;
    }

    public String getPropertyType(){
        String result=null;
        if(this.requiredCoverages!=null && this.requiredCoverages.size()>0){

            result =requiredCoverages.get(0).getPropertyType();
            //Try to get the property type from the latest Fiat; for now, we assume the pending verification has the highest priority
            for(RequiredCoverage requiredCoverage : requiredCoverages ){
                RequiredCoverageSource covsource = requiredCoverage.getRequiredCoverageSource();
                if(VerificationStatus.PENDING_VERIFICATION.name().equals(covsource.getStatus())){
                    return requiredCoverage.getPropertyType();
                }else if(VerificationStatus.VERIFIED.name().equals(covsource.getStatus())){
                    result = requiredCoverage.getPropertyType();
                }
            }
        }
        return result;
    }
}