package com.jpmorgan.cb.wlt.apis.c3.dtos;

import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.StringUtils;

import java.beans.Transient;
import java.io.Serializable;

public class C3FloodDetermination implements Serializable {
    private static final long serialVersionUID = -1;
    private String floodZone;
    private String dateOfMapChange;

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isInHighRiskFloodZone() {
        return StringUtils.isNotBlank(floodZone) &&
                (floodZone.toUpperCase().trim().startsWith("A") || floodZone.toUpperCase().trim().startsWith("V"));
    }

    public String getFloodZone() {
        return floodZone;
    }

    public void setFloodZone(String floodZone) {
        this.floodZone = floodZone;
    }

    public String getDateOfMapChange() {
        return dateOfMapChange;
    }

    public void setDateOfMapChange(String dateOfMapChange) {
        this.dateOfMapChange = dateOfMapChange;
    }
}
