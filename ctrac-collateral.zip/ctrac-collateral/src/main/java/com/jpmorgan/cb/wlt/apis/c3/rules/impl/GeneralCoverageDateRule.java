package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3CalculatedCoverageDateBuilder;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;

import java.util.Date;
import java.util.List;

public class GeneralCoverageDateRule extends AbstractCoverageDateRule {

    protected InsuranceType getInsuranceType() {
        return InsuranceType.GENERAL;
    }

    @Override
    protected List<C3CalculatedCoverageDate> getC3CalculatedCoverageDates(C3ResponseDTO c3ResponseDTO) {
        return c3ResponseDTO.getCalculatedGeneralCoverageDates();
    }

    @Override
    void addCalculatedCoverageDate(List<C3CalculatedCoverageDate> calculatedCoverageDates, Date date, C3Coverage c3Coverage) {
        calculatedCoverageDates.add(new C3CalculatedCoverageDateBuilder(InsuranceType.GENERAL.name(), date)
                .coverageType(c3Coverage.getCoverageType())
                .build());

    }

    @Override
    protected Date getOverrideCalculatedCoverageDate(C3RequestDTO c3RequestDTO) {
        return c3RequestDTO.getOverrideGeneralCoverageDate_();
    }

    @Override
    protected void addCalculatedCoverageDates(List<C3CalculatedCoverageDate> calculatedCoverageDates, Date coverageDate, C3Policy policy) {
        policy.getProvidedCoverages().forEach(providedCoverage -> {
            String coverageType = providedCoverage.getCoverageType();
            calculatedCoverageDates.add(new C3CalculatedCoverageDateBuilder(InsuranceType.GENERAL.name(), coverageDate)
                    .coverageType(coverageType)
                    .policyId(policy.getPolicyId())
                    .build());
        });
    }

}
