package com.jpmorgan.cb.wlt.apis.policy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CollateralInsuranceRepository extends JpaRepository<CollateralInsuranceViewData, CollateralInsuranceViewDataPK> {

    List<CollateralInsuranceViewData> findByCollateralRid(Long collateralRid);

    List<CollateralInsuranceViewData> findByCollateralRidOrderByProofOfCoverageExpirationDateAsc(Long collateralRid);

    List<CollateralInsuranceViewData> findByProofOfCoverageRid(Long proofOfCoverageRid);

    List<CollateralInsuranceViewData> findByCollateralRidAndProofOfCoveragePolicyStatusIn(Long collateralRid, List<String> policyStatuses);

}
