package com.jpmorgan.cb.wlt.apis.policy.dao.populators;

import com.jpmorgan.cb.wlt.dao.ContactDetails;
import com.jpmorgan.cb.wlt.dao.DaoAuditDataPopulator;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

public class ContactDetailsAuditPopulator implements DaoAuditDataPopulator<ContactDetails,UserRequestInfo> {

    @Override
    public void populateAuditInfo(ContactDetails source, UserRequestInfo userRequestInfo) {
        source.setAuditInfo(userRequestInfo);

        if(source.getAddress() != null){
            source.getAddress().setAuditInfo(userRequestInfo);
        }

    }
}
