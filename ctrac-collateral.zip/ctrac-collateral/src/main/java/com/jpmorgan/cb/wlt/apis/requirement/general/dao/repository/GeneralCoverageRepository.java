package com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository;

import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralCoverage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GeneralCoverageRepository extends JpaRepository<GeneralCoverage, Long> {
    GeneralCoverage findByCoverageType(String coverageType);
}
