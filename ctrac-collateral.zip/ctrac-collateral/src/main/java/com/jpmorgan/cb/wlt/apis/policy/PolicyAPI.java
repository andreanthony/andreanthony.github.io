package com.jpmorgan.cb.wlt.apis.policy;

import com.jpmorgan.cb.wlt.apis.policy.dtos.InsuranceCompanyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.OverrideLpPolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyGatewayService;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyService;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.apis.upload.services.FileUploadService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cb.wlt.apis.policy.services.InsuranceCompanyService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@Secured(CtracRole.ROLE_READER)
@RequestMapping(value = "/api/policies")
public class PolicyAPI {
    private PolicyGatewayService policyGatewayService;
    private PolicyService policyService;
    private FileUploadService fileUploadService;
    private InsuranceCompanyService insuranceCompanyService;

    @Autowired
    public PolicyAPI(PolicyGatewayService policyGatewayService,
                     PolicyService policyService, FileUploadService fileUploadService, InsuranceCompanyService insuranceCompanyService) {
        assert(policyGatewayService != null);
        this.policyGatewayService = policyGatewayService;
        assert(policyService != null);
        this.policyService = policyService;
        assert(fileUploadService != null);
        this.fileUploadService = fileUploadService;
        assert(insuranceCompanyService != null);
        this.insuranceCompanyService = insuranceCompanyService;
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<PolicyDTO> createPolicy(@RequestBody PolicyDTO policyDTO,
                                                  @RequestAttribute UserRequestInfo userRequestInfo) {
        List<FileUploadAttachmentDTO> filesUploaded = fileUploadService
                .getAttachments(policyDTO.getUploadBucketName());
        try{
            return ResponseEntity.ok(policyGatewayService.createPolicy(policyDTO, filesUploaded, userRequestInfo));
        }
        finally {
            if(CollectionUtils.isNotEmpty(filesUploaded)) {
                fileUploadService.deleteAllAttachments(policyDTO.getUploadBucketName());
            }
        }
    }

    @RequestMapping(value = "general", method = RequestMethod.GET)
    public ResponseEntity<List<PolicyDTO>> getPolicies(@RequestParam Long collateralId,
                                                       @RequestParam (required = false) Boolean active,
                                                       @RequestAttribute UserRequestInfo userRequestInfo) {
        return ResponseEntity.ok(policyService.getGeneralPolicies(collateralId, active));
    }

    @RequestMapping(value = "/{policyId}", method = RequestMethod.GET)
    public ResponseEntity<PolicyDTO> getPolicy(@PathVariable Long policyId, @RequestAttribute UserRequestInfo userRequestInfo) {
        return ResponseEntity.ok(policyService.getPolicy(policyId));
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/{policyId}", method = RequestMethod.POST)
    public ResponseEntity<PolicyDTO> editPolicy(@PathVariable Long policyId, @RequestBody PolicyDTO policyDTO
            , @RequestAttribute UserRequestInfo userRequestInfo) {
        List<FileUploadAttachmentDTO> filesUploaded = fileUploadService
                .getAttachments(policyDTO.getUploadBucketName());
        try{
            return ResponseEntity.ok(policyGatewayService.editPolicy(policyId, policyDTO, filesUploaded, userRequestInfo));
        }
        finally {
            if(CollectionUtils.isNotEmpty(filesUploaded)) {
                fileUploadService.deleteAllAttachments(policyDTO.getUploadBucketName());
            }
        }
    }

    @Secured(CtracRole.ROLE_ADMIN)
    @RequestMapping(value = "/{policyId}/override", method = RequestMethod.POST)
    public ResponseEntity<PolicyDTO> overridePolicy(@PathVariable Long policyId, @RequestBody OverrideLpPolicyDTO overrideLpPolicyDTO
            , @RequestAttribute UserRequestInfo userRequestInfo) {
        return ResponseEntity.ok(policyGatewayService.overridePolicy(policyId, overrideLpPolicyDTO, userRequestInfo));

    }

    @Secured(CtracRole.ROLE_VERIFIER)
    @RequestMapping(value = "/{policyId}/verify", method = RequestMethod.POST)
    public ResponseEntity<PolicyDTO> verifyPolicy(@PathVariable Long policyId, @RequestBody PolicyDTO policyDTO,
                                                  @RequestAttribute UserRequestInfo userRequestInfo) {
        return ResponseEntity.ok(policyGatewayService.verifyPolicy(policyId, policyDTO, userRequestInfo));
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/{policyId}", method = RequestMethod.DELETE)
    public ResponseEntity deletePolicy(@PathVariable Long policyId, @RequestAttribute UserRequestInfo userRequestInfo) {
        policyService.deletePolicy(policyId, userRequestInfo);
        return ResponseEntity.ok().build();
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/review",method = RequestMethod.POST)
    public ResponseEntity<Map<String, BIRRuleConclusionDTO>> reviewPolicy(@RequestBody PolicyDTO policyDTO) {
        return ResponseEntity.ok(policyGatewayService.reviewPolicy(policyDTO));
    }

    @Secured(CtracRole.ROLE_READER)
    @RequestMapping(value = "/getCompanyListNames/{searchParam}",method = RequestMethod.GET)
    public ResponseEntity<List<InsuranceCompanyDTO>> getByCompanyList(@PathVariable String searchParam) {
        return ResponseEntity.ok(insuranceCompanyService.getListofInsuranceCompanyNames(searchParam));
    }


}