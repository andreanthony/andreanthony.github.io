package com.jpmorgan.cb.wlt.apis.upload;

import com.jpmorgan.cb.wlt.apis.upload.dtos.FileAttachmentDeletedResponse;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentSummaryDTO;
import com.jpmorgan.cb.wlt.apis.upload.services.FileUploadService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/fileUpload/bucket")
public class FileUploadAPI {

    private FileUploadService attachmentService;

    @Autowired
    public FileUploadAPI(FileUploadService attachmentService) {
        assert(attachmentService != null);
        this.attachmentService = attachmentService;
    }

    @RequestMapping(value = "/{bucketId}", method = RequestMethod.GET)
    public ResponseEntity<List<FileUploadAttachmentSummaryDTO>> getAttachmentsSummary(
            @PathVariable("bucketId") String bucketId) {
        return ResponseEntity.ok(attachmentService.getAttachmentsSummary(bucketId));
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/{bucketId}/category/{bucketCategory}", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<List<FileUploadAttachmentSummaryDTO>> uploadFileToBucket(
            @PathVariable("bucketCategory") String bucketCategory,
            @PathVariable("bucketId") String bucketId,
            @RequestPart(name ="files") MultipartFile[] files) {
        return ResponseEntity.ok(attachmentService.storeAttachments(bucketId, bucketCategory ,files));
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/{bucketId}", method = RequestMethod.DELETE)
    public ResponseEntity<FileAttachmentDeletedResponse> deleteAllAttachmentsFromBucket(
            @PathVariable("bucketId") String bucketId) {
        return ResponseEntity.ok(attachmentService.deleteAllAttachments(bucketId));
    }

}
