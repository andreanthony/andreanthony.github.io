package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3CalculatedCoverageDate;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3AlertEmailBuilder;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.enums.C3AlertEmailTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class AlertLenderPlaceRestrictionRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(AlertLenderPlaceRestrictionRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        List<C3CalculatedCoverageDate> allCalculatedCoverageDates = c3ResponseDTO.getAllCalculatedCoverageDates();
        allCalculatedCoverageDates.forEach(calculatedCoverageDate -> {
            C3Policy lpPolicy = c3RequestDTO.getLpPolicy(
                    calculatedCoverageDate.getCoverageType(), calculatedCoverageDate.getInsurableAssetId());
            if (lpPolicy != null
                    && c3RequestDTO.isInsuranceTypeRequested(lpPolicy.getInsuranceType_())
                    && lpPolicy.isInactiveOn(calculatedCoverageDate.getCoverageDate())) {
                addAlertEmail(C3AlertEmailTemplate.INACTIVE_LP_POLICY, c3ResponseDTO, calculatedCoverageDate, lpPolicy,c3RequestDTO.getCollateralRid());
                calculatedCoverageDate.setValid(false);
                logger.debug("AlertLenderPlaceRestrictionRule - alert email sent for email template {} and policy {}",C3AlertEmailTemplate.INACTIVE_LP_POLICY,lpPolicy.getPolicyId());
            } else if (lpPolicy != null && lpPolicy.isAfter(calculatedCoverageDate.getCoverageDate())) {
                addAlertEmail(C3AlertEmailTemplate.SUBSEQUENT_LP_POLICY, c3ResponseDTO, calculatedCoverageDate, lpPolicy,c3RequestDTO.getCollateralRid());
                logger.debug("AlertLenderPlaceRestrictionRule - alert email sent for email template {} and policy {}",C3AlertEmailTemplate.SUBSEQUENT_LP_POLICY,lpPolicy.getPolicyId());
                calculatedCoverageDate.setCoverageDate(lpPolicy.getEffectiveDate_());
            }
        });
    }

    private void addAlertEmail(C3AlertEmailTemplate alertEmailTemplate, C3ResponseDTO c3ResponseDTO,
                               C3CalculatedCoverageDate calculatedCoverageDate, C3Policy c3Policy, Long collateralRid) {
        c3ResponseDTO.getAlertEmails().add(new C3AlertEmailBuilder(alertEmailTemplate)
                .calculatedCoverageDate(calculatedCoverageDate).lpPolicyId(c3Policy.getPolicyId()).collateralRid(collateralRid).build());
    }
}
