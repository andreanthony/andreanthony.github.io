package com.jpmorgan.cb.wlt.apis.policy.services.impl;

public enum PolicyReasonForVerification {
	OTHER,
	CANCELATION_DATE_ENTERED
}
