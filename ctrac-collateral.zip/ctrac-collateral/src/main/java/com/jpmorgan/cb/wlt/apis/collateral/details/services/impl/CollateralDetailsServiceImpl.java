package com.jpmorgan.cb.wlt.apis.collateral.details.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralStatus;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.CollateralRepository;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.EmailDetailsRepository;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralValidationService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.VerifyCollateralEventDto;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CollateralDetailsServiceImpl implements CollateralDetailsService {

    private ModelMapper modelMapper;
    private CollateralRepository collateralRepository;
    private CollateralSectionService collateralSectionService;
    private CollateralValidationService collateralValidationService;
    private PublishEventService publishEventService;
    private EmailDetailsRepository emailDetailsRepository;


    @Autowired
    public CollateralDetailsServiceImpl(ModelMapper modelMapper , CollateralRepository collateralRepository , CollateralSectionService collateralSectionService
            , CollateralValidationService collateralValidationService, PublishEventService publishEventService , EmailDetailsRepository emailDetailsRepository) {
        assert(modelMapper != null);
        this.modelMapper = modelMapper;
        assert(collateralRepository != null);
        this.collateralRepository = collateralRepository;
        assert(collateralSectionService != null);
        this.collateralSectionService = collateralSectionService;
        assert(collateralValidationService != null);
        this.collateralValidationService = collateralValidationService;
        assert(publishEventService != null);
        this.publishEventService = publishEventService;
        assert(emailDetailsRepository != null);
        this.emailDetailsRepository = emailDetailsRepository;
    }

    @Override
    public CollateralDTO getCollateralDetails(Long collateralId) {
        Optional<Collateral> collateral = collateralRepository.findById(collateralId);
        if (!collateral.isPresent()) {
            return null;
        }
        return modelMapper.map(collateral.get(), CollateralDTO.class);
    }
    @Override
    public CollateralDTO pledgeCollateral(Long collateralRid, UserRequestInfo userRequestInfo)
    {
        if(collateralSectionService.areBasicSectionsVerified(collateralRid))
        {
            Collateral collateral = collateralRepository.getOne(collateralRid);
            collateral.setCollateralStatus(CollateralStatus.PLEDGED.name());
            collateralRepository.save(collateral);
        }
        return getCollateralDetails(collateralRid);
    }

    @Override
    public void submitForVerification(Long collateralId, UserRequestInfo userRequestInfo) {
        Optional<Collateral> collateralList=collateralRepository.findById(collateralId);
        Collateral collateral=collateralList.get();
        CollateralDTO collateralDTO=modelMapper.map(collateral,CollateralDTO.class);
        collateralValidationService.validateSubmitForVerification(collateralDTO);
        collateralSectionService.advanceAllSections(collateralDTO);
        publishEventService.publishEvent(new VerifyCollateralEventDto(collateralId));
    }

}
