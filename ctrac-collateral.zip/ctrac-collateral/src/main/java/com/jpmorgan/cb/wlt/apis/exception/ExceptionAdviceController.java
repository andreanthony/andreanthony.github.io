package com.jpmorgan.cb.wlt.apis.exception;

import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class ExceptionAdviceController {

    private static final Logger logger = LoggerFactory.getLogger(ExceptionAdviceController.class);

    @ExceptionHandler(CtracException.class)
    public ResponseEntity<ExceptionDTO> handleCtracException(CtracException e) {
        logger.debug(e.getMessage(), e);
        return ResponseEntity.badRequest().body(new ExceptionDTO(e.getMessage()));
    }

    @ExceptionHandler({ AccessDeniedException.class })
    public ResponseEntity<Object> handleAccessDeniedException(
            Exception ex, WebRequest request) {
        logger.debug(ex.getMessage(), ex);
        return new ResponseEntity<>(
                "Unauthorized - User does not have the role to perform this operation", new HttpHeaders(), HttpStatus.UNAUTHORIZED);
    }


    @ExceptionHandler(Exception.class)
    public ResponseEntity<ExceptionDTO> handleCtracException(Exception e) {
        logger.debug(e.getMessage(), e);
        return ResponseEntity.badRequest().body(new ExceptionDTO("Unexpected error occurred. If the error continues, please raise a support ticket."));
    }
}