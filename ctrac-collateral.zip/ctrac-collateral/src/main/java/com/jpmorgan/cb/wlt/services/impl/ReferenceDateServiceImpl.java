package com.jpmorgan.cb.wlt.services.impl;

import com.jpmorgan.cb.wlt.dao.BankHolidays;
import com.jpmorgan.cb.wlt.dao.BankHolidaysRepository;
import com.jpmorgan.cb.wlt.dao.ReferenceDate;
import com.jpmorgan.cb.wlt.dao.ReferenceDateRepository;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import org.apache.commons.lang.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class ReferenceDateServiceImpl implements ReferenceDateService {

    static final String REFERENCE_DATE = "APP_REFERENCE_DATE";
    private static final Character ENABLED_FLAG ='Y';
    private static final String USA_CALENDAR ="US";

    private ReferenceDateRepository referenceDateRepository;
    private BankHolidaysRepository bankHolidaysRepository;

    @Autowired
    public ReferenceDateServiceImpl(ReferenceDateRepository referenceDateRepository, BankHolidaysRepository bankHolidaysRepository) {
        assert (referenceDateRepository != null);
        this.referenceDateRepository = referenceDateRepository;
        assert (bankHolidaysRepository != null);
        this.bankHolidaysRepository = bankHolidaysRepository;
    }

    @Override
    public Date getCurrentReferenceDate() {
        ReferenceDate referenceDate = referenceDateRepository.findByName(REFERENCE_DATE);
        return new DateTime(referenceDate.getReferenceDate()).toDate();
    }

    /**
     * determine if the @calendarDay is a business day not inserted in JPMC
     * official holidays.
     */
    private boolean isWorkingDay(DateTime calendarDay) {
        if (DateTimeConstants.SATURDAY == calendarDay.getDayOfWeek() || DateTimeConstants.SUNDAY == calendarDay.getDayOfWeek()) {
            return false;
        }

        if (isTodayAHoliday(calendarDay, ENABLED_FLAG, USA_CALENDAR)) {
            return false;
        }
        return true;
    }

    private boolean isTodayAHoliday(DateTime calendarDay, Character enabled, String holidayCalendar) {
        List<BankHolidays> holidays = bankHolidaysRepository.findByHolidayDateAndHolidayActiveFlagAndHolidayCalendar(
                DateUtils.truncate(calendarDay.toDate(), Calendar.DATE), enabled, holidayCalendar);
        if (holidays == null) {
            return false;
        }
        if (holidays.isEmpty()) {
            return false;
        }
        if (holidays.size() == 0) {
            return false;
        }

        return true;

    }

    /**
     * @param businessDays the number of calendar days to add
     * @return the Date x number of business days in the future
     */
    @Override
    public Date addBusinessDays(int businessDays, Date start){

        DateTime fromDate = new DateTime(start);

        int counter = 0;
        while(counter < businessDays){

            fromDate = fromDate.plusDays(1);

            if(isWorkingDay(fromDate)){
                counter++;
            }
        }

        return fromDate.toDate();
    }

    @Override
    public Date addCalendarDays(int calendarDays, Date start){

        DateTime fromDate = new DateTime(start);
        fromDate = fromDate.plusDays(calendarDays);

        return fromDate.toDate();
    }

}
