package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.Agent;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProvidedCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyCollateralDetailsDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.dao.ContactDetails;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

public abstract class AbstractPolicyMapper implements DaoMapper<ProofOfCoverage, PolicyDTO> {

    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    @Override
    public PolicyDTO toDTO(ProofOfCoverage model) {
        PolicyDTO dto = new PolicyDTO();
        dto.setPolicyId(model.getRid());
        dto.setPolicyType(model.getPolicyType());
        dto.setPolicyStatus(model.getPolicyStatus() != null ? model.getPolicyStatus() : PolicyStatus.PENDING_VERIFICATION.name());
        dto.setIssuanceDate(DATE_FORMATTER.print(model.getIssuanceDate()));
        dto.setMigrated(model.getMigrated());
        dto.setReasonForVerification(model.getReasonForVerification());
        dto.setCancellationDate(DATE_FORMATTER.print(model.getCancellationEffectiveDate()));
        dto.setEffectiveDate(DATE_FORMATTER.print(model.getEffectiveDate()));
        dto.setExpirationDate(DATE_FORMATTER.print(model.getExpirationDate()));
        dto.setInsuranceCompanyName(model.getInsuranceAgency());
        dto.setPolicyNumber(model.getPolicyNumber());
        dto.setLpAction(model.getLpAction());
        dto.setInsuranceType(model.getInsuranceType());
        dto.fromAuditableEntityModel(model);

        //Map agent information
        if(model.getInsuranceAgent() != null && model.getInsuranceAgent().getContactDetails() != null) {
            dto.setAgentEmailAddress(model.getInsuranceAgent().getContactDetails().getEmailAddress());
            dto.setAgentPhoneNumber(model.getInsuranceAgent().getContactDetails().getPhoneNumber());
            dto.setAgentFaxNumber(model.getInsuranceAgent().getContactDetails().getFaxNumber());
        }

        if (CollectionUtils.isNotEmpty(model.getProvidedCoverages())) {
            Map<Long, PolicyCollateralDetailsDTO> policyCollateralDetailMap = new HashMap<>();
            model.getProvidedCoverages().forEach(providedCoverage -> {

                PolicyCollateralDetailsDTO policyCollateralDetailsDTO = policyCollateralDetailMap.get(providedCoverage.getCollateralId());

                PolicyInsuranceCoverageDTO policyInsuranceCoverageDTO = providedCoverage.toPolicyCollateralDetailsDTO();

                if(policyCollateralDetailsDTO == null){
                    policyCollateralDetailsDTO = new PolicyCollateralDetailsDTO();
                    policyCollateralDetailsDTO.setCollateralId(providedCoverage.getCollateralId());
                }

                if(policyInsuranceCoverageDTO.getInsuranceCoverageType() == null) {
                    policyInsuranceCoverageDTO.setInsuranceCoverageType(model.getCoverageType());
                }

                policyCollateralDetailsDTO.getInsuranceCoverages().add(policyInsuranceCoverageDTO);

                policyCollateralDetailMap.put(providedCoverage.getCollateralId(), policyCollateralDetailsDTO);
            });
            policyCollateralDetailMap.values().forEach(policyCollateralDetailsDTO -> dto.getCollateralCoverages().add(policyCollateralDetailsDTO));
            policyCollateralDetailMap.keySet().forEach(colId -> dto.getCollateralIds().add(colId));
        }

        if(CollectionUtils.isNotEmpty(model.getPolicyDocuments())) {
            model.getPolicyDocuments().forEach(policyDocument ->
                    dto.getPolicyDocuments()
                            .add(policyDocument.toCollateralDocumentDTO()
                                    .getCollateralDocumentSummary()));
        }

        return dto;
    }

    @Override
    public boolean map(PolicyDTO dto, ProofOfCoverage model) {
        if (dto.equals(toDTO(model))) {
            return false;
        }

        model.setRid(dto.getPolicyId());
        model.setPolicyType(dto.getPolicyType());
        // do not map policyStatus
        model.setReasonForVerification(dto.getReasonForVerification());
        model.setCancellationEffectiveDate(DATE_FORMATTER.parse(dto.getCancellationDate()));
        model.setEffectiveDate(DATE_FORMATTER.parse(dto.getEffectiveDate()));
        model.setExpirationDate(DATE_FORMATTER.parse(dto.getExpirationDate()));
        model.setInsuranceAgency(dto.getInsuranceCompanyName());
        model.setPolicyNumber(dto.getPolicyNumber());
        model.setLpAction(dto.getLpAction());
        if (dto.getLetterCycle() != null && dto.getLetterCycle().getBorrowerPolicyRid() != null) {
            model.setParentPolicyRid(dto.getLetterCycle().getBorrowerPolicyRid());
            model.setGapBorrowerPolicyRid(dto.getLetterCycle().getBorrowerPolicyRid());
        }
        if (model.getInsuranceAgent() == null) {
            Agent newAgent = new Agent();
            newAgent.setContactDetails(new ContactDetails());
            model.setInsuranceAgent(newAgent);
        }
        Agent agent = model.getInsuranceAgent();
        ContactDetails contactDetails = agent.getContactDetails();

        contactDetails.setEmailAddress(dto.getAgentEmailAddress());
        contactDetails.setPhoneNumber(dto.getAgentPhoneNumber());
        contactDetails.setFaxNumber(dto.getAgentFaxNumber());
        return true;
    }

    void mapPolicyCoverages(PolicyDTO dto, ProofOfCoverage model){
        List<ProvidedCoverage> newProvidedCoverages = new ArrayList<>();
        Set<Long> collateralRids = new HashSet<>();
        //Loop over all given DTO collateral coverages
        dto.getCollateralCoverages().forEach(policyCollateralDetailsDTO -> {
            collateralRids.add(policyCollateralDetailsDTO.getCollateralId());
            //Find Matching provided coverages for the current collateral
            List<ProvidedCoverage> matchingProvidedCoveragesByCollateral = model.getProvidedCoverages()
                    .stream()
                    .filter(providedCoverage -> providedCoverage.getCollateralId()
                            .equals(policyCollateralDetailsDTO.getCollateralId()))
                    .collect(Collectors.toList());

            //Loop over all Insurance DTO coverages for that collateral
            policyCollateralDetailsDTO.getInsuranceCoverages().forEach(policyInsuranceCoverageDTO -> {
                //Matching provided coverages for each coverage type
                Optional<ProvidedCoverage> matchingProvidedCoverage = findMatchingProvidedCoverage(matchingProvidedCoveragesByCollateral, policyInsuranceCoverageDTO);

                ProvidedCoverage providedCoverageToMapOn = matchingProvidedCoverage.orElse(new ProvidedCoverage());
                providedCoverageToMapOn.setCollateralId(policyCollateralDetailsDTO.getCollateralId());
                providedCoverageToMapOn.map(policyInsuranceCoverageDTO);
                providedCoverageToMapOn.setProofOfCoverage(model);

                if(!matchingProvidedCoverage.isPresent()){
                    newProvidedCoverages.add(providedCoverageToMapOn);
                }
            });
        });

        //Add the new created Provided Coverages to the Policy Model
        model.getProvidedCoverages().addAll(newProvidedCoverages);
        //Collect all the provided coverages from this policy that are linked to collateral rids
        // that are not part anymore of this policy submission and remove them
        List<ProvidedCoverage> providedCoveragesToRemove = model.getProvidedCoverages().stream().filter(providedCoverage ->
                !collateralRids.contains(providedCoverage.getCollateralId())).collect(Collectors.toList());
        if(CollectionUtils.isNotEmpty(providedCoveragesToRemove)) {
            model.getProvidedCoverages().removeAll(providedCoveragesToRemove);
        }
    }

    protected abstract Optional<ProvidedCoverage> findMatchingProvidedCoverage(
            List<ProvidedCoverage> providedCoverages, PolicyInsuranceCoverageDTO policyInsuranceCoverageDTO);

    protected String getCompositeKey(Long collateralId, Long assetSortOrder, String key) {
        String mapKey = key;
        if (assetSortOrder != null) {
            mapKey = assetSortOrder + "-" + mapKey;
        }
        if (collateralId != null) {
            mapKey = collateralId + "-" + mapKey;
        }
        return mapKey;
    }


}
