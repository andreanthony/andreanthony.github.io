package com.jpmorgan.cb.wlt.dao;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_CONTACT_DETAILS")
public class ContactDetails extends AuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "contactDetailsSeqGenerator")
    @TableGenerator(name = "contactDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_CONTACT_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Column(name = "RID")
    private Long rid;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "ADDRESS_ID")
    private Address address;

    @Column(name = "PHONE_NUMBER")
    private String phoneNumber;

    @Column(name = "EMAIL_ADDRESS")
    private String emailAddress;

    @Column(name = "FAX_NUMBER")
    private String faxNumber;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        ContactDetails that = (ContactDetails) o;

        return new EqualsBuilder()
                .append(rid, that.rid)
                .append(address, that.address)
                .append(phoneNumber, that.phoneNumber)
                .append(emailAddress, that.emailAddress)
                .append(faxNumber, that.faxNumber)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(address)
                .append(phoneNumber)
                .append(emailAddress)
                .append(faxNumber)
                .toHashCode();
    }

}
