package com.jpmorgan.cb.wlt.apis.requirement.general.services.impl;

import com.jpmorgan.cb.wlt.apis.lookup.dtos.LookupCodeDTO;
import com.jpmorgan.cb.wlt.apis.lookup.services.LookupCodeService;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageSourceDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralCoverageService;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralRequiredCoverageValidationService;
import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ValidationException;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.*;

@Service
public class GeneralRequiredCoverageValidationServiceImpl implements GeneralRequiredCoverageValidationService {

    private GeneralCoverageService generalCoverageService;
    private LookupCodeService lookupCodeService;

    @Autowired
    public GeneralRequiredCoverageValidationServiceImpl(
            GeneralCoverageService generalCoverageService, LookupCodeService lookupCodeService) {
        assert(generalCoverageService != null);
        this.generalCoverageService = generalCoverageService;
        assert(lookupCodeService != null);
        this.lookupCodeService = lookupCodeService;
    }

    @Override
    public void validateVerify(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                               GeneralRequiredCoverageSourceDTO pendingVerification) {
        List<String> messages = validateRequiredValues(generalRequiredCoverageSourceDTO);
        if(pendingVerification == null || pendingVerification.getRid().compareTo(generalRequiredCoverageSourceDTO.getRid()) != 0) {
            messages.add("status invalid");
        }
        if (!messages.isEmpty()) {
            throw new ValidationException().with(messages);
        }
    }

    @Override
    public void validateCreate(@Valid GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                               GeneralRequiredCoverageSourceDTO pendingVerification) {
        List<String> messages = validateRequiredValues(generalRequiredCoverageSourceDTO);
        if (pendingVerification != null) {
            messages.add("status invalid");
        }
        if (!messages.isEmpty()) {
            throw new ValidationException().with(messages);
        }
    }

    @Override
    public void validateEdit(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                             GeneralRequiredCoverageSourceDTO pendingVerification) {
        List<String> messages = validateRequiredValues(generalRequiredCoverageSourceDTO);
        if (!VerificationStatus.PENDING_VERIFICATION.name().equals(generalRequiredCoverageSourceDTO.getStatus()) ||
                (pendingVerification != null && pendingVerification.getRid().compareTo(generalRequiredCoverageSourceDTO.getRid()) != 0)) {
            messages.add("status invalid");
        }
        if (!messages.isEmpty()) {
            throw new ValidationException().with(messages);
        }
    }

    @Override
    public void validateDelete(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO, boolean canDelete) {
        if (generalRequiredCoverageSourceDTO == null) {
            throw new ValidationException("Cannot delete coverage source when it does not exist");
        }
        if (!canDelete) {
            throw new ValidationException("Cannot delete coverage source with id: " + generalRequiredCoverageSourceDTO.getRid());
        }
    }

    List<String> validateRequiredValues(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO) {
        List<String> messages = new ArrayList<>();
        Long collateralRid = generalRequiredCoverageSourceDTO.getCollateralRid();
        if (collateralRid == null || collateralRid == 0) {
            messages.add("collateralRid required");
        }
        else if (collateralRid < 0) {
            messages.add("collateralRid invalid");
        }
        if (generalRequiredCoverageSourceDTO.getDocumentDate() == null) {
            messages.add("documentDate required");
        }
        if (generalRequiredCoverageSourceDTO.getSource() == null) {
            messages.add("source required");
        } else if (!validSourceValue(generalRequiredCoverageSourceDTO.getSource())) {
            messages.add("Invalid source value provided");
        }
        if (generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages() == null ||
                generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages().isEmpty()) {
            messages.add("generalCoverages required");
        } else {
            messages.addAll(validateRequiredCoverages(generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages()));
        }
        return messages;
    }

    Boolean validSourceValue(String source) {
        List<LookupCodeDTO> lookupCodeDTOS = lookupCodeService.getByCodeset("GENERAL_COVERAGE_REQUIREMENT_SOURCE");
        return lookupCodeDTOS.stream().anyMatch(lookupCodeDTO -> lookupCodeDTO.getDescription().equals(source));
    }

    List<String> validateRequiredCoverages(List<GeneralRequiredCoverageDTO> generalRequiredCoverages) {
        List<String> messages = new ArrayList<>();
        List<GeneralCoverageDTO> generalCoverages = generalCoverageService.getGeneralCoverageTypes();
        List<LookupCodeDTO> balanceTypes = lookupCodeService.getByCodeset("GENERAL_COVERAGE_BALANCE_TYPE");
        messages.addAll(validateGeneralRequiredCoverageProperties(generalRequiredCoverages, generalCoverages, balanceTypes));
        messages.addAll(validateDuplicates(generalRequiredCoverages));
        messages.addAll(validateAtLeastOneCoverageInScope(generalRequiredCoverages));
        messages.addAll(validateDependencies(generalRequiredCoverages, generalCoverages));
        return messages;
    }

    List<String> validateGeneralRequiredCoverageProperties(List<GeneralRequiredCoverageDTO> generalRequiredCoverages,
                                                                   List<GeneralCoverageDTO> generalCoverages, List<LookupCodeDTO> balanceTypes) {
        List<String> messages = new ArrayList<>();
        for (GeneralRequiredCoverageDTO generalRequiredCoverageDTO: generalRequiredCoverages) {
            messages.addAll(validateGeneralCoverage(generalRequiredCoverageDTO, generalCoverages));
            if(BooleanUtils.isTrue(generalRequiredCoverageDTO.getIsDescoped())){
                messages.addAll(validateDescopedCoverage(generalRequiredCoverageDTO));
                continue;
            }
            if(generalRequiredCoverageDTO.getGeneralCoverageDTO() != null) {
                messages.addAll(validateGeneralCoverageRules(generalRequiredCoverageDTO));
            }
            if (!isValidAmount(generalRequiredCoverageDTO.getCoverageAmount(), true)) {
                messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": coverageAmount required");
            }
            if (StringUtils.isEmpty(generalRequiredCoverageDTO.getBalanceType())) {
                messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": balanceType required");
            } else if (!isValidBalanceType(generalRequiredCoverageDTO.getBalanceType(), balanceTypes)) {
                messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": balanceType invalid");
            }
        }
        return messages;
    }

    private List<String> validateDescopedCoverage(GeneralRequiredCoverageDTO generalRequiredCoverageDTO){
        List<String> messages = new ArrayList<>();
        if(!isAmountZero(generalRequiredCoverageDTO.getCoverageAmount())){
            messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": coverageAmount invalid");
        }
        if(!isAmountZero(generalRequiredCoverageDTO.getDeductibleAmount())){
            messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": deductible invalid");
        }
        if(!isAmountZero(generalRequiredCoverageDTO.getAggregateAmount())){
            messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": aggregate invalid");
        }
        if (StringUtils.isNotEmpty(generalRequiredCoverageDTO.getBalanceType())) {
            messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": balanceType invalid");
        }
        return messages;
    }

    Set<String> validateDuplicates(List<GeneralRequiredCoverageDTO> generalRequiredCoverages) {
        Set<String> messages = new HashSet<>();
        for (GeneralRequiredCoverageDTO generalRequiredCoverageDTO: generalRequiredCoverages) {
            for (GeneralRequiredCoverageDTO other: generalRequiredCoverages) {
                if (generalRequiredCoverageDTO != other &&
                        generalRequiredCoverageDTO.getGeneralCoverageRid().equals(other.getGeneralCoverageRid())) {
                    messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": coverageType duplicate");
                    break;
                }
             }
        }
        return messages;
    }

    List<String> validateGeneralCoverage(GeneralRequiredCoverageDTO generalRequiredCoverageDTO,
                                                      List<GeneralCoverageDTO> generalCoverages) {
        List<String> messages = new ArrayList<>();
        if (generalRequiredCoverageDTO.getGeneralCoverageRid() == null) {
            messages.add("generalCoverageRid required");
            return messages;
        }
        GeneralCoverageDTO generalCoverageDTO = getGeneralCoverageByRid(generalRequiredCoverageDTO.getGeneralCoverageRid(), generalCoverages);
        if (generalCoverageDTO == null) {
            messages.add("generalCoverageRid invalid");
            return messages;
        }
        generalRequiredCoverageDTO.setGeneralCoverageDTO(generalCoverageDTO);
        return messages;
    }

    List<String> validateGeneralCoverageRules(GeneralRequiredCoverageDTO generalRequiredCoverageDTO) {
        List<String> messages = new ArrayList<>();
        if (!isValidAmount(generalRequiredCoverageDTO.getAggregateAmount(),
                generalRequiredCoverageDTO.getGeneralCoverageDTO().isAggregateAmountRequired())) {
            messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": aggregateAmount required");
        }
        if (!isValidAmount(generalRequiredCoverageDTO.getDeductibleAmount(),
                generalRequiredCoverageDTO.getGeneralCoverageDTO().isDeductibleAmountRequired())) {
            messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": deductibleAmount required");
        }
        return messages;
    }

    List<String> validateAtLeastOneCoverageInScope(List<GeneralRequiredCoverageDTO> generalRequiredCoverages) {
        List<String> messages = new ArrayList<>();
        if (generalRequiredCoverages
                .stream().allMatch(generalRequiredCoverageDTO -> BooleanUtils.isTrue(generalRequiredCoverageDTO.getIsDescoped()))){
            messages.add("At least one coverage has to be in-scope");
        }
        return messages;
    }

    List<String> validateDependencies(List<GeneralRequiredCoverageDTO> generalRequiredCoverages, List<GeneralCoverageDTO> generalCoverages) {
        List<String> messages = new ArrayList<>();
        Map<String, Set<Long>> coverageGroups = buildCoverageGroups(generalCoverages);
        for (GeneralRequiredCoverageDTO generalRequiredCoverageDTO: generalRequiredCoverages) {
            String coverageGroup = generalRequiredCoverageDTO.getGeneralCoverageDTO().getCoverageGroup();
            if (coverageGroups.get(coverageGroup) != null && coverageGroups.get(coverageGroup).size() !=
                    getGeneralRequiredCoveragesByGroup(coverageGroup, generalRequiredCoverages).size()) {
                messages.add(generalRequiredCoverageDTO.getGeneralCoverageType() + ": Dependent coverage required");
            }
        }
        return messages;
    }

    Map<String, Set<Long>> buildCoverageGroups(List<GeneralCoverageDTO> generalCoverages) {
        Map<String, Set<Long>> coverageGroups = new HashMap<>();
        for (GeneralCoverageDTO generalCoverageDTO: generalCoverages) {
            String coverageGroup = generalCoverageDTO.getCoverageGroup();
            if( coverageGroups.get(coverageGroup) == null) {
                coverageGroups.put(coverageGroup, new HashSet<>());
            }
            coverageGroups.get(coverageGroup).add(generalCoverageDTO.getRid());
        }
        return coverageGroups;
    }

    List<GeneralRequiredCoverageDTO> getGeneralRequiredCoveragesByGroup(String coverageGroup,
                                                                        List<GeneralRequiredCoverageDTO> generalRequiredCoverages) {
        List<GeneralRequiredCoverageDTO> matchingGeneralRequiredCoverages = new ArrayList<>();
        for (GeneralRequiredCoverageDTO generalRequiredCoverageDTO: generalRequiredCoverages) {
            if (generalRequiredCoverageDTO.getGeneralCoverageDTO().getCoverageGroup().equals(coverageGroup)) {
                matchingGeneralRequiredCoverages.add(generalRequiredCoverageDTO);
            }
        }
        return matchingGeneralRequiredCoverages;
    }

    GeneralCoverageDTO getGeneralCoverageByRid(Long generalCoverageRid, List<GeneralCoverageDTO> generalCoverages) {
        for (GeneralCoverageDTO generalCoverageDTO: generalCoverages) {
            if (generalCoverageRid == generalCoverageDTO.getRid()) {
                return generalCoverageDTO;
            }
        }
        return null;
    }

    boolean isValidBalanceType(String balanceType, List<LookupCodeDTO> balanceTypes) {
        for (LookupCodeDTO lookupCodeDTO: balanceTypes) {
            if (lookupCodeDTO.getCode().equals(balanceType)) {
                return true;
            }
        }
        return false;
    }

    boolean isValidAmount(BigDecimal amount, boolean required) {
        return  !required && isAmountZero(amount) ||
                ObjectUtils.compare(amount, BigDecimal.ZERO) > 0;
    }

    private boolean isAmountZero(BigDecimal amount){
        return amount == null || ObjectUtils.compare(amount, BigDecimal.ZERO) == 0;
    }

}
