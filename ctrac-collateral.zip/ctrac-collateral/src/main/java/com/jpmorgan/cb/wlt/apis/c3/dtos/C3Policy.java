package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;

import java.beans.Transient;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class C3Policy implements Serializable {
    private static final long serialVersionUID = -1;
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    private Long policyId;
    private String policyType;
    private String policyStatus;
    private String insuranceType;
    private String effectiveDate;
    private String expirationDate;
    private String cancellationEffectiveDate;
    private List<C3ProvidedCoverage> providedCoverages = new ArrayList<>();
    //TODO: populate lpAction when reading from db
    private String lpAction;
    private Long gapBorrowerPolicyId;

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isApplicationOrBinder() {
        return getPolicyType_().isApplicationOrBinder();
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isNewlyExpired(Date currentReferenceDate) {
        return getPolicyStatus_().isActive(true) && isExpired(currentReferenceDate);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    private boolean isExpired(Date currentReferenceDate) {
        Date thisExpirationDate = getExpirationDate_();
        if (thisExpirationDate == null) {
            return true;
        }
        if (currentReferenceDate == null) {
            return false;
        }
        DateTime expirationDateTime = new DateTime(thisExpirationDate).withTimeAtStartOfDay();
        DateTime thisDateTime = new DateTime(currentReferenceDate).withTimeAtStartOfDay();
        return !thisDateTime.isBefore(expirationDateTime);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isEffectiveOn(Date coverageDate) {
        if (coverageDate == null) {
            return true;
        }
        if (StringUtils.isBlank(cancellationEffectiveDate)) {
            return isEffectiveOn(coverageDate, getExpirationDate_());
        }
        return isEffectiveOn(coverageDate, getCancellationEffectiveDate_());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    private boolean isEffectiveOn(Date coverageDate, Date endDate) {
        if (effectiveDate == null || endDate == null) {
            return false;
        }
        if (coverageDate == null) {
            return true;
        }
        DateTime effectiveDateTime = new DateTime(getEffectiveDate_()).withTimeAtStartOfDay();
        DateTime endDateTime = new DateTime(endDate).withTimeAtStartOfDay();
        DateTime thisDateTime = new DateTime(coverageDate).withTimeAtStartOfDay();
        return !effectiveDateTime.isAfter(thisDateTime) && thisDateTime.isBefore(endDateTime);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isInactiveOn(Date coverageDate) {
        return getPolicyStatus_().isInactive() &&
                !getEffectiveDate_().after(coverageDate) && !getExpirationDate_().before(coverageDate) &&
                (getCancellationEffectiveDate_() == null || !getCancellationEffectiveDate_().before(coverageDate));
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isAfter(Date coverageDate) {
        return getEffectiveDate_().after(coverageDate);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3ProvidedCoverage> getProvidedCoverages(Long insurableAssetId, FloodCoverageType coverageType) {
        return providedCoverages.stream()
                .filter(providedCoverage ->
                        insurableAssetId.equals(providedCoverage.getInsurableAssetId())
                        && (coverageType == null || coverageType == providedCoverage.getFloodCoverageType()))
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3ProvidedCoverage> getProvidedCoverages(String coverageType) {
    return providedCoverages.stream()
            .filter(providedCoverage -> coverageType.equals(providedCoverage.getCoverageType()))
            .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public C3ProvidedCoverage getFirstProvidedCoverage() {
        return providedCoverages.get(0);
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public String getPolicyType() {
        return policyType;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public PolicyType getPolicyType_() {
        return PolicyType.valueOf(policyType);
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getPolicyStatus() {
        return policyStatus;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public PolicyStatus getPolicyStatus_() {
        return PolicyStatus.valueOf(policyStatus);
    }

    public void setPolicyStatus(String policyStatus) {
        this.policyStatus = policyStatus;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public InsuranceType getInsuranceType_() {
        return InsuranceType.valueOf(insuranceType);
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getEffectiveDate_() {
        return DATE_FORMATTER.parse(effectiveDate);
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getExpirationDate_() {
        return DATE_FORMATTER.parse(expirationDate);
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = DATE_FORMATTER.print(adjustToEffectiveDate(expirationDate));
    }

    public String getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getCancellationEffectiveDate_() {
        return DATE_FORMATTER.parse(cancellationEffectiveDate);
    }

    public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
        this.cancellationEffectiveDate = DATE_FORMATTER.print(adjustToEffectiveDate(cancellationEffectiveDate));
    }

    private Date adjustToEffectiveDate(String endDate) {
        return getNullOrMax(DATE_FORMATTER.parse(endDate), this.getEffectiveDate_());
    }

    private Date getNullOrMax(Date date1, Date date2) {
        return date1 == null? null :
               date2 == null? date1 :
               date1.after(date2)? date1 : date2;
    }

    public List<C3ProvidedCoverage> getProvidedCoverages() {
        return providedCoverages;
    }

    public void setProvidedCoverages(List<C3ProvidedCoverage> providedCoverages) {
        this.providedCoverages = providedCoverages;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isNewlyAccepted() {
        LPAction lpActionEnum = getLpAction_();
        return PolicyStatus.ACCEPTED == this.getPolicyStatus_() &&
                (LPAction.NEW_BP == lpActionEnum || LPAction.PENDING_C3 == lpActionEnum);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isNewlyCancelled() {
        return PolicyStatus.CANCELLED == this.getPolicyStatus_() && LPAction.CANCEL_BP == getLpAction_();
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean hasMatchingCoverage(String coverageType, Long insurableAssetId) {
        return providedCoverages.stream()
                .anyMatch(providedCoverage -> isMatchingCoverage(coverageType, providedCoverage.getCoverageType())
                        && Objects.equals(insurableAssetId, providedCoverage.getInsurableAssetId()));
    }

    private boolean isMatchingCoverage(String coverageType, String coverageType1) {
        return Objects.equals(coverageType, coverageType1) || isMatchingFloodCoverage(coverageType, coverageType1);
    }

    private boolean isMatchingFloodCoverage(String coverageType, String coverageType1) {
        FloodCoverageType floodCoverageType = FloodCoverageType.forName(coverageType);
        return  floodCoverageType != null && floodCoverageType.isMatching(FloodCoverageType.forName(coverageType1));
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isProvidingCoverageOn(String coverageType, Long insurableAssetId, Date effectiveOn) {
        return hasMatchingCoverage(coverageType, insurableAssetId) && (effectiveOn == null || isEffectiveOn(effectiveOn));
    }

    public String getLpAction() {
        return lpAction;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public LPAction getLpAction_() {
        return EnumUtils.getEnum(LPAction.class, this.lpAction);
    }

    public void setLpAction(String lpAction) {
        this.lpAction = lpAction;
    }

    public Long getGapBorrowerPolicyId() {
        return gapBorrowerPolicyId;
    }

    public void setGapBorrowerPolicyId(Long gapBorrowerPolicyId) {
        this.gapBorrowerPolicyId = gapBorrowerPolicyId;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isExpiring() {
        return getPolicyStatus_().isExpiring();
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean hasMatchingCoverage(C3Policy c3Policy) {
        return c3Policy.getProvidedCoverages()
                .stream()
                .anyMatch(providedCoverage -> this.hasMatchingCoverage(
                        providedCoverage.getCoverageType(), providedCoverage.getInsurableAssetId()));
    }
}
