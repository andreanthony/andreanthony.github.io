package com.jpmorgan.cb.wlt.config;

import com.jpmorgan.cb.wlt.config.converters.DateToStringConverter;
import com.jpmorgan.cb.wlt.config.converters.StringToDateConverter;
import com.jpmorgan.cb.wlt.config.mappings.CollateralDetailsMapping;
import com.jpmorgan.cb.wlt.config.mappings.CreateCollateralDTOMapping;
import com.jpmorgan.cb.wlt.config.mappings.CustomerMapping;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.ResourceResolver;
import org.springframework.web.servlet.resource.ResourceResolverChain;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Configuration
public class ApplicationConfiguration {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        modelMapper.addConverter(new DateToStringConverter());
        modelMapper.addConverter(new StringToDateConverter());
        modelMapper.addMappings(CreateCollateralDTOMapping.getCreateRealEstateCollateralDTOMapping());
        modelMapper.addMappings(CreateCollateralDTOMapping.getCreateBusinessAssetsDTOMapping());
        modelMapper.addMappings(CollateralDetailsMapping.getRealEstateDetailMapping());
        modelMapper.addMappings(CollateralDetailsMapping.getBusinessAssetsDetailMapping());
        modelMapper.addMappings(CustomerMapping.getEntityDTOMapping());
        return modelMapper;
    }

    /**
     * Redirects every page to index.html
     */
    @Configuration
    public static class BrowserHistoryConfig implements WebMvcConfigurer {

        @Override
        public void addResourceHandlers(final ResourceHandlerRegistry registry) {
            registry.addResourceHandler("/**").addResourceLocations("classpath:/static/").setCachePeriod(3600)
                    .resourceChain(true).addResolver(new WebResourceResolver());
        }

        private class WebResourceResolver implements ResourceResolver {
            private final Resource index = new ClassPathResource("/static/index.html");

            private final List<String> handledExtensions = Arrays
                    .asList("html", "js", "json", "csv", "css", "png", "svg", "eot", "ttf", "woff", "appcache", "jpg",
                            "jpeg", "gif", "ico", "map", "woff2");

            private final List<String> ignoredPaths = Arrays.asList("api", "actuator", "cli");

            @Override
            public Resource resolveResource(final HttpServletRequest request, final String requestPath,
                                            final List<? extends Resource> locations, final ResourceResolverChain chain) {
                return resolve(requestPath, locations);
            }

            @Override
            public String resolveUrlPath(final String resourcePath, final List<? extends Resource> locations,
                                         final ResourceResolverChain chain) {
                final Resource resolvedResource = resolve(resourcePath, locations);
                if (resolvedResource == null) {
                    return null;
                }
                try {
                    return resolvedResource.getURL().toString();
                } catch (final IOException e) {
                    return resolvedResource.getFilename();
                }
            }

            private Resource resolve(final String requestPath, final List<? extends Resource> locations) {
                if (isIgnored(requestPath)) {
                    return null;
                }
                if (isHandled(requestPath)) {
                    return locations.stream().map(loc -> createRelative(loc, requestPath))
                            .filter(resource -> resource != null && resource.exists()).findFirst().orElse(null);
                }
                return index;
            }

            private Resource createRelative(final Resource resource, final String relativePath) {
                try {
                    return resource.createRelative(relativePath);
                } catch (final IOException e) {
                    return null;
                }
            }

            private boolean isIgnored(final String path) {
                return ignoredPaths.contains(path);
            }

            private boolean isHandled(final String path) {
                final String extension = StringUtils.getFilenameExtension(path);
                return handledExtensions.stream().anyMatch(ext -> ext.equals(extension));
            }
        }
    }

}
