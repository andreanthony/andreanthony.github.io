package com.jpmorgan.cb.wlt.apis.policy.dao.mappers;

import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.AbstractBirCollateralDetailsMapper;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.GeneralBirCollateralDetailsMapper;

public class BirCollateralDetailsMapperFactory {
    private BirCollateralDetailsMapperFactory() {}

    public static AbstractBirCollateralDetailsMapper getBirCollateralDetailsMapper(String insuranceType) {
        if ("GENERAL".equals(insuranceType)) {
            return new GeneralBirCollateralDetailsMapper();
        } else {
            // TODO: update with FLOOD
            return new GeneralBirCollateralDetailsMapper();
        }
    }
}
