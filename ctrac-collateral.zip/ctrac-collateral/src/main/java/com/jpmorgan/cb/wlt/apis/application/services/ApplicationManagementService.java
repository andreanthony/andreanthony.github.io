package com.jpmorgan.cb.wlt.apis.application.services;

import com.jpmorgan.cb.wlt.apis.application.dto.ApplicationInfoDTO;

public interface ApplicationManagementService {

    ApplicationInfoDTO getApplicationInfo();
}
