package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3PolicyCancellationUtil;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FloodZoneRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(FloodZoneRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        if (c3RequestDTO.getFloodDetermination() != null && !c3RequestDTO.getFloodDetermination().isInHighRiskFloodZone()) {
            c3ResponseDTO.addPoliciesToCancel(C3PolicyCancellationUtil.cancelLpPolicies(
                    c3RequestDTO.getFloodLpPolicies(),
                    c3RequestDTO.getFloodDetermination().getDateOfMapChange(),
                    CancellationReason.INSURANCE_NOT_NEEDED));
            c3RequestDTO.setFloodComplete(c3ResponseDTO);
        }
        logger.debug("FloodZoneRule - Number of policies to be cancelled : {} ",c3ResponseDTO.getPoliciesToCancel().size());
    }
}
