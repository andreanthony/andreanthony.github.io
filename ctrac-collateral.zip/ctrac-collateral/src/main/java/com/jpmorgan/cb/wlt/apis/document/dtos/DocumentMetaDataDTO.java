package com.jpmorgan.cb.wlt.apis.document.dtos;

import java.util.Date;

public class DocumentMetaDataDTO {

    private String docIdentifier;
    private Long collateralRid;
    private Date documentDate;

    private String userSid;

    public String getDocIdentifier() {
        return docIdentifier;
    }

    public void setDocIdentifier(String docIdentifier) {
        this.docIdentifier = docIdentifier;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public Date getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }

    public String getUserSid() {
        return userSid;
    }

    public void setUserSid(String userSid) {
        this.userSid = userSid;
    }
}
