package com.jpmorgan.cb.wlt.apis.collateral.details;

import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/collaterals")
public class CollateralAPI {

    private static final Logger logger = LoggerFactory.getLogger(CollateralAPI.class);

    private CollateralDetailsService collateralDetailsService;
    private CollateralSectionService collateralSectionService;

    @Autowired
    public CollateralAPI(
            CollateralDetailsService collateralDetailsService,
            CollateralSectionService collateralSectionService) {
        assert(collateralDetailsService != null);
        this.collateralDetailsService = collateralDetailsService;
        assert(collateralSectionService != null);
        this.collateralSectionService = collateralSectionService;
    }

    @RequestMapping(value = "/{collateralId}", method = RequestMethod.GET)
    public ResponseEntity<CollateralDTO> getCollateral(@PathVariable Long collateralId) {
        return ResponseEntity.ok(collateralDetailsService.getCollateralDetails(collateralId));
    }

    @Secured(CtracRole.ROLE_VERIFIER)
    @RequestMapping(value = "/{collateralId}/verify", method = RequestMethod.POST)
    public ResponseEntity<CollateralDTO> verifyCollateralDetailsSection(@PathVariable Long collateralId, @RequestAttribute UserRequestInfo userRequestInfo) {
        collateralSectionService.verify(collateralId, CollateralSection.COLLATERAL_BASIC_DETAILS, userRequestInfo);
        return getCollateral(collateralId);
    }

    @Secured(CtracRole.ROLE_API)
    @RequestMapping(value = "/{collateralId}/pledged", method = RequestMethod.POST)
    public ResponseEntity<CollateralDTO> pledgeCollateral(@PathVariable Long collateralId, @RequestAttribute UserRequestInfo userRequestInfo) {
       return ResponseEntity.ok( collateralDetailsService.pledgeCollateral(collateralId,userRequestInfo));
    }

    @Secured(CtracRole.ROLE_WRITER)
    @GetMapping("/{collateralId}/changeCollateralDraftToVerify")
    public ResponseEntity changeCollateralDraftToVerify(@PathVariable Long collateralId,@RequestAttribute UserRequestInfo userRequestInfo){
        collateralDetailsService.submitForVerification(collateralId,userRequestInfo);
        return ResponseEntity.ok().build();
    }

}
