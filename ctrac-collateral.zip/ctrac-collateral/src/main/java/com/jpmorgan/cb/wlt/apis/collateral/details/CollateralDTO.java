package com.jpmorgan.cb.wlt.apis.collateral.details;

import java.util.Date;

public class CollateralDTO {
    private Long rid;
    private String collateralTypeCode;
    private String collateralSubTypeCode;
    private String collateralStatus;
    private String collateralDescription;
    private String streetAddress;
    private String unitOrBuilding;
    private String county;
    private String city;
    private String state;
    private String zipCode;
    private String marketEmailAddress;
    private Date releaseDate;
    private String releaseComments;
    private String adminComments;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getCollateralTypeCode() {
        return collateralTypeCode;
    }

    public void setCollateralTypeCode(String collateralTypeCode) {
        this.collateralTypeCode = collateralTypeCode;
    }

    public String getCollateralSubTypeCode() {
        return collateralSubTypeCode;
    }

    public void setCollateralSubTypeCode(String collateralSubTypeCode) {
        this.collateralSubTypeCode = collateralSubTypeCode;
    }

    public String getCollateralStatus() {
        return collateralStatus;
    }

    public void setCollateralStatus(String collateralStatus) {
        this.collateralStatus = collateralStatus;
    }

    public String getCollateralDescription() {
        return collateralDescription;
    }

    public void setCollateralDescription(String collateralDescription) {
        this.collateralDescription = collateralDescription;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getUnitOrBuilding() {
        return unitOrBuilding;
    }

    public void setUnitOrBuilding(String unitOrBuilding) {
        this.unitOrBuilding = unitOrBuilding;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getMarketEmailAddress() {
        return marketEmailAddress;
    }

    public void setMarketEmailAddress(String marketEmailAddress) {
        this.marketEmailAddress = marketEmailAddress;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getReleaseComments() {
        return releaseComments;
    }

    public void setReleaseComments(String releaseComments) {
        this.releaseComments = releaseComments;
    }

    public String getAdminComments() {
        return adminComments;
    }

    public void setAdminComments(String adminComments) {
        this.adminComments = adminComments;
    }
}
