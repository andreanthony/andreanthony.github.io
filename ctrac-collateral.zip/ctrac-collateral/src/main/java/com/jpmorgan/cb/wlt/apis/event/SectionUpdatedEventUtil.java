package com.jpmorgan.cb.wlt.apis.event;

import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.CollateralScreenAction;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.SectionUpdatedEventDTO;

public class SectionUpdatedEventUtil {
    public static SectionUpdatedEventDTO build(Long collateralId, CollateralSection section, CollateralScreenAction action, UserRequestInfo userRequestInfo) {
        SectionUpdatedEventDTO sectionUpdatedEvent = new SectionUpdatedEventDTO();
        sectionUpdatedEvent.setCollateralId(collateralId);
        sectionUpdatedEvent.setPerformedBy(userRequestInfo.getUserSid());
        sectionUpdatedEvent.setCollateralSection(section.name());
        sectionUpdatedEvent.setAction(action.name());
        sectionUpdatedEvent.setEventType(CtracEventType.COLLATERAL_SECTION_UPDATED.getDisplayValue());
        return sectionUpdatedEvent;
    }
}
