package com.jpmorgan.cb.wlt.apis.collateral.sections;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public enum CollateralSection {
    COLLATERAL_BASIC_DETAILS,
    LOAN_BORROWER,
    FLOOD_HAZARD_DETERMINATION_FORM,
    FLOOD_REQUIRED_INSURANCE_COVERAGE,
    GENERAL_REQUIRED_INSURANCE_COVERAGE,
    FLOOD_INSURANCE_POLICIES,
    GENERAL_INSURANCE_POLICIES,
    WORKFLOW_DETAILS;


    public static Set<CollateralSection> getBasicCollateralSections(){
        return new HashSet<CollateralSection>(
                Arrays.asList(COLLATERAL_BASIC_DETAILS, LOAN_BORROWER)
        );
    }
}
