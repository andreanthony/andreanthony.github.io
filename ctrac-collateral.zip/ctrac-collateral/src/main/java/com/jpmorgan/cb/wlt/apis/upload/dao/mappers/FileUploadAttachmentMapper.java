package com.jpmorgan.cb.wlt.apis.upload.dao.mappers;

import com.jpmorgan.cb.wlt.apis.upload.dao.FileUploadAttachment;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentSummaryDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

public class FileUploadAttachmentMapper implements DaoMapper<FileUploadAttachment, FileUploadAttachmentDTO> {

    @Override
    public FileUploadAttachmentDTO toDTO(FileUploadAttachment model) {
        FileUploadAttachmentDTO dto = new FileUploadAttachmentDTO();
        FileUploadAttachmentSummaryDTO summaryDTO = new FileUploadAttachmentSummaryDTO();
        summaryDTO.setRid(model.getRid());
        summaryDTO.setBucketName(model.getBucketName());
        summaryDTO.setFileName(model.getFileName());
        dto.setFileContent(model.getFileContent());
        dto.setSummary(summaryDTO);
        return dto;
    }

    @Override
    public boolean map(FileUploadAttachmentDTO dto, FileUploadAttachment model) {
        if (dto.equals(toDTO(model))) {
            return false;
        }
        model.setBucketName(dto.getSummary() != null ? dto.getSummary().getBucketName(): null);
        model.setFileName(dto.getSummary() != null ? dto.getSummary().getFileName(): null);
        model.setFileContent(dto.getFileContent());
        return true;
    }
}
