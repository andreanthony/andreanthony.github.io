package com.jpmorgan.cb.wlt.apis.requirement.flood.dao.repository;

import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.RequiredCoverageView;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RequiredCoverageViewRepository extends JpaRepository<RequiredCoverageView,Long> {

    List<RequiredCoverageView> findByCollateralRid(Long collateralRid);
    List<RequiredCoverageView> findByCollateralRidAndStatus(Long collateralRid, String status);
}
