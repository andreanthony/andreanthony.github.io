package com.jpmorgan.cb.wlt.apis.loan.services;

public enum LoanStatus {
    PENDING_VERIFICATION("Pending Verification"),
    ACTIVE("Active"),
    RELEASED("Released");

    private final String displayName;

    LoanStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isActive() {
        return this == PENDING_VERIFICATION || this == ACTIVE;
    }

    public boolean isInactive() {
        return !isActive();
    }
}
