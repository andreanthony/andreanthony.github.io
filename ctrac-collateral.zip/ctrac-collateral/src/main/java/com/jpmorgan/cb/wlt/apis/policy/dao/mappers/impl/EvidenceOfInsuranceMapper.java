package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;

public class EvidenceOfInsuranceMapper {
    private EvidenceOfInsuranceMapper() {}

    public static PolicyType getPolicyType(String evidenceOfInsurance) {
        switch (evidenceOfInsurance) {
            case "DEC_PAGE":
                return PolicyType.DECLARATION_PAGE;
            case "POLICY":
                return PolicyType.GI_POLICY;
            case "NP":
                return PolicyType.NFIP;
            case "APPLICATION":
            case "AWP":
                return PolicyType.APPLICATION;
            case "BINDER":
            case "BWP":
                return PolicyType.BINDER;
            case "PP":
            case "PPTCSBAC":
                return PolicyType.PRIVATE;
            case "ACCORD":
            case "ANCAPYFPOF":
            case "AWCONPYFPOF":
                return PolicyType.ACCORD;
            default:
                //TODO: Throw exception
                return null;
        }
    }
}
