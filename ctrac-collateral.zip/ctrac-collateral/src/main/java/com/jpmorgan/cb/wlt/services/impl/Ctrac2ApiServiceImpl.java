package com.jpmorgan.cb.wlt.services.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerService;
import com.jpmorgan.cb.wlt.apis.event.store.TrustStoreManagerService;
import com.jpmorgan.cb.wlt.services.Ctrac2ApiService;
import com.jpmorgan.cib.wlt.ctrac.auth.AuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.EventStoreException;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonPoster;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonPosterFactory;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class Ctrac2ApiServiceImpl implements Ctrac2ApiService {

    @Value("${ctrac.workflow.api.url}")
    private String CTRAC_WORKFLOW_API;

    @Value("${ctrac.entitlements.api.url}")
    private String CTRAC_ENTITLEMENTS_API;

    private TrustStoreManagerService trustStoreManagerService;
    CtracAuthenticationManagerService authManagerService;

    @Autowired
    public Ctrac2ApiServiceImpl(CtracAuthenticationManagerService authManagerService,
                                TrustStoreManagerService trustStoreManagerService) {
        assert(authManagerService != null);
        this.authManagerService = authManagerService;
        assert(trustStoreManagerService != null);
        this.trustStoreManagerService = trustStoreManagerService;
    }

    @Override
    public void startWorkflow(String workflow, String jsonObject) {
        AuthenticationManager authManager = authManagerService.getAuthenticationManager();
        EventJsonPoster poster = getEventJsonPoster(CTRAC_WORKFLOW_API + "/" + workflow, authManager);
        try {
            boolean isAsyncPost = true;
            poster.post(jsonObject, authManager.getAuthenticationToken(), isAsyncPost);
        } catch (EventStoreException ex) {
            throw new CtracException(ex.getMessage());
        }
    }

    @Override
    public void startOrAbortWorkflow(String jsonObject) {
        AuthenticationManager authManager = authManagerService.getAuthenticationManager();
        EventJsonPoster poster = getEventJsonPoster(CTRAC_WORKFLOW_API + "/c3", authManager);
        try {
            boolean isAsyncPost = false;
            poster.post(jsonObject, authManager.getAuthenticationToken(), isAsyncPost);
        } catch (EventStoreException ex) {
            throw new CtracException(ex.getMessage());
        }
    }

    @Override
    public UserEntitlementsDTO getUserEntitlements(String janusUser) {
        AuthenticationManager authManager = authManagerService.getAuthenticationManager();
        EventJsonPoster poster = getEventJsonPoster(CTRAC_ENTITLEMENTS_API + "/" + janusUser, authManager);
        try {
            String response = poster.post(StringUtils.EMPTY, authManager.getAuthenticationToken(), false);
            return new ObjectMapper().readValue(response, UserEntitlementsDTO.class);
        } catch (Exception ex) {
            throw new CtracException(ex.getMessage());
        }
    }

    EventJsonPoster getEventJsonPoster(String url, AuthenticationManager authManager) {
        return EventJsonPosterFactory.create(url,
                trustStoreManagerService.getTrustStoreManager().getSSLContext(), authManager);
    }

}
