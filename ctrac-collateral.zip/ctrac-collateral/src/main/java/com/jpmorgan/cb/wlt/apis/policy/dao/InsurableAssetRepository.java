package com.jpmorgan.cb.wlt.apis.policy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InsurableAssetRepository extends JpaRepository<InsurableAsset, Long> { }
