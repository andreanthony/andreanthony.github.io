package com.jpmorgan.cb.wlt.dao;

import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.util.Date;

@MappedSuperclass
public abstract class AuditableEntity {

    @Column(name = "INSERTED_BY")
    private String insertedBy;

    @Column(name = "INSERTED_DATE")
    private Date insertedDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;



    public void setInitialAuditInfo(String userName){
        Date today = new Date();
        setInsertedBy(userName);
        setInsertedDate(today);
        setUpdatedBy(userName);
        setUpdatedDate(today);
    }

    public void updateAuditInfo(String userName){
        Date today = new Date();
        setUpdatedBy(userName);
        setUpdatedDate(today);
    }

    public void setAuditInfo(UserRequestInfo userRequestInfo){
        if(getRid() == null || getRid() == 0){
            setInitialAuditInfo(userRequestInfo.getUserSid());
        }else{
            updateAuditInfo(userRequestInfo.getUserSid());
        }
    }

    public String getInsertedBy() {
        return insertedBy;
    }

    public void setInsertedBy(String insertedBy) {
        this.insertedBy = insertedBy;
    }

    public Date getInsertedDate() {
        return insertedDate;
    }

    public void setInsertedDate(Date insertedDate) {
        this.insertedDate = insertedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public abstract Long getRid();
}
