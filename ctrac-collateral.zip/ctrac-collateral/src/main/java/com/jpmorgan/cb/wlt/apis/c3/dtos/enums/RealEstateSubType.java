package com.jpmorgan.cb.wlt.apis.c3.dtos.enums;

import java.util.Arrays;

public enum RealEstateSubType {

	DWELLING_RESIDENTIAL("DR"),
	MULTI_FAMILY("MF"),
	COMMERCIAL("C"),
	COMMERCIAL_CONDO_ASSOCIATION("CCA"),
	RESIDENTIAL_CONDO_ASSOCIATION("RCA");

	private final String code;

	public static RealEstateSubType getByCode(String code) {
		return Arrays.stream(RealEstateSubType.values())
				.filter(type -> type.code.equals(code))
				.findAny()
				.orElse(null);
	}

	private RealEstateSubType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public boolean isCommercial() {
		return this == COMMERCIAL_CONDO_ASSOCIATION || this == COMMERCIAL;
	}
}
