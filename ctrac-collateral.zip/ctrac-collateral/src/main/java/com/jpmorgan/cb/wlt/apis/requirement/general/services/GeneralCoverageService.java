package com.jpmorgan.cb.wlt.apis.requirement.general.services;

import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;

import java.util.List;

public interface GeneralCoverageService {
    List<GeneralCoverageDTO> getGeneralCoverageTypes();
}
