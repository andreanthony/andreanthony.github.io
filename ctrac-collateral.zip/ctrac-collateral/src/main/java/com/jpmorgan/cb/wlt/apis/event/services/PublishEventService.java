package com.jpmorgan.cb.wlt.apis.event.services;

import com.jpmorgan.cb.wlt.apis.event.AbstractPublishEventRequest;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.EventDTO;

public interface PublishEventService {

	void publishEvent(AbstractPublishEventRequest publishRequest);
	void publishEvent(EventDTO eventDTO);
}
