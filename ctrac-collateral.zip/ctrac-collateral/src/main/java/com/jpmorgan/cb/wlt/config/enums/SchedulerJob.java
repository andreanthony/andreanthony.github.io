package com.jpmorgan.cb.wlt.config.enums;

public enum SchedulerJob {
    FULL_EOD_JOB("EOD"),
    EOD_C3_JOB("C3");

    private String name;

    SchedulerJob(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}
