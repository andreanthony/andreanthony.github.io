package com.jpmorgan.cb.wlt.apis.policy.services.impl;

public enum BorrowerInsuranceReviewConclusion {
    NONE, ACTION_REQUIRED, ACCEPTABLE, REJECTED
}
