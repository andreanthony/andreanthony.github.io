package com.jpmorgan.cb.wlt.apis.c3.dtos;

import java.io.Serializable;

public class C3Loan implements Serializable {
    private static final long serialVersionUID = -1;
    private String loanType;
    private String status;
    private String releasedDate;

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReleasedDate() {
        return releasedDate;
    }

    public void setReleasedDate(String releasedDate) {
        this.releasedDate = releasedDate;
    }
}
