package com.jpmorgan.cb.wlt.apis.policy.services;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;


public interface PolicySectionStatusService {

    void transitionOnVerify(ProofOfCoverage policy, InsuranceType insuranceType, UserRequestInfo userRequestInfo);

    void transitionOnCreate(ProofOfCoverage policy, InsuranceType insuranceType, UserRequestInfo userRequestInfo);

    void transitionOnEdit(ProofOfCoverage policy, InsuranceType insuranceType, UserRequestInfo userRequestInfo);

}
