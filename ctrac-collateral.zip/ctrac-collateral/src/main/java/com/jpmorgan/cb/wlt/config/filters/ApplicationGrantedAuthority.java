package com.jpmorgan.cb.wlt.config.filters;

import org.springframework.security.core.GrantedAuthority;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class ApplicationGrantedAuthority implements GrantedAuthority {

	private static final long serialVersionUID = -9046040962631786016L;
    private String authority;
    private Set<String> lobs = new HashSet<>();

    ApplicationGrantedAuthority(String authority) {
        this.authority = authority;
    }

    @Override
    public String getAuthority() {
        return authority;
    }


    public Set<String> getLobs() {
        return Collections.unmodifiableSet(lobs);
    }

    public void addLobs(Set<String> lobs) {
        this.lobs.addAll(lobs);
    }

}
