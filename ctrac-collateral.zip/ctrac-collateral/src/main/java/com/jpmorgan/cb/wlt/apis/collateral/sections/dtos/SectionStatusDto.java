package com.jpmorgan.cb.wlt.apis.collateral.sections.dtos;

import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.dtos.AuditableEntityDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;

public class SectionStatusDto extends AuditableEntityDTO {

    private Long rid;

    private Long collateralRid;

    private String verifiedBy;

    private CollateralSection sectionId;

    private VerificationStatus statusId;

    private String modifiedBy;

    private Boolean showVerify;

    private String modifiedDate;

    private String verifiedDate;

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getVerifiedDate() {
        return verifiedDate;
    }

    public void setVerifiedDate(String verifiedDate) {
        this.verifiedDate = verifiedDate;
    }

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public CollateralSection getSectionId() {
        return sectionId;
    }

    public void setSectionId(CollateralSection sectionId) {
        this.sectionId = sectionId;
    }

    public VerificationStatus getStatusId() {
        return statusId;
    }

    public void setStatusId(VerificationStatus statusId) {
        this.statusId = statusId;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public Boolean getShowVerify() {
        return showVerify;
    }

    public void setShowVerify(Boolean showVerify) {
        this.showVerify = showVerify;
    }


}
