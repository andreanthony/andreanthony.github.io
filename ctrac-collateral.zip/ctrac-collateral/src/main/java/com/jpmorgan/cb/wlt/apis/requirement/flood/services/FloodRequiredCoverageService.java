package com.jpmorgan.cb.wlt.apis.requirement.flood.services;

import com.jpmorgan.cb.wlt.apis.requirement.flood.dto.FloodRequiredCoverageDTO;

import java.util.List;

public interface FloodRequiredCoverageService {

    List<FloodRequiredCoverageDTO> getByCollateralId(Long collateralId);
}
