package com.jpmorgan.cb.wlt.apis.requirement.general.dtos;

import java.util.ArrayList;
import java.util.List;

public class GeneralCoverageRequirementDTO {
    private Long collateralRid;

    List<GeneralRequiredCoverageSourceDTO> inactiveRequirementSources = new ArrayList<>();
    GeneralRequiredCoverageSourceDTO verifiedRequirementSource;
    GeneralRequiredCoverageSourceDTO pendingVerificationRequirementSource;

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public List<GeneralRequiredCoverageSourceDTO> getInactiveRequirementSources() {
        return inactiveRequirementSources;
    }

    public void setInactiveRequirementSources(List<GeneralRequiredCoverageSourceDTO> inactiveRequirementSources) {
        this.inactiveRequirementSources = inactiveRequirementSources;
    }

    public GeneralRequiredCoverageSourceDTO getVerifiedRequirementSource() {
        return verifiedRequirementSource;
    }

    public void setVerifiedRequirementSource(GeneralRequiredCoverageSourceDTO verifiedRequirementSource) {
        this.verifiedRequirementSource = verifiedRequirementSource;
    }

    public GeneralRequiredCoverageSourceDTO getPendingVerificationRequirementSource() {
        return pendingVerificationRequirementSource;
    }

    public void setPendingVerificationRequirementSource(GeneralRequiredCoverageSourceDTO pendingVerificationRequirementSource) {
        this.pendingVerificationRequirementSource = pendingVerificationRequirementSource;
    }

}
