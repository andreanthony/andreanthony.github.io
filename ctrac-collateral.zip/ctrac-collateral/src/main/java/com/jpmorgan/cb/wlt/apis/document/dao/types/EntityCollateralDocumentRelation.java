package com.jpmorgan.cb.wlt.apis.document.dao.types;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.policy.dao.GeneralInsurance;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralRequiredCoverageSource;
import org.hibernate.annotations.Any;
import org.hibernate.annotations.AnyMetaDef;
import org.hibernate.annotations.MetaValue;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "TLCP_ENTITY_DOCUMENTS_REL")
public class EntityCollateralDocumentRelation implements Serializable{
    private static final long serialVersionUID = -1;

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "entityCollateralDocumentRelationSeqGenerator")
    @TableGenerator(name = "entityCollateralDocumentRelationSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_ENTITY_DOCUMENTS_REL", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 6)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Any(
            metaDef = "EntityDocumentRelMetaDef",
            metaColumn = @Column(name = "ENTITY_TYPE")
    )
    @AnyMetaDef(
            name = "EntityDocumentRelMetaDef",
            metaType = "string",
            idType = "long",
            metaValues = {
                    @MetaValue(value = "GeneralRequiredCoverageSource", targetEntity = GeneralRequiredCoverageSource.class),
                    @MetaValue(value = "GeneralInsurance", targetEntity = GeneralInsurance.class)
            }
    )
    @JoinColumn(name = "ENTITY_RID")
    private Object entity;

    @OneToOne(cascade = {CascadeType.ALL}, orphanRemoval = true)
    @JoinColumn(name = "DOCUMENT_RID")
    private CollateralDocument document;

    public Object getEntity() {
        return entity;
    }

    public void setEntity(Object entity) {
        this.entity = entity;
    }

    public CollateralDocument getDocument() {
        return document;
    }

    public void setDocument(CollateralDocument document) {
        this.document = document;
    }
}
