package com.jpmorgan.cb.wlt.apis.policy.services;

import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;

import java.util.List;

public interface LetterCycleValidator {
    List<String> validate(PolicyDTO policyDTO, List<GeneralCoverageDTO> generalCoverages);
}
