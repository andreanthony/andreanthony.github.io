package com.jpmorgan.cb.wlt.apis.policy.services;

import com.jpmorgan.cb.wlt.apis.policy.dtos.InsuranceCompanyDTO;

import java.util.List;

public interface InsuranceCompanyService {

    public List<InsuranceCompanyDTO> getListofInsuranceCompanyNames(String searchParam);
}
