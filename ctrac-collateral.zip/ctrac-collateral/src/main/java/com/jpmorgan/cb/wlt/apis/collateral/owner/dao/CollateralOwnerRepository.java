package com.jpmorgan.cb.wlt.apis.collateral.owner.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CollateralOwnerRepository extends JpaRepository<CollateralOwner, CollateralOwnerPk> {
    List<CollateralOwner> findByCollateralRid(Long collateralRid);
}
