package com.jpmorgan.cb.wlt.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Table(name = "TLCP_FEATURE_SWITCH")
public class FeatureSwitch implements Serializable {
    private static final long serialVersionUID = 1;

    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "FEATURE_NAME")
    @NotNull
    private String featureName;

    @Column(name = "ENABLED")
    private Boolean enabled;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FeatureSwitch that = (FeatureSwitch) o;

        if (!rid.equals(that.rid)) return false;
        return featureName.equals(that.featureName);
    }

    @Override
    public int hashCode() {
        int result = rid.hashCode();
        result = 31 * result + featureName.hashCode();
        return result;
    }
}