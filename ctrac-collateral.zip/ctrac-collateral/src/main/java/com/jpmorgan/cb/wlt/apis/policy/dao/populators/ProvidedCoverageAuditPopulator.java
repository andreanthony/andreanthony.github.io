package com.jpmorgan.cb.wlt.apis.policy.dao.populators;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProvidedCoverage;
import com.jpmorgan.cb.wlt.dao.DaoAuditDataPopulator;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

public class ProvidedCoverageAuditPopulator implements DaoAuditDataPopulator<ProvidedCoverage,UserRequestInfo> {

    @Override
    public void populateAuditInfo(ProvidedCoverage source, UserRequestInfo userRequestInfo) {
        source.setAuditInfo(userRequestInfo);

        if(source.getCoverageDetails() != null){
            source.getCoverageDetails().setAuditInfo(userRequestInfo);
        }

    }
}
