package com.jpmorgan.cb.wlt.apis.lookup.services.impl;

import com.jpmorgan.cb.wlt.apis.lookup.dao.LookupCode;
import com.jpmorgan.cb.wlt.apis.lookup.dao.LookupCodeRepository;
import com.jpmorgan.cb.wlt.apis.lookup.dtos.LookupCodeDTO;
import com.jpmorgan.cb.wlt.apis.lookup.services.LookupCodeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class LookupCodeServiceImpl implements LookupCodeService {

    private static final Logger logger = LoggerFactory.getLogger(LookupCodeServiceImpl.class);
    private LookupCodeRepository lookupCodeRepository;

    @Autowired
    public LookupCodeServiceImpl(LookupCodeRepository lookupCodeRepository) {
        assert(lookupCodeRepository != null);
        this.lookupCodeRepository = lookupCodeRepository;
    }

    @Override
    public List<LookupCodeDTO> getByCodeset(String codeset) {
        List<LookupCode> lookupCodes = lookupCodeRepository.findByCodeSetAndActiveOrderBySortOrderAsc(codeset, "Y");
        List<LookupCodeDTO> lookupCodeDTOS = new ArrayList<>();
        for (LookupCode generalCoverage : lookupCodes) {
            lookupCodeDTOS.add(generalCoverage.toLookupCodeDTO());
        }
        return lookupCodeDTOS;
    }

    @Override
    public List<LookupCodeDTO> getChildrenLookupCodes(String codeSet, String code) {
        List<LookupCode> lookupCodes = lookupCodeRepository.findChildrenLookupCodesByParentCodeSetAndCode(codeSet, code);
        List<LookupCodeDTO> lookupCodeDTOS = new ArrayList<>();
        for (LookupCode generalCoverage : lookupCodes) {
            lookupCodeDTOS.add(generalCoverage.toLookupCodeDTO());
        }
        return lookupCodeDTOS;
    }

    @Override
    public LookupCodeDTO getByCodeSetAndCode(String codeSet, String code) {
        LookupCode lookupCode = lookupCodeRepository.findByCodeAndCodeSetAndActive(code, codeSet, "Y");
        if(lookupCode == null){
            return null;
        }
        return lookupCode.toLookupCodeDTO();
    }
}
