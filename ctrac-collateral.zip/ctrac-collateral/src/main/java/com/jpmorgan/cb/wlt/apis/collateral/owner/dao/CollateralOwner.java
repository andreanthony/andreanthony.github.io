package com.jpmorgan.cb.wlt.apis.collateral.owner.dao;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_COLLATERAL_OWNER")
@IdClass(value = CollateralOwnerPk.class)
public class CollateralOwner {

    @Id
    @ManyToOne
    @JoinColumn(name = "COLLATERAL_ID")
    private Collateral collateral;

    @Id
    @Column(name = "CUSTOMER_ID")
    private Long ownerId;

    public Collateral getCollateral() {
        return collateral;
    }

    public void setCollateral(Collateral collateral) {
        this.collateral = collateral;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }
}
