package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.ProvidedCoverageMapperFactory;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralCoverage;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cb.wlt.dao.CoverageDetails;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_PROVIDED_COVERAGE")
public class ProvidedCoverage extends AuditableEntity{

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "providedCoverageSeqGenerator")
    @TableGenerator(name = "providedCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_PROVIDED_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Id
    @Column(name = "RID")
    private Long rid;

    @OneToOne(cascade=CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "COVERAGE_DETAILS_ID", nullable = false)
    private CoverageDetails coverageDetails;

    @ManyToOne
    @JoinColumn(name = "INSURABLE_ASSET_ID")
    private InsurableAsset insurableAsset;

    @Column(name = "COLLATERAL_ID")
    private Long collateralId;

    @OneToOne
    @JoinColumn(name = "GENERAL_COVERAGE_ID")
    private GeneralCoverage generalCoverage;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PROOF_OF_COVERAGE_ID")
    private ProofOfCoverage proofOfCoverage;

    @Column(name = "REQUIRED_COVERAGE_RID")
    private Long requiredCoverageRid;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public CoverageDetails getCoverageDetails() {
        return coverageDetails;
    }

    public void setCoverageDetails(CoverageDetails coverageDetails) {
        this.coverageDetails = coverageDetails;
    }

    public InsurableAsset getInsurableAsset() {
        return insurableAsset;
    }

    public void setInsurableAsset(InsurableAsset insurableAsset) {
        this.insurableAsset = insurableAsset;
    }

    public Long getCollateralId() {
        if (insurableAsset != null && generalCoverage == null && insurableAsset.getBuilding() != null) {
            return insurableAsset.getBuilding().getCollateralRid();
        }
        return collateralId;
    }

    public void setCollateralId(Long collateralId) {
        this.collateralId = collateralId;
    }

    public GeneralCoverage getGeneralCoverage() { return generalCoverage; }

    public void setGeneralCoverage(GeneralCoverage generalCoverage) {
        this.generalCoverage = generalCoverage;
    }

    public ProofOfCoverage getProofOfCoverage() {
        return proofOfCoverage;
    }

    public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
        this.proofOfCoverage = proofOfCoverage;
    }

    public Long getRequiredCoverageRid() {
        return requiredCoverageRid;
    }

    public void setRequiredCoverageRid(Long requiredCoverageRid) {
        this.requiredCoverageRid = requiredCoverageRid;
    }

    public PolicyInsuranceCoverageDTO toPolicyCollateralDetailsDTO() {
        return ProvidedCoverageMapperFactory.getProvidedCoverageMapper(this).toDTO(this);
    }

    public boolean map(PolicyInsuranceCoverageDTO insuranceCoverageDTO) {
        return ProvidedCoverageMapperFactory.getProvidedCoverageMapper(insuranceCoverageDTO).map(insuranceCoverageDTO, this);
    }
}
