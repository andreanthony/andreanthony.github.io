package com.jpmorgan.cb.wlt.apis.document.dao.types;

public interface EntityDocumentHolder {
}
