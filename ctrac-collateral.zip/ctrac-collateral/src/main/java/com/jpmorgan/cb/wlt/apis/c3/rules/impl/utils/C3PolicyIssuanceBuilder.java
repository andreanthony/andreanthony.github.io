package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.joda.time.DateTime;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class C3PolicyIssuanceBuilder {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    public static C3PolicyIssuance buildC3PolicyIssuance(String coverageType, PolicyType policyType, BigDecimal lpAmount, Date coverageDate) {
        C3PolicyIssuance c3PolicyIssuance = new C3PolicyIssuance();
        c3PolicyIssuance.setPolicyType(policyType);
        c3PolicyIssuance.setPolicyStatus(PolicyStatus.PENDING_LETTER_CYCLE);
        c3PolicyIssuance.setLpAction(LPAction.NEW_LP);
        c3PolicyIssuance.setCoverageType(coverageType);
        c3PolicyIssuance.setCoverageAmount(lpAmount);
        c3PolicyIssuance.setEffectiveDate(DATE_FORMATTER.print(coverageDate));
        c3PolicyIssuance.setExpirationDate(DATE_FORMATTER.print(new DateTime(coverageDate).plusYears(1).toDate()));

        return c3PolicyIssuance;
    }

    public static Long getParentPolicyId(List<C3Policy> borrowerPolicies) {
        //Calculate for the new LP policy what the parent policy rid would be
        ParentPolicyCalculator parentPolicyCalculator = new ParentPolicyCalculator(borrowerPolicies);
        C3Policy parentPolicy = parentPolicyCalculator.calculateParentPolicy();
        return parentPolicy == null? null: parentPolicy.getPolicyId();
    }
}
