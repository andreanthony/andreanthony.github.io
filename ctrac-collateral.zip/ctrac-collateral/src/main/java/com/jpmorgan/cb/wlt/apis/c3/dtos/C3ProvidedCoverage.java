package com.jpmorgan.cb.wlt.apis.c3.dtos;

public class C3ProvidedCoverage extends C3Coverage {
    private static final long serialVersionUID = -1;
}
