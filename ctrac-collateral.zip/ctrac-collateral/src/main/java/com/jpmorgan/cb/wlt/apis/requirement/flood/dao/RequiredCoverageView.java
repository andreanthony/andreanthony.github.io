package com.jpmorgan.cb.wlt.apis.requirement.flood.dao;

import com.jpmorgan.cb.wlt.apis.requirement.flood.dto.FloodRequiredCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name="VLCP_REQ_COVERAGE_DETAILS")
public class RequiredCoverageView {

    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    @Id
    @Column(name="RID")
    private Long rid;

    @Column(name = "REQUIRED_COVERAGE_RID")
    private Long requiredCoverageRid; //original Required coverage that caused this LPI

    @Column(name="COLLATERAL_RID")
    private Long collateralRid;

    @Column(name="INSURABLE_ASSET_RID")
    private Long insurableAssetRid;

    @Column(name="STATUS")
    private String status;

    @Column(name="DOCUMENT_DATE")
    private Date documentDate;

    @Column(name="INSURANCE_TYPE")
    private String insuranceType;

    @Column(name="ASSET_TYPE")
    private String insurableAssetType;

    @Column(name="PROPERTY_TYPE")
    private String propertyType;

    @Column(name="PRIMARY_COVERAGE_AMOUNT")
    private BigDecimal primaryCoverageAmount;

    @Column(name="EXCESS_COVERAGE_AMOUNT")
    private BigDecimal excessCoverageAmount;

    @Column(name="COVERAGE_IS_DESCOPED")
    private boolean descoped;

    @Column(name="CANCELLATION_EFFECTIVE_DATE")
    private Date cancellationEffectiveDate;

    @Column(name="PRIMARY_HOLD_RID")
    private Long primaryHoldRid;

    @Column(name="EXCESS_HOLD_RID")
    private Long excessHoldRid;


    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public Long getRequiredCoverageRid() {
        return requiredCoverageRid;
    }

    public void setRequiredCoverageRid(Long requiredCoverageRid) {
        this.requiredCoverageRid = requiredCoverageRid;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public Long getInsurableAssetRid() {
        return insurableAssetRid;
    }

    public void setInsurableAssetRid(Long insurableAssetRid) {
        this.insurableAssetRid = insurableAssetRid;
    }

    public String getInsurableAssetType() {
        return insurableAssetType;
    }

    public void setInsurableAssetType(String insurableAssetType) {
        this.insurableAssetType = insurableAssetType;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public BigDecimal getExcessCoverageAmount() {
        return excessCoverageAmount;
    }

    public void setExcessCoverageAmount(BigDecimal excessCoverageAmount) {
        this.excessCoverageAmount = excessCoverageAmount;
    }

    public BigDecimal getPrimaryCoverageAmount() {
        return primaryCoverageAmount;
    }

    public void setPrimaryCoverageAmount(BigDecimal primaryCoverageAmount) {
        this.primaryCoverageAmount = primaryCoverageAmount;
    }

    public boolean isDescoped() {
        return descoped;
    }

    public void setDescoped(boolean descoped) {
        this.descoped = descoped;
    }

    public Date getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
        this.cancellationEffectiveDate = cancellationEffectiveDate;
    }

    public Long getPrimaryHoldRid() {
        return primaryHoldRid;
    }

    public void setPrimaryHoldRid(Long primaryHoldRid) {
        this.primaryHoldRid = primaryHoldRid;
    }

    public Long getExcessHoldRid() {
        return excessHoldRid;
    }

    public void setExcessHoldRid(Long excessHoldRid) {
        this.excessHoldRid = excessHoldRid;
    }

    protected FloodRequiredCoverageDTO toFloodRequiredCoverageDTO() {
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = new FloodRequiredCoverageDTO();
        floodRequiredCoverageDTO.setRequiredCoverageRid(requiredCoverageRid);
        floodRequiredCoverageDTO.setInsuranceType(InsuranceType.FLOOD.name());
        floodRequiredCoverageDTO.setInsurableAssetId(insurableAssetRid);
        floodRequiredCoverageDTO.setInsurableAssetType(insurableAssetType);
        floodRequiredCoverageDTO.setDocumentDate(DATE_FORMATTER.print(documentDate));
        floodRequiredCoverageDTO.setCancellationEffectiveDate(DATE_FORMATTER.print(cancellationEffectiveDate));
        floodRequiredCoverageDTO.setPropertyType(propertyType);
        floodRequiredCoverageDTO.setDescoped(descoped);
        floodRequiredCoverageDTO.setStatus(this.status);
        return floodRequiredCoverageDTO;
    }

    public FloodRequiredCoverageDTO toPrimaryFloodRequiredCoverageDTO() {
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = toFloodRequiredCoverageDTO();
        floodRequiredCoverageDTO.setCoverageType(FloodCoverageType.PRIMARY.name());
        floodRequiredCoverageDTO.setCoverageAmount(primaryCoverageAmount);
        floodRequiredCoverageDTO.setHoldRid(primaryHoldRid);
        return floodRequiredCoverageDTO;
    }

    public FloodRequiredCoverageDTO toExcessFloodRequiredCoverageDTO() {
        FloodRequiredCoverageDTO floodRequiredCoverageDTO = toFloodRequiredCoverageDTO();
        floodRequiredCoverageDTO.setCoverageType(FloodCoverageType.EXCESS.name());
        floodRequiredCoverageDTO.setCoverageAmount(excessCoverageAmount);
        floodRequiredCoverageDTO.setHoldRid(excessHoldRid);
        return floodRequiredCoverageDTO;
    }

}
