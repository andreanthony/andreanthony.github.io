package com.jpmorgan.cb.wlt.apis.event.store;

import com.jpmorgan.cib.wlt.ctrac.event.store.shared.secure.TrustStoreManager;

public interface TrustStoreManagerService {

	TrustStoreManager getTrustStoreManager();
}
