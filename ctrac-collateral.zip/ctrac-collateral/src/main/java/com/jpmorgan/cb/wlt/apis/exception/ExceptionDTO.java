package com.jpmorgan.cb.wlt.apis.exception;

public class ExceptionDTO {
    private String errorMessage;

    public ExceptionDTO(){}

    public ExceptionDTO(String message) {
        this.errorMessage = message;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
