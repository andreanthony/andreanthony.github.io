package com.jpmorgan.cb.wlt.config.mappings;

import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;
import com.jpmorgan.cb.wlt.apis.entity.dao.Customer;
import org.modelmapper.PropertyMap;

public class CustomerMapping {
    public static PropertyMap<Customer, EntityDTO> getEntityDTOMapping() {
        return new PropertyMap <Customer, EntityDTO>() {
            protected void configure() {
                map().setRid(source.getRid());
                map().setName(source.getName());
                map().setUniqueCustomerNumber(source.getUniqueCustomerNumber());
                map().setStreetAddress(source.getContactDetails().getAddress().getStreetAddress());
                map().setUnitOrBuilding(source.getContactDetails().getAddress().getUnitOrBuilding());
                map().setCity(source.getContactDetails().getAddress().getCity());
                map().setCounty(source.getContactDetails().getAddress().getCounty());
                map().setState(source.getContactDetails().getAddress().getState());
                map().setZipCode(source.getContactDetails().getAddress().getZipCode());
                map().setPhoneNumber(source.getContactDetails().getPhoneNumber());
                map().setEmailAddress(source.getContactDetails().getEmailAddress());
                map().setFaxNumber(source.getContactDetails().getFaxNumber());
            }
        };
    }
}
