package com.jpmorgan.cb.wlt.config.mappings;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.BusinessAssets;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.RealEstate;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateBusinessAssetsDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateCollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateRealEstateDTO;
import org.modelmapper.PropertyMap;

public class CreateCollateralDTOMapping {

    public static PropertyMap<CreateRealEstateDTO, RealEstate> getCreateRealEstateCollateralDTOMapping() {
        return new PropertyMap <CreateRealEstateDTO, RealEstate>() {
            protected void configure() {
                map().setCollateralDescription(source.getDescription());
                map().getCollateralAddress().setStreetAddress(source.getStreetAddress());
                map().getCollateralAddress().setUnitOrBuilding(source.getUnitOrBuilding());
                map().getCollateralAddress().setCounty(source.getCounty());
                map().getCollateralAddress().setCity(source.getCity());
                map().getCollateralAddress().setState(source.getState());
                map().getCollateralAddress().setZipCode(source.getZipCode());
            }
        };
    }

    public static PropertyMap<CreateBusinessAssetsDTO, BusinessAssets> getCreateBusinessAssetsDTOMapping() {
        return new PropertyMap <CreateBusinessAssetsDTO, BusinessAssets>() {
            protected void configure() {
                map().setCollateralDescription(source.getDescription());
                map().getCollateralAddress().setStreetAddress(source.getStreetAddress());
                map().getCollateralAddress().setUnitOrBuilding(source.getUnitOrBuilding());
                map().getCollateralAddress().setCounty(source.getCounty());
                map().getCollateralAddress().setCity(source.getCity());
                map().getCollateralAddress().setState(source.getState());
                map().getCollateralAddress().setZipCode(source.getZipCode());
            }
        };
    }
}