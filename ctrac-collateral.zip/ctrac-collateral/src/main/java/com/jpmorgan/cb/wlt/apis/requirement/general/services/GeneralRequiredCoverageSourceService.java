package com.jpmorgan.cb.wlt.apis.requirement.general.services;

import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageRequirementDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageSourceDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

import javax.validation.Valid;
import java.util.List;

public interface GeneralRequiredCoverageSourceService {

    GeneralRequiredCoverageSourceDTO save(@Valid GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                                          List<FileUploadAttachmentDTO> fileUploadAttachmentDTOList, UserRequestInfo userRequestInfo);

    GeneralRequiredCoverageSourceDTO verify(@Valid GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                                            UserRequestInfo userRequestInfo);

    GeneralCoverageRequirementDTO getByCollateralId(Long collateralId);

    GeneralRequiredCoverageSourceDTO getById(Long generalRequiredCoverageSourceId);

    List<GeneralCoverageDTO> getCoveragesByCollateralId(Long collateralId);

    GeneralRequiredCoverageSourceDTO getVerifiedOrPendingByCollateralId(Long collateralId);

    void deleteSource(Long generalRequiredCoverageSourceId, UserRequestInfo userRequestInfo);
}
