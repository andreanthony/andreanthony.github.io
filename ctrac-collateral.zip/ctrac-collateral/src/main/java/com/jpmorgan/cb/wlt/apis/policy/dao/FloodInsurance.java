package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cb.wlt.config.ApplicationContextProvider;
import com.jpmorgan.cb.wlt.dao.CoverageDetails;
import com.jpmorgan.cib.wlt.ctrac.enums.CtracAppConstants;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "TLCP_FLOOD_INSURANCE")
@PrimaryKeyJoinColumn(name = "RID", referencedColumnName = "RID")
public class FloodInsurance extends ProofOfCoverage {
    @Override
    public String getInsuranceType() {
        return InsuranceType.FLOOD.name();
    }

    @Override
    public void map(C3PolicyIssuance policyIssuance) {
        super.map(policyIssuance);
        ProvidedCoverage providedCoverage = new ProvidedCoverage();

        InsurableAssetRepository insurableAssetRepository =
                ApplicationContextProvider.getContext().getBean(InsurableAssetRepository.class);

        providedCoverage.setInsurableAsset(insurableAssetRepository
                .findById(policyIssuance.getInsurableAssetId()).orElse(null));
        CoverageDetails coverageDetails = new CoverageDetails();
        coverageDetails.setCoverageAmount(policyIssuance.getCoverageAmount());
        coverageDetails.setCoverageType(policyIssuance.getCoverageType_().getDisplayName());
        coverageDetails.setBalanceType(policyIssuance.getBalanceType());
        providedCoverage.setCoverageDetails(coverageDetails);

        providedCoverage.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);
        coverageDetails.setInitialAuditInfo(CtracAppConstants.SYSTEM_USER);

        addProvidedCoverage(providedCoverage);
    }
}
