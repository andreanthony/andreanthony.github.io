package com.jpmorgan.cb.wlt.services;

import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;

public interface Ctrac2ApiService {

    void startWorkflow(String workflow, String jsonObject);
    void startOrAbortWorkflow(String jsonObject);
    UserEntitlementsDTO getUserEntitlements(String janusUser);
}
