package com.jpmorgan.cb.wlt.apis.loan.dao;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_LOAN_COLLATERAL")
@IdClass(value = LoanCollateralPk.class)
public class LoanCollateral {

    @Id
    @ManyToOne
    @JoinColumn(name = "LOAN_ID")
    private Loan loan;

    @Id
    @Column(name = "COLLATERAL_ID")
    private Long collateralId;

    @Column(name = "PRIMARY_FLAG")
    private String primaryFlag;

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public Long getCollateralId() {
        return collateralId;
    }

    public void setCollateralId(Long collateralId) {
        this.collateralId = collateralId;
    }

    public String getPrimaryFlag() {
        return primaryFlag;
    }

    public void setPrimaryFlag(String primaryFlag) {
        this.primaryFlag = primaryFlag;
    }
}
