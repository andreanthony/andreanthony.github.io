package com.jpmorgan.cb.wlt.config.environment.impl;

import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerService;
import com.jpmorgan.cb.wlt.config.environment.EnvironmentManager;
import com.jpmorgan.cb.wlt.config.environment.EnvironmentType;
import com.jpmorgan.cb.wlt.config.environment.type.LocalEnvironment;
import com.jpmorgan.cb.wlt.config.environment.type.NonLocalEnvironment;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class EnvironmentManagerImpl implements EnvironmentManager{

    @Value("${janus.env}")
    private String janusEnv;

    @Autowired
    private CtracAuthenticationManagerService ctracAuthenticationManagerService;
    private EnvironmentType environmentType;

    @PostConstruct
    public void init(){
        if(StringUtils.equals("local",janusEnv)){
            environmentType = new LocalEnvironment(ctracAuthenticationManagerService);
        }else{
            environmentType = new NonLocalEnvironment(ctracAuthenticationManagerService);
        }
    }


    @Override
    public EnvironmentType getActiveEnvironment(){
        return this.environmentType;
    }

}
