package com.jpmorgan.cb.wlt.apis.collateral.types.dto;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotBlank;

public class CreateRealEstateDTO extends CreateCollateralDTO {

    private String description;

    private String streetAddress;

    private String unitOrBuilding;

    private String county;

    private String city;

    private String state;

    private String zipCode;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @ApiModelProperty(required = true)
    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getUnitOrBuilding() {
        return unitOrBuilding;
    }

    public void setUnitOrBuilding(String unitOrBuilding) {
        this.unitOrBuilding = unitOrBuilding;
    }

    @ApiModelProperty(required = true)
    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    @ApiModelProperty(required = true)
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @ApiModelProperty(required = true)
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @ApiModelProperty(required = true)
    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}
