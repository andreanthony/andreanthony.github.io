package com.jpmorgan.cb.wlt.apis.document.dao;

import com.jpmorgan.cb.wlt.apis.document.dao.mappers.FileContentMapper;
import com.jpmorgan.cb.wlt.apis.document.dtos.FileContentDTO;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_FILE_CONTENT")
public class FileContent {

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "fileContentSeqGenerator")
	@TableGenerator(name = "fileContentSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_FILE_CONTENT", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 6)
	@Id
	@Column(name = "RID")
	private Long rid;
	
	@Lob
	@Column(name = "FILE_CONTENT", nullable = false)
	private byte[] fileContent;
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public byte[] getFileContent() {
		return fileContent;
	}

	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}

	public FileContentDTO toFileContentDTO() {
		return new FileContentMapper().toDTO(this);
	}

	public boolean map(FileContentDTO fileContentDTO) {
		return new FileContentMapper().map(fileContentDTO, this);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;

		if (o == null || getClass() != o.getClass()) return false;

		FileContent that = (FileContent) o;

		return new EqualsBuilder()
				.append(rid, that.rid)
				.append(fileContent, that.fileContent)
				.isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 37)
				.append(rid)
				.append(fileContent)
				.toHashCode();
	}
}
