package com.jpmorgan.cb.wlt.apis.floodDetermination.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FloodDeterminationRepository extends JpaRepository<FloodDetermination, Long> {
    FloodDetermination findByCollateralRidAndStatus(Long collateral, String status);
}
