package com.jpmorgan.cb.wlt.apis.collateral.owner.services;

import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;

import java.util.List;

public interface CollateralOwnerService {
    List<EntityDTO> getCollateralOwners(Long collateralId);
    String getUniqueMortgagorAndBorrowerNames(Long collateralRid , String separator ) ;

}
