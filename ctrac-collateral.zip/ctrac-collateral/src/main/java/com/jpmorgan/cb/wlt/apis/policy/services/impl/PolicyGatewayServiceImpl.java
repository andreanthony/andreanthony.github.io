package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.EvidenceOfInsuranceMapper;
import com.jpmorgan.cb.wlt.apis.policy.dtos.OverrideLpPolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyGatewayService;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyService;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyValidationService;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class PolicyGatewayServiceImpl implements PolicyGatewayService {

    private static final Logger logger = LoggerFactory.getLogger(PolicyGatewayServiceImpl.class);

    private PolicyService policyService;
    private PolicyValidationService policyValidationService;

    @Autowired
    public PolicyGatewayServiceImpl(PolicyService policyService, PolicyValidationService policyValidationService) {
        assert(policyService != null);
        this.policyService = policyService;
        assert(policyValidationService != null);
        this.policyValidationService = policyValidationService;
    }


    @Override
    public PolicyDTO createPolicy(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, UserRequestInfo userRequestInfo) {
        overridePolicyTypeEoi(policyDTO);
        policyValidationService.validateCreate(policyDTO, filesUploaded);
        return policyService.createPolicy(policyDTO, filesUploaded, userRequestInfo);
    }

    @Override
    public PolicyDTO editPolicy(Long policyId, PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, UserRequestInfo userRequestInfo) {
        ProofOfCoverage policy = policyService.getExistingProofOfCoverage(policyId, policyDTO);
        PolicyStatus originalPolicyStatus = PolicyStatus.valueOf(policy.getPolicyStatus());
        boolean isBPolicyWithCancellation = PolicyType.valueOf(policy.getPolicyType()).isBorrowerPolicy() &&
                StringUtils.isNotEmpty(policyDTO.getCancellationDate());
        boolean isLPPolicyExpiring = PolicyType.valueOf(policy.getPolicyType()).isLenderPlaced() &&
                originalPolicyStatus.isExpiring();
        if (originalPolicyStatus != PolicyStatus.PENDING_VERIFICATION  && !isBPolicyWithCancellation && !isLPPolicyExpiring) {
            throw new CtracException("Policy must be Pending Verification to make an edit");
        }
        overridePolicyTypeEoi(policyDTO);
        policyValidationService.validateEdit(policyDTO, filesUploaded, originalPolicyStatus);
        return policyService.editPolicy(policy, policyDTO, filesUploaded, userRequestInfo);
    }

    @Override
    public PolicyDTO overridePolicy(Long policyId, OverrideLpPolicyDTO overrideLpPolicyDTO, UserRequestInfo userRequestInfo) {
        ProofOfCoverage policy = policyService.getExistingProofOfCoverage(policyId, overrideLpPolicyDTO.getLpPolicy());
        policyValidationService.validateOverride(overrideLpPolicyDTO.getLpPolicy(), policy.getPolicyStatus_());
        return policyService.overridePolicy(policy, overrideLpPolicyDTO, userRequestInfo);
    }

    @Override
    public PolicyDTO verifyPolicy(Long policyId, PolicyDTO policyDTO, UserRequestInfo userRequestInfo) {
        ProofOfCoverage policy = policyService.getExistingProofOfCoverage(policyId, policyDTO);
        if (PolicyStatus.valueOf(policy.getPolicyStatus()) != PolicyStatus.PENDING_VERIFICATION) {
            throw new CtracException("Policy must be Pending Verification to perform a verification");
        }
        if (StringUtils.equals(userRequestInfo.getUserSid(), policy.getUpdatedBy())) {
            throw new CtracException("Policy can not be verified by same person that modified it");
        }
        overridePolicyTypeEoi(policyDTO);
        policyValidationService.validateVerify(policyDTO, policy.getPolicyStatus_());
        return policyService.verifyPolicy(policyDTO, userRequestInfo);
    }

    @Override
    public Map<String, BIRRuleConclusionDTO> reviewPolicy(PolicyDTO policyDTO) {
        overridePolicyTypeEoi(policyDTO);
        //TODO when flood BIR is switched to use review API, add form validation here
        if (InsuranceType.GENERAL == EnumUtils.getEnum(InsuranceType.class, policyDTO.getInsuranceType())) {
            policyValidationService.validateReview(policyDTO);
        }
        return policyService.getPolicyConclusions(policyDTO);
    }

    private void overridePolicyTypeEoi(PolicyDTO policyDTO){
        //override policy type when Evidence Of Insurance is provided
        if (policyDTO.getEvidenceOfInsurance() != null) {
            policyDTO.setPolicyType(EvidenceOfInsuranceMapper
                    .getPolicyType(policyDTO.getEvidenceOfInsurance()).name());
        }
    }
}