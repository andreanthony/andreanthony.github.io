package com.jpmorgan.cb.wlt.apis.document.dao.repository;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.types.EntityCollateralDocumentRelation;
import org.springframework.data.jpa.repository.JpaRepository;



public interface EntityCollateralDocumentRepository extends JpaRepository<EntityCollateralDocumentRelation, Long> {

    void deleteByDocument(CollateralDocument document);

}
