package com.jpmorgan.cb.wlt.apis.loan.dao;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.io.Serializable;

public class LoanBorrowerPk implements Serializable {
    private static final long serialVersionUID = -1;

    private Loan loan;
    private Long borrowerId;

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public Long getBorrowerId() {
        return borrowerId;
    }

    public void setBorrowerId(Long borrowerId) {
        this.borrowerId = borrowerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {return true;}
        if (o == null || getClass() != o.getClass()) {return false;}

        LoanBorrowerPk that = (LoanBorrowerPk) o;
        return new EqualsBuilder()
                .append(loan, that.loan)
                .append(borrowerId, that.borrowerId)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(loan)
                .append(borrowerId)
                .toHashCode();
    }
}
