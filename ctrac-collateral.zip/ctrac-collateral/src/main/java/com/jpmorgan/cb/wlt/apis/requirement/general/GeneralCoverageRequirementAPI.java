package com.jpmorgan.cb.wlt.apis.requirement.general;

import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageSourceDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralRequiredCoverageSourceService;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.apis.upload.services.FileUploadService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api")
public class GeneralCoverageRequirementAPI {
    private static final Logger logger = LoggerFactory.getLogger(GeneralCoverageRequirementAPI.class);

    private GeneralRequiredCoverageSourceService generalRequiredCoverageSourceService;
    private FileUploadService fileUploadService;

    @Autowired
    public GeneralCoverageRequirementAPI(GeneralRequiredCoverageSourceService generalRequirementsService,
                                         FileUploadService fileUploadService) {
        assert(generalRequirementsService != null);
        this.generalRequiredCoverageSourceService = generalRequirementsService;
        assert(fileUploadService != null);
        this.fileUploadService = fileUploadService;
    }


    @RequestMapping(value = "/requirement/general/{sourceId}",method = RequestMethod.GET )
    public ResponseEntity<GeneralRequiredCoverageSourceDTO> getById(@PathVariable Long sourceId) {
        return ResponseEntity.ok(generalRequiredCoverageSourceService.getById(sourceId));
    }

    @RequestMapping(value = "/collateral/{collateralId}/requirement/general/coverages",method = RequestMethod.GET )
    public ResponseEntity<List<GeneralCoverageDTO>> getCoveragesByCollateralId(@PathVariable Long collateralId) {
        return ResponseEntity.ok(generalRequiredCoverageSourceService.getCoveragesByCollateralId(collateralId));
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/requirement/general", method = RequestMethod.POST)
    public ResponseEntity<GeneralRequiredCoverageSourceDTO> save(@Valid @RequestBody GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
            @RequestAttribute UserRequestInfo userRequestInfo) {
        List<FileUploadAttachmentDTO> filesUploaded = fileUploadService
                .getAttachments(generalRequiredCoverageSourceDTO.getUploadBucketName());
        try{
             return ResponseEntity.ok(generalRequiredCoverageSourceService.save(generalRequiredCoverageSourceDTO, filesUploaded, userRequestInfo));
        }
        finally {
            if(CollectionUtils.isNotEmpty(filesUploaded)) {
                fileUploadService.deleteAllAttachments(generalRequiredCoverageSourceDTO.getUploadBucketName());
            }
        }
    }

    @Secured(CtracRole.ROLE_VERIFIER)
    @RequestMapping(value = "/requirement/general/verify", method = RequestMethod.POST)
    public ResponseEntity<GeneralRequiredCoverageSourceDTO> verify(
            @Valid @RequestBody GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
            @RequestAttribute UserRequestInfo userRequestInfo) {
        return ResponseEntity.ok(
                generalRequiredCoverageSourceService.verify(generalRequiredCoverageSourceDTO, userRequestInfo));
     }

    @RequestMapping(value = "/collateral/{collateralId}/requirement/general/verified",method = RequestMethod.GET )
    public ResponseEntity<GeneralRequiredCoverageSourceDTO> getVerifiedByCollateralId(@PathVariable Long collateralId) {
        return ResponseEntity.ok(
                generalRequiredCoverageSourceService.getVerifiedOrPendingByCollateralId(collateralId));
    }

    @Secured(CtracRole.ROLE_WRITER)
    @RequestMapping(value = "/requirement/general/{sourceId}", method = RequestMethod.DELETE)
    public ResponseEntity delete(@PathVariable Long sourceId,
                                 @RequestAttribute UserRequestInfo userRequestInfo) {
        generalRequiredCoverageSourceService.deleteSource(sourceId, userRequestInfo);
        return ResponseEntity.ok().build();
    }

}
