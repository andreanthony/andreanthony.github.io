package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3CalculatedCoverageDateBuilder;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;

import java.util.Date;
import java.util.List;

public class FloodCoverageDateRule extends AbstractCoverageDateRule {

    protected InsuranceType getInsuranceType() {
        return InsuranceType.FLOOD;
    }

    @Override
    protected List<C3CalculatedCoverageDate> getC3CalculatedCoverageDates(C3ResponseDTO c3ResponseDTO) {
        return c3ResponseDTO.getCalculatedFloodCoverageDates();
    }

    @Override
    protected Date getOverrideCalculatedCoverageDate(C3RequestDTO c3RequestDTO) {
        return c3RequestDTO.getOverrideFloodCoverageDate_();
    }

    @Override
    protected void addCalculatedCoverageDates(List<C3CalculatedCoverageDate> calculatedFloodCoverageDates, Date date, C3Policy policy) {
        policy.getProvidedCoverages().forEach(providedCoverage ->
            addCalculatedCoverageDate(calculatedFloodCoverageDates, date, policy, providedCoverage));
    }

    @Override
    protected void addCalculatedCoverageDate(List<C3CalculatedCoverageDate> calculatedFloodCoverageDates, Date date, C3Coverage c3Coverage) {
        addCalculatedCoverageDate(calculatedFloodCoverageDates, date, null, c3Coverage);
    }

    private void addCalculatedCoverageDate(List<C3CalculatedCoverageDate> calculatedFloodCoverageDates, Date date, C3Policy policy, C3Coverage c3Coverage) {
        Long insurableAssetId = c3Coverage.getInsurableAssetId();
        InsurableAssetType insurableAssetType = c3Coverage.getInsurableAssetType_();
        FloodCoverageType floodCoverageType = c3Coverage.getFloodCoverageType();
        if (floodCoverageType.isMatching(FloodCoverageType.PRIMARY)) {
            addCalculatedCoverageDates(calculatedFloodCoverageDates, date, policy, insurableAssetId, insurableAssetType, FloodCoverageType.PRIMARY);
        }
        if (floodCoverageType.isMatching(FloodCoverageType.EXCESS)) {
            addCalculatedCoverageDates(calculatedFloodCoverageDates, date, policy, insurableAssetId, insurableAssetType, FloodCoverageType.EXCESS);
        }
    }

    private void addCalculatedCoverageDates(List<C3CalculatedCoverageDate> calculatedFloodCoverageDates, Date coverageDate,
                                    C3Policy policy, Long insurableAssetId, InsurableAssetType insurableAssetType, FloodCoverageType coverageType) {
        calculatedFloodCoverageDates.add(new C3CalculatedCoverageDateBuilder(InsuranceType.FLOOD.name(), coverageDate)
                .insurableAssetId(insurableAssetId)
                .coverageType(coverageType.name())
                .insurableAssetType(insurableAssetType)
                .policyId(policy == null? null: policy.getPolicyId())
                .build());
    }
}
