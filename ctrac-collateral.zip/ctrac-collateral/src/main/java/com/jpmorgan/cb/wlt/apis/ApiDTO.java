package com.jpmorgan.cb.wlt.apis;

public class ApiDTO {
    private String api;
    private String description;

    public String getApi() {
        return api;
    }

    public void setApi(String api) {
        this.api = api;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
