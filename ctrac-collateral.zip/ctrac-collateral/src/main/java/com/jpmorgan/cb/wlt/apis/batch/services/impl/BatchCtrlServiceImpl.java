package com.jpmorgan.cb.wlt.apis.batch.services.impl;

import com.jpmorgan.cb.wlt.apis.batch.services.BatchCtrlService;
import com.jpmorgan.cb.wlt.dao.BatchCtrl;
import com.jpmorgan.cb.wlt.dao.BatchCtrlRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.jpmorgan.cb.wlt.config.enums.SchedulerJob.EOD_C3_JOB;
import static com.jpmorgan.cb.wlt.config.enums.SchedulerJob.FULL_EOD_JOB;

@Service
public class BatchCtrlServiceImpl implements BatchCtrlService {

private static final Logger logger = LoggerFactory.getLogger(BatchCtrlServiceImpl.class);
private static final Character DB_FLAG_YES = 'Y';
@Autowired
private BatchCtrlRepository batchCtrlRepository;


    private static final List<String> BATCH_TYPES_TO_FORWARD;

    static {
        List<String> batchTypes = new ArrayList<>();
        batchTypes.add(FULL_EOD_JOB.getName());
        batchTypes.add(EOD_C3_JOB.getName());
        BATCH_TYPES_TO_FORWARD = Collections.unmodifiableList(batchTypes);
    }

    @Override
    public boolean isBatchRunning() {
        logger.info("Batch check interceptor::Begin");
        List<BatchCtrl> runningBatchProcesses = batchCtrlRepository.findByRunningAndBatchTypeIn(DB_FLAG_YES,BATCH_TYPES_TO_FORWARD);
        if (!runningBatchProcesses.isEmpty()) {
            logger.info("A batch process is running. Intercepting request...");
            return true;
        }
        logger.info("Batch check interceptor::End");
        return false;
    }
}
