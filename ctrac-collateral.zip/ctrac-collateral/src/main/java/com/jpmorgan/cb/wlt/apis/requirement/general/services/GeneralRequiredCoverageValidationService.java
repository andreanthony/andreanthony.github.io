package com.jpmorgan.cb.wlt.apis.requirement.general.services;

import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageSourceDTO;

import javax.validation.Valid;

public interface GeneralRequiredCoverageValidationService {

    void validateVerify(@Valid GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                        GeneralRequiredCoverageSourceDTO pendingVerification);

    void validateCreate(@Valid GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                        GeneralRequiredCoverageSourceDTO pendingVerification);

    void validateEdit(@Valid GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                      GeneralRequiredCoverageSourceDTO pendingVerification);

    void validateDelete(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO, boolean canDelete);
}
