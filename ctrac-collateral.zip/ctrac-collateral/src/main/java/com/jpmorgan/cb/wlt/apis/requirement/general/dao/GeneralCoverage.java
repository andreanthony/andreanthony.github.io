package com.jpmorgan.cb.wlt.apis.requirement.general.dao;

import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "TLCP_GENERAL_COVERAGE")
public class GeneralCoverage extends AuditableEntity implements Serializable {
    private static final long serialVersionUID = -1;

    @Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "generalCoverageSeqGenerator")
	@TableGenerator(name = "generalCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_GENERAL_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Column(name = "RID")
	private Long rid;

    @Column(name = "COVERAGE_TYPE")
    private String coverageType;

    @Column(name = "COVERAGE_GROUP")
    private String coverageGroup;

    @Column(name = "LP_REQUIRED")
    private boolean lenderPlacementRequired;

    @Column(name = "AGGREGATE_AMT_REQUIRED")
    private boolean aggregateAmountRequired;

    @Column(name = "DEDUCTIBLE_AMT_REQUIRED")
    private boolean deductibleAmountRequired;

    @Column(name = "ANNUAL_REVIEW_REQUIRED")
    private boolean annualReviewRequired;

    @Column(name = "LP_DISPLAY_FORMAT")
    private String lpDisplayFormat;

    @Column(name = "BP_DISPLAY_FORMAT")
    private String bpDisplayFormat;

    @Column(name = "ACTIVE")
    private Boolean active;

    @Column(name = "SORT_ORDER")
    private Integer sortOrder;

    public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public boolean isLenderPlacementRequired() {
        return lenderPlacementRequired;
    }

    public void setLenderPlacementRequired(boolean lenderPlacementRequired) {
        this.lenderPlacementRequired = lenderPlacementRequired;
    }

    public boolean isAggregateAmountRequired() {
        return aggregateAmountRequired;
    }

    public void setAggregateAmountRequired(boolean aggregateAmountRequired) {
        this.aggregateAmountRequired = aggregateAmountRequired;
    }

    public boolean isDeductibleAmountRequired() {
        return deductibleAmountRequired;
    }

    public void setDeductibleAmountRequired(boolean deductibleAmountRequired) {
        this.deductibleAmountRequired = deductibleAmountRequired;
    }

    public boolean isAnnualReviewRequired() {
        return annualReviewRequired;
    }

    public void setAnnualReviewRequired(boolean annualReviewRequired) {
        this.annualReviewRequired = annualReviewRequired;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getCoverageGroup() {
        return coverageGroup;
    }

    public void setCoverageGroup(String coverageGroup) {
        this.coverageGroup = coverageGroup;
    }

    public String getLpDisplayFormat() {
        return lpDisplayFormat;
    }

    public void setLpDisplayFormat(String lpDisplayFormat) {
        this.lpDisplayFormat = lpDisplayFormat;
    }

    public String getBpDisplayFormat() {
        return bpDisplayFormat;
    }

    public void setBpDisplayFormat(String bpDisplayFormat) {
        this.bpDisplayFormat = bpDisplayFormat;
    }

    public GeneralCoverageDTO toGeneralCoverageDTO()
    {
        GeneralCoverageDTO generalCoverageDTO = new GeneralCoverageDTO();
       BeanUtils.copyProperties(this,generalCoverageDTO);
        return generalCoverageDTO;
    }

    public GeneralCoverage fromGeneralCoverageDTO(GeneralCoverageDTO generalCoverageDTO)
    {
        BeanUtils.copyProperties(generalCoverageDTO, this);
        return this;
    }

}
