package com.jpmorgan.cb.wlt.config.mappings;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.BusinessAssets;
import com.jpmorgan.cb.wlt.apis.collateral.types.dao.RealEstate;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;

public class CollateralDetailsMapping extends ModelMapper {

    public static PropertyMap<RealEstate, CollateralDTO>  getRealEstateDetailMapping() {
        return new PropertyMap <RealEstate, CollateralDTO>() {
            protected void configure() {
                map().setStreetAddress(source.getCollateralAddress().getStreetAddress());
                map().setUnitOrBuilding(source.getCollateralAddress().getUnitOrBuilding());
                map().setCounty(source.getCollateralAddress().getCounty());
                map().setCity(source.getCollateralAddress().getCity());
                map().setState(source.getCollateralAddress().getState());
                map().setZipCode(source.getCollateralAddress().getZipCode());
                map().setMarketEmailAddress(source.getEmailDetails().getEmailTo());
            }
        };
    }

    public static PropertyMap<BusinessAssets, CollateralDTO>  getBusinessAssetsDetailMapping() {
        return new PropertyMap <BusinessAssets, CollateralDTO>() {
            protected void configure() {
                map().setStreetAddress(source.getCollateralAddress().getStreetAddress());
                map().setUnitOrBuilding(source.getCollateralAddress().getUnitOrBuilding());
                map().setCounty(source.getCollateralAddress().getCounty());
                map().setCity(source.getCollateralAddress().getCity());
                map().setState(source.getCollateralAddress().getState());
                map().setZipCode(source.getCollateralAddress().getZipCode());
                map().setMarketEmailAddress(source.getEmailDetails().getEmailTo());
            }
        };
    }
}
