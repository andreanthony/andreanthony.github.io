package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.BirCollateralDetails;
import com.jpmorgan.cb.wlt.apis.policy.dao.BirProofOfCovDetails;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyCollateralDetailsDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

public class GeneralBirProofOfCovDetailsMapper extends AbstractBirProofOfCovDetailsMapper{

    @Override
    public void addToDTO(PolicyDTO dto, BirProofOfCovDetails model) {
        super.addToDTO(dto, model);

        dto.setPolicyWrittenAtRcv(model.getPolicyWrittenAtRcv());
        dto.setJpmAdditionalInsured(model.getJpmAdditionalInsured());

        if(CollectionUtils.isNotEmpty(model.getBirCollateralDetails())){
            //PolicyCollateralDetailsDTO has been already created by the AbstractPolicyMapper - Just need to append BIR Collateral data to it
            model.getBirCollateralDetails().forEach(birCollateralDetails -> {
                PolicyCollateralDetailsDTO foundPolicyCollateralDto = dto.getCollateralCoverages().stream().filter(policyCollateralDetailsDTO ->
                        birCollateralDetails.getCollateralRid().equals(policyCollateralDetailsDTO.getCollateralId()))
                        .findFirst().orElse(null);
                if(foundPolicyCollateralDto != null) {
                    birCollateralDetails.mergeToCollateralCoverageDTO(foundPolicyCollateralDto, InsuranceType.GENERAL.name());
                }
            });
        }
    }

    @Override
    public boolean map(PolicyDTO dto, BirProofOfCovDetails model) {
        super.map(dto,model);
        if(CollectionUtils.isNotEmpty(dto.getCollateralCoverages())){
            dto.getCollateralCoverages().forEach(policyCollateralDetailsDTO ->
            {
                BirCollateralDetails birCollateralDetails = model.getBirCollateralDetails().stream()
                        .filter(modelObj -> modelObj.getCollateralRid().equals(policyCollateralDetailsDTO.getCollateralId()))
                        .findFirst().orElse(new BirCollateralDetails());
                birCollateralDetails.map(policyCollateralDetailsDTO, InsuranceType.GENERAL.name());
                if(birCollateralDetails.getRid() == null){
                    birCollateralDetails.setBirProofOfCovDetails(model);
                    model.getBirCollateralDetails().add(birCollateralDetails);
                }
            });

            List<BirCollateralDetails> colDetailsToDelete = new ArrayList<>();
            for(BirCollateralDetails colDetModel : model.getBirCollateralDetails()){
                PolicyCollateralDetailsDTO policyCollateralDetailsDTO = dto.getCollateralCoverages().stream()
                        .filter(dtoObject -> dtoObject.getCollateralId().equals(colDetModel.getCollateralRid()))
                        .findFirst().orElse(null);
                if(policyCollateralDetailsDTO == null){
                    colDetailsToDelete.add(colDetModel);
                }
            }

            model.getBirCollateralDetails().removeAll(colDetailsToDelete);
        }
        model.setPolicyWrittenAtRcv(dto.getPolicyWrittenAtRcv());
        model.setJpmAdditionalInsured(dto.getJpmAdditionalInsured());
        return true;
    }
}