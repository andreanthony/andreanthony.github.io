package com.jpmorgan.cb.wlt.apis.requirement.general.dtos;

import com.jpmorgan.cb.wlt.apis.event.AbstractPublishEventRequest;
import com.jpmorgan.cb.wlt.apis.event.CollateralEventSection;
import org.apache.commons.lang3.StringUtils;

public class GeneralRequiredCoveragePublishEventRequest extends AbstractPublishEventRequest {

	private static final CollateralEventSection COLLATERAL_EVENT_SECTION = CollateralEventSection.GENERAL_REQUIRED_COVERAGE;
	GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO;

	public GeneralRequiredCoveragePublishEventRequest(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO) {
		this.generalRequiredCoverageSourceDTO = generalRequiredCoverageSourceDTO;
	}

	@Override
	public String getIdentifier() {
		if (this.generalRequiredCoverageSourceDTO.getDocumentDate() != null) {
			return this.generalRequiredCoverageSourceDTO.getDocumentDate();
		}
		return StringUtils.EMPTY;
	}

	@Override
	public Long getCollateralRid() {
		return generalRequiredCoverageSourceDTO.getCollateralRid();
	}

	@Override
	public CollateralEventSection getCollateralEventSection() {
		return COLLATERAL_EVENT_SECTION;
	}
}
