package com.jpmorgan.cb.wlt.apis.c3;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.services.C3AdminService;
import com.jpmorgan.cb.wlt.apis.c3.services.CollateralCoverageComputationService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3WorkflowRequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ExceptionLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Secured(CtracRole.ROLE_API)
@RestController
@RequestMapping(value = "/api/c3")
public class C3API {

    private static final Logger logger = LoggerFactory.getLogger(C3API.class);

    private CollateralCoverageComputationService c3Service;
    private C3AdminService c3AdminService;

    @Autowired
    public C3API(CollateralCoverageComputationService c3Service, C3AdminService c3AdminService) {
        assert(c3Service != null);
        this.c3Service = c3Service;
        assert(c3AdminService != null);
        this.c3AdminService = c3AdminService;
    }

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<C3ResponseDTO> evaluateAndApply(@RequestBody C3RequestEventDTO c3RequestEventDTO) {
        try {
            C3ResponseDTO c3ResponseDTO = c3Service.evaluate(c3RequestEventDTO);
            c3Service.apply(c3ResponseDTO);
            return ResponseEntity.ok(c3ResponseDTO);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            throw new CtracException("C3 service interruption ", ExceptionLevel.GENEOS);
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/evaluate")
    public ResponseEntity<C3ResponseDTO> evaluate(@RequestBody C3RequestDTO c3RequestDTO) {
        try {
            return ResponseEntity.ok(c3Service.evaluate(c3RequestDTO));
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            throw new CtracException("C3 service interruption ", ExceptionLevel.GENEOS);
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/evaluate/gap")
    public ResponseEntity<C3ResponseDTO> evaluateGap(@RequestBody C3RequestEventDTO c3RequestEventDTO) {
        try {
            return ResponseEntity.ok(c3Service.evaluateGap(c3RequestEventDTO));
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            throw new CtracException("C3 service interruption ", ExceptionLevel.GENEOS);
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/admin/cancel")
    public ResponseEntity<C3PolicyCancellation> evaluate(@RequestBody C3WorkflowRequestEventDTO workflowRequestEventDTO) {
        return ResponseEntity.ok(c3AdminService.cancel(workflowRequestEventDTO));
    }
}
