package com.jpmorgan.cb.wlt.apis.loan.services.impl;

import com.jpmorgan.cb.wlt.apis.entity.services.EntityService;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.UpbDTO;
import com.jpmorgan.cb.wlt.apis.loan.dao.*;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanService;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanStatus;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class LoanServiceImpl implements LoanService {

    private EntityService entityService;
    private LoanRepository loanRepository;
    private LoanCollateralRepository loanCollateralRepository;
    private LoanUpbDetailsRepository loanUpbDetailsRepository;
    private ModelMapper modelMapper;
    private static final DateFormatter DEFAULT_DATE_FORMATTER = new DefaultDateFormatter();


    @Autowired
    public LoanServiceImpl(EntityService entityService,LoanRepository loanRepository,
                           LoanCollateralRepository loanCollateralRepository,
                           LoanUpbDetailsRepository loanUpbDetailsRepository, ModelMapper modelMapper )
    {
        assert(entityService != null);
        this.entityService = entityService;
        assert(loanRepository != null);
        this.loanRepository = loanRepository;
        assert(loanCollateralRepository != null);
        this.loanCollateralRepository = loanCollateralRepository;
        assert(loanUpbDetailsRepository != null);
        this.loanUpbDetailsRepository = loanUpbDetailsRepository;
        assert(modelMapper != null);
        this.modelMapper = modelMapper;
    }

    @Override
    public LoanDTO createLoan(LoanDTO loanDTO,UserRequestInfo userRequestInfo) {
        Loan loan =modelMapper.map(loanDTO, Loan.class);
        List<LoanCollateral> loanCollaterals = new ArrayList<LoanCollateral>();
        LoanCollateral loanCollateral = new LoanCollateral();
        loanCollateral.setLoan(loan);
        loanCollateral.setCollateralId(loanDTO.getCollateralId());
        loanCollateral.setPrimaryFlag("Yes");
        loanCollaterals.add(loanCollateral);
       loan.setLoanCollaterals(loanCollaterals);
        loan.setAuditInfo(userRequestInfo);
        loan = loanRepository.save(loan);
        return modelMapper.map(loan, LoanDTO.class);

    }

    @Override
    public List<LoanDTO> getLoans(Long collateralId, Boolean active, Boolean primary) {
        List<LoanDTO> loanDTOs = getLoans(collateralId);
        return loanDTOs.stream()
                .filter(loanDTO -> (primary == null || primary == loanDTO.getPrimaryFlag()) && (active == null || active == (loanDTO.getReleaseDate() == null)))
                .collect(Collectors.toList());
    }

    @Override
    public List<LoanDTO> getActiveLoans(Long collateralId) {
        List<LoanDTO> loanDTOs = getLoans(collateralId);
        return loanDTOs.stream()
                .filter(loanDTO -> LoanStatus.ACTIVE.name().equals(loanDTO.getStatus()))
                .collect(Collectors.toList());
    }

    @Override
    public List<LoanDTO> getLoans(Long collateralId) {
        List<LoanDTO> loanDTOs = new ArrayList<>();
        List<LoanCollateral> loanCollaterals = loanCollateralRepository.findByCollateralId(collateralId);
        loanCollaterals.forEach(loanCollateral -> {
            LoanDTO loanDTO = modelMapper.map(loanCollateral.getLoan(), LoanDTO.class);
            loanDTO.setCollateralId(loanCollateral.getCollateralId());
            loanDTO.setStatus(loanCollateral.getLoan().getStatus());
            loanDTO.setPrimaryFlag("Yes".equals(loanCollateral.getPrimaryFlag()));
            loanDTO.setBorrowers(entityService.getEntities(loanCollateral.getLoan().getBorrowerIds()));
            loanDTOs.add(loanDTO);
        });
        return loanDTOs;
    }


    @Override
    public LoanDTO getLoan(Long loanId) {
        Optional<Loan> optional = loanRepository.findById(loanId);
        if (!optional.isPresent()) {
            throw new CtracException("No Loan available with rid=" + loanId);
        }
        Loan loan = optional.get();
        LoanDTO loanDTO = modelMapper.map(loan, LoanDTO.class);
        loanDTO.setStatus(loan.getStatus());
        loanDTO.setBorrowers(entityService.getEntities(loan.getBorrowerIds()));
        return loanDTO;
    }

    @Override
    public List<UpbDTO> getLoanUPBDetails(Long loanId) {
        List<UpbDTO> upbDTOs = new ArrayList<UpbDTO>();
        List<LoanUpbDetails> upbList = loanUpbDetailsRepository.findByLoanRid(loanId);
        upbList.forEach(upb -> {
            UpbDTO upbDTO = modelMapper.map(upb, UpbDTO.class);
            upbDTO.setRid(upb.getRid());
            upbDTO.setUpb(upb.getUpb());
            upbDTO.setUpbDate(upb.getUpbDate() !=null ? DEFAULT_DATE_FORMATTER.print(upb.getUpbDate()) : null );
            upbDTOs.add(upbDTO);
        });
        return upbDTOs;
    }

    @Override
    public List<LoanDTO> verifyLoanSection(Long collateralId, UserRequestInfo userRequestInfo) {
        //need to revisit when we implment the angular loan borrower section
        List<Loan> loans = new ArrayList<Loan>();
        getLoans(collateralId).forEach(loanDTO -> {
         if (EnumUtils.getEnum(LoanStatus.class, loanDTO.getStatus()) == LoanStatus.PENDING_VERIFICATION) {
           Loan loan = new Loan();
                modelMapper.map(loanDTO, loan);
                loan.setStatus(LoanStatus.ACTIVE.name());
                loans.add(loan);
            }
        });

        if (! CollectionUtils.isEmpty(loans)) {
            loanRepository.saveAll(loans);
        }
      return getActiveLoans(collateralId);
    }

}
