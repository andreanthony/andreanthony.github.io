package com.jpmorgan.cb.wlt.apis.c3.dtos.builders;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3AlertEmail;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3CalculatedCoverageDate;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequiredCoverage;
import com.jpmorgan.cib.wlt.ctrac.enums.C3AlertEmailTemplate;

public class C3AlertEmailBuilder {
    private C3AlertEmail c3AlertEmail = new C3AlertEmail();

    public C3AlertEmailBuilder(C3AlertEmailTemplate alertEmailTemplate) {
        c3AlertEmail.setAlertTemplate(alertEmailTemplate);
    }

    public C3AlertEmailBuilder calculatedCoverageDate(C3CalculatedCoverageDate calculatedCoverageDate) {
        c3AlertEmail.setCalculatedCoverageDate(calculatedCoverageDate);
        return this;
    }

    public C3AlertEmailBuilder lpPolicyId(Long lpPolicyId) {
        c3AlertEmail.setLpPolicyId(lpPolicyId);
        return this;
    }

    public C3AlertEmailBuilder collateralRid(Long collateralRid) {
        c3AlertEmail.setCollateralRid(collateralRid);
        return this;
    }

    public C3AlertEmail build() {
        return c3AlertEmail;
    }

    public C3AlertEmailBuilder requiredCoverage(C3RequiredCoverage requiredCoverage) {
        c3AlertEmail.setRequiredCoverage(requiredCoverage);
        return this;
    }
}
