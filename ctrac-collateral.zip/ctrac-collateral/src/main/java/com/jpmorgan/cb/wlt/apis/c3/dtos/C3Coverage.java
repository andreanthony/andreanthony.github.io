package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.ObjectUtils;

import java.beans.Transient;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

public class C3Coverage implements Serializable {
    private static final long serialVersionUID = -1;
    private Long insurableAssetId;
    private String insurableAssetType;
    private String coverageType;
    private BigDecimal coverageAmount;
    private BigDecimal deductibleAmount;
    private String insuranceType;

    public Long getInsurableAssetId() {
        return insurableAssetId;
    }

    public void setInsurableAssetId(Long insurableAssetId) {
        this.insurableAssetId = insurableAssetId;
    }

    public String getInsurableAssetType() {
        return insurableAssetType;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public InsurableAssetType getInsurableAssetType_() {
        return EnumUtils.getEnum(InsurableAssetType.class, insurableAssetType);
    }

    public void setInsurableAssetType(String insurableAssetType) {
        this.insurableAssetType = insurableAssetType;
    }

    public String getCoverageType() {
        return coverageType;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public FloodCoverageType getFloodCoverageType() {
        return EnumUtils.getEnum(FloodCoverageType.class, coverageType);
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public BigDecimal getCoverageAmount() {
        return ObjectUtils.defaultIfNull(coverageAmount, BigDecimal.ZERO);
    }

    public void setCoverageAmount(BigDecimal coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public BigDecimal getDeductibleAmount() {
        return ObjectUtils.defaultIfNull(deductibleAmount, BigDecimal.ZERO);
    }

    public void setDeductibleAmount(BigDecimal deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public InsuranceType getInsuranceType_() {
        return EnumUtils.getEnum(InsuranceType.class, insuranceType);
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isMatching(String coverageType, Long insurableAssetId) {
        return Objects.equals(this.coverageType, coverageType) && Objects.equals(this.insurableAssetId, insurableAssetId);
    }

}
