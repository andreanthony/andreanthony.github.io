package com.jpmorgan.cb.wlt.apis.collateral.types.services;

import com.jpmorgan.cb.wlt.apis.ApiDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.types.CollateralType;
import com.jpmorgan.cb.wlt.apis.collateral.types.dto.CreateCollateralDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

import java.util.List;

public interface CollateralCreationService {
    List<ApiDTO> getCollateralTypeAPIs();
    CollateralDTO createCollateral(CreateCollateralDTO createCollateralDTO, CollateralType collateralType, UserRequestInfo userRequestInfo);
}
