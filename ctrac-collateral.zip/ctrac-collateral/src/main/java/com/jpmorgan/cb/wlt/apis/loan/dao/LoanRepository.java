package com.jpmorgan.cb.wlt.apis.loan.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LoanRepository extends JpaRepository<Loan, Long> {

    @Query("select loan from Loan loan, LoanCollateral loanCollateral " +
            "where loan.rid=loanCollateral.loan.rid and loanCollateral.collateralId=:collateralId")
    List<Loan> findByCollateralId(@Param(value = "collateralId") Long collateralId);

}
