package com.jpmorgan.cb.wlt.apis.floodDetermination.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeterminationDetailsViewRepository extends JpaRepository<DeterminationDetailsViewData, Long> {

    List<DeterminationDetailsViewData> findByCollateralRidAndStatus(Long collateralRid, String status);

}
