package com.jpmorgan.cb.wlt.apis.requirement.general.dtos;

public class GeneralCoverageDTO {
    private Long rid;
    private String coverageType;
    private String coverageGroup;
    private boolean lenderPlacementRequired;
    private boolean aggregateAmountRequired;
    private boolean deductibleAmountRequired;
    private boolean annualReviewRequired;
    private String lpDisplayFormat;
    private String bpDisplayFormat;
    private Integer sortOrder;
    private Boolean active;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public boolean isAggregateAmountRequired() {
        return aggregateAmountRequired;
    }

    public void setAggregateAmountRequired(boolean aggregateAmountRequired) {
        this.aggregateAmountRequired = aggregateAmountRequired;
    }

    public boolean isDeductibleAmountRequired() {
        return deductibleAmountRequired;
    }

    public void setDeductibleAmountRequired(boolean deductibleAmountRequired) {
        this.deductibleAmountRequired = deductibleAmountRequired;
    }

    public boolean isAnnualReviewRequired() {
        return annualReviewRequired;
    }

    public void setAnnualReviewRequired(boolean annualReviewRequired) {
        this.annualReviewRequired = annualReviewRequired;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public boolean isLenderPlacementRequired() {
        return lenderPlacementRequired;
    }

    public void setLenderPlacementRequired(boolean lenderPlacementRequired) {
        this.lenderPlacementRequired = lenderPlacementRequired;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getCoverageGroup() {
        return coverageGroup;
    }

    public void setCoverageGroup(String coverageGroup) {
        this.coverageGroup = coverageGroup;
    }

    public String getLpDisplayFormat() {
        return lpDisplayFormat;
    }

    public void setLpDisplayFormat(String lpDisplayFormat) {
        this.lpDisplayFormat = lpDisplayFormat;
    }

    public String getBpDisplayFormat() {
        return bpDisplayFormat;
    }

    public void setBpDisplayFormat(String bpDisplayFormat) {
        this.bpDisplayFormat = bpDisplayFormat;
    }
}
