package com.jpmorgan.cb.wlt.apis.policy.dao.populators;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.dao.DaoAuditDataPopulator;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import org.apache.commons.collections4.CollectionUtils;

public class PolicyAuditPopulator implements DaoAuditDataPopulator<ProofOfCoverage,UserRequestInfo> {

    @Override
    public void populateAuditInfo(ProofOfCoverage source, UserRequestInfo userRequestInfo) {
        source.setAuditInfo(userRequestInfo);

        if(source.getInsuranceAgent() != null){
            AgentAuditPopulator agentAuditPopulator = new AgentAuditPopulator();
            agentAuditPopulator.populateAuditInfo(source.getInsuranceAgent(),userRequestInfo);
        }
        if(source.getBlanketCoverage() != null){
            source.getBlanketCoverage().setAuditInfo(userRequestInfo);
        }
        if(source.getBirProofOfCovDetails() != null){
            BirProofOfCovDetailsAuditPopulator birPoCovDetailsAuditPopulator = new BirProofOfCovDetailsAuditPopulator();
            birPoCovDetailsAuditPopulator.populateAuditInfo(source.getBirProofOfCovDetails(), userRequestInfo);
        }

        if(CollectionUtils.isNotEmpty(source.getProvidedCoverages())){
            ProvidedCoverageAuditPopulator provCovAuditPop = new ProvidedCoverageAuditPopulator();
            source.getProvidedCoverages().forEach(providedCoverage ->
                provCovAuditPop.populateAuditInfo(providedCoverage, userRequestInfo)
            );
        }

    }
}
