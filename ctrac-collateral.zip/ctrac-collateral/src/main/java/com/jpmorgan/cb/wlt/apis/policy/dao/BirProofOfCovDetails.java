package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "TLCP_BIR_PROOF_OF_COV_DETAILS")
public class BirProofOfCovDetails extends AuditableEntity {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "birProofOfCovDetailsSeqGenerator")
    @TableGenerator(name = "birProofOfCovDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BIR_PROOF_OF_COV_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PROOF_OF_COVERAGE_RID")
    private ProofOfCoverage proofOfCoverage;

    @Column(name = "EOI_RECEIVED_DATE")
    private Date eoiReceivedDate;

    @Column(name = "EOI_TYPE")
    private String eoiType;

    @Column(name = "PROOF_OF_PAYMENT")
    private String proofOfPayment;

    @Column(name = "CONDO_ASSOCIATION_POLICY")
    private String condoAssociationPolicy;

    @Column(name = "NUMBER_OF_CONDO_UNITS")
    private Long numberOfCondoUnits;

    @Column(name = "JPM_MORTGAGEE_PAYEE")
    private String jpmMortgageePayee;

    @Column(name = "JPM_LENDER_LOSS_PAYEE")
    private String jpmLenderLossPayee;

    @Column(name = "JPM_ADDITIONAL_INSURED")
    private String jpmAdditionalInsured;

    @Column(name = "JPM_LIEN_POSITION")
    private String jpmLienPosition;

    @Column(name = "IND_CONDO_UNIT_NUMBERS")
    private String indCondoUnitNumbers;

    @Column(name = "SIGNED_BY_AGENT")
    private String signedByAgent;

    @Column(name = "POLICY_WRITTEN_AT_RCV")
    private String policyWrittenAtRcv;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "birProofOfCovDetails", orphanRemoval = true)
    private List<BirCollateralDetails> birCollateralDetails = new ArrayList<>();

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public ProofOfCoverage getProofOfCoverage() {
        return proofOfCoverage;
    }

    public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
        this.proofOfCoverage = proofOfCoverage;
    }

    public Date getEoiReceivedDate() {
        return eoiReceivedDate;
    }

    public void setEoiReceivedDate(Date eoiReceivedDate) {
        this.eoiReceivedDate = eoiReceivedDate;
    }

    public String getEoiType() {
        return eoiType;
    }

    public void setEoiType(String eoiType) {
        this.eoiType = eoiType;
    }

    public String getProofOfPayment() {
        return proofOfPayment;
    }

    public void setProofOfPayment(String proofOfPayment) {
        this.proofOfPayment = proofOfPayment;
    }

    public String getCondoAssociationPolicy() {
        return condoAssociationPolicy;
    }

    public void setCondoAssociationPolicy(String condoAssociationPolicy) {
        this.condoAssociationPolicy = condoAssociationPolicy;
    }

    public Long getNumberOfCondoUnits() {
        return numberOfCondoUnits;
    }

    public void setNumberOfCondoUnits(Long numberOfCondoUnits) {
        this.numberOfCondoUnits = numberOfCondoUnits;
    }

    public String getJpmMortgageePayee() {
        return jpmMortgageePayee;
    }

    public void setJpmMortgageePayee(String jpmMortgageePayee) {
        this.jpmMortgageePayee = jpmMortgageePayee;
    }

    public String getJpmLenderLossPayee() {
        return jpmLenderLossPayee;
    }

    public void setJpmLenderLossPayee(String jpmLenderLossPayee) {
        this.jpmLenderLossPayee = jpmLenderLossPayee;
    }

    public String getJpmLienPosition() {
        return jpmLienPosition;
    }

    public void setJpmLienPosition(String jpmLienPosition) {
        this.jpmLienPosition = jpmLienPosition;
    }

    public String getIndCondoUnitNumbers() {
        return indCondoUnitNumbers;
    }

    public void setIndCondoUnitNumbers(String indCondoUnitNumbers) {
        this.indCondoUnitNumbers = indCondoUnitNumbers;
    }

    public String getSignedByAgent() {
        return signedByAgent;
    }

    public void setSignedByAgent(String signedByAgent) {
        this.signedByAgent = signedByAgent;
    }

    public List<BirCollateralDetails> getBirCollateralDetails() {
        return birCollateralDetails;
    }

    public String getPolicyWrittenAtRcv() {
        return policyWrittenAtRcv;
    }

    public void setPolicyWrittenAtRcv(String policyWrittenAtRcv) {
        this.policyWrittenAtRcv = policyWrittenAtRcv;
    }

    public String getJpmAdditionalInsured() {
        return jpmAdditionalInsured;
    }

    public void setJpmAdditionalInsured(String jpmAdditionalInsured) {
        this.jpmAdditionalInsured = jpmAdditionalInsured;
    }

    public void setBirCollateralDetails(List<BirCollateralDetails> birCollateralDetails) {
        this.birCollateralDetails = birCollateralDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        BirProofOfCovDetails that = (BirProofOfCovDetails) o;

        return new EqualsBuilder()
                .append(rid, that.rid)
                .append(proofOfCoverage, that.proofOfCoverage)
                .append(eoiReceivedDate, that.eoiReceivedDate)
                .append(eoiType, that.eoiType)
                .append(proofOfPayment, that.proofOfPayment)
                .append(condoAssociationPolicy, that.condoAssociationPolicy)
                .append(numberOfCondoUnits, that.numberOfCondoUnits)
                .append(jpmMortgageePayee, that.jpmMortgageePayee)
                .append(jpmLenderLossPayee, that.jpmLenderLossPayee)
                .append(jpmAdditionalInsured, that.jpmAdditionalInsured)
                .append(jpmLienPosition, that.jpmLienPosition)
                .append(indCondoUnitNumbers, that.indCondoUnitNumbers)
                .append(signedByAgent, that.signedByAgent)
                .append(policyWrittenAtRcv, that.policyWrittenAtRcv)
                .append(birCollateralDetails, that.birCollateralDetails)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(proofOfCoverage)
                .append(eoiReceivedDate)
                .append(eoiType)
                .append(proofOfPayment)
                .append(condoAssociationPolicy)
                .append(numberOfCondoUnits)
                .append(jpmMortgageePayee)
                .append(jpmLenderLossPayee)
                .append(jpmAdditionalInsured)
                .append(jpmLienPosition)
                .append(indCondoUnitNumbers)
                .append(signedByAgent)
                .append(policyWrittenAtRcv)
                .append(birCollateralDetails)
                .toHashCode();
    }
}
