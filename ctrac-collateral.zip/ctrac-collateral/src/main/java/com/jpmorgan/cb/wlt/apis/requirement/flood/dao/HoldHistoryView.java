package com.jpmorgan.cb.wlt.apis.requirement.flood.dao;

import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="VLCP_HOLD_HISTORY")
public class HoldHistoryView {

    @Id
    @Column(name="HOLD_RID")
    private Long holdRid;

    @Column(name="ASSET_RID")
    private Long assetRid;

    @Column(name="COLLATERAL_RID")
    private Long collateralRid;

    @Column(name="BUILDING_NAME")
    private String buildingName;

    @Column(name="INSURABLE_ASSET_TYPE")
    private String insurableAssetType;

    @Column(name="COVERAGE_TYPE")
    private String coverageType;

    @OneToOne
    @JoinColumn(name = "PARENT_HOLD_RID")
    private HoldHistoryView parentHold;

    @Column(name="HOLD_TYPE")
    private String holdType;

    @Column(name="START_DATE")
    private Date startDate;

    @Column(name="HOLD_PERIOD")
    private String holdPeriod;

    @Column(name="LPI_DATE")
    private Date lpiDate;

    @Column(name="HOLD_STATUS")
    private String holdStatus;

    public Long getHoldRid() {
        return holdRid;
    }

    public void setHoldRid(Long holdRid) {
        this.holdRid = holdRid;
    }

    public Long getAssetRid() {
        return assetRid;
    }

    public void setAssetRid(Long assetRid) {
        this.assetRid = assetRid;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getInsurableAssetType() {
        return insurableAssetType;
    }

    public void setInsurableAssetType(String insurableAssetType) {
        this.insurableAssetType = insurableAssetType;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public HoldHistoryView getParentHold() {
        return parentHold;
    }

    public void setParentHold(HoldHistoryView parentHold) {
        this.parentHold = parentHold;
    }

    public String getHoldType() {
        return holdType;
    }

    public void setHoldType(String holdType) {
        this.holdType = holdType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getHoldPeriod() {
        return holdPeriod;
    }

    public void setHoldPeriod(String holdPeriod) {
        this.holdPeriod = holdPeriod;
    }

    public Date getLpiDate() {
        return lpiDate;
    }

    public void setLpiDate(Date lpiDate) {
        this.lpiDate = lpiDate;
    }

    public String getHoldStatus() {
        return holdStatus;
    }

    public void setHoldStatus(String holdStatus) {
        this.holdStatus = holdStatus;
    }

    @Transient
    public Date getHoldEndDate() {
        return EnumUtils.getEnum(VerificationStatus.class, holdStatus) == VerificationStatus.VERIFIED ?
                lpiDate : null;
    }

    @Transient
    public Date getParentStartDate() {
        // Initial hold start date is in the parent hold row
        return parentHold == null ? startDate : parentHold.getStartDate();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        HoldHistoryView that = (HoldHistoryView) o;
        return new EqualsBuilder()
                .append(holdRid, that.holdRid)
                .append(assetRid, that.assetRid)
                .append(collateralRid, that.collateralRid)
                .append(buildingName, that.buildingName)
                .append(insurableAssetType, that.insurableAssetType)
                .append(coverageType, that.coverageType)
                .append(parentHold, that.parentHold)
                .append(holdType, that.holdType)
                .append(startDate, that.startDate)
                .append(holdPeriod, that.holdPeriod)
                .append(lpiDate, that.lpiDate)
                .append(holdStatus, that.holdStatus)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(holdRid)
                .append(assetRid)
                .append(collateralRid)
                .append(buildingName)
                .append(insurableAssetType)
                .append(coverageType)
                .append(parentHold)
                .append(holdType)
                .append(startDate)
                .append(holdPeriod)
                .append(lpiDate)
                .append(holdStatus)
                .toHashCode();
    }

}
