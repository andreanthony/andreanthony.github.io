package com.jpmorgan.cb.wlt.apis.application.services.impl;

import com.jpmorgan.cb.wlt.apis.application.dto.ApplicationInfoDTO;
import com.jpmorgan.cb.wlt.apis.application.services.ApplicationManagementService;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplicationManagementServiceImpl implements ApplicationManagementService {

    private ReferenceDateService referenceDateService;
    private DefaultDateFormatter defaultDateFormatter = new DefaultDateFormatter();

    @Autowired
    public ApplicationManagementServiceImpl(ReferenceDateService referenceDateService) {
        assert(referenceDateService != null);
        this.referenceDateService = referenceDateService;
    }

    @Override
    public ApplicationInfoDTO getApplicationInfo() {
        ApplicationInfoDTO applicationInfoDTO = new ApplicationInfoDTO();
        applicationInfoDTO.setRefDate(defaultDateFormatter.print(referenceDateService.getCurrentReferenceDate()));
        return applicationInfoDTO;
    }
}
