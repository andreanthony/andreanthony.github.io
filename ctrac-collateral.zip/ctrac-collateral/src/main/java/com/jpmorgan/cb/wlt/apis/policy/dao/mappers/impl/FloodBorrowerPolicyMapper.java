package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.BirProofOfCovDetails;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

public class FloodBorrowerPolicyMapper extends AbstractFloodPolicyMapper implements DaoMapper<ProofOfCoverage, PolicyDTO> {

    @Override
    public PolicyDTO toDTO(ProofOfCoverage model) {
        PolicyDTO dto = super.toDTO(model);
        dto.setInsuredName(model.getInsuredName());

        if(model.getBirProofOfCovDetails() == null){
            model.setBirProofOfCovDetails(new BirProofOfCovDetails());
        }

        // TODO: create mapper for FloodBorrower policy.

        return dto;
    }

    @Override
    public boolean map(PolicyDTO dto, ProofOfCoverage model) {
        if (!super.map(dto, model)) {
            return false;
        }
        super.mapPolicyCoverages(dto, model);

        model.setInsuredName(dto.getInsuredName());
        if (model.getBirProofOfCovDetails() == null) {
            model.setBirProofOfCovDetails(new BirProofOfCovDetails());
        }

        // TODO: create mapper for FloodBorrower policy.

        return true;
    }
}
