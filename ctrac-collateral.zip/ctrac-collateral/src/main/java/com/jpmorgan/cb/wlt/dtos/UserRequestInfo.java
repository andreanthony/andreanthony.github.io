package com.jpmorgan.cb.wlt.dtos;

import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.CtracAppConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.io.Serializable;

public class UserRequestInfo implements Serializable {

    private static final long serialVersionUID = 230111867833097401L;
    private String userName;
    private UserEntitlementsDTO userEntitlementsDto=new UserEntitlementsDTO();

    public UserRequestInfo(String userName){this.userName = userName;}

    public String getUserSid() {
        return StringUtils.defaultString(userEntitlementsDto.getSid());
    }

    public String getUserFullName() {
        if( StringUtils.isEmpty(userEntitlementsDto.getFirstName()) &&
                StringUtils.isEmpty(userEntitlementsDto.getLastName())){
            return getUserSid();
        }
        return StringUtils.defaultString(userEntitlementsDto.getFirstName()).concat(" ")
                .concat(StringUtils.defaultString(userEntitlementsDto.getLastName())).trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserEntitlementsDto(UserEntitlementsDTO userEntitlementsDto) {
        this.userEntitlementsDto = userEntitlementsDto;
    }

    public UserEntitlementsDTO getUserEntitlementsDto() {
        return userEntitlementsDto;
    }


    public static UserRequestInfo createSystemUserRequest(){
        UserRequestInfo userRequestInfo = new UserRequestInfo(CtracAppConstants.SYSTEM_USER);
        UserEntitlementsDTO userEntitlementsDTO = new UserEntitlementsDTO();
        userEntitlementsDTO.setJanusUsername(userRequestInfo.getUserName());
        userEntitlementsDTO.setSid(userRequestInfo.getUserName());
        userEntitlementsDTO.setFirstName(StringUtils.EMPTY);
        userEntitlementsDTO.setLastName(StringUtils.EMPTY);
        userRequestInfo.setUserEntitlementsDto(userEntitlementsDTO);
        return userRequestInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        UserRequestInfo that = (UserRequestInfo) o;

        return new EqualsBuilder()
                .append(userName, that.userName)
                .append(userEntitlementsDto, that.userEntitlementsDto)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(userName)
                .append(userEntitlementsDto)
                .toHashCode();
    }
}