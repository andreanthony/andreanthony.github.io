package com.jpmorgan.cb.wlt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FeatureSwitchRepository extends JpaRepository<FeatureSwitch, Long> {

}
