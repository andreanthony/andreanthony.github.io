package com.jpmorgan.cb.wlt.apis.loan.services;

public enum LoanType {
    STANDARD("Standard"),
    SBA("SBA"),
    CHARGED_OFF("Charged Off"),
    FNMA("FNMA"),
    FHMC("FHMC"),
    EXTERNALLY_AGENTED("Externally Agented");

    private String displayName;

    LoanType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
