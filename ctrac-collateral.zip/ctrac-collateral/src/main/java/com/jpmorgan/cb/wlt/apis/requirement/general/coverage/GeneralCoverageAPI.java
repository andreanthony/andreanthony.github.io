package com.jpmorgan.cb.wlt.apis.requirement.general.coverage;

import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralCoverageService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/requirement/general/coverages")
public class GeneralCoverageAPI {
    private static final Logger logger = LoggerFactory.getLogger(GeneralCoverageAPI.class);

    private GeneralCoverageService generalCoverageService;

    @Autowired
    public GeneralCoverageAPI(GeneralCoverageService generalCoverageService) {
        assert(generalCoverageService != null);
        this.generalCoverageService = generalCoverageService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<GeneralCoverageDTO>> getAll() {
        List<GeneralCoverageDTO> generalCoverageDTOS = new ArrayList<>();
        try {
            generalCoverageDTOS = generalCoverageService.getGeneralCoverageTypes();
        } catch (CtracException e) {
            logger.error(e.getMessage(), e);
        }
        return ResponseEntity.ok(generalCoverageDTOS);
    }

}
