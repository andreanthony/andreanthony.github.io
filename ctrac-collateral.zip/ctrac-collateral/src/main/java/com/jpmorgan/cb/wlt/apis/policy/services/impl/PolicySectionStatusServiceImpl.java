package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverageRepository;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicySectionStatusService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class PolicySectionStatusServiceImpl implements PolicySectionStatusService {

    private ProofOfCoverageRepository proofOfCoverageRepository;
    private CollateralSectionService collateralSectionService;

    @Autowired
    public PolicySectionStatusServiceImpl(ProofOfCoverageRepository proofOfCoverageRepository,
                                          CollateralSectionService collateralSectionService) {
        assert(proofOfCoverageRepository != null);
        this.proofOfCoverageRepository = proofOfCoverageRepository;
        assert(collateralSectionService != null);
        this.collateralSectionService = collateralSectionService;
    }

    @Override
    public void transitionOnVerify(ProofOfCoverage policy, InsuranceType insuranceType, UserRequestInfo userRequestInfo) {
        CollateralSection collateralSectionToUpdate = getPolicyCollateralSectionByInsuranceType(insuranceType);
        policy.getLinkedCollateralIds().forEach(colId -> {
            List<ProofOfCoverage> allPoliciesPendingVerification = proofOfCoverageRepository.findByCollateralIdAndStatus(
                    colId, Collections.singletonList(PolicyStatus.PENDING_VERIFICATION.name()));
            List<ProofOfCoverage> filteredListByInsuranceType = allPoliciesPendingVerification.stream()
                    .filter(proofOfCoverage -> proofOfCoverage.getInsuranceType().equals(insuranceType.name()))
                    .collect(Collectors.toList());
            if (CollectionUtils.isEmpty(filteredListByInsuranceType)) {
                collateralSectionService.verify(colId, collateralSectionToUpdate, userRequestInfo);
            }
        });
    }

    @Override
    public void transitionOnCreate(ProofOfCoverage policy, InsuranceType insuranceType, UserRequestInfo userRequestInfo) {
        CollateralSection collateralSectionToUpdate = getPolicyCollateralSectionByInsuranceType(insuranceType);
        policy.getLinkedCollateralIds().forEach(colId -> collateralSectionService.edit(colId, collateralSectionToUpdate, userRequestInfo));
    }

    @Override
    public void transitionOnEdit(ProofOfCoverage policy, InsuranceType insuranceType, UserRequestInfo userRequestInfo) {
        CollateralSection collateralSectionToUpdate = getPolicyCollateralSectionByInsuranceType(insuranceType);
        policy.getLinkedCollateralIds().forEach(colId -> collateralSectionService.edit(colId, collateralSectionToUpdate, userRequestInfo));
    }

    private CollateralSection getPolicyCollateralSectionByInsuranceType(InsuranceType insuranceType){
        return InsuranceType.GENERAL == insuranceType ?
                CollateralSection.GENERAL_INSURANCE_POLICIES : CollateralSection.FLOOD_INSURANCE_POLICIES;
    }
}
