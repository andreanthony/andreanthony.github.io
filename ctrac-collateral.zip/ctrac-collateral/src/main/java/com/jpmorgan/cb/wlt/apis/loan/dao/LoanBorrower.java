package com.jpmorgan.cb.wlt.apis.loan.dao;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_LOAN_BORROWER")
@IdClass(value = LoanBorrowerPk.class)
public class LoanBorrower {

    @Id
    @ManyToOne
    @JoinColumn(name = "LOAN_ID")
    private Loan loan;

    @Id
    @Column(name = "BORROWER_ID")
    private Long borrowerId;

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public Long getBorrowerId() {
        return borrowerId;
    }

    public void setBorrowerId(Long borrowerId) {
        this.borrowerId = borrowerId;
    }
}
