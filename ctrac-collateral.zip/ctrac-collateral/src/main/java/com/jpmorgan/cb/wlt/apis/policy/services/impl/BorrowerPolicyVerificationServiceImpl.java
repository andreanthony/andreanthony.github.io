package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralStatus;
import com.jpmorgan.cb.wlt.apis.collateral.details.services.CollateralDetailsService;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.services.BorrowerPolicyVerificationService;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BorrowerPolicyVerificationServiceImpl implements BorrowerPolicyVerificationService {

    private CollateralDetailsService collateralDetailsService;

    @Autowired
    public BorrowerPolicyVerificationServiceImpl(CollateralDetailsService collateralDetailsService) {
        assert (collateralDetailsService != null);
        this.collateralDetailsService = collateralDetailsService;
    }

    @Override
    public boolean notMigratedAllVerifiedAndAllPledged(ProofOfCoverage proofOfCoverage) {
        return PolicyType.valueOf(proofOfCoverage.getPolicyType()).isBorrowerPolicy() &&
                !proofOfCoverage.getMigrated() &&
                areAllCollateralsPledged(proofOfCoverage) &&
                isVerifiedOnAllCollaterals(proofOfCoverage);
    }

    private boolean areAllCollateralsPledged(ProofOfCoverage proofOfCoverage) {
        return proofOfCoverage.getBirProofOfCovDetails().getBirCollateralDetails().stream().allMatch(
                birCollateralDetails -> CollateralStatus.PLEDGED == getCollateralStatus(birCollateralDetails.getCollateralRid()));
    }

    private CollateralStatus getCollateralStatus(Long collateralRid) {
        return EnumUtils.getEnum(CollateralStatus.class, collateralDetailsService.getCollateralDetails(collateralRid).getCollateralStatus());
    }

    private boolean isVerifiedOnAllCollaterals(ProofOfCoverage proofOfCoverage) {
        return PolicyStatus.PENDING_VERIFICATION != proofOfCoverage.getPolicyStatus_() &&
                proofOfCoverage.getBirProofOfCovDetails().getBirCollateralDetails().stream().noneMatch(
                        birCollateralDetails -> PolicyStatus.PENDING_VERIFICATION == birCollateralDetails.getPolicyStatus_());
    }
}
