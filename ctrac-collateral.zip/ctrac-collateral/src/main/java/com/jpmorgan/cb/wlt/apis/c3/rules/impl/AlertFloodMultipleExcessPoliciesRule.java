package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.enums.C3AlertEmailTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Collectors;

public class AlertFloodMultipleExcessPoliciesRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(AlertFloodMultipleExcessPoliciesRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        logger.debug("AlertFloodMultipleExcessPoliciesRule - Number of alert email to be sent {}",c3ResponseDTO.getAlertEmails().size());
        c3ResponseDTO.getAlertEmails().stream()
                .filter(alertEmail -> alertEmail.getAlertTemplate() == C3AlertEmailTemplate.MULTIPLE_EXCESS_POLICIES)
                .forEach(alertEmail -> c3ResponseDTO.getPoliciesToIssue().removeAll(c3ResponseDTO.getPoliciesToIssue().stream()
                        .filter(policyToIssue -> policyToIssue.getInsurableAssetId() != 0
                                && policyToIssue.getInsurableAssetId().equals(alertEmail.getRequiredCoverage().getInsurableAssetId())
                                && policyToIssue.getInsurableAssetType() == alertEmail.getRequiredCoverage().getInsurableAssetType_())
                        .collect(Collectors.toList())));
    }
}
