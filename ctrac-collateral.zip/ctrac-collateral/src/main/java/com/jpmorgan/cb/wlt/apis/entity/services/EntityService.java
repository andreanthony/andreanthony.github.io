package com.jpmorgan.cb.wlt.apis.entity.services;

import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;

import java.util.List;

public interface EntityService {
    List<EntityDTO> getEntities(List<Long> entityIds);

    }
