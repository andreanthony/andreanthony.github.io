package com.jpmorgan.cb.wlt.apis.policy.dtos;

import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentSummaryDTO;
import com.jpmorgan.cb.wlt.dtos.AuditableEntityDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionMap;
import com.jpmorgan.cib.wlt.ctrac.bir.enums.BorrowerInsuranceReviewConclusion;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.*;

public class PolicyDTO extends AuditableEntityDTO{

    @ApiModelProperty(position = -25)
    private Long policyId;

    @ApiModelProperty(position = -21)
    private Set<Long> collateralIds = new HashSet<>();

    @ApiModelProperty(position = -17)
    private String policyType;

    @ApiModelProperty(position = -13)
    private String policyStatus;

    @ApiModelProperty(position = -9)
    private String issuanceDate;

    @ApiModelProperty(position = -5)
    private Boolean migrated;

    private String eoiReceivedDate;
    private String evidenceOfInsurance;
    private String signedByAgent;

    private String effectiveDate;
    private String expirationDate;
    private String cancellationDate;
    private String policyNumber;
    private String insuredName;
    private String proofOfPayment;
    private String floodCovIncluded;
    private String floodZoneListed;
    private String coversAllRiskOfFlood;
    private String jpmMortgageePayee;
    private String jpmLenderLossPayee;
    private String jpmAdditionalInsured;
    private String policyWrittenAtRcv;
    private String jpmLienPosition;
    private String insuranceCompanyName;
    private String agentEmailAddress;
    private String agentPhoneNumber;
    private String agentFaxNumber;

    @ApiModelProperty(position = 1)
    private List<PolicyCollateralDetailsDTO> collateralCoverages = new ArrayList<>();

    @ApiModelProperty(position = 2)
    private PaymentMethodDTO invoicePaymentMethod;

    @ApiModelProperty(position = 3)
    private PaymentMethodDTO refundPaymentMethod;

    @ApiModelProperty(position = 4)
    private PaymentMethodDTO renewalPaymentMethod;

    @ApiModelProperty(position = 5)
    private String lpAction;

    private String insuranceType;
    private String condoAssociationPolicy;
    private Long totalNumberOfCondoUnits;
    private String individualCondoUnitNumbers;

    public PaymentMethodDTO getRenewalPaymentMethod() {
        return renewalPaymentMethod;
    }

    public void setRenewalPaymentMethod(PaymentMethodDTO renewalPaymentMethod) {
        this.renewalPaymentMethod = renewalPaymentMethod;
    }

    private String uploadBucketName;

    private List<CollateralDocumentSummaryDTO> policyDocuments = new ArrayList<>();

    private Map<String, BIRRuleConclusionDTO> ruleConclusions = new BIRRuleConclusionMap();

    @ApiModelProperty(position = 4)
    private LetterCycleDTO letterCycle;

    private String reasonForVerification;

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public Set<Long> getCollateralIds() {
        return collateralIds;
    }

    public void setCollateralIds(Set<Long> collateralIds) {
        this.collateralIds = collateralIds;
    }

    public String getPolicyType() {
        return policyType;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getPolicyStatus() {
        return policyStatus;
    }

    public void setPolicyStatus(String policyStatus) {
        this.policyStatus = policyStatus;
    }

    public String getIssuanceDate() {
        return issuanceDate;
    }

    public void setIssuanceDate(String issuanceDate) {
        this.issuanceDate = issuanceDate;
    }

    public Boolean getMigrated() {
        return migrated;
    }

    public void setMigrated(Boolean migrated) {
        this.migrated = migrated;
    }

    public String getEoiReceivedDate() {
        return eoiReceivedDate;
    }

    public void setEoiReceivedDate(String eoiReceivedDate) {
        this.eoiReceivedDate = eoiReceivedDate;
    }

    public String getEvidenceOfInsurance() {
        return evidenceOfInsurance;
    }

    public void setEvidenceOfInsurance(String evidenceOfInsurance) {
        this.evidenceOfInsurance = evidenceOfInsurance;
    }

    public String getSignedByAgent() {
        return signedByAgent;
    }

    public void setSignedByAgent(String signedByAgent) {
        this.signedByAgent = signedByAgent;
    }

    public String getProofOfPayment() {
        return proofOfPayment;
    }

    public void setProofOfPayment(String proofOfPayment) {
        this.proofOfPayment = proofOfPayment;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getCancellationDate() {
        return cancellationDate;
    }

    public void setCancellationDate(String cancellationDate) {
        this.cancellationDate = cancellationDate;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getInsuredName() {
        return insuredName;
    }

    public void setInsuredName(String insuredName) {
        this.insuredName = insuredName;
    }

    public String getJpmMortgageePayee() {
        return jpmMortgageePayee;
    }

    public void setJpmMortgageePayee(String jpmMortgageePayee) {
        this.jpmMortgageePayee = jpmMortgageePayee;
    }

    public String getJpmLenderLossPayee() {
        return jpmLenderLossPayee;
    }

    public void setJpmLenderLossPayee(String jpmLenderLossPayee) {
        this.jpmLenderLossPayee = jpmLenderLossPayee;
    }

    public String getJpmLienPosition() {
        return jpmLienPosition;
    }

    public void setJpmLienPosition(String jpmLienPosition) {
        this.jpmLienPosition = jpmLienPosition;
    }

    public String getPolicyWrittenAtRcv() {
        return policyWrittenAtRcv;
    }

    public void setPolicyWrittenAtRcv(String policyWrittenAtRcv) {
        this.policyWrittenAtRcv = policyWrittenAtRcv;
    }

    public String getInsuranceCompanyName() {
        return insuranceCompanyName;
    }

    public void setInsuranceCompanyName(String insuranceCompanyName) {
        this.insuranceCompanyName = insuranceCompanyName;
    }

    public String getAgentEmailAddress() {
        return agentEmailAddress;
    }

    public void setAgentEmailAddress(String agentEmailAddress) {
        this.agentEmailAddress = agentEmailAddress;
    }

    public String getAgentPhoneNumber() {
        return agentPhoneNumber;
    }

    public void setAgentPhoneNumber(String agentPhoneNumber) {
        this.agentPhoneNumber = agentPhoneNumber;
    }

    public String getAgentFaxNumber() {
        return agentFaxNumber;
    }

    public void setAgentFaxNumber(String agentFaxNumber) {
        this.agentFaxNumber = agentFaxNumber;
    }

    public List<PolicyCollateralDetailsDTO> getCollateralCoverages() {
        return collateralCoverages;
    }

    public void setCollateralCoverages(List<PolicyCollateralDetailsDTO> collateralCoverages) {
        this.collateralCoverages = collateralCoverages;
    }

    public PaymentMethodDTO getInvoicePaymentMethod() {
        return invoicePaymentMethod;
    }

    public void setInvoicePaymentMethod(PaymentMethodDTO invoicePaymentMethod) {
        this.invoicePaymentMethod = invoicePaymentMethod;
    }

    public PaymentMethodDTO getRefundPaymentMethod() {
        return refundPaymentMethod;
    }

    public void setRefundPaymentMethod(PaymentMethodDTO refundPaymentMethod) {
        this.refundPaymentMethod = refundPaymentMethod;
    }

    public String getJpmAdditionalInsured() {
        return jpmAdditionalInsured;
    }

    public void setJpmAdditionalInsured(String jpmAdditionalInsured) {
        this.jpmAdditionalInsured = jpmAdditionalInsured;
    }

    public String getUploadBucketName() {
        return uploadBucketName;
    }

    public void setUploadBucketName(String uploadBucketName) {
        this.uploadBucketName = uploadBucketName;
    }

    public List<CollateralDocumentSummaryDTO> getPolicyDocuments() {
        return policyDocuments;
    }

    public void setPolicyDocuments(List<CollateralDocumentSummaryDTO> policyDocuments) {
        this.policyDocuments = policyDocuments;
    }

    public LetterCycleDTO getLetterCycle() {
        return letterCycle;
    }

    public void setLetterCycle(LetterCycleDTO letterCycle) {
        this.letterCycle = letterCycle;
    }

    public String getReasonForVerification() {
        return reasonForVerification;
    }

    public void setReasonForVerification(String reasonForVerification) {
        this.reasonForVerification = reasonForVerification;
    }

    public String getInsuranceType() { return insuranceType; }

    public void setInsuranceType(String insuranceType) { this.insuranceType = insuranceType; }

    public String getLpAction() { return lpAction; }

    public void setLpAction(String lpAction) { this.lpAction = lpAction; }

    public Map<String, BIRRuleConclusionDTO> getRuleConclusions() {
        return ruleConclusions;
    }

    public void setRuleConclusions(Map<String, BIRRuleConclusionDTO> ruleConclusions) {
        this.ruleConclusions = ruleConclusions;
    }

    public String getFloodCovIncluded() {
        return floodCovIncluded;
    }

    public void setFloodCovIncluded(String floodCovIncluded) {
        this.floodCovIncluded = floodCovIncluded;
    }

    public String getFloodZoneListed() {
        return floodZoneListed;
    }

    public void setFloodZoneListed(String floodZoneListed) {
        this.floodZoneListed = floodZoneListed;
    }

    public String getCoversAllRiskOfFlood() {
        return coversAllRiskOfFlood;
    }

    public void setCoversAllRiskOfFlood(String coversAllRiskOfFlood) {
        this.coversAllRiskOfFlood = coversAllRiskOfFlood;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        PolicyDTO policyDTO = (PolicyDTO) o;

        return new EqualsBuilder()
                .append(policyId, policyDTO.policyId)
                .append(policyType, policyDTO.policyType)
                .append(migrated, policyDTO.migrated)
                .append(eoiReceivedDate, policyDTO.eoiReceivedDate)
                .append(evidenceOfInsurance, policyDTO.evidenceOfInsurance)
                .append(signedByAgent, policyDTO.signedByAgent)
                .append(proofOfPayment, policyDTO.proofOfPayment)
                .append(effectiveDate, policyDTO.effectiveDate)
                .append(expirationDate, policyDTO.expirationDate)
                .append(cancellationDate, policyDTO.cancellationDate)
                .append(policyNumber, policyDTO.policyNumber)
                .append(insuredName, policyDTO.insuredName)
                .append(jpmMortgageePayee, policyDTO.jpmMortgageePayee)
                .append(jpmLenderLossPayee, policyDTO.jpmLenderLossPayee)
                .append(jpmAdditionalInsured, policyDTO.jpmAdditionalInsured)
                .append(jpmLienPosition, policyDTO.jpmLienPosition)
                .append(policyWrittenAtRcv, policyDTO.policyWrittenAtRcv)
                .append(insuranceCompanyName, policyDTO.insuranceCompanyName)
                .append(agentEmailAddress, policyDTO.agentEmailAddress)
                .append(agentPhoneNumber, policyDTO.agentPhoneNumber)
                .append(agentFaxNumber, policyDTO.agentFaxNumber)
                .append(invoicePaymentMethod, policyDTO.invoicePaymentMethod)
                .append(refundPaymentMethod, policyDTO.refundPaymentMethod)
                .append(insuranceType, policyDTO.insuranceType)
                .isEquals()
                && equalCollateralCoverages(policyDTO.collateralCoverages)
                && equalRuleConclusions(policyDTO.getRuleConclusions());
    }

    private boolean equalCollateralCoverages(List<PolicyCollateralDetailsDTO> collateralCoveragesToCompare){
        return collateralCoverages.containsAll(collateralCoveragesToCompare)
                && collateralCoverages.size() == collateralCoveragesToCompare.size();
    }


    private boolean equalRuleConclusions(Map<String, BIRRuleConclusionDTO> ruleConclusionsToCompare){
        Collection<BIRRuleConclusionDTO> conclusions = MapUtils.emptyIfNull(getRuleConclusions()).values();
        Collection<BIRRuleConclusionDTO> conclusionsToCompareCollection = MapUtils.emptyIfNull(ruleConclusionsToCompare).values();
        return conclusions.containsAll(conclusionsToCompareCollection)
                && conclusions.size() == conclusionsToCompareCollection.size();
    }


    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(policyId)
                .append(policyType)
                .append(migrated)
                .append(eoiReceivedDate)
                .append(evidenceOfInsurance)
                .append(signedByAgent)
                .append(proofOfPayment)
                .append(effectiveDate)
                .append(expirationDate)
                .append(cancellationDate)
                .append(policyNumber)
                .append(insuredName)
                .append(jpmMortgageePayee)
                .append(jpmLenderLossPayee)
                .append(jpmAdditionalInsured)
                .append(jpmLienPosition)
                .append(policyWrittenAtRcv)
                .append(insuranceCompanyName)
                .append(agentEmailAddress)
                .append(agentPhoneNumber)
                .append(agentFaxNumber)
                .append(collateralCoverages)
                .append(invoicePaymentMethod)
                .append(refundPaymentMethod)
                .append(insuranceType)
                .toHashCode();
    }

    public boolean hasLetterCycle() {
        return letterCycle != null && !StringUtils.isEmpty(letterCycle.getWorkflowStep());
    }

    private List<PolicyInsuranceCoverageDTO> getProvidedCoverages(Long collateralId) {
        PolicyCollateralDetailsDTO policyCollateralDetailsDTO = collateralCoverages
                .stream()
                .filter(policyCollateralDetails -> policyCollateralDetails.getCollateralId().equals(collateralId))
                .findFirst()
                .orElse(null);
        return policyCollateralDetailsDTO == null ? new ArrayList<>() : policyCollateralDetailsDTO.getInsuranceCoverages();
    }

    public boolean hasCoverageType(String coverageType, Long collateralId) {
        return getProvidedCoverages(collateralId)
                .stream()
                .anyMatch(providedCoverage -> coverageType.equals(providedCoverage.getInsuranceCoverageType()));
    }

    public boolean hasRejectedConclusion() {
        return hasConclusion(BorrowerInsuranceReviewConclusion.REJECTED);
    }

    public boolean hasActionRequiredConclusion() {
        return hasConclusion(BorrowerInsuranceReviewConclusion.ACTION_REQUIRED);
    }

    private boolean hasConclusion(BorrowerInsuranceReviewConclusion conclusion) {
        return getAllRuleConclusions().values().
                stream().anyMatch(birRuleConclusionDTO ->
                    EnumUtils.getEnum(BorrowerInsuranceReviewConclusion.class, birRuleConclusionDTO.getConclusion()) == conclusion);
    }

    public String getCondoAssociationPolicy() {
        return condoAssociationPolicy;
    }

    public void setCondoAssociationPolicy(String condoAssociationPolicy) {
        this.condoAssociationPolicy = condoAssociationPolicy;
    }

    public Long getTotalNumberOfCondoUnits() {
        return totalNumberOfCondoUnits;
    }

    public void setTotalNumberOfCondoUnits(Long totalNumberOfCondoUnits) {
        this.totalNumberOfCondoUnits = totalNumberOfCondoUnits;
    }

    public String getIndividualCondoUnitNumbers() {
        return individualCondoUnitNumbers;
    }

    public void setIndividualCondoUnitNumbers(String individualCondoUnitNumbers) {
        this.individualCondoUnitNumbers = individualCondoUnitNumbers;
    }

    public Map<String, BIRRuleConclusionDTO> getAllRuleConclusions() {
        Map<String, BIRRuleConclusionDTO> allConclusions = new HashMap<>(ruleConclusions);
        collateralCoverages.forEach(policyCollateralDetailsDTO ->
            allConclusions.putAll(policyCollateralDetailsDTO.getBirRuleConclusions()));
        return allConclusions;
    }
}
