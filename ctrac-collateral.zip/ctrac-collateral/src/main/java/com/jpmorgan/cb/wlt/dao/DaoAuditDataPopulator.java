package com.jpmorgan.cb.wlt.dao;

public interface DaoAuditDataPopulator<S, D> {

    void populateAuditInfo(S source, D userRequestInfo);

}
