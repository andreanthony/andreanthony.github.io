package com.jpmorgan.cb.wlt.apis.policy.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProofOfCoverageRepository extends JpaRepository<ProofOfCoverage, Long> {

    @Query("select poc from ProofOfCoverage poc, CollateralInsuranceViewData ci where poc.rid=ci.proofOfCoverage.rid " +
            "and ci.collateral.rid=:collateralId and poc.policyType in :policyTypes and poc.policyStatus in :policyStatuses")
    List<ProofOfCoverage> findByCollateralIdAndTypeAndStatus(@Param("collateralId") Long collateralId,
                                                             @Param("policyTypes") List<String> policyTypes,
                                                             @Param("policyStatuses") List<String> policyStatuses);

    @Query("select poc from ProofOfCoverage poc, CollateralInsuranceViewData ci where poc.rid=ci.proofOfCoverage.rid " +
            "and ci.collateral.rid=:collateralId and poc.policyStatus in :policyStatuses")
    List<ProofOfCoverage> findByCollateralIdAndStatus(@Param("collateralId") Long collateralId,
                                                             @Param("policyStatuses") List<String> policyStatuses);
}
