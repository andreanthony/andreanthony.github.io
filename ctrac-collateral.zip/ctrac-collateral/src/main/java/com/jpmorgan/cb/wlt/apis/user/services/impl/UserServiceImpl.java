package com.jpmorgan.cb.wlt.apis.user.services.impl;

import com.jpmorgan.cb.wlt.apis.user.services.UserService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cb.wlt.services.Ctrac2ApiService;
import com.jpmorgan.cib.wlt.ctrac.entitlements.UserEntitlementsDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.apache.commons.collections4.map.PassiveExpiringMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    @Value("${ctrac.entitlements.cacheTime}")
    private String cacheTimeSetting;

    private Ctrac2ApiService ctrac2ApiService;

    private Map<String, UserEntitlementsDTO> cachedUserEntitlements;


    @Autowired
    public UserServiceImpl(Ctrac2ApiService ctrac2ApiService) {
        assert(ctrac2ApiService != null);
        this.ctrac2ApiService = ctrac2ApiService;
    }

    @PostConstruct
    public void init(){
        cachedUserEntitlements = Collections.synchronizedMap(new PassiveExpiringMap<>(Long.valueOf(cacheTimeSetting)));
    }


    @Override
    public void populateUserDetails(UserRequestInfo userRequestInfo) {
        if(StringUtils.isEmpty(userRequestInfo.getUserName())){
            return;
        }
        if(cachedUserEntitlements == null){
            throw new CtracException("The caching store has not been initialized.");
        }
        String userName = userRequestInfo.getUserName();
        if (!cachedUserEntitlements.containsKey(userName)) {
            UserEntitlementsDTO userEntitlementsDto = ctrac2ApiService.getUserEntitlements(userName);
            cachedUserEntitlements.put(userName, userEntitlementsDto);
        }
        userRequestInfo.setUserEntitlementsDto(cachedUserEntitlements.get(userName));
    }

    @Override
    public Boolean clearUserEntitlementsCache() {
        cachedUserEntitlements.clear();
        return true;
    }

}
