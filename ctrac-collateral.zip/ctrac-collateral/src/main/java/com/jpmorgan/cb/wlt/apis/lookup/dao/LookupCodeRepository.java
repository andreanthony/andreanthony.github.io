package com.jpmorgan.cb.wlt.apis.lookup.dao;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LookupCodeRepository extends JpaRepository<LookupCode, Long>{

    @Cacheable(value = "lookUpCodeDataCache")
	List<LookupCode> findByCodeSetAndActiveOrderBySortOrderAsc(String codeSet, String active);

    @Cacheable(value = "lookUpCodeDataCache")
    LookupCode findByCodeAndCodeSetAndActive(String code, String codeSet, String active);

    @Cacheable(value = "lookUpCodeDataCache")
    @Query("select lookup2 from LookupCode lookup1, LookupCode lookup2 where lookup1.codeSet = :codeSet and lookup1.code = :code" +
            " and lookup1.childCodeSet = lookup2.codeSet")
    List<LookupCode> findChildrenLookupCodesByParentCodeSetAndCode(@Param("codeSet")String codeSet, @Param("code") String code);

}
