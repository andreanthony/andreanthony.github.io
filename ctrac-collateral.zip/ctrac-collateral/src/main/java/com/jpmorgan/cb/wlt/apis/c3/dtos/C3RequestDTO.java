package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralStatus;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanStatus;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanType;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.EnumUtils;

import java.beans.Transient;
import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class C3RequestDTO implements Serializable {
    private static final long serialVersionUID = -1;
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();
    private String collateralStatus;
    private String collateralReleaseDate;
    private Long collateralRid;
    private C3FloodDetermination floodDetermination = new C3FloodDetermination();
    private List<C3Policy> borrowerPolicies = new ArrayList<>();
    private List<C3Policy> lpPolicies = new ArrayList<>();
    private List<C3Loan> loans = new ArrayList<>();
    private String insuredName;
    private List<C3RequiredCoverage> requiredCoverages = new ArrayList<>();
    private String overrideFloodCoverageDate;
    private String overrideGeneralCoverageDate;
    private String currentReferenceDate;
    private String collateralSubType;
    private boolean addedAndRemovedCoveragesOnly;
    private String insuranceType;
    private List<Long> holdsVerifiedWithLpiDate = new ArrayList<>();
    private String performedBy;
    private boolean hasFloodHolds;
    private boolean evaluateGap;

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isReleased() {
        return CollateralStatus.RELEASED.name().equalsIgnoreCase(collateralStatus);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isExternallyAgented() {
        for (C3Loan loan : loans) {
            if (LoanType.EXTERNALLY_AGENTED.name().equalsIgnoreCase(loan.getLoanType())) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return null if there is an active loan, otherwise latest loan paid off date
     */
    @Transient
    @ApiModelProperty(hidden = true)
    public Date getLatestLoanPaidOffDate() {
        Date latestLoanPaidOffDate = null;
        for (C3Loan loan : loans) {
            LoanStatus loanStatus = LoanStatus.valueOf(loan.getStatus());
            if (loanStatus.isActive()) {
                return null;
            }
            Date releasedDate = DATE_FORMATTER.parse(loan.getReleasedDate());
            if (latestLoanPaidOffDate == null || latestLoanPaidOffDate.before(releasedDate)) {
                latestLoanPaidOffDate = releasedDate;
            }
        }
        if (latestLoanPaidOffDate == null) {
            latestLoanPaidOffDate = DATE_FORMATTER.parse(currentReferenceDate);
        }
        return latestLoanPaidOffDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public C3RequiredCoverage getFloodRequiredCoverage(Long insurableAssetId, FloodCoverageType coverageType) {
        return requiredCoverages.stream()
                .filter(requiredCoverage -> InsuranceType.FLOOD == requiredCoverage.getInsuranceType_()
                        && insurableAssetId.equals(requiredCoverage.getInsurableAssetId())
                        && coverageType == requiredCoverage.getFloodCoverageType())
                .max((o1, o2) -> {
                    if (o1 == o2) {
                        return 0;
                    }
                    return o1.getDocumentDate_().before(o2.getDocumentDate_()) ? -1 : 1;
                }).orElse(null);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public C3RequiredCoverage getGeneralRequiredCoverage(String coverageType) {
        return requiredCoverages.stream()
                .filter(requiredCoverage -> InsuranceType.GENERAL == requiredCoverage.getInsuranceType_()
                        && StringUtils.equals(coverageType, requiredCoverage.getCoverageType()))
                .max((o1, o2) -> {
                    if (o1 == o2) {
                        return 0;
                    }
                    return o1.getDocumentDate_().before(o2.getDocumentDate_()) ? -1 : 1;
                }).orElse(null);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getFloodBorrowerPoliciesEffectiveOn(Date coverageDate, Long insurableAssetId) {
        return getBorrowerPolicies(InsuranceType.FLOOD)
                .stream()
                .filter(borrowerPolicy -> borrowerPolicy.isEffectiveOn(coverageDate) && borrowerPolicy.getProvidedCoverages()
                            .stream()
                            .anyMatch(providedCoverage -> providedCoverage.getInsurableAssetId().equals(insurableAssetId)))
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getGeneralBorrowerPoliciesEffectiveOn(Date coverageDate, String coverageType) {
        return getBorrowerPolicies(InsuranceType.GENERAL)
                .stream()
                .filter(borrowerPolicy -> borrowerPolicy.isProvidingCoverageOn(coverageType, null, coverageDate))
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getBorrowerPolicies(InsuranceType insuranceType) {
        return borrowerPolicies.stream()
                .filter(policy -> insuranceType == policy.getInsuranceType_())
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getBorrowerPoliciesExcludingPendingVerification(InsuranceType insuranceType, String coverageType, Long insurableAssetId) {
        return getBorrowerPolicies(insuranceType).stream()
                .filter(borrowerPolicy -> borrowerPolicy.hasMatchingCoverage(coverageType, insurableAssetId)
                        && !borrowerPolicy.getPolicyStatus_().isPendingVerification())
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getMatchingBorrowerPolicies(C3Policy lpPolicy) {
        return getMatchingBorrowerPolicies(
                lpPolicy.getInsuranceType_(),
                lpPolicy.getFirstProvidedCoverage().getCoverageType(),
                lpPolicy.getFirstProvidedCoverage().getInsurableAssetId());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getMatchingBorrowerPolicies(C3PolicyIssuance c3PolicyIssuance) {
        return getMatchingBorrowerPolicies(
                c3PolicyIssuance.getPolicyType().getInsuranceType(),
                c3PolicyIssuance.getCoverageType(),
                c3PolicyIssuance.getInsurableAssetId());
    }

    private List<C3Policy> getMatchingBorrowerPolicies(InsuranceType insuranceType, String coverageType, Long insurableAssetId) {
        return getBorrowerPolicies(insuranceType)
                .stream()
                .filter(borrowerPolicy -> borrowerPolicy.hasMatchingCoverage(coverageType, insurableAssetId))
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getFloodLpPolicies() {
        return lpPolicies.stream()
                .filter(policy -> InsuranceType.FLOOD == policy.getInsuranceType_())
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public C3Policy getLpPolicy(String coverageType, Long insurableAssetId) {
        Optional<C3Policy> lpPolicy = lpPolicies.stream()
                .filter(policy -> policy.hasMatchingCoverage(coverageType, insurableAssetId))
                .max((o1, o2) -> {
                        if (o1 == o2) {
                            return 0;
                        }
                        return o1.getEffectiveDate_().before(o2.getEffectiveDate_()) ? -1 : 1;
                    });
            return lpPolicy.orElse(null);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public C3Hold getRequiredCoverageHold(Long insurableAssetId, FloodCoverageType coverageType) {
        C3RequiredCoverage c3RequiredCoverage = getFloodRequiredCoverage(insurableAssetId, coverageType);
        return c3RequiredCoverage == null ? null : c3RequiredCoverage.getHold();
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public InsurableAssetType getInsurableAssetType(Long insurableAssetId) {
        return getFloodRequiredCoverage(insurableAssetId, FloodCoverageType.PRIMARY).getInsurableAssetType_();
    }

    public String getCollateralStatus() {
        return collateralStatus;
    }

    public void setCollateralStatus(String collateralStatus) {
        this.collateralStatus = collateralStatus;
    }

    public String getCollateralReleaseDate() {
        return collateralReleaseDate;
    }

    public void setCollateralReleaseDate(String collateralReleaseDate) {
        this.collateralReleaseDate = collateralReleaseDate;
    }

    public C3FloodDetermination getFloodDetermination() {
        return floodDetermination;
    }

    public void setFloodDetermination(C3FloodDetermination floodDetermination) {
        this.floodDetermination = floodDetermination;
    }

    public List<C3Policy> getBorrowerPolicies() {
        return borrowerPolicies;
    }

    public List<C3Policy> getLpPolicies() {
        return lpPolicies;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getLpPolicies(InsuranceType insuranceType) {
        return !isInsuranceTypeRequested(insuranceType)? new ArrayList<>():
                lpPolicies.stream()
                .filter(policy -> insuranceType == policy.getInsuranceType_())
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public void addBorrowerPolicies(List<C3Policy> borrowerPolicies) {
        this.borrowerPolicies.addAll(borrowerPolicies);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public void addBorrowerPolicy(C3Policy borrowerPolicy) {
        this.borrowerPolicies.add(borrowerPolicy);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public void addLPPolicies(List<C3Policy> lpPolicies) {
        this.lpPolicies.addAll(lpPolicies);
    }

    public Long getCollateralRid() { return collateralRid; }

    public void setCollateralRid(Long collateralRid) { this.collateralRid = collateralRid; }

    public List<C3Loan> getLoans() {
        return loans;
    }

    public void setLoans(List<C3Loan> loans) {
        this.loans = loans;
    }

    public String getInsuredName() {
        return insuredName;
    }

    public void setInsuredName(String insuredName) {
        this.insuredName = insuredName;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3RequiredCoverage> getRequiredCoverages(InsuranceType insuranceType) {
        return !isInsuranceTypeRequested(insuranceType)? new ArrayList<>():
                getRequiredCoverages()
                .stream()
                .filter(requiredCoverage -> requiredCoverage.getInsuranceType_() == insuranceType)
                .collect(Collectors.toList());
    }

    public List<C3RequiredCoverage> getRequiredCoverages() {
        return Collections.unmodifiableList(requiredCoverages);
    }

    public void addRequiredCoverages(List<C3RequiredCoverage> requiredCoverages) {
        this.requiredCoverages.addAll(requiredCoverages);
    }

    public void addRequiredCoverage(C3RequiredCoverage requiredCoverage) {
        this.requiredCoverages.add(requiredCoverage);
    }

    public String getOverrideFloodCoverageDate() {
        return overrideFloodCoverageDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getOverrideFloodCoverageDate_() {
        return DATE_FORMATTER.parse(overrideFloodCoverageDate);
    }

    public void setOverrideFloodCoverageDate(String overrideFloodCoverageDate) {
        this.overrideFloodCoverageDate = overrideFloodCoverageDate;
    }

    public String getOverrideGeneralCoverageDate() {
        return overrideGeneralCoverageDate;
    }

    public void setOverrideGeneralCoverageDate(String overrideGeneralCoverageDate) {
        this.overrideGeneralCoverageDate = overrideGeneralCoverageDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getOverrideGeneralCoverageDate_() {
        return DATE_FORMATTER.parse(overrideGeneralCoverageDate);
    }

    public String getCurrentReferenceDate() {
        return currentReferenceDate;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getCurrentReferenceDate_() {
        return DATE_FORMATTER.parse(currentReferenceDate);
    }

    public void setCurrentReferenceDate(String currentReferenceDate) {
        this.currentReferenceDate = currentReferenceDate;
    }

    public String getCollateralSubType() {
        return collateralSubType;
    }

    public void setCollateralSubType(String collateralSubType) {
        this.collateralSubType = collateralSubType;
    }

    public boolean isAddedAndRemovedCoveragesOnly() {
        return addedAndRemovedCoveragesOnly;
    }

    public void setAddedAndRemovedCoveragesOnly(boolean addedAndRemovedCoveragesOnly) {
        this.addedAndRemovedCoveragesOnly = addedAndRemovedCoveragesOnly;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isInsuranceTypeRequested(InsuranceType insuranceType) {
        return this.insuranceType == null || this.insuranceType.equals(insuranceType.name());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public boolean isInsuranceTypeRequested(String insuranceTypeName) {
        return this.insuranceType == null || this.insuranceType.equals(insuranceTypeName);
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public void setFloodComplete(C3ResponseDTO c3ResponseDTO) {
        if (this.insuranceType == null) {
            this.insuranceType = InsuranceType.GENERAL.name();
        }
        else if (EnumUtils.getEnum(InsuranceType.class, this.insuranceType) == InsuranceType.FLOOD) {
            c3ResponseDTO.setComplete(true);
        }
    }

    public List<Long> getHoldsVerifiedWithLpiDate() {
        return holdsVerifiedWithLpiDate;
    }

    public void setHoldsVerifiedWithLpiDate(List<Long> holdsVerifiedWithLpiDate) {
        this.holdsVerifiedWithLpiDate = holdsVerifiedWithLpiDate;
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }

    public boolean isHoldVerifiedWithLpiDateOnly() {
        return !CollectionUtils.isEmpty(holdsVerifiedWithLpiDate);
    }

    public boolean hasFloodHolds() {
        return hasFloodHolds;
    }

    public void setHasFloodHolds(boolean hasFloodHolds) {
        this.hasFloodHolds = hasFloodHolds;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public Date getHoldStartDate(String coverageType, Long insurableAssetId) {
        return requiredCoverages
                .stream()
                .filter(requiredCoverage -> requiredCoverage.isMatching(coverageType, insurableAssetId))
                .findAny()
                .map(C3RequiredCoverage::getHoldStartDate)
                .orElse(null);
    }

    public boolean isEvaluateGap() {
        return evaluateGap;
    }

    public void setEvaluateGap(boolean evaluateGap) {
        this.evaluateGap = evaluateGap;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getExpiringPolicies(List<C3Policy> policies) {
        return policies
                .stream()
                .filter(C3Policy::isExpiring)
                .collect(Collectors.toList());
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getAllPolicies(InsuranceType insuranceType) {
        List<C3Policy> policies = new ArrayList<>(getBorrowerPolicies(insuranceType));
        policies.addAll(getLpPolicies(insuranceType));
        return policies;
    }

    @Transient
    @ApiModelProperty(hidden = true)
    public List<C3Policy> getAllPolicies() {
        List<C3Policy> policies = new ArrayList<>(getBorrowerPolicies());
        policies.addAll(getLpPolicies());
        return policies;
    }

}
