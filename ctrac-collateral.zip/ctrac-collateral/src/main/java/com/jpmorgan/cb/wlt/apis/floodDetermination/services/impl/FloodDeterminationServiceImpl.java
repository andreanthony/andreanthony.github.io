package com.jpmorgan.cb.wlt.apis.floodDetermination.services.impl;

import com.jpmorgan.cb.wlt.apis.floodDetermination.dao.FloodDetermination;
import com.jpmorgan.cb.wlt.apis.floodDetermination.dao.FloodDeterminationRepository;
import com.jpmorgan.cb.wlt.apis.floodDetermination.services.FloodDeterminationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FloodDeterminationServiceImpl implements FloodDeterminationService {
    private static final Logger logger = LoggerFactory.getLogger(FloodDeterminationServiceImpl.class);
    private FloodDeterminationRepository floodDeterminationRepository;

    @Autowired
    public FloodDeterminationServiceImpl(FloodDeterminationRepository floodDeterminationRepository) {
        assert(floodDeterminationRepository != null);
        this.floodDeterminationRepository = floodDeterminationRepository;
    }
    @Override
    public FloodDetermination findByCollateralRidAndStatus(Long collateral, String status)
    {
        return floodDeterminationRepository.findByCollateralRidAndStatus(collateral,status);
    }
}
