package com.jpmorgan.cb.wlt.apis.policy.dtos;

import com.jpmorgan.cb.wlt.apis.event.AbstractPublishEventRequest;
import com.jpmorgan.cb.wlt.apis.event.CollateralEventSection;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

public class PolicyPublishEventRequest extends AbstractPublishEventRequest {

	private ProofOfCoverage proofOfCoverage;
	private InsuranceType insuranceType;
	private Long collateralRid;

	public PolicyPublishEventRequest(ProofOfCoverage proofOfCoverage, InsuranceType insuranceType, Long collateralRid) {
		this.proofOfCoverage = proofOfCoverage;
		this.insuranceType = insuranceType;
		this.collateralRid = collateralRid;
	}

	@Override
	public String getDescription() {
		if(PolicyType.valueOf(proofOfCoverage.getPolicyType()).isBorrowerPolicy()){
			return StringUtils.EMPTY;
		}else{
			String migrated = BooleanUtils.isTrue(proofOfCoverage.getMigrated()) ? " - Migrated" : "";
			return "LPI " + proofOfCoverage.getPolicyStatus_().getDisplayName() + migrated;
		}
	}

	@Override
	public String getIdentifier() {
		if (proofOfCoverage.getRid() != null) {
			return this.proofOfCoverage.getRid().toString();
		}
		return StringUtils.EMPTY;
	}

	@Override
	public Long getCollateralRid() {
		return this.collateralRid;
	}

	@Override
	public CollateralEventSection getCollateralEventSection() {
		if(InsuranceType.GENERAL.equals(insuranceType)){
			if(PolicyType.valueOf(proofOfCoverage.getPolicyType()).isBorrowerPolicy()){
				return CollateralEventSection.GENERAL_INSURANCE_BORROWER_POLICY;
			}else{
				return CollateralEventSection.GENERAL_INSURANCE_LPI_POLICY;
			}
		}else{
			if(PolicyType.valueOf(proofOfCoverage.getPolicyType()).isBorrowerPolicy()){
				return CollateralEventSection.FLOOD_INSURANCE_BORROWER_POLICY;
			}else{
				return CollateralEventSection.FLOOD_INSURANCE_LPI_POLICY;
			}
		}
	}
}
