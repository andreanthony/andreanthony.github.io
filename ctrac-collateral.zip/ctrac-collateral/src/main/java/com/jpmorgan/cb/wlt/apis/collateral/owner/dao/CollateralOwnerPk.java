package com.jpmorgan.cb.wlt.apis.collateral.owner.dao;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.io.Serializable;

public class CollateralOwnerPk implements Serializable {
    private static final long serialVersionUID = -1;

    private Collateral collateral;
    private Long ownerId;

    public Collateral getCollateral() {
        return collateral;
    }

    public void setCollateral(Collateral collateral) {
        this.collateral = collateral;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {return true;}
        if (o == null || getClass() != o.getClass()) {return false;}

        CollateralOwnerPk that = (CollateralOwnerPk) o;
        return new EqualsBuilder()
                .append(collateral, that.collateral)
                .append(ownerId, that.ownerId)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(collateral)
                .append(ownerId)
                .toHashCode();
    }
}
