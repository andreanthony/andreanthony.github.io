package com.jpmorgan.cb.wlt.apis.requirement.general.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.apis.document.builder.DocumentMetaDataBuilder;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentSummaryDTO;
import com.jpmorgan.cb.wlt.apis.document.services.CollateralDocumentService;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyService;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralRequiredCoverageSource;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository.GeneralRequiredCoverageSourceRepository;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageRequirementDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoveragePublishEventRequest;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageSourceDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralCoverageService;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralRequiredCoverageSourceService;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralRequiredCoverageValidationService;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class GeneralRequiredCoverageSourceServiceImpl implements GeneralRequiredCoverageSourceService {

    private static final Logger logger = LoggerFactory.getLogger(GeneralRequiredCoverageSourceServiceImpl.class);
    private static final String CONST_GENERAL_REQUIRED_COVERAGE_SOURCE_DOCUMENT_IDENTIFIER = "GENERAL_REQ_COV";
    private DefaultDateFormatter defaultDateFormatter = new DefaultDateFormatter();

    private CollateralSectionService collateralSectionService;
    private GeneralRequiredCoverageSourceRepository  generalRequiredCoverageSourceRepository;
    private PublishEventService publishEventService;
    private GeneralRequiredCoverageValidationService validationService;
    private CollateralDocumentService collateralDocumentService;
    private GeneralCoverageService generalCoverageService;
    private PolicyService policyService;

    @Autowired
    public GeneralRequiredCoverageSourceServiceImpl(CollateralSectionService collateralSectionService ,
                                                    GeneralRequiredCoverageValidationService validationService,
                                                    PublishEventService publishEventService,
                                                    CollateralDocumentService collateralDocumentService,
                                                    GeneralCoverageService generalCoverageService,
                                                    PolicyService policyService,
                                                    GeneralRequiredCoverageSourceRepository  generalRequiredCoverageSourceRepository)
    {
        assert(collateralSectionService != null);
        this.collateralSectionService = collateralSectionService;
        assert(generalRequiredCoverageSourceRepository!= null);
        this.generalRequiredCoverageSourceRepository = generalRequiredCoverageSourceRepository;
        assert(validationService != null);
        this.validationService = validationService;
        assert(publishEventService != null);
        this.publishEventService = publishEventService;
        assert(collateralDocumentService != null);
        this.collateralDocumentService = collateralDocumentService;
        assert(generalCoverageService != null);
        this.generalCoverageService = generalCoverageService;
        assert(policyService != null);
        this.policyService = policyService;
    }

    @Override
    @Transactional
    public GeneralRequiredCoverageSourceDTO save(@Valid GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                                                 List<FileUploadAttachmentDTO> fileUploadAttachmentDTOList, UserRequestInfo userRequestInfo) {
        GeneralRequiredCoverageSourceDTO newRequiredCoverageSourceDTO;
        Long generalRequireCoverageSourceDTORid = generalRequiredCoverageSourceDTO.getRid();
        GeneralRequiredCoverageSourceDTO pendingVerification = getByCollateralId(generalRequiredCoverageSourceDTO.getCollateralRid())
                .getPendingVerificationRequirementSource();

        CtracEventType ctracEventType;
        if (generalRequireCoverageSourceDTORid == null || generalRequireCoverageSourceDTORid == 0) {
            validationService.validateCreate(generalRequiredCoverageSourceDTO, pendingVerification);
            ctracEventType = CtracEventType.ADDED;
        }
        else {
            GeneralRequiredCoverageSource originalValue = getGeneralRequiredCoverageSource(generalRequiredCoverageSourceDTO.getRid());
            generalRequiredCoverageSourceDTO.setStatus(originalValue != null ? originalValue.getStatus(): null);
            validationService.validateEdit(generalRequiredCoverageSourceDTO, pendingVerification);
            ctracEventType = CtracEventType.EDITED;
        }
        updateStatus(generalRequiredCoverageSourceDTO, VerificationStatus.PENDING_VERIFICATION, userRequestInfo);
        newRequiredCoverageSourceDTO = saveGeneralRequiredCoverageSource(
                generalRequiredCoverageSourceDTO, fileUploadAttachmentDTOList, ctracEventType, userRequestInfo,null);
        return newRequiredCoverageSourceDTO;
    }


    @Override
    @Transactional
    public GeneralRequiredCoverageSourceDTO verify(@Valid GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO, UserRequestInfo userRequestInfo) {
        GeneralCoverageRequirementDTO generalCoverageRequirementDTO = getByCollateralId(
                generalRequiredCoverageSourceDTO.getCollateralRid());
        GeneralRequiredCoverageSourceDTO pendingVerification = generalCoverageRequirementDTO.getPendingVerificationRequirementSource();


        // Convert Documentdate as Tue Sep 18 00:00:00 IST 2018 format for comparision
        Date pendingDocumentDate = defaultDateFormatter.parse(pendingVerification.getDocumentDate());
        Date generalRequiredCoverageDocumentDate = defaultDateFormatter.parse(generalRequiredCoverageSourceDTO.getDocumentDate());

        //set Documentdate into PendingVarification & generalRequiredCoverageSourceDTO obj
        pendingVerification.setDocumentDate(defaultDateFormatter.print(pendingDocumentDate));
        generalRequiredCoverageSourceDTO.setDocumentDate(defaultDateFormatter.print(generalRequiredCoverageDocumentDate));

        boolean hasChanges = !pendingVerification.equals(generalRequiredCoverageSourceDTO);
        validationService.validateVerify(
                generalRequiredCoverageSourceDTO, pendingVerification);
        updateStatus(
                generalRequiredCoverageSourceDTO, VerificationStatus.VERIFIED, userRequestInfo);
        updateStatus(
                generalCoverageRequirementDTO.getVerifiedRequirementSource(), VerificationStatus.INACTIVE, userRequestInfo);
        if (hasChanges) {
            publishEventService.publishEvent(new GeneralRequiredCoveragePublishEventRequest(
                    generalRequiredCoverageSourceDTO)
                    .forCtracEventType(CtracEventType.EDITED)
                    .withUserRequestInfo(userRequestInfo));
        }
        GeneralRequiredCoverageSourceDTO newRequiredCoverageSourceDTO = saveGeneralRequiredCoverageSource(
                generalRequiredCoverageSourceDTO, null, CtracEventType.VERIFIED, userRequestInfo, generalCoverageRequirementDTO.getVerifiedRequirementSource());
        deleteGeneralRequiredCoverageSourceDocuments(generalRequiredCoverageSourceDTO);

        //TODO trigger verification actions
        return newRequiredCoverageSourceDTO;
    }

    @Override
    public GeneralCoverageRequirementDTO getByCollateralId(Long collateralId) {
        GeneralCoverageRequirementDTO generalCoverageRequirementDTO = new GeneralCoverageRequirementDTO();
        List<GeneralRequiredCoverageSourceDTO> sources = new ArrayList<>();
        List<GeneralRequiredCoverageSource> sourceList = generalRequiredCoverageSourceRepository.findByCollateralRid(collateralId);
        for (GeneralRequiredCoverageSource generalRequiredCoverageSource: sourceList) {
            sources.add(generalRequiredCoverageSource.toGeneralRequiredCoverageSourceDTO());
        }
        Collections.sort(sources);
        for (GeneralRequiredCoverageSourceDTO source: sources) {
            if(VerificationStatus.PENDING_VERIFICATION.name().equals(source.getStatus())){
                generalCoverageRequirementDTO.setPendingVerificationRequirementSource(source);
            }
            else if(VerificationStatus.VERIFIED.name().equals(source.getStatus())){
                generalCoverageRequirementDTO.setVerifiedRequirementSource(source);
            }
        }
        sources.remove(generalCoverageRequirementDTO.getPendingVerificationRequirementSource());
        sources.remove(generalCoverageRequirementDTO.getVerifiedRequirementSource());
        generalCoverageRequirementDTO.setInactiveRequirementSources(sources);
        generalCoverageRequirementDTO.setCollateralRid(collateralId);
        return generalCoverageRequirementDTO;
    }

    @Override
    @Transactional
    public GeneralRequiredCoverageSourceDTO getById(Long genReqCovSrcId) {
        GeneralRequiredCoverageSource generalRequiredCoverageSource = generalRequiredCoverageSourceRepository.getOne(genReqCovSrcId);
        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = generalRequiredCoverageSource.toGeneralRequiredCoverageSourceDTO();
        populateCanDelete(generalRequiredCoverageSourceDTO);
        return generalRequiredCoverageSourceDTO;
    }

    void updateStatus(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO, VerificationStatus verificationStatus, UserRequestInfo userRequestInfo) {
        if(generalRequiredCoverageSourceDTO != null) {
            generalRequiredCoverageSourceDTO.setStatus(verificationStatus.name());
            if (VerificationStatus.PENDING_VERIFICATION == verificationStatus) {
                collateralSectionService.edit(generalRequiredCoverageSourceDTO.getCollateralRid(),
                        CollateralSection.GENERAL_REQUIRED_INSURANCE_COVERAGE, userRequestInfo);
            } else if (VerificationStatus.VERIFIED == verificationStatus) {
                collateralSectionService.verify(generalRequiredCoverageSourceDTO.getCollateralRid(),
                        CollateralSection.GENERAL_REQUIRED_INSURANCE_COVERAGE, userRequestInfo);
            }
        }
     }

     private GeneralRequiredCoverageSource getGeneralRequiredCoverageSource(Long rid){
         Optional<GeneralRequiredCoverageSource> genReqSource = generalRequiredCoverageSourceRepository.findById(rid);
         return genReqSource.orElse(null);
     }

    GeneralRequiredCoverageSourceDTO saveGeneralRequiredCoverageSource(
            GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
            List<FileUploadAttachmentDTO> fileUploadAttachmentDTOList,
            CtracEventType collateralEventType, UserRequestInfo userRequestInfo,
            GeneralRequiredCoverageSourceDTO inactiveGeneralCoverageRequirementDTO) {
        GeneralRequiredCoverageSource generalRequiredCoverageSource = new GeneralRequiredCoverageSource();

        if(generalRequiredCoverageSourceDTO.getRid() != null){
            generalRequiredCoverageSource = generalRequiredCoverageSourceRepository.getOne(generalRequiredCoverageSourceDTO.getRid());
            if (inactiveGeneralCoverageRequirementDTO != null) {
                GeneralRequiredCoverageSource inactiveRequiredCoverageSource = generalRequiredCoverageSourceRepository.getOne(inactiveGeneralCoverageRequirementDTO.getRid());
                inactiveRequiredCoverageSource = inactiveRequiredCoverageSource.fromGeneralRequiredCoverageSourceDTO(
                        inactiveGeneralCoverageRequirementDTO, userRequestInfo);
                generalRequiredCoverageSourceRepository.save(inactiveRequiredCoverageSource);
            }
        }
        generalRequiredCoverageSource = generalRequiredCoverageSource.fromGeneralRequiredCoverageSourceDTO(
                generalRequiredCoverageSourceDTO, userRequestInfo);
        generalRequiredCoverageSource = generalRequiredCoverageSourceRepository.save(generalRequiredCoverageSource);

        GeneralRequiredCoverageSourceDTO newRequiredCoverageSourceDTO = generalRequiredCoverageSource.toGeneralRequiredCoverageSourceDTO();

        if(CollectionUtils.isNotEmpty(fileUploadAttachmentDTOList)) {
            newRequiredCoverageSourceDTO.addCoverageSourceDocuments(
                    saveGeneralRequiredCoverageSourceDocuments(generalRequiredCoverageSource, fileUploadAttachmentDTOList, userRequestInfo));
        }
        publishEventService.publishEvent(new GeneralRequiredCoveragePublishEventRequest(
                newRequiredCoverageSourceDTO).forCtracEventType(collateralEventType)
                .withUserRequestInfo(userRequestInfo));
        return newRequiredCoverageSourceDTO;
    }

    private List<CollateralDocumentSummaryDTO> saveGeneralRequiredCoverageSourceDocuments(GeneralRequiredCoverageSource generalRequiredCoverageSource,
                                                               List<FileUploadAttachmentDTO> fileUploadAttachmentDTOList, UserRequestInfo userRequestInfo){
        List<CollateralDocumentSummaryDTO> list = new ArrayList<>();
        try{
            list.addAll(this.collateralDocumentService
                    .saveDocuments(fileUploadAttachmentDTOList, generalRequiredCoverageSource,
                            DocumentMetaDataBuilder.aDocumentMetaData()
                                    .withDocumentDate(generalRequiredCoverageSource.getDocumentDate())
                                    .withDocIdentifier(CONST_GENERAL_REQUIRED_COVERAGE_SOURCE_DOCUMENT_IDENTIFIER)
                                    .withUserSid(userRequestInfo.getUserSid())
                                    .buildDto())
            );
        }catch(Exception ex){
            logger.error("Failure - Saving General Required Coverage Source Documents ",ex);
        }
        return list;
    }

    void deleteGeneralRequiredCoverageSourceDocuments(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO){
        if (generalRequiredCoverageSourceDTO == null) {
            return;
        }
        GeneralRequiredCoverageSource model = generalRequiredCoverageSourceRepository.getOne(generalRequiredCoverageSourceDTO.getRid());
        this.collateralDocumentService.deleteAllDocuments(model.getCoverageSourceDocuments());
    }

    @Override
    public List<GeneralCoverageDTO> getCoveragesByCollateralId(Long collateralRid) {
        List<GeneralCoverageDTO> generalCoverageDTOs = new ArrayList<>();
        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = getVerifiedOrPendingByCollateralId(collateralRid);
        if (generalRequiredCoverageSourceDTO != null) {
            generalCoverageDTOs = getFilteredGeneralCoverageDTO(generalRequiredCoverageSourceDTO);
        }
        return generalCoverageDTOs;
    }

    @Override
    public GeneralRequiredCoverageSourceDTO getVerifiedOrPendingByCollateralId(Long collateralId) {
        GeneralCoverageRequirementDTO generalRequirements = getByCollateralId(collateralId);
        return generalRequirements.getVerifiedRequirementSource() != null ? generalRequirements.getVerifiedRequirementSource() :
                generalRequirements.getPendingVerificationRequirementSource();
    }

    List<GeneralCoverageDTO> getFilteredGeneralCoverageDTO(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO) {
        List<GeneralCoverageDTO> all = generalCoverageService.getGeneralCoverageTypes();
        List<GeneralCoverageDTO> generalCoverageDTOs;
        generalCoverageDTOs = all.stream()
                .filter(gc -> generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages().stream()
                        .anyMatch(grc -> gc.getRid().equals(grc.getGeneralCoverageRid()) && BooleanUtils.isNotTrue(grc.getIsDescoped())))
                .collect(Collectors.toList());
        return generalCoverageDTOs;
    }

    boolean canDeleteRequiredCoverageSource(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO) {
        if (generalRequiredCoverageSourceDTO == null) {
            return false;
        }
        if (VerificationStatus.PENDING_VERIFICATION.name().equals(generalRequiredCoverageSourceDTO.getStatus())) {
            Long collateralRid = generalRequiredCoverageSourceDTO.getCollateralRid();
            if (collateralRid == null) {
                return false;
            }
            GeneralRequiredCoverageSourceDTO verifiedRequirementSource = getByCollateralId(collateralRid).getVerifiedRequirementSource();
            if (verifiedRequirementSource != null) {
                return true;
            }
            if (CollectionUtils.isEmpty(policyService.getGeneralPolicies(collateralRid, true)) &&
                    CollectionUtils.isEmpty(policyService.getGeneralPolicies(collateralRid, false))) {
                return true;
            }
        }
        return false;
    }

    void populateCanDelete(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO) {
        if (generalRequiredCoverageSourceDTO != null) {
            generalRequiredCoverageSourceDTO.setCanDelete(canDeleteRequiredCoverageSource(generalRequiredCoverageSourceDTO));
        }
    }

    @Override
    @Transactional
    public void deleteSource(Long generalRequiredCoverageSourceId, UserRequestInfo userRequestInfo) {
        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = getById(generalRequiredCoverageSourceId);
        validationService.validateDelete(
                generalRequiredCoverageSourceDTO, canDeleteRequiredCoverageSource(generalRequiredCoverageSourceDTO));
        generalRequiredCoverageSourceRepository.deleteById(generalRequiredCoverageSourceId);
        publishEventService.publishEvent(new GeneralRequiredCoveragePublishEventRequest(
                generalRequiredCoverageSourceDTO)
                .forCtracEventType(CtracEventType.DELETED)
                .withUserRequestInfo(userRequestInfo));
    }
}
