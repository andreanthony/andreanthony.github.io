package com.jpmorgan.cb.wlt.dao;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "TLCP_COVERAGE_DETAILS")
public class CoverageDetails extends AuditableEntity {

    public static final BigDecimal DEFAULT_COVERAGE_AMOUNT = new BigDecimal("0.00");
    public static final BigDecimal DEFAULT_COVERAGE_VALUE = new BigDecimal("0.00");

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "coverageDetailsSeqGenerator")
    @TableGenerator(name = "coverageDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_COVERAGE_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "COVERAGE_TYPE")
    private String coverageType;

    @Column(name = "BALANCE_TYPE")
    private String balanceType;

    @Column(name = "BUILDING_CONTENT_BALANCE_TYPE")
    private String buildingContentBalanceType;

    @Column(name = "COVERAGE_AMOUNT")
    private BigDecimal coverageAmount = DEFAULT_COVERAGE_AMOUNT;

    @Column(name = "COVERAGE_VALUE")
    private BigDecimal coverageValue = DEFAULT_COVERAGE_VALUE;

    @Column(name = "DEDUCTIBLE_AMOUNT")
    private BigDecimal deductibleAmount = DEFAULT_COVERAGE_AMOUNT;

    @Column(name = "AGGREGATE_AMOUNT")
    private BigDecimal aggregateAmount = DEFAULT_COVERAGE_AMOUNT;

    @ManyToOne
    @JoinColumn(name = "COVERAGE_ADDRESS_ID")
    private Address coverageAddress;

    @Column(name = "VERIFIED")
    private Boolean verified = false;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "HOLD_RID")
    private Hold hold;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public String getBalanceType() {
        return balanceType;
    }

    public void setBalanceType(String balanceType) {
        this.balanceType = balanceType;
    }

    public String getBuildingContentBalanceType() {
        return buildingContentBalanceType;
    }

    public void setBuildingContentBalanceType(String buildingContentBalanceType) {
        this.buildingContentBalanceType = buildingContentBalanceType;
    }

    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(BigDecimal coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public BigDecimal getDeductibleAmount() {
        return deductibleAmount;
    }

    public void setDeductibleAmount(BigDecimal deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
    }

    public BigDecimal getAggregateAmount() {
        return aggregateAmount;
    }

    public void setAggregateAmount(BigDecimal aggregateAmount) {
        this.aggregateAmount = aggregateAmount;
    }

    public BigDecimal getCoverageValue() {
        return coverageValue;
    }

    public void setCoverageValue(BigDecimal coverageValue) {
        this.coverageValue = coverageValue;
    }

    public Address getCoverageAddress() {
        return coverageAddress;
    }

    public void setCoverageAddress(Address coverageAddress) {
        this.coverageAddress = coverageAddress;
    }

    public Boolean getVerified() {
        return verified;
    }

    public void setVerified(Boolean verified) {
        this.verified = verified;
    }

    public Hold getHold() {
        return hold;
    }

    public void setHold(Hold hold) {
        this.hold = hold;
    }

}
