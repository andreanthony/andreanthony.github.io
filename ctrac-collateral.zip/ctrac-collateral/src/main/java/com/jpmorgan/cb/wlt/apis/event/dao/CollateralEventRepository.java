package com.jpmorgan.cb.wlt.apis.event.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CollateralEventRepository extends JpaRepository<CollateralEvent, Long> {

}
