package com.jpmorgan.cb.wlt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;


public interface BankHolidaysRepository extends JpaRepository<BankHolidays, Long>{
	
	List<BankHolidays> findByHolidayDateAndHolidayActiveFlagAndHolidayCalendar(Date holidayDate, Character holidayActiveFlag, String holidayCalendar);
	
}
