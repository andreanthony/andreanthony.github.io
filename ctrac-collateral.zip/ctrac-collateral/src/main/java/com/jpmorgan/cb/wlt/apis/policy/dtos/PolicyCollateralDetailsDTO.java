package com.jpmorgan.cb.wlt.apis.policy.dtos;

import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionMap;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PolicyCollateralDetailsDTO {

    private Long collateralId;

    @ApiModelProperty(position = 1)
    private String policyAddress;

    @ApiModelProperty(position = 2)
    private String unitOrBuilding;

    @ApiModelProperty(position = 3)
    private String city;

    @ApiModelProperty(position = 4)
    private String state;

    @ApiModelProperty(position = 5)
    private String zipCode;

    @ApiModelProperty(position = 6)
    private List<PolicyInsuranceCoverageDTO> insuranceCoverages = new ArrayList<>();

    private String policyFloodZone;

    private String grandfathered;


    private Map<String, BIRRuleConclusionDTO> birRuleConclusions = new BIRRuleConclusionMap();

    public Long getCollateralId() {
        return collateralId;
    }

    public void setCollateralId(Long collateralId) {
        this.collateralId = collateralId;
    }

    public String getPolicyAddress() {
        return policyAddress;
    }

    public void setPolicyAddress(String policyAddress) {
        this.policyAddress = policyAddress;
    }

    public String getUnitOrBuilding() {
        return unitOrBuilding;
    }

    public void setUnitOrBuilding(String unitOrBuilding) {
        this.unitOrBuilding = unitOrBuilding;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public List<PolicyInsuranceCoverageDTO> getInsuranceCoverages() {
        return insuranceCoverages;
    }

    public void setInsuranceCoverages(List<PolicyInsuranceCoverageDTO> insuranceCoverages) {
        this.insuranceCoverages = insuranceCoverages;
    }

    public String getPolicyFloodZone() {
        return policyFloodZone;
    }

    public void setPolicyFloodZone(String policyFloodZone) {
        this.policyFloodZone = policyFloodZone;
    }

    public String getGrandfathered() {
        return grandfathered;
    }

    public void setGrandfathered(String grandfathered) {
        this.grandfathered = grandfathered;
    }

    public Map<String, BIRRuleConclusionDTO> getBirRuleConclusions() {
        return birRuleConclusions;
    }

    public void setBirRuleConclusions(Map<String, BIRRuleConclusionDTO> birRuleConclusions) {
        this.birRuleConclusions = birRuleConclusions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        PolicyCollateralDetailsDTO that = (PolicyCollateralDetailsDTO) o;

        return new EqualsBuilder()
                .append(collateralId, that.collateralId)
                .append(policyAddress, that.policyAddress)
                .append(unitOrBuilding, that.unitOrBuilding)
                .append(city, that.city)
                .append(state, that.state)
                .append(zipCode, that.zipCode)
                .isEquals() && equalInsuranceCoverages(that.insuranceCoverages);
    }

    private boolean equalInsuranceCoverages(List<PolicyInsuranceCoverageDTO> insuranceCoveragesToCompare){
        return insuranceCoverages.containsAll(insuranceCoveragesToCompare)
                && insuranceCoverages.size() == insuranceCoveragesToCompare.size();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(collateralId)
                .append(policyAddress)
                .append(unitOrBuilding)
                .append(city)
                .append(state)
                .append(zipCode)
                .append(insuranceCoverages)
                .toHashCode();
    }
}
