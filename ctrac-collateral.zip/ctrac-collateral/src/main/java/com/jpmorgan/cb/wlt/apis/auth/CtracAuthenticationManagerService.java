package com.jpmorgan.cb.wlt.apis.auth;

import com.jpmorgan.cib.wlt.ctrac.auth.AuthenticationManager;

public interface CtracAuthenticationManagerService {

	String USER_REQUEST_INFO = "userRequestInfo";

	AuthenticationManager getAuthenticationManager();
}
