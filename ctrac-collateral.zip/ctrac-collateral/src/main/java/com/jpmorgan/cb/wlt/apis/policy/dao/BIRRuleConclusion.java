package com.jpmorgan.cb.wlt.apis.policy.dao;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_BIR_FIELD_CONCLUSION")
public class BIRRuleConclusion {
	
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "birFieldConclusionSeqGenerator")
	@TableGenerator(name = "birFieldConclusionSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BIR_FIELD_CONCLUSION", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
	@Id
	@Column(name = "RID")
	private Long rid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PROOF_OF_COVERAGE_RID")
	private ProofOfCoverage proofOfCoverage;
	
	@Column(name = "COLLATERAL_RID")
	private Long collateralRid;
	
	@Column(name = "INSURABLE_ASSET_RID")
	private Long insurableAssetSortOrder;
	
	@Column(name = "FIELD_NAME")
	private String fieldName;
	
	@Column(name = "CONCLUSION")
	private String conclusion;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public ProofOfCoverage getProofOfCoverage() {
		return proofOfCoverage;
	}

	public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
		this.proofOfCoverage = proofOfCoverage;
	}

	public Long getCollateralRid() {
		return collateralRid;
	}

	public void setCollateralRid(Long collateralRid) {
		this.collateralRid = collateralRid;
	}

	public Long getInsurableAssetSortOrder() {
		return insurableAssetSortOrder;
	}

	public void setInsurableAssetSortOrder(Long insurableAssetSortOrder) {
		this.insurableAssetSortOrder = insurableAssetSortOrder;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getConclusion() {
		return conclusion;
	}

	public void setConclusion(String conclusion) {
		this.conclusion = conclusion;
	}
}
