package com.jpmorgan.cb.wlt.apis.upload.dtos;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class FileUploadAttachmentDTO {

    private FileUploadAttachmentSummaryDTO summary;
    private byte[] fileContent;

    public FileUploadAttachmentSummaryDTO getSummary() {
        return summary;
    }

    public void setSummary(FileUploadAttachmentSummaryDTO summary) {
        this.summary = summary;
    }

    public byte[] getFileContent() {
        return fileContent;
    }

    public void setFileContent(byte[] fileContent) {
        this.fileContent = fileContent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        FileUploadAttachmentDTO that = (FileUploadAttachmentDTO) o;

        return new EqualsBuilder()
                .append(summary, that.summary)
                .append(fileContent, that.fileContent)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(summary)
                .append(fileContent)
                .toHashCode();
    }
}
