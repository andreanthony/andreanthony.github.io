package com.jpmorgan.cb.wlt.apis.c3.services;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3AlertEmail;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;

import java.util.List;

public interface LenderPlacePolicyService {
    List<Long> applyC3Response(C3ResponseDTO c3ResponseDTO);

    ProofOfCoverage cancel(C3PolicyCancellation policyCancellation);

    void publishC3WorkflowEvent(List<Long> proofOfCoverageIds, Long collateralRid, CtracEventType ctracEventType);

    void publishAlertEmailEvent(C3AlertEmail alertEmail);

}
