package com.jpmorgan.cb.wlt.apis.policy.dao.mappers;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProvidedCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.FloodProvidedCoverageMapper;
import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.GeneralProvidedCoverageMapper;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.exceptions.ExceptionLevel;

public class ProvidedCoverageMapperFactory {
    private ProvidedCoverageMapperFactory() {}

    public static DaoMapper<ProvidedCoverage, PolicyInsuranceCoverageDTO> getProvidedCoverageMapper(ProvidedCoverage providedCoverage) {
        if (providedCoverage.getGeneralCoverage() != null && providedCoverage.getInsurableAsset() == null) {
            return new GeneralProvidedCoverageMapper();
        } else if (providedCoverage.getInsurableAsset() != null && providedCoverage.getGeneralCoverage() == null) {
            return new FloodProvidedCoverageMapper();
        } else {
            throw new CtracException("ProvidedCoverage must have either GeneralCoverage or InsurableAsset and not both.", ExceptionLevel.GENEOS);
        }
    }

    public static DaoMapper<ProvidedCoverage, PolicyInsuranceCoverageDTO> getProvidedCoverageMapper(PolicyInsuranceCoverageDTO insuranceCoverageDTO) {
        if (insuranceCoverageDTO.getInsurableAssetRid() != null && insuranceCoverageDTO.getInsuranceCoverageType() != null) {
            return new FloodProvidedCoverageMapper();
        } else if (insuranceCoverageDTO.getInsuranceCoverageType() != null){
            return new GeneralProvidedCoverageMapper();
        } else {
            throw new CtracException("PolicyInsuranceCoverageDTO must have either GeneralCoverage or InsurableAsset and not both.", ExceptionLevel.GENEOS);
        }
    }
}
