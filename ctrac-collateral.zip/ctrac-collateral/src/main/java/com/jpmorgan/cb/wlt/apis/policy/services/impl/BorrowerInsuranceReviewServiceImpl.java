package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl.GenericBirPolicyDetailsMapper;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.services.BorrowerInsuranceReviewService;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.GenericBorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.enums.BorrowerInsuranceReviewRule;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class BorrowerInsuranceReviewServiceImpl implements BorrowerInsuranceReviewService {

    public Map<String, BIRRuleConclusionDTO> getBorrowerPolicyConclusions(PolicyDTO policyDTO) {
        GenericBirPolicyDetailsMapper policyMapper = new GenericBirPolicyDetailsMapper();
        GenericBorrowerInsuranceReviewDTO biReviewDTO = policyMapper.toDTO(policyDTO);
        InsuranceType insuranceType = EnumUtils.getEnum(InsuranceType.class, policyDTO.getInsuranceType());
        for (BorrowerInsuranceReviewRule rule : BorrowerInsuranceReviewRule.getRulesByInsuranceType(insuranceType)) {
            rule.execute(biReviewDTO);
        }
        if (InsuranceType.GENERAL == insuranceType) {
             policyDTO.getRuleConclusions().keySet().forEach(fieldName -> {
                if (!biReviewDTO.getBirRuleConclusions().keySet().contains(fieldName) ||
                        StringUtils.equals(BorrowerInsuranceReviewRule.JPM_LIEN_POSITION_RULE.getKey(), fieldName)) {
                    BIRRuleConclusionDTO userDefinedConclusion = biReviewDTO.getBirRuleConclusions().get(fieldName);
                    userDefinedConclusion.setConclusion(policyDTO.getRuleConclusions().get(fieldName).getConclusion());
                }
            });
        }
        return biReviewDTO.getAllBIRRuleConclusionsMap();
    }
}
