package com.jpmorgan.cb.wlt.apis.document.dao.mappers;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.FileContent;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

public class CollateralDocumentMapper implements DaoMapper<CollateralDocument, CollateralDocumentDTO> {

    @Override
    public CollateralDocumentDTO toDTO(CollateralDocument model) {
        CollateralDocumentDTO dto = new CollateralDocumentDTO();
        dto.setCollateralRid(model.getCollateralRid());
        dto.setRid(model.getRid());
        dto.setDocIdentifier(model.getDocIdentifier());
        dto.setDocumentDate(model.getDocumentDate());
        dto.setFileName(model.getFileName());
        dto.setFileNameWithExt(model.getFileNameWithExt());
        dto.setFileContent(model.getFileContent() != null ? model.getFileContent().toFileContentDTO() : null);
        return dto;
    }

    @Override
    public boolean map(CollateralDocumentDTO dto, CollateralDocument model) {
        if (dto.equals(toDTO(model))) {
            return false;
        }
        model.setCollateralRid(dto.getCollateralRid());
        model.setDocIdentifier(dto.getDocIdentifier());
        model.setDocumentDate(dto.getDocumentDate());
        model.setFileName(dto.getFileName());
        model.setFileNameWithExt(dto.getFileNameWithExt());
        if(dto.getFileContent() != null){
            if(model.getFileContent() == null){
                model.setFileContent(new FileContent());
            }
            model.getFileContent().map(dto.getFileContent());
        }
        return true;
    }

}
