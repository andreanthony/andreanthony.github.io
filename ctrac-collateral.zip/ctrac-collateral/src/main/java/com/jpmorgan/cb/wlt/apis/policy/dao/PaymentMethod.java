package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.apis.policy.dtos.PaymentMethodDTO;
import com.jpmorgan.cb.wlt.dao.Address;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_PAYMENT_METHOD")
public class PaymentMethod {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "paymentMethodSeqGenerator")
    @TableGenerator(name = "paymentMethodSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_PAYMENT_METHOD", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;

    @Column(name = "PAYMENT_ACCOUNT")
    private String paymentAccount;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ADDRESS_RID")
    private Address address;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public PaymentMethodDTO toDTO() {
        PaymentMethodDTO paymentMethodDTO = new PaymentMethodDTO();
        if (address != null) {
            paymentMethodDTO.setAddress(address.toDTO());
        }
        paymentMethodDTO.setPaymentMethod(paymentMethod);
        paymentMethodDTO.setPaymentAccount(paymentAccount);
        return paymentMethodDTO;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        PaymentMethod that = (PaymentMethod) o;

        return new EqualsBuilder()
                .append(rid, that.rid)
                .append(paymentMethod, that.paymentMethod)
                .append(paymentAccount, that.paymentAccount)
                .append(address, that.address)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(paymentMethod)
                .append(paymentAccount)
                .append(address)
                .toHashCode();
    }

    public boolean map(PaymentMethodDTO paymentMethodDTO) {
        if (this.toDTO().equals(paymentMethodDTO)) {
            return false;
        }
        this.paymentMethod = paymentMethodDTO.getPaymentMethod();
        this.paymentAccount = paymentMethodDTO.getPaymentAccount();
        if (paymentMethodDTO.getAddress() != null) {
            if (address == null) {
                address = new Address();
            }
            address.map(paymentMethodDTO.getAddress());
        } else {
            this.address = null;
        }
        return true;
    }
}
