package com.jpmorgan.cb.wlt.apis.requirement.general.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.sections.impl.CollateralSectionStatusImpl;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralCoverage;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository.GeneralCoverageRepository;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.services.GeneralCoverageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GeneralCoverageServiceImpl implements GeneralCoverageService {

    private static final Logger logger = LoggerFactory.getLogger(CollateralSectionStatusImpl.class);
    private GeneralCoverageRepository generalCoverageRepository;

    @Autowired
    public GeneralCoverageServiceImpl(GeneralCoverageRepository generalCoverageRepository) {
        assert(generalCoverageRepository != null);
        this.generalCoverageRepository = generalCoverageRepository;
    }

    @Override
    public List<GeneralCoverageDTO> getGeneralCoverageTypes() {
        List<GeneralCoverageDTO> generalCoverageDTOS = new ArrayList<>();
        List<GeneralCoverage> generalCoverages = generalCoverageRepository.findAll();
        for (GeneralCoverage generalCoverage : generalCoverages) {
            generalCoverageDTOS.add(generalCoverage.toGeneralCoverageDTO());
        }
        return generalCoverageDTOS;
    }

}
