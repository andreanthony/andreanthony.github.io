package com.jpmorgan.cb.wlt.apis.collateral.owner.services.impl;

import com.jpmorgan.cb.wlt.apis.collateral.owner.dao.CollateralOwner;
import com.jpmorgan.cb.wlt.apis.collateral.owner.dao.CollateralOwnerRepository;
import com.jpmorgan.cb.wlt.apis.collateral.owner.services.CollateralOwnerService;
import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;
import com.jpmorgan.cb.wlt.apis.entity.services.EntityService;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CollateralOwnerServiceImpl implements CollateralOwnerService {

    private CollateralOwnerRepository collateralOwnerRepository;
    private EntityService entityService;
    private LoanService loanService;


    @Autowired
    public CollateralOwnerServiceImpl(CollateralOwnerRepository collateralOwnerRepository,
                                      EntityService entityService, LoanService loanService) {
        assert (collateralOwnerRepository != null);
        this.collateralOwnerRepository = collateralOwnerRepository;
        assert (entityService != null);
        this.entityService = entityService;
        assert (loanService != null);
        this.loanService = loanService;
    }

    @Override
    public List<EntityDTO> getCollateralOwners(Long collateralId) {
        List<CollateralOwner> collateralOwners = collateralOwnerRepository.findByCollateralRid(collateralId);
        List<Long> entityIds = collateralOwners.stream().map(CollateralOwner::getOwnerId).collect(Collectors.toList());
        return entityService.getEntities(entityIds);
    }
    @Override
    public String getUniqueMortgagorAndBorrowerNames(Long collateralRid, String separator) {
        Set<String> uniqueMortgagorAndBorrowerNames = getListOfUniqueOwnerAndBorrower(getCollateralOwners(collateralRid));
        uniqueMortgagorAndBorrowerNames.addAll(getUniqueBorrowerNames(collateralRid));
        return uniqueMortgagorAndBorrowerNames.stream()
                .map(i -> i.toString()).collect(Collectors.joining(separator));
    }

    protected Set<String> getUniqueBorrowerNames(Long collateralRid) {
        List<LoanDTO> loans = loanService.getActiveLoans(collateralRid);
        List<EntityDTO> borrowerList = new ArrayList<>();
        loans.forEach(loan -> {
            borrowerList.addAll(loan.getBorrowers());
        });
        return getListOfUniqueOwnerAndBorrower(borrowerList);
    }

    protected Set<String> getListOfUniqueOwnerAndBorrower(List<EntityDTO> customerList) {

        return customerList.stream().map(entityDTO -> entityDTO.getName()).collect(Collectors.toCollection(HashSet::new));

    }

}
