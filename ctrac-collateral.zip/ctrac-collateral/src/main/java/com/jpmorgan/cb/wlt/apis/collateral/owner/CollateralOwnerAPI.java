package com.jpmorgan.cb.wlt.apis.collateral.owner;

import com.jpmorgan.cb.wlt.apis.collateral.owner.services.CollateralOwnerService;
import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/collaterals/{collateralId}/owners")
public class CollateralOwnerAPI {

    private CollateralOwnerService collateralOwnerService;

    @Autowired
    public CollateralOwnerAPI(CollateralOwnerService collateralOwnerService) {
        assert(collateralOwnerService != null);
        this.collateralOwnerService = collateralOwnerService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<EntityDTO>> getCollateralOwners(@PathVariable Long collateralId) {
        return ResponseEntity.ok(collateralOwnerService.getCollateralOwners(collateralId));
    }
}
