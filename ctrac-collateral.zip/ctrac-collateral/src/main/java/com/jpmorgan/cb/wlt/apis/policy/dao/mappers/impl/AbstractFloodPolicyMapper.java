package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProvidedCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

import java.util.List;
import java.util.Optional;

public class AbstractFloodPolicyMapper extends AbstractPolicyMapper implements DaoMapper<ProofOfCoverage, PolicyDTO> {

    @Override
    protected Optional<ProvidedCoverage> findMatchingProvidedCoverage(
            List<ProvidedCoverage> providedCoverages, PolicyInsuranceCoverageDTO policyInsuranceCoverageDTO) {
        return providedCoverages.stream()
                .filter(providedCoverage ->
                        providedCoverage.getInsurableAsset() != null
                                && providedCoverage.getInsurableAsset().getRid().equals(policyInsuranceCoverageDTO.getInsurableAssetRid())).findFirst();
    }
}