package com.jpmorgan.cb.wlt.apis.upload.services;


import com.jpmorgan.cb.wlt.apis.upload.dtos.FileAttachmentDeletedResponse;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentSummaryDTO;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface FileUploadService {

    String CONST_FILE_UPLOAD_BUCKET_CATEGORY_CODESET = "FILE_UPLOAD_BUCKET_CATEGORY";

    List<FileUploadAttachmentSummaryDTO> getAttachmentsSummary(String bucketId);

    List<FileUploadAttachmentDTO> getAttachments(String bucketId);

    List<FileUploadAttachmentSummaryDTO> storeAttachments(String bucketId, String category, MultipartFile[] files);

    FileAttachmentDeletedResponse deleteAllAttachments(String bucketId);
}
