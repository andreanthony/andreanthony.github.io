package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class GapOnPolicyExpirationRule implements C3Rule {
    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        if (c3RequestDTO.isEvaluateGap()) {
            List<C3Policy> newC3Policies = c3RequestDTO.getBorrowerPolicies()
                    .stream()
                    .filter(C3Policy::isNewlyAccepted)
                    .collect(Collectors.toList());
            // creating a list of expiring policies which are fully covered by a newly accepted (pending c3) policy
            // with no lenderplacement required on the expiration date
            if (!newC3Policies.isEmpty()) {
                c3ResponseDTO.getExpiringPoliciesWithNoGap().addAll(
                    c3RequestDTO.getExpiringPolicies(c3RequestDTO.getAllPolicies())
                        .stream()
                        .filter(expiringPolicy -> hasMatchingPolicy(expiringPolicy, newC3Policies) &&
                                !policyIssuanceNeeded(c3ResponseDTO.getPoliciesToIssue(),
                                        expiringPolicy.getProvidedCoverages(), expiringPolicy.getExpirationDate_()))
                        .map(C3Policy::getPolicyId)
                        .collect(Collectors.toList()));
            }
        }
    }

    private boolean hasMatchingPolicy(C3Policy matchingPolicy, List<C3Policy> c3Policies) {
        return c3Policies
                .stream()
                .anyMatch(policy -> policy.hasMatchingCoverage(matchingPolicy));
    }

    private boolean policyIssuanceNeeded(List<C3PolicyIssuance> policiesToIssue, List<C3ProvidedCoverage> providedCoverages, Date date) {
        return providedCoverages
                .stream()
                .anyMatch(c3ProvidedCoverage -> policiesToIssue
                        .stream()
                        .anyMatch(c3PolicyIssuance -> c3PolicyIssuance.isProvidingCoverage(
                                c3ProvidedCoverage.getCoverageType(), c3ProvidedCoverage.getInsurableAssetId(), date)));
    }
}
