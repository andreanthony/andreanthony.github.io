package com.jpmorgan.cb.wlt.apis.requirement.general.dtos;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class GeneralRequiredCoverageDTO {
    private Long rid;
    private long requiredCoverageSourceRid;
    @NotNull
    private Long generalCoverageRid;
    private GeneralCoverageDTO generalCoverageDTO;
    @NotNull @DecimalMin("0")
    private BigDecimal coverageAmount;
    private BigDecimal aggregateAmount;
    private BigDecimal deductibleAmount;
    private String balanceType;
    private Boolean isDescoped;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public long getRequiredCoverageSourceRid() {
        return requiredCoverageSourceRid;
    }

    public void setRequiredCoverageSourceRid(long requiredCoverageSourceRid) {
        this.requiredCoverageSourceRid = requiredCoverageSourceRid;
    }

    public Long getGeneralCoverageRid() {
        return generalCoverageRid;
    }

    public void setGeneralCoverageRid(Long generalCoverageRid) {
        this.generalCoverageRid = generalCoverageRid;
    }

    public GeneralCoverageDTO getGeneralCoverageDTO() {
        return generalCoverageDTO;
    }

    public void setGeneralCoverageDTO(GeneralCoverageDTO generalCoverageDTO) {
        this.generalCoverageDTO = generalCoverageDTO;
    }

    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(BigDecimal coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public BigDecimal getAggregateAmount() {
        return aggregateAmount;
    }

    public void setAggregateAmount(BigDecimal aggregateAmount) {
        this.aggregateAmount = aggregateAmount;
    }

    public BigDecimal getDeductibleAmount() {
        return deductibleAmount;
    }

    public void setDeductibleAmount(BigDecimal deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
    }

    public String getBalanceType() {
        return balanceType;
    }

    public void setBalanceType(String balanceType) {
        this.balanceType = balanceType;
    }

    public String getGeneralCoverageType() {
        return generalCoverageDTO == null? null : generalCoverageDTO.getCoverageType();
    }

    public Boolean getIsDescoped() {
        return isDescoped;
    }

    public void setIsDescoped(Boolean isDescoped) {
        this.isDescoped = isDescoped;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        GeneralRequiredCoverageDTO that = (GeneralRequiredCoverageDTO) o;

        return new EqualsBuilder()
                .append(requiredCoverageSourceRid, that.requiredCoverageSourceRid)
                .append(rid, that.rid)
                .append(generalCoverageRid, that.generalCoverageRid)
                .append(generalCoverageDTO, that.generalCoverageDTO)
                .append(coverageAmount, that.coverageAmount)
                .append(aggregateAmount, that.aggregateAmount)
                .append(deductibleAmount, that.deductibleAmount)
                .append(balanceType, that.balanceType)
                .append(isDescoped, that.isDescoped)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(requiredCoverageSourceRid)
                .append(generalCoverageRid)
                .append(generalCoverageDTO)
                .append(coverageAmount)
                .append(aggregateAmount)
                .append(deductibleAmount)
                .append(balanceType)
                .append(isDescoped)
                .toHashCode();
    }
}
