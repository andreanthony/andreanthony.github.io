package com.jpmorgan.cb.wlt.apis.policy.services;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.OverrideLpPolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;

import java.util.List;
import java.util.Map;

public interface PolicyService {
    PolicyDTO createPolicy(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, UserRequestInfo userRequestInfo);
    PolicyDTO getPolicy(Long policyId);
    PolicyDTO editPolicy(ProofOfCoverage policy, PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, UserRequestInfo userRequestInfo);
    List<PolicyDTO> getPoliciesForC3(Long collateralId);
    List<PolicyDTO> getGeneralPolicies(Long collateralId, Boolean active);
    PolicyDTO overridePolicy(ProofOfCoverage policy, OverrideLpPolicyDTO overrideLpPolicyDTO, UserRequestInfo userRequestInfo);
    PolicyDTO verifyPolicy(PolicyDTO policyDTO, UserRequestInfo userRequestInfo);
    ProofOfCoverage getExistingProofOfCoverage(Long policyId, PolicyDTO policyDTO);
    void deletePolicy(Long policyId, UserRequestInfo userRequestInfo);
    Map<String, BIRRuleConclusionDTO> getPolicyConclusions(PolicyDTO policyDTO);
}

