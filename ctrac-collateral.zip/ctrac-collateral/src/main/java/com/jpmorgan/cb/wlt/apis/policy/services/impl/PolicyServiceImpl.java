package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cb.wlt.apis.document.builder.DocumentMetaDataBuilder;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentSummaryDTO;
import com.jpmorgan.cb.wlt.apis.document.services.CollateralDocumentService;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.policy.dao.*;
import com.jpmorgan.cb.wlt.apis.policy.dtos.LetterCycleDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.OverrideLpPolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyPublishEventRequest;
import com.jpmorgan.cb.wlt.apis.policy.services.BorrowerInsuranceReviewService;
import com.jpmorgan.cb.wlt.apis.policy.services.BorrowerPolicyVerificationService;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicySectionStatusService;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyService;
import com.jpmorgan.cb.wlt.apis.policy.services.exceptions.PolicyNotFoundException;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cb.wlt.services.Ctrac2ApiService;
import com.jpmorgan.cb.wlt.services.ReferenceDateService;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.BIRWorkflowRequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3WorkflowRequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.WorkItemUpdateRequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonBuilder;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class PolicyServiceImpl implements PolicyService {

    private static final Logger logger = LoggerFactory.getLogger(PolicyServiceImpl.class);
    private static final String CONST_GENERAL_POLICY_DOCUMENT_IDENTIFIER = "GENERAL_POLICY";
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    private PolicySectionStatusService policySectionStatusService;
    private CollateralDocumentService collateralDocumentService;
    private ProofOfCoverageRepository proofOfCoverageRepository;
    private PublishEventService publishEventService;
    private Ctrac2ApiService ctrac2ApiService;
    private BorrowerPolicyVerificationService borrowerPolicyVerificationService;
    private BorrowerInsuranceReviewService borrowerInsuranceReviewService;
    private ReferenceDateService referenceDateService;
    private BirProofOfCovDetailsRepository birProofOfCovDetailsRepository;

    @Autowired
    public PolicyServiceImpl(ProofOfCoverageRepository proofOfCoverageRepository,
                             PolicySectionStatusService policySectionStatusService,
                             CollateralDocumentService collateralDocumentService,
                             PublishEventService publishEventService,
                             Ctrac2ApiService ctrac2ApiService,
                             BorrowerPolicyVerificationService borrowerPolicyVerificationService,
                             BorrowerInsuranceReviewService borrowerInsuranceReviewService,
                             ReferenceDateService referenceDateService,
                             BirProofOfCovDetailsRepository birProofOfCovDetailsRepository) {
        assert(proofOfCoverageRepository != null);
        this.proofOfCoverageRepository = proofOfCoverageRepository;
        assert(policySectionStatusService != null);
        this.policySectionStatusService = policySectionStatusService;
        assert(collateralDocumentService != null);
        this.collateralDocumentService = collateralDocumentService;
        assert(publishEventService != null);
        this.publishEventService = publishEventService;
        assert(ctrac2ApiService != null);
        this.ctrac2ApiService = ctrac2ApiService;
        assert(borrowerPolicyVerificationService != null);
        this.borrowerPolicyVerificationService = borrowerPolicyVerificationService;
        assert(borrowerInsuranceReviewService != null);
        this.borrowerInsuranceReviewService = borrowerInsuranceReviewService;
        assert(referenceDateService != null);
        this.referenceDateService = referenceDateService;
        assert(birProofOfCovDetailsRepository != null);
        this.birProofOfCovDetailsRepository = birProofOfCovDetailsRepository;
    }

    @Override
    @Transactional
    public PolicyDTO createPolicy(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, UserRequestInfo userRequestInfo) {
        GeneralInsurance generalInsurance = new GeneralInsurance();
        updateRuleConclusionMap(policyDTO);
        generalInsurance.map(policyDTO);
        updatePolicyStatus(generalInsurance, policyDTO,false);
        PolicyType policyType = PolicyType.valueOf(generalInsurance.getPolicyType());
        if (policyType.isBorrowerPolicy()) {
            generalInsurance.getBirProofOfCovDetails().setProofOfCoverage(generalInsurance);
        }
        updateMigratedFlagForLP(generalInsurance);
        updateReasonForVerification(generalInsurance);
        generalInsurance.applyDeepLevelAuditInfo(userRequestInfo);
        generalInsurance = proofOfCoverageRepository.save(generalInsurance);
        publishPolicyEvent(generalInsurance, CtracEventType.ADDED, userRequestInfo);
        policySectionStatusService.transitionOnCreate(generalInsurance, InsuranceType.GENERAL, userRequestInfo);
        PolicyDTO newPolicyDTO = generalInsurance.toPolicyDTO();
        newPolicyDTO.getPolicyDocuments().addAll(saveUploadedPolicyDocuments(generalInsurance,filesUploaded));
        return newPolicyDTO;
    }

    @Override
    public List<PolicyDTO> getGeneralPolicies(Long collateralId, Boolean active) {
        return getPolicies(collateralId, active, InsuranceType.GENERAL, true);
    }

    @Override
    public List<PolicyDTO> getPoliciesForC3(Long collateralId) {
        return getPolicies(collateralId, true, null, false);
    }

    private List<PolicyDTO> getPolicies(Long collateralId, Boolean active, InsuranceType insuranceType, boolean includePendingVerification) {

        List<String> policyStatuses = PolicyStatus.getActiveAsStrings(includePendingVerification);
        if (active == null) {
            policyStatuses = PolicyStatus.getAllAsStrings();
        } else if (!active) {
            policyStatuses = PolicyStatus.getInactiveAsStrings();
        }
        List<ProofOfCoverage> proofOfCoverages = proofOfCoverageRepository.findByCollateralIdAndStatus(
                collateralId, policyStatuses);

        if (insuranceType == null) {
            return proofOfCoverages.stream().map(ProofOfCoverage::toPolicyDTO).collect(Collectors.toList());
        } else {
            return proofOfCoverages.stream().filter(poc -> insuranceType == InsuranceType.valueOf(poc.getInsuranceType()))
                    .map(ProofOfCoverage::toPolicyDTO).collect(Collectors.toList());
        }
    }

    @Override
    public PolicyDTO getPolicy(Long policyId){
        return getProofOfCoverage(policyId).toPolicyDTO();
    }

    @Override
    @Transactional
    public PolicyDTO editPolicy(ProofOfCoverage policy, PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded,
                                UserRequestInfo userRequestInfo){
        reviewPolicyConclusions(policyDTO);
        updateRuleConclusionMap(policyDTO);
        boolean hasChanged = policy.map(policyDTO);
        // When Policy is LP and expiring - Just save the policy without changing policy Status
        // and without transitioning the section to pending verification (User can save RenewalPaymentMethod)
        boolean skipPolicyStatusTransitioning = PolicyType.valueOf(policy.getPolicyType()).isLenderPlaced() && policy.getPolicyStatus_().isExpiring();
        if (hasChanged) {
            //Policy data changed - save changes and publish edit event
            //Policy Status update
            if(!skipPolicyStatusTransitioning) {
                updatePolicyStatus(policy, policyDTO, false);
                updateReasonForVerification(policy);
            }
            policy.applyDeepLevelAuditInfo(userRequestInfo);
            policy = proofOfCoverageRepository.save(policy);
            publishPolicyEvent(policy, CtracEventType.EDITED, userRequestInfo);
            //Policy Section Status update
            if (!skipPolicyStatusTransitioning) {
                policySectionStatusService.transitionOnEdit(policy, InsuranceType.valueOf(policy.getInsuranceType()), userRequestInfo);
            }
        }
        PolicyDTO newPolicyDTO = policy.toPolicyDTO();
        newPolicyDTO.getPolicyDocuments().addAll(saveUploadedPolicyDocuments(policy,filesUploaded));
        return newPolicyDTO;
    }

    @Override
    @Transactional
    public PolicyDTO overridePolicy(ProofOfCoverage policy, OverrideLpPolicyDTO overrideLpPolicyDTO, UserRequestInfo userRequestInfo){
        logger.debug("overridePolicy::BEGIN, rid={}", policy.getRid());
        PolicyDTO savedPolicy = saveOverriddenPolicy(policy, overrideLpPolicyDTO, userRequestInfo);
        initWorkflowForOverriddenPolicy(policy, overrideLpPolicyDTO, userRequestInfo);
        logger.debug("overridePolicy::END");
        return savedPolicy;
    }

    private PolicyDTO saveOverriddenPolicy(ProofOfCoverage policy, OverrideLpPolicyDTO overrideLpPolicyDTO,
                                           UserRequestInfo userRequestInfo){
        boolean hasChanged = policy.map(overrideLpPolicyDTO.getLpPolicy());
        //Set fields on policy correct when cancellation workflow is triggered

        if (policy.getCancellationEffectiveDate() != null) {
            CancellationReason reason = overrideLpPolicyDTO.hasPremiumNotReceived(policy) ?
                    CancellationReason.BORROWER_POLICY_RECEIVED : CancellationReason.INSURANCE_NOT_NEEDED;
            if (overrideLpPolicyDTO.isTriggerCancellationWorkflow()) {
                policy.setCancellationReason(reason.name());
            } else {
                policy.cancel(reason, policy.getCancellationEffectiveDate(), referenceDateService.getCurrentReferenceDate());
            }
        }
        if (hasChanged || policyOverrideIssuanceDate(policy, overrideLpPolicyDTO.getLpPolicy())) {
            //Policy data changed - save changes and publish edit event
            policy.applyDeepLevelAuditInfo(userRequestInfo);
            publishPolicyEvent(policy, CtracEventType.ADMIN_EDITED, userRequestInfo);
        }
        policy = proofOfCoverageRepository.save(policy);
        return policy.toPolicyDTO();
    }

    private void initWorkflowForOverriddenPolicy(ProofOfCoverage policy, OverrideLpPolicyDTO overrideLpPolicyDTO,
                                                 UserRequestInfo userRequestInfo){
        if(overrideLpPolicyDTO.isTriggerCancellationWorkflow()) {
            C3WorkflowRequestEventDTO startCancellationWorkflowEvent = new C3WorkflowRequestEventDTO();
            startCancellationWorkflowEvent.setEventType(CtracEventType.LP_POLICY_CANCELLED.getDisplayValue());
            startCancellationWorkflowEvent.setProofOfCoverageRids(Collections.singletonList(policy.getRid()));
            startCancellationWorkflowEvent.setPerformedBy(userRequestInfo.getUserSid());
            publishEventService.publishEvent(startCancellationWorkflowEvent);
        }

        // Send event to update the work Items related to the LP Override event
        WorkItemUpdateRequestEventDTO updateWorkItemsEventDto = overrideLpPolicyDTO.toWorkItemUpdateRequestDto(userRequestInfo);
        if(CollectionUtils.isNotEmpty(updateWorkItemsEventDto.getWorkItems())){
            publishEventService.publishEvent(overrideLpPolicyDTO.toWorkItemUpdateRequestDto(userRequestInfo));
        }
    }

    boolean policyOverrideIssuanceDate(ProofOfCoverage policy, PolicyDTO policyDTO){
        Date newIssuanceDate = policyDTO.getIssuanceDate() != null ? DATE_FORMATTER.parse(policyDTO.getIssuanceDate()): null;
        boolean hasChanged = false;
        if(policy.getIssuanceDate() != null) {
            if (newIssuanceDate != null && policy.getIssuanceDate().compareTo(newIssuanceDate) == 0) {
                return false;
            }
            policy.setIssuanceDate(newIssuanceDate);
            hasChanged = true;
        }else{
            if (newIssuanceDate != null) {
                policy.setIssuanceDate(newIssuanceDate);
                hasChanged = true;
            }
        }
        return hasChanged;
    }

    @Override
    @Transactional
    public void deletePolicy(Long policyId, UserRequestInfo userRequestInfo) {
        ProofOfCoverage policy = getProofOfCoverage(policyId);
        PolicyStatus policyStatus = PolicyStatus.valueOf(policy.getPolicyStatus());
        if (policyStatus != PolicyStatus.PENDING_VERIFICATION) {
            throw new CtracException("Cannot delete policy that has been verified");
        }
        publishPolicyEvent(policy, CtracEventType.DELETED, userRequestInfo);
        proofOfCoverageRepository.delete(policy);
    }

    @Override
    public ProofOfCoverage getExistingProofOfCoverage(Long policyId, PolicyDTO policyDTO) {
        if (policyId == null || !policyId.equals(policyDTO.getPolicyId())) {
            throw new CtracException("policyId does not match policy");
        }
        return getProofOfCoverage(policyId);
    }

    private ProofOfCoverage getProofOfCoverage(Long policyId) {
        Optional<ProofOfCoverage> policy = proofOfCoverageRepository.findById(policyId);
        if (!policy.isPresent()) {
            logger.debug("Policy not found for policyId={}", policyId);
            throw new PolicyNotFoundException("Policy not found for policyId=" + policyId);
        }
        return policy.get();
    }

    private void reviewPolicyConclusions(PolicyDTO policyDTO) {
        //TODO: run the conclusions rules and save outcome in BIRRuleConclusion table
        // With Audit event when exception state changed
    }

    private void updatePolicyStatus(ProofOfCoverage policy, PolicyDTO policyDTO, boolean onVerification){
        PolicyStatus newPolicyStatus = PolicyStatus.PENDING_VERIFICATION;
        boolean isBorrowerPolicy = PolicyType.valueOf(policy.getPolicyType()).isBorrowerPolicy();
        if(onVerification){
            if (policy.getCancellationEffectiveDate() != null) {
                newPolicyStatus = PolicyStatus.CANCELLED;
            } else if (isBorrowerPolicy){
                newPolicyStatus = policyDTO.hasRejectedConclusion() ? PolicyStatus.REJECTED : PolicyStatus.ACCEPTED;
            }
            else if (!policyDTO.hasLetterCycle()) {
                newPolicyStatus = PolicyStatus.PAID;
            }
            else if (LetterCycleDTO.FIRST_WORKFLOW_STEP.equals(policyDTO.getLetterCycle().getWorkflowStep())) {
                newPolicyStatus = PolicyStatus.PENDING_LETTER_CYCLE;
            }
            else {
                newPolicyStatus = PolicyStatus.LETTER_CYCLE;
            }
        }
        if(isBorrowerPolicy) {
            for(BirCollateralDetails birCollateralDetails:policy.getBirProofOfCovDetails().getBirCollateralDetails()){
                birCollateralDetails.setPolicyStatus(newPolicyStatus.name());
            }
        }
        policy.setPolicyStatus(newPolicyStatus.name());
    }

    private void updateMigratedFlagForLP(ProofOfCoverage proofOfCoverage){
        if (PolicyType.valueOf(proofOfCoverage.getPolicyType()).isLenderPlaced()) {
            proofOfCoverage.setMigrated(true);
        }
    }

    private void updateReasonForVerification(ProofOfCoverage proofOfCoverage){
        String reasonForVerification = getReasonForVerification(
                proofOfCoverage.getPolicyType(), proofOfCoverage.getPolicyStatus(), proofOfCoverage.getCancellationEffectiveDate());
        if (reasonForVerification != null) {
            proofOfCoverage.setReasonForVerification(reasonForVerification);
        }
    }

    void updateReasonForVerification(PolicyDTO policyDTO){
        String reasonForVerification = getReasonForVerification(
                policyDTO.getPolicyType(), policyDTO.getPolicyStatus(), DATE_FORMATTER.parse(policyDTO.getCancellationDate()));
        if (reasonForVerification != null) {
            policyDTO.setReasonForVerification(reasonForVerification);
        }
    }

    private String getReasonForVerification(String policyType_, String policyStatus_, Date cancellationEffectiveDate) {
        PolicyType policyType = EnumUtils.getEnum(PolicyType.class, policyType_);
        if (policyType != null && policyType.isBorrowerPolicy() &&
                PolicyStatus.PENDING_VERIFICATION == EnumUtils.getEnum(PolicyStatus.class, policyStatus_)) {
            return cancellationEffectiveDate != null ?
                    PolicyReasonForVerification.CANCELATION_DATE_ENTERED.name() :
                    PolicyReasonForVerification.OTHER.name();
        }
        return null;
    }

    @Override
    @Transactional
    public PolicyDTO verifyPolicy(PolicyDTO policyDTO, UserRequestInfo userRequestInfo) {
        updateReasonForVerification(policyDTO);
        updateRuleConclusionMap(policyDTO);
        reviewPolicyConclusions(policyDTO);
        ProofOfCoverage policy = getProofOfCoverage(policyDTO.getPolicyId());
        boolean hasChanged = policy.map(policyDTO);
        saveVerifiedProofOfCoverage(policy, policyDTO, userRequestInfo);
        startLetterCycle(policyDTO.getLetterCycle());
        if (hasChanged) {
            //Policy data changed - publish edit event
            publishPolicyEvent(policy, CtracEventType.EDITED, userRequestInfo);
        }
        //Policy data Verified - publish verified event
        publishPolicyEvent(policy, CtracEventType.VERIFIED, userRequestInfo);

        if (borrowerPolicyVerificationService.notMigratedAllVerifiedAndAllPledged(policy)) {
            if (policy.getPolicyStatus_() == PolicyStatus.ACCEPTED) {
                //TODO: check if anything else may delay triggering c3
                publishC3PolicyEvent(policy);
            } else if (policy.getPolicyStatus_() == PolicyStatus.REJECTED) {
                publishBIRWorkflowRequestEvent(policy);
            }
        }
        deletePolicyDocuments(policy);
        return policy.toPolicyDTO();
    }

    @Transactional
    ProofOfCoverage saveVerifiedProofOfCoverage(ProofOfCoverage policy, PolicyDTO policyDTO, UserRequestInfo userRequestInfo) {
        updatePolicyStatus(policy, policyDTO, true);
        setPolicyLpAction(policy);
        policy.applyDeepLevelAuditInfo(userRequestInfo);
        policy = proofOfCoverageRepository.save(policy);
        policySectionStatusService.transitionOnVerify(policy, InsuranceType.valueOf(policy.getInsuranceType()), userRequestInfo);
        return policy;
    }

    @Override
    public Map<String, BIRRuleConclusionDTO> getPolicyConclusions(PolicyDTO policyDTO) {
        return borrowerInsuranceReviewService.getBorrowerPolicyConclusions(policyDTO);
    }

    void setPolicyLpAction(ProofOfCoverage policy) {
        if (PolicyType.valueOf(policy.getPolicyType()).isBorrowerPolicy()) {
            String lpAction;
            if (policy.getCancellationEffectiveDate() == null) {
                lpAction = LPAction.NEW_BP.name();
                BirProofOfCovDetails borrowerInsuranceReviewDetails = birProofOfCovDetailsRepository.findByProofOfCoverageRid(policy.getRid());
                if (borrowerInsuranceReviewDetails != null) {
                    borrowerInsuranceReviewDetails.getBirCollateralDetails().forEach(birCollateralDetails -> {
                        birCollateralDetails.setLpAction(LPAction.NEW_BP.name());
                    });
                }
            } else {
                lpAction = LPAction.CANCEL_BP.name();
            }

            policy.setLpAction(lpAction);
        }
    }

    void startLetterCycle(LetterCycleDTO letterCycleDTO) {
        if(letterCycleDTO != null && letterCycleDTO.getWorkflowStep() != null) {
            String json = new EventJsonBuilder()
                    .put("proofOfCoverageRid", letterCycleDTO.getProofOfCoverageRid())
                    .put("workflowStep", letterCycleDTO.getWorkflowStep())
                    .put("firstLetterDate", letterCycleDTO.getFirstLetterDate())
                    .put("secondLetterDate", letterCycleDTO.getSecondLetterDate())
                    .put("borrowerPolicyRid", letterCycleDTO.getBorrowerPolicyRid())
                    .put("marketEmailNeeded", letterCycleDTO.isMarketEmailNeeded())
                    .build();
            ctrac2ApiService.startWorkflow("letterCycle", json);
        }
    }

    private List<CollateralDocumentSummaryDTO> saveUploadedPolicyDocuments(ProofOfCoverage policy, List<FileUploadAttachmentDTO> fileUploadAttachmentDTOList){
        List<CollateralDocumentSummaryDTO> list = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(fileUploadAttachmentDTOList)) {
            list.addAll(this.collateralDocumentService
                    .saveDocuments(fileUploadAttachmentDTOList, policy,
                            DocumentMetaDataBuilder.aDocumentMetaData()
                                    .withDocIdentifier(CONST_GENERAL_POLICY_DOCUMENT_IDENTIFIER)
                                    .buildDto())
            );
        }
        return list;
    }

    private void deletePolicyDocuments(ProofOfCoverage policy){
        this.collateralDocumentService.deleteAllDocuments(policy.getPolicyDocuments());
    }

    void publishPolicyEvent(ProofOfCoverage proofOfCoverage, CtracEventType collateralEventType, UserRequestInfo userRequestInfo){
        proofOfCoverage.getLinkedCollateralIds().forEach(colRid ->
            publishEventService.publishEvent(new PolicyPublishEventRequest(proofOfCoverage, InsuranceType.GENERAL, colRid)
                    .forCtracEventType(collateralEventType).withUserRequestInfo(userRequestInfo)));
    }

    void publishC3PolicyEvent(ProofOfCoverage proofOfCoverage) {
        CtracEventType ctracEventType = proofOfCoverage.getCancellationEffectiveDate() != null ?
                CtracEventType.BORROWER_POLICY_CANCELLED : CtracEventType.BORROWER_POLICY_ACCEPTED;
        proofOfCoverage.getLinkedCollateralIds().forEach(colRid -> publishEventService.publishEvent(
                new C3RequestEventDTO(colRid, ctracEventType.getDisplayValue())
                        .forInsuranceType(proofOfCoverage.getInsuranceType()))
        );
    }

    private void publishBIRWorkflowRequestEvent(ProofOfCoverage policy) {
        publishEventService.publishEvent(
                new BIRWorkflowRequestEventDTO(policy.getRid(), null, CtracAppConstants.SYSTEM_USER));
    }

    private void updateRuleConclusionMap(PolicyDTO policyDTO) {
        if (EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()).isBorrowerPolicy()) {
            policyDTO.getRuleConclusions().putAll(getPolicyConclusions(policyDTO));
        }
    }
}