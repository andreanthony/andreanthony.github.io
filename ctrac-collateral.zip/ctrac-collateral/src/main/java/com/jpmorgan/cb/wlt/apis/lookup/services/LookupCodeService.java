package com.jpmorgan.cb.wlt.apis.lookup.services;

import com.jpmorgan.cb.wlt.apis.lookup.dtos.LookupCodeDTO;

import java.util.List;

public interface LookupCodeService {
    List<LookupCodeDTO> getByCodeset(String codeset);

    LookupCodeDTO getByCodeSetAndCode(String codeSet, String code);

    List<LookupCodeDTO> getChildrenLookupCodes(String codeSet, String code);

}
