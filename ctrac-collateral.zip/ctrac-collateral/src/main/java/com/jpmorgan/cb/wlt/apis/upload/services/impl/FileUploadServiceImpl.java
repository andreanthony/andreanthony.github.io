package com.jpmorgan.cb.wlt.apis.upload.services.impl;

import com.jpmorgan.cb.wlt.apis.lookup.dtos.LookupCodeDTO;
import com.jpmorgan.cb.wlt.apis.lookup.services.LookupCodeService;
import com.jpmorgan.cb.wlt.apis.upload.dao.FileUploadAttachment;
import com.jpmorgan.cb.wlt.apis.upload.dao.repository.FileUploadAttachmentRepository;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileAttachmentDeletedResponse;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentSummaryDTO;
import com.jpmorgan.cb.wlt.apis.upload.services.FileUploadService;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class FileUploadServiceImpl implements FileUploadService{

    private static final Logger logger = LoggerFactory.getLogger(FileUploadServiceImpl.class);

    private FileUploadAttachmentRepository fileUploadAttachmentRepository;
    private LookupCodeService lookupCodeService;

    @Autowired
    public FileUploadServiceImpl(FileUploadAttachmentRepository fileUploadAttachmentRepository,
                                 LookupCodeService lookupCodeService) {
        assert(fileUploadAttachmentRepository != null);
        this.fileUploadAttachmentRepository =fileUploadAttachmentRepository;
        assert(lookupCodeService != null);
        this.lookupCodeService =lookupCodeService;
    }

    @Override
    public List<FileUploadAttachmentSummaryDTO> getAttachmentsSummary(String bucketId) {
        List<FileUploadAttachmentDTO> attachments = getAttachments(bucketId);
        logger.debug("Returning attachment summary for bucket " + bucketId);
        return extractAttachmentSummary(attachments);
    }

    @Override
    public List<FileUploadAttachmentDTO> getAttachments(String bucketId) {
        logger.debug("Fetching attachments for bucket " + bucketId);
        List<FileUploadAttachment> attachmentList = fileUploadAttachmentRepository.findByBucketName(bucketId);
        return mapAttachmentToDtoList(attachmentList);
    }

    private List<FileUploadAttachmentSummaryDTO> extractAttachmentSummary(List<FileUploadAttachmentDTO> attachmentListDTO){
        List<FileUploadAttachmentSummaryDTO> attachmentSummaryListDTO = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(attachmentListDTO)) {
            for (FileUploadAttachmentDTO fileUploadAttachmentDTO : attachmentListDTO) {
                attachmentSummaryListDTO.add(fileUploadAttachmentDTO.getSummary());
            }
        }
        return attachmentSummaryListDTO;
    }

    private List<FileUploadAttachmentDTO> mapAttachmentToDtoList(List<FileUploadAttachment> attachmentList){
        List<FileUploadAttachmentDTO> attachmentListDTO = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(attachmentList)) {
            for (FileUploadAttachment fileUploadAttachment : attachmentList) {
                attachmentListDTO.add(fileUploadAttachment.toFileUploadAttachmentDTO());
            }
        }
        return attachmentListDTO;
    }

    @Override
    @Transactional
    public List<FileUploadAttachmentSummaryDTO> storeAttachments(String bucketId,String category, MultipartFile[] files) {
        try{
            logger.debug("Storing attachments for bucket " + bucketId);
            if(files != null && files.length > 0){
                validateBucketCategory(category);
                List<FileUploadAttachment> attachmentList = new ArrayList<>();
                for(MultipartFile multipartFile: files){
                    FileUploadAttachment fileUploadAttachment = new FileUploadAttachment();
                    fileUploadAttachment.setBucketName(bucketId);
                    fileUploadAttachment.setFileName(multipartFile.getOriginalFilename());
                    fileUploadAttachment.setFileContent(multipartFile.getBytes());
                    attachmentList.add(fileUploadAttachment);
                }
                //Remove any existing items in bucket
                this.deleteAllAttachments(bucketId);
                List<FileUploadAttachment> attachmentListSaved = fileUploadAttachmentRepository.saveAll(attachmentList);
                return extractAttachmentSummary(mapAttachmentToDtoList(attachmentListSaved));
            }else{
                throw new CtracException("Failure - No files were uploaded in the request for bucket " + bucketId);
            }
        }catch(IOException ex){
            logger.error("Failure - Reading the uploaded files on bucket {}", bucketId, ex);
            throw new CtracException("Failure - Reading the uploaded files on bucket " + bucketId);
        }
    }

    private void validateBucketCategory(String bucketCategory){
        LookupCodeDTO lookupCode = this.lookupCodeService
                .getByCodeSetAndCode(CONST_FILE_UPLOAD_BUCKET_CATEGORY_CODESET,bucketCategory);
        if(lookupCode == null){
            throw new CtracException("The bucket category specified ("+ bucketCategory+") is invalid. " +
                    "Look at available codes in set ("+CONST_FILE_UPLOAD_BUCKET_CATEGORY_CODESET+")");
        }
    }

    @Override
    @Transactional
    public FileAttachmentDeletedResponse deleteAllAttachments(String bucketId) {
        try{
            logger.debug("Deleting all attachments for bucket " + bucketId);
            Integer attachmentsCount = fileUploadAttachmentRepository.countByBucketName(bucketId);
            if(attachmentsCount > 0) {
                fileUploadAttachmentRepository.deleteByBucketName(bucketId);
                fileUploadAttachmentRepository.flush();
                logger.debug(attachmentsCount + " Items deleted from bucket " + bucketId);
            }
            return new FileAttachmentDeletedResponse(attachmentsCount);
        }catch(Exception ex){
            throw new CtracException("Failure - Deleting all attachments for bucket " + bucketId);
        }
    }
}
