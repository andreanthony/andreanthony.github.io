package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyIssuance;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.enums.LenderPlaceReason;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class LenderPlaceLapseRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(LenderPlaceLapseRule.class);
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        // adjust expiration dates based on stacking
        List<C3PolicyIssuance> policiesToIssue = c3ResponseDTO.getPoliciesToIssue()
                .stream()
                .distinct()
                .sorted(new EffectiveDateDescendingComparator())
                .collect(Collectors.toList());

        policiesToIssue
                .removeIf(laterPolicy ->
                    CollectionUtils.isNotEmpty(getOverlappingPolicies(laterPolicy, policiesToIssue, true)));

        policiesToIssue
               .stream()
               .sorted(new EffectiveDateComparator())
               .forEach(policy -> {
                    processGapAndLapse(policy, policiesToIssue, c3RequestDTO.getMatchingBorrowerPolicies(policy));
                    processLapseForHoldStartDate(policy, c3RequestDTO.getHoldStartDate(policy.getCoverageType(), policy.getInsurableAssetId()));
               });
        policiesToIssue.removeIf(policy -> policy.getEffectiveDate().equals(policy.getExpirationDate()));

        logger.debug("LenderPlaceLapseRule - policies to be issued for Collateral and Policy ID {} ",
                policiesToIssue.stream().map(C3PolicyIssuance::toString).collect(Collectors.joining(",")));
        c3ResponseDTO.setPoliciesToIssue(policiesToIssue);
    }

    private void processGapAndLapse(C3PolicyIssuance policy, List<C3PolicyIssuance> policiesToIssue, List<C3Policy> matchingBorrowerPolicies) {
        // find a later borrower policy possibly causing a lapse
        C3Policy borrowerPolicyLeadingToLapse = getBorrowerPolicyLeadingToLapse(policy, matchingBorrowerPolicies);
        if (borrowerPolicyLeadingToLapse != null) {
            convertToLapsePolicy(policy, borrowerPolicyLeadingToLapse.getEffectiveDate(), borrowerPolicyLeadingToLapse);
        } else {
            // find a later C3PolicyIssuance possibly causing a lapse
            C3PolicyIssuance nextPolicy = getNextOverlappingPolicy(policy, policiesToIssue);
            if (nextPolicy != null) {
                convertToLapsePolicy(policy, nextPolicy.getEffectiveDate(), null);
            }
        }
    }

    void processLapseForHoldStartDate(C3PolicyIssuance policy, Date holdStartDate) {
        if (holdStartDate != null && isPolicyIssuanceEffectiveOn(policy, holdStartDate)) {
            convertToLapsePolicy(policy, DATE_FORMATTER.print(holdStartDate), null);
        }
    }

    C3Policy getBorrowerPolicyLeadingToLapse(C3PolicyIssuance policyToIssue, List<C3Policy> matchingBorrowerPolicies) {
        return matchingBorrowerPolicies
                .stream()
                .filter(c3Policy -> c3Policy.getPolicyStatus_().isActive(false)
                        && c3Policy.getEffectiveDate_().before(policyToIssue.getExpirationDate_())
                        && c3Policy.getEffectiveDate_().after(policyToIssue.getEffectiveDate_()))
                .min(new EffectiveDatePolicyComparator())
                .orElse(null);
    }

    private C3PolicyIssuance getNextOverlappingPolicy(C3PolicyIssuance policy, List<C3PolicyIssuance> policiesToIssue) {
        List<C3PolicyIssuance> matchingPolicies = getMatchingPolicies(policy, policiesToIssue, false)
                .stream()
                .filter(matchingPolicy -> isPolicyIssuanceEffectiveOn(policy, matchingPolicy.getEffectiveDate_()))
                .collect(Collectors.toList());
        if (!matchingPolicies.isEmpty()) {
            return Collections.min(matchingPolicies, new EffectiveDateComparator());
        }
        return null;
    }

    private boolean isPolicyIssuanceEffectiveOn(C3PolicyIssuance policy, Date date) {
        return !policy.getEffectiveDate_().after(date) &&
                policy.getExpirationDate_().after(date);
    }

    private List<C3PolicyIssuance> getMatchingPolicies(
            C3PolicyIssuance laterPolicy, List<C3PolicyIssuance> policiesToIssue, boolean sameAmount) {
        return policiesToIssue
                .stream()
                .filter(matchingPolicy -> matchingPolicy != laterPolicy
                        && matchingPolicy.hasMatchingCoverage(laterPolicy.getCoverageType(), laterPolicy.getInsurableAssetId())
                        && isAmountCompare(sameAmount, matchingPolicy.getCoverageAmount(), laterPolicy.getCoverageAmount()) )
                .collect(Collectors.toList());
    }

    void convertToLapsePolicy(C3PolicyIssuance lpPolicy, String expirationDate, C3Policy lapseBorrowerPolicy) {
        lpPolicy.setExpirationDate(expirationDate);
        // so renewal workflow should not start
        lpPolicy.setIndRenewal("Y");
        PolicyType policyType = lpPolicy.getPolicyType();
        // excess policies are not converted to lapse
        if (PolicyType.LP_EXCESS != policyType) {
            PolicyType lpGapType = policyType.getLpGapType();
            //gap policies are not converted to lapse
            if (lpGapType != policyType) {
                lpPolicy.setPolicyType(lpGapType);
                if (lapseBorrowerPolicy != null) {
                    lpPolicy.setLenderPlaceReason(LenderPlaceReason.getLapseReasonForInsuranceType(policyType.getInsuranceType()));
                    lpPolicy.setGapBorrowerPolicyId(lapseBorrowerPolicy.getPolicyId());
                }
                else {
                    lpPolicy.setLenderPlaceReason(LenderPlaceReason.getGapReasonForInsuranceType(policyType.getInsuranceType()));
                }
            }
        }
    }

    private List<C3PolicyIssuance> getOverlappingPolicies(
            C3PolicyIssuance laterPolicy, List<C3PolicyIssuance> policiesToIssue, boolean sameAmount) {
        return policiesToIssue
            .stream()
            .filter(overlappingPolicy -> overlappingPolicy != laterPolicy
                && overlappingPolicy.hasMatchingCoverage(laterPolicy.getCoverageType(), laterPolicy.getInsurableAssetId())
                && isPolicyIssuanceEffectiveOn(overlappingPolicy, laterPolicy.getEffectiveDate_())
                && isAmountCompare(sameAmount, overlappingPolicy.getCoverageAmount(), laterPolicy.getCoverageAmount()) )
            .collect(Collectors.toList());
    }

    private boolean isAmountCompare(boolean sameAmount, BigDecimal amount, BigDecimal amount1) {
        return sameAmount == (amount.compareTo(amount1) == 0);
    }

    private static class EffectiveDatePolicyComparator implements Comparator<C3Policy> {
        @Override
        public int compare(C3Policy o1, C3Policy o2) {
            return o1.getEffectiveDate_().compareTo(o2.getEffectiveDate_());
        }
    }

    private static class EffectiveDateComparator implements Comparator<C3PolicyIssuance> {
        @Override
        public int compare(C3PolicyIssuance o1, C3PolicyIssuance o2) {
            return o1.getEffectiveDate_().compareTo(o2.getEffectiveDate_());
        }
    }

    private static class EffectiveDateDescendingComparator implements Comparator<C3PolicyIssuance> {
        @Override
        public int compare(C3PolicyIssuance o1, C3PolicyIssuance o2) {
            return o2.getEffectiveDate_().compareTo(o1.getEffectiveDate_());
        }
    }
}
