package com.jpmorgan.cb.wlt.apis.batch;

public class BatchCtrlDTO {

    private boolean batchRunning;

    public boolean isBatchRunning() {
        return batchRunning;
    }

    public void setBatchRunning(boolean batchRunning) {
        this.batchRunning = batchRunning;
    }


}
