package com.jpmorgan.cb.wlt.apis.policy.dao.populators;

import com.jpmorgan.cb.wlt.apis.policy.dao.BirProofOfCovDetails;
import com.jpmorgan.cb.wlt.dao.DaoAuditDataPopulator;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import org.apache.commons.collections4.CollectionUtils;

public class BirProofOfCovDetailsAuditPopulator implements DaoAuditDataPopulator<BirProofOfCovDetails,UserRequestInfo> {

    @Override
    public void populateAuditInfo(BirProofOfCovDetails source, UserRequestInfo userRequestInfo) {
        source.setAuditInfo(userRequestInfo);

        if(CollectionUtils.isNotEmpty(source.getBirCollateralDetails())){
            BirCollateralDetailsAuditPopulator birColDetAuditPop = new BirCollateralDetailsAuditPopulator();
            source.getBirCollateralDetails().forEach(birCollateralDetails ->
                    birColDetAuditPop.populateAuditInfo(birCollateralDetails, userRequestInfo)
            );
        }

    }
}
