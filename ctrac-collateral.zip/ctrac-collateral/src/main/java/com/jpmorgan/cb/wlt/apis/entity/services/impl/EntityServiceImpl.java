package com.jpmorgan.cb.wlt.apis.entity.services.impl;


import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;
import com.jpmorgan.cb.wlt.apis.entity.dao.Customer;
import com.jpmorgan.cb.wlt.apis.entity.dao.CustomerRepository;
import com.jpmorgan.cb.wlt.apis.entity.services.EntityService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Type;
import java.util.List;


@Service
@Transactional(readOnly = true)
public class EntityServiceImpl implements EntityService {

    private CustomerRepository customerRepository;
    private ModelMapper modelMapper;

    @Autowired
    public EntityServiceImpl(CustomerRepository customerRepository, ModelMapper modelMapper ) {
        assert(customerRepository != null);
        this.customerRepository = customerRepository;
        assert(modelMapper != null);
        this.modelMapper = modelMapper;

    }

    @Override
    public List<EntityDTO> getEntities(List<Long> entityIds) {
        List<Customer> customers = customerRepository.findAllById(entityIds);
        Type listType = new TypeToken<List<EntityDTO>>() {}.getType();
        return modelMapper.map(customers, listType);
    }


}
