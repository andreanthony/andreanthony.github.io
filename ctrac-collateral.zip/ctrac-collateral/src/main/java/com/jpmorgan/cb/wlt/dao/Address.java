package com.jpmorgan.cb.wlt.dao;

import com.jpmorgan.cb.wlt.dtos.AddressDTO;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "TLCP_ADDRESS")
public class Address extends AuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "addressSeqGenerator")
    @TableGenerator(name = "addressSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_ADDRESS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Column(name = "RID")
    private Long rid;

    @Column(name = "CITY")
    private String city;

    @Column(name = "ZIP_CODE")
    private String zipCode;

    @Column(name = "COUNTY")
    private String county;

    @Column(name = "VERIFIED_DATE")
    private Date verifiedDate;

    @Column(name = "ADDRESS")
    private String streetAddress;

    @Column(name = "STATE_ABBR")
    private String state;

    @Column(name = "UNIT_BLNG")
    private String unitOrBuilding;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public Date getVerifiedDate() {
        return verifiedDate;
    }

    public void setVerifiedDate(Date verifiedDate) {
        this.verifiedDate = verifiedDate;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getUnitOrBuilding() {
        return unitOrBuilding;
    }

    public void setUnitOrBuilding(String unitOrBuilding) {
        this.unitOrBuilding = unitOrBuilding;
    }

    public AddressDTO toDTO() {
        AddressDTO addressDTO = new AddressDTO();
        addressDTO.setStreetAddress(streetAddress);
        addressDTO.setUnitOrBuilding(unitOrBuilding);
        addressDTO.setCity(city);
        addressDTO.setCounty(county);
        addressDTO.setState(state);
        addressDTO.setZipCode(zipCode);
        return addressDTO;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        Address address = (Address) o;

        return new EqualsBuilder()
                .append(rid, address.rid)
                .append(city, address.city)
                .append(zipCode, address.zipCode)
                .append(county, address.county)
                .append(verifiedDate, address.verifiedDate)
                .append(streetAddress, address.streetAddress)
                .append(state, address.state)
                .append(unitOrBuilding, address.unitOrBuilding)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(city)
                .append(zipCode)
                .append(county)
                .append(verifiedDate)
                .append(streetAddress)
                .append(state)
                .append(unitOrBuilding)
                .toHashCode();
    }

    public boolean map(AddressDTO addressDTO) {
        if (this.toDTO().equals(addressDTO)) {
            return false;
        }
        this.streetAddress = addressDTO.getStreetAddress();
        this.unitOrBuilding = addressDTO.getUnitOrBuilding();
        this.city = addressDTO.getCity();
        this.county = addressDTO.getCounty();
        this.state = addressDTO.getState();
        this.zipCode = addressDTO.getZipCode();
        return true;
    }
}
