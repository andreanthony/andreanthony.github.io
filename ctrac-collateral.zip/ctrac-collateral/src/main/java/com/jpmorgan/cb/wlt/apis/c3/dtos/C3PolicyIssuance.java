package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

public class C3PolicyIssuance implements Serializable {
    private static final long serialVersionUID = -1;
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    private PolicyType policyType;
    private PolicyStatus policyStatus = PolicyStatus.PENDING_LETTER_CYCLE;
    private String insuredName;
    private Long collateralRid;
    private Long insurableAssetId;
    private InsurableAssetType insurableAssetType;
    private String effectiveDate;
    private String expirationDate;
    private String coverageType;
    private BigDecimal coverageAmount;
    private String balanceType;
    private Long parentPolicyId;
    private LPAction lpAction;
    private String floodZone;
    private LenderPlaceReason lenderPlaceReason;
    private Long gapBorrowerPolicyId;
    private String indRenewal;

    public PolicyType getPolicyType() {
        return policyType;
    }

    public void setPolicyType(PolicyType policyType) {
        this.policyType = policyType;
    }

    public PolicyStatus getPolicyStatus() {
        return policyStatus;
    }

    public void setPolicyStatus(PolicyStatus policyStatus) {
        this.policyStatus = policyStatus;
    }

    public String getInsuredName() {
        return insuredName;
    }

    public void setInsuredName(String insuredName) {
        this.insuredName = insuredName;
    }

    public Long getCollateralRid() { return collateralRid; }

    public void setCollateralRid(Long collateralRid) { this.collateralRid = collateralRid; }

    public Long getInsurableAssetId() {
        return insurableAssetId;
    }

    public void setInsurableAssetId(Long insurableAssetId) {
        this.insurableAssetId = insurableAssetId;
    }

    public InsurableAssetType getInsurableAssetType() {
        return insurableAssetType;
    }

    public void setInsurableAssetType(InsurableAssetType insurableAssetType) {
        this.insurableAssetType = insurableAssetType;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    @ApiModelProperty(hidden = true)
    public Date getEffectiveDate_() {
        return DATE_FORMATTER.parse(effectiveDate);
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    @ApiModelProperty(hidden = true)
    public Date getExpirationDate_() {
        return DATE_FORMATTER.parse(expirationDate);
    }
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = DATE_FORMATTER.print(adjustToEffectiveDate(expirationDate));
    }

    private Date adjustToEffectiveDate(String endDate) {
        return getNullOrMax(DATE_FORMATTER.parse(endDate), this.getEffectiveDate_());
    }

    private Date getNullOrMax(Date date1, Date date2) {
        return date1 == null? null :
                date2 == null? date1 :
                        date1.after(date2)? date1 : date2;
    }

    @JsonIgnore
    public FloodCoverageType getCoverageType_() {
        return FloodCoverageType.valueOf(coverageType);
    }

    public void setCoverageType_(FloodCoverageType coverageType) {
        this.coverageType = coverageType.name();
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(BigDecimal coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public String getBalanceType() {
        return balanceType;
    }

    public void setBalanceType(String balanceType) {
        this.balanceType = balanceType;
    }

    public Long getParentPolicyId() {
        return parentPolicyId;
    }

    public void setParentPolicyId(Long parentPolicyId) {
        this.parentPolicyId = parentPolicyId;
    }


    public boolean isProvidingCoverage(String coverageType, Long insurableAssetId, Date effectiveOn) {
        return Objects.equals(insurableAssetId, this.insurableAssetId) &&
                isMatchingCoverage(coverageType, this.coverageType) &&
                Objects.equals(effectiveOn, this.getEffectiveDate_());
    }

    public boolean hasMatchingCoverage(String coverageType, Long insurableAssetId) {
        return Objects.equals(insurableAssetId, this.insurableAssetId) && isMatchingCoverage(coverageType, this.coverageType);
    }

    private boolean isMatchingCoverage(String coverageType, String coverageType1) {
        return Objects.equals(coverageType, coverageType1) || isMatchingFloodCoverage(coverageType, coverageType1);
    }

    private boolean isMatchingFloodCoverage(String coverageType, String coverageType1) {
        FloodCoverageType floodCoverageType = FloodCoverageType.forName(coverageType);
        return  floodCoverageType != null && floodCoverageType.isMatching(FloodCoverageType.forName(coverageType1));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        C3PolicyIssuance that = (C3PolicyIssuance) o;
        return policyType == that.policyType &&
                policyStatus == that.policyStatus &&
                Objects.equals(insuredName, that.insuredName) &&
                Objects.equals(insurableAssetId, that.insurableAssetId) &&
                insurableAssetType == that.insurableAssetType &&
                Objects.equals(effectiveDate, that.effectiveDate) &&
                Objects.equals(expirationDate, that.expirationDate) &&
                Objects.equals(coverageType, that.coverageType) &&
                Objects.equals(coverageAmount, that.coverageAmount) &&
                Objects.equals(balanceType, that.balanceType) &&
                Objects.equals(collateralRid, that.collateralRid) &&
                Objects.equals(parentPolicyId, that.parentPolicyId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(policyType, insurableAssetId, insurableAssetType, effectiveDate,
                expirationDate, coverageType, coverageAmount, balanceType);
    }

    public void setLpAction(LPAction lpAction) {
        this.lpAction = lpAction;
    }

    public LPAction getLpAction() {
        return lpAction;
    }

    public void setFloodZone(String floodZone) {
        this.floodZone = floodZone;
    }

    public String getFloodZone() {
        return floodZone;
    }

    public void setLenderPlaceReason(LenderPlaceReason lenderPlaceReason) {
        this.lenderPlaceReason = lenderPlaceReason;
    }

    public LenderPlaceReason getLenderPlaceReason() {
        return lenderPlaceReason;
    }

    public void setGapBorrowerPolicyId(Long gapBorrowerPolicyId) {
        this.gapBorrowerPolicyId = gapBorrowerPolicyId;
    }

    public Long getGapBorrowerPolicyId() {
        return gapBorrowerPolicyId;
    }

    public void setIndRenewal(String indRenewal) {
        this.indRenewal = indRenewal;
    }

    public String getIndRenewal() {
        return indRenewal;
    }

    @Override
    public String toString() {
       return getFormatedStringValue(getCollateralRid()) + " " + getFormatedStringValue(getParentPolicyId())  ;

    }

    private String getFormatedStringValue(Object obj){
        if(obj == null) return "";
        return obj.toString();
    }
}
