package com.jpmorgan.cb.wlt.apis.c3.dtos.builders;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3CalculatedCoverageDate;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsurableAssetType;

import java.util.Date;

public class C3CalculatedCoverageDateBuilder {
    private C3CalculatedCoverageDate c3CalculatedCoverageDate = new C3CalculatedCoverageDate();

    public C3CalculatedCoverageDateBuilder(String insuranceType, Date coverageDate) {
        c3CalculatedCoverageDate.setInsuranceType(insuranceType);
        c3CalculatedCoverageDate.setCoverageDate(coverageDate);
    }

    public C3CalculatedCoverageDateBuilder insurableAssetId(Long insurableAssetId) {
        c3CalculatedCoverageDate.setInsurableAssetId(insurableAssetId);
        return this;
    }

    public C3CalculatedCoverageDateBuilder coverageType_(FloodCoverageType coverageType) {
        c3CalculatedCoverageDate.setCoverageType(coverageType.name());
        return this;
    }

    public C3CalculatedCoverageDateBuilder coverageType(String coverageType) {
        c3CalculatedCoverageDate.setCoverageType(coverageType);
        return this;
    }

    public C3CalculatedCoverageDateBuilder insurableAssetType(InsurableAssetType insurableAssetType) {
        c3CalculatedCoverageDate.setInsurableAssetType(insurableAssetType);
        return this;
    }

    public C3CalculatedCoverageDateBuilder policyId(Long policyId) {
        c3CalculatedCoverageDate.setPolicyId(policyId);
        return this;
    }

    public C3CalculatedCoverageDate build() {
        return c3CalculatedCoverageDate;
    }
}
