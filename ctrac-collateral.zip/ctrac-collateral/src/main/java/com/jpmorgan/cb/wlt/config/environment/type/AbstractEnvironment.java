package com.jpmorgan.cb.wlt.config.environment.type;


import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerService;
import com.jpmorgan.cb.wlt.config.environment.EnvironmentType;

import javax.servlet.http.HttpServletRequest;

public abstract class AbstractEnvironment implements EnvironmentType{

    protected CtracAuthenticationManagerService ctracAuthenticationManagerService;

    public AbstractEnvironment(CtracAuthenticationManagerService ctracAuthenticationManagerService){
        this.ctracAuthenticationManagerService = ctracAuthenticationManagerService;
    }

    @Override
    public abstract String getUserNameFromRequest(HttpServletRequest request);
}
