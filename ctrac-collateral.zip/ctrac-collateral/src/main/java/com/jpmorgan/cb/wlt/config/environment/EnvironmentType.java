package com.jpmorgan.cb.wlt.config.environment;

import javax.servlet.http.HttpServletRequest;

public interface EnvironmentType {

    String getUserNameFromRequest(HttpServletRequest request);
}
