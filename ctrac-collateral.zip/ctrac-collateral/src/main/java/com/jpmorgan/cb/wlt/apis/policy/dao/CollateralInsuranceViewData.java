package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;

import javax.persistence.*;

@Entity
@Table(name="VLCP_COLLATERAL_INSURANCE")
@IdClass(value=CollateralInsuranceViewDataPK.class)
public class CollateralInsuranceViewData {
    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COLLATERAL_RID")
    private Collateral collateral;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PROOF_OF_COVERAGE_RID")
    private ProofOfCoverage proofOfCoverage;

    public Collateral getCollateral() {
        return collateral;
    }

    public void setCollateral(Collateral collateral) {
        this.collateral = collateral;
    }

    public ProofOfCoverage getProofOfCoverage() {
        return proofOfCoverage;
    }

    public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
        this.proofOfCoverage = proofOfCoverage;
    }
}
