package com.jpmorgan.cb.wlt.apis.lookup.dao;

import com.jpmorgan.cb.wlt.apis.lookup.dao.mappers.LookupCodeMapper;
import com.jpmorgan.cb.wlt.apis.lookup.dtos.LookupCodeDTO;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "TLCP_LOOKUP_CODES")
public class LookupCode implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "RID")
	private Long rid;

	@Column(name = "CODESET")
	private String codeSet;

	@Column(name = "CODE")
	private String code;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "ACTIVE")
	private String active;
	
	@Column(name = "SORT_ORDER")
	private Integer sortOrder;

	@Column(name = "CHILD_CODE_SET")
	private String childCodeSet;
	
	public Long getRid() {
		return rid;
	}

	public Integer getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getCodeSet() {
		return codeSet;
	}

	public void setCodeSet(String codeSet) {
		this.codeSet = codeSet;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public LookupCodeDTO toLookupCodeDTO() {
		return new LookupCodeMapper().toDTO(this);
	}

	public String getChildCodeSet() {
		return childCodeSet;
	}

	public void setChildCodeSet(String childCodeSet) {
		this.childCodeSet = childCodeSet;
	}

	public boolean map(LookupCodeDTO lookupCodeDTO) {
		return new LookupCodeMapper().map(lookupCodeDTO, this);
	}
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;

		if (o == null || getClass() != o.getClass()) return false;

		LookupCode that = (LookupCode) o;

		return new EqualsBuilder()
				.append(rid, that.rid)
				.append(codeSet, that.codeSet)
				.append(code, that.code)
				.append(description, that.description)
				.append(active, that.active)
				.append(sortOrder, that.sortOrder)
				.append(childCodeSet, that.childCodeSet)
				.isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 37)
				.append(rid)
				.append(codeSet)
				.append(code)
				.append(description)
				.append(active)
				.append(sortOrder)
				.append(childCodeSet)
				.toHashCode();
	}
}
