package com.jpmorgan.cb.wlt.apis.event;

import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;

public interface PublishEventRequest {

	CtracEventType getCtracEventType();

	String getDescription();

	String getIdentifier();

	Long getCollateralRid();

	@Deprecated
	String getLineOfBusiness();

	UserRequestInfo getUserRequestInfo();

	String getTaskName();
}
