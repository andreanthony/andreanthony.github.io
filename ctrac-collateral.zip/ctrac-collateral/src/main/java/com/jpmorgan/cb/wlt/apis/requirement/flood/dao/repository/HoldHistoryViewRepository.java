package com.jpmorgan.cb.wlt.apis.requirement.flood.dao.repository;

import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.HoldHistoryView;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HoldHistoryViewRepository extends JpaRepository<HoldHistoryView,Long> {

   List<HoldHistoryView> findByCollateralRid(Long collateralRid);
}
