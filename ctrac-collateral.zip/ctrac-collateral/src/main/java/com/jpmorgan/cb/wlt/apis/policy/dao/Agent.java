package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cb.wlt.dao.ContactDetails;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_AGENT")
public class Agent extends AuditableEntity {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "agentSeqGenerator")
    @TableGenerator(name = "agentSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_AGENT", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Id
    @Column(name = "RID")
    private Long rid;

    @OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    @JoinColumn(name = "CONTACT_DETAILS_ID")
    private ContactDetails contactDetails;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public ContactDetails getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(ContactDetails contactDetails) {
        this.contactDetails = contactDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        Agent agent = (Agent) o;

        return new EqualsBuilder()
                .append(rid, agent.rid)
                .append(contactDetails, agent.contactDetails)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(contactDetails)
                .toHashCode();
    }

}
