package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3PolicyCancellation;
import com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils.C3PolicyCancellationUtil;
import com.jpmorgan.cb.wlt.apis.c3.services.C3AdminService;
import com.jpmorgan.cb.wlt.apis.c3.services.C3RequestPopulationService;
import com.jpmorgan.cb.wlt.apis.c3.services.LenderPlacePolicyService;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3WorkflowRequestEventDTO;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class C3AdminServiceImpl implements C3AdminService {

    private C3RequestPopulationService c3RequestPopulationService;
    private LenderPlacePolicyService lenderPlacePolicyService;

    @Autowired
    public C3AdminServiceImpl(C3RequestPopulationService c3RequestPopulationService, LenderPlacePolicyService lenderPlacePolicyService) {
        assert(c3RequestPopulationService != null);
        this.c3RequestPopulationService = c3RequestPopulationService;
        assert(lenderPlacePolicyService != null);
        this.lenderPlacePolicyService = lenderPlacePolicyService;
    }

    @Override
    public C3PolicyCancellation cancel(C3WorkflowRequestEventDTO workflowRequestEventDTO) {
        List<Long> policyIds = workflowRequestEventDTO.getProofOfCoverageRids();
        if (policyIds.size() != 1) {
            throw new CtracException("C3AdminServiceImpl::cancel called with proofOfCoverageRids != 1");
        }
        C3Policy policyDTO = c3RequestPopulationService.populatePolicy(policyIds.get(0));
        C3PolicyCancellation policyCancellation = C3PolicyCancellationUtil.cancelLpPolicy(
                policyDTO, policyDTO.getCancellationEffectiveDate_(), null);
        ProofOfCoverage cancelledPolicy = lenderPlacePolicyService.cancel(policyCancellation);
        policyCancellation.setCancellationReason(
                EnumUtils.getEnum(CancellationReason.class, cancelledPolicy.getCancellationReason()));
        if (cancelledPolicy.getPolicyStatus_() == PolicyStatus.CANCELLED || cancelledPolicy.getPolicyStatus_() == PolicyStatus.DELETED) {
            lenderPlacePolicyService.publishC3WorkflowEvent(policyIds, cancelledPolicy.getProvidedCoverages().get(0).getCollateralId(), CtracEventType.C3_COMPLETED);
        }
        return policyCancellation;
    }
}
