package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.BIRInsuranceCompanyName;
import com.jpmorgan.cb.wlt.apis.policy.dtos.InsuranceCompanyDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

public class InsuranceCompanyMapper implements DaoMapper<BIRInsuranceCompanyName,InsuranceCompanyDTO> {

    @Override
    public InsuranceCompanyDTO toDTO(BIRInsuranceCompanyName model) {
        InsuranceCompanyDTO autoSuggestionDTO = new InsuranceCompanyDTO();
        autoSuggestionDTO.setRid(model.getRid());
        autoSuggestionDTO.setCompanyName(model.getApprovedInsCompanyName());
        return autoSuggestionDTO;
    }

    @Override
    public boolean map(InsuranceCompanyDTO dto, BIRInsuranceCompanyName model) {
        // Nothing to map for now
        return false;
    }
}
