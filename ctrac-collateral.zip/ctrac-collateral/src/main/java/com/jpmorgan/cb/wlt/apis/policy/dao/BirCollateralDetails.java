package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.apis.policy.dao.mappers.BirCollateralDetailsMapperFactory;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyCollateralDetailsDTO;
import com.jpmorgan.cb.wlt.dao.Address;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyStatus;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "TLCP_BIR_COLLATERAL_DETAILS")
public class BirCollateralDetails {

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "birCollateralDetailsSeqGenerator")
    @TableGenerator(name = "birCollateralDetailsSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_BIR_COLLATERAL_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BIR_PROOF_OF_COV_DETAILS_RID")
    private BirProofOfCovDetails birProofOfCovDetails;

    @Column(name = "COLLATERAL_RID")
    private Long collateralRid;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "POLICY_ADDRESS_RID")
    private Address policyAddress;

    @Column(name = "POLICY_FLOOD_ZONE")
    private String policyFloodZone;

    @Column(name = "GRANDFATHERED")
    private String grandfathered;

    @Column(name = "POLICY_STATUS")
    private String policyStatus;

    @Column(name = "LP_ACTION")
    private String lpAction;

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "birCollateralDetailsRid")
    private List<BIRInsurableAssetDetails> allBIRInsurableAssetDetails = new ArrayList<BIRInsurableAssetDetails>();

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public BirProofOfCovDetails getBirProofOfCovDetails() {
        return birProofOfCovDetails;
    }

    public void setBirProofOfCovDetails(BirProofOfCovDetails birProofOfCovDetails) {
        this.birProofOfCovDetails = birProofOfCovDetails;
    }

    public String getLpAction() { return lpAction; }

    public void setLpAction(String lpAction) { this.lpAction = lpAction; }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public Address getPolicyAddress() {
        return policyAddress;
    }

    public void setPolicyAddress(Address policyAddress) {
        this.policyAddress = policyAddress;
    }

    public String getPolicyFloodZone() {
        return policyFloodZone;
    }

    public void setPolicyFloodZone(String policyFloodZone) {
        this.policyFloodZone = policyFloodZone;
    }

    public String getGrandfathered() {
        return grandfathered;
    }

    public void setGrandfathered(String grandfathered) {
        this.grandfathered = grandfathered;
    }

    public String getPolicyStatus() {
        return policyStatus;
    }

    public PolicyStatus getPolicyStatus_() {
        return EnumUtils.getEnum(PolicyStatus.class, policyStatus);
    }

    public void setPolicyStatus(String policyStatus) {
        this.policyStatus = policyStatus;
    }

    public PolicyCollateralDetailsDTO mergeToCollateralCoverageDTO(PolicyCollateralDetailsDTO policyCollateralDetailsDTO, String insuranceType) {
        return BirCollateralDetailsMapperFactory.getBirCollateralDetailsMapper(insuranceType).mapOnToDTO(policyCollateralDetailsDTO, this);
    }

    public boolean map(PolicyCollateralDetailsDTO policyCollateralDetailsDTO, String insuranceType) {
        return BirCollateralDetailsMapperFactory.getBirCollateralDetailsMapper(insuranceType).map(policyCollateralDetailsDTO,this);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }

        if (o == null || this.getClass() != o.getClass()) { return false; }

        BirCollateralDetails that = (BirCollateralDetails) o;

        return new EqualsBuilder()
                .append(rid, that.rid)
                .append(birProofOfCovDetails, that.birProofOfCovDetails)
                .append(collateralRid, that.collateralRid)
                .append(policyAddress, that.policyAddress)
                .append(policyFloodZone, that.policyFloodZone)
                .append(grandfathered, that.grandfathered)
                .append(policyStatus, that.policyStatus)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(birProofOfCovDetails)
                .append(collateralRid)
                .append(policyAddress)
                .append(policyFloodZone)
                .append(grandfathered)
                .append(policyStatus)
                .toHashCode();
    }
}
