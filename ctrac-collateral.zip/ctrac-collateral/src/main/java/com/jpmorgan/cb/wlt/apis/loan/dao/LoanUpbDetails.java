package com.jpmorgan.cb.wlt.apis.loan.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "TLCP_LOAN_UPB_DETAILS")
public class LoanUpbDetails extends AuditableEntity implements Serializable {
	private static final long serialVersionUID = -1;

	@GeneratedValue(strategy = GenerationType.TABLE, generator = "loanUpbSeqGenerator")
	@TableGenerator(name = "loanUpbSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_LOAN_UPB_DETAILS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
	@Id
	@Column(name = "RID")
	private Long rid;

	@ManyToOne
	@JoinColumn(name = "LOAN_ID")
	private Loan loan;

	@Column(name = "UPB_DATE")
	private Date upbDate;

	@Column(name = "UPB")
	private BigDecimal upb;

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	public Date getUpbDate() {
		return upbDate;
	}

	public void setUpbDate(Date upbDate) {
		this.upbDate = upbDate;
	}

	public BigDecimal getUpb() {
		return upb;
	}

	public void setUpb(BigDecimal upb) {
		this.upb = upb;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rid == null) ? 0 : rid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		LoanUpbDetails other = (LoanUpbDetails) obj;
		if (rid == null) {
			if (other.rid != null) {
				return false;
			}
		} else if (!rid.equals(other.rid)) {
			return false;
		}
		return true;
	}
}
