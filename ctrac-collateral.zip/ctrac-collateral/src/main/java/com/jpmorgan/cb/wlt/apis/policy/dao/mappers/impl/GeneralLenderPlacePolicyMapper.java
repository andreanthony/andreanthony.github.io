package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;

public class GeneralLenderPlacePolicyMapper extends AbstractGeneralPolicyMapper implements DaoMapper<ProofOfCoverage, PolicyDTO> {
    @Override
    public PolicyDTO toDTO(ProofOfCoverage model) {
        PolicyDTO dto = super.toDTO(model);
        PolicyMapperUtil.populateLPPolicyDTOPaymentMethodDetails(model, dto);
        return dto;
    }

    @Override
    public boolean map(PolicyDTO dto, ProofOfCoverage model) {
        if (!super.map(dto, model)) {
            return false;
        }

        if(PolicyMapperUtil.validLPPolicyDTOProvidedCoverages(dto)) {
            super.mapPolicyCoverages(dto, model);
        }

        PolicyMapperUtil.mapLPPolicyDTOPaymentMethodDetailsToModel(dto, model);

        return true;
    }
}
