package com.jpmorgan.cb.wlt.apis.policy.services;

import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;

public interface BorrowerPolicyVerificationService {
    boolean notMigratedAllVerifiedAndAllPledged(ProofOfCoverage proofOfCoverage);
}
