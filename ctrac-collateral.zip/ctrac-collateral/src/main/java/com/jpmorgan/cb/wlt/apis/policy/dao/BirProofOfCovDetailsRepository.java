package com.jpmorgan.cb.wlt.apis.policy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BirProofOfCovDetailsRepository extends JpaRepository<BirProofOfCovDetails, Long> {
    BirProofOfCovDetails findByProofOfCoverageRid(Long proofOfCoverageRid);
}
