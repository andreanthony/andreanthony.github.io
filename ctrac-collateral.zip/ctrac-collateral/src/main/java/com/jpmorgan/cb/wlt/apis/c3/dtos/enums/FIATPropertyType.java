package com.jpmorgan.cb.wlt.apis.c3.dtos.enums;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by E704298 on 7/11/2017.
 */
public enum FIATPropertyType {

    DWELLING_RESIDENTIAL("Dwelling (1-4 Unit) Residential", true),
    MULTI_FAMILY("5+ Multi Family", false),
    COMMERCIAL("Commercial", false),
    COMMERCIAL_CONDO_ASSOCIATION("Commercial Condo Association", false),
    RESIDENTIAL_CONDO_ASSOCIATION("Residential Condo Association", false);

    private final String displayName;
    private final Boolean isResidential;

    FIATPropertyType(String displayName, Boolean isResidential) {
        this.displayName = displayName;
        this.isResidential = isResidential;        
    }

    public String getDisplayName() {
        return displayName;
    }
    
    public Boolean isResidential() {
        return isResidential;
    }

    public static FIATPropertyType findByDisplayName(String description) {
        for (FIATPropertyType value : values()) {
            if (value.getDisplayName().equalsIgnoreCase(description)) {
                return value;
            }
        }
        return null;
    }
    
    public static String[] getResidentialPropertyType() {
    	List<String> residentialPropertyType = new ArrayList<>();
    			
        for (FIATPropertyType value : values()) {
            if (value.isResidential()) {
            	residentialPropertyType.add(value.getDisplayName());
            }
        }
        
        return residentialPropertyType.toArray(new String[residentialPropertyType.size()]);
    }
}
