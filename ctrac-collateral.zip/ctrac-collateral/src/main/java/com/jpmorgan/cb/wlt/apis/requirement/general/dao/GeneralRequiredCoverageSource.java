package com.jpmorgan.cb.wlt.apis.requirement.general.dao;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.types.EntityDocumentHolder;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageDTO;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageSourceDTO;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.annotations.WhereJoinTable;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;


@Entity
@Table(name = "TLCP_GENERAL_REQUIRED_COV_SRC")
public class GeneralRequiredCoverageSource extends AuditableEntity implements Serializable, EntityDocumentHolder {
    private static final long serialVersionUID = -1;

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "generalRequiredCoverageSourceSeqGenerator")
    @TableGenerator(name = "generalRequiredCoverageSourceSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_GENERAL_REQUIRED_COV_SRC", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "COLLATERAL_RID", nullable = false)
    private Long collateralRid;

    @OneToMany(orphanRemoval = true)
    @JoinTable(name = "TLCP_ENTITY_DOCUMENTS_REL",
            joinColumns = { @JoinColumn(name = "ENTITY_RID") },
            inverseJoinColumns = { @JoinColumn(name = "DOCUMENT_RID") })
    @WhereJoinTable(clause = "ENTITY_TYPE = 'GeneralRequiredCoverageSource' ")
    private Collection<CollateralDocument> coverageSourceDocuments = new ArrayList<>();

    @Column(name = "SOURCE")
    private String source;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "INSURANCE_TYPE")
    private String insuranceType;

    @Column(name = "DOCUMENT_DATE")
    private Date documentDate;

    @Column(name = "CANCELLATION_EFFECTIVE_DATE")
    private Date cancellationEffectiveDate;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "generalRequiredCoverageSource", orphanRemoval = true)
    private List<GeneralRequiredCoverage> generalRequiredCoverages = new ArrayList<GeneralRequiredCoverage>();

    private static final DateFormatter DEFAULT_DATE_FORMATTER = new DefaultDateFormatter();
    public GeneralRequiredCoverageSource() {
    }

    /**
     * @return the rid
     */
    public Long getRid() {
        return rid;
    }


    /**
     * @return the source
     */
    public String getSource() {
        return source;
    }


    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }


    /**
     * @return the insuranceType
     */
    public String getInsuranceType() {
        return insuranceType;
    }


    /**
     * @param rid the rid to set
     */
    public void setRid(Long rid) {
        this.rid = rid;
    }

    /**
     * @param source the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }


    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }


    /**
     * @param insuranceType the insuranceType to set
     */
    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    /**
     * @return the documentDate
     */
    public Date getDocumentDate() {
        return documentDate;
    }


    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }

    public Collection<CollateralDocument> getCoverageSourceDocuments() {
        return coverageSourceDocuments;
    }

    public void setCoverageSourceDocuments(Collection<CollateralDocument> coverageSourceDocuments) {
        this.coverageSourceDocuments = coverageSourceDocuments;
    }

    public void addCoverageSourceDocuments(Collection<CollateralDocument> coverageSourceDocuments) {
        this.coverageSourceDocuments.addAll(coverageSourceDocuments);
    }

    public boolean isVeried() {
        return VerificationStatus.VERIFIED.name().equalsIgnoreCase(status);
    }

    public Date getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
        this.cancellationEffectiveDate = cancellationEffectiveDate;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public List<GeneralRequiredCoverage> getGeneralRequiredCoverages() {
        return generalRequiredCoverages;
    }

    public void setGeneralRequiredCoverages(List<GeneralRequiredCoverage> generalRequiredCoverages) {
        this.generalRequiredCoverages = generalRequiredCoverages;

    }

    public GeneralRequiredCoverageSourceDTO toGeneralRequiredCoverageSourceDTO(){
        GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO = new GeneralRequiredCoverageSourceDTO();
        generalRequiredCoverageSourceDTO.setRid(rid);
        generalRequiredCoverageSourceDTO.setSource(source);
        generalRequiredCoverageSourceDTO.setStatus(status);
        generalRequiredCoverageSourceDTO.setCancellationEffectiveDate(cancellationEffectiveDate !=null ? DEFAULT_DATE_FORMATTER.print(cancellationEffectiveDate) : null);
        generalRequiredCoverageSourceDTO.setCollateralRid(collateralRid);
        generalRequiredCoverageSourceDTO.setDocumentDate(DEFAULT_DATE_FORMATTER.print(documentDate));
        generalRequiredCoverageSourceDTO.setInsuranceType(insuranceType);
        generalRequiredCoverageSourceDTO.setUpdatedBy(this.getUpdatedBy());
        this.getGeneralRequiredCoverages().forEach(generalRequiredCoverage -> {
            generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages()
                    .add(generalRequiredCoverage.toGeneralRequiredCoverageDTO());
        });
        if(CollectionUtils.isNotEmpty(this.getCoverageSourceDocuments())) {
            this.getCoverageSourceDocuments().forEach(coverageSourceDocument ->
                    generalRequiredCoverageSourceDTO.getCoverageSourceDocuments()
                    .add(coverageSourceDocument.toCollateralDocumentDTO()
                            .getCollateralDocumentSummary()));
        }
        return generalRequiredCoverageSourceDTO;
    }


    public GeneralRequiredCoverageSource fromGeneralRequiredCoverageSourceDTO(GeneralRequiredCoverageSourceDTO generalRequiredCoverageSourceDTO,
                                                                              UserRequestInfo userRequestInfo) {
        if (null!=generalRequiredCoverageSourceDTO.getRid()&& generalRequiredCoverageSourceDTO.getRid() != 0) {
            this.setRid(generalRequiredCoverageSourceDTO.getRid());
            this.updateAuditInfo(userRequestInfo.getUserSid());
        }else{
            this.setInitialAuditInfo(userRequestInfo.getUserSid());
        }

        setInsuranceType(generalRequiredCoverageSourceDTO.getInsuranceType());
        setCancellationEffectiveDate(DEFAULT_DATE_FORMATTER.parse(generalRequiredCoverageSourceDTO.getCancellationEffectiveDate()));
        setSource(generalRequiredCoverageSourceDTO.getSource());
        setStatus(generalRequiredCoverageSourceDTO.getStatus());
        setCollateralRid(generalRequiredCoverageSourceDTO.getCollateralRid());
        setDocumentDate(DEFAULT_DATE_FORMATTER.parse(generalRequiredCoverageSourceDTO.getDocumentDate()));

        List<GeneralRequiredCoverage> newGeneralReqCoveragesToAdd = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages())){
            generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages().forEach(generalRequiredCoverageDTO ->
            {
                GeneralRequiredCoverage generalRequiredCoverage = this.generalRequiredCoverages.stream()
                        .filter(modelObj -> modelObj.getRid().equals(generalRequiredCoverageDTO.getRid()))
                        .findFirst().orElse(new GeneralRequiredCoverage());
                generalRequiredCoverage.fromGeneralRequiredCoverageDTO(generalRequiredCoverageDTO, userRequestInfo);
                if(generalRequiredCoverage.getRid() == null){
                    generalRequiredCoverage.setGeneralRequiredCoverageSource(this);
                    newGeneralReqCoveragesToAdd.add(generalRequiredCoverage);
                }
            });

            List<GeneralRequiredCoverage> coveragesToDelete = new ArrayList<>();
            for(GeneralRequiredCoverage generalRequiredCoverage : this.generalRequiredCoverages){
                GeneralRequiredCoverageDTO generalRequiredCoverageDTO = generalRequiredCoverageSourceDTO.getGeneralRequiredCoverages().stream()
                        .filter(dtoObject -> Objects.equals(generalRequiredCoverage.getRid(), dtoObject.getRid()))
                        .findFirst().orElse(null);
                if(generalRequiredCoverageDTO == null){
                    coveragesToDelete.add(generalRequiredCoverage);
                }
            }
            this.generalRequiredCoverages.addAll(newGeneralReqCoveragesToAdd);
            this.generalRequiredCoverages.removeAll(coveragesToDelete);
        }
        return this;
    }

}