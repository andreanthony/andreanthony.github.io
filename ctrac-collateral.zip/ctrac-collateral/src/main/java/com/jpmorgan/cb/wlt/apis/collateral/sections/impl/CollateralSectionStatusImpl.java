package com.jpmorgan.cb.wlt.apis.collateral.sections.impl;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.details.dao.CollateralRepository;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionStatus;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dao.SectionStatus;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dao.SectionStatusRepository;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dtos.SectionStatusDto;
import com.jpmorgan.cb.wlt.apis.event.SectionUpdatedEventUtil;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.floodDetermination.dao.DeterminationDetailsViewData;
import com.jpmorgan.cb.wlt.apis.floodDetermination.dao.DeterminationDetailsViewRepository;
import com.jpmorgan.cb.wlt.apis.policy.dao.CollateralInsuranceRepository;
import com.jpmorgan.cb.wlt.apis.policy.dao.CollateralInsuranceViewData;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverageRepository;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.RequiredCoverageView;
import com.jpmorgan.cb.wlt.apis.requirement.flood.dao.repository.RequiredCoverageViewRepository;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.GeneralRequiredCoverageSource;
import com.jpmorgan.cb.wlt.apis.requirement.general.dao.repository.GeneralRequiredCoverageSourceRepository;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.enums.*;
import com.jpmorgan.cib.wlt.ctrac.exceptions.CtracException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

import static com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus.*;

@Service
public class CollateralSectionStatusImpl implements CollateralSectionService {

    private static final Logger logger = LoggerFactory.getLogger(CollateralSectionStatusImpl.class);

    private CollateralRepository collateralRepository;
    private SectionStatusRepository sectionStatusRepository;
    private PublishEventService publishEventService;
    private ProofOfCoverageRepository proofOfCoverageRepository;
    private GeneralRequiredCoverageSourceRepository generalRequiredCoverageSourceRepository;
    private CollateralInsuranceRepository collateralInsuranceRepository;
    private DeterminationDetailsViewRepository determinationDetailsViewRepository;
    private RequiredCoverageViewRepository requiredCoverageViewRepository;

    private static final Map<VerificationStatus, VerificationStatus> sectionStatusTransition;
    static{
        sectionStatusTransition = new HashMap<>();
        sectionStatusTransition.put(DRAFT, PENDING_VERIFICATION);
        sectionStatusTransition.put(PENDING_VERIFICATION, VERIFIED);
    }


    @Autowired
    public CollateralSectionStatusImpl(CollateralRepository collateralRepository,
                                       SectionStatusRepository sectionStatusRepository,
                                       PublishEventService publishEventService,
                                       ProofOfCoverageRepository proofOfCoverageRepository,
                                       GeneralRequiredCoverageSourceRepository generalRequiredCoverageSourceRepository,
                                       CollateralInsuranceRepository collateralInsuranceRepository,
                                       DeterminationDetailsViewRepository determinationDetailsViewRepository,
                                       RequiredCoverageViewRepository requiredCoverageViewRepository) {
        assert(collateralRepository != null);
        this.collateralRepository = collateralRepository;
        assert(sectionStatusRepository != null);
        this.sectionStatusRepository = sectionStatusRepository;
        assert(publishEventService != null);
        this.publishEventService = publishEventService;
        assert(proofOfCoverageRepository !=null);
        this.proofOfCoverageRepository = proofOfCoverageRepository;
        assert(generalRequiredCoverageSourceRepository !=null);
        this.generalRequiredCoverageSourceRepository = generalRequiredCoverageSourceRepository;
        assert(collateralInsuranceRepository !=null);
        this.collateralInsuranceRepository = collateralInsuranceRepository;
        assert(determinationDetailsViewRepository!=null);
        this.determinationDetailsViewRepository=determinationDetailsViewRepository;
        assert(requiredCoverageViewRepository!=null);
        this.requiredCoverageViewRepository=requiredCoverageViewRepository;
    }

    @Override
    public List<SectionStatus> initializeCollateralSections(Long collateralId, UserRequestInfo userRequestInfo) {
        Optional<Collateral> collateral = collateralRepository.findById(collateralId);
        if (!collateral.isPresent()) {
            throw new CtracException("No collateral for initializeCollateralSections, rid=" + collateralId);
        }
        List<SectionStatus> sectionStatuses = new ArrayList<>();
        for (CollateralSection collateralSection : CollateralSection.values()) {
            SectionStatus sectionStatus = sectionStatusRepository.findByCollateral_RidAndSectionId(collateralId, collateralSection.name());
            if(sectionStatus == null) {
                sectionStatuses.add(createSectionStatus(collateral.get(), collateralSection, userRequestInfo.getUserSid()));
            }
        }
        return sectionStatusRepository.saveAll(sectionStatuses);
    }

    @Override
    public void edit(Long collateralId, CollateralSection collateralSection, UserRequestInfo userRequestInfo) {
        SectionStatus sectionStatus = sectionStatusRepository.findByCollateral_RidAndSectionId(collateralId, collateralSection.name());
        if (sectionStatus == null) {
            logger.debug("No sectionStatus found for collateralId={} and collateralSection={}", collateralId, collateralSection);
            throw new CtracException("Invalid request");
        }
        sectionStatus.updateAuditInfo(userRequestInfo.getUserSid());
        sectionStatus.setModifiedDate(new Date());
        sectionStatus.setModifiedBy(userRequestInfo.getUserSid());
        if (!CollateralSectionStatus.DRAFT.name().equals(sectionStatus.getStatusId())) {
            sectionStatus.setStatusId(CollateralSectionStatus.PENDING_VERIFICATION.name());
        }
        sectionStatusRepository.save(sectionStatus);
        publishEventService.publishEvent(SectionUpdatedEventUtil.build(collateralId, collateralSection, CollateralScreenAction.EDIT, userRequestInfo));
    }

    @Override
    public void verify(Long collateralId, CollateralSection collateralSection, UserRequestInfo userRequestInfo) {
        SectionStatus sectionStatus = sectionStatusRepository.findByCollateral_RidAndSectionId(collateralId, collateralSection.name());
        if (sectionStatus == null) {
            logger.debug("No sectionStatus found for collateralId={} and collateralSection={}", collateralId, collateralSection);
            throw new CtracException("Invalid request");
        }

          if (EnumUtils.getEnum(CollateralSectionStatus.class, sectionStatus.getStatusId()) != CollateralSectionStatus.PENDING_VERIFICATION)
           {
            logger.debug("sectionStatus not in PENDING_VERIFICATION; sectionStatus.rid={}", sectionStatus.getRid());
            throw new CtracException("Invalid request");
        }
        sectionStatus.setStatusId(CollateralSectionStatus.VERIFIED.name());
        sectionStatus.setVerifiedDate(new Date());
        sectionStatus.setVerifiedBy(userRequestInfo.getUserSid());
        sectionStatus.updateAuditInfo(userRequestInfo.getUserSid());
        sectionStatusRepository.save(sectionStatus);
        publishEventService.publishEvent(SectionUpdatedEventUtil.build(collateralId, collateralSection, CollateralScreenAction.VERIFY, userRequestInfo));
    }

    @Override
    @Transactional
    public void allowAnyVerification(Long collateralId) {
        List<SectionStatus> sectionStatuses = sectionStatusRepository.findByCollateralRid(collateralId);
        List<SectionStatus> updatedSectionStatuses = new ArrayList<>();
        for (SectionStatus sectionStatus : sectionStatuses) {
            if (EnumUtils.getEnum(VerificationStatus.class, sectionStatus.getStatusId()) == PENDING_VERIFICATION)
            {
                sectionStatus.setModifiedBy(CtracAppConstants.CONST_UPDATED_BY_ADMIN);
                updatedSectionStatuses.add(sectionStatus);
                if(CollateralSection.GENERAL_INSURANCE_POLICIES == EnumUtils.getEnum(CollateralSection.class,sectionStatus.getSectionId())){
                    allowForVerificationProofOfCoverage(collateralId);
                } else if(CollateralSection.GENERAL_REQUIRED_INSURANCE_COVERAGE == EnumUtils.getEnum(CollateralSection.class,sectionStatus.getSectionId())){
                    allowForVerificationRequiredCoverageSource(collateralId);
                }
            }
        }
        if (!updatedSectionStatuses.isEmpty()) {
            sectionStatusRepository.saveAll(sectionStatuses);
        }

    }

    @Override
    @Transactional
    public List<SectionStatusDto> getSectionStatuses(Long collateralId) {

            List<SectionStatus> sectionStatus = sectionStatusRepository.findByCollateralRid(collateralId);
            List<SectionStatusDto> sectionStatusDtos = sectionStatus.stream()
                    .map(model -> model.mapToDto())
                    .collect(Collectors.toList());
            return sectionStatusDtos;
    }

    @Override
    public boolean areBasicSectionsVerified(Long collateralRid) {
        List<SectionStatus> sectionsStatuses = sectionStatusRepository.findByCollateralRid(collateralRid);
        return areSectionsVerified(sectionsStatuses, CollateralSection.getBasicCollateralSections());
    }

    private boolean areSectionsVerified(List<SectionStatus> sectionStatuses, Set<CollateralSection> sections) {
        Set<CollateralSection> verifiedSections = new HashSet<CollateralSection>();
            sectionStatuses.forEach(sectionStatus -> {
            CollateralSection section = CollateralSection.valueOf(sectionStatus.getSectionId());
            if (sections.contains(section) &&
             (EnumUtils.getEnum(CollateralSectionStatus.class, sectionStatus.getStatusId()) == CollateralSectionStatus.VERIFIED))
            {
                verifiedSections.add(section);
            }
        });
        return sections.size() == verifiedSections.size();
    }


    private SectionStatus createSectionStatus(Collateral collateral, CollateralSection collateralSection, String userSid) {
        SectionStatus sectionStatus = new SectionStatus();
        sectionStatus.setCollateral(collateral);
        sectionStatus.setSectionId(collateralSection.name());
        sectionStatus.setStatusId(CollateralSectionStatus.DRAFT.name());
        sectionStatus.setModifiedBy(userSid);
        sectionStatus.setModifiedDate(new Date());
        sectionStatus.setInitialAuditInfo(userSid);
        return sectionStatus;
    }
    @Transactional
    public void allowForVerificationProofOfCoverage(Long collateralId) {
            List<CollateralInsuranceViewData> insuranceViewDataList = collateralInsuranceRepository.findByCollateralRidAndProofOfCoveragePolicyStatusIn(collateralId,
                            Collections.singletonList(PolicyStatus.PENDING_VERIFICATION.name()));
            List<ProofOfCoverage> proofOfCoverages=new ArrayList<>();
            for (CollateralInsuranceViewData insuranceViewData : insuranceViewDataList) {
                if (PENDING_VERIFICATION == EnumUtils.getEnum(VerificationStatus.class,insuranceViewData.getProofOfCoverage().getPolicyStatus())) {
                    ProofOfCoverage proofOfCoverage=insuranceViewData.getProofOfCoverage();
                    proofOfCoverage.updateAuditInfo(CtracAppConstants.CONST_UPDATED_BY_ADMIN);
                    proofOfCoverages.add(proofOfCoverage);

                }
            }

            if(!proofOfCoverages.isEmpty()){
                proofOfCoverageRepository.saveAll(proofOfCoverages);
            }
    }
    @Transactional
    public void allowForVerificationRequiredCoverageSource(Long collateralId) {
            List<GeneralRequiredCoverageSource> sourceList = generalRequiredCoverageSourceRepository.findByCollateralRid(collateralId);
            List<GeneralRequiredCoverageSource> requiredCoverageSources=new ArrayList<>();
            for (GeneralRequiredCoverageSource source : sourceList) {
                if (PENDING_VERIFICATION == EnumUtils.getEnum(VerificationStatus.class,source.getStatus())) {
                    source.updateAuditInfo(CtracAppConstants.CONST_UPDATED_BY_ADMIN);
                    requiredCoverageSources.add(source);

                }
            }
            if(!requiredCoverageSources.isEmpty()) {
                generalRequiredCoverageSourceRepository.saveAll(requiredCoverageSources);
            }
    }

    @Override
    @Transactional
    public void advanceAllSections(CollateralDTO collateralDto) {
        List<SectionStatus> sectionStatusList = sectionStatusRepository.findByCollateralRid(collateralDto.getRid());
            sectionStatusList.forEach(sectionStatus->advanceSectionStatus(sectionStatus));
        if(CollectionUtils.isNotEmpty(sectionStatusList)) {
            sectionStatusRepository.saveAll(sectionStatusList);
        }
    }


    private void advanceSectionStatus(SectionStatus sectionStatus) {
        VerificationStatus newSectionStatus = sectionStatusTransition.get(EnumUtils.getEnum(VerificationStatus.class,sectionStatus.getStatusId()));
        if (newSectionStatus == null) {
            logger.debug("null transition");
            return;
        }
        sectionStatus.setStatusId(newSectionStatus.name());
        if (newSectionStatus == PENDING_VERIFICATION) {
            setSectionStatus(sectionStatus);
        }

    }

    private void setSectionStatus(SectionStatus sectionStatus) {
        CollateralSection collateralSection=EnumUtils.getEnum(CollateralSection.class,sectionStatus.getSectionId());
        switch (collateralSection) {
            case FLOOD_HAZARD_DETERMINATION_FORM:
                setFloodHazardSection(sectionStatus);
                break;
            case FLOOD_REQUIRED_INSURANCE_COVERAGE:
                setFloodCoverageSection(sectionStatus);
                break;
            case GENERAL_REQUIRED_INSURANCE_COVERAGE:
                setGeneralCoverageSection(sectionStatus);
                break;
            case FLOOD_INSURANCE_POLICIES:
                setPolicyInsuranceSectionByInsuranceType(sectionStatus, InsuranceType.FLOOD);
                break;
            case GENERAL_INSURANCE_POLICIES:
                setPolicyInsuranceSectionByInsuranceType(sectionStatus, InsuranceType.GENERAL);
                break;
        }
    }

    private void setGeneralCoverageSection(SectionStatus sectionStatus) {
        List<GeneralRequiredCoverageSource> sourceList =
                generalRequiredCoverageSourceRepository.findByCollateralRidAndStatus
                        (sectionStatus.getCollateral().getRid(),CtracAppConstants.CONST_PENDING_VERIFICATION);
        if (CollectionUtils.isEmpty(sourceList)) {
            sectionStatus.setStatusId(VerificationStatus.VERIFIED.name());
        }
    }

    private void setFloodCoverageSection(SectionStatus sectionStatus) {
        List<RequiredCoverageView> requiredCoverages =
                requiredCoverageViewRepository.findByCollateralRidAndStatus(
                        sectionStatus.getCollateral().getRid(), CtracAppConstants.CONST_PENDING_VERIFICATION);
        if (CollectionUtils.isEmpty(requiredCoverages)) {
            sectionStatus.setStatusId(VerificationStatus.VERIFIED.name());
        }
    }

    private void setFloodHazardSection(SectionStatus sectionStatus) {
        List<DeterminationDetailsViewData> floodDeterminations =
                determinationDetailsViewRepository.findByCollateralRidAndStatus(
                        sectionStatus.getCollateral().getRid(), CtracAppConstants.CONST_PENDING_VERIFICATION);
        if (CollectionUtils.isEmpty(floodDeterminations)) {
            sectionStatus.setStatusId(VerificationStatus.VERIFIED.name());
        }
    }

    private void setPolicyInsuranceSectionByInsuranceType(SectionStatus sectionStatus, InsuranceType insuranceType){
        List<String> policyStatuses = PolicyStatus.getActiveAsStrings(true);
        List<ProofOfCoverage> proofOfCoverages = proofOfCoverageRepository.findByCollateralIdAndStatus(
                sectionStatus.getCollateral().getRid(), policyStatuses);
        List<ProofOfCoverage> filteredListByInsuranceType = proofOfCoverages.stream().filter(proofOfCoverage ->
                insuranceType == EnumUtils.getEnum(InsuranceType.class,proofOfCoverage.getInsuranceType())).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(filteredListByInsuranceType)) {
            sectionStatus.setStatusId(VerificationStatus.VERIFIED.name());
        }
    }
}
