package com.jpmorgan.cb.wlt.apis.application;

import com.jpmorgan.cb.wlt.apis.application.dto.ApplicationInfoDTO;
import com.jpmorgan.cb.wlt.apis.application.services.ApplicationManagementService;
import com.jpmorgan.cb.wlt.apis.user.services.UserService;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Secured({CtracRole.ROLE_READER})
@RestController
@RequestMapping(value = "/api/application")
public class ApplicationManagementAPI {

    private ApplicationManagementService applicationManagementService;
    private UserService userService;

    @Autowired
    public ApplicationManagementAPI(ApplicationManagementService applicationManagementService,
                                    UserService userService) {
        assert(applicationManagementService != null);
        this.applicationManagementService = applicationManagementService;
        assert(userService != null);
        this.userService = userService;
    }

    @GetMapping(value = "/info")
    public ResponseEntity<ApplicationInfoDTO> getApplicationInfo() {
        return ResponseEntity.ok(applicationManagementService.getApplicationInfo());
    }

    @Secured({CtracRole.ROLE_API})
    @PostMapping(value = "/entitlements/cache/clear")
    public ResponseEntity<Boolean> clearUserEntitlementsCache() {
        return ResponseEntity.ok(userService.clearUserEntitlementsCache());
    }
}
