package com.jpmorgan.cb.wlt.apis.event;

import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import org.apache.commons.lang3.StringUtils;

public abstract class AbstractPublishEventRequest implements PublishEventRequest {
	private CtracEventType ctracEventType;
	private UserRequestInfo userRequestInfo;

	public AbstractPublishEventRequest forCtracEventType(CtracEventType ctracEventType) {
		this.ctracEventType = ctracEventType;
		return this;
	}

	public AbstractPublishEventRequest withUserRequestInfo(UserRequestInfo userRequestInfo) {
		this.userRequestInfo = userRequestInfo;
		return this;
	}

	public CtracEventType getCtracEventType() {
		return ctracEventType;
	}

	public String getDescription() {
		return StringUtils.EMPTY;
	}

	public abstract String getIdentifier();

	public abstract Long getCollateralRid();

	public UserRequestInfo getUserRequestInfo() {
		return userRequestInfo;
	}

	public String getTaskName() {
		return StringUtils.EMPTY;
	}

	public abstract CollateralEventSection getCollateralEventSection();

	@Deprecated
	public final String getLineOfBusiness() {
		return null;
	}

}
