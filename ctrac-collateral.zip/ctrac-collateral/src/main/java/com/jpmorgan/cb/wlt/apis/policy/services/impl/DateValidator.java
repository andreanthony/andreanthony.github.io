package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;

import java.util.List;

public class DateValidator {
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    private DateValidator(){}

    public static DateTime validateDateValue(String dateValue, String dateType, List<String> validationErrors) {
        DateTime date = null;
        if (StringUtils.isEmpty(dateValue)) {
            validationErrors.add(dateType + "Date required");
            return date;
        }
        try {
            date = new DateTime(DATE_FORMATTER.parse(dateValue));
        } catch (Exception e) {
            validationErrors.add(dateType + "Date invalid");
        }
        return date;
    }
}
