package com.jpmorgan.cb.wlt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface BatchCtrlRepository extends JpaRepository<BatchCtrl, Long> {


    List<BatchCtrl> findByRunningAndBatchTypeIn(Character running, Collection<String> batchTypes);

}