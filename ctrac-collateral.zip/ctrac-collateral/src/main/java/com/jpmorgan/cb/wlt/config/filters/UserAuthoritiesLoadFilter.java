package com.jpmorgan.cb.wlt.config.filters;

import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerService;
import com.jpmorgan.cb.wlt.apis.user.services.UserService;
import com.jpmorgan.cb.wlt.config.environment.EnvironmentManager;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class UserAuthoritiesLoadFilter extends GenericFilterBean {

    @Autowired
    private EnvironmentManager environmentManager;

    @Autowired
    private UserService userService;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        String userFromRequest = environmentManager.getActiveEnvironment().getUserNameFromRequest((HttpServletRequest) request);
        UserRequestInfo requestInfo = new UserRequestInfo(userFromRequest);
        userService.populateUserDetails(requestInfo);
        request.setAttribute(CtracAuthenticationManagerService.USER_REQUEST_INFO, requestInfo);

        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken
                (userFromRequest, StringUtils.EMPTY, generateApplicationGrantedAuthorities(requestInfo)));
        chain.doFilter(request, response);
    }

    private List<ApplicationGrantedAuthority> generateApplicationGrantedAuthorities(UserRequestInfo requestInfo){
        List<ApplicationGrantedAuthority> applicationGrantedAuthorities = new ArrayList<>();
        requestInfo.getUserEntitlementsDto().getAuthorities().forEach((role, lobs) -> {
            ApplicationGrantedAuthority applicationGrantedAuthority = applicationGrantedAuthorities.stream()
                    .filter(appAuthority -> StringUtils.equals(appAuthority.getAuthority(),role))
                    .findFirst()
                    .orElse(new ApplicationGrantedAuthority(role));
            applicationGrantedAuthority.addLobs(lobs);
            applicationGrantedAuthorities.add(applicationGrantedAuthority);
        });
        return applicationGrantedAuthorities;
    }

}
