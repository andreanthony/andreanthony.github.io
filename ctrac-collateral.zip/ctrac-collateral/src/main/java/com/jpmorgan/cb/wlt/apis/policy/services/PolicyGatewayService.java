package com.jpmorgan.cb.wlt.apis.policy.services;

import com.jpmorgan.cb.wlt.apis.policy.dtos.OverrideLpPolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;

import java.util.List;
import java.util.Map;

public interface PolicyGatewayService {
    PolicyDTO createPolicy(PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, UserRequestInfo userRequestInfo);
    PolicyDTO editPolicy(Long policyId, PolicyDTO policyDTO, List<FileUploadAttachmentDTO> filesUploaded, UserRequestInfo userRequestInfo);
    PolicyDTO verifyPolicy(Long policyId, PolicyDTO policyDTO, UserRequestInfo userRequestInfo);
    PolicyDTO overridePolicy(Long policyId, OverrideLpPolicyDTO overrideLpPolicyDTO, UserRequestInfo userRequestInfo);
    Map<String, BIRRuleConclusionDTO> reviewPolicy(PolicyDTO policyDTO);
}
