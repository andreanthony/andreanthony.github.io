package com.jpmorgan.cb.wlt.apis.lookup.dtos;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class LookupCodeDTO {

	private Long rid;
	private String codeSet;
	private String code;
	private String description;
	private String active;
	private Integer sortOrder;

	private String childCodeSet;
	
	public Long getRid() {
		return rid;
	}

	public Integer getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public String getCodeSet() {
		return codeSet;
	}

	public void setCodeSet(String codeSet) {
		this.codeSet = codeSet;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getChildCodeSet() { return childCodeSet; }

	public void setChildCodeSet(String childCodeSet) { this.childCodeSet = childCodeSet; }

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;

		if (o == null || getClass() != o.getClass()) return false;

		LookupCodeDTO that = (LookupCodeDTO) o;

		return new EqualsBuilder()
				.append(rid, that.rid)
				.append(codeSet, that.codeSet)
				.append(code, that.code)
				.append(description, that.description)
				.append(active, that.active)
				.append(sortOrder, that.sortOrder)
				.append(childCodeSet, that.childCodeSet)
				.isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 37)
				.append(rid)
				.append(codeSet)
				.append(code)
				.append(description)
				.append(active)
				.append(sortOrder)
				.append(childCodeSet)
				.toHashCode();
	}
}
