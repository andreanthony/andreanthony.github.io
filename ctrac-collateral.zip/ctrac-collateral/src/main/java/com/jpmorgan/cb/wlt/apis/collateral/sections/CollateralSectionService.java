package com.jpmorgan.cb.wlt.apis.collateral.sections;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dao.SectionStatus;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dtos.SectionStatusDto;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;

import java.util.List;

public interface CollateralSectionService {
    List<SectionStatus> initializeCollateralSections(Long collateralId, UserRequestInfo userRequestInfo);
    void edit(Long collateralId, CollateralSection collateralSection, UserRequestInfo userRequestInfo);
    void verify(Long collateralId, CollateralSection collateralSection, UserRequestInfo userRequestInfo);
    void allowAnyVerification(Long collateralId);
    List<SectionStatusDto> getSectionStatuses(Long collateralId);
    boolean areBasicSectionsVerified(Long collateralRid);
    void advanceAllSections(CollateralDTO collateralDto);
}
