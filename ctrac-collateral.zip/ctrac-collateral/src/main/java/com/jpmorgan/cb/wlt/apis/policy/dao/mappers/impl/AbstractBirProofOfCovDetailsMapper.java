package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.BirProofOfCovDetails;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;

public abstract class AbstractBirProofOfCovDetailsMapper {

    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    public void addToDTO(PolicyDTO dto, BirProofOfCovDetails model) {
        dto.setEoiReceivedDate(DATE_FORMATTER.print(model.getEoiReceivedDate()));
        dto.setEvidenceOfInsurance(model.getEoiType());
        dto.setSignedByAgent(model.getSignedByAgent());
        dto.setProofOfPayment(model.getProofOfPayment());
        dto.setJpmMortgageePayee(model.getJpmMortgageePayee());
        dto.setJpmLenderLossPayee(model.getJpmLenderLossPayee());
        dto.setJpmLienPosition(model.getJpmLienPosition());

    }

    public boolean map(PolicyDTO dto, BirProofOfCovDetails model) {
        model.setEoiReceivedDate(DATE_FORMATTER.parse(dto.getEoiReceivedDate()));
        model.setEoiType(dto.getEvidenceOfInsurance());
        model.setSignedByAgent(dto.getSignedByAgent());
        model.setProofOfPayment(dto.getProofOfPayment());
        model.setJpmMortgageePayee(dto.getJpmMortgageePayee());
        model.setJpmLenderLossPayee(dto.getJpmLenderLossPayee());
        model.setJpmLienPosition(dto.getJpmLienPosition());

        return true;
    }
}