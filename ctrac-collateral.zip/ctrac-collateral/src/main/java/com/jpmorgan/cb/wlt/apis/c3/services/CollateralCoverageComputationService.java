package com.jpmorgan.cb.wlt.apis.c3.services;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;

public interface CollateralCoverageComputationService {
    C3ResponseDTO evaluate(C3RequestEventDTO c3RequestEventDTO);
    C3ResponseDTO evaluate(C3RequestDTO c3RequestDTO);
    void apply(C3ResponseDTO c3ResponseDTO);
    C3ResponseDTO evaluateGap(C3RequestEventDTO c3RequestEventDTO);
}
