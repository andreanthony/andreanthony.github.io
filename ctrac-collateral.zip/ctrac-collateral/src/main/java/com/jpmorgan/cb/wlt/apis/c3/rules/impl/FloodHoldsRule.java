package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3AlertEmailBuilder;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3CalculatedCoverageDateBuilder;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.enums.C3AlertEmailTemplate;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.List;

public class FloodHoldsRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(FloodHoldsRule.class);
    private static final InsuranceType INSURANCE_TYPE = InsuranceType.FLOOD;

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        if (c3RequestDTO.hasFloodHolds()) {
            List<C3CalculatedCoverageDate> c3CalculatedCoverageDates = c3ResponseDTO.getCalculatedFloodCoverageDates();
            List<C3RequiredCoverage> requiredCoverages = c3RequestDTO.getRequiredCoverages(INSURANCE_TYPE);
            List<Long> holdsVerifiedWithLpiDate = c3RequestDTO.getHoldsVerifiedWithLpiDate();

            if (CollectionUtils.isEmpty(holdsVerifiedWithLpiDate)) {
                if (c3RequestDTO.isAddedAndRemovedCoveragesOnly()) {
                    // Required Coverages verified without FIAT Requested task
                    calculateNewHoldDates(c3CalculatedCoverageDates, requiredCoverages);
                } else {
                    calculateHoldLpiDates(c3CalculatedCoverageDates, requiredCoverages);
                    updateCalculatedFloodCoverageDatesForHolds(c3RequestDTO, c3ResponseDTO);
                }
            } else {
                // Hold LPI dates verified on the Hold Status helper
                calculateHoldsWithVerifiedLpiDate(c3CalculatedCoverageDates, holdsVerifiedWithLpiDate, requiredCoverages);
            }
            if (logger.isDebugEnabled()) {
                logger.debug("FloodHoldsRule - calculated coverage dates: {}",
                        StringUtils.join(c3ResponseDTO.getCalculatedFloodCoverageDates(), ','));
            }
        }
    }

    protected void calculateHoldsWithVerifiedLpiDate(List<C3CalculatedCoverageDate> calculatedCoverageDates, List<Long> holdsVerifiedWithLpiDate, List<C3RequiredCoverage> requiredCoverages) {
        requiredCoverages
                .stream()
                .filter(requiredCoverage -> requiredCoverage.getHoldLpiDate() != null &&
                        holdsVerifiedWithLpiDate.contains(requiredCoverage.getHold().getRid()))
                .forEach(c3RequiredCoverage ->
                        calculatedCoverageDates.add(
                                buildCalculatedCoverageDate(c3RequiredCoverage.getHoldLpiDate(), c3RequiredCoverage)));
    }

    protected void calculateHoldLpiDates(List<C3CalculatedCoverageDate> calculatedFloodCoverageDates, List<C3RequiredCoverage> requiredCoverages) {
        requiredCoverages
                .stream()
                .filter(c3RequiredCoverage -> c3RequiredCoverage.getHoldLpiDate() != null)
                .forEach(c3RequiredCoverage -> calculatedFloodCoverageDates.add(
                        buildCalculatedCoverageDate(c3RequiredCoverage.getHoldLpiDate(), c3RequiredCoverage)));
    }

    protected void calculateNewHoldDates(List<C3CalculatedCoverageDate> calculatedCoverageDates, List<C3RequiredCoverage> requiredCoverages) {
        requiredCoverages
                .forEach(c3RequiredCoverage -> {
                    if (c3RequiredCoverage.hasNewHold()) {calculatedCoverageDates.add(
                            buildCalculatedCoverageDate(c3RequiredCoverage.getHoldStartDate(), c3RequiredCoverage));
                    }
                });
    }

    private C3CalculatedCoverageDate buildCalculatedCoverageDate(Date date, C3RequiredCoverage c3RequiredCoverage) {
        return new C3CalculatedCoverageDateBuilder(INSURANCE_TYPE.name(), date)
                .insurableAssetId(c3RequiredCoverage.getInsurableAssetId())
                .coverageType(c3RequiredCoverage.getCoverageType())
                .insurableAssetType(c3RequiredCoverage.getInsurableAssetType_())
                .build();
    }

    private void updateCalculatedFloodCoverageDatesForHolds(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        c3ResponseDTO.getValidCalculatedFloodCoverageDates()
                .forEach(calculatedCoverageDate -> {
                    C3Hold c3Hold = c3RequestDTO.getRequiredCoverageHold(calculatedCoverageDate.getInsurableAssetId(),
                            calculatedCoverageDate.getCoverageType_());
                    if (c3Hold != null) {
                        if (c3Hold.isAfter(calculatedCoverageDate.getCoverageDate())) {
                            c3ResponseDTO.getAlertEmails().add(new C3AlertEmailBuilder(
                                    C3AlertEmailTemplate.HOLD_ACTION_REQUIRED)
                                    .calculatedCoverageDate(calculatedCoverageDate)
                                    .collateralRid(c3RequestDTO.getCollateralRid())
                                    .build());
                            calculatedCoverageDate.setValid(false);
                        } else if (c3Hold.isActive(calculatedCoverageDate.getCoverageDate())) {
                            calculatedCoverageDate.setCoverageDate(c3Hold.getHoldStartDate());
                        }
                        logger.debug("FloodHoldsRule - latest hold start date {} and hold LPI date {}", c3Hold.getHoldStartDate(), c3Hold.getHoldLpiDate());
                    }
                });
    }

}
