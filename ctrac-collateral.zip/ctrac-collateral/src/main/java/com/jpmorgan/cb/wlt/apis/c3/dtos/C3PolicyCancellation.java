package com.jpmorgan.cb.wlt.apis.c3.dtos;

import com.jpmorgan.cib.wlt.ctrac.enums.CancellationReason;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.DateFormatter;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;

import java.io.Serializable;
import java.util.Date;

public class C3PolicyCancellation implements Serializable {
    private static final long serialVersionUID = -1;
    private static final DateFormatter DATE_FORMATTER = new DefaultDateFormatter();

    private Long policyId;
    private String cancellationEffectiveDate;
    private CancellationReason cancellationReason;
    private String updatedExpirationDate;
    private boolean deleted;

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public String getCancellationEffectiveDate() {
        return cancellationEffectiveDate;
    }

    public void setCancellationEffectiveDate(String cancellationEffectiveDate) {
        this.cancellationEffectiveDate = cancellationEffectiveDate;
    }

    public CancellationReason getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(CancellationReason cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public Date getCancellationEffectiveDate_() {
        return DATE_FORMATTER.parse(cancellationEffectiveDate);
    }

    public String getUpdatedExpirationDate() {
        return updatedExpirationDate;
    }

    public void setUpdatedExpirationDate(String updatedExpirationDate) {
        this.updatedExpirationDate = updatedExpirationDate;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public Date getUpdatedExpirationDate_() {
        return DATE_FORMATTER.parse(updatedExpirationDate);
    }

    @Override
    public String toString() {
        if(getPolicyId()!=null) {
            return getPolicyId().toString();
        }else {return "";}
    }
}
