package com.jpmorgan.cb.wlt.apis.collateral.sections;


import com.jpmorgan.cb.wlt.apis.collateral.sections.dtos.SectionStatusDto;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/collaterals/{collateralId}/sectionStatuses")
public class SectionStatusAPI {

    CollateralSectionService collateralSectionService;

    @Autowired
    public SectionStatusAPI(CollateralSectionService collateralSectionService){
        assert(collateralSectionService != null);
        this.collateralSectionService = collateralSectionService;
    }

    @GetMapping
    public ResponseEntity<List<SectionStatusDto>> getSectionStatuses(@PathVariable Long collateralId) {
        return ResponseEntity.ok(collateralSectionService.getSectionStatuses(collateralId));
    }

    @Secured(CtracRole.ROLE_OPERATE_WRITERS)
    @PostMapping(value = "/allowVerification")
    public ResponseEntity allowVerification(@PathVariable Long collateralId, @RequestAttribute UserRequestInfo userRequestInfo) {
        collateralSectionService.allowAnyVerification(collateralId);
        return getSectionStatuses(collateralId);
    }
}
