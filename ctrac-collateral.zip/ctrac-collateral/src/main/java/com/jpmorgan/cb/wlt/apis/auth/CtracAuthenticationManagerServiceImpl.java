package com.jpmorgan.cb.wlt.apis.auth;

import com.jpmorgan.cib.wlt.ctrac.auth.AuthenticationManager;
import com.jpmorgan.cib.wlt.ctrac.auth.AuthenticationManagerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class CtracAuthenticationManagerServiceImpl implements CtracAuthenticationManagerService {

	@Value("${janus.api.sso.account}")
	private String CONST_JANUS_SSO_F_ACCOUNT;
	@Value("${janus.api.sso.pwd}")
	private String CONST_JANUS_SSO_PWD;
	@Value("${janus.api.sso.url}")
	private String CONST_JANUS_SSO_URL_KEY;
	@Value("${janus.api.key}")
	private String CONST_JANUS_LICENSE_KEY;

	private AuthenticationManager authenticationManager;

	@PostConstruct
	void init() {
		authenticationManager = AuthenticationManagerFactory.createAuthenticationManager(
				CONST_JANUS_SSO_URL_KEY, CONST_JANUS_LICENSE_KEY, CONST_JANUS_SSO_F_ACCOUNT, CONST_JANUS_SSO_PWD);
	}

	public AuthenticationManager getAuthenticationManager() {
		return authenticationManager;
	}
}
