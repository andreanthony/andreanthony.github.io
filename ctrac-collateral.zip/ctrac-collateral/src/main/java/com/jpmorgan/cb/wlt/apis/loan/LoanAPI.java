package com.jpmorgan.cb.wlt.apis.loan;

import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSectionService;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.auth.roles.CtracRole;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Secured(CtracRole.ROLE_READER)
@RestController
@RequestMapping(value = "/api/loans")
public class LoanAPI {
    private static final Logger logger = LoggerFactory.getLogger(LoanAPI.class);

    private LoanService loanService;
    private CollateralSectionService collateralSectionService;

    @Autowired
    public LoanAPI(LoanService loanService,CollateralSectionService collateralSectionService) {

        this.loanService = loanService;
        assert(collateralSectionService != null);
        this.collateralSectionService = collateralSectionService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<LoanDTO>> getLoans(@RequestParam Long collateralId,
              @RequestParam (required = false) Boolean active, @RequestParam (required = false) Boolean primary) {
       return ResponseEntity.ok(loanService.getLoans(collateralId, active, primary));
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{loanId}")
    public ResponseEntity<LoanDTO> getLoan(@PathVariable Long loanId) {
       return ResponseEntity.ok(loanService.getLoan(loanId));
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{loanId}/upbs")
    public ResponseEntity<List<UpbDTO>> getLoanUpbDetails(@PathVariable Long loanId) {
        return ResponseEntity.ok(loanService.getLoanUPBDetails(loanId));
    }

    @Secured(CtracRole.ROLE_VERIFIER)
    @RequestMapping(value = "/{collateralId}/verifyLoanSection", method = RequestMethod.POST)
    public ResponseEntity<List<LoanDTO>> verifyLoanBorrowerSection(@PathVariable Long collateralId, @RequestAttribute UserRequestInfo userRequestInfo) {
        collateralSectionService.verify(collateralId, CollateralSection.LOAN_BORROWER, userRequestInfo);
        return ResponseEntity.ok(loanService.verifyLoanSection(collateralId, userRequestInfo));
    }


}
