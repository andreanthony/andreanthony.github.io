package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;

import com.jpmorgan.cb.wlt.apis.c3.dtos.enums.AlthansPropertyType;
import com.jpmorgan.cb.wlt.apis.c3.dtos.enums.FIATPropertyType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Component
public class FiatToAlthansPropertyTypeConverter implements Converter<FIATPropertyType, AlthansPropertyType> {

    public static final Map<String, AlthansPropertyType> mapping;

    static {
        Map<String, AlthansPropertyType> tmp = new HashMap<>();
        tmp.put(FIATPropertyType.COMMERCIAL_CONDO_ASSOCIATION.name(), AlthansPropertyType.CONDO_ASSOC);
        tmp.put(FIATPropertyType.RESIDENTIAL_CONDO_ASSOCIATION.name(), AlthansPropertyType.CONDO_ASSOC);

        tmp.put(FIATPropertyType.MULTI_FAMILY.name(), AlthansPropertyType.MULTI_FAMILY);
        tmp.put(FIATPropertyType.COMMERCIAL.name(), AlthansPropertyType.COMMERCIAL);
        tmp.put(FIATPropertyType.DWELLING_RESIDENTIAL.name(), AlthansPropertyType.DWELLING_RESIDENTIAL);
        mapping = Collections.unmodifiableMap(tmp);
    }

    @Override
    public AlthansPropertyType convert(FIATPropertyType fiatPropertyType) {
        if (fiatPropertyType != null) {
            return mapping.get(fiatPropertyType.name());
        }
        return null;
    }

    public AlthansPropertyType convertByPropertyDescription(String fiatPropertyTypeDesc) {
        FIATPropertyType fiatPropertyType = FIATPropertyType.findByDisplayName(fiatPropertyTypeDesc);
        return convert(fiatPropertyType);
    }

}
