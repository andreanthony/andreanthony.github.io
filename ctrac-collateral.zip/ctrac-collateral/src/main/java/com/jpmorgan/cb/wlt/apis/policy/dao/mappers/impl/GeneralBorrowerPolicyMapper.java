package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.BIRRuleConclusion;
import com.jpmorgan.cb.wlt.apis.policy.dao.BirProofOfCovDetails;
import com.jpmorgan.cb.wlt.apis.policy.dao.ProofOfCoverage;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionMap;
import org.apache.commons.collections4.CollectionUtils;

import java.util.*;

public class GeneralBorrowerPolicyMapper extends AbstractGeneralPolicyMapper implements DaoMapper<ProofOfCoverage, PolicyDTO> {


    @Override
    public PolicyDTO toDTO(ProofOfCoverage model) {
        PolicyDTO dto = super.toDTO(model);
        dto.setInsuredName(model.getInsuredName());

        if(model.getBirProofOfCovDetails() == null){
            model.setBirProofOfCovDetails(new BirProofOfCovDetails());
        }

        if (CollectionUtils.isNotEmpty(model.getBirRuleConclusions())) {
            BIRRuleConclusionMap ruleConclusionMap = new BIRRuleConclusionMap();
            BIRRuleConclusionsMapper birRuleConclusionsMapper = new BIRRuleConclusionsMapper();
            model.getBirRuleConclusions().forEach(conclusion -> {
                BIRRuleConclusionDTO birRuleConclusionDTO = birRuleConclusionsMapper.toDTO(conclusion);
                ruleConclusionMap.put(getCompositeKey(conclusion.getCollateralRid(),
                        conclusion.getInsurableAssetSortOrder(),
                        conclusion.getFieldName()), birRuleConclusionDTO);
            });
            dto.setRuleConclusions(ruleConclusionMap);
        }
        
        GeneralBirProofOfCovDetailsMapper birProofOfCovDetailsMapper = new GeneralBirProofOfCovDetailsMapper();
        birProofOfCovDetailsMapper.addToDTO(dto, model.getBirProofOfCovDetails());

        return dto;
    }

    @Override
    public boolean map(PolicyDTO dto, ProofOfCoverage model) {
        if (!super.map(dto, model)) {
            return false;
        }

        //Only map the migrated flag from the DTO to model for Borrower policy
        model.setMigrated(dto.getMigrated());

        super.mapPolicyCoverages(dto, model);
        mapPolicyConclusions(dto, model);

        model.setInsuredName(dto.getInsuredName());
        if (model.getBirProofOfCovDetails() == null) {
            model.setBirProofOfCovDetails(new BirProofOfCovDetails());
        }

        GeneralBirProofOfCovDetailsMapper birProofOfCovDetailsMapper = new GeneralBirProofOfCovDetailsMapper();
        birProofOfCovDetailsMapper.map(dto, model.getBirProofOfCovDetails());
        return true;
    }

    private void mapPolicyConclusions(PolicyDTO dto, ProofOfCoverage model){
        List<BIRRuleConclusion> allBIRRuleConclusions = new ArrayList<>();
        BIRRuleConclusionsMapper birRuleConclusionsMapper = new BIRRuleConclusionsMapper();
        dto.getRuleConclusions()
                .values()
                .forEach(newConclusion -> {
                    BIRRuleConclusion existingConclusion = findRuleConclusion(model.getBirRuleConclusions(),
                            newConclusion.getFieldName(),
                            newConclusion.getCollateralRid()).orElse(new BIRRuleConclusion());
                    birRuleConclusionsMapper.map(newConclusion, existingConclusion);
                    existingConclusion.setProofOfCoverage(model);
                    allBIRRuleConclusions.add(existingConclusion);
                });
        model.setBirRuleConclusions(allBIRRuleConclusions);
    }

    private Optional<BIRRuleConclusion> findRuleConclusion(
            List<BIRRuleConclusion> ruleConclusions, String fieldName, Long collateralId) {
        return ruleConclusions.stream()
                .filter(conclusion -> collateralId == null ? conclusion.getFieldName().equals(fieldName)
                        : conclusion.getFieldName().equals(fieldName) && conclusion.getCollateralRid().equals(collateralId))
                .findFirst();
    }

}
