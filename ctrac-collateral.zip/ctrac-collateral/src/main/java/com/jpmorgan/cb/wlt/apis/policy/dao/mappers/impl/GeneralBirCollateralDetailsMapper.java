package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.BirCollateralDetails;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyCollateralDetailsDTO;

public class GeneralBirCollateralDetailsMapper extends AbstractBirCollateralDetailsMapper {

    @Override
    public PolicyCollateralDetailsDTO toDTO(BirCollateralDetails model){
        return super.toDTO(model);
    }

    @Override
    public boolean map(PolicyCollateralDetailsDTO dto, BirCollateralDetails model) {
        return super.map(dto,model);
    }
}