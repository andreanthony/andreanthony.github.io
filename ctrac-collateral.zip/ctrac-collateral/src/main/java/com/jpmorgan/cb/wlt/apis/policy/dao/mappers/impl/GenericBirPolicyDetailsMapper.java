package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyCollateralDetailsDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyInsuranceCoverageDTO;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRCollateralDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRInsurableAssetDetailsDTO;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.GenericBorrowerInsuranceReviewDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.FloodCoverageType;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.apache.commons.lang3.EnumUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GenericBirPolicyDetailsMapper implements DaoMapper<PolicyDTO, GenericBorrowerInsuranceReviewDTO> {

    @Override
    public GenericBorrowerInsuranceReviewDTO toDTO(PolicyDTO policyDTO) {
        Map<Long, List<String>> collateralCoverages = getCollateralCoverageMap(policyDTO);

        GenericBorrowerInsuranceReviewDTO genericBIReviewDTO = new GenericBorrowerInsuranceReviewDTO();
        genericBIReviewDTO.setRid(policyDTO.getPolicyId());
        Long collateralRid = collateralCoverages.keySet().iterator().next();
        genericBIReviewDTO.setCollateralRid(collateralRid);
        policyDTO.getCollateralCoverages().forEach(policyCollateralDetailsDTO ->
                addBIRCollateralDetailsDTO(genericBIReviewDTO, policyCollateralDetailsDTO));
        genericBIReviewDTO.setPolicyType(EnumUtils.getEnum(PolicyType.class, policyDTO.getPolicyType()));
        genericBIReviewDTO.setInsuranceType(EnumUtils.getEnum(InsuranceType.class, policyDTO.getInsuranceType()));
        genericBIReviewDTO.setEoiType(policyDTO.getEvidenceOfInsurance());
        genericBIReviewDTO.setCoverageType(getFloodCoverageType(collateralCoverages, collateralRid));
        genericBIReviewDTO.setExpirationDate(policyDTO.getExpirationDate());
        genericBIReviewDTO.setFloodCoverageIncluded(policyDTO.getFloodCovIncluded());
        genericBIReviewDTO.setFloodZonesListed(policyDTO.getFloodZoneListed());
        genericBIReviewDTO.setCoversAllRiskOfFlood(policyDTO.getCoversAllRiskOfFlood());
        genericBIReviewDTO.setJpmListedAsMortgageePayee(policyDTO.getJpmMortgageePayee());
        genericBIReviewDTO.setJpmListedAsLenderLossPayee(policyDTO.getJpmLenderLossPayee());
        genericBIReviewDTO.setJpmListedAsAdditionalInsured(policyDTO.getJpmAdditionalInsured());
        genericBIReviewDTO.setJpmLienPosition(policyDTO.getJpmLienPosition());
        genericBIReviewDTO.setProofOfPayment(policyDTO.getProofOfPayment());
        genericBIReviewDTO.setPolicyWrittenAtRcv(policyDTO.getPolicyWrittenAtRcv());
        genericBIReviewDTO.setProvidedCoverageTypes(collateralCoverages);
        genericBIReviewDTO.setSignedByAgent(policyDTO.getSignedByAgent());
        genericBIReviewDTO.setCondoAssociationPolicy(policyDTO.getCondoAssociationPolicy());
        genericBIReviewDTO.setTotalNumberOfCondoUnits(policyDTO.getTotalNumberOfCondoUnits());
        genericBIReviewDTO.setIndividualCondoUnitNumbers(policyDTO.getIndividualCondoUnitNumbers());
        populatePropertyTypes(genericBIReviewDTO, collateralRid, getPropertyTypeMap(policyDTO, collateralRid));
        return genericBIReviewDTO;

    }

    private FloodCoverageType getFloodCoverageType(Map<Long, List<String>> collateralCoverages, Long collateralRid) {
        return EnumUtils.getEnum(FloodCoverageType.class, collateralCoverages.get(collateralRid).get(0));
    }

    private void populatePropertyTypes(GenericBorrowerInsuranceReviewDTO genericBIReviewDTO, Long collateralRid, Map<Long, String> propertyTypeMap) {
        BIRCollateralDetailsDTO birCollateralDetails = genericBIReviewDTO.getCollateralDetailsMap().get(collateralRid);
        propertyTypeMap.keySet().forEach(key -> {
            BIRInsurableAssetDetailsDTO birInsurableAssetDetailsDTO = new BIRInsurableAssetDetailsDTO();
            birInsurableAssetDetailsDTO.setInsurableAssetSortOrder(key);
            birInsurableAssetDetailsDTO.setPropertyType(propertyTypeMap.get(key));
            birCollateralDetails.getInsurableAssetDetailsMap().put(key, birInsurableAssetDetailsDTO);
        });
    }

    private void addBIRCollateralDetailsDTO(
            GenericBorrowerInsuranceReviewDTO genericBIReviewDTO, PolicyCollateralDetailsDTO policyCollateralDetailsDTO) {
        BIRCollateralDetailsDTO birCollateralDetails = new BIRCollateralDetailsDTO();
        birCollateralDetails.setCollateralRid(policyCollateralDetailsDTO.getCollateralId());
        birCollateralDetails.setPolicyFloodZone(policyCollateralDetailsDTO.getPolicyFloodZone());
        birCollateralDetails.setGrandfathered(policyCollateralDetailsDTO.getGrandfathered());
        birCollateralDetails.getBirRuleConclusions().putAll(policyCollateralDetailsDTO.getBirRuleConclusions());
        genericBIReviewDTO.getCollateralDetailsMap().put(policyCollateralDetailsDTO.getCollateralId(), birCollateralDetails);
    }

    private Map<Long, String> getPropertyTypeMap(PolicyDTO policyDTO, Long collateralRid) {
        Map<Long, String> propertyTypeMap = new HashMap<>();
        PolicyCollateralDetailsDTO policyCollateralDetailsDTO = policyDTO.getCollateralCoverages()
                .stream().filter(dto -> collateralRid.equals(dto.getCollateralId())).findFirst().orElse(null);
        if (policyCollateralDetailsDTO != null && policyCollateralDetailsDTO.getInsuranceCoverages() != null) {
            policyCollateralDetailsDTO.getInsuranceCoverages().forEach(policyInsuranceCoverageDTO ->
                propertyTypeMap.put(policyInsuranceCoverageDTO.getInsurableAssetRid(), policyInsuranceCoverageDTO.getCoverageCategory()));
        }
        return propertyTypeMap;
    }

    @Override
    public boolean map(GenericBorrowerInsuranceReviewDTO dto, PolicyDTO model) {
        return false;
    }

    private Map<Long, List<String>> getCollateralCoverageMap(PolicyDTO policyDTO) {
        Map<Long, List<String>> collateralCoveragesMap = new HashMap<>();
        policyDTO.getCollateralCoverages().forEach((policyCollateralDetails) -> {
            List<String> coverageTypes = policyCollateralDetails.getInsuranceCoverages().stream()
                    .map(PolicyInsuranceCoverageDTO::getInsuranceCoverageType).collect(Collectors.toList());
            collateralCoveragesMap.put(policyCollateralDetails.getCollateralId(), coverageTypes);
        });
        return collateralCoveragesMap;
    }


}