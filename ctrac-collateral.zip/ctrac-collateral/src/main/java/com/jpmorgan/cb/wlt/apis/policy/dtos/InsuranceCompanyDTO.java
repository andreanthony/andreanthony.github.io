package com.jpmorgan.cb.wlt.apis.policy.dtos;

import lombok.Data;

import java.io.Serializable;

@Data
public class InsuranceCompanyDTO implements Serializable {

    private static final long serialVersionUID =1L;

    private Long rid;

    private String companyName;

}
