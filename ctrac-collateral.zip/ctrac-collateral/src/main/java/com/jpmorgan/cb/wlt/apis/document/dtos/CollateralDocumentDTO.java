package com.jpmorgan.cb.wlt.apis.document.dtos;

import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.Date;

public class CollateralDocumentDTO {

    private Long rid;
    private String fileName;
    private String fileNameWithExt;
    private String docIdentifier;
    private Long collateralRid;
    private Date documentDate;
    private FileContentDTO fileContent;


    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileNameWithExt() {
        return fileNameWithExt;
    }

    public void setFileNameWithExt(String fileNameWithExt) {
        this.fileNameWithExt = fileNameWithExt;
    }

    public String getDocIdentifier() {
        return docIdentifier;
    }

    public void setDocIdentifier(String docIdentifier) {
        this.docIdentifier = docIdentifier;
    }

    public Long getCollateralRid() {
        return collateralRid;
    }

    public void setCollateralRid(Long collateralRid) {
        this.collateralRid = collateralRid;
    }

    public Date getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }

    public FileContentDTO getFileContent() {
        return fileContent;
    }

    public void setFileContent(FileContentDTO fileContent) {
        this.fileContent = fileContent;
    }

    public CollateralDocumentSummaryDTO getCollateralDocumentSummary(){
        CollateralDocumentSummaryDTO summaryDTO = new CollateralDocumentSummaryDTO();
        summaryDTO.setRid(this.getRid());
        summaryDTO.setFileName(this.getFileNameWithExt());
        return summaryDTO;
    }

    public static CollateralDocumentDTO parseFromFileUpload(FileUploadAttachmentDTO fileUploadAttachmentDTO, DocumentMetaDataDTO metaDataDTO) {
        CollateralDocumentDTO collateralDocumentDTO = new CollateralDocumentDTO();
        collateralDocumentDTO.setCollateralRid(metaDataDTO.getCollateralRid());
        collateralDocumentDTO.setDocIdentifier(metaDataDTO.getDocIdentifier());
        collateralDocumentDTO.setDocumentDate(metaDataDTO.getDocumentDate());
        collateralDocumentDTO.setFileNameWithExt(fileUploadAttachmentDTO.getSummary().getFileName());
        collateralDocumentDTO.setFileName(FilenameUtils.removeExtension(fileUploadAttachmentDTO.getSummary().getFileName()));
        collateralDocumentDTO.setFileContent(FileContentDTO.parseFromFileUpload(fileUploadAttachmentDTO));
        return collateralDocumentDTO;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        CollateralDocumentDTO that = (CollateralDocumentDTO) o;

        return new EqualsBuilder()
                .append(rid, that.rid)
                .append(fileName, that.fileName)
                .append(fileNameWithExt, that.fileNameWithExt)
                .append(docIdentifier, that.docIdentifier)
                .append(collateralRid, that.collateralRid)
                .append(documentDate, that.documentDate)
                .append(fileContent, that.fileContent)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(rid)
                .append(fileName)
                .append(fileNameWithExt)
                .append(docIdentifier)
                .append(collateralRid)
                .append(documentDate)
                .append(fileContent)
                .toHashCode();
    }
}
