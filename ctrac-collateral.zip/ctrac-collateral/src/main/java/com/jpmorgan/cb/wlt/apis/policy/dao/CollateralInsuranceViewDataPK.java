package com.jpmorgan.cb.wlt.apis.policy.dao;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;

import java.io.Serializable;

public class CollateralInsuranceViewDataPK implements Serializable {
    private static final long serialVersionUID = -1;

    public CollateralInsuranceViewDataPK() {}

    private Collateral collateral;

    private ProofOfCoverage proofOfCoverage;

    public Collateral getCollateral() {
        return collateral;
    }

    public void setCollateral(Collateral collateral) {
        this.collateral = collateral;
    }

    public ProofOfCoverage getProofOfCoverage() {
        return proofOfCoverage;
    }

    public void setProofOfCoverage(ProofOfCoverage proofOfCoverage) {
        this.proofOfCoverage = proofOfCoverage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CollateralInsuranceViewDataPK that = (CollateralInsuranceViewDataPK) o;

        if (collateral != null ? !collateral.equals(that.collateral) : that.collateral != null) return false;
        return proofOfCoverage != null ? proofOfCoverage.equals(that.proofOfCoverage) : that.proofOfCoverage == null;
    }

    @Override
    public int hashCode() {
        int result = collateral != null ? collateral.hashCode() : 0;
        result = 31 * result + (proofOfCoverage != null ? proofOfCoverage.hashCode() : 0);
        return result;
    }
}
