package com.jpmorgan.cb.wlt.apis.collateral.details.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CollateralRepository extends JpaRepository<Collateral, Long> {}
