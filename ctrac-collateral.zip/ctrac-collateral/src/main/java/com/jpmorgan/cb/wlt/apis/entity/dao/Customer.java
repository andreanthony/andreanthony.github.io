package com.jpmorgan.cb.wlt.apis.entity.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cb.wlt.dao.ContactDetails;

import javax.persistence.*;

@Entity
@Table(name = "TLCP_CUSTOMER")
public class Customer extends AuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "customerSeqGenerator")
    @TableGenerator(name = "customerSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_CUSTOMER", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Column(name = "RID")
    private Long rid;

    @Column(name = "NAME")
    private String name;

    @Column(name = "UNIQUE_CUSTOMER_NUMBER")
    private String uniqueCustomerNumber;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "CONTACT_DETAILS_ID")
    private ContactDetails contactDetails;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUniqueCustomerNumber() {
        return uniqueCustomerNumber;
    }

    public void setUniqueCustomerNumber(String uniqueCustomerNumber) {
        this.uniqueCustomerNumber = uniqueCustomerNumber;
    }

    public ContactDetails getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(ContactDetails contactDetails) {
        this.contactDetails = contactDetails;
    }

}
