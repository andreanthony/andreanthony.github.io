package com.jpmorgan.cb.wlt.apis.event.services.impl;

import com.jpmorgan.cb.wlt.apis.event.AbstractPublishEventRequest;
import com.jpmorgan.cb.wlt.apis.event.CollateralEventSection;
import com.jpmorgan.cb.wlt.apis.event.CollateralEventStatus;
import com.jpmorgan.cb.wlt.apis.event.dao.CollateralEvent;
import com.jpmorgan.cb.wlt.apis.event.dao.CollateralEventRepository;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cb.wlt.apis.loan.LoanDTO;
import com.jpmorgan.cb.wlt.apis.loan.services.LoanService;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.AuditEventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.EventDTO;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.json.EventJsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PublishEventServiceImpl implements PublishEventService {

	private static final Logger logger = LoggerFactory.getLogger(PublishEventServiceImpl.class);

	private CollateralEventRepository collateralEventRepository;
	private LoanService loanService;

	@Autowired
	public PublishEventServiceImpl(CollateralEventRepository collateralEventRepository,
	                               LoanService loanService) {
		this.collateralEventRepository = collateralEventRepository;
		this.loanService = loanService;
	}

	void publishEventWithUserName(String identifier, Long collateralRid, String description,
								  CtracEventType eventType, CollateralEventSection collateralSection,
								  String taskName, UserRequestInfo userRequestInfo) {
		String lineOfBusiness = getLineOfBusiness(collateralRid);

		AuditEventDTO auditEventDTO = new AuditEventDTO();
		auditEventDTO.setEventType(eventType.getDisplayValue());
		auditEventDTO.setPerformedBy(userRequestInfo.getUserSid());
		auditEventDTO.setCollateralId(collateralRid);
		auditEventDTO.setIdentifier(identifier);
		auditEventDTO.setLineOfBusiness(lineOfBusiness);
		auditEventDTO.setDescription(description);
		auditEventDTO.setCollateralSection(collateralSection.toString());
		auditEventDTO.setTaskName(taskName);
		auditEventDTO.setUserFullName(userRequestInfo.getUserFullName());
		publishEvent(auditEventDTO);
	}

	@Override
	@Transactional
	public void publishEvent(EventDTO eventDTO) {
		CollateralEvent collateralEvent = new CollateralEvent();
		collateralEvent.setEventStatus(CollateralEventStatus.PENDING.name());
		collateralEvent.setEventTime(eventDTO.getEventTime());
		collateralEvent.setEventUuid(eventDTO.getEventUuid());
		EventJsonBuilder eventJsonBuilder = new EventJsonBuilder().forDTO(eventDTO);
		collateralEvent.setEventJson(eventJsonBuilder.build());
		collateralEventRepository.save(collateralEvent);
	}

	String getLineOfBusiness(Long collateralRid) {
		List<LoanDTO> loans = loanService.getLoans(collateralRid, true, true);
		return loans.isEmpty() ? StringUtils.EMPTY : loans.get(0).getLineOfBusiness();
	}

	@Override
	public void publishEvent(AbstractPublishEventRequest publishRequest) {
		publishEventWithUserName(publishRequest.getIdentifier(), publishRequest.getCollateralRid(),
				publishRequest.getDescription(), publishRequest.getCtracEventType(),
				publishRequest.getCollateralEventSection(), publishRequest.getTaskName(), publishRequest.getUserRequestInfo());

	}
}
