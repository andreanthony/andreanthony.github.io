package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.*;
import com.jpmorgan.cb.wlt.apis.c3.dtos.builders.C3CalculatedCoverageDateBuilder;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cib.wlt.ctrac.enums.InsuranceType;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public abstract class AbstractCoverageDateRule implements C3Rule{

    private static final Logger logger = LoggerFactory.getLogger(AbstractCoverageDateRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        if (c3RequestDTO.getInsuranceType() == null ||
                getInsuranceType() == InsuranceType.valueOf(c3RequestDTO.getInsuranceType())) {
            List<C3CalculatedCoverageDate> calculatedCoverageDates = getC3CalculatedCoverageDates(c3ResponseDTO);

            if (!c3RequestDTO.isHoldVerifiedWithLpiDateOnly()) {
                if (!c3RequestDTO.isAddedAndRemovedCoveragesOnly()) {
                    c3ResponseDTO.getProcessedPolicies().addAll(calculateBorrowerPolicyDates(c3RequestDTO, calculatedCoverageDates));
                    c3ResponseDTO.getProcessedPolicies().addAll(calculateNewlyExpiredLpPolicyDates(c3RequestDTO, calculatedCoverageDates));
                    calculateFutureBorrowerPolicyDates(c3RequestDTO, calculatedCoverageDates);
                    calculatedCoverageDates.addAll(calculateDatesPriorToFutureDates(c3RequestDTO, calculatedCoverageDates));
                    if (c3RequestDTO.isEvaluateGap()) {
                        calculateExpiringPoliciesExpirationDates(c3RequestDTO, calculatedCoverageDates);
                    }
                }
                calculateAddedAndRemovedCoverageDates(c3RequestDTO, calculatedCoverageDates);
            }
            Date overrideDate = c3RequestDTO.isInsuranceTypeRequested(getInsuranceType()) ? getOverrideCalculatedCoverageDate(c3RequestDTO) : null;
            if (overrideDate != null) {
                logger.debug("AbstractCoverageDateRule - overrideDate for {} is {}", getInsuranceType(), overrideDate);
                calculatedCoverageDates
                        .removeIf(calculatedCoverageDate -> !calculatedCoverageDate.getCoverageDate().after(overrideDate));
                calculatedCoverageDates.addAll(buildCalculatedCoverageDates(overrideDate, c3RequestDTO.getRequiredCoverages(getInsuranceType())));
            }
            if (logger.isDebugEnabled()) {
                logger.debug("AbstractCoverageDateRule - {} calculated coverage dates: {}", getInsuranceType(),
                        StringUtils.join(c3ResponseDTO.getCalculatedFloodCoverageDates(), ','));
            }
        }
    }

    private List<C3CalculatedCoverageDate> calculateDatesPriorToFutureDates(C3RequestDTO c3RequestDTO, List<C3CalculatedCoverageDate> calculatedCoverageDates) {
        //if any date is after currentRefDate - find any policy with eff/expr/canc date between currentRefDate and that future date
        Date currentReferenceDate = c3RequestDTO.getCurrentReferenceDate_();
        List<C3Policy> allPolicies = c3RequestDTO.getAllPolicies(getInsuranceType());
        List<C3CalculatedCoverageDate> priorCalculatedCoverageDates = new ArrayList<>();
        calculatedCoverageDates
                .stream()
                .filter(c3CalculatedCoverageDate -> c3CalculatedCoverageDate.getCoverageDate().after(currentReferenceDate))
                .forEach(c3CalculatedCoverageDate -> allPolicies.forEach(policy -> {
                    Date policyFutureDate = getPolicyDateInRange(policy, currentReferenceDate, c3CalculatedCoverageDate.getCoverageDate());
                    if (policyFutureDate != null && policy.hasMatchingCoverage(
                            c3CalculatedCoverageDate.getCoverageType(), c3CalculatedCoverageDate.getInsurableAssetId())) {
                        addCalculatedCoverageDates(priorCalculatedCoverageDates, policyFutureDate, policy);
                    }
                }));
        return priorCalculatedCoverageDates;
    }

    private Date getPolicyDateInRange(C3Policy policy, Date date1, Date date2) {
        Date date = getDateInRangeOrNull(policy.getEffectiveDate_(), date1, date2);
        if (date == null) {
            date = getDateInRangeOrNull(policy.getCancellationEffectiveDate_(), date1, date2);
            if (date == null) {
                date = getDateInRangeOrNull(policy.getExpirationDate_(), date1, date2);
            }
        }
        return date;
    }

    private Date getDateInRangeOrNull(Date date, Date date1, Date date2) {
        if (date != null && date.after(date1) && date.before(date2)) {
            return date;
        }
        return null;
    }

    private List<C3CalculatedCoverageDate> buildCalculatedCoverageDates(Date coverageDate, List<C3RequiredCoverage> requiredCoverages) {
        List<C3CalculatedCoverageDate> c3CalculatedCoverageDates = new ArrayList<>();
        requiredCoverages
                .forEach(c3RequiredCoverage ->
                    c3CalculatedCoverageDates.add(new C3CalculatedCoverageDateBuilder(getInsuranceType().name(), coverageDate)
                            .coverageType(c3RequiredCoverage.getCoverageType())
                            .insurableAssetId(c3RequiredCoverage.getInsurableAssetId())
                            .insurableAssetType(c3RequiredCoverage.getInsurableAssetType_())
                            .build())
                );
        return c3CalculatedCoverageDates;
    }

    void calculateFutureBorrowerPolicyDates(C3RequestDTO c3RequestDTO, List<C3CalculatedCoverageDate> calculatedCoverageDates) {
        if (!CollectionUtils.isEmpty(calculatedCoverageDates)) {
            Date earliestDate = calculatedCoverageDates
                    .stream()
                    .map(C3CalculatedCoverageDate::getCoverageDate)
                    .min(Date::compareTo).orElse(null);

            c3RequestDTO.getBorrowerPolicies(getInsuranceType()).forEach(policy -> {
                if (policy.getEffectiveDate_().after(earliestDate)) {
                    addCalculatedCoverageDates(calculatedCoverageDates, policy.getEffectiveDate_(), policy);
                }
            });
        }
    }

    private void calculateAddedAndRemovedCoverageDates(C3RequestDTO c3RequestDTO, List<C3CalculatedCoverageDate> calculatedCoverageDates) {
        c3RequestDTO.getRequiredCoverages(getInsuranceType())
            .forEach(c3RequiredCoverage -> {
                if (c3RequiredCoverage.isNewlyAdded()) {
                    addCalculatedCoverageDate(calculatedCoverageDates, c3RequiredCoverage.getDocumentDate_(), c3RequiredCoverage);
                }
                else if (c3RequiredCoverage.isDescoped()) {
                    addCalculatedCoverageDate(calculatedCoverageDates, c3RequiredCoverage.getCancellationEffectiveDate_(), c3RequiredCoverage);
                }
            });
    }

    protected abstract InsuranceType getInsuranceType();

    abstract Date getOverrideCalculatedCoverageDate(C3RequestDTO c3RequestDTO);

    abstract List<C3CalculatedCoverageDate> getC3CalculatedCoverageDates(C3ResponseDTO c3ResponseDTO);

    abstract void addCalculatedCoverageDate(List<C3CalculatedCoverageDate> calculatedCoverageDates, Date date, C3Coverage c3Coverage);

    abstract void addCalculatedCoverageDates(List<C3CalculatedCoverageDate> calculatedCoverageDates, Date date, C3Policy policy);

    private List<Long> calculateBorrowerPolicyDates(C3RequestDTO c3RequestDTO, List<C3CalculatedCoverageDate> calculatedCoverageDates) {
        List<Long> processedPolicies = new ArrayList<>();
        c3RequestDTO.getBorrowerPolicies(getInsuranceType()).forEach(policy -> {
            if (policy.isNewlyCancelled()) {
                Date calculatedCoverageDate = policy.isApplicationOrBinder() ? policy.getEffectiveDate_() : policy.getCancellationEffectiveDate_();
                addCalculatedCoverageDates(calculatedCoverageDates, calculatedCoverageDate, policy);
                processedPolicies.add(policy.getPolicyId());
            }
            if (policy.isNewlyAccepted()) {
                addCalculatedCoverageDates(calculatedCoverageDates, policy.getEffectiveDate_(), policy);
                processedPolicies.add(policy.getPolicyId());
            }
            if (policy.isNewlyExpired(c3RequestDTO.getCurrentReferenceDate_())) {
                addCalculatedCoverageDates(calculatedCoverageDates, policy.isApplicationOrBinder() ?
                        policy.getEffectiveDate_() : policy.getExpirationDate_(), policy);
                processedPolicies.add(policy.getPolicyId());
            }
        });
        return processedPolicies;
    }

    private List<Long> calculateNewlyExpiredLpPolicyDates(C3RequestDTO c3RequestDTO, List<C3CalculatedCoverageDate> calculatedCoverageDates) {
        List<Long> processedPolicies = new ArrayList<>();
        c3RequestDTO.getLpPolicies(getInsuranceType()).forEach(policy -> {
            if (policy.isNewlyExpired(c3RequestDTO.getCurrentReferenceDate_())) {
                addCalculatedCoverageDates(calculatedCoverageDates, policy.getExpirationDate_(), policy);
                processedPolicies.add(policy.getPolicyId());
            }
        });
        return processedPolicies;
    }

    private void calculateExpiringPoliciesExpirationDates(C3RequestDTO c3RequestDTO, List<C3CalculatedCoverageDate> calculatedCoverageDates) {
        c3RequestDTO.getExpiringPolicies(c3RequestDTO.getAllPolicies(getInsuranceType()))
                .forEach(policy -> addCalculatedCoverageDates(calculatedCoverageDates, policy.getExpirationDate_(), policy));
    }

}
