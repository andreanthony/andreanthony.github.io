package com.jpmorgan.cb.wlt.apis.collateral.sections.dao;

import com.jpmorgan.cb.wlt.apis.collateral.details.dao.Collateral;
import com.jpmorgan.cb.wlt.apis.collateral.sections.CollateralSection;
import com.jpmorgan.cb.wlt.apis.collateral.sections.dtos.SectionStatusDto;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cib.wlt.ctrac.enums.VerificationStatus;
import com.jpmorgan.cib.wlt.ctrac.formatters.date.impl.DefaultDateFormatter;
import org.apache.commons.lang3.EnumUtils;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "TLCP_SECTION_STATUS")
public class SectionStatus extends AuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "sectionStatusSeqGenerator")
    @TableGenerator(name = "sectionStatusSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_SECTION_STATUS", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    @Column(name = "RID")
    private Long rid;

    @Column(name = "SECTION_ID")
    private String sectionId;

    @Column(name = "STATUS_ID")
    private String statusId;

    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

    @Column(name = "MODIFIED_DATE")
    private Date modifiedDate;

    @Column(name = "VERIFIED_BY")
    private String verifiedBy;

    @Column(name = "VERIFIED_DATE")
    private Date verifiedDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COLLATERAL_RID")
    private Collateral collateral;

    @Transient
   private  DefaultDateFormatter defaultDateFormatter= new DefaultDateFormatter();

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getSectionId() {
        return sectionId;
    }

    public void setSectionId(String sectionId) {
        this.sectionId = sectionId;
    }

    public String getStatusId() {
        return statusId;
    }

    public void setStatusId(String statusId) {
        this.statusId = statusId;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Date getVerifiedDate() {
        return verifiedDate;
    }

    public void setVerifiedDate(Date verifiedDate) {
        this.verifiedDate = verifiedDate;
    }

    public Collateral getCollateral() {
        return collateral;
    }

    public void setCollateral(Collateral collateral) {
        this.collateral = collateral;
    }

    public SectionStatusDto mapToDto(){
        SectionStatusDto sectionStatusDto=new SectionStatusDto();
        sectionStatusDto.setRid(this.rid);
        sectionStatusDto.setSectionId(EnumUtils.getEnum(CollateralSection.class,this.sectionId));
        sectionStatusDto.setStatusId(EnumUtils.getEnum(VerificationStatus.class,this.statusId));
        sectionStatusDto.setModifiedBy(this.modifiedBy);
        sectionStatusDto.setModifiedDate(defaultDateFormatter.print(this.modifiedDate));
        sectionStatusDto.setVerifiedDate(defaultDateFormatter.print(this.verifiedDate));
        sectionStatusDto.setCollateralRid(collateral.getRid());

        return sectionStatusDto;
    }

}
