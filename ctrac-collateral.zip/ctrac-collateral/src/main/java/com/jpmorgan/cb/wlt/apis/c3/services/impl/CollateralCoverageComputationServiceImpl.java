package com.jpmorgan.cb.wlt.apis.c3.services.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3AlertEmail;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3RuleFactory;
import com.jpmorgan.cb.wlt.apis.c3.services.C3RequestPopulationService;
import com.jpmorgan.cb.wlt.apis.c3.services.CollateralCoverageComputationService;
import com.jpmorgan.cb.wlt.apis.c3.services.LenderPlacePolicyService;
import com.jpmorgan.cb.wlt.apis.event.services.PublishEventService;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.CtracEventType;
import com.jpmorgan.cib.wlt.ctrac.event.store.shared.dto.C3RequestEventDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;

@Service
public class CollateralCoverageComputationServiceImpl implements CollateralCoverageComputationService {

    private static final Logger logger = LoggerFactory.getLogger(CollateralCoverageComputationServiceImpl.class);

    private C3RuleFactory c3RuleFactory;
    private LenderPlacePolicyService lenderPlacePolicyService;
    private C3RequestPopulationService c3RequestPopulationService;
    private PublishEventService publishEventService;

    @Autowired
    public CollateralCoverageComputationServiceImpl(C3RuleFactory c3RuleFactory,
                                                    LenderPlacePolicyService lenderPlacePolicyService,
                                                    C3RequestPopulationService c3RequestPopulationService,
                                                    PublishEventService publishEventService) {
        assert(c3RuleFactory != null);
        this.c3RuleFactory = c3RuleFactory;
        assert(lenderPlacePolicyService != null);
        this.lenderPlacePolicyService = lenderPlacePolicyService;
        assert(c3RequestPopulationService != null);
        this.c3RequestPopulationService = c3RequestPopulationService;
        assert(publishEventService != null);
        this.publishEventService = publishEventService;
    }

    @Override
    public C3ResponseDTO evaluate(C3RequestEventDTO c3RequestEventDTO) {
        return evaluate(c3RequestPopulationService.build(c3RequestEventDTO));
    }

    @Override
    public C3ResponseDTO evaluate(C3RequestDTO c3RequestDTO) {
        logger.debug("Begin evaluate(c3RequestDTO)");
        final List<C3Rule> c3Rules = Collections.unmodifiableList(c3RuleFactory.getC3Rules());
        C3ResponseDTO c3ResponseDTO = new C3ResponseDTO();
        c3ResponseDTO.setCollateralRid(c3RequestDTO.getCollateralRid());
        for (C3Rule c3Rule : c3Rules) {
            c3Rule.execute(c3RequestDTO, c3ResponseDTO);
            if (c3ResponseDTO.isComplete()) {
                break;
            }
        }
        logger.debug("End evaluate(c3RequestDTO)");
        return c3ResponseDTO;
    }

    @Override
    public void apply(C3ResponseDTO c3ResponseDTO) {
        logger.debug("Begin apply(c3RequestDTO)");
        List<Long> proofOfCoverageRids = lenderPlacePolicyService.applyC3Response(c3ResponseDTO);
        proofOfCoverageRids.addAll(c3ResponseDTO.getProcessedPolicies());
        lenderPlacePolicyService.publishC3WorkflowEvent(proofOfCoverageRids, c3ResponseDTO.getCollateralRid(), CtracEventType.C3_COMPLETED);
        sendAlertEmails(c3ResponseDTO.getAlertEmails());
        logger.debug("End apply(c3RequestDTO)");
    }

    @Override
    public C3ResponseDTO evaluateGap(C3RequestEventDTO c3RequestEventDTO) {
        logger.debug("Begin evaluateGap(c3RequestEventDTO)");
        C3ResponseDTO c3ResponseDTO = evaluate(c3RequestEventDTO);
        List<Long> proofOfCoverageRids = c3ResponseDTO.getExpiringPoliciesWithNoGap();
        if (!proofOfCoverageRids.isEmpty()) {
            lenderPlacePolicyService.publishC3WorkflowEvent(
                    proofOfCoverageRids, c3RequestEventDTO.getCollateralId(), CtracEventType.C3_EVALUATE_GAP_COMPLETED);
        }
        logger.debug("End evaluateGap(c3RequestEventDTO)");
        return c3ResponseDTO;
    }

    private void sendAlertEmails(List<C3AlertEmail> alertEmails) {
        if(CollectionUtils.isEmpty(alertEmails)){ return; }
        for (C3AlertEmail alertEmail: alertEmails) {
            lenderPlacePolicyService.publishAlertEmailEvent(alertEmail);
        }
    }
}
