package com.jpmorgan.cb.wlt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReferenceDateRepository extends JpaRepository<ReferenceDate, Long> {
	
	ReferenceDate findByName(String name);
	
}
