package com.jpmorgan.cb.wlt.apis.collateral.details.services;

import com.jpmorgan.cb.wlt.apis.collateral.details.CollateralDTO;

public interface CollateralValidationService {

    void validateSubmitForVerification(CollateralDTO collateralDTO);
}
