package com.jpmorgan.cb.wlt.apis.loan.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface LoanUpbDetailsRepository extends JpaRepository<LoanUpbDetails, Long> {
	public List <LoanUpbDetails> findByLoanRid(Long loanRid);
}



