package com.jpmorgan.cb.wlt.apis.policy.dao;

import lombok.Data;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Data
@Table(name = "VLCP_INSURANCE_COMPANY_LIST")
public class BIRInsuranceCompanyName  {

    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "AMBNUMBER")
    private String ambNumber;

    @Column(name = "APPROVED_INS_COMPANY_NAME")
    private String approvedInsCompanyName;

    @Column(name = "INSCOINDEX")
    private String inscoIndex;

    @Column(name = "NAICCOMPANYNUMBER")
    private Long naiccompanynumber;

    @Column(name = "COMPANYNAME_SOURCE")
    private String companyNameSource;

    @Column(name = "ACTIVE")
    private String active;

    @Column(name = "INSERTED_DATE")
    private Date insertedDate;

    @Override
    public boolean equals(Object obj) {
        if(obj == null) return false ;
        if(obj == this) return true;

        if(obj.getClass() !=getClass()){
            return false;
        }
        BIRInsuranceCompanyName insC = (BIRInsuranceCompanyName) obj;

        return new EqualsBuilder()
                    .appendSuper(super.equals(obj))
                    .append(rid,insC.rid)
                    .append(ambNumber,insC.ambNumber)
                    .append(approvedInsCompanyName,insC.approvedInsCompanyName)
                    .append(inscoIndex,insC.inscoIndex)
                    .append(naiccompanynumber,insC.naiccompanynumber)
                    .append(companyNameSource,insC.companyNameSource)
                    .append(active,insC.active)
                    .append(insertedDate,insC.insertedDate)
                    .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(this.rid)
                .append(this.ambNumber)
                .append(this.approvedInsCompanyName)
                .append(this.inscoIndex)
                .append(this.naiccompanynumber)
                .append(this.companyNameSource)
                .append(this.active)
                .append(this.insertedDate)
                .toHashCode();
    }

}
