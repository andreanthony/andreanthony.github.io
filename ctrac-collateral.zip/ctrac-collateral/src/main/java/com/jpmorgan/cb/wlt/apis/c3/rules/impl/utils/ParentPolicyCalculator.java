package com.jpmorgan.cb.wlt.apis.c3.rules.impl.utils;


import com.jpmorgan.cb.wlt.apis.c3.dtos.C3Policy;
import com.jpmorgan.cib.wlt.ctrac.enums.LPAction;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;

import java.util.*;

import static com.jpmorgan.cib.wlt.ctrac.enums.LPAction.NEW_BP;
import static com.jpmorgan.cib.wlt.ctrac.enums.LPAction.PENDING_C3;

public class ParentPolicyCalculator {

    private Map<LPAction, List<C3Policy>> policiesGroupedByLPAction;
    //LP Action used as priority to pick parent policy RID
    private final LinkedList<LPAction> priorityOrder = new LinkedList<>(Arrays.asList(NEW_BP, null, PENDING_C3));

    public ParentPolicyCalculator(List<C3Policy> policies){
        policiesGroupedByLPAction = groupPoliciesByLPAction(policies);
    }

    /**
     * Group the Policies in a map together by LP Action which will be used to pick parent policy by priority
     * @param policies - Policies to calculate from
     * @return grouped map of policies by LPAction
     */
    private Map<LPAction, List<C3Policy>> groupPoliciesByLPAction(List<C3Policy> policies){
        HashMap<LPAction, List<C3Policy>> groupedPolicies = new HashMap<>();
        if(CollectionUtils.isNotEmpty(policies)) {
            for (C3Policy policy : policies) {
                List<C3Policy> policiesForCurrentLpAction = groupedPolicies.get(policy.getLpAction_()) == null ?
                        new ArrayList<>() : groupedPolicies.get(policy.getLpAction_());
                policiesForCurrentLpAction.add(policy);
                groupedPolicies.put(policy.getLpAction_(), policiesForCurrentLpAction);
            }
        }
        return groupedPolicies;
    }

    /**
     * Main method of the calculator that will be called to determine the parent Policy for a given Policy DTO
     * @return Parent Policy
     */
    public C3Policy calculateParentPolicy(){
        for (LPAction lpAction : priorityOrder) {
            C3Policy parentPolicy = lookupParentPolicyWithPriority(lpAction);
            if (parentPolicy != null) {
                return parentPolicy;
            }
        }
        //Did not find any policy that classify to be the parent policy
        return null;
    }

    private C3Policy lookupParentPolicyWithPriority(LPAction lpAction){
        if(MapUtils.isNotEmpty(policiesGroupedByLPAction)){
            List<C3Policy> policiesFound = policiesGroupedByLPAction.get(lpAction);
            if(CollectionUtils.isNotEmpty(policiesFound)){
                return policiesFound.get(0);
            }
        }
        return null;
    }

 }
