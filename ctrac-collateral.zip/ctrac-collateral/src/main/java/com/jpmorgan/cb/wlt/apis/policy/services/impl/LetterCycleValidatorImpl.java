package com.jpmorgan.cb.wlt.apis.policy.services.impl;

import com.jpmorgan.cb.wlt.apis.policy.dtos.LetterCycleDTO;
import com.jpmorgan.cb.wlt.apis.policy.dtos.PolicyDTO;
import com.jpmorgan.cb.wlt.apis.policy.services.LetterCycleValidator;
import com.jpmorgan.cb.wlt.apis.policy.services.PolicyService;
import com.jpmorgan.cb.wlt.apis.policy.services.exceptions.PolicyNotFoundException;
import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralCoverageDTO;
import com.jpmorgan.cib.wlt.ctrac.enums.PolicyType;
import org.apache.commons.lang3.EnumUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class LetterCycleValidatorImpl implements LetterCycleValidator {
    private static final Logger logger = LoggerFactory.getLogger(LetterCycleValidatorImpl.class);
    public static final String SEND_FIRST_LP_LETTER = "Send_1st_LP_Letter";
    public static final String SEND_SECOND_LP_LETTER = "Send_2nd_LP_Letter";
    public static final String PENDING_FOR_ALTHANS = "Pending_For_Althans";
    private PolicyService policyService;

    @Autowired
    public LetterCycleValidatorImpl(PolicyService policyService) {
        assert(policyService != null);
        this.policyService = policyService;
    }

    @Override
    public List<String> validate(PolicyDTO policyDTO, List<GeneralCoverageDTO> generalCoverages) {
        List<String> validationErrors = new ArrayList<>();
        LetterCycleDTO letterCycleDTO = policyDTO.getLetterCycle();
        if(letterCycleDTO != null && letterCycleDTO.getWorkflowStep() != null) {
            validatePolicyType(policyDTO, validationErrors);
            validateLetterCycleWorkflowStep(policyDTO, generalCoverages, validationErrors);
            validateFirstLetterDate(policyDTO, validationErrors);
            validateSecondLetterDate(policyDTO, validationErrors);
            validateInsuranceAgency(policyDTO, validationErrors);
            validateParentBorrowerPolicy(policyDTO, validationErrors);
  		}
  		return validationErrors;
	}

    private void validateLetterCycleWorkflowStep(PolicyDTO policyDTO, List<GeneralCoverageDTO> generalCoverages, List<String> validationErrors) {
        String workflowStep = policyDTO.getLetterCycle().getWorkflowStep();
        if(!getValidWorkflowSteps().contains(workflowStep)) {
            validationErrors.add("workflowStep invalid");
        }
        else if (workflowStep == PENDING_FOR_ALTHANS) {
            String coverageType = policyDTO.getCollateralCoverages().get(0).getInsuranceCoverages().get(0).getInsuranceCoverageType();
            if (!generalCoverages
                    .stream()
                    .anyMatch(generalCoverageDTO -> generalCoverageDTO.getCoverageType().equals(coverageType) &&
                            generalCoverageDTO.isLenderPlacementRequired())) {
                validationErrors.add("workflowStep invalid - not lenderplaceable");
            }
        }
	}

    private List<String> getValidWorkflowSteps() {
        return Arrays.asList(SEND_FIRST_LP_LETTER, SEND_SECOND_LP_LETTER, PENDING_FOR_ALTHANS);
    }

    private void validatePolicyType(PolicyDTO policyDTO, List<String> validationErrors) {
		if(!PolicyType.valueOf(policyDTO.getPolicyType()).isLenderPlaced()){
            validationErrors.add("workflowStep invalid for borrower policy");
		}
	}

    private void validateInsuranceAgency(PolicyDTO policyDTO, List<String> validationErrors) {
		if(!"Althans".equals(policyDTO.getInsuranceCompanyName())){
            validationErrors.add("workflowStep invalid for insuranceAgency");
		}
	}

    private void validateFirstLetterDate(PolicyDTO policyDTO, List<String> validationErrors) {
        if(SEND_SECOND_LP_LETTER.equals(policyDTO.getLetterCycle().getWorkflowStep()) ||
                PENDING_FOR_ALTHANS.equals(policyDTO.getLetterCycle().getWorkflowStep())){
            DateValidator.validateDateValue(policyDTO.getLetterCycle().getFirstLetterDate(), "firstLetter", validationErrors);
        }
	}

    private void validateSecondLetterDate(PolicyDTO policyDTO, List<String> validationErrors) {
        if(PENDING_FOR_ALTHANS.equals(policyDTO.getLetterCycle().getWorkflowStep())){
            DateValidator.validateDateValue(policyDTO.getLetterCycle().getSecondLetterDate(), "secondLetter", validationErrors);
        }
	}

    private void validateParentBorrowerPolicy(PolicyDTO lpPolicy, List<String> validationErrors) {
        if (PolicyType.GI_LP_GAP == EnumUtils.getEnum(PolicyType.class, lpPolicy.getPolicyType())) {
            Long borrowerPolicyId = lpPolicy.getLetterCycle().getBorrowerPolicyRid();
            if (borrowerPolicyId == null) {
                validationErrors.add("borrowerPolicyRid required");
            } else {
                PolicyDTO borrowerPolicy=null;
                try{
                    borrowerPolicy = policyService.getPolicy(borrowerPolicyId);
                }
                catch(PolicyNotFoundException policyNotFoundException)
                {
                    logger.error("Invalid Policy ID for Borrower Policy");
                }
                if (borrowerPolicy == null) {
                    validationErrors.add("borrowerPolicyRid invalid");
                }
                else if (!PolicyType.valueOf(borrowerPolicy.getPolicyType()).isBorrowerPolicy()) {
                    validationErrors.add("borrowerPolicyRid invalid");
                } else {
                    Long collateralId = lpPolicy.getCollateralCoverages().get(0).getCollateralId();
                    String insuranceCoverageType = lpPolicy.getCollateralCoverages().get(0).getInsuranceCoverages().get(0).getInsuranceCoverageType();
                    if (!borrowerPolicy.hasCoverageType(insuranceCoverageType, collateralId)) {
                        validationErrors.add("borrowerPolicyRid invalid");
                    }
                }
            }
        }
    }

}
