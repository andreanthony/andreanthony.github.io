package com.jpmorgan.cb.wlt.apis.loan;

import com.jpmorgan.cb.wlt.apis.entity.EntityDTO;

import java.util.Date;
import java.util.List;

public class LoanDTO {
    private Long rid;
    private String loanNumber;
    private String loanAccountingSystem;
    private String lineOfBusiness;
    private String loanType;
    private Date releaseDate;
    private Date loadedDate;
    private String status;
    private String escrowType;
    private String agentLeadBankName;
    private String agentLeadBankEmail;
    private Long collateralId;
    private Boolean primaryFlag;
    private List<EntityDTO> borrowers;

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getLoanNumber() {
        return loanNumber;
    }

    public void setLoanNumber(String loanNumber) {
        this.loanNumber = loanNumber;
    }

    public String getLoanAccountingSystem() {
        return loanAccountingSystem;
    }

    public void setLoanAccountingSystem(String loanAccountingSystem) {
        this.loanAccountingSystem = loanAccountingSystem;
    }

    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public Date getLoadedDate() {
        return loadedDate;
    }

    public void setLoadedDate(Date loadedDate) {
        this.loadedDate = loadedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEscrowType() {
        return escrowType;
    }

    public void setEscrowType(String escrowType) {
        this.escrowType = escrowType;
    }

    public String getAgentLeadBankName() {
        return agentLeadBankName;
    }

    public void setAgentLeadBankName(String agentLeadBankName) {
        this.agentLeadBankName = agentLeadBankName;
    }

    public String getAgentLeadBankEmail() {
        return agentLeadBankEmail;
    }

    public void setAgentLeadBankEmail(String agentLeadBankEmail) {
        this.agentLeadBankEmail = agentLeadBankEmail;
    }

    public Long getCollateralId() {
        return collateralId;
    }

    public void setCollateralId(Long collateralId) {
        this.collateralId = collateralId;
    }

    public Boolean getPrimaryFlag() {
        return primaryFlag;
    }

    public void setPrimaryFlag(Boolean primaryFlag) {
        this.primaryFlag = primaryFlag;
    }

    public List<EntityDTO> getBorrowers() {
        return borrowers;
    }

    public void setBorrowers(List<EntityDTO> borrowers) {
        this.borrowers = borrowers;
    }
}
