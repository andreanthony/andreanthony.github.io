package com.jpmorgan.cb.wlt.apis.requirement.general.dao;


import com.jpmorgan.cb.wlt.apis.requirement.general.dtos.GeneralRequiredCoverageDTO;
import com.jpmorgan.cb.wlt.dao.AuditableEntity;
import com.jpmorgan.cb.wlt.dtos.UserRequestInfo;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "TLCP_GENERAL_REQUIRED_COVERAGE")
public class GeneralRequiredCoverage  extends AuditableEntity implements Serializable {
    private static final long serialVersionUID = -1;

    public static final BigDecimal DEFAULT_COVERAGE_AMOUNT = new BigDecimal("0.00");

    @GeneratedValue(strategy = GenerationType.TABLE, generator = "generalRequiredCoverageSeqGenerator")
    @TableGenerator(name = "generalRequiredCoverageSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_GENERAL_REQUIRED_COVERAGE", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 10)
    @Id
    @Column(name = "RID")
    private Long rid;

    @Column(name = "GENERAL_COVERAGE_RID")
    private Long generalCoverageRid;

    @Column(name = "IS_DESCOPED")
    private Boolean isDescoped;

    @Column(name = "COVERAGE_AMOUNT")
    private BigDecimal coverageAmount = DEFAULT_COVERAGE_AMOUNT;

    @Column(name = "AGGREGATE_AMOUNT")
    private BigDecimal aggregateAmount = DEFAULT_COVERAGE_AMOUNT;

    @Column(name = "DEDUCTIBLE_AMOUNT")
    private BigDecimal deductibleAmount = DEFAULT_COVERAGE_AMOUNT;

    @Column(name = "BALANCE_TYPE")
    private String balanceType;

    @Column(name = "STATUS")
    private String status;

    @ManyToOne
    @JoinColumn(name = "REQUIRED_COVERAGE_SOURCE_ID", nullable = false)
    private GeneralRequiredCoverageSource generalRequiredCoverageSource;
    public GeneralRequiredCoverage()
    {}
    public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	public Boolean getIsDescoped() {
		return isDescoped;
	}

	public void setIsDescoped(Boolean isDescoped) {
		this.isDescoped = isDescoped;
	}

    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(BigDecimal coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public BigDecimal getAggregateAmount() {
        return aggregateAmount;
    }

    public void setAggregateAmount(BigDecimal aggregateAmount) {
        this.aggregateAmount = aggregateAmount;
    }

    public BigDecimal getDeductibleAmount() {
        return deductibleAmount;
    }

    public void setDeductibleAmount(BigDecimal deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
    }

    public String getBalanceType() {
        return balanceType;
    }

    public void setBalanceType(String balanceType) {
        this.balanceType = balanceType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getGeneralCoverageRid() {
        return generalCoverageRid;
    }

    public void setGeneralCoverageRid(Long generalCoverageRid) {
        this.generalCoverageRid = generalCoverageRid;
    }


  public GeneralRequiredCoverageSource getGeneralRequiredCoverageSource() {
        return generalRequiredCoverageSource;
    }

    public void setGeneralRequiredCoverageSource(GeneralRequiredCoverageSource generalRequiredCoverageSource) {
        this.generalRequiredCoverageSource = generalRequiredCoverageSource;
    }
    public GeneralRequiredCoverageDTO toGeneralRequiredCoverageDTO()
    {
        GeneralRequiredCoverageDTO generalRequiredCoverageDTO = new GeneralRequiredCoverageDTO();
        BeanUtils.copyProperties(this,generalRequiredCoverageDTO);
        return generalRequiredCoverageDTO;
    }

    public GeneralRequiredCoverage fromGeneralRequiredCoverageDTO(GeneralRequiredCoverageDTO generalRequiredCoverageDTO, UserRequestInfo userRequestInfo) {
        if (generalRequiredCoverageDTO.getRid() == null || generalRequiredCoverageDTO.getRid() == 0) {
            BeanUtils.copyProperties(generalRequiredCoverageDTO, this, "rid");
        } else {
            BeanUtils.copyProperties(generalRequiredCoverageDTO, this);
        }
        this.setAuditInfo(userRequestInfo);
        return this;
    }

}
