package com.jpmorgan.cb.wlt.services;

import java.util.Date;

public interface ReferenceDateService {

    Date getCurrentReferenceDate();

    Date addBusinessDays(int businessDays, Date start);

    Date addCalendarDays(int calendarDays, Date start);
}
