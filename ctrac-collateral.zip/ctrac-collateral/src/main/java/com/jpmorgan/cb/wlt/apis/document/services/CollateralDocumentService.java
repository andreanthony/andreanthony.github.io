package com.jpmorgan.cb.wlt.apis.document.services;

import com.jpmorgan.cb.wlt.apis.document.dao.CollateralDocument;
import com.jpmorgan.cb.wlt.apis.document.dao.types.EntityDocumentHolder;
import com.jpmorgan.cb.wlt.apis.document.dtos.CollateralDocumentSummaryDTO;
import com.jpmorgan.cb.wlt.apis.document.dtos.DocumentMetaDataDTO;
import com.jpmorgan.cb.wlt.apis.upload.dtos.FileUploadAttachmentDTO;

import java.util.Collection;
import java.util.List;

public interface CollateralDocumentService {

    List<CollateralDocumentSummaryDTO> saveDocuments(List<FileUploadAttachmentDTO> fileUploadAttachmentDTOList,
                                                     EntityDocumentHolder entityDocumentHolder,
                                                     DocumentMetaDataDTO documentMetaDataDTO);

    void deleteAllDocuments(Collection<CollateralDocument> documentList);

    CollateralDocument lookupAndValidateDocument(Long docRid);
}
