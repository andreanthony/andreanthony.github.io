package com.jpmorgan.cb.wlt.config.environment.type;


import com.jpmorgan.cb.wlt.apis.auth.CtracAuthenticationManagerService;

import javax.servlet.http.HttpServletRequest;

public class NonLocalEnvironment extends AbstractEnvironment {

    public NonLocalEnvironment(CtracAuthenticationManagerService ctracAuthenticationManagerService) {
        super(ctracAuthenticationManagerService);
    }

    public String getUserNameFromRequest(HttpServletRequest request){
        return this.ctracAuthenticationManagerService.getAuthenticationManager().getUserFromRequest(request);
    }
}
