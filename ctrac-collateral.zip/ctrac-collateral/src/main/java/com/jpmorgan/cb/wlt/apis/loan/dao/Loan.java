package com.jpmorgan.cb.wlt.apis.loan.dao;

import com.jpmorgan.cb.wlt.dao.AuditableEntity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Table(name = "TLCP_LOAN")
public class Loan extends AuditableEntity implements Serializable {
    private static final long serialVersionUID = -1;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "loanSeqGenerator")
    @TableGenerator(name = "loanSeqGenerator", table = "TLCP_SEQUENCES", pkColumnName = "SEQ_NAME", pkColumnValue = "TLCP_LOAN", valueColumnName = "NEXT_HIGH_VAL", allocationSize = 1)
    private Long rid;

    @Column(name = "LOAN_NUMBER")
    private String loanNumber;

    @Column(name = "LOAN_ACCOUNTING_SYSTEM")
    private String loanAccountingSystem;

    @Column(name = "LINE_OF_BUSINESS")
    private String lineOfBusiness;

    @Column(name = "LOAN_TYPE")
    private String loanType;

    @Column(name = "RELEASE_DATE")
    private Date releaseDate;

    @Column(name = "LOADED_DATE")
    private Date loadedDate;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "ESCROW_TYPE")
    private String escrowType;

    @Column(name = "AGENT_LEAD_BANK_NAME")
    private String agentLeadBankName;

    @Column(name = "AGENT_LEAD_BANK_EMAIL")
    private String agentLeadBankEmail;

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "loan")
    private List<LoanBorrower> loanBorrowers = new ArrayList<>();

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "loan")
    private List<LoanCollateral> loanCollaterals = new ArrayList<>();

    public List<Long> getBorrowerIds() {
        return loanBorrowers.stream().map(LoanBorrower::getBorrowerId).collect(Collectors.toList());
    }

    public Long getRid() {
        return rid;
    }

    public void setRid(Long rid) {
        this.rid = rid;
    }

    public String getLoanNumber() {
        return loanNumber;
    }

    public void setLoanNumber(String loanNumber) {
        this.loanNumber = loanNumber;
    }

    public String getLoanAccountingSystem() {
        return loanAccountingSystem;
    }

    public void setLoanAccountingSystem(String loanAccountingSystem) {
        this.loanAccountingSystem = loanAccountingSystem;
    }

    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public Date getLoadedDate() {
        return loadedDate;
    }

    public void setLoadedDate(Date loadedDate) {
        this.loadedDate = loadedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEscrowType() {
        return escrowType;
    }

    public void setEscrowType(String escrowType) {
        this.escrowType = escrowType;
    }

    public String getAgentLeadBankName() {
        return agentLeadBankName;
    }

    public void setAgentLeadBankName(String agentLeadBankName) {
        this.agentLeadBankName = agentLeadBankName;
    }

    public String getAgentLeadBankEmail() {
        return agentLeadBankEmail;
    }

    public void setAgentLeadBankEmail(String agentLeadBankEmail) {
        this.agentLeadBankEmail = agentLeadBankEmail;
    }

    public List<LoanBorrower> getLoanBorrowers() {
        return loanBorrowers;
    }

    public void setLoanBorrowers(List<LoanBorrower> loanBorrowers) {
        this.loanBorrowers = loanBorrowers;
    }

    public List<LoanCollateral> getLoanCollaterals() {
        return loanCollaterals;
    }

    public void setLoanCollaterals(List<LoanCollateral> loanCollaterals) {
        this.loanCollaterals = loanCollaterals;
    }

}
