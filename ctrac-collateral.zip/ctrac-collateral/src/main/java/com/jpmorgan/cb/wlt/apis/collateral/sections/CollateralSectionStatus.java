package com.jpmorgan.cb.wlt.apis.collateral.sections;

public enum CollateralSectionStatus {
    VERIFIED,
    PENDING_VERIFICATION,
    DRAFT
}
