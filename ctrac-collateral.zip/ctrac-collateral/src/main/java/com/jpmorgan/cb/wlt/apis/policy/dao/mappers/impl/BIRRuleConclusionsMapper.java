package com.jpmorgan.cb.wlt.apis.policy.dao.mappers.impl;

import com.jpmorgan.cb.wlt.apis.policy.dao.BIRRuleConclusion;
import com.jpmorgan.cb.wlt.dao.DaoMapper;
import com.jpmorgan.cib.wlt.ctrac.bir.dto.BIRRuleConclusionDTO;

public class BIRRuleConclusionsMapper implements DaoMapper<BIRRuleConclusion, BIRRuleConclusionDTO> {

    @Override
    public BIRRuleConclusionDTO toDTO(BIRRuleConclusion model) {
        BIRRuleConclusionDTO birRuleConclusionDTO = new BIRRuleConclusionDTO();
        birRuleConclusionDTO.setCollateralRid(model.getCollateralRid());
        birRuleConclusionDTO.setProofOfCoverageRid(model.getProofOfCoverage() != null ? model.getProofOfCoverage().getRid(): null);
        birRuleConclusionDTO.setFieldName(model.getFieldName());
        birRuleConclusionDTO.setConclusion(model.getConclusion());
        birRuleConclusionDTO.setInsurableAssetSortOrder(model.getInsurableAssetSortOrder());
        return birRuleConclusionDTO;
    }


    @Override
    public boolean map(BIRRuleConclusionDTO dto, BIRRuleConclusion model) {
        if (dto.equals(toDTO(model))) {
            return false;
        }
        model.setConclusion(dto.getConclusion());
        model.setFieldName(dto.getFieldName());
        model.setInsurableAssetSortOrder(dto.getInsurableAssetSortOrder());
        model.setCollateralRid(dto.getCollateralRid());
        return true;
    }
}
