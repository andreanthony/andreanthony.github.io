package com.jpmorgan.cb.wlt.config;

import oracle.jdbc.pool.OracleDataSource;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.orm.hibernate5.HibernateExceptionTranslator;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.Properties;

@Profile({"collateralserver"})
@Configuration
@ComponentScan(basePackages = {"com.jpmorgan.cb.wlt"})
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "entityManagerFactory",
        transactionManagerRef = "transactionManager",
        basePackages = "com.jpmorgan.cb.wlt")

public class CollateralDataSourceConfig {

    @Value("${epv.tomcatdatasource}")
    private String TOMCAT_DATASOURCE;

    @Value("${db.jdbcUrl}")
    private String PROPERTY_NAME_DATABASE_URL;

    @Value("${db.username}")
    private String PROPERTY_NAME_DATABASE_USERNAME;

    @Value("${db.pwd}")
    private String PROPERTY_NAME_DATABASE_PWD;

    @Value("${hibernate.dialect}")
    private String PROPERTY_NAME_HIBERNATE_DIALECT_VALUE;

    @Value("${hibernate.show_sql}")
    private String PROPERTY_NAME_HIBERNATE_SHOW_SQL_VALUE;

    @Value("${db.connpool.minLimit}")
    private String PROPERTY_NAME_DATABASE_MINLIMIT;

    @Value("${db.connpool.maxLimit}")
    private String PROPERTY_NAME_DATABASE_MAXLIMIT;

    @Value("${db.connpool.initialLimit}")
    private String PROPERTY_NAME_DATABASE_INITIALLIMIT;

    @Value("${db.connpool.timeout}")
    private String PROPERTY_NAME_DATABASE_CONNTIMEOUT;

    @Value("${db.connpool.inactivityTimeout}")
    private String PROPERTY_NAME_DATABASE_INACTIVITYTIMEOUT;

    @Value("${db.connpool.validateConn}")
    private String PROPERTY_NAME_DATABASE_VALIDATECONN;

    private static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
    private static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
    private static final String PROPERTY_NAME_ENTITYMANAGER_PACKAGES_TO_SCAN = "com.jpmorgan.cb.wlt";

    private static final Logger logger = LoggerFactory.getLogger(CollateralDataSourceConfig.class);

    @Resource
    private Environment env;

    @Bean(name = "collateralDataSource")
    public DataSource dataSource(){
        DataSource dataSource = null;
        OracleDataSource oracleDataSource = null;

        try {

            if (TOMCAT_DATASOURCE != null && TOMCAT_DATASOURCE.equalsIgnoreCase("Y")) {
                logger.info("Collateral API - DB password is not specified. Retriving password from EPV-AIM valut using Tomcat Context Configuration.");
                Context initContext = new InitialContext();
                Context webContext = (Context)initContext.lookup("java:/comp/env");
                String dataSourceName = "jdbc/collateralDB";
                dataSource = (DataSource) webContext.lookup(dataSourceName);

                // Testing connection
                logger.info("Making test connection to DB (Getting connection from Tomcat connection pool");
                Connection conn = dataSource.getConnection();
                DatabaseMetaData dmd = conn.getMetaData();
                logger.info("getURL: {} getUserName: {}", dmd.getURL(), dmd.getUserName());
                logger.info("Closing test connection");
                conn.close();
                return dataSource;
            } else {

                oracleDataSource = new OracleDataSource();
                oracleDataSource.setURL(PROPERTY_NAME_DATABASE_URL);
                oracleDataSource.setUser(PROPERTY_NAME_DATABASE_USERNAME);
                oracleDataSource.setPassword(PROPERTY_NAME_DATABASE_PWD);
                if (PROPERTY_NAME_DATABASE_PWD == null || PROPERTY_NAME_DATABASE_PWD.equalsIgnoreCase("") ) {
                    logger.error("DB password is not specified. DB password must be declared in the property file");
                    oracleDataSource.setUser("");
                }
                oracleDataSource.setImplicitCachingEnabled(true);
                oracleDataSource.setConnectionCacheName("collateralDSCache");
                oracleDataSource.setConnectionCacheProperties(connectionCacheProperties());
                return oracleDataSource;
            }
        }

        catch(SQLException sqlex){
            logger.error(sqlex.getMessage(), sqlex);
        }
        catch(Exception ex) {
            // Additional safety mechanism - if exception, blank out the userId so that account doesn't get locked.
            if (oracleDataSource != null) {
                oracleDataSource.setUser("");
            }
            logger.error(ex.getMessage(), ex);
        }
        return dataSource;
    }

    @Bean(name = "entityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactoryBean.setDataSource(dataSource());
        entityManagerFactoryBean.setPersistenceProvider(new HibernatePersistenceProvider());
        entityManagerFactoryBean.setPackagesToScan(PROPERTY_NAME_ENTITYMANAGER_PACKAGES_TO_SCAN);
        entityManagerFactoryBean.setJpaProperties(hibProperties());

        entityManagerFactoryBean.afterPropertiesSet();
        return entityManagerFactoryBean;
    }


    @Bean(name = "transactionManager")
    @Primary
    public JpaTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

    @Bean
    public OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher() {
        OracleSequenceMaxValueIncrementer taskUniqueIdSeqFetcher = new OracleSequenceMaxValueIncrementer();
        taskUniqueIdSeqFetcher.setDataSource(dataSource());
        taskUniqueIdSeqFetcher.setIncrementerName("SEQ_TASK_UNIQUE_ID");
        return taskUniqueIdSeqFetcher;
    }

    @Bean
    public HibernateExceptionTranslator hibernateExceptionTranslator() {
        return new HibernateExceptionTranslator();
    }

    private Properties hibProperties() {
        Properties properties = new Properties();
        properties.put(PROPERTY_NAME_HIBERNATE_DIALECT, PROPERTY_NAME_HIBERNATE_DIALECT_VALUE);
        properties.put(PROPERTY_NAME_HIBERNATE_SHOW_SQL, PROPERTY_NAME_HIBERNATE_SHOW_SQL_VALUE);
        properties.put("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.SingletonEhCacheRegionFactory");
        properties.put("hibernate.cache.use_second_level_cache", true);
        properties.put("hibernate.cache.use_query_cache", true);
        properties.put("hibernate.id.new_generator_mappings", false);
        return properties;
    }

    private Properties connectionCacheProperties() {
        Properties properties = new Properties();
        properties.setProperty("MinLimit", PROPERTY_NAME_DATABASE_MINLIMIT);
        properties.setProperty("MaxLimit", PROPERTY_NAME_DATABASE_MAXLIMIT);
        properties.setProperty("InitialLimit", PROPERTY_NAME_DATABASE_INITIALLIMIT);
        properties.setProperty("ConnectionWaitTimeout", PROPERTY_NAME_DATABASE_CONNTIMEOUT);
        properties.setProperty("InactivityTimeout", PROPERTY_NAME_DATABASE_INACTIVITYTIMEOUT);
        properties.setProperty("ValidateConnection", PROPERTY_NAME_DATABASE_VALIDATECONN);
        return properties;
    }

}
