package com.jpmorgan.cb.wlt.apis.c3.rules.impl;

import com.jpmorgan.cb.wlt.apis.c3.dtos.C3RequestDTO;
import com.jpmorgan.cb.wlt.apis.c3.dtos.C3ResponseDTO;
import com.jpmorgan.cb.wlt.apis.c3.rules.C3Rule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExternallyAgentedRule implements C3Rule {

    private static final Logger logger = LoggerFactory.getLogger(ExternallyAgentedRule.class);

    @Override
    public void execute(C3RequestDTO c3RequestDTO, C3ResponseDTO c3ResponseDTO) {
        c3ResponseDTO.setComplete(c3RequestDTO.isExternallyAgented());
        logger.debug("ExternallyAgentedRule - Loan externally agented : {} ",c3RequestDTO.isExternallyAgented());
    }
}
