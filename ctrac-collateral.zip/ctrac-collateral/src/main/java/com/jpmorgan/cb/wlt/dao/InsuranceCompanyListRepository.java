package com.jpmorgan.cb.wlt.dao;


import com.jpmorgan.cb.wlt.apis.policy.dao.BIRInsuranceCompanyName;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InsuranceCompanyListRepository extends JpaRepository<BIRInsuranceCompanyName,Long> {

    @Cacheable(value = "insuranceCompanyNamesCache")
    List<BIRInsuranceCompanyName> findByApprovedInsCompanyNameContainingIgnoreCase(String approvedInsCompanyName);
}
